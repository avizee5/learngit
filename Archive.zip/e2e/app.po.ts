import { browser, by, element } from 'protractor';

export class Z5GlobalAppPage {
  navigateTo() {
    return browser.get('/');
  }

  getParagraphText() {
    return element(by.css('app-root h1')).getText();
  }
}
