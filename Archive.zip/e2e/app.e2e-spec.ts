import { Z5GlobalAppPage } from './app.po';

describe('z5-global-app App', () => {
  let page: Z5GlobalAppPage;

  beforeEach(() => {
    page = new Z5GlobalAppPage();
  });

  it('should display welcome message', done => {
    page.navigateTo();
    page.getParagraphText()
      .then(msg => expect(msg).toEqual('Welcome to app!!'))
      .then(done, done.fail);
  });
});
