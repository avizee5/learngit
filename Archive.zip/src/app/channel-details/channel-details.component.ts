import { Component, OnInit, Input , ViewChild, ElementRef, Output, EventEmitter, HostListener, OnDestroy} from '@angular/core';
import { HeaderservicesService } from '../services/headerservices.service';
import { VideoService } from '../services/video.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { UserProfileService } from '../services/user-profile.service';
import { SubscriptionService } from '../services/subscription.service';
import { NetworkService } from '../services/network.service';
import { RouteService } from '../services/route.service';
import { SettingsService } from '../services/settings.service';
import { EpgService } from '../services/epg.service';
import { SeoService } from '../services/seo.service';
import { CommonService } from '../services/common.service';
import { CarouselComponent } from '../carousel/carousel.component'; // import to control carousel in your views
// import { EpgApi } from '../../data/catalog/api/EpgApi';
import { FavoritesApi, RemindersApi, UserApi, WatchHistoryApi, WatchlistApi } from '../../data/user/api/api';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { Http} from '@angular/http';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import * as $ from 'jquery';
// import * as api from '../../data/catalog/api/api';
import { ChannelApi, EpgApi } from '../../data/catalog/api/api';
import { environment } from '../../environments/environment';
import 'rxjs/add/operator/timeout';
import 'rxjs/add/operator/takeUntil';
import { Subject } from 'rxjs/Subject';
import {CollectionApi} from '../../data/gwapi_catalog/api/CollectionApi';

/* Angular Universal */
import { isPlatformBrowser } from '@angular/common';
import { Inject, PLATFORM_ID } from '@angular/core';

declare let googletag;
@Component
({
  selector: 'app-channel-details',
  templateUrl: './channel-details.component.html',
  styleUrls: ['./channel-details.component.less']
})

export class ChannelDetailsComponent implements OnInit, OnDestroy {
 @Input() public show: any;

 private sub: any; /*Route Params for deep linking*/
 private id: string;
 public name: string;
 private engilshName: string;
 private startTime: any;
 private currentTime: any;
 private remainingTime: any;
 private endTime: any;
 private elapsed: any;
 private serverTime: any;
 private getServerTime: any;

 public bannerplayer: any;
 public featuredShows: any;
 public similarChannels: any;
 public relatedChannels: any;
 public newReleases: any;
 public upNextTwo: any;
 public upNext: any;
 public featuredisplay: any;

 private modalVideoPopup = false; /*Video*/
 private modalVideoDetails: any;
 private castVisibility: any;
 public video: any;
 public videochange: any;
 public bannerImage: any;

 public carousel: any; /*Depends on API*/
 public carouselTitle: any;

 public ifRights: any;
 public test: any;
 public nowPlaying: any;
 public nextPlaying: any;
 public featured: any;
 public similar: any;
 public related: any;
 private noInformation: boolean;
 private streamDash: any;
 private streamHls: any;
 public data: any;
 private router2: any;
 private router: any;
 private basepath: any;
 // private catalogbasepath: any;
 private pageName: any;

 private reminderText: string;
 private typeofpopup: string;
 public showSignUpPromt: boolean;
 private subscription: boolean;
 private gAlanguages: any = [];
 private gAgenres: any = [];
 private channelGenres: any = [];
 private channelLanguages: any = [];
 private channelRelatedGenres: any;
 private string: any;
 private string1: any;
 private string2: any;
 private relatedGenres: any;
 private similarContent: any = [];
 private relatedContent: any = [];
 private contentLanguages: any;
 private loginToken: any;
 public showLogin: any;
 private assetTypes: any;
 private premium: any;

 private googletagAvailable: any;
 private errorImage1: any;
 private showSubPopUp: any;

 private subscriptionSuccess: any;
 private configFile: any;
 private videoCounter: any = 0;

 private coverImage: any;
 private coverName: any;

 private timeOffset: any;
public orginalBannerData: any;
public errorMessage: any;
private browser: any;
private countryCode: any;
private playerHeight: any;

private localstorage: any;
private window: any;
private document: any;
private navigator: any;

public customPage = false;

 // Asset basepath letiable
 private assetbasepath = environment.assetsBasePath;
 private catalogbasepath = environment.catalogbasepath;
 private paramName: any;

 public showUpNextEmpty: any = false;
 public isNewsPage = false;
 public apiRetryCount = 1;
 public apiRetry = 2;
 public moreNewsData: any;
 private ngUnsubscribe = new Subject<any>();
 public showGetPremium: any = false;
 public displayLang: any;

 public videoAdData: any;
 public yIndex: any;
 constructor (@Inject(PLATFORM_ID) private platformId: Object,
  private commonService: CommonService,
  private seoService: SeoService,
  private settingsService: SettingsService,
  private epgService: EpgService ,
  private location: Location,
  private networkService: NetworkService,
  private routeservice: RouteService,
  private gtm: GoogleAnalyticsService,
  private subscriptionService: SubscriptionService,
  private route: ActivatedRoute,
  private userProfileService: UserProfileService,
  private headerservicesService: HeaderservicesService,
  private http: Http, private videoService: VideoService,
  private currentRoute: Router) {
  if (isPlatformBrowser(this.platformId)) {
    this.localstorage = localStorage;
    this.window = window;
    this.document = document;
    this.navigator = navigator;
  }

  this.router = currentRoute;
  this.router2 = this.window.location.pathname;
  this.headerservicesService.viewChange(this.router2);
  this.loginToken = this.localstorage.getItem('token');
  this.headerservicesService.signInReminder.takeUntil(this.ngUnsubscribe).subscribe(val => {
    if ( val === false) {
      if ( this.premium.indexOf('premium') !== -1) {
        $('#noAccess').show();
        $('#noAccessSubs').hide();
        $('#playImage').hide();
      }
    } else {
      $('#noAccess').hide();
      $('#noAccessSubs').hide();
    }
  });

  this.headerservicesService.subscribeReminder.takeUntil(this.ngUnsubscribe).subscribe(value => {
    if ( value === false) {
      if ( this.premium.indexOf('premium') !== -1) {
        $('#noAccessSubs').show();
        $('#noAccess').hide();
        $('#playImage').hide();
      }
    } else {
      $('#noAccess').hide();
      $('#noAccessSubs').hide();
    }
  });

  this.headerservicesService.modelValue.takeUntil(this.ngUnsubscribe).subscribe(value => {
    this.videochange = value;
    if (this.videochange === true) {
      // this.video = false;
    } else if (!this.videochange && this.document.getElementById('playImage')) {
      if ((this.loginToken && this.subscription) || this.premium.indexOf('premium') === -1) {
        this.browser = this.videoService.get_browser();
        if ((this.browser.name.match(/UCBrowser/i) || this.browser.name.match(/UBrowser/i)) && this.navigator.userAgent.match(/mobile|iPhone|iPod|iPad/i)) {
          this.video = true;
        } else {
          if (this.document.getElementById('playImage')) {
          this.document.getElementById('playImage').style.display = 'block';
          }
        }
      }
    }
  });

  this.headerservicesService.searchValue.takeUntil(this.ngUnsubscribe).subscribe(value => {
    if (value === false && this.loginToken && this.subscription) {
      $('#noAccessSubs').hide();
      $('#noAccess').hide();
      $('#playImage').show();
    }
  });

  this.videoService.alertCastState.takeUntil(this.ngUnsubscribe).subscribe(value => {
    this.castVisibility = value;
    if (!value && this.video === false && this.document.getElementById('playImage') && this.loginToken && this.subscription) {
      this.document.getElementById('playImage').style.display = 'block';
    }
  });

  this.videoService.alertModalState.takeUntil(this.ngUnsubscribe).subscribe(value => {
    if ( value) {
      this.video = false;
    }
  });

  // check my plan flag
  this.subscriptionService.planApiSuccess.takeUntil(this.ngUnsubscribe).subscribe(value => {
    this.showSubPopUp = value;
    if (this.showSubPopUp !== undefined  && this.subscriptionSuccess === undefined) {
      this.ngOnInit();
    }
  });
 }
  public ngOnInit () {
    if (isPlatformBrowser(this.platformId)) {
      this.localstorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
    if (this.loginToken) {
      this.displayLang = this.localstorage.getItem('UserDisplayLanguage');
    } else {
      this.displayLang = this.localstorage.getItem('display_language');
    }
    let network;
    network = this.networkService.getScreenStatus();
    $('#loaderPage').css( 'display', 'block');
    this.loginToken = localStorage.getItem('token');
    this.countryCode = this.settingsService.getCountry();
    this.showSubPopUp = this.subscriptionService.getPlanApiSucess();
    if (this.loginToken && (this.showSubPopUp === undefined)) {
      return;
    }

    this.subscriptionSuccess = true;
    this.errorImage1 = '';
    this.configFile = this.settingsService.getCompleteConfig();
    // this.googletagAvailable = this.localstorage.getItem('googletag');
    this.googletagAvailable = this.commonService.checkGoogleTag();

    if ( this.getServerTime === undefined) {
     $('#loaderPage').css('display', 'block');
    }

    this.sub = this.route.params.takeUntil(this.ngUnsubscribe).subscribe(params => {
    this.headerservicesService.routeParamChange(true);
    this.getOffset();
    this.routeservice.setLoginRoute(this.window.location.pathname);  /*Return back to this page on login relaod */
    this.window.scrollTo(0, 0);
    $('#loaderPage').css('display', 'block');
    this.loginToken = this.localstorage.getItem('token');

    this.gtm.storeWindowError();
    this.ifRights = undefined;
    this.castVisibility = this.videoService.enableCastView;
    this.basepath = this.settingsService.getbasePath(); /*Image URL */
    this.featuredShows = undefined;
    this.similarChannels = undefined;
    this.relatedChannels =  undefined;
    this.moreNewsData =  undefined;
    this.carousel = undefined;
    this.nowPlaying = false;
    this.nextPlaying = false;
    this.featured = false;
    this.noInformation = false;
    this.similar = false;
    this.related = false;
    this.video = false;
    this.showLogin = undefined;
    this.subscription = false;
    this.channelGenres = [];
    this.channelLanguages = [];
    this.gAgenres = [];
    this.channelRelatedGenres = [];
    this.gAlanguages = [];
    this.test = [];
    // this.test = ''
    this.similarContent = [];
    this.relatedContent = [];
    this.orginalBannerData = undefined;
    this.id = params['id'];
    this.paramName = params['name'] ;
    this.showGetPremium = false;
    this.yIndex = 0;
    if (network === true) {
      $('#loaderPage').css('display', 'block');
    }
      this.callServerTime();
      this.getBannerDetails();
    });
  }

  @HostListener('window:resize', ['$event'])
  public onResize(event) {
    let width;
    width = $('.bannerinner').width();
    this.playerHeight = width * 9 / 16 ;
  }

  private getOffset(): void {
    let offset, o;
    offset = new Date().getTimezoneOffset(), o = Math.abs(offset);
    this.timeOffset = (offset < 0 ? '+' : '-') + ('00' + Math.floor(o / 60)).slice(-2) + ':' + ('00' + (o % 60)).slice(-2);
    offset = 0, o = Math.abs(offset);
  }

  private callServerTime() {
    let url;
    url = environment.serverTimeUrl;
    this.getServerTime = this.epgService.getcurrentTime(url).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe( value => {
      this.serverTime = new Date(value.serverdate);
      this.currentTime = this.serverTime.getTime();
      if (this.currentTime) {
        this.callngoninit();
      }
    }, err => {
      this.serverTime = new Date();
      this.currentTime = this.serverTime.getTime();
      if (this.currentTime) {
        this.callngoninit();
      }
    });
    ++this.videoCounter;
    this.videoService.instance = this.videoCounter;
  }

  public callngoninit() {
    let config;
    config = {
    apiKey: ' ',
    username: ' ',
    password: ' ',
    accessToken: ' ',
    withCredentials: false
    };
    let x, y;
    // x = new api.ChannelApi(this.http, null, config);
    // y = new api.EpgApi(this.http, null, config);
    x = new ChannelApi(this.http, null, config);
    y = new EpgApi(this.http, null, config);

    let token, channelTitle, tempTitle;
    token = this.localstorage.getItem('token');
    let params;
    params = 'bearer ' + token;
    let scope = this;
    this.countryCode = this.settingsService.getCountry();
    x.v1ChannelByIdGet(this.id, undefined, this.countryCode ).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(response => {
    let breadCrumbArray;
    breadCrumbArray = [{'label': 'BREADCRUMB.HOME', 'url': '/', 'enable': true}, {'label': 'BREADCRUMB.CHANNELS', 'url': '/channels', 'enable': true}, {'label': response.title, 'url': this.router2, 'enable': false}];
    this.headerservicesService.breadCrump(breadCrumbArray);
    response.business_type = (response.business_type === undefined ? 'free' : response.business_type);
    this.premium = response.business_type;
    // if (response && response.extended && response.extended.seo_title) {
    //      tempTitle = (response.extended.seo_title !== null || response.extended.seo_title !== undefined || response.extended.seo_title !== '') ? response.extended.seo_title : response.original_title;
    // } else {
    //       tempTitle = (response.seo_title && (response.seo_title !== null || response.seo_title !== undefined || response.seo_title !== '')) ? response.seo_title : response.original_title;
    // }
    tempTitle = response.original_title;
    channelTitle = this.commonService.convertToLowercase(tempTitle);
    if (channelTitle !== this.paramName) {
      if (window.location.search.length > 0) {
        // todo
      } else {
        this.location.replaceState('channels/details/' +  channelTitle + '/' + this.id);
      }
    }

    this.headerservicesService.premium = (this.premium.indexOf('premium') !== -1) ? true : false;
    this.channelGenres = [];
    this.channelLanguages = [];
    this.channelRelatedGenres = [];
    this.coverImage = response.cover_image;
    this.coverName = response.id;
    this.bannerImage = this.basepath + this.coverName + '/cover/' + '170x120/' + this.coverImage;

      // let channel_title
      // let name
      // name = response.original_title
      // channel_title = name.toLowerCase().replace(/ /g, '-')
      // channel_title = channel_title.replace(/---/g, '-')
      // channel_title = channel_title.replace(/,/g, '')
      // channel_title = channel_title.toLowerCase().replace(/&/g, 'and')


      /*For GA genres */
      let index;
      if ( response.genres.length > 0) {
        for ( index = 0; index < response.genres.length ; index++) {
          this.gAgenres.push(response.genres[index].id);
          this.channelGenres.push(response.genres[index].id);
          this.channelLanguages.push(response.languages);
          this.string = this.gAgenres.join();
          this.string2 = this.channelGenres.join();
          this.contentLanguages = this.channelLanguages.join();
        }
      } else {
        this.string = '';
        this.string2 = '';
      }

      /*For GA languages */
      if ( response.languages.length > 0) {
        for (let i = 0; i < this.configFile.languages.length ; i++) {
          for ( let j = 0; j < response.languages.length ; j++) {
            if (this.configFile.languages[i].id === response.languages[j]) {
              this.gAlanguages.push(this.configFile.languages[i].name);
              this.string1 = this.gAlanguages.join();
            }
          }
        }
      } else {
        this.string1 = '';
      }
       if (response.asset_type === 9 && response.genres.findIndex(i => i.id === 'News') !== -1) {
            this.moreNews(response);
       }
       if ( this.channelGenres.length > 0) {
        x.v1ChannelGet('channel_number', undefined, undefined, undefined, this.string2, undefined, this.contentLanguages, this.countryCode).timeout(environment.timeOut).takeUntil(this.ngUnsubscribe).subscribe(val => {
          let a;
          if ( val.items) {
            for (a = 0 ; a < val.items.length ; a++ ) {
              if ( val.items[a].id !== this.id) {
                this.similar = true;
                this.similarContent.push(val.items[a]);
              }
            }
            if (response.asset_type === 9 && response.genres.findIndex(i => i.id === 'News') !== -1) {
                this.similarChannels = {'content': this.similarContent , 'title': 'SUSCRIPTION.NEWS_CHANNELS'};
             } else {
                this.similarChannels = {'content': this.similarContent , 'title': 'SUSCRIPTION.SIMILAR_CHANNELS'};
             }
             this.getYIndex();
           }
        });
       }

       if ( response) {
         let tempTitle1;
        this.noInformation = true;
        this.name = response.title;
        this.engilshName = response.original_title;
        this.pageName = this.string1 + '|Channel|' + this.string + '|' + this.engilshName;
        this.gtm.sendTvChannel(this.engilshName);
        this.gtm.sendPageName(this.pageName);
        this.gtm.sendEvent();
        if (response && response.extended && response.extended.seo_title) {
            tempTitle1 = (response.extended.seo_title !== null || response.extended.seo_title !== undefined || response.extended.seo_title !== '') ? response.extended.seo_title : response.original_title;
          } else {
            tempTitle1 = (response.seo_title && (response.seo_title !== null || response.seo_title !== undefined || response.seo_title !== '')) ? response.seo_title : response.original_title;
          }
        // this.seoService.channelPage(this.commonService.convertToLowercase(tempTitle1), this.string1, this.string2);
        this.seoService.channelPage(tempTitle1, this.string1, this.string2);

       /* Check Broadcast rights */
        if (response.broadcast_state) {
          if (response.broadcast_state === '' || response.broadcast_state === 'ON-AIR') {
            this.ifRights = true;
          } else if (response.broadcast_state === 'ARCHIVE') {
            this.ifRights = false;
          } else {
            this.ifRights = true;
          }
        } else {
          this.ifRights = true;
        }
        if (this.ifRights === true) {
          let width;
          width = $('.bannerinner').width();
          this.playerHeight = width * 9 / 16 ;
          this.streamDash = response.stream_url;
          this.streamHls = response.stream_url_hls;
          let p;
          p = new EpgApi(this.http, null, null);
          p.v1EpgNowGet([this.id], undefined, undefined, undefined, this.countryCode).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe( value => {
           this.fetchDataNow(value, response);
           this.data = value;
          if ( response.stream_url || response.stream_url_hls) {
            this.showLogin = true;
            this.nowPlaying = true;
          } else {
            this.showLogin = false;
          }

          this.videoObject(value, response);
          this.adApiCall(response);
          this.startVideo(response);
          },
          err => { $('#loaderPage').css('display', 'none');
                   this.gtm.sendErrorEvent('api', err);
                  }
         );
        } else if (this.ifRights === false || this.ifRights === undefined) {
          this.ifRights = false;
          $('#loaderPage').css('display', 'none');
        }
      }

      // this.fetchData(response);
      this.setRelatedData(response);

      scope = this;
      this.window.onpopstate = function() {
        if ( scope.modalVideoPopup === true) {
        scope.closeVideo('event');
        }
      };
    },
    error =>  {
      if (error.status === 404) {
        this.customPage = true;
      } else {
        $('#loaderPage').css('display', 'none');
        this.pageName = 'channels/details';
        this.gtm.sendPageName(this.pageName);
        this.gtm.sendEvent();
        this.related = false;
        this.similar = false;
        this.ifRights = false;
        this.featured = false;
        this.nowPlaying = false;
        this.nextPlaying = false;
        this.showUpNextEmpty = true;
        this.gtm.sendErrorEvent('api', error);
      }
      this.headerservicesService.breadCrump('');
    });
  }

  private startVideo(response): any {
    if ( this.data && this.loginToken && this.premium.indexOf('premium') !== -1) {
        this.assetTypes = this.subscriptionService.checkPlanApiSuccess(true);
        this.showSubPopUp = this.subscriptionService.getPlanApiSucess();
        let hasLanguage;
        hasLanguage = this.subscriptionService.checkAssetLang('9', response.languages);
        if ( this.showSubPopUp !== undefined) {
          if ( this.assetTypes.length > 0 ) {
          let subscriptionIndex;
          for (subscriptionIndex = 0; subscriptionIndex < this.assetTypes.length; subscriptionIndex++) {
            if (this.assetTypes[subscriptionIndex] === '9' && hasLanguage) {
               this.subscription = true;
            }
          }
          if ( this.subscription === true) {
            $('#loaderPage').css('display', 'none');
            if ( !this.castVisibility) {
              this.video = true;
              if (this.document.getElementById('playImage')) {
                this.document.getElementById('playImage').style.display = 'none';
              }
              $('#noAccess').hide();
            }
          } else {
            $('#loaderPage').css('display', 'none');
            $('#noAccess').hide();
            $('#noAccessSubs').hide();
            this.video = false;
            if (this.document.getElementById('playImage')) {
            this.document.getElementById('playImage').style.display = 'block';
            }
            if (this.assetTypes.indexOf('9') > -1 && !hasLanguage) {
              $('#loaderPage').css('display', 'none');
              setTimeout(() => {
                $('#noAccessSubs').show();
                $('#noAccess').hide();
                $('#playImage').hide();
              }, 0);
              // alert('show upgrade popup');
              this.showGetPremium = true;
              // this.headerservicesService.callUpgradePopup(true);
              this.headerservicesService.subscribeReminderChange(true);

            } else {
               this.showGetPremium = true;
              this.headerservicesService.subscribeReminderChange(true);
            }
          }
        } else {
           $('#loaderPage').css('display', 'none');
           $('#noAccessSubs').show();
           $('#noAccess').hide();
           this.showGetPremium = true;
           this.headerservicesService.subscribeReminderChange(true);
        }
        } else {
           $('#loaderPage').css('display', 'none');
        }
    } else if (this.showLogin === false) {
      if ( !this.castVisibility) {
          this.video = true;
          if (this.document.getElementById('playImage')) {
          this.document.getElementById('playImage').style.display = 'none';
          }
      }
      $('#noAccess').hide();
      this.headerservicesService.signReminderChange(false);
    } else if (this.premium.indexOf('premium') === -1) {
      if ( !this.castVisibility) {
          this.video = true;
          if (this.document.getElementById('playImage')) {
            this.document.getElementById('playImage').style.display = 'none';
          }
        }
      $('#noAccess').hide();
      $('#noAccessSubs').hide();
    } else {
      this.showGetPremium = true;
      this.headerservicesService.signReminderChange(true);
    }
  }

  private adApiCall(response): void {
   let userType, adResponse, countyCode, countryValue, adApiTimeoutValue;
   userType = this.commonService.getUserType();
   countyCode = this.settingsService.getCountry();
   countryValue = this.settingsService.getCountryValueNew();
   if (countyCode !== 'IN') {
     adApiTimeoutValue = countryValue && countryValue[0] && countryValue[0].video_ads_api_timeout ? countryValue[0].video_ads_api_timeout : environment.adApiTimeOut;
   } else {
     adApiTimeoutValue = environment.adApiTimeOut;
   }
    this.videoService.getAdData(this.id, 'live').takeUntil(this.ngUnsubscribe).timeout(adApiTimeoutValue).subscribe(value => {
      if (value && value._body) {
        try {
          adResponse = JSON.parse(value._body);
          if (adResponse.video_ads && adResponse.video_ads[0]) {
            this.videoAdData = {
              'type': adResponse.video_ads[0].type,
              'intervals': adResponse.video_ads[0].intervals,
              'ads_visibility': adResponse.video_ads[0].ads_visibility
            };
          } else {
            this.videoAdData = {};
          }
        } catch (error) {
          this.videoAdData = {};
        }
      } else {
        this.videoAdData = {};
      }
      // this.startVideo(response);
    }, err => {
      this.videoAdData = {};
      this.gtm.sendErrorEvent('api', err);
      // this.startVideo(response);
    });
 }

  public moreNews(newsData) {
    if (!newsData.id) {
      return;
    }
    let config;
    config = {
    apiKey: ' ',
    username: ' ',
    password: ' ',
    accessToken: ' ',
    withCredentials: false
    };
    let x, pageNo, itemLimit, channel_name, userType;
    x = new CollectionApi(this.http, null, config);
    pageNo = 1;
    itemLimit = 25;
    channel_name = newsData.title ? newsData.title : newsData.original_title;
    userType = this.commonService.getUserType();
    x.v1ChannelNewsCollectionByIdGet('live', newsData.id, pageNo, null, itemLimit, null, null, null, null, null, null, userType).timeout(environment.timeOut).takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.apiRetryCount = 1;
      let list, relatednews, morenews;
      value.buckets = this.commonService.removeWebView(value.buckets);
      if (value.buckets && value.buckets[0] && value.buckets[0].items && value.buckets[0].items.length) {
        relatednews = value.buckets[0];
        morenews = relatednews.items && relatednews.items.length > 0 ? relatednews.items : [];
        if (morenews.length > 0) {
          // list = {'title': 'MENU.MORE_FROM' , 'original_title': 'MENU.MORE_FROM', 'id': relatednews.id, 'type': 'videos', 'parentType': 'videos', 'link': 'videos', 'content': relatednews.items, 'original_length': relatednews.items.length, 'channel_name': channel_name};
          list = {'title': 'MENU.MORE_FROM' , 'original_title': 'MENU.MORE_FROM', 'id': relatednews.id, 'type': 'videos', 'parentType': 'moreinfo', 'link': 'videos', 'content': relatednews.items, 'original_length': 1, 'channel_name': channel_name, next_url: Math.ceil(relatednews.total / itemLimit), 'api_details': {'genre': null, 'content_owner': null, 'news_id': newsData.id}};
        }
        this.moreNewsData = list;
        this.getYIndex();
      }
    },
    err => {
      this.gtm.sendErrorEvent('api', err);
      if (err.status === 401 && this.apiRetryCount < this.apiRetry) {
        this.apiRetryCount ++;
        this.commonService.refreshToken().then(
          () => {
            this.moreNews(newsData);
          },
          // () => {},
          );
      }
    }
    );
  }
  /*Convert millisecs to hours+mins+secs */
  private updateLiveTime(s: number): any {
    let secs = (s / 1000) % 60;
    s = ((s / 1000) - secs) / 60;
    let mins;
    mins = s % 60;
    s = (s - mins) / 60;
    let hrs;
    hrs = s % 60;
    secs = Math.floor(secs);
    let hrsStr;
    hrsStr = hrs ? ((hrs < 10 ? '0' + hrs : hrs) + ':') : '';
    let time;
    if (this.displayLang === 'ru') {
                time = (hrs ? hrs + 'ч' : '') + ' ' + (mins ? mins + 'м' : '') + ' ' + (secs ? secs + 'с' : '');
                } else {
                time = (hrs ? hrs + 'h' : '') + ' ' + (mins ? mins + 'm' : '') + ' ' + (secs ? secs + 's' : '');
                }
    // time = (hrs ? hrs + 'h' : '') + ' ' + (mins ? mins + 'm' : '') + ' ' + (secs ? secs + 's' : '');
    return time;
  }

  private setRelatedData(value): any {
    if (value.related.length > 0) {
      this.featured = true;
      this.featuredShows = { 'title': 'SUSCRIPTION.RELATED_SHOWS', 'original_title': 'Related Shows', 'type' : 'tvshows', 'router': '/showdetails',
      'content': value.related };
      this.carouselTitle = {'title': 'RELATED', 'original_title': 'RELATED'};
      this.carousel = value.related.slice(0, 5);
      this.getYIndex();
    } else {
      this.featured = false;
    }
  }

private fetchData(value): any {
    let config;
    config = {
    apiKey: ' ',
    username: ' ',
    password: ' ',
    accessToken: ' ',
    withCredentials: false
    };
    let y, temp1, timeOffset, translation;
    // y = new api.EpgApi(this.http, null, config);
    y = new EpgApi(this.http, null, config);
    this.catalogbasepath = environment.catalogbasepath;
    timeOffset = encodeURIComponent(this.timeOffset);

    if (this.loginToken) {
      translation = this.localstorage.getItem('UserDisplayLanguage');
    } else {
      translation = this.localstorage.getItem('display_language');
    }
    temp1 = this.catalogbasepath + '/v1/epg?' + 'channels=' + this.id + '&' + 'start=0' + '&end=0' + '&time_offset=' + timeOffset + '&translation=' + translation + '&country=' + this.countryCode;
    this.epgService.getcurrentEpgData(temp1).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(val => {
      this.fetchUpNextData(val);
    }, err =>  {
      $('#loaderPage').css('display', 'none');
      this.nextPlaying = false;
      this.showUpNextEmpty = true;
    });
  }

  private fetchUpNextData(value): any {
    if (this.showLogin === false || (this.premium.indexOf('premium') === -1)) {
      $('#loaderPage').css('display', 'none');
    }
    if (!this.loginToken && !this.subscription) {
      $('#loaderPage').css('display', 'none');
    }
    this.upNextTwo = { 'title': 'DETAILS.UP_NEXT', 'type' : 'live', 'content': []};
    this.test = [];
    if ( value.items.length > 0) {
      if ( value.items[0].items.length > 0 && this.startTime !== undefined) {
        // this.UpNext = [{ 'type' : 'tvshows', 'content': value.items[0].items }]
        for ( let i = 0; i < value.items[0].items.length; i++) {
          if ( this.startTime < Date.parse(value.items[0].items[i].start_time)) {
            this.upNextTwo.content.push(value.items[0].items[i]);
            this.test.push(value.items[0].items[i]);
            this.nextPlaying = true;
          }
        }
        this.getYIndex();
      } else {
        $('#loaderPage').css('display', 'none');
        this.nextPlaying = false;
        this.showUpNextEmpty = true;
      }
    } else {
      $('#loaderPage').css('display', 'none');
      this.nextPlaying = false;
      this.showUpNextEmpty = true;
    }
  }

  private fetchDataNow(value, response): any {
    let y;
    // y = new api.ChannelApi(this.http, null, null);
    y = new ChannelApi(this.http, null, null);
     /*For GA genres */
     this.channelRelatedGenres = [];
     if ( value.items[0].items.length > 0) {
        if ( value.items[0].items[0].genres.length > 0) {
          for ( let i = 0; i < value.items[0].items[0].genres.length ; i++) {
            this.channelRelatedGenres.push(value.items[0].items[0].genres[i].id);
            this.relatedGenres = this.channelRelatedGenres.join();
          }
        } else {
         this.relatedGenres = '';
        }
       }

    if ( this.channelRelatedGenres.length > 0) {
      y.v1ChannelGet('channel_number', undefined, undefined, undefined, this.relatedGenres, undefined, this.contentLanguages, this.countryCode).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(val => {
        let a;
        if ( val.items) {
          for (a = 0 ; a < val.items.length ; a++ ) {
            if ( val.items[a].id !== this.id) {
              this.related = true;
              this.relatedContent.push(val.items[a]);
            }
          }
         this.relatedChannels = {'content': this.relatedContent , 'title': 'SUSCRIPTION.RELATED_CHANNELS'};
         this.getYIndex();
       }
      }, err => {
        $('#loaderPage').css('display', 'none');
        this.gtm.sendErrorEvent('api', err);
      });
    }
    let json_ld;
    if ( value.items[0].items.length > 0) {
      let starttime, endtime;
      starttime = '' + new Date(value.items[0].items[0].start_time);
      endtime = '' + new Date(value.items[0].items[0].end_time);

      json_ld = { '@context': 'http://schema.org',
                  '@type': 'BroadcastEvent',
                  'startDate': starttime,
                  'endDate': endtime,
                  'publishedOn': {
                  '@type': 'BroadcastService',
                  'name': this.engilshName
                },
                  'workPerformed': {
                  '@type': 'CreativeWork',
                  'name': value.items[0].items[0].original_title
                },
                  'inLanguage':  this.contentLanguages,
                  'videoFormat': 'HD',
                  'isLiveBroadcast': 'False',
                  'name': value.items[0].items[0].original_title,
                  'description': value.items[0].items[0].description
                };
                  this.clean(json_ld);
   } else {
      json_ld = { '@context': 'http://schema.org',
                  '@type': 'BroadcastEvent',
                  'publishedOn': {
                  '@type': 'BroadcastService',
                  'name': this.engilshName
                }
    };
      this.clean(json_ld);
    }

    let script;
    script = this.document.createElement('script');
    script.id = 'schema';
    script.type = 'application/ld+json';
    script.innerHTML = JSON.stringify(json_ld);
    if (this.document.getElementById('channeldetailsMarkup')) {
     this.document.getElementById('channeldetailsMarkup').appendChild(script);
    }

    // this.bannerplayer = [{'content': { 'title': 'N/A'}}];
    this.bannerplayer = {'content': { 'title': 'N/A'}};
    let width;
    width = $('.bannerinner').width();
    this.playerHeight = width * 9 / 16 ;
    if ( value.items[0].items.length > 0) {
      this.nowPlaying = true;
      if (value.items[0].items[0].list_image !== undefined || value.items[0].items[0].list_image !== null ) {
      this.bannerImage = this.basepath + this.coverName + '/cover/' + '170x120/' + this.coverImage;
      } else {
      this.bannerImage = '';
      }
      this.startTime = Date.parse(value.items[0].items[0].start_time);
      this.endTime = Date.parse(value.items[0].items[0].end_time);
      this.elapsed = (this.currentTime - this.startTime);
      this.remainingTime = (this.endTime - this.startTime - this.elapsed);
      this.fetchData(response);
      if (this.remainingTime > 0) {
        setTimeout(() => { this.callServerTime(); }, this.remainingTime);
      }
      this.bannerplayer =  {'content': {'title': value.items[0].items[0].title, 'duration': this.elapsed } };
    } else {
       $('#loaderPage').css('display', 'none');
      this.showUpNextEmpty = true;
      this.nextPlaying = false;
    }
  }

  private videoObject(value, response) {
     if ( value.items[0].items.length > 0) {
      let genres;
      genres = [];
      if (value.items[0].genres) {
        for ( let index = 0; index < value.items[0].genres.length; index++) {
          genres.push(value.items[0].genres[index].id);
        }
      }
      let genresdata;
      genresdata = genres.join(',');

      let show_title;
      let name;
      name = value.items[0].original_title;
      show_title = name.toLowerCase().replace(/ /g, '-');
      show_title = show_title.replace(/---/g, '-');
      show_title = show_title.replace(/,/g, '');

      this.data = [
      {
      id: value.items[0].items[0].id,
      duration: value.items[0].items[0].duration,
      subtitles: response.subtitle_languages,
      audio_languages: response.languages,
      stream_url_dash: response.stream_url,
      stream_url_hls: response.stream_url_hls,
      drm: response.is_drm,
      drm_keyid: response.drm_key_id ,
      type: 'live',
      title: value.items[0].items[0].title ,
      title_en : value.items[0].items[0].original_title,
      season_no: '',
      episode_no: '' ,
      episode_name: '',
      episode_name_en : '',
      channel_name: value.items[0].original_title,
      channel_id: value.items[0].id,
      category: 'Live TV' ,
      content_type: '',
      genre: genresdata,
      sub_genre: '' ,
      catch_up: 'N' ,
      series_id: value.items[0].items[0].vod_id ,
      rating: '',
      release_date: '',
      business_type: this.premium,
      description: value.items[0].items[0].description,
      image: value.items[0].items[0].list_image,
      elapsed_time: '',
      asset_type: value.items[0].items[0].asset_type,
      Favorite: '',
      WatchLater: '',
      share_url: 'channels/details/' + show_title + '/' + value.items[0].id,
      sub_category: ''
      }];
    } else {
      let show_title;
      let name1;
      name1 = response.original_title;
      show_title = name1.toLowerCase().replace(/ /g, '-');
      show_title = show_title.replace(/---/g, '-');
      show_title = show_title.replace(/,/g, '');

      let genres;
      genres = [];
      for ( let index = 0; index < value.items[0].genres.length; index++) {
        genres.push(value.items[0].genres[index].id);
      }
      let genresData;
      genresData = genres.join(',');

      this.data = [
      {
      id: '',
      duration: '',
      subtitles: response.subtitle_languages,
      audio_languages: response.languages,
      stream_url_dash: this.streamDash,
      stream_url_hls: this.streamHls,
      drm: response.is_drm,
      drm_keyid: response.drm_key_id ,
      type: 'live',
      title: '' ,
      title_en: '',
      season_no: '',
      episode_no: '' ,
      episode_name: '',
      episode_name_en: '',
      channel_name: response.original_title,
      channel_id: response.id,
      category: 'Live TV' ,
      content_type: '',
      genre: genresData,
      sub_genre: '' ,
      catch_up: 'N' ,
      series_id: '' ,
      rating: '',
      release_date: '',
      business_type: this.premium,
      description: '',
      image: '',
      elapsed_time: '',
      asset_type: response.asset_type,
      Favorite: '',
      WatchLater: '',
      share_url: 'channels/details/' + show_title + '/' + response.id,
      sub_category: ''
      }];
    }
  }

private clean(obj) {
  let propName;
    for (propName in obj) {
      if (obj[propName] === null || obj[propName] === undefined || obj[propName] === '') {
          delete obj[propName];
    }
  }
}

 /*Video for Static Player*/
  private startVideoLive = function(event) {
    this.gtm.GAsubCategory = 'NA';
    this.gtm.clearContentClickDetails();
    let y;
    // y = new api.ChannelApi(this.http, null, null);
    y = new ChannelApi(this.http, null, null);
    y.v1ChannelByIdGet(this.id, undefined, this.countryCode).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(response => {
      let premium;
      response.business_type = (response.business_type === undefined ? 'free' : response.business_type);
      premium = response.business_type;
      this.streamDash = response.stream_url;
      this.streamHls = response.stream_url_hls;
      if (this.streamDash || this.streamHls) {
        this.nowPlaying = true;
      }
      let x;
      x = new EpgApi(this.http, null, null);
      x.v1EpgNowGet([this.id], undefined, undefined, undefined, this.countryCode).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe( value => {

      this.data = value;
      this.videoObject(value, response);
      if ( this.castVisibility) {
        if (this.document.getElementById('playImage')) {
          this.document.getElementById('playImage').style.display = 'none';
        }
          this.videoService.castQueueObject = this.data;
          this.videoService.toggleQueueState(true);
          return;
      }
      if (this.loginToken) {
        this.assetTypes = this.subscriptionService.checkPlanApiSuccess(true);
        this.showSubPopUp = this.subscriptionService.getPlanApiSucess();

        if (this.showSubPopUp !== undefined) {
          this.video = true;
          if (this.document.getElementById('playImage')) {
            this.document.getElementById('playImage').style.display = 'none';
          }
        }
      }

      if ( this.premium.indexOf('premium') === -1) {
        this.video = true;
        if (this.document.getElementById('playImage')) {
          this.document.getElementById('playImage').style.display = 'none';
        }
      }
      },
      err => {
        $('#loaderPage').css('display', 'none');
        this.gtm.sendErrorEvent('api', err);
      }
     );
    });
  };

  private closeVideo = function (event) {
    let name;
    name = this.name.toLowerCase().replace(/ /g, '-');
    this.location.replaceState('channel/' + name + '/' + this.id);
    this.modalVideoPopup = false;
    this.document.getElementById('body').classList.remove('modal-open');
  };

  private closeReminder = function(event) {
    this.showSignUpPromt = false;
  };

  // Channel ADs
  private getBannerDetails() {
    this.settingsService.getBanner(this.id).takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.orginalBannerData = value;
      this.getYIndex();
    }, error => {
      this.errorMessage = error;
    });
  }

  public getYIndex(): any {
    let index;
    index = -1;
    this.yIndex = [-1, -1, -1, -1, -1, -1];
    /* up-next, related shows, banners, similar channels, related channels, more news*/
    if (this.upNextTwo && this.upNextTwo.content && this.upNextTwo.content.length > 0) {
      this.yIndex[0] = ++index;
    }
    if (this.featuredShows && this.featuredShows.content && this.featuredShows.content.length > 0) {
      this.yIndex[1] = ++index;
    }
    if (this.orginalBannerData && this.orginalBannerData.length > 0) {
      this.yIndex[2] = ++index;
    }
    if (this.similarChannels && this.similarChannels.content && this.similarChannels.content.length > 0) {
      this.yIndex[3] = ++index;
    }
    if (this.relatedChannels && this.relatedChannels.content && this.relatedChannels.content.length > 0) {
      this.yIndex[4] = ++index;
    }
    if (this.moreNewsData && this.moreNewsData.content && this.moreNewsData.content.length > 0) {
      this.yIndex[5] = ++index;
    }
    // console.log(this.yIndex);
  }

  public mygpSubscriptionroute(): any {
    this.headerservicesService.MygpSubscriptionroute();
  }

  public ngOnDestroy() {
    this.getServerTime.unsubscribe();
    this.gtm.sendTvChannel('');
    this.headerservicesService.premium = false;
    this.videoService.instance = 0;
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }
}

