import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared.module';
import { ChannelDetailsComponent } from './channel-details.component';
import { VideoModule } from '../video/video.module';
import { ScrollListModule } from '../scroll-list/scroll-list.module';
import { ScrollGridModule } from '../scroll-grid/scroll-grid.module';
import { ScrollListChannelComponent } from './scroll-list-channel/scroll-list-channel.component';
import { ScrollListBannersComponent } from './scroll-list-banners/scroll-list-banners.component';
import { ReminderSignupModule } from '../reminder-signup/reminder-signup.module';
import { CarouselModule } from '../carousel/carousel.module';
import { DataUnavailableModule } from '../data-unavailable/data-unavailable.module';
import { CustomErrorScreenModule } from '../custom-error-screen/custom-error-screen.module';
import { PremiumTabModule } from '../premium-tab/premium-tab.module';
const routes: Routes = [
    {
        path: ':name/:id',
        component: ChannelDetailsComponent,
    },
];
@NgModule({
 exports: [RouterModule],
  imports: [RouterModule.forChild(routes), CommonModule, SharedModule, VideoModule, ScrollGridModule, ReminderSignupModule,
   CarouselModule, DataUnavailableModule, ScrollListModule, CustomErrorScreenModule, PremiumTabModule],
  declarations: [ChannelDetailsComponent, ScrollListChannelComponent, ScrollListBannersComponent]
})
export class ChannelDetailsModule {
}
