import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TvguideComponent } from './tvguide.component';

describe('TvguideComponent', () => {
  let component: TvguideComponent;
  let fixture: ComponentFixture<TvguideComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TvguideComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TvguideComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
