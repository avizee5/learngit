import { Component, OnInit , HostListener, ViewChild, ElementRef, OnDestroy, Inject, PLATFORM_ID } from '@angular/core';
import { EpgService } from '../services/epg.service';
import { FilterService } from '../services/filter.service';
import { Subscription } from 'rxjs/Subscription';
import * as $ from 'jquery';
import {Observable} from 'rxjs/Rx';
import { HeaderservicesService } from '../services/headerservices.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Http} from '@angular/http';
// import * as api from '../../data/catalog/api/api';
import { ChannelApi } from '../../data/catalog/api/ChannelApi';
// import { DateFilterPipe } from '../custom-filters/date-filter.pipe';
import { environment } from '../../environments/environment';
import { Subject } from 'rxjs/Subject';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import {  NetworkService  } from '../services/network.service';
import { RouteService } from '../services/route.service';
import { VideoService } from '../services/video.service';
import { Location } from '@angular/common';
import { SeoService } from '../services/seo.service';
import { SubscriptionService } from '../services/subscription.service';
import { isPlatformBrowser } from '@angular/common';
import { LinkService } from '../services/link.service';
import { SettingsService } from '../services/settings.service';
import {TranslateService} from '@ngx-translate/core';
import { CommonService } from '../services/common.service';
declare let googletag;

@Component({
  selector: 'app-tvguide',
  templateUrl: './tvguide.component.html',
  styleUrls: ['./tvguide.component.less']
})
export class TvguideComponent implements OnInit, OnDestroy  {
  private loading = false;
  private event: any;
  public toastMsg: any;
  private channelId;
  private margintop;
  private marginbottom;
  private sortedarrayheight = 0;
  private infi_pageSize = 10;
  private scrolLeft = 0;
  private assetbasepath: any;
  private uparrow: any;
  private downarrow: any;
  private clickedletter = false;
  private channelContainerHeight: any;
  private lastScrollTop = 0;
  private pageloaddec: number;
  private pageloaded: boolean;
  private dataIndexes: Array<any> = [];
  private scrollValues: Array<any> = [];
  private apiepgDataload: Array<any> = [];
  private prevUi: string;
  private clicked = false;
  private serverTime: any;
  private slot = false;
  private isPreviousEventComplete = true;
  private translation: any;
  private checknext = false;
  private currentTime: any;
  private timeOffset: any;
  public empty = false;
  private selecteddate: any;
  private tooglesort = false;
  private visibleCount: number;
  private epgIndex: number;
  private languages: any;
  private genre: Array<any> = [];
  private unsortedData: any;
  private basepath: any;
  private affix: boolean;
  private errorMessage: any;
  private sorted_channels: any;
  private prevDay_index = -1;
  private loaded: boolean;
  private dayindex_epg: number;
  private pageSize: any;
  private pageload = 1;
  private currTime_index: any;
  public error: boolean;
  private prev_array = -1;
  private top: any;
  private blockWidth: any;
  private filterFlag = false;
  private title: any;
  public filter_titles: any;
  public filterbar = false;
  public sortbar = false;
  private totalData: any;
  private selec;
  private alphabet: boolean;
  private arr_time: any;
  private timecount: number;
  private dayindex = 7;
  private min: any;
  private h: any;
  private k: any;
  private dates: any = [];
  private movecount = 0;
  private timeslotWidth: any;
  private timeslotWidthScroll: any;
  private firstIndex = 0;
  private reloadFlag = false;
  private modalstatus = false;
  private selectedFilters: any;
  private selectedoptionsHeight = 86;
  private tvguideHeight: any;
  private timebarHeight: any;
  private tvguideHeaderHeight: any;
  private epgsectionHeight: any;
  private totalHeight: any;
  private containerHeight: any;
  public epgLayout = true;
  private offsettop: any;
  private className: any;
  private pointer = true;
  private row_no: number;
  private show: boolean;
  private prev_row = -1;
  private ui: any;
  private prev_sendrow: number;
  private newcontainerHeight = 0;
  private idx: number;
  private router: any;
  private router2: any;
  private alphabets: any;
  private prevSelectedLetter: any;
  private slotHeight = 0;
  private sortedarray: Array<any> = [];
  private selectedAlphabets: Array<any> = [];
  private temp: Array<any> = [];
  private timer: Subscription;
  private array_no: any ;
  private headerMenuheight: any;
  public view = 'livetv';
  public apiepgData: Array<any> = [];
  private apiepgDataDuplicate: Array<any> = [];
  private touchScreen: boolean;
  private selectedDay: any;
  private toggle_div: boolean;
  private timescroll = false;
  private datascroll = false;
  private dayWidth: any;
  private daycount = 7;
  private timeBarWidth: any;
  private channelData: Array<any>;
  private currentShow: boolean;
  private channel_pages = 0;
  private waiting: any;
  private channel_ids: any;
  private channel_titles: any;
  private prevValue: boolean;
  private changeContent: boolean;
  private slotHeight1 = 0;
  private heightflag = false;
  private divTop = 0;
  private setchangeContent: boolean;
  private pageName: any;
  private window: any;
  private document: any;
  private navigator: any;
  private searchBar: false;
  private country_code: any;
  private ngUnsubscribe = new Subject<any>();
  private queryChnl: any;
  private queryShwAll: any;
  private queryFlag: any = false;
  public nativeTag: any;
  @ViewChild('scrolltime') private myScrollContainer: ElementRef;
  @ViewChild('scrolldata') private myScrollContainer1: ElementRef;
  constructor(private linkservice: LinkService, @Inject(PLATFORM_ID) private platformId: Object, private commonService: CommonService, private settings: SettingsService, private sub: SubscriptionService, private seoService: SeoService, private location: Location, private videoService: VideoService, private networkService: NetworkService, private gtm: GoogleAnalyticsService, private routeservice: RouteService, private epgService: EpgService, private filterService: FilterService, private headerservicesService: HeaderservicesService, private routerVal: Router, private http: Http, private route: ActivatedRoute, private translate: TranslateService) {
    if (isPlatformBrowser(this.platformId)) {
        this.window = window;
        this.document = document;
        this.navigator = navigator;
    }
    this.router = routerVal;
    this.routeservice.setLoginRoute(this.window.location.pathname);
    this.router2 = this.router.url;
    this.headerservicesService.viewChange(this.router2);
    this.routeservice.setRoute(this.router2);
    // on click of filter / sort button reinitializing the slotheight
    this.filterService.contentObservable.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.slotHeight = value;
      this.setchangeContent = true;
      if (this.alphabet) {
        this.slotHeight = this.slotHeight - 120;
      }
    });
    // timer function
    this.timer = Observable.interval(60000).subscribe(x => {
      if (this.loaded) {
        this.doSomething();
      }
    });
    // on click of searchicon close the slots
        this.headerservicesService.searchValue.takeUntil(this.ngUnsubscribe).subscribe(value => {
          this.searchBar = value;
          if (this.searchBar) {
          this.epgService.loaded(false);
        }
});
        //  To disable scroll if player is in full screen mode
        this.epgService.disableScroll.takeUntil(this.ngUnsubscribe).subscribe(value => {
          let val;
          val = value;
          if (!val) {
          this.clickedletter = true;
           setTimeout(() => {
                      this.clickedletter = value;
          }, 2000);
          } else {

                      this.clickedletter = value;
          }
    });
    // Changes in filter selection
    this.filterService.configObservable.takeUntil(this.ngUnsubscribe).subscribe(value => {
      if (this.networkService.getScreenStatus()) {
        if(window.location.search.indexOf('channel=') < 0){
          this.sortedarray = [];
          this.selectedFilters = value;
          if (this.selectedFilters.length >= 0 && this.loaded) {
            $('#loaderPage').css('display', 'block');
            this.fetchChannels();
          }
        }
      } else {
        this.filterbar = false;
      }
    });
    // on click of footer go to top icon
    this.sub.click.takeUntil(this.ngUnsubscribe).subscribe(value => {
                             setTimeout(() => {
                               this.setview();
      }, 400);
    });
    // any change in sort overlay
    this.filterService.configSortObservable.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.sortedarray = [];
      let network;
      network = this.networkService.getScreenStatus();
      if (network) {
        $('#loaderPage').css('display', 'block');
        this.getSort(value);
      } else {
        this.sortbar = false;
      }
    });
    // on click of any program
    this.epgService.CHECK.takeUntil(this.ngUnsubscribe).subscribe(value => {
      if (this.videoService.enableCastView) {
            if (value[0].ui === 'next') {
                            this.openSlot(value[0]);
            } else {
              this.send(false);
            }
            } else {
                            this.openSlot(value[0]);
                            this.clickedletter = true;
                             setTimeout(() => {
                                        this.clickedletter = false;
                            }, 1000);
            }
    });
    // check for next day live when started playback from previous day
    this.epgService.livecheck.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.checknext = value;
    });
  }
  // move the slot for every 30 mts
  private goNext(): void {
    if (this.dayindex === 7 && this.loaded) {
      let curr_time;
      curr_time = this.currtimeIndex();
      this.currTime_index = this.arr_time.indexOf(curr_time);
    }
    if (this.movecount < (this.timecount - this.visibleCount) && this.timecount > this.visibleCount && this.loaded) {
      this.movecount++;
      this.scrolLeft =  $('#slide-wrap')[0].scrollLeft + this.timeslotWidthScroll;
      $('#slide-wrap').animate({scrollLeft: '+=' + this.timeslotWidthScroll + 'px'}, 0);
      $('.epgProgramColumn').animate({scrollLeft: '+=' + (this.timeslotWidthScroll) + 'px'}, 0);
    }
  }
  // to get the current offset value (one of the apg api parameter)
  private getOffset(): void {
    let offset, o;
    offset = new Date().getTimezoneOffset(), o = Math.abs(offset);
    this.timeOffset = (offset < 0 ? '+' : '-') + ('00' + Math.floor(o / 60)).slice(-2) + ':' + ('00' + (o % 60)).slice(-2);
    offset = 0, o = Math.abs(offset);
  }
  // if genre length is 0 fire genre api then fire channels api
  private startApicall(): void {
     this.genre = this.filterService.getSelectedGenre();
     if (this.genre.length > 0) {
               this.fetchChannels();
     } else {
         let z, country_code;
        // z = new api.ChannelApi(this.http, null, null);
        z = new ChannelApi(this.http, null, null);
        country_code = this.settings.getCountry();
        z.v1ChannelByIdGet('genres', undefined, country_code, undefined).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
          let data, channelsGenre;
         data = value;
         if (data.genres) {
            channelsGenre = this.filterService.getIds(data.genres);
           this.filterService.setChannelsGenre(data.genres);
           this.genre = this.filterService.getSelectedGenre();
           this.fetchChannels();
         } else {
                       this.fetchChannels();
         }
    }, error => {
               this.fetchChannels();
      this.gtm.sendErrorEvent('api', error);
    });
     }
  }
  // To get the currrent time from API
  private getServerTime(): void {
    let url, time, data;
    url = environment.serverTimeUrl;
    time = null;
    this.epgService.getcurrentTime(url).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
     data = value.serverdate;
      if (data !== null) {
        this.serverTime = new Date(data).getTime();
        this.getDate();
        this.currentTime = new Date(this.serverTime).toISOString();
        this.startApicall();
      } else {
        this.serverTime = new Date().getTime();
        this.getDate();
        this.currentTime = new Date(this.serverTime).toISOString();
        this.startApicall();
      }
    }, error => {
      this.serverTime = new Date().getTime();
      this.getDate();
      this.currentTime = new Date(this.serverTime).toISOString();
      this.fetchChannels();

    });
  }
  // to set the view with proper data while on click of go to top icon in footer/on press of home key
  private setview(): void {
    this.loading = false;
    let scope;
     scope = this;
        if (scope.dataIndexes.length >= 3) {
              scope.clickedletter = true;
            scope.pageload = 3;
            scope.apiepgData =  scope.apiepgDataload.slice(0, scope.dataIndexes[(scope.pageload - 1)]);
           if (scope.alphabet) {
              scope.groupArray(scope.apiepgData, true);
            }
            $('.epgSection').css('margin-top', '0px');
                       setTimeout(() => {
                         scope.clickedletter = false;
             }, 0);
          }
  }
  public ngOnInit() {
    this.settings.bluekaiPagename('tvguide');
    let breadCrumbArray, top;
    breadCrumbArray = [{'label': 'BREADCRUMB.HOME', 'url': '/', 'enable': true}, {'label': 'BREADCRUMB.TVGUIDE', 'url': '/tvguide', 'enable': false}];
    this.headerservicesService.breadCrump(breadCrumbArray);
    $('#loaderPage').css('display', 'block');
    let network, scope;
    this.gtm.storeWindowError();
    this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'tvguide'  } );
    network = this.networkService.getScreenStatus();
    if (network) {
      this.assetbasepath = environment.assetsBasePath;
      this.epgService.clearchannels();
      this.getServerTime();
      this.getOffset();
      this.pageName = 'tv guide';
      this.gtm.sendPageName(this.pageName);
      this.gtm.sendEvent();
      scope = this;
      this.translation = this.filterService.gettranslation();
      $(this.document).keydown(function(e) {
        if (e.which === 32 || e.which === 9) {
          if (scope.show && scope.window.location.pathname === '/tvguide') {
              e.preventDefault();
          }
         } else if (e.which === 36) {
          scope.setview();
        }
        });
      this.basepath = environment.catalogbasepath;
      if (this.window.innerHeight >= 1000) {
        this.heightflag = true;
        this.divTop = 150;
      }
      this.title = 'TV Guide';
      this.filter_titles = [{'code': '2', 'name': 'DETAILS.GENRE'}, {'code': '1', 'name': 'COMMON.LANGUAGE'}];
      this.firstIndex = 1;
      if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i) || this.window.innerWidth <= 768) {
        this.touchScreen = true;
       }
             top = this.touchScreen ? 90 : 100;
           $('#breadcrumInit').css('top', top + 'px');
        this.uparrow = this.assetbasepath + 'assets/common/uparrow_icon.png';
        this.downarrow = this.assetbasepath + 'assets/common/downarrow_icon.png';
      $(this.document).mouseup(function(e) {
        if (e.target.id !== 'dropdowndiv' && !$('#dropdowndiv').find(e.target).length) {
          if (scope.toggle_div === true) {
            scope.closeDropdown();
          }
        }
      });
      $(this.document).keypress(function (e) {
         if (scope.window.location.pathname === '/tvguide' && !$('.modal') ) {
              e.preventDefault();
          }
      });
            this.alphabets = ['&', '0-9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
    }
  }
  // to fetch all the channels
  private fetchChannels(): void {
    this.pageloaddec = -1;
    this.dataIndexes = [];
    this.scrollValues = [];
    this.pageloaded = false;
        this.pageload = 1;
    let sort, config, data, data1, x, i, sort_order;
    this.channelData = [];
    if(window.location.search.indexOf('channel=') >= 0 && this.settings.getCountry() !== 'IN'){
      this.route.queryParams.subscribe(queryparams => {
        this.queryChnl = queryparams ['channel'].split(',');
        this.queryShwAll = queryparams ['show_all'];
        if(this.queryChnl){
          this.queryFlag = true;
          if(this.queryShwAll == "0"){
            // this.querySrtFlg = false;
            $("app-selected-options").hide();
          }
        }
      });
    }
    else{
      this.queryFlag = false;
      // this.querySrtFlg = true;
    }
    sort = (this.alphabet ? 'original_title' : 'channel_number');
    sort_order = (this.alphabet ? 'ASC' : null);
    if(!this.queryFlag){
      this.languages = this.filterService.getSelectedLanguage();
      this.genre = this.filterService.getSelectedGenre();
    }
    $('.epgSection').css('margin-top', '0px');
    config = {
      apiKey: ' ',
      username: ' ',
      password: ' ',
      accessToken: ' ',
      withCredentials: false
    };
    this.loading = false;
    this.selectedAlphabets = [];
    this.country_code = this.settings.getCountry();
    // x = new api.ChannelApi(this.http, null, config);
    x = new ChannelApi(this.http, null, config);
    
    x.v1ChannelGet(sort, sort_order, this.pageload, 100, this.genre, null, this.languages, this.country_code).takeUntil(this.ngUnsubscribe).subscribe(value => {
       data = value;
      this.channelData = data.items;
      // ids for epg api call
      this.unsortedData = this.getChannelDetails('id', this.channelData);
      if(this.queryFlag){
        if(this.queryShwAll == "0"){
          this.unsortedData = [];
          this.unsortedData = this.queryChnl;
        }
        else{
          this.queryChnl.forEach(element => {
            var pos = this.unsortedData.indexOf(element);
            if (pos !== -1) this.unsortedData.splice(pos, 1)
          });
          this.unsortedData = this.queryChnl.concat(this.unsortedData);
        }
      }
      this.pageSize = (Math.ceil(value.total / 10)) - 1;
      this.channel_pages = Math.ceil(value.total / value.page_size);
      this.waiting = this.channel_pages;
      this.error = false;
      if(!this.queryFlag){
        this.send(false);
      }
      else{
        this.send(false,window.location.search);
      }
      this.prev_row = -1;
      // to set the day for epg api
      this.epgIndex = (this.prevDay_index >= 0 ? this.prevDay_index : 7);
      // if there is only one page data
      if (this.channel_pages === 1) {
        this.empty = false;
        this.selectDay(this.epgIndex, false);
        this.getEPGData();
      } else if (this.channel_pages === 0 || value.total === 0) {   // if there is no data set empty state -> no data available
        this.sorted_channels = [];
        $('#loaderPage').css('display', 'none');
        this.empty = true;
        this.emptystate();
      }
      // more than one page in channels get api
      i = 2;
      while (i <= this.channel_pages) {
        this.empty = false;
        x.v1ChannelGet(sort, sort_order, i, 100, this.genre, null, this.languages, this.country_code).takeUntil(this.ngUnsubscribe).subscribe(value1 => {
          data1 = value1;
          this.channelData = this.channelData.concat(data1.items);
          this.finish();
        });
        i++;

      }
    }, error => {
      $('#loaderPage').css('display', 'none');
      this.error = true;
      this.gtm.sendErrorEvent('api', error);
    });
  }
  // if there is no data from channels api
  private emptystate(): void {
    $('#loaderPage').css('display', 'none');
    if (!this.loaded) {
       this.fetchData();
     }
    this.empty = true;
  }
  // To check whether all the pages of channela api firing is done or not
  private finish() {
    this.waiting--;
    if (this.waiting === 1) {
      this.unsortedData = this.getChannelDetails('id', this.channelData);
      if(this.queryShwAll == "0"){
        this.unsortedData = [];
        this.unsortedData.push(this.queryChnl);
      }
      else{
        var pos = this.unsortedData.indexOf(this.queryChnl);
        if (pos !== -1) this.unsortedData.splice(pos, 1)
        this.unsortedData.unshift(this.queryChnl);
      }
      this.selectDay(this.epgIndex, false);
      this.getEPGData();
    }
  }
  // to remove the channel if the items node is empty
  private nodataFilter(myArray): any {
    myArray = myArray.filter(function( obj ) {
      return obj.items.length > 0;
    });
    return myArray;
  }
  // epg api firing
  private getEPGData(): void {
    let data, temp, temp1, data1, myArray;
    this.channel_ids = this.unsortedData;
    this.checknext = false;
            this.empty = false;
    data = this.channelData;
    this.selectedAlphabets = [];
    this.setalphabets(data);
     if ((this.channel_ids && this.channel_ids.length > 0)) {
       // forming the url for api call with required parameters
       temp = this.epgService.formatData(this.channel_ids.slice(0,  this.infi_pageSize), this.timeOffset, this.dayindex_epg, this.translation, 25);
       temp1 = this.basepath + '/v1/epg?' + temp;
       this.epgService.getcurrentEpgData(temp1).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
         data1 = value;
         myArray = data1.items;
         this.window.scrollTo(0, 0);
         this.apiepgDataDuplicate = myArray;
         // removing the empty items channel
         this.apiepgData = this.nodataFilter(myArray);
         this.apiepgDataload =    this.apiepgData;
             this.setAd();
         this.dataIndexes.push(this.apiepgDataload.length);
         if (this.apiepgData.length > 0) {
         if (this.alphabet) {
           this.groupArray(this.apiepgData, true);
         }
         // first time dom gets loaded
         if (!this.loaded) {
           this.fetchData();
         } else {
           setTimeout(() => {
             $('#loaderPage').css('display', 'none');
             /// if it is currentday
             if (this.dayindex === 7) {
               this.starttime();
             }
             if (this.tooglesort) {
               if (this.dayindex === 7) {
                 // do nothing
               } else {
                 $('#slide-wrap').scrollLeft(0);
                 this.movecount = 0;
               }
             }
             // if (this.selectedFilters.length === 0) {
             //   this.top = (($('#timeBar').offset().top) - 2) || 200;
             //  }
             this.tooglesort = false;
             this.getContainerHeight();
           }, 0);
         }
       } else {
            this.emptystate();
       }
       }, error => {this.errorMessage = error;
         $('#loaderPage').css('display', 'none');
         this.error = true;
         this.gtm.sendErrorEvent('api', error);
       });
     } else {
          this.emptystate();
     }
   }
   // return only ids
   private getChannelDetails(prop: string, arr: any): any {
     return arr.map(function(a) {return a[prop]; });
   }
   private selectLetter(i, sel_letter): void {
     let index = -1, index1 = [], letter, charCodeZero, charCodeNine, top, lastItem, val;
     top = 0;
     letter = sel_letter;
     // find the index of which channel original title first letter is having slected letter
           index = this.apiepgDataDuplicate.findIndex(x => x.original_title.charAt(0).toUpperCase() === letter);
           // if the selected letter index is 1 compare it with charcode(0-9) and take the indexvalue
           if (i === 1) {
             charCodeZero = '0'.charCodeAt(0);
              charCodeNine = '9'.charCodeAt(0);
                index =   this.apiepgDataDuplicate.findIndex(x => x.original_title.charCodeAt(0) >= charCodeZero && x.original_title.charCodeAt(0) <= charCodeNine );
           }
     if ( $('#letter' + i).hasClass('selected') && i !== this.prevSelectedLetter) {
       if ( $('.alphabet').hasClass('affix')) {
         // if the channel is available in array scroll till that channel
         if (index >= 0) {
           $('#tvguideData').css('margin-top', '');
            this.clicked = true;
            val = 272 + 16 + 30;
            this.scrollPage(val, i, sel_letter);
         } else {            // if the index is not available find the index from channels data and fire the epg api till that index to get the data
           index1 = this.getAllIndexes(this.channelData, letter);
           lastItem = index1[0];
           if (lastItem >= 0 && lastItem > this.apiepgData.length) {
              top = 310;
             if (this.prevSelectedLetter === undefined) {
               top = 240;
             }
                      this.isPreviousEventComplete = false;
                      this.autoload(lastItem, top, i, sel_letter);
                      $('#tvguideData').css('margin-top', '');

                    }
                  }
                } else {
                  if (index >= 0) {
                     top = 290;
                    $('#tvguideData').css('margin-top', '');
                    if (this.prevSelectedLetter === undefined) {
                      top = 240;
                    }
                    this.clicked = true;
                    this.scrollPage(top, i, sel_letter);
                  } else {
                    index1 = this.getAllIndexes(this.channelData, letter);
                    lastItem = index1[0];
                    if (lastItem >= 0 && lastItem > this.apiepgData.length) {
                      top = 290;
                      $('#tvguideData').css('margin-top', '');
                      if (this.prevSelectedLetter === undefined) {
                        top = 240;
                      }
                      this.isPreviousEventComplete = false;
                      this.autoload(lastItem, top, i, sel_letter);
                    }
                  }
                }
              }
              this.prevSelectedLetter = i;
  }
  // filter and return the length of the array if the channels are available in the epgdata
 private getCount(val): any {
   let arr, data, result;
   arr = this.apiepgDataload;
   result = [];
   for (let i = 0; i < val.length; i++) {
     data = arr.filter(x => x.id === val[i]);
      if (data.length !== 0) {
        result.push(data[0]);
      }
  }
  return result.length;

}
// to push the each page channel length and each page offset value ->while scrolling back
 private autoloadVal(start, end): void {
       for (let i = 0; i < end; i++ ) {
                if (this.dataIndexes[i] === undefined) {
                    let pageload, startVal, endVal, channels, length, len, val, scroll;
                         pageload = i;
                         startVal = (pageload) * this.infi_pageSize;
                         endVal = (pageload + 1) * this.infi_pageSize;
                         this.channel_ids = this.unsortedData;
                         channels = this.channel_ids.slice(startVal, endVal);
                         length = this.getCount(channels);
                         len = this.dataIndexes[i - 1] + length;
                         this.dataIndexes.push(len);
                         if (i !== (end - 1)) {
                           val = this.scrollValues[i - 1];
                           scroll =  val === undefined ? 0 : val;
                           this.scrollValues.push(scroll + (length * this.channelContainerHeight * 1));
                         }
                } else {
                   if (this.scrollValues[i] === undefined) {
                       let arr, val1, scroll1;
                       arr = this.scrollValues;
                       val1 =  arr.pop();
                       scroll1 =  val1 === undefined ? 0 : val1;
                       this.scrollValues.push (scroll1 + ( this.dataIndexes[i] * this.channelContainerHeight));
                   }
                }
       }
  }
  // on click of alphbet if the data is not available in array fire th api befor that set the proper pageload value
  private autoload(n, top, i, letter): void {
        let timeout, pageLoadOld, start, end, temp, temp1, data1, myArray, factor, startPage, len;
        timeout = 50000;
       $('#loaderPage').css('display', 'block');
        pageLoadOld = this.pageload;
      this.pageload++;
      this.scrollValues = [];
      start = this.dataIndexes.length * this.infi_pageSize;
      this.dataIndexes.splice(1);
      startPage = (this.pageload - 1);
      // to set the pageload value
      this.pageload = Math.ceil(n / this.infi_pageSize);
      // if the letter modular value is 0 then add 1 more page
      factor = (n % this.infi_pageSize === 0 ? 1 : 0);
      this.pageload = this.pageload + factor;
      // total pages
      len = Math.ceil(this.unsortedData.length / this.infi_pageSize);
            // keep the channel is in middle if possible
       this.pageload = (this.pageload + 1) <= len ? (this.pageload + 1) : this.pageload;
      end = ((this.pageload) * this.infi_pageSize) ;
      this.channel_ids = this.unsortedData;
       temp = this.epgService.formatData (this.channel_ids.slice(start, end), this.timeOffset, this.dayindex_epg, this.translation, ((end - start) + 5));
       temp1 = this.basepath + '/v1/epg?' + temp;
      this.epgService.getcurrentEpgData(temp1).takeUntil(this.ngUnsubscribe).timeout(timeout).subscribe(value => {
         data1 = value;
         myArray = data1.items;
        this.apiepgDataDuplicate = this.apiepgDataDuplicate.concat(myArray);
        myArray = this.nodataFilter(myArray);
        $('#loaderPage').css('display', 'none');
        this.isPreviousEventComplete = true;
        this.apiepgDataload =  this.apiepgDataload.concat(myArray);
        this.apiepgData = this.apiepgData.concat(myArray);
        this.autoloadVal(startPage, this.pageload);
        // same as in loadmore
           if (this.pageload > 3 ) {
               let topv, margin;
               this.pageloaded = true;
               end = this.dataIndexes[(this.pageload - 4)];
               this.slotClose(end);
               margin = this.getSortMargin(this.apiepgDataload.slice(0, end), this.apiepgDataload[end]) * this.sortedarrayheight;
               topv = this.dataIndexes[(this.pageload - 4)] * this.channelContainerHeight;
               topv = (this.alphabet === true) ? (topv + margin) : topv;
                $('.epgSection').css('margin-top', topv + 'px');
                this.apiepgData =  this.apiepgDataload.slice(this.dataIndexes[(this.pageload - 4)], this.dataIndexes[(this.pageload - 1)]);
              if (this.alphabet) {
               this.groupArray(this.apiepgData, true);
               this.callScroll(top, i, letter);
             }
            } else {
              if (this.alphabet) {
                this.groupArray(myArray, false);
                this.callScroll(top, i, letter);
              }
        }
      }, error => {
        this.callToast();
        this.pageload = pageLoadOld;
        this.isPreviousEventComplete = true;
        $('#loaderPage').css('display', 'none');
        $('.auto-loader').css('display', 'none');
        this.gtm.sendErrorEvent('api', error);
      });
    }
    private callScroll(top, i, letter): void {
           setTimeout(() => {
          this.clicked = true;
          this.scrollPage(top, i, letter);
        }, 1 );
        this.isPreviousEventComplete = true;
    }
    private scrollPage(topval, i, letter): void {
      let index, index1, charCodeZero, charCodeNine, top;
       index = this.apiepgData.findIndex(x => x.original_title.charAt(0).toUpperCase() === letter);
       index1 = this.apiepgDataload.findIndex(x => x.original_title.charAt(0).toUpperCase() === letter);
       top =  topval === undefined ? 0 : topval;
       if (i === 1) {
             charCodeZero = '0'.charCodeAt(0);
              charCodeNine = '9'.charCodeAt(0);
              index =   this.apiepgData.findIndex(x => x.original_title.charCodeAt(0) >= charCodeZero && x.original_title.charCodeAt(0) <= charCodeNine );
              index1 =   this.apiepgDataload.findIndex(x => x.original_title.charCodeAt(0) >= charCodeZero && x.original_title.charCodeAt(0) <= charCodeNine );

           }
           // if it is available in current view data scroll it
       if (index !== -1) {
          this.clickedletter = true;
              setTimeout(() => {
           $('html, body').
          scrollTop(($('#letters' + i).offset().top) - top);
         setTimeout(() => {
                          this.clickedletter = false;
             }, 0 );
        }, 0 );
        } else if (index1 !== -1) {        // if it is not available in current view data set the proper data in view based on the index and scroll it
              $('#loaderPage').css('display', 'block');
              let startPage, start, end, startv, mtop, index_calc;
              index_calc = this.getAllIndexes(this.apiepgDataload, letter);
              index_calc = index_calc[0];
              startPage = Math.floor(index_calc / this.infi_pageSize);
               startPage = (startPage) > 0 ? startPage - 1 : 0;
              start = startPage * this.infi_pageSize;
              end = startPage + 2;
              this.pageload = end;
              startv = (this.pageload - 4) >= 0 ? this.dataIndexes[(this.pageload - 4)] : 0;
              if (this.pageload > 3) {
                  this.slotClose(startv);
              }
              mtop = startv * this.channelContainerHeight;
              $('.epgSection').css('margin-top', mtop + 'px');
              this.apiepgData =  this.apiepgDataload.slice(startv, this.dataIndexes[(this.pageload - 1)]);
              this.groupArray(this.apiepgData, true);
             $('#loaderPage').css('display', 'none');
        setTimeout(() => {
          this.clickedletter = true;
           $('html, body').
          scrollTop(($('#letters' + i).offset().top) - top);
                  setTimeout(() => {
                          this.clickedletter = false;

             }, 0 );

        }, 0 );
       }
      setTimeout(() => {
           this.setScroll();
      }, 0 );
    }
    // closing the slot during page load
    private slotClose(end): void {
      let open;
      if (this.slot) {
          open = this.channelIdcheck(this.apiepgDataload.slice(0, end), this.channelId);
              if (open) {
                this.prev_row = -1;
                this.sendVal(false);
              }
     }
    }
    // replaces route and chaning the metadata for tvguide
   private sendVal(eve): void {
        this.slot = false;
  if (!this.touchScreen) {
    this.location.replaceState('tvguide');
    let event;
     event = {url: '/tvguide'};
          this.seoService. updateStaticMeta(event);

  }
    }
    // find the index of first channel which has the first letter from original title as selected letter
    private getAllIndexes(myArray, letter): any {
      let results, len;
       results = [];
       len = myArray.length;
      for (let i = 0; i < len; i++) {
        if (myArray[i].original_title.charAt(0).toUpperCase() === letter) {
          results.push(i);
        }
      }
      return results;
    }
    // lazyloading of pages
    private loadMore(): void {
      if (this.clickedletter === true) {
                        $('.auto-loader').css('display', 'none');
             }
      if (this.pageload <= this.pageSize && this.epgLayout && this.isPreviousEventComplete && this.clickedletter === false) {
         let temppageload;
         temppageload = this.pageload;
                this.pageload++;
                this.loading = true;
        this.pageloaddec = this.pageload;
        if (this.pageload > this.dataIndexes.length) {
        let start, end, temp, temp1, data1, myArray;
        this.isPreviousEventComplete = false;
                $('.auto-loader').css('display', 'block');
                // infi_pageSize - maximum channels in the page
         start = (this.pageload - 1) * this.infi_pageSize;
         end = (this.pageload) * this.infi_pageSize;
           this.channel_ids = this.unsortedData;
            temp = this.epgService.formatData(this.channel_ids.slice(start, end), this.timeOffset, this.dayindex_epg, this.translation, 25);
            temp1 = this.basepath + '/v1/epg?' + temp;
           this.epgService.getcurrentEpgData(temp1).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
              data1 = value;
               this.setIndex(false);
              myArray = data1.items;
              // with empty items channel
             this.apiepgDataDuplicate = this.apiepgDataDuplicate.concat(myArray);
             myArray = this.nodataFilter(myArray);
             this.isPreviousEventComplete = true;
             // total epg data
             this.apiepgDataload =  this.apiepgDataload.concat(myArray);
             // data available in dom
             this.apiepgData = this.apiepgDataload;
             this.dataIndexes.push(this.apiepgDataload.length);
              if (this.pageload <= 3) {
                 setTimeout(() => {
                  this.loading = false; }, 0);
              }
              // when to insert the page while cming back
               this.scrollValues.push(this.window.pageYOffset);
               // at a time there will be only 3 pages data available in dom
               // if it is more than 3 pages removing the pages from top and including margin top value for that content
             if (this.pageload > 3 ) {
               let top, margin, open, offset;
                    $('.auto-loader').css('display', 'none');
                   this.clickedletter = true;
                    end = this.dataIndexes[(this.pageload - 4)];
                    offset = this.window.pageYOffset;
                    open = false;
                    // if the slot is open in whichever paga we are removing find the index and close the slot
                    if (this.slot) {
                      open = this.channelIdcheck(this.apiepgDataload.slice(0, end), this.channelId);
                    if (open) {
                           // this.slot = false
                           this.sendVal(false);
                                           this.prev_row = -1;
                                  this.window.scrollTo (0, (offset - (this.slotHeight - 120)));
                  setTimeout(() => {
                  this.clickedletter = false; }, 500);
                       } else {
                          setTimeout(() => {
                  this.clickedletter = false; }, 500);
                       }
                    }
                    this.pageloaded = true;
                    // to get the alphabet height,margin value which we are removing
                margin = this.getSortMargin(this.apiepgDataload.slice(0, end), this.apiepgDataload[end]) * this.sortedarrayheight;
               // set the top value based on how many channels in that page
               top = this.dataIndexes[(this.pageload - 4)] * this.channelContainerHeight;
               top = (this.alphabet === true) ? (top + margin) : top;
                $('.epgSection').css('margin-top', (top) + 'px');
                this.apiepgData =  this.apiepgDataload.slice(this.dataIndexes[(this.pageload - 4)], this.dataIndexes[(this.pageload - 1)]);
                             if (this.alphabet) {
               this.groupArray(this.apiepgData, true);
             }                                                         setTimeout(() => {
                  this.loading = false;  }, 0);

                                                   $('.epgSection').css('pointer-events', '');
             setTimeout(() => {
                  this.clickedletter = false; }, 500);
            } else {
                              $('.auto-loader').css('display', 'none');
                                      $('.epgSection').css('pointer-events', '');
                               if (this.alphabet) {
               this.groupArray(myArray, false);
             }
            }


           }, error => {
              this.epgService.loaded(false);
              this.callToast();
              this.loading = false;
              this.isPreviousEventComplete = true;
              this.pageload =  temppageload;
             $('#loaderPage').css('display', 'none');
             $('.auto-loader').css('display', 'none');
             this.gtm.sendErrorEvent('api', error);
           });
         } else {
               if (this.pageload > 3 ) {
                 this.setIndex(true);
                 this.clickedletter = true;
                 let top1, startVal, endv, margin1, diff;
                 this.pageloaded = true;
                 startVal = (this.pageload - 4) >= 0 ? this.dataIndexes[(this.pageload - 4)] : 0;
                 endv = startVal;
                 this.slotClose(endv);
                 margin1 = this.getSortMargin(this.apiepgDataload.slice(0, endv), this.apiepgDataload[endv]) * this.sortedarrayheight;
                 top1 = this.dataIndexes[(this.pageload - 4)] * this.channelContainerHeight;
                 top1 = (this.alphabet === true) ? (top1 + margin1) : top1;
                $('.epgSection').css('margin-top', (top1) + 'px');
                this.apiepgData =  this.apiepgDataload.slice(startVal, this.dataIndexes[(this.pageload - 1)]);
                if (this.alphabet) {
               this.groupArray(this.apiepgData, true);
             } else {
                diff = this.dataIndexes[this.pageload - 1] - this.dataIndexes[this.pageload - 2];
                this.window.scrollBy(0, (diff * 126));
             }

             $('.epgSection').css('pointer-events', '');
                               setTimeout(() => {
                  this.loading = false; }, 0);

                             setTimeout(() => {
                  this.clickedletter = false; }, 500);
             }
        }
        }
  }

private setAd(): any {
  let userType, nativeAds, showNativeAds;
  userType = this.commonService.getUserType();
  nativeAds = this.commonService.getAdsValue();
  showNativeAds = nativeAds && nativeAds['native_tags_ads'] && nativeAds['native_tags_ads'][userType] && nativeAds['native_tags_ads'][userType].ads_visibility && nativeAds['native_tags_ads'][userType]['screens'];
  if (showNativeAds) {
    nativeAds = nativeAds['native_tags_ads'][userType]['screens'];
    let native_ad, scope;
    scope = this;
    native_ad = $.grep(nativeAds, function(e) {
      return e.screen_id === 'tvguide';
    });
    if (native_ad && native_ad[0] && native_ad[0].ad_data && native_ad[0].ad_data.length > 0) {
      this.nativeTag = native_ad[0].ad_data[0];
      if (this.nativeTag) {
        this.nativeTag.adStyle = this.commonService.getAdType(this.nativeTag.ad_type);
        // this.adCreation(this.nativeTag.ad_tag, (this.nativeTag.div_id),  this.nativeTag.ad_dimension, 'native');
      }
      this.googleAdCreation();
    }
  }
}

public googleAdCreation () {
  if (this.nativeTag && this.nativeTag && this.nativeTag.div_id) {
    switch (this.nativeTag.ad_provider) {
      case 'adfox':
        let adFoxtagAvailable;
        adFoxtagAvailable = this.commonService.checkAdFoxTag();
        if (adFoxtagAvailable === 'true' && this.nativeTag.owner_id && this.nativeTag.params) {
          let scope;
          scope = this;
          $(this.document).ready(function() {
            scope.adFoxCreation(scope.nativeTag.div_id, scope.nativeTag.owner_id, scope.nativeTag.params , 'native');
          });
        }
        break;
      default:
        let googletagAvailable;
        googletagAvailable = this.commonService.checkGoogleTag();
        if (googletagAvailable === 'true' && this.nativeTag.ad_tag) {
          this.adCreation(this.nativeTag.ad_tag, this.nativeTag.div_id,  this.nativeTag.ad_dimension, 'native');
        }
        break;
    }
  }
}

public adFoxCreation(id: any, owner_id: any, params: any, adType: any) {
  let adFoxtagAvailable;
  adFoxtagAvailable = this.commonService.checkAdFoxTag();
  if (adFoxtagAvailable === 'true') {
      this.window.Ya.adfoxCode.create({
        ownerId: owner_id,
        containerId: id,
        params: params,
        // onLoad: function(data) { console.log(data, 'onLoad') },
        // onRender: function(render) { console.log(render, 'onRender') },
        onError: function(error) {
          // console.log(error, 'onError');
          $('#' + id).hide();
        },
        onStub: function(stub) {
          // console.log(stub, 'onstub');
          $('#' + id).hide();
        }
      });
  } else {
    $('#' + id).hide();
  }
}

  public adCreation(tag: any, id: any, dimension: any, adType: any) {
      let scope;
          scope = this;
      setTimeout(function() {
        if (googletag.apiReady) {
          googletag = googletag || {};
          googletag.cmd = googletag.cmd || [];
          googletag.cmd.push(function() {
            googletag.defineSlot(tag, dimension, id).setCollapseEmptyDiv(true).addService(googletag.pubads());
            // }
            googletag.enableServices();
          });
          googletag.cmd.push(function() { googletag.display(id); });
        }
      }, 1000);
  }

 private channelIdcheck(arr, channel): any {
  return arr.some(x => x.id === channel);
  }
        // to maintain the scroll position of timebar and epgdata
        private setScroll(): void {
          let n;
          n = this.alphabet ? '1' : '0';
           if ($('#slide-wrap')[0].scrollLeft === 0) {
                $('#slide-wrap').scrollLeft(this.scrolLeft);
           }
           if ($('.epgProgramColumn')[0].scrollLeft === 0) {
              setTimeout(() => {
                 $('#program' + n).scrollLeft(this.scrolLeft);
                 }, 300);
           }
        }
        // to get the number of alphabets which we are going to remove -> to calculate margin
        private getSortMargin(arr, next): any {
          let chars, next_char;
           chars = [];
           next_char = next.original_title.charAt(0);
                for (let i = 0; i < arr.length; i += 1) {
                    if (chars.indexOf(arr[i].original_title.charAt(0)) === -1 && (arr[i].original_title.charAt(0)) !== next_char) {
                       chars.push( arr[i].original_title.charAt(0));
                  }
                }
                return chars.length;
        }
       @HostListener('window:scroll', ['$event']) private onScrollEvent($event) {
        let factor, top, classname,  st;
        factor = 0.85;
        // perfomance
        st = this.window.pageYOffset;
        if (st === 0) {
            this.setScroll();
        }
        // scroll back to top set the epgdata and lastscrolltop values
        if (st < this.lastScrollTop && this.pageload > 3 && this.clickedletter === false) {
            let topv;
            topv = this.scrollValues[this.pageload - 3] * 1;
            if (st <= topv) {
             this.setIndex(false);
             $('#loaderUp').css('display', 'block');
             this.clickedletter = true;
              this.pageload =  this.pageload - 1;
              let start, mtop;
                 start = (this.pageload - 3) >= 0 ? this.dataIndexes[(this.pageload - 3)] : 0;
                 mtop = start * this.channelContainerHeight;
                this.lastScrollTop = st + (this.dataIndexes[(this.pageload - 1)] - start) * this.channelContainerHeight;
                st = this.lastScrollTop;
                this.document.getElementById('body').classList.add('overlay-open');
                                  this.showloader(mtop, start);
            }
       } else if (st > this.lastScrollTop && this.clickedletter === false) {   // scroll to next page if it reaches the factor
         this.lastScrollTop = st;
         if ($(this.window).scrollTop() >= ($(this.document).height() - $(this.window).height()) * factor) {
           if (this.touchScreen) {
             if (!this.slot && this.queryShwAll != 0) {
               this.loadMore();
             }
           } else {
             if(this.queryShwAll != 0){this.loadMore();}
           }
         }
        }
         this.lastScrollTop = st;
        // timebar position and if slot is open set the top value for slot visibility in viewport
           classname = $('#timeBar').hasClass('affix');
           // timebar position fix
         if ($(this.window).scrollTop() > Math.abs(this.top - this.headerMenuheight) && !this.empty ) {
           this.affix = true;
           classname = $('#timeBar').hasClass('affix');
           // if (classname === false) {
             $('#timeBar').addClass('affix');
           if (!this.touchScreen ) {
             if (this.alphabet) {
               if ((this.ui === 'current') && !this.heightflag ) {
                 $('.epgSection').css('padding-top', '305px');
               } else if ((this.ui === 'next') && !this.heightflag) {
                 $('.epgSection').css('padding-top', '320px');
               } else if (this.heightflag) {
                 $('.epgSection').css('padding-top', '465px');
               } else {
                     top = (this.clicked ? '290px' : '180px');
                    $('.epgSection').css('padding-top', top);
                    this.clicked = false;
               }
             } else {
               if ((this.ui === 'next' || this.ui === 'current') && !this.heightflag) {
                 $('.epgSection').css('padding-top', '160px');
               } else if ((this.ui === 'next' || this.ui === 'current') && this.heightflag) {
                 $('.epgSection').css('padding-top', '280px');
               } else {
                 $('.epgSection').css('padding-top', '126px');
               }
             }
             }
                           this.setSize();
           // }
         }  else if ($(this.window).scrollTop() < Math.abs(this.top - this.headerMenuheight) && !this.empty) {      // timebar position fixed to relative
           this.removeSize();
         }
         this.closeDropdown();
       }
       // setting the epg data and margintop based on pageload
       private showloader(mtop, start): void {
                       let startv, top, topvalue, end, margin, arr;
                        startv =  (this.pageload - 4) >= 0 ? this.dataIndexes[(this.pageload - 4)] : 0;
                        top = parseInt($('.epgSection').css('margin-top'), 10);
                        topvalue = startv * this.channelContainerHeight;
                        end = startv;
                        // to get alphabet height and margin
                        margin = this.getSortMargin(this.apiepgDataload.slice(0, end), this.apiepgDataload[end]) * this.sortedarrayheight;
                       topvalue = (this.alphabet === true) ? (topvalue + margin) : topvalue;
         setTimeout(() => {
               startv =  (this.pageload - 4) >= 0 ? this.dataIndexes[(this.pageload - 4)] : 0;
               arr = this.apiepgDataload.slice(startv, this.dataIndexes[(this.pageload - 1)]);
              this.apiepgData =  arr;
              if (this.alphabet) {
                 this.groupArray(this.apiepgData, true);
               }
                    $('.epgSection').css('margin-top', topvalue + 'px');
                    $('.epgSection').css('pointer-events', '');
                                      setTimeout(() => {
                  this.loading = false; }, 0);

                     setTimeout(() => {
                                  this.setScroll();
                                  this.document.getElementById('body').classList.remove('overlay-open');
                                           this.clickedletter = false;
                                           let startval;
                                            startval = startv * this.channelContainerHeight;
                                           $('#loaderUp').css('display', 'none');
                        }, 0);
          }, 0);
       }
       // if the timeber hits top keep it in fixed position
       private setSize(): void {
         let h, w1;
         h = this.window.innerHeight;
         w1 = $('.epgSection').width();
         if (this.alphabet && !this.touchScreen) {
           $('.alphabet').addClass('affix');
           $('.alphabet').css({'width': + w1 + 'px', 'height': 'calc(100% *(52/' + h + '))', 'top': this.headerMenuheight});
           $('#timeBar').css({'width': + w1 + 'px', 'height': 'calc(100% *(160/' + h + '))', 'top': '124px'});
         } else {
           $('#timeBar').css({'width': + w1 + 'px', 'height': 'calc(100% *(160/' + h + '))', 'top': this.headerMenuheight});
         }
       }
       // if the timeber moves from top remove the styles used in fixed position
       private removeSize(): void {
         this.clickedletter = this.epgService.getWindowScroll();
         $('#timeBar').removeClass('affix');
         $('#timeBar').css({'width': '', 'height': '', 'top': ''});
         $('.alphabet').removeClass('affix');
         $('.alphabet').css({'width': '', 'height': '', 'top': ''});
         if (this.clickedletter === false) {
           $('#tvguideData').css('margin-top', '');
           $('.epgSection').css('padding-top', '');
         }
         this.affix = false;
         this.prevSelectedLetter = null;
       }
       // timer function
       private doSomething(): void {
         this.timeslotWidth = (($('#timeSlot').width()));
         this.serverTime += 60000;
         let d, n, m, h, a, value;
         d = new Date(this.serverTime);
         n = d.getMinutes();
         this.min = n;
         m = d.getSeconds();
         h = d.getHours();
         this.currentTime = new Date(this.serverTime).toISOString();
         // every 30 mins move the slot
         if ((n === 30 || n === 0)) {
           this.goNext();
         }
         if (n >= 30) {
           n = n - 30;
         }
         // night 12 reload the page
         if (h === 0 && n === 1 && !this.slot) {
           location.reload();
         }
         // to track the live index
         if (this.slot && this.dayindex === 7 && this.ui === 'current' || this.checknext) {
           this.epgService.trackLiveIndex(true, this.currentTime);
         }
         // to set the time indicator
         a = (this.touchScreen === true ? 30 : 30 + 3);
         value = n * (this.timeslotWidth / a);
         if (value <= this.timeslotWidth) {
           $('#fillerImage').css('left', + value + 'px');
         }
       }
       // to set the timeindicator position
       private setIndicator(): void {
         let n, value, a;
         n = this.min;
         // 30 - eacl time slot is for 30 mts
         if (n > 30) {
           n = n - 30;
         }
         // each time slot width
         this.timeslotWidth = (($('#timeSlot').width()));
          a = (this.touchScreen === true ? 30 : 30 + 3);
         value = n * (this.timeslotWidth / a);
         if (value <= this.timeslotWidth) {
           $('#fillerImage').css('left', + value + 'px');
         }
       }
       // to get the width/height of few divs
       private fetchData(): any {
         $('.tvGuideInnerContainer').css('height', '');
         this.loaded = true;
           let timeScrollwidth;
           setTimeout(() => {
             $('#loaderPage').css('display', 'none');
             this.top = (($('#timeBar').offset().top) - 2) || 200;
             this.offsettop = this.top;
             this.filterService.getFilters();
             this.blockWidth = ($('#timeSlot').width());
             this.timeslotWidthScroll = (($('#timeSlot').width()) + 0.4);
             this.headerMenuheight = $('#headerMenu').height();
             this.dayWidth = ($('.days').width());
             timeScrollwidth = ($('#slide-wrap').width());
             this.visibleCount = Math.round(timeScrollwidth / (this.timeslotWidthScroll - 0.4));
             setTimeout(() => {
               if (this.selectedFilters.length > 0) {
                 this.filterFlag = true;
               }
             }, 1);
             $('.daycontainer-inner').scrollLeft(7 * this.dayWidth);
             this.setTimebarWidth();
             this.getContainerHeight();
             setTimeout(() => {
               if (this.dayindex === 7) {
                 this.starttime();
                 this.window.scrollTo(0, 0);
               }
             }, 0);
           }, 0);
         }
         // To set the epg data container width based on the timebar width
         private setTimebarWidth(): void {
           this.timeBarWidth = ($('.timescroll-outer').width());
           if (this.touchScreen) {
               $('.epgProgramColumn').css('width', + (this.timeBarWidth - 9) + 'px');
           }
         }
         // to get the container and sorted array(alphabet) height based on view(popularity/a-z) and device(desktop/mobile)
         private getContainerHeight(): void {
           if (this.touchScreen) {
              this.marginbottom = parseInt($('.channelContainerBox').css('margin-bottom'), 10);
              this.channelContainerHeight =  $('.channelContainerBox').height() +  this.marginbottom;
             if (this.alphabet) {
                  this.sortedarrayheight = (parseFloat($('.alphabetTitle').css('margin-bottom')) +  $('.alphabetTitle').height() + 19.5) - this.marginbottom;
                }
            } else {
                let top;
                top = parseInt($('.channelContainerBox').css('margin-top'), 10) > 0 ? parseInt($('.channelContainerBox').css('margin-top'), 10) : 6;
                this.margintop = top;
                this.channelContainerHeight = $('.channelContainerBox').height() + top;
                if (this.alphabet) {
                  this.sortedarrayheight = (parseFloat($('.alphabetTitle').css('margin-bottom')) +  $('.alphabetTitle').height() + parseFloat($('.sortedArray').css('margin-top') )) - this.margintop;
                }
           }
         }
         // to get the times(30 mts division) per day
         private getTimes = function(dayindex) {
           this.arr_time = [];
           this.h = 0;
           this.k = 0;
           let min, h;
           for (let i = this.h; i < 24; i++) {
             for (let j = this.k; j < 2; j++) {
               min = (j === 0 ? '00' : 30 * j);
               h = (i.toString().length === 1 ? '0' + i : i);
               this.arr_time.push(h + ':' + min);
               this.k = 0;
             }
           }
           this.arr_time.push('00:00');
           this.timecount = this.arr_time.length;
         };
         // to get the current time index
         private currtimeIndex(): any {
           let date, h, m, curr_time;
           date = new Date(this.currentTime);
           this.min = date.getMinutes();
           this.h = date.getHours();
           h = (this.h.toString().length === 1 ? '0' + this.h : this.h);
           m = (this.min >= 30 ? '30' : '00');
           curr_time = h + ':' + m;
           return curr_time;
         }
         // to move the timebar and data container till current time and to set the time indicator
         private starttime = function() {
           let curr_time, movable, time, count, n;
            curr_time = this.currtimeIndex();
           movable = this.timecount - this.visibleCount;
           this.currTime_index = this.arr_time.indexOf(curr_time);
           if (this.timeslotWidthScroll > 0) {
             this.currTime_index = this.arr_time.indexOf(curr_time);
             if (curr_time > this.arr_time[movable]) {
               time = movable;
             } else {
               time = this.arr_time.indexOf(curr_time);
             }
             $('#slide-wrap').scrollLeft(time * this.timeslotWidthScroll - 13.2);
             n = this.alphabet ? '1' : '0';
             $('#program' + n).scrollLeft(time * this.timeslotWidthScroll - 13.2);
             this.scrolLeft = time * this.timeslotWidthScroll - 13.2;
           }
           count = (this.currTime_index > movable ?  movable : this.currTime_index);
           this.movecount = count;
           setTimeout(() => {
             this.setIndicator();
           }, 0);
         };
   // to get previous 7 days and next 6 days based on the current day
   private getDate = function() {
    this.curr_time = this.serverTime; // First day is the day of the month - the day of the week
    for (let i = -7; i < 7; i++) {
      let last;
      // 86400000 -> milliseconds per day (3600*1000*24)
      last = this.curr_time + (i * 86400000);
      this.dates.push(last);
    }
  };
  /* Function to translate day and month */
  private getDateTranslate(date, details) {
      let day, month, dateString;
      dateString = (new Date(date)).toString().toUpperCase();
      day = dateString.split(' ')[0]; // fetch day of week
      month = dateString.split(' ')[1]; // fetch month
      if (details === 'day') {
        return this.translate.instant('TVGUIDE.' + day); // translate day eg: Mon, Tue, Wed, ...
      }
      if (details === 'month') {
        return dateString.split(' ')[2] + ' ' + this.translate.instant('TVGUIDE.' + month) + ' ' + dateString.split(' ')[3]; // translate month eg: Jan, Feb, Mar, ...
      }
      if (details === 'selectedDay') {
        return dateString.split(' ')[2] + ' ' + this.translate.instant('TVGUIDE.' + month) + ' ' + dateString.split(' ')[3]; // translate date
      }
      if (details === 'date') {
        return dateString.split(' ')[2] + ' ' + this.translate.instant('TVGUIDE.' + month) + ' ' + dateString.split(' ')[3]; // translate date
      }
  }
  // on click of any day
  private selectDay = function(dayindex, eve) {
    if (this.networkService.getScreenStatus()) {
      this.dayindex = dayindex;
      // initializing the values
      if (this.prevDay_index !== this.dayindex) {
         this.scrolLeft = 0;
        $('#slide-wrap').scrollLeft(0);
        $('.epgProgramColumn').scrollLeft(0);
        $('#slide-wrap').stop(true, false);
        $('.epgProgramColumn').stop(true, false);
         this.pageload = 1;
         $('.epgSection').css('margin-top', '0px');
         this.pageloaddec = -1;
         this.dataIndexes = [];
         this.scrollValues = [];
         this.pageloaded = false;
         this.epgService.loaded(true);
        this.sortedarray = [];
        this.dayindex_epg = dayindex - 7;
        this.selectedDay = this.dates[dayindex];
        this.firstIndex = 0;
        this.movecount = 0;
        this.selecteddate = this.dates[dayindex];
        if (eve) {
          this.selectedAlphabets = [];
          this.getEPGData();
        }
        this.getTimes(this.dayindex);
        $('#loaderPage').css('display', 'block');
      }
      this.prevDay_index = this.dayindex;
    }
  };
        // Previous time click on time bar
  private movePrevious(): void {
    if (this.movecount >= 1) {
      this.movecount--;
      this.scrolLeft =  $('#slide-wrap')[0].scrollLeft - this.timeslotWidthScroll;
      $('#slide-wrap').animate({scrollLeft: '-=' + this.timeslotWidthScroll + 'px'});
      $('.epgProgramColumn').animate({scrollLeft: '-=' + (this.timeslotWidthScroll) + 'px'});
    }
  }
      // Next time click on time bar
  private moveNext(): void {
    // this.timecount -> total no of 30minutes in one day (48),this.visibleCount -> how many are visible in dom
    if (this.movecount < (this.timecount - this.visibleCount) && this.timecount > this.visibleCount) {
      this.movecount++;
      this.scrolLeft =  $('#slide-wrap')[0].scrollLeft + this.timeslotWidthScroll;
      $('#slide-wrap').animate({scrollLeft: '+=' + this.timeslotWidthScroll + 'px'});
      $('.epgProgramColumn').animate({scrollLeft: '+=' + (this.timeslotWidthScroll) + 'px'});
    }
  }
    // Previous day click on day bar
  private movePreviousDay(): void {
    if (this.daycount >= 1) {
      this.daycount--;
      $('#day_Scroll').animate({scrollLeft: '-=' + this.dayWidth + 'px'}, 300);
   }
  }
  // Next day click on day bar
  private moveNextDay(): void {
    if (this.daycount < 14 && this.daycount !== 7 ) {
      this.daycount++;
      $('#day_Scroll').animate({scrollLeft: '+=' + this.dayWidth + 'px'}, 300);
    }
  }
  // on click of any program
  private rowClick(j, k, eve): void {
    if ((eve.target.id === 'showsArrayinner') || (eve.target.id === 'showName') || (eve.target.id === 'selectedTriangle')) {
      this.row_no = k;
      this.array_no = j;
    }
  }
    // calculate scroll top to move the slot into view (A-Z screen)
  private scrollupdownalpha(): void {
    let topVal, prevui;
    topVal = 0;
    // array not same
    if (this.array_no !== this.prev_array) {
      this.slotHeight = 0;
      topVal = Math.abs((this.slotHeight));
      if ( $('#timeBar').hasClass('affix')) {
            if (this.prev_array > this.array_no) {
             topVal = (this.ui === 'next' ? 140 : 120);
      } else if (this.prev_array < this.array_no) {
             if (prevui !== 'next') {
                topVal = (this.array_no > this.prev_array) && (this.prev_row > -1) ? 240 : 120;
             } else {
               topVal = 120;
             }
      }

            this.moveslots( topVal, true, 'diff');
      } else {
        topVal = 20;
                    this.moveslots( topVal, true, 'diff');
      }
    }  else if (this.row_no === this.prev_row && this.changeContent && !this.heightflag && this.array_no === this.prev_array) {   // array same and same row
      this.slotHeight = 0;
      topVal = this.slotHeight;
      topVal = Math.abs((this.slotHeight - (120 + 15)));
      if (!$('#timeBar').hasClass('affix')) {
        topVal = 20;
      }
          this.moveslots( topVal, false, 'same');
    }  else if (this.array_no === this.prev_array && this.row_no !== this.prev_row) {     // array same and diff row
            this.slotHeight = 0;
      topVal = Math.abs( this.slotHeight - 120);
      if (this.row_no < this.prev_row) {
        topVal = (this.ui === 'next' ? 135 : 120);
      } else if (this.row_no > this.prev_row && this.setchangeContent) {
        topVal = (this.ui === 'next' ? 135 : 115);
      }  else if (this.row_no > this.prev_row) {
          topVal = 240;
      }
       this.moveslots( topVal, false, 'diff');
    }
    prevui = this.ui;
  }
  // scroll the slot into view (A-Z screen)
  private moveslots(topval, status, info): void {
    let scroltop, factor, topVal,  factoradd;
    factor = 0;
    if ((this.prev_row > -1) && (this.prevUi !== this.ui) && (status || info === 'diff')) {
      factor = ((this.prevUi === 'next')  ? -50 : 50);
     if (this.setchangeContent && this.array_no !== this.prev_array ) {
       factor = (this.array_no > this.prev_array)  ? -80 : 0;
    }
    } else if (this.setchangeContent && this.array_no !== this.prev_array && (this.prev_row > -1)) {
     factor = (this.array_no > this.prev_array)  ? -80 : 0;
    }
    topVal = topval + factor;
       setTimeout(() => {
                      factoradd =  ((this.ui === 'next' &&  this.divTop === 0) ? 100 : 0);
               scroltop = ((  $('#channelDetail' + this.row_no + '-' + this.array_no).offset().top) - topVal) - this.divTop;
      $('html, body').animate({scrollTop: scroltop - factoradd }, 0);
    }, 120);
          this.prevUi = this.ui;

  }
  // scroll the slot into view (popularity screen)
  private scrollupdown(): void {
    this.slotHeight = 0;
    let scroltop, topVal, factor;
    if (this.row_no < this.prev_row ) {
      this.slotHeight = 0;
    }
    if (this.row_no !== this.prev_row) {
     topVal = Math.abs((this.slotHeight - (75)));
         setTimeout(() => {
      if ( $('#timeBar').hasClass('affix')) {
        scroltop = (($('#channelDetails' + this.row_no).offset().top) - topVal) - this.divTop;
      } else {
        scroltop = (($('#channelDetails' + this.row_no).offset().top) - (75));
      }
             factor =  ((this.ui === 'next' &&  this.divTop === 0) ? 120 : 0);
            $('html, body').animate({scrollTop: scroltop - factor}, 0);
          }, 120);

    } else if (this.row_no === this.prev_row && this.changeContent && !this.heightflag) {
               setTimeout(() => {

      this.slotHeight = (this.ui === 'next' ? 0 : 0);
      topVal = Math.abs((this.slotHeight - (75)));
             factor =  ((this.ui === 'next' &&  this.divTop === 0) ? 120 : 0);
      scroltop = (($('#channelDetails' + this.row_no).offset().top) - topVal );
            $('html, body').animate({scrollTop: (scroltop - factor)}, 0);
                      }, 120);

    }
  }
  // calculate the slot height based on which slot is opened
  private setPopupHeight(): void {
    switch (this.ui) {
      case 'next':
      this.nextshow();
      this.currentShow = false;
      break;
      case 'current':
      this.currentshow();
      this.currentShow = true;
      break;
      default:
      break;
    }
    this.checkShow();
  }
  // currentslot-nextslot / nextslot-currentslot change
  private checkShow(): void {
    if (this.currentShow !== this.prevValue || this.setchangeContent) {
      this.changeContent = true;
    } else {
      this.changeContent = false;
    }
    this.prevValue = this.currentShow;
  }
  // set the calculated container height based on the view (popularity/a-z)
  private setContainerHeight(): void {
    this.slotHeight = this.slotHeight1;
    if (this.alphabet) {
      $('#channelDetail' + this.row_no + '-' + this.array_no).css('height', + this.newcontainerHeight + 'px');
      $('#channelBox' + this.row_no + '-' + this.array_no).css('height', + this.newcontainerHeight + 'px');
    } else {
      for ( let i = 0; i < this.apiepgData.length; i++) {
          $('#channelDetails' + this.row_no).removeAttr('style');
       $('#channelBox' + this.row_no).removeAttr('style');
      }
      $('#channelDetails' + this.row_no).css('height', + this.newcontainerHeight + 'px');
      $('#channelBox' + this.row_no).css('height', + this.newcontainerHeight + 'px');
    }
  }
  // To calculate the the currenslot height based on innerwidth
  private currentshow(): void {
    if (this.window.innerWidth > 1400) {
      this.newcontainerHeight = 541 + 120;
    } else {
      let factor;
      factor = (541 * this.window.innerWidth) / 1400;
      this.newcontainerHeight = factor + 120 + 14;
    }
    this.slotHeight1 = this.newcontainerHeight;
  }
    // To calculate the the nextslot height based on innerwidth
  private nextshow(): void {
    let factor, innerHeight;
    factor = 313 / 1080;
    innerHeight = this.window.innerHeight;
    this.newcontainerHeight = (innerHeight * factor) + 120;
    this.slotHeight1 = this.newcontainerHeight + 20;
  }
  // sort open
  private openSort(): void {
    if (this.networkService.getPopupStatus()) {
      this.sortbar = true;
    }
  }
  // sort close
  public closeSort(event): void {
    this.sortbar = event;
  }
  // after selection of A-Z in sort overlay
  private getSort(sort): void {
    this.slotHeight = 0;
    this.prevSelectedLetter = undefined;
    switch (sort) {
      case 0:
      this.alphabet = false;
      break;
      case 1:
      this.alphabet = true;
      break;
      default:
      break;
    }
    if ($('#timeBar').hasClass('affix')) {
       this.setSize();
     }
// re=initializing values and fire the api again with sort field
    if (this.epgLayout && this.loaded) {
      this.pageload = 1;
      this.tooglesort = true;
      this.sortedarray = [];
      this.fetchChannels();

    }
    this.setTimebarWidth();
    // initializing the top value if it is alphabet view
    if (this.alphabet && !this.empty && !this.touchScreen) {
         setTimeout(() => {
         this.top = (($('.alphabet').offset ().top) - 2);
         this.top = (this.top === undefined) ? 200 : this.top;
       }, 1000);  }
     }
     // pushing the alphabets into one array based on the first letter of channel original tile (array is used for highlight/de-highlight)
     private setalphabets(data): void {
      if (this.alphabet) {
       let idx, char1;
       for (let i = 0; i < data.length; i++) {
         char1 = (data[i].original_title) ? (data[i].original_title).charAt(0).toUpperCase() : '';
         if (char1 >= 'A' && char1 <= 'Z') {
           idx = this.alphabets.indexOf(char1);
         } else if ((char1 >= '0' && char1 <= '9')) {
           idx = 1;
         } else {
           idx = 0;
         }
         // check whether the alphabet is already available or not then push if it is not available
         if (this.selectedAlphabets.indexOf(this.alphabets[idx]) === -1) {
           this.selectedAlphabets.push(this.alphabets[idx]);
         }
       }
     }
     }
     private getSortChannelDetails(prop: string): any {
       return this.sorted_channels.map(function(a) {return a[prop]; });
     }
     // If the view is alphabet view group the array based on first char of the channel
      private groupArray (data, status): void {
       if (status) {
         this.sortedarray = [];
       }
       if (this.alphabet) {
         let idx, char1;
         for (let i = 0; i < data.length; i++) {
           char1 = (data[i].original_title).charAt(0).toUpperCase();
           this.temp = [];
           if (char1 >= 'A' && char1 <= 'Z') {
             idx = this.alphabets.indexOf(char1);
           } else if ((char1 >= '0' && char1 <= '9')) {
             idx = 1;
           } else {
             idx = 0;
           }
       //  if the particular index array is already available take the old values and push the new one in the temp
      if (this.sortedarray[idx]) {
        this.temp = this.sortedarray[idx];
        this.temp.push(data[i]);
      }  else {  //  if the particular index array is not available push the new one
        this.temp.push(data[i]);
      }
      // pushing the data to proper index in an array
      this.sortedarray[idx] = this.temp;
    }
  }
}
// to highlight/de-highlight the alphabet
private isAlphabetSelected(n): any {
  return this.selectedAlphabets.indexOf(n) > -1;
}
// filter open
private openFilter(): void {
  if (this.networkService.getPopupStatus()) {
    this.filterbar = true;
  }
}
// filter close
public closeFilter = function(event) {
  this.filterbar = false;
};
// while loading the next page remove the styles
private setIndex(status): void {
        this.loading = true;
    if (!this.alphabet) {
      this.epgService.loaded(false);
      $('.channelContainerDetails').removeAttr('style');
      $('.channelContainerBox').removeAttr('style');
      $('.epgSection').css('pointer-events', 'none');
   }
}
// While closing the slot
private send(eve,query?): void {
  this.slot = false;
  // route reset and breadcrum value change
  if (!this.touchScreen) {
    if(query){
      this.location.replaceState('tvguide' + query);
    }
    else{
      this.location.replaceState('tvguide');
    }
    let event;
    event = {url: '/tvguide'};
          this.seoService. updateStaticMeta(event);
           let breadCrumbArray;
    breadCrumbArray = [{'label': 'BREADCRUMB.HOME', 'url': '/', 'enable': true}, {'label': 'BREADCRUMB.TVGUIDE', 'url': '/tvguide', 'enable': false}];
    this.headerservicesService.breadCrump(breadCrumbArray);
  }
  // based on popularity/sort view remove the height from previously selected channel
  if (this.alphabet) {
    $('#channelDetail' + this.prev_row + '-' + this.prev_array).css('height', '');
    $('#channelBox' + this.prev_row + '-' + this.prev_array).css('height', '');
  } else if (!this.alphabet) {
    $('#channelDetails' + this.prev_row).css('height', '');
    $('#channelBox' + this.prev_row).css('height', '');
  }
  err => {
       this.headerservicesService.breadCrump('');
      };
}
// on click of any program
private openSlot(eve): void {
               let breadCrumbArray;
  setTimeout(() => {
    this.event = eve;
    this.show = eve.event;
    this.slot = this.show;
    this.ui = eve.ui;
    this.channelId = eve.id;
    // calculate height and set it
    if (this.show) {
      if (this.show && !this.touchScreen) {
        this.setPopupHeight();
        if (!this.alphabet) {
          this.scrollupdown();
        } else {
          this.scrollupdownalpha();
        }
        this.setContainerHeight();
      }
      // metadata,breadcrum,route update
      let genres, tempTitle;
          genres = [];
          for (let ind = 0; ind < eve.genres.length; ind++) {
            genres.push(eve.genres[ind].id);
          }
          genres = genres.join(', ');
      this.prev_row = this.row_no;
      this.prev_array = this.array_no;
      this.setchangeContent = false;
        if (!this.touchScreen) {
        eve.title = eve.title.toLowerCase().replace(/&/g, 'and');   // & not routing to tvguide so
      this.location.replaceState('tvguide/' + eve.title + '/' + eve.id);
         let  index;
                    index = this.channelData.findIndex(x => x.id === eve.id);
    breadCrumbArray = [{'label': 'BREADCRUMB.HOME', 'url': '/', 'enable': true}, {'label': 'BREADCRUMB.TVGUIDE', 'url': '/tvguide', 'enable': false}, {'label': this.channelData[index].title, 'url': '/tvguide/' + eve.title + '/' + eve.id, 'enable': false}];
    this.headerservicesService.breadCrump(breadCrumbArray);
      if (eve.extended && eve.extended.seo_title) {
            tempTitle = (eve.extended.seo_title !== null || eve.extended.seo_title !== undefined || eve.extended.seo_title !== '') ? eve.extended.seo_title : eve.original_title;
          } else {
            tempTitle = (eve.seo_title && (eve.seo_title !== null || eve.seo_title !== undefined || eve.seo_title !== '')) ? eve.seo_title : eve.original_title;
          }
            this.seoService.tvguidePage(tempTitle, genres, eve.languages);
    }
    } else if (!this.show) {
      this.prev_row = this.row_no;
    }
  }, 0);
   err => {
       this.headerservicesService.breadCrump('');
      };
}
@HostListener('window:resize', ['$event'])
private onResize(event) {
  this.onresize(event.target);
}
// while resizing get the width of divs
private onresize(event) {
    let timeScrollwidth, top;
if (!this.clickedletter) {
  this.touchScreen = false;
  this.headerMenuheight = $('#headerMenu').height();
  this.blockWidth = ($('#timeSlot').width());
  timeScrollwidth = ($('#slide-wrap').width());
  this.visibleCount = Math.round(timeScrollwidth / (this.blockWidth));
  if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i) || this.window.innerWidth <= 768) {
    this.touchScreen = true;
    setTimeout(() => {
      this.setTimebarWidth();
    }, 0);
  } else {
    $('.epgProgramColumn').css('width', '');

  }
  // if slot is open set the propr height
  if (this.slot) {
    this.setPopupHeight();
    this.setContainerHeight();
  }
  // if timebar is fixed set the proper width and height
  if ($( '#timeBar' ).hasClass( 'affix' )) {
    this.setSize();
  }
  // set the dayslot scroll position
  $('.daycontainer-inner').scrollLeft(7 * this.dayWidth);
 }
   top = this.touchScreen ? 90 : 100;
  $('#breadcrumInit').css('top', top + 'px');
}
public ngOnDestroy (): void {
      this.linkservice.removeCanonicalLink();
  this.document.getElementById('hideoutside').style.backgroundColor = '';
  this.filterService.showfooter(true);
  this.document.getElementById('body').classList.remove('overlay-open');
    this.document.getElementById('body').classList.remove('modal-open');
    /* ad implementation */
    let googletagAvailable;
    googletagAvailable = this.commonService.checkGoogleTag();
    if (googletagAvailable === 'true' && googletag.destroySlots) {
      googletag.destroySlots();
      // clearTimeout(this.timer);
    }
    let adFoxtagAvailable;
    adFoxtagAvailable = this.commonService.checkAdFoxTag();
    if (adFoxtagAvailable === 'true' && this.window.Ya.adfoxCode.destroy) {
    // if (adFoxtagAvailable === 'true' && this.window.Ya && this.window.Ya.adfoxCode && this.window.Ya.adfoxCode.destroy) {
      this.window.Ya.adfoxCode.destroy();
    }
    /* ad implementation */
  if (this.timer !== null) {
    this.timer.unsubscribe();
  }
  this.ngUnsubscribe.next();
  this.ngUnsubscribe.complete();
  this.headerservicesService.premium = false;
    $('#breadcrumInit').css('top', '90px');

}
// mobileview dropdown open and close
private toggelShowDiv(): void {
  let scope;
  scope = this;
  $(this.document).ready(function() {
    if (scope.toggle_div === true) {
      $( '.dropdown-content' ).fadeOut( 'fast' );
      scope.toggle_div = false;
    }  else {
      $( '.dropdown-content' ).fadeIn( 'fast' );
      scope.toggle_div = true;
    }
  });
}
// mobileview dropdown close
private closeDropdown(): void {
  if (this.toggle_div === true) {
    $( '.dropdown-content' ).fadeOut( 'fast' );
    this.toggle_div = false;
  }
}
// mobileView touch scroll for epgdata will scroll time
private scrollData(): void {
  if (this.touchScreen) {
    if (!this.datascroll) {
      let element;
      element = this.myScrollContainer1.nativeElement;
      this.timescroll = true;
      this.myScrollContainer.nativeElement.scrollLeft = element.scrollLeft;
    }
    this.datascroll = false;
  }
}
// mobileView touch scroll for time will scroll data
private scrollTime(): void {
  if (this.touchScreen) {
    if (!this.timescroll) {
      this.datascroll = true;
      let element;
      element = this.myScrollContainer.nativeElement;
      this.myScrollContainer1.nativeElement.scrollLeft = element.scrollLeft;
    }
    this.timescroll = false;
  }
}
// toast msg for api timeout error
 private callToast() {
    let p;
    p = this.document.getElementById('tryLater');
    p.className = 'show';
    setTimeout(function() { p.className = p.className.replace('show', ''); }, 3000);
    this.toastMsg =  'MESSAGES.TIMEOUT_ERROR';
}
}

