import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FilterModule } from '../filter/filter.module';
import { SortModule } from '../sort/sort.module';
import { ShareoptionsModule } from '../share-options/share-options.module';
import { DataUnavailableModule } from '../data-unavailable/data-unavailable.module';
import { SharedModule } from '../shared.module';
import { TvguideComponent } from '../tvguide/tvguide.component';
import { EpgChannelimageContainerComponent } from './epg-channelimage-container/epg-channelimage-container.component';
import { EpgChannelContainerComponent } from './epg-channel-container/epg-channel-container.component';
import { EpgNextShowComponent } from './epg-next-show/epg-next-show.component';
import { EpgCurrentShowComponent } from './epg-current-show/epg-current-show.component';
import { CatchupScrollListComponent } from './catchup-scroll-list/catchup-scroll-list.component';
import { CatchupGridComponent } from './catchup-grid/catchup-grid.component';
import { RouterModule, Routes } from '@angular/router';
import { DateFilterPipe } from './custom-filter/date-filter.pipe';
import { FooterModule } from '../footer/footer.module';
import { VideoModule } from '../video/video.module';

const routes: Routes = [
    { path: '', component: TvguideComponent},

];
@NgModule({
  exports: [RouterModule],
  imports: [
  	RouterModule.forChild(routes),
    CommonModule,
    FilterModule,
  	SortModule,
  	ShareoptionsModule,
  	DataUnavailableModule,
  	SharedModule,
    FooterModule,
    VideoModule
  ],
  declarations: [DateFilterPipe, TvguideComponent, EpgChannelimageContainerComponent, EpgChannelContainerComponent, EpgNextShowComponent, EpgCurrentShowComponent, CatchupScrollListComponent, CatchupGridComponent]
})
export class TvGuideModule { }
