import { Component, OnInit, Input} from '@angular/core';
import * as $ from 'jquery';
import { SettingsService } from '../../services/settings.service';
import { environment } from '../../../environments/environment';
import { EpgService } from '../../services/epg.service';
import { GoogleAnalyticsService } from '../../services/google-analytics.service';

@Component({
  selector: 'app-epg-channelimage-container',
  templateUrl: './epg-channelimage-container.component.html',
  styleUrls: ['./epg-channelimage-container.component.less']
})
export class EpgChannelimageContainerComponent implements OnInit {
  @Input() public touchScreen: boolean;
  @Input() public channel: any;
  public assetbasepath: any;
  public url: any;
  private default: any;
  private basePath: any;
  public errorImage: any;
  private channelId: Array<any> = [];
  private loadedimages: Array<any> = [];
  private loaded = false;
  constructor(private gtm: GoogleAnalyticsService, private epgService: EpgService, private settingsService: SettingsService) {
         this.assetbasepath = environment.assetsBasePath;
         this.default =   this.assetbasepath + 'assets/default/epg_channel_logo.png';
         this.errorImage = this.assetbasepath + 'assets/default/epg_channel_logo.png';
  }

  public ngOnInit() {
    this.gtm.storeWindowError();
     this.loadedimages = this.epgService.getchannelIds();
     // whether the image is already loaded or not
     if (this.loadedimages.indexOf(this.channel.id) === -1) {
         this.url = this.default;
         this.loaded = false;
     } else {
        this.loaded = true;
     }
     // list image availability
    if (this.channel.list_image !== null && this.channel.id !== null && this.channel.list_image !== '') {
      this.basePath = this.settingsService.getbasePath();
      let url, lastPoint, str1, str2, str3, urlform, img1, scope;
      this.channelId = this.channel.id;
      this.epgService.channelIds(this.channelId);
      url = this.channel.list_image;
      lastPoint = url.lastIndexOf('.');
      // finding the index of dot before jpg -> removing .jpg -> appending .png
      if (lastPoint >= 0) {
        str1 = url.substring(0, lastPoint);
        str2 = url.substring(lastPoint + 1);
        str3 = str1 + '.png';
        urlform = this.basePath + this.channel.id + '/list/' + '170x120/' + str3;
          if (!this.loaded) {
          img1 = new Image();
          img1.src = this.url;
          scope = this;
            img1.onload = function() {
              $('.channelImage').css('background', '#030003');
              scope.url = urlform;
            };
          } else {
                    this.url = urlform;
          }
      } else {
      this.url = urlform;
      }
    }
  }
}
