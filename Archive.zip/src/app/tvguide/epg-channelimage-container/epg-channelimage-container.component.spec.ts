import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EpgChannelimageContainerComponent } from './epg-channelimage-container.component';

describe('EpgChannelimageContainerComponent', () => {
  let component: EpgChannelimageContainerComponent;
  let fixture: ComponentFixture<EpgChannelimageContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EpgChannelimageContainerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EpgChannelimageContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
