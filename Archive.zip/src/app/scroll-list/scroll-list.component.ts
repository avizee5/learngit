import { Component, OnInit, Input, ViewChild, ElementRef, Output, EventEmitter, OnDestroy, OnChanges} from '@angular/core';
import * as $ from 'jquery';
import { Router } from '@angular/router';
import {  NetworkService  } from '../services/network.service';
import { environment } from '../../environments/environment';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import {CommonService} from '../services/common.service';
import { Subject } from 'rxjs/Subject';
import {CollectionApi} from '../../data/gwapi_catalog/api/CollectionApi';
import { Headers, Http , RequestOptions, Response} from '@angular/http';
import { SettingsService } from '../services/settings.service';

@Component({
  selector: 'app-scroll-list',
  templateUrl: './scroll-list.component.html',
  styleUrls: ['./scroll-list.component.less']
})
export class ScrollListComponent implements OnInit, OnChanges, OnDestroy {
  @Input() public arrayList: any;
  @Input() public pagenumber: any;
  @Input() public screen: any;
  @Input() public detectChange: any;
  @Input() public modalVideoPopup: boolean;
  @Input() public episodeConsumption: any;
  @Input() public showCard: boolean;
  @Input() public noEpisodes: any = false;
  @Input() public yIndex: any = 'NA';
  @Input() public talamoosImpression: any;
  @Input() public pagename: any;
  // @ViewChild('left') public previous_select: ElementRef;
  // @ViewChild('right') public next_select: ElementRef;
  @ViewChild('list') public element_select: ElementRef;
  @ViewChild('parentList') public element_parent: ElementRef;

  public count: any;
  public arrows: any;
  public gridWidth: any;
  public containerWidth: any;
  public scrollEnable: any = false;
  public gridTitle: any;
  public localstorage: any;
  public window: any;
  public document: any;
  public navigator: any;
  public index_limit: any = 4;
  public pageSize: any = 4;
  public totalPages: any;
  public currentPage: any = 1;
  public currentPosition: any = 4;
  public updatedArray: any;
  public fetchPending: any = false;
  public isDesktop: any = true;
  public isMovieTray: any = false;
  public assetBasePath = environment.assetsBasePath;
  @Output() public onChange = new EventEmitter<any>();
  @Output() public nextpage = new EventEmitter<boolean>();
  public percent: any = 0;
  private ngUnsubscribe = new Subject<any>();
  public apiRetry: any = 2;
  public apiRetryCount: any = 1;
  public processPending: any = false;
  public right_arrow: any = true;
  public left_arrow: any = false;
  public showDetailsPopup: any;
  public pagecount: any;
  public ischanneldetails: any = false;
  public scrollDetails: any = true;
  public scrollEvent: any;
  public scrollLeft: any = 0;
  public basePath: any;
  public channelHover: any = [];
  public channelCarousal: any = false;
  private talamoosGA: any = false;
  constructor(private http: Http, private commonService: CommonService, @Inject(PLATFORM_ID) private platformId: Object, private gtm: GoogleAnalyticsService, private router_link: Router, private networkService: NetworkService, private settingsService: SettingsService) { }
  public ngOnChanges (changes: any): void {
    if (changes['talamoosImpression']) {
      if (changes['talamoosImpression'].previousValue === undefined && changes['talamoosImpression'].currentValue === true) {
        this.sendTalamoosGA();
      }
      // return;
    }
    if (isPlatformBrowser(this.platformId)) {
      this.localstorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
    this.showDetailsPopup = this.showCard;
    if (this.arrayList.type === 'eventbanner') {
      this.pageSize = 2;
      this.currentPosition = 2;
    } else {
      this.pageSize = 4;
      this.currentPosition = 4;
    }
    if (this.arrayList.content && this.arrayList.content.length > 0) {
      this.totalPages = Math.ceil(this.arrayList.content.length / this.pageSize);
    }
    if (this.arrayList.type === 'livetv' && this.arrayList.parentType !== 'search_live' ) {
      this.count = 0;
    }
    if (this.arrayList.content ) {
      if (this.arrayList.content.length < this.pageSize + 1 || this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
        this.arrows = false;
      } else {
        this.arrows = true;
        this.isDesktop = true;
      }

      if ( this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
        this.isDesktop = false;
      } else {
        this.isDesktop = true;
      }


      if (this.isDesktop === false) {
        if (this.updatedArray === undefined || this.updatedArray == null ) {
          this.updatedArray = this.arrayList.content.slice(0, this.pageSize);
        }
      }

      if (this.window.innerWidth > 768) {
        this.index_limit = this.pageSize + 1;
      }

      if (this.window.innerWidth > 768) {
         if (this.arrayList.type === 'eventbanner') {
               this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
           this.containerWidth = 25 * this.arrayList.content.length * 1.612;
         } else {
           this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
           this.containerWidth = 25 * this.arrayList.content.length * 0.941;
         }
        //  if (this.arrayList.content.length === 2) {
        //   this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
        //   this.containerWidth = 25 * this.arrayList.content.length * 1.912;
        // }
      } else if (this.window.innerWidth <= 768 && this.window.innerWidth > 480) {
        if (this.arrayList.type === 'eventbanner') {
               this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
        this.containerWidth = 25 * this.arrayList.content.length * 2;
         } else {
           this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
        this.containerWidth = 25 * this.arrayList.content.length * 1.5;
      }
      } else if (this.window.innerWidth <= 480) {
        if (this.arrayList.content.length !== 1 || this.isDesktop) {
          this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
        } else {
          this.gridWidth = 10;
        }
        if (this.arrayList.type === 'movies'  || this.arrayList.type === 'movie'  || this.arrayList.type === 'movies_details'  ) {

             // this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
             this.containerWidth = 25 * this.arrayList.content.length * 1.5;
             this.isMovieTray = true;

        } else {
        //     if (this.arrayList.content.length !== 1 || this.isDesktop) {
        //   this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
        // } else {
        //   this.gridWidth = 10;
        // }

          if (this.isDesktop === true) {
             if (this.arrayList.type === 'eventbanner') {
              this.containerWidth = 25 * this.arrayList.content.length * 1.75;
            } else {
              this.containerWidth = 25 * this.arrayList.content.length * 2.75;
            }
           } else {
               if (this.arrayList.type === 'eventbanner') {
               this.containerWidth = 42.5 * this.arrayList.content.length * 1.75;
             } else {
               this.containerWidth = 13.96 * this.arrayList.content.length;
             }
           }
           this.isMovieTray = false;
        }
      }
    }
  }
  public ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.localstorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
    this.basePath = this.settingsService.getbasePath();
    if (this.arrayList.type === 'channels') {
      if (this.arrayList.original_length > 6) {
        this.channelCarousal = true;
      }
      this.arrayList.content = this.arrayList.content.slice(0, 6);
      for (let i = 0; i < this.arrayList.content.length; i++) {
        if (this.arrayList.content[i].list_image) {
          this.arrayList.content[i].list_image = this.basePath + this.arrayList.content[i].id + '/list/170x120/' + this.arrayList.content[i].image.list + '.png';
        }
        if (this.arrayList.content[i].cover_image) {
          this.arrayList.content[i].cover_image = this.basePath + this.arrayList.content[i].id + '/list/170x120/' + this.arrayList.content[i].image.cover + '.png';
        }
      }
    }
    if (!(((this.arrayList.parentType === 'search' ||  this.arrayList.link ) || (this.arrayList.type === 'catchUp' && !this.arrayList.more )) && !this.arrayList.modelname && this.arrayList.original_length > 4)) {
        this.ischanneldetails = true;
     }
    setTimeout(() => {
      this.gtm.storeWindowError();
    }, 0);
    this.arrayList.pageNo = 1;
    if (this.arrayList.title) {
      this.gridTitle = this.arrayList;
    } else {
      if (this.arrayList.titleMain) {
        this.gridTitle = this.arrayList.titleMain;
      } else {
        this.gridTitle = '';
      }
    }
    if (this.arrayList.content) {
      this.count = 0;
      this.arrows = true;
      if (this.arrayList.type === 'eventbanner') {
        this.pagecount = 2;
      } else {
        this.pagecount = 4;
      }
      if (this.arrayList.content.length < this.pagecount + 1 || this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
        this.arrows = false;
      } else {
        this.arrows = true;
      }

      this.updatedArray = this.arrayList.content.slice(0, 4);

      if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
        this.scrollEnable = true;
      }
      if (this.window.innerWidth > 768) {
         if (this.arrayList.type === 'eventbanner') {
               this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
           this.containerWidth = 25 * this.arrayList.content.length * 1.612;
         } else {
           this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
           this.containerWidth = 25 * this.arrayList.content.length * 0.941;
         }
      } else if (this.window.innerWidth <= 768 && this.window.innerWidth > 480) {
        if (this.arrayList.type === 'eventbanner') {
               this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
        this.containerWidth = 25 * this.arrayList.content.length * 2;
         } else {
           this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
        this.containerWidth = 25 * this.arrayList.content.length * 1.5; }
      } else if (this.window.innerWidth <= 480) {

        if (this.arrayList.type === 'movies'  || this.arrayList.type === 'movie'  || this.arrayList.type === 'movies_details'  ) {
                            if (this.updatedArray.length !== 1 || this.isDesktop) {
          this.gridWidth = (( 4 * 25) / this.updatedArray.length);
        } else {
          this.gridWidth = 10;
        }
          // this.gridWidth = (( 4 * 25) / (this.updatedArray.length));
          this.containerWidth = 25 * (this.updatedArray.length) * 1.5;
          this.isMovieTray = true;
        } else {
          if (this.arrayList.content.length !== 1 || this.isDesktop) {
          this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
        } else {
          this.gridWidth = 10;
        }
          if (this.isDesktop === true) {
            if (this.arrayList.type === 'eventbanner') {
              this.containerWidth = 25 * this.arrayList.content.length * 1.75;
            } else {
              this.containerWidth = 25 * this.arrayList.content.length * 2.75;
            }
          } else {
             if (this.arrayList.type === 'eventbanner') {
               this.containerWidth = 42.5 * this.arrayList.content.length * 1.75;
             } else {
               this.containerWidth = 25 * this.arrayList.content.length * 1.75;
          }
          }
          this.isMovieTray = false;
        }
      }
    }
    this.sendTalamoosGA();
  }

  private sendTalamoosGA(): any {
    if (this.talamoosImpression && !this.talamoosGA && this.arrayList && this.arrayList.modelname) {
    // if (this.arrayList && this.arrayList.modelname) {
      this.gtm.talamoosGA(this.yIndex, this.arrayList.original_title);
      this.talamoosGA = true;
    }
  }

  public dismiss(event: any, index: any): void {
    // if (event.type === 'advertisement') {
    //   for (let i = 0; i < this.arrayList.content.length; i++) {
    //     if (this.arrayList.content[i].divId && event.divId === this.arrayList.content[i].divId) {
    //          this.arrayList.content.splice(index, 1);
    //     }
    //   }
    //   // this.updatedArray = this.arrayList.content.filter(function(el) {
    //   //   return el.id !== event.id;
    //   // });
    //   this.updatedArray = [];
    //   this.updatedArray = this.arrayList.content.slice(0, 4);
    //   // this.updatedArray.push(this.updatedArray.content.length)
    // } else
    if (event.type === 'missing') {
       this.arrayList.content = this.arrayList.content.filter(function(el) {
        return el.id !== event.id;
      });
      this.updatedArray = [];
      this.updatedArray = this.arrayList.content.slice(0, 4);
    } else {
      this.onChange.emit(event);
    }
    let scope;
    scope = this;
    setTimeout(function() {
      if (event.type !== 'missing' && (scope.arrayList.content.length - index) <= 4 && index > 3) {
      // if (!(event.type === 'advertisement' || event.type === 'missing' ) && (scope.arrayList.content.length - index) <= 4 && index > 3) {
        scope.count += 25;
        scope.element_select.nativeElement.style.marginLeft = scope.count + '%';
      } else if (event.type !== 'missing' &&  scope.arrayList.content.length <= 4 && scope.arrayList.content.length) {
      // } else if (!(event.type === 'advertisement' || event.type === 'missing' ) &&  scope.arrayList.content.length <= 4 && scope.arrayList.content.length) {
        scope.count = 0;
        scope.element_select.nativeElement.style.marginLeft = scope.count + '%';
        scope.arrows = false;
      }
      scope.onResize('event');
    }, 200);
  }
  public previous(): void {
    this.collectionSwipeDetails('right');
    if (this.count < 0) {
      this.currentPosition--;
      this.count += 25;
      if (this.count + 25 === 25 && this.arrayList.content.length === this.pagecount + 1) {
        this.right_arrow = true;
        this.left_arrow = false;
      } else if (this.count + 25 === 25 && this.arrayList.content.length !== this.pagecount + 1) {
        this.right_arrow = true;
        this.left_arrow = false;
      } else if (this.count < - (this.arrayList.content.length - this.pagecount) * 25 + 50) {
         this.right_arrow = true;
      }
      if (this.arrayList.type === 'eventbanner') {
        this.element_select.nativeElement.style.marginLeft = (this.count * 40.6 / 25) + '%';
      } else {
        this.element_select.nativeElement.style.marginLeft = (this.count * 23.525 / 25) + '%';
      }
      // this.element_select.nativeElement.style.marginLeft = this.count + '%';
    }

  }
  public next(): void {
    this.collectionSwipeDetails('left');
    if ((this.currentPage < this.totalPages - 1 ) && (this.currentPosition % this.pagecount === 0)) {
      this.currentPage ++;
      // this.index_limit = this.index_limit + this.pageSize;
      this.updateArray();
    } else if (this.currentPage === this.totalPages - 1) {
      this.currentPage ++;
      // this.index_limit = this.arrayList.content.length;
      this.updateArray();
    }
    if (this.count >= - (this.arrayList.content.length - this.pagecount) * 25 + 25) {
      let last;
      this.currentPosition ++;
      this.count -= 25;
      if (this.count === -25 && this.arrayList.content.length === this.pagecount + 1) {
        this.left_arrow = true;
        this.right_arrow = false;
      } else if (this.count === -25 && this.arrayList.content.length !== this.pagecount + 1) {
       this.left_arrow = true;
      } else if ( this.count <= -(this.arrayList.content.length - this.pagecount) * 25 ) {
        if (this.screen && (this.pagenumber + 1) <= this.arrayList.pages) {
          this.nextpage.emit(true);
          // this.next_select.nativeElement.src = this.assetBasePath + 'assets/common/right_nav_selected.png';
          this.right_arrow = true;
        } else {
          last = true;
           this.right_arrow = false;
        }
      } this.element_select.nativeElement.style.marginLeft = this.count + '%';
      if (last) {
        if (this.arrayList.type === 'eventbanner') {
          this.element_select.nativeElement.style.marginLeft = ((this.count * 40.6 / 25) + (43 / this.pagecount)) + '%';
        } else {
          this.element_select.nativeElement.style.marginLeft = ((this.count * 23.525 / 25) + (23.525 / this.pagecount)) + '%';
        }
      } else {
        if (this.arrayList.type === 'eventbanner') {
          this.element_select.nativeElement.style.marginLeft = (this.count * 20.3 * 2 / 25) + '%';
        } else {
          this.element_select.nativeElement.style.marginLeft = (this.count * 23.525 / 25) + '%';
        }
      }
    }
  }

  // public onScrollDown() {
  // }

  // public update(event: any) {
  // }

  // public track(event: any): void {
  //   // console.log("Scroll Mani");
  // }

  public scrollData(event: any) {
    let fetchdetailPercentage = 0.625;
    if ((this.arrayList.type === 'movies'  || this.arrayList.type === 'movie'  || this.arrayList.type === 'movies_details'  )) {
      fetchdetailPercentage = 0.275;
    } else {
        fetchdetailPercentage = 0.625;
    }
    if (this.element_parent.nativeElement.scrollLeft  >=  (fetchdetailPercentage * (this.element_parent.nativeElement.scrollWidth * (this.index_limit / this.arrayList.content.length) - this.element_parent.nativeElement.clientWidth))) {
      if (this.index_limit < this.arrayList.content.length) {
        if ((this.currentPage < this.totalPages - 1 ) && (this.currentPosition % 4 === 0)) {
          this.currentPage ++;
        } else if (this.currentPage === this.totalPages - 1) {
          this.currentPage ++;
        }
        this.updateArray();
        this.updateParentContainerWidth();
      }
    }
    // swipe right left capture
    clearTimeout(this.scrollEvent);
    this.scrollEvent = setTimeout(() => {
      if (this.scrollLeft < event.path[0].scrollLeft) {
        this.collectionSwipeDetails('left');
      } else {
        this.collectionSwipeDetails('right');
      }
      this.scrollLeft = event.path[0].scrollLeft;
    }, 100);
    // setTimeout(()=>{},0);
  }

  public updateArray() {
    if (this.arrayList.next_url && !this.processPending && this.currentPage === this.totalPages - 1) {
      this.apiRetryCount = 1;
      if (this.arrayList.parentType && this.arrayList.parentType.match(/recommended|related/i)) {
        this.appendDataNews();
      } else if (this.arrayList.parentType && this.arrayList.parentType === 'moreinfo') {
        this.appendDataNewsMore();
      } else {
        this.appendData();
      }
    }
    if (!this.isDesktop) {
      let item;
      item = this.arrayList.content.slice(this.index_limit, (this.index_limit + 4));
      if (item) {
        for (let index = 0; index < item.length ; index ++) {
          this.updatedArray.push(item[index]);
        }
        this.index_limit = this.index_limit + 4;
      }
    } else {
     this.index_limit = this.index_limit + 4;
    }


  }

  public appendData(): any {
    this.processPending = true;
    this.commonService.nextData(this.arrayList.next_url).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
      this.apiRetryCount = 1;
      this.processPending = false;
      this.arrayList.content = this.arrayList.content.concat(value[this.arrayList.category]);
      this.totalPages = Math.ceil(this.arrayList.content.length / this.pageSize);
      this.arrayList.next_url = value['next_' + this.arrayList.category + '_api'];
      this.updateParentContainerWidth();
      // console.log(value, this.arrayList);
    },
    err => {
      this.processPending = false;
      if (err.status === 401 && this.apiRetryCount < this.apiRetry) {
        this.apiRetryCount ++;
        this.commonService.refreshToken().then(
        () => {
          this.appendData();
        },
        // () => {},
        );
      }
    });
  }

  public appendDataNews(): any {
    if (this.arrayList.pageNo >= this.arrayList.next_url) {
      return;
    }
    this.processPending = true;
    let x, apiconfig, userType;
    apiconfig = {
      apiKey: ' ',
      username: ' ',
      password: ' ',
      accessToken: ' ',
      withCredentials: false
    };
    x = new CollectionApi(this.http, null, apiconfig);
    userType = this.commonService.getUserType();
    x.v1DetailNewsCollectionByIdGet(this.arrayList.parentType, this.arrayList.api_details.news_id, (this.arrayList.pageNo + 1), null, 25, this.arrayList.api_details.genre, this.arrayList.api_details.content_owner, null, null, null, null, userType).timeout(environment.timeOut).takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.apiRetryCount = 1;
      this.arrayList.pageNo++;
      this.processPending = false;
      value.buckets = this.commonService.removeWebView(value.buckets);
      this.arrayList.content = this.arrayList.content.concat(value.buckets[0].items);
      this.totalPages = Math.ceil(this.arrayList.content.length / this.pageSize);
      // this.arrayList.next_url--;
      this.updateParentContainerWidth();
      // console.log(value, this.arrayList);
    },
    err => {
      this.processPending = false;
      if (err.status === 401 && this.apiRetryCount < this.apiRetry) {
        this.apiRetryCount ++;
        this.commonService.refreshToken().then(
        () => {
          this.appendDataNews();
        },
        // () => {},
        );
      }
    });
  }

  public appendDataNewsMore(): any {
    if (this.arrayList.pageNo >= this.arrayList.next_url) {
      return;
    }
    this.processPending = true;
    let x, apiconfig, userType;
    apiconfig = {
      apiKey: ' ',
      username: ' ',
      password: ' ',
      accessToken: ' ',
      withCredentials: false
    };
    x = new CollectionApi(this.http, null, apiconfig);
    userType = this.commonService.getUserType();
    x.v1ChannelNewsCollectionByIdGet('news', null, (this.arrayList.pageNo + 1), null, 25, null, this.arrayList.api_details.content_owner, null, null, null, null, userType).timeout(environment.timeOut).takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.apiRetryCount = 1;
      this.arrayList.pageNo++;
      this.processPending = false;
      value.buckets = this.commonService.removeWebView(value.buckets);
      this.arrayList.content = this.arrayList.content.concat(value.buckets[0].items);
      this.totalPages = Math.ceil(this.arrayList.content.length / this.pageSize);
      // this.arrayList.next_url--;
      this.updateParentContainerWidth();
      // console.log(value, this.arrayList);
    },
    err => {
      this.processPending = false;
      if (err.status === 401 && this.apiRetryCount < this.apiRetry) {
        this.apiRetryCount ++;
        this.commonService.refreshToken().then(
        () => {
          this.appendDataNewsMore();
        },
        // () => {},
        );
      }
    });
  }

  public updateParentContainerWidth() {
    if (this.window.innerWidth > 768) {
      if (this.arrayList.type === 'eventbanner') {
               this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
           this.containerWidth = 50 * this.arrayList.content.length * 0.941;
         } else {
           this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
           this.containerWidth = 25 * this.arrayList.content.length * 0.941;
        // this.containerWidth = 25 * this.arrayList.content.length;
         }
    } else if (this.window.innerWidth <= 768 && this.window.innerWidth > 480) {
      if (this.arrayList.type === 'eventbanner') {
               this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
        this.containerWidth = 50 * this.arrayList.content.length * 1.5;
         } else {
           this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
        this.containerWidth = 25 * this.arrayList.content.length * 1.5;
      }
    } else if (this.window.innerWidth <= 480) {
      if (this.arrayList.type === 'movies'  || this.arrayList.type === 'movie'  || this.arrayList.type === 'movies_details'  ) {
        let addedcardlength;
        addedcardlength = ((this.updatedArray.length) < (this.arrayList.content.length) ) ? (this.updatedArray.length ) : this.arrayList.content.length;
        this.gridWidth = (( 4 * 25) / (addedcardlength));
        this.containerWidth = 25 * (addedcardlength) * 1.5;
        this.isMovieTray = true;
      } else {
        this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
        // this.containerWidth = 25 * this.arrayList.content.length * 2.75;
        this.containerWidth = 13.96 * this.arrayList.content.length;
        this.isMovieTray = false;
      }
    }
  }

  public onResize(event: any): void {
    if (this.arrayList.content.length < this.pageSize + 1 || this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
      this.arrows = false;
    } else {
      this.arrows = true;
    }
    if (this.window.innerWidth > 768 && this.index_limit === this.pagecount) {
      this.index_limit = this.pagecount + 1;
    }
    if (this.window.innerWidth > 768) {
      if (this.arrayList.type === 'eventbanner') {
              this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
              this.containerWidth = 25 * this.arrayList.content.length * 1.612;
         } else {
             this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
             this.containerWidth = 25 * this.arrayList.content.length * 0.941;
        }
    } else if (this.window.innerWidth <= 768 && this.window.innerWidth > 480) {
        if (this.arrayList.type === 'eventbanner') {
               this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
                this.containerWidth = 25 * this.arrayList.content.length * 2;
         } else {
           this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
        this.containerWidth = 25 * this.arrayList.content.length * 1.5;
    }
    } else if (this.window.innerWidth <= 480) {
      if (this.arrayList.type === 'movies'  || this.arrayList.type === 'movie'  || this.arrayList.type === 'movies_details'  ) {
        // this.containerWidth = 25 * (this.updatedArray.length + 2)* 1.5;
        // this.gridWidth = (( 4 * 25) / (this.updatedArray.length+ 2));
        if (this.updatedArray.length !== 1 || this.isDesktop) {
          this.gridWidth = (( 4 * 25) / this.updatedArray.length);
        } else {
          this.gridWidth = 10;
        }
        this.containerWidth = 25 * (this.updatedArray.length) * 1.5;
        // this.gridWidth = (( 4 * 25) / (this.updatedArray.length));
        // 13% required
        this.isMovieTray = true;
      } else {
      //   if (this.arrayList.content.length !== 1 || this.isDesktop) {
      //   this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
      // } else {
      //   this.gridWidth = 10;
      // }
      if (this.isDesktop === true) {
          if (this.arrayList.type === 'eventbanner') {
              this.containerWidth = 50 * this.arrayList.content.length * 1.75;
            } else {
              this.containerWidth = 25 * this.arrayList.content.length * 2.75;
            }
        } else {
           if (this.arrayList.type === 'eventbanner') {
               this.containerWidth = 42.5 * this.arrayList.content.length * 2;
             } else {
               this.containerWidth = 13.96 * this.arrayList.content.length;
             }
        }
       this.isMovieTray = false;
      }
    }
  }

  public sublandingRoute() {
    this.commonService.sendLanguages(true);
    let tempTitle;
    // if (this.arrayList && this.arrayList.extended && this.arrayList.extended.seo_title) {
    //     tempTitle = (this.arrayList.extended.seo_title !== null || this.arrayList.extended.seo_title !== undefined || this.arrayList.extended.seo_title !== '') ? this.arrayList.extended.seo_title : this.arrayList.original_title;
    // } else {
    //     tempTitle = (this.arrayList.seo_title && (this.arrayList.seo_title !== null || this.arrayList.seo_title !== undefined || this.arrayList.seo_title !== '')) ? this.arrayList.seo_title : this.arrayList.original_title;
    // }
      tempTitle = this.arrayList.original_title;
    if (this.networkService.getPopupStatus()) {
      if (this.arrayList.parentType === 'seasons' ) {
        if (this.arrayList.orderid !== 1) {
            this.router_link.navigate(['/' + (this.arrayList.asset_subtype === 'original' ? 'zee5originals' : 'tvshows') + '/details/' + this.commonService.convertToLowercase(this.arrayList.content[0].tvshow_details.original_title) + '/' + this.arrayList.id + '/' + 'season-' + this.arrayList.orderid + '/episodes']);
        } else {
            this.router_link.navigate(['/' + (this.arrayList.asset_subtype === 'original' ? 'zee5originals' : 'tvshows') + '/details/' + this.commonService.convertToLowercase(this.arrayList.content[0].tvshow_details.original_title) + '/' + this.arrayList.id + '/episodes']);
        }
      } else if (this.arrayList.parentType === 'search' ) {
        this.router_link.navigate(['/search', this.arrayList.search_category , 'result'], { queryParams: { q: this.arrayList.query} });
      } else if (this.arrayList.type === 'catchUp') {
        this.router_link.navigate(['/' + (this.arrayList.asset_subtype === 'original' ? 'zee5originals' : 'tvshows') + '/details', this.commonService.convertToLowercase(tempTitle) , this.arrayList.id , 'episodes' ] );
      } else if (this.arrayList.type === 'channels') {
        this.router_link.navigate(['channels']);
      } else {
        this.settingsService.setpage(this.pagename);
        this.router_link.navigate(['collections', this.commonService.convertToLowercase(tempTitle), this.arrayList.id]);
      }
    }
    this.sendButtonClickDetails('view all');
  }
  public onHover(index): void {
    this.channelHover[index] = true;
  }
  public noHover(index): void {
    this.channelHover[index] = false;
  }
  public routeChannel(name: any, id: any, xIndex: any, yIndex: any) {
    let show_title = name.toLowerCase().replace(/ /g, '-');
    show_title = show_title.replace(/---/g, '-');
    show_title = show_title.replace(/&/g, 'and');
    this.router_link.navigate(['channels/details', show_title, id ]);
  }
  public channelSrcError (event: any) {
    if (event.srcElement) {
      event.srcElement.src =  environment.assetsBasePath + 'assets/default/epg_channel_logo.png';
    } else {
      event.currentTarget.src =  environment.assetsBasePath + 'assets/default/epg_channel_logo.png';
    }
  }
  public ngOnDestroy(): any {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }
  // send clicks on Collection Carousal
  public collectionSwipeDetails(direction) {
    let swipeDetails;
    swipeDetails = {
      'event': 'swipeClick',
      'SwipeType': 'collection',
      'SwipeDirection': direction,
      'SubCategory': this.arrayList.original_title ? this.arrayList.original_title : 'NA',
      'Vertical_Index': this.yIndex || (this.yIndex !== 0 ? 'NA' : this.yIndex)
    };
    this.gtm.sendEventDetails(swipeDetails);
  }
  public sendButtonClickDetails(ctadetails) {
    let buttonDetails;
    buttonDetails = {
      'event': 'buttonClicks',
      'cta': ctadetails,
      'SubCategory': this.arrayList.original_title ? this.arrayList.original_title : 'NA'
    };
    setTimeout(() => {
      this.gtm.sendEventDetails(buttonDetails);
    }, 100);
  }
}
