import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ScrollListComponent } from './scroll-list.component';
import { SharedModule } from '../shared.module';
import { HomeGridModule } from '../home-grid/home-grid.module';


@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    HomeGridModule
  ],
  declarations: [ScrollListComponent],
  exports: [ScrollListComponent]

})
export class ScrollListModule {
}



