import { Component, ViewChild, OnInit, OnDestroy, HostListener, Renderer2 } from '@angular/core';
import { FilterService } from '../services/filter.service';
import * as $ from 'jquery';
import { Router } from '@angular/router';
import { HeaderservicesService } from '../services/headerservices.service';
import { SettingsService } from '../services/settings.service';
import { Subscription } from 'rxjs/Subscription';
import { Headers, Http , RequestOptions, Response} from '@angular/http';
import { ActivatedRoute } from '@angular/router';
import {CollectionApi} from '../../data/gwapi_catalog/api/CollectionApi';
import {WatchHistoryApi} from '../../data/user/api/api';
import * as userApi from '../../data/user/api/api';
import { RouteService } from '../services/route.service';
// import { SignInComponent } from '../sign-in/sign-in.component';
import { Location } from '@angular/common';
import { UserProfileService } from '../services/user-profile.service';
import {environment} from '../../environments/environment';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import {  NetworkService  } from '../services/network.service';
import {CommonService} from '../services/common.service';
import { isPlatformBrowser, DOCUMENT } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { LinkService } from '../services/link.service';
import { EpgService } from '../services/epg.service';
import { SubscriptionService } from '../services/subscription.service';
import { UseractionapiService } from '../services/useractionapi.service';
import { RequestMethod, RequestOptionsArgs } from '@angular/http';
// import * as api from '../../data/catalog/api/api';
import { EpgApi } from '../../data/catalog/api/EpgApi';
import { SeoService } from '../services/seo.service';
declare let googletag;
declare const qg;
import 'rxjs/add/operator/timeout';

const freeChannelTag = 'free_channels';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.less']
})
export class HomeComponent implements OnInit, OnDestroy {
  public collectionTags: any;
  public localPARstorage: any = [];
  public showpaytmpopup = false;
  public paytmIndex: any = -1;
  public color: string;
  public mode: string;
  public type: any;
  public value: number;
  public bufferValue: number;
  public continueShows: any;
  public recommended: any;
  public popular: any;
  public new: any;
  public popularItems: any;
  public channels: any;
  public banner: any;
  public channelData: any;
  public interface: string;
  public count: any = 0;
  public count1: number;
  public count2: number;
  public count3: number;
  public count4: number;
  public carousel: any;
  public modalVideoPopup = false;
  public modalVideoDetails: any;
  public carouselFlag: any;
  public channelHover: any;
  public languages_api: any;
  public router: any;
  public router2: any;
  public data: any;
  public popularTitle: any;
  public channelsTitle: any;
  public sub: any;
  public param: any;
  public id: any;
  public register: any;
  public code: any = '';
  public forgotcode: any = '';
  public params: any;
  public popularData: any;
  public dataAvailable: any = true;
  public carouselTitle: any;
  public val: any;
  public token: any;
  public userapi: any;
  public displayLang: any;
  public contentLang: any;
  public getToken: any;
  public userType: any;
  public basepath: any;
  public pageName: any;
  public homepageData: any;
  // public totalAds: any;
  public googletagAvailable: any;
  public collectionPageNo = 1;
  public totalCollectionPages: any;
  public collectionPageSize: any = 5;
  public config: any;
  public processPending: any = false;
  public touchScreen: any;
  public assetBasePath = environment.assetsBasePath;
  public tagValue: any;
  // public desktopTag: any;
  // public mobileTag: any;
  public nativeTag: any;
  public nativeAdPosition: any;
  public popularShow: any;
  public currentRoute: any;
  public carouselCollection: any;
  public scrollListData: any;
  public trailerChange: any;
  public movieApi: any;
  public trailerShow: any;
  public genres: any;
  public seasonApi: any;
  public languageData: any;
  // public divDesktop: any;
  // public divMobile: any;
  // public adSpacing: any = 3;
  public timer: any = [];
  public popularTitle_en: any;
  public localstorage: any;
  public window: any;
  public document: any;
  public navigator: any;
  public channelsTitleEng: any;
  public link: any;
  public count_ad: any = 0;
  // public ads_sum: any = 0;
  public mobile = false;
  public showPopup = false;
  public countryCode: any;
  public serverTime: any;
  public showViewAll = false;
  public premiumPage: any;
  public newsPage: any;
  public collectionID: any;
  public mastTag: any;
  public mastDivID: any;
  public mastHeadStyle: any;
  public plans: any;
  public premiumUser: any = false;
  public convivaData: any;
  public convivaContent: any = [];
  public content: any;
  public serverUrl: any = environment.serverTimeUrl;
  public gdpr = false;
  public paytmPack: any;
  public paytmFlag = false;
  public today: any;
  public configValue: any;
  public currentCountry: any;
  public titleText: any;
  public itemLimit: any = 20;
  public apiRetry: any = 2;
  public apiRetryCount: any = 1;
  public historyRetryCount: any = 1;
  public showMastAds: any = false;
  public mastHeadAds: any;
  public mastAd: any = false;
  public adSlot: any;
  public showNativeAds: any = false;
  public nativeAds: any;
  private checkUrl: any;
  public infiniteScrollDistance: any = 0.5;
  private countryListget: any;
  private collectionsWeb: any;
  private collectionsConfig: any;
  public version: any;
  public platform: any;
  public languages: any;
  public newsPageResult: any;
  public newsPageData: any;
  public newsPageObj = false;
  private ngUnsubscribe = new Subject<any>();
  public traylength: any = 0;
  public breadcrump: any = '';
  private gwapidata = false;
  private watchlistdata = false;
  private livetvdata = false;
  public addIndex: any = 0;
  private adsInitialized: any = 0;
  public scrollCount: any = 0;
  public musicNode = false;
  public talamoosImpression: any;

  public footerAd: any;
  private skippedAdIndex: any;
  public footerAdRendered: any = false;
  public footerAdSlot: any;
  constructor(
    private subscriptionService: SubscriptionService ,
    private userAction: UseractionapiService,
    private epgService: EpgService,
    private linkservice: LinkService,
    @Inject(PLATFORM_ID) private platformId: Object,
    private commonService: CommonService,
    private networkService: NetworkService,
    private location: Location,
    private filterService: FilterService,
    private userProfileService: UserProfileService,
    private router_link: Router,
    private route: ActivatedRoute,
    private headerservicesService: HeaderservicesService,
    private settingsService: SettingsService,
    private http: Http,
    private routeservice: RouteService,
    private gtm: GoogleAnalyticsService,
    private seoservice: SeoService,
    private renderer2: Renderer2,
    @Inject(DOCUMENT) private doc: Document
    ) {
    let scope;
    scope = this;
    if (isPlatformBrowser(this.platformId)) {
      this.localstorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
    this.version = this.window.appVersion;
    this.platform = this.navigator.userAgent.match(/mobile|iPhone|iPod|iPad/i) ? 'Web Mobile' : 'Web Desktop';
    this.router = router_link;
    this.router2 = this.window.location.pathname;
    this.routeservice.setRoute(this.router2);
    this.headerservicesService.viewChange(this.router2);
    if (this.router.url.match(/premium/g)) {
      this.premiumPage = true;
    } else {
      this.premiumPage = false;
    }
    if (this.router.url.match(/news/g)) {
      this.newsPage = true;
    } else {
      this.newsPage = false;
    }
    this.settingsService.gdprValue.subscribe(value => {
      this.gdpr = value;
      this.travellingUser();
    });
     this.subscriptionService.traveller.takeUntil(this.ngUnsubscribe).subscribe(value => {
      setTimeout (() => {
        // console.log(value, 'value')
         if (!value) {
           this.showPopup = false;
           this.checkPARPack();
         }
      }, 0);
    });
    this.subscriptionService.nextPopup.takeUntil(this.ngUnsubscribe).subscribe(value => {
       this.showpaytmpopup = false;
       if (value !== -1) {
          setTimeout (() => { this.paytmpopup(); }, 10);
       } else {
          this.showpaytmpopup = false;
       }
    });
    this.settingsService.musicnodeValue.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.musicNode = value
    });
  }
  public ngOnInit() {
    this.gtm.storeWindowError();
    this.carousel = undefined;
    this.adsInitialized = false;
    this.countryCode = this.settingsService.getCountry();
    this.countryListget  = this.settingsService.getCountryValueNew();
    this.collectionsWeb = (this.countryListget && this.countryListget[0] && this.countryListget[0].collections && this.countryListget[0].collections.web_app !== null) ? this.countryListget[0].collections.web_app : undefined;
    if (isPlatformBrowser(this.platformId)) {
      this.localstorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
    if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
      this.touchScreen = true;
      this.infiniteScrollDistance = 6;
    }
    this.configValue = this.settingsService.getCompleteConfig();
    this.collectionsConfig = (this.configValue && this.configValue.collections && this.configValue.collections.web_app !== null) ? this.configValue.collections.web_app : undefined;
    // this.plans = this.subscriptionService.checkPlanApiSuccess(false);
    // if (this.plans && this.plans.length > 0) {
    //   this.premiumUser = true;
    // }
    if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
      this.mobile = true;
    }

    if (this.mobile === false) {
      this.collectionPageSize = 5;
    } else {
      this.collectionPageSize = 3;
    }


    if (this.networkService.getScreenStatus()) {
      this.filterService.setView('home');
      if (this.premiumPage) {
        this.currentCountry = this.settingsService.getCountryValueNew();
        if (this.currentCountry && this.currentCountry[0] && this.currentCountry[0].menu_options.premium_menu === 'no') {
          this.titleText = 'MENU.EXCLUSIVE';
          this.breadcrump = 'MENU.EXCLUSIVE';
          this.updateBreadCrump(this.breadcrump);
        } else {
          this.titleText = 'COMMON.PREMIUM';
          this.breadcrump = 'BREADCRUMB.PREMIUM';
          this.updateBreadCrump(this.breadcrump);
        }
        if (this.collectionsWeb !== undefined && this.collectionsWeb.premium) {
          this.collectionID = this.collectionsWeb.premium;
        } else if (this.collectionsConfig !== undefined && this.collectionsConfig.premium) {
          this.collectionID = this.collectionsConfig.premium;
        } else {
          this.collectionID = environment.premiumPageCollectionId;
        }

        this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'premium'  } );
        this.commonService.qgraphevent('Premiumpage_visited', {'country': this.countryCode, 'state': this.localstorage.getItem('state_code')});

        //  send page name for GA
        this.pageName = 'premium';
        this.gtm.sendPageName(this.pageName);
        this.gtm.sendEvent();
        this.settingsService.bluekaiPagename('premium');
        this.token = this.localstorage.getItem('token');
        if (this.token) {
          this.userProfileService.httpgetFavoriteData();
          this.userProfileService.httpgetWatchData();
        }
        this.routeservice.setLoginRoute(this.window.location.pathname);

      } else if (this.newsPage) {
        let token: string;
         token = localStorage.getItem('token');
        if (token) {
            this.languages = localStorage.getItem('UserContentLanguage');
        } else {
            this.languages = localStorage.getItem('ContentLang');
        }
        if(this.countryCode == 'DE'){
          this.breadcrump = 'MENU.NEWS_DE';
        }
        else{this.breadcrump = 'NEWS_PAGE.NEWS';}
        this.updateBreadCrump('NEWS_PAGE.NEWS');
        this.currentCountry = this.settingsService.getCountryValueNew();
        // this.titleText = 'NEWS_PAGE.NEWS';
        // if (this.currentCountry && this.currentCountry[0] && this.currentCountry[0].menu_options.premium_menu === 'no') {
        //   this.titleText = 'MENU.EXCLUSIVE';
        // } else {
        //   this.titleText = 'COMMON.PREMIUM';
        // }
        this.musicNode = this.settingsService.getconsiderMusicnode();
        if (this.musicNode) { // Ru changes
          if (this.collectionsWeb !== undefined && this.collectionsWeb.music) {
            this.collectionID = this.collectionsWeb.music;
          } else if (this.collectionsConfig !== undefined && this.collectionsConfig.news) {
            this.collectionID = this.collectionsConfig.news;
          } else {
            this.collectionID = environment.premiumPageCollectionId;
          }
        } else {
          if (this.collectionsWeb !== undefined && this.collectionsWeb.news) {
            this.collectionID = this.collectionsWeb.news;
          } else if (this.collectionsConfig !== undefined && this.collectionsConfig.news) {
            this.collectionID = this.collectionsConfig.news;
          } else {
            this.collectionID = environment.premiumPageCollectionId;
          }
        }
        // this.tagValue = this.settingsService.getCompleteConfig();
        // if (!this.premiumUser && this.tagValue && this.tagValue.ads && this.tagValue.ads.web && this.tagValue.ads.web.news && this.tagValue.ads.web.news.mobile && this.tagValue.ads.web.news.desktop) {
        //   this.desktopTag = this.tagValue.ads.web.news.desktop;
        //   this.mobileTag =  this.tagValue.ads.web.news.mobile;
        // }
      //   this.getServerTime();
        // this.showMastAds = this.tagValue && this.tagValue.masthead_ads && this.tagValue.masthead_ads.web && (this.premiumUser && this.tagValue.masthead_ads.web.premium_user && (this.tagValue.masthead_ads.web.premium_user[this.countryCode] === undefined ? this.tagValue.masthead_ads.web.premium_user['default'] : this.tagValue.masthead_ads.web.premium_user[this.countryCode])) || !this.premiumUser;
        // if (this.showMastAds && this.mobile &&  this.tagValue.masthead_ads.web['mobile'] && this.tagValue.masthead_ads.web['mobile'].news && this.tagValue.masthead_ads.web['mobile'].news[0]) {
        //   this.mastTag = this.tagValue.masthead_ads.web['mobile'].news[0].ad_tag;
        //   this.mastDivID = this.tagValue.masthead_ads.web['mobile'].news[0].div_id;
        // }
        this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'news'  } );
       // todoooooo
        this.commonService.qgraphevent('Newspage_visited', {'country': this.countryCode, 'state': this.localstorage.getItem('state_code')});

        //  send page name for GA
        this.pageName = 'news';
        this.gtm.sendPageName(this.pageName);
        this.gtm.sendEvent();
        this.settingsService.bluekaiPagename('news');
        this.token = this.localstorage.getItem('token');
        if (this.token) {
          this.userProfileService.httpgetFavoriteData();
          this.userProfileService.httpgetWatchData();
        }
        this.routeservice.setLoginRoute(this.window.location.pathname);
          if (!this.musicNode) {  // Ru changes
            this.fetchCall();
          } else {
            this.getYIndex();
            this.livetvdata = true;
            this.loadervisible(); // gwapihomedata,watchlistdata,livedata
          }
      }  else {

        let paytmscreen;
        paytmscreen = this.subscriptionService.getpaytmpopup();
        if (!paytmscreen) {
               this.showPopup = false;
               this.checkPARPack();
             }
        this.pageName = 'home';
        if (this.collectionsWeb !== undefined && this.collectionsWeb.home) {
         this.collectionID = this.collectionsWeb.home;
        } else if (this.collectionsConfig !== undefined && this.collectionsConfig.home) {
          this.collectionID = this.collectionsConfig.home;
        } else {
          this.collectionID = environment.homePageCollectionId;
        }
        // this.tagValue = this.settingsService.getCompleteConfig();
        // if (!this.premiumUser && this.tagValue && this.tagValue.ads && this.tagValue.ads.web && this.tagValue.ads.web.home && this.tagValue.ads.web.home.mobile && this.tagValue.ads.web.home.desktop) {
        //   this.desktopTag = this.tagValue.ads.web.home.desktop;
        //   this.mobileTag =  this.tagValue.ads.web.home.mobile;
        // }
      //   this.getServerTime();
      // this.showMastAds = this.tagValue && this.tagValue.masthead_ads && this.tagValue.masthead_ads.web && (this.premiumUser && this.tagValue.masthead_ads.web.premium_user && (this.tagValue.masthead_ads.web.premium_user[this.countryCode] === undefined ? this.tagValue.masthead_ads.web.premium_user['default'] : this.tagValue.masthead_ads.web.premium_user[this.countryCode])) || !this.premiumUser;
      // if (this.showMastAds && this.mobile &&  this.tagValue.masthead_ads.web['mobile'] && this.tagValue.masthead_ads.web['mobile'].home && this.tagValue.masthead_ads.web['mobile'].home[0]) {
      //   this.mastTag = this.tagValue.masthead_ads.web['mobile'].home[0].ad_tag;
      //   this.mastDivID = this.tagValue.masthead_ads.web['mobile'].home[0].div_id;
      // }
     // this.settingsService.bluekaiPagename('home');
      this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation() } );
      this.commonService.qgraphevent('Homepage_visited', {'country': this.countryCode, 'state': this.localstorage.getItem('state_code')});

        // send page name for GA
        this.userapi = new userApi.UserApi(this.http, null, null);
        this.route.queryParams.subscribe(queryparams => {
          this.code = queryparams ['code'];
          this.forgotcode = queryparams ['code'];
          this.routeservice.setcode(this.code);
          this.routeservice.setforgotcode(this.forgotcode);

        });
        if (this.route.params) {
          this.routeservice.setRoute('/');
          this.sub = this.route.params.subscribe(params => {
            this.id = params ['id'];
          });
          if (this.router.url.indexOf('/signin/mobile') >= 0 ) {
            this.pageName = 'sign in';
            this.settingsService.bluekaiPagename('login');
            this.gtm.sendPageName(this.pageName);
            // this.gtm.sendEvent();
            if (this.localstorage.getItem('country_code') === 'IN') {
              this.headerservicesService.signinChange(true);
              this.routeservice.Signal('/signin/mobile');
            } else {
              this.headerservicesService.internationalRegisterChange(true);
              this.routeservice.Signal('/signin/mobile');
            }
            this.headerservicesService.modelChange(true);
          } else if (this.router.url.indexOf('/signin/email') >= 0 ) {
              this.pageName = 'sign in';
              this.settingsService.bluekaiPagename('login');
              this.gtm.sendPageName(this.pageName);
              // this.gtm.sendEvent();
              if (this.localstorage.getItem('country_code') === 'IN') {
                this.headerservicesService.signinChange(true);
                this.routeservice.Signal('/signin/email');
              } else {
                this.headerservicesService.internationalRegisterChange(true);
                this.routeservice.Signal('/signin/email');
              }
              this.headerservicesService.modelChange(true);
          } else if (this.router.url.indexOf('/signin') >= 0 ) {
              this.pageName = 'sign in';
              this.settingsService.bluekaiPagename('login');
              this.gtm.sendPageName(this.pageName);
              // this.gtm.sendEvent();
              if (this.localstorage.getItem('country_code') === 'IN') {
                this.headerservicesService.signinChange(true);
              } else {
                this.headerservicesService.internationalRegisterChange(true);
                this.routeservice.Signal('/signin');
              }
              this.headerservicesService.modelChange(true);
          } else if (this.router.url.indexOf('/register/mobile') >= 0 ) {
            this.routeservice.Signal('/register/mobile');
            if (this.localstorage.getItem('country_code') === 'IN') {
              this.headerservicesService.signinChange(true);
            } else {
              this.headerservicesService.internationalRegisterChange(true);
            }
            this.headerservicesService.modelChange(true);
          } else if (this.router.url.indexOf('/register/email') >= 0 ) {
            this.routeservice.Signal('/register/email');
            if (this.localstorage.getItem('country_code') === 'IN') {
              this.headerservicesService.signinChange(true);
            } else {
              this.headerservicesService.internationalRegisterChange(true);
            }
            this.headerservicesService.modelChange(true);
          } else if (this.router.url.indexOf('/register') >= 0 ) {
              this.routeservice.Signal('register');
              if (this.localstorage.getItem('country_code') === 'IN') {
                this.headerservicesService.signinChange(true);
              } else {
              this.headerservicesService.internationalRegisterChange(true);
              }
             this.headerservicesService.modelChange(true);
          } else if (this.router.url.indexOf('/search') >= 0) {
             this.settingsService.bluekaiPagename('search');
            this.headerservicesService.searchIcon(true);
          } else if (this.router.url.indexOf('/language') >= 0) {
              this.settingsService.bluekaiPagename('language');
              this.headerservicesService.languageIcon(true);
          } else if (this.router.url.indexOf('/verify?code=') >= 0) {
            this.settingsService.bluekaiPagename('verify');
            this.headerservicesService.modelChange(true);
            this.routeservice.Signal(this.router.url);
            this.headerservicesService.signinChange(true);
          } else if (this.router.url.indexOf('/forgotpassword/mobile') >= 0) {
            this.settingsService.bluekaiPagename('forgotpassword');
            this.routeservice.Signal('/forgotpassword/mobile');
            this.headerservicesService.modelChange(true);
            if (this.localstorage.getItem('country_code') === 'IN') {
              this.headerservicesService.signinChange(true);
            } else {
              this.headerservicesService.internationalRegisterChange(true);
            }
          } else if (this.router.url.indexOf('/forgotpassword/email') >= 0) {
            this.settingsService.bluekaiPagename('forgotpassword');
            this.routeservice.Signal('/forgotpassword/email');
            this.headerservicesService.modelChange(true);
            if (this.localstorage.getItem('country_code') === 'IN') {
              this.headerservicesService.signinChange(true);
            } else {
              this.headerservicesService.internationalRegisterChange(true);
            }
          } else if (this.router.url.indexOf('/forgotpassword') >= 0) {
            this.settingsService.bluekaiPagename('forgotpassword');
            this.routeservice.Signal('/forgotpassword');
            this.headerservicesService.modelChange(true);
            if (this.localstorage.getItem('country_code') === 'IN') {
              this.router_link.navigate(['/pagenotfound']);
            } else {
              this.headerservicesService.internationalRegisterChange(true);
            }
          } else if (this.router.url.indexOf('/resetpassword?code=') >= 0) {
            this.settingsService.bluekaiPagename('resetpassword');
            this.headerservicesService.modelChange(true);
            this.routeservice.Signal(this.router.url);
            if (this.localstorage.getItem('country_code') === 'IN') {
              this.headerservicesService.signinChange(true);
            } else {
              this.headerservicesService.internationalRegisterChange(true);
            }
          } else {
          this.settingsService.bluekaiPagename('home');
          this.pageName = 'home';
          this.schemaToBeLoaded();
          setTimeout(() => {
            // console.log("Sending Home page name events to gtm");
             this.gtm.sendPageName(this.pageName);
             this.gtm.sendEvent();
          }, 0);
        }
      } else {
        this.routeservice.setRoute('/');
        this.pageName = 'home';
        this.gtm.sendPageName(this.pageName);
        this.gtm.sendEvent();
        // this.location.replaceState('/');
      }
     this.token = this.localstorage.getItem('token');
      let lang, pathname;
      lang = this.token ? this.localstorage.getItem('UserDisplayLanguage') : this.localstorage.getItem('display_language');
      // if (lang !== 'en') {
      if (lang !== 'en' || ( lang === 'en' && window.location.pathname.split('/')[1] === 'en')) {
        pathname = this.window.location.pathname.slice(3);
      } else {
        pathname = this.window.location.pathname;
      }

      // NationalFlag
      if (this.localstorage.getItem('country_code') === 'IN') {
        if (pathname !== '/language') {
          if (pathname !== '/signin') {
            if (pathname !== '/register/mobile') {
              if (pathname !== '/signin/mobile' && pathname !== '/search') {
                this.routeservice.setLoginRoute(this.window.location.pathname);
              }
            }
          }
        }
      } else {
        // InterNationalFlag
        if (pathname !== '/language') {
          if (pathname !== '/signin') {
            if (pathname !== '/register' && pathname !== '/search') {
                this.routeservice.setLoginRoute(this.window.location.pathname);
            }
          }
        }
      }
      if (this.token) {
        if (this.router.url === '/signin' || this.router.url.match('/mobile') || this.router.url.match('/email')) {
          this.checkUrl = '/';
        } else {
          this.checkUrl = this.router.url;
        }
      } else {
        this.checkUrl = this.router.url;
      }
        if (this.checkUrl !== '/language' && this.checkUrl !== '/signin' && this.checkUrl !== '/register/mobile' && this.checkUrl !== '/signin/mobile' && this.checkUrl !== '/register/email' && this.checkUrl !== '/signin/email') {
          this.getServerTime();
        if (this.token) {
          let params;
          params = 'bearer ' + this.token;
          this.params = params;
          let configUser;
          configUser = {
            apiKey: params,
            username: ' ',
            password: ' ',
            accessToken: ' ',
            withCredentials: false
          };
          // let watchHistoryRequest;
          this.userProfileService.httpgetFavoriteData();
          this.userProfileService.httpgetWatchData();
          // watchHistoryRequest = new  WatchHistoryApi(this.http, null, configUser);
          // watchHistoryRequest.v1WatchhistoryGet().timeout(environment.timeOut).takeUntil(this.ngUnsubscribe).subscribe(value => {
          //   this.continueShows = { 'title': 'SETTINGS.CONTINUE_WATCH', 'type': 'continue',
          //   'content': value
          //   };
          // },
          // err => this.gtm.sendErrorEvent('api', err)
          // );
          this.checkWatchHistory();
        } else {
          this.watchlistdata = true;
          this.loadervisible(); // gwapihomedata,watchlistdata,livedata
        }
      }
  }
      let lang1, pathname1;
      lang1 = this.token ? this.localstorage.getItem('UserDisplayLanguage') : this.localstorage.getItem('display_language');
      if (lang1 !== 'en') {
        pathname1 = this.window.location.pathname.slice(3);
      } else {
        pathname1 = this.window.location.pathname;
      }

    if (this.checkUrl !== '/language' && this.checkUrl !== '/signin' && this.checkUrl !== '/register/mobile' && this.checkUrl !== '/signin/mobile' && this.checkUrl !== '/register/email' && this.checkUrl !== '/signin/email') {
    this.config = {
      apiKey: ' ',
      username: ' ',
      password: ' ',
      accessToken: ' ',
      withCredentials: false
    };
    $('#loaderPage').css('display', 'block');
    this.processPending = false;
    this.initialApiCall();

  }
  this.count = 0;
  this.channelHover = [false, false, false, false, false, false ];
  // if (this.mastDivID && this.mastTag) {
  //   this.adCreation(this.mastTag, this.mastDivID, ['fluid']);
  // }
}
}

        public updateBreadCrump(title: any) {
          let breadcrump;
          breadcrump = [
          {
            'label': 'BREADCRUMB.HOME',
            'url': '/',
            'enable': true
          },
          {
            'label': this.breadcrump,
            'url': this.router2,
            'enable': false
          },
          ];
          if (this.breadcrump === '') {
            this.headerservicesService.breadCrump('');
          } else {
            this.headerservicesService.breadCrump(breadcrump);
          }
      }
  public checkWatchHistory(): any {
    this.userAction.checkWatchHistory().takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
      if (value && value.code === 401) {
        this.gtm.sendErrorEvent('api', value);
        return;
      }
      this.historyRetryCount = 1;
      if (value && value.length) {
        this.continueShows = { 'title': 'SETTINGS.CONTINUE_WATCH', 'type': 'continue',
        'content': value
        };    
        this.setAd();
      }
      this.getYIndex();
      this.watchlistdata = true;
      this.loadervisible(); // gwapihomedata,watchlistdata,livedata
    }, err => {
      this.gtm.sendErrorEvent('api', err);
      if (err.status === 401 && this.historyRetryCount < this.apiRetry) {
        this.historyRetryCount ++;
        this.commonService.refreshToken().then(
          () => {
            this.checkWatchHistory();
          // },
          // () => {
          });
      }else {
      this.watchlistdata = true;
      this.loadervisible(); // gwapihomedata,watchlistdata,livedata
      this.getYIndex();

      }
    });
  }


public setGlobalObject() {
  if (isPlatformBrowser(this.platformId)) {
    this.localstorage = localStorage;
    this.window = window;
    this.document = document;
    this.navigator = navigator;
  }
}
/*--------------new ad implementation--------------------*/
private setAd(): any {
  if (!this.adsInitialized) {
    this.adsInitialized = true;
    let userType;
      userType = this.commonService.getUserType();
      this.mastHeadAds = this.commonService.getAdsValue();
      this.nativeAds = this.commonService.getAdsValue();
      this.showNativeAds = this.nativeAds && this.nativeAds['native_tags_ads'] && this.nativeAds['native_tags_ads'][userType] && this.nativeAds['native_tags_ads'][userType].ads_visibility && this.nativeAds['native_tags_ads'][userType]['screens'];
      this.showMastAds = this.mastHeadAds && this.mastHeadAds['masthead_ads'] && this.mastHeadAds['masthead_ads'][userType] && this.mastHeadAds['masthead_ads'][userType].ads_visibility && this.mastHeadAds['masthead_ads'][userType]['screens'];
      if (this.showMastAds) {
        this.mastHeadAds = this.mastHeadAds['masthead_ads'][userType]['screens'];
        let mast_head_ad, scope;
        scope = this;
        mast_head_ad = $.grep(this.mastHeadAds, function(e) {
            return e.screen_id === scope.pageName;
          });
        if (mast_head_ad && mast_head_ad[0] && mast_head_ad[0].ad_data && mast_head_ad[0].ad_data[0]) {
            mast_head_ad = mast_head_ad[0].ad_data[0];
            this.mastDivID = mast_head_ad.div_id;
            this.mastTag = mast_head_ad.ad_tag;
            this.mastHeadStyle = this.commonService.getAdType(mast_head_ad.ad_type);
        }
        if (this.mastDivID && this.mastTag) {
          this.adCreation(this.mastTag, this.mastDivID, mast_head_ad.ad_dimension, 'masthead');
        }
      }
      if (this.showNativeAds) {
        this.nativeAds = this.nativeAds['native_tags_ads'][userType]['screens'];
        let native_ad, scope;
        scope = this;
        native_ad = $.grep(this.nativeAds, function(e) {
            return e.screen_id === scope.pageName;
          });
        if (native_ad && native_ad[0] && native_ad[0].ad_data && native_ad[0].ad_data.length > 0) {
          // native_ad[0].ad_data = native_ad[0].ad_data.splice(0, 1);
          this.nativeTag = native_ad[0].ad_data;
          this.nativeTag = this.subscriptionService.formatDuplicate(this.nativeTag, 'position');
          this.nativeAdPosition = this.nativeTag.map(a => a.position);
          let index;
          index = native_ad[0].ad_data.findIndex(ad => ad.position === 'footer');
          if (index !== -1 && native_ad[0].ad_data[index]) {
            this.footerAd = native_ad[0].ad_data[index];
            this.footerAd.adStyle = this.commonService.getAdType(this.footerAd.ad_type);
            this.footerAd.adNative = this.footerAd.div_id;
            this.googleAdCreation('footer', index);
          }
        }
      }
  }

}
/*--------------new ad implementation--------------------*/

public initialApiCall() {
  this.setGlobalObject();
  let x, userType, content_language;
  if(this.pageName == 'news' ) {
    if(this.settingsService.getconsiderMusicnode()) {
      let content_lang = this.token ? localStorage.getItem('UserContentLanguage') : localStorage.getItem('ContentLang');
      let str1  =this.settingsService.getpasscontentLang()
      let str2 = str1.lang.join()
      if(str1.value == true) {
              let result = (content_lang + ',' + str2)
                                            .split(',')
                                              .filter(function(w, i, words) { return i === words.indexOf(w) })
                                                  .join(',')

        content_language = result;
      } else {
        content_language = null;
      }
    } else {
      content_language = null;
    }
    
    //if(content_lang)
  }
  x = new CollectionApi(this.http, null, this.config);
  this.processPending = true;
  userType = this.commonService.getUserType();
  x.v1DetailCollectionByIdGet(this.collectionID, this.collectionPageNo, this.collectionPageSize, this.itemLimit, this.countryCode, null, null, content_language, null, userType).takeUntil(this.ngUnsubscribe).subscribe(value => {
    // talamoos reco API
    let countrylist = this.settingsService.getCountryValueNew()
    // this.settingsService.getCountryListNew().subscribe(value1 => {
      if(countrylist && countrylist.length > 0 && countrylist[0].recommendations && countrylist[0].recommendations == true) {
        x.v1RecommendationByIdGet(this.collectionID, null, null, null, this.countryCode, null, null, null, userType, null).takeUntil(this.ngUnsubscribe).subscribe(Rvalue => {
      value = this.talamoosFilter(value, Rvalue);
      this.commonProcedureAfterLandingAPI(value);
      }, err => {
        this.commonProcedureAfterLandingAPI(value);
      });
    } else {
      this.commonProcedureAfterLandingAPI(value);
    }
  },
  err => {
    // $('#loaderPage').css('display', 'none');
    this.gtm.sendErrorEvent('api', err);
    if (err.status === 401 && this.apiRetryCount <= this.apiRetry) {
      this.apiRetryCount ++;
      this.processPending = true;
      this.commonService.refreshToken().then(() => {
          this.initialApiCall();
      },() => {
          this.processPending = true;
          this.dataAvailable = false;
          this.travellingUser();
          // $('#loaderPage').css('display', 'none');
          this.gwapidata = true;
          this.loadervisible(); // gwapihomedata,watchlistdata,livedata
      },
        );
    }  else {
      $('#loaderPage').css('display', 'block');
      let countrylist = this.settingsService.getCountryValueNew()
      if (countrylist && countrylist.length > 0 && countrylist[0].recommendations && countrylist[0].recommendations == true) {
       x.v1RecommendationByIdGet(this.collectionID, null, null, null, this.countryCode, null, null, null, userType, null).takeUntil(this.ngUnsubscribe).subscribe(Rvalue => {
          this.setAd();
          this.homepageData = [];
          this.processPending = false;
          Rvalue.items = Rvalue.buckets;
          Rvalue.items = this.commonService.removeWebView(Rvalue.items);
          this.data = Rvalue;
          this.seoservice.updatefromAPI(this.data, this.router);
          this.initialiseData(this.data);
          this.totalCollectionPages = Math.ceil((this.data.total) / (this.collectionPageSize));
              /*--------------new ad implementation--------------------*/
          this.AdImplementation(Rvalue);
              /*--------------new ad implementation--------------------*/
          // $('#loaderPage').css('display', 'none');
          this.gwapidata = true;
          this.loadervisible(); // gwapihomedata,watchlistdata,livedata
          if (!this.premiumPage && !this.newsPage) {
            $('#breadcrumInit').css('display', 'none');
          }
      }, error => {
        // $('#loaderPage').css('display', 'none');
        this.gwapidata = true;
        this.loadervisible(); // gwapihomedata,watchlistdata,livedata
        this.processPending = true;
        this.dataAvailable = false;
      });
     } else {
        // $('#loaderPage').css('display', 'none');
        this.gwapidata = true;
        this.loadervisible(); // gwapihomedata,watchlistdata,livedata
        this.processPending = true;
        this.dataAvailable = false;
     }
      this.travellingUser();
    }
  });
}


public AdImplementation(value) {
    if (value.items && value.items.length > 0 && this.nativeAdPosition && this.nativeAdPosition.length > 0) {
        this.traylength = 0;
        for (let index1 = 0; index1 < value.items.length; index1++) {
          if (value.items[index1].tags && (value.items[index1].tags[0] === 'banner')) {
            this.traylength++;
          } else {
            let adIndex, adPosition;
            adPosition = ((this.collectionPageNo - 1) * this.collectionPageSize) + index1 + 1 - this.traylength;
            adIndex = this.nativeAdPosition.indexOf((adPosition).toString());
            // if (adIndex >= 0) {
            // console.log(adIndex, index1, this.homepageData.length, 'length');
            if (adIndex >= 0) {
              // this.totalAds ++;
              if (this.footerAd && adPosition === this.homepageData.length) {
              // if (this.footerAd && this.footerAdRendered && adPosition === this.moviesCategory.length) {
                this.skippedAdIndex = adIndex;
              } else {
                this.googleAdCreation('native', adIndex);
              }
            }
          }
        }
        // this.ads_sum = this.ads_sum + this.totalAds;
      }
}

public commonProcedureAfterLandingAPI(value) {
    this.setAd();
    this.apiRetryCount = 1;
    this.homepageData = [];
    this.processPending = false;
    value.items = this.commonService.removeWebView(value.items);
    value.items = value.buckets;

    this.data = value;
    this.seoservice.updatefromAPI(this.data, this.router);
    this.initialiseData(this.data);
    this.totalCollectionPages = Math.ceil((this.data.total) / (this.collectionPageSize));
    /*--------------new ad implementation--------------------*/
    this.AdImplementation(value);
    /*--------------new ad implementation--------------------*/
    // $('#loaderPage').css('display', 'none');
      this.gwapidata = true;
    this.loadervisible(); // gwapihomedata,watchlistdata,livedata

    if (!this.premiumPage && !this.newsPage) {
      $('#breadcrumInit').css('display', 'none');
    }
    this.travellingUser();
    let scope;
    scope = this;
    setTimeout(() => {
      if (this.today) {
        this.commonService.setServertime(this.today);
      } else {
        this.today = new Date();
        this.commonService.setServertime(this.today);
      }
    }, 0);
}

public talamoosFilter(value, Rvalue) {
  let bannercount = 0;
  if (value.buckets && value.buckets.length > Rvalue.rails_position) {
    if (value.buckets && value.buckets.length > 0) {
      for (let checkbannerindex = 0 ; checkbannerindex < Rvalue.rails_position; checkbannerindex++) {
          if (value.buckets[checkbannerindex].tags && (value.buckets[checkbannerindex].tags.length > 0) && (value.buckets[checkbannerindex].tags[0] === 'banner')) {
            bannercount++;
          }
      }
    }
  }

  // replace talamoos content on the particular rail position
  if (value.buckets && value.buckets.length > Rvalue.rails_position) {
    for (let i = 0 ; i < Rvalue.buckets.length; i++ ) {
      if (this.pageName === 'news') {
        value.buckets.splice(Rvalue.rails_position+ i + bannercount, 0 ,Rvalue.buckets[i])
      } else {
        value.buckets.splice(Rvalue.rails_position+ i + bannercount -1, 0 ,Rvalue.buckets[i])
      }
    }
  } else {
    value.buckets = value.buckets.concat(Rvalue.buckets);
  }
  return value;
}


// public googleAdCreation (slotName: any, id: any) {
//   this.googletagAvailable = this.commonService.checkGoogleTag();
//   if (this.googletagAvailable === 'true' && this.nativeTag && this.nativeTag[id] && this.nativeTag[id].ad_tag && this.nativeTag[id].div_id) {
//     if (!this.touchScreen) {
//       this.adCreation(this.nativeTag[id].ad_tag, (this.nativeTag[id].div_id),  this.nativeTag[id].ad_dimension, 'native');
//     } else {
//       this.adCreation(this.nativeTag[id].ad_tag, (this.nativeTag[id].div_id),  this.nativeTag[id].ad_dimension, 'native');
//     }
//   }
// }

public googleAdCreation (adType: any, id: any) {
  if (this.nativeTag && this.nativeTag[id] && this.nativeTag[id].div_id) {
    switch (this.nativeTag[id].ad_provider) {
      case 'adfox':
        let adFoxtagAvailable;
        adFoxtagAvailable = this.commonService.checkAdFoxTag();
        if (adFoxtagAvailable === 'true' && this.nativeTag[id].owner_id && this.nativeTag[id].params) {
          this.adFoxCreation(this.nativeTag[id].div_id, this.nativeTag[id].owner_id, this.nativeTag[id].params , adType);
        }
        break;
      default:
        this.googletagAvailable = this.commonService.checkGoogleTag();
        if (this.googletagAvailable === 'true' && this.nativeTag[id].ad_tag) {
          this.adCreation(this.nativeTag[id].ad_tag, (this.nativeTag[id].div_id),  this.nativeTag[id].ad_dimension, adType);
        }
        break;
    }
  }
}

public adFoxCreation(id: any, owner_id: any, params: any, adType: any) {
  let adFoxtagAvailable;
  adFoxtagAvailable = this.commonService.checkAdFoxTag();
  if (adFoxtagAvailable === 'true') {
    this.timer.push(setTimeout(function() {
      this.window.Ya.adfoxCode.create({
        ownerId: owner_id,
        containerId: id,
        params: params,
        // onLoad: function(data) { console.log(data, 'onLoad') },
        // onRender: function(render) { console.log(render, 'onRender') },
        onError: function(error) {
          // console.log(error, 'onError');
          $('#' + id).hide();
        },
        onStub: function(stub) {
          // console.log(stub, 'onstub');
          $('#' + id).hide();
        }
      });
    }, 0));
  } else {
    $('#' + id).hide();
  }
}

public adCreation(tag: any, id: any, dimension: any, adType: any) {
  this.googletagAvailable = this.commonService.checkGoogleTag();
  if (this.googletagAvailable === 'true') {
    let scope;
    scope = this;
    this.timer.push(setTimeout(function() {
      if (googletag.apiReady) {
        googletag = googletag || {};
        googletag.cmd = googletag.cmd || [];
        googletag.cmd.push(function() {
          googletag.pubads().enableSingleRequest();
          googletag.pubads().addEventListener('slotRenderEnded', function(event) {
              if (event.slot === scope.adSlot && (!event.isEmpty)) {
                scope.mastAd = true;
              } else if (event.slot === scope.adSlot && (event.isEmpty)) {
                // ad slot is not empty
              }
          });
          if (adType === 'masthead') {
            scope.adSlot = googletag.defineSlot(tag, dimension, id).setCollapseEmptyDiv(true).addService(googletag.pubads());
          } else if (adType === 'footer') {
            scope.footerAdSlot = googletag.defineSlot(tag, dimension, id).setCollapseEmptyDiv(true).addService(googletag.pubads());
          } else {
            googletag.defineSlot(tag, dimension, id).setCollapseEmptyDiv(true).addService(googletag.pubads());
          }
          googletag.enableServices();
        });
        googletag.cmd.push(function() { googletag.display(id); });
      }
    }, 0));
  }
}

public travellingUser(): void {
  this.gdpr = this.settingsService.getgdprTraveller();
  if (this.gdpr && this.token && !this.premiumPage) {
      this.showPopup = true;
  } else {
    this.newOffer();
  }
}

public newOffer() {
  if (this.router.url === '/' && this.countryCode === 'CA' && this.configValue && this.configValue.canadaLaunchOffer) {
    this.headerservicesService.launchOfferChange(true);
  }
}

public getServerTime(): any {
  let time;
    this.epgService.getcurrentTime(this.serverUrl).timeout(environment.timeOut).subscribe(value => {
        time = value;
        if (time != null) {
            this.today = new Date(time.serverdate);
        } else {
            this.today = new Date();
        }
        return this.today;
      }, error => {
         this.today = new Date();
         this.gtm.sendErrorEvent('api', error);
         return this.today;
      });
}

public checkPARPack(): any {
  this.localPARstorage = [];
  this.paytmPack = this.subscriptionService.getActivePAR();
  //  console.log('PAR this.paytmPack', this.paytmPack)
  if (this.paytmPack !== undefined && this.paytmPack.length > 0 ) {
  if ((this.localstorage.getItem('PARPack') === null)) {
      this.paytmIndex = 0;
      // this.showpaytmpopup = true;
      this.checkPaytmEnd(this.paytmIndex, true);
  } else {
          this.paytmpopup();
  }
  }
}
public paytmpopup(): void {
  let packDate, dateDiff  , serverDate, local = {};
  if (this.paytmPack && this.paytmPack.length > 0) {
    for (let i = 0; i < this.paytmPack.length; i++) {
      // serverDate = new Date()
      serverDate = this.today;
      packDate = new Date(this.paytmPack[i].sub_end);
      // packDate = new Date('2018-07-04T00:00:00Z')
      dateDiff = (packDate - serverDate) / (1000 * 3600 * 24);
      dateDiff = parseInt(dateDiff, 10);
      local = JSON.parse(this.localstorage.getItem('PARPack'));
      if ((local[i] === undefined) || (local[i] && local[i].parID && ((local[i].parID  !== this.paytmPack[i].pack_id) || (local[i].parFlag !== 0 && ( (local[i].parFlag !== dateDiff) && (dateDiff === 5 || 3 || 1) ) )) ) ) {
        this.paytmIndex = i;
        this.showpaytmpopup = true;
        this.checkPaytmEnd(this.paytmIndex, false);
        break;
      }
    }
  }
}
 public checkPaytmEnd(i: any, status): any {
  // console.log(this.paytmIndex,"this.paytmIndex", "this.paytmIndex")
  let  packDate , dateDiff , serverDate, local = [];
  // serverDate = new Date()
  serverDate = this.today;
  if (serverDate === undefined) {
    serverDate = new Date();
  }
  packDate = new Date(this.paytmPack[this.paytmIndex].sub_end);
  // packDate[i] = new Date('2018-07-04T00:00:00Z')
  dateDiff = (packDate - serverDate) / (1000 * 3600 * 24);
  dateDiff = parseInt(dateDiff, 10);
  //  console.log('PAR dateDiff', dateDiff[i])
  if (status) {
    this.localPARstorage.push({
      'parID': this.paytmPack[i].pack_id,
      'parFlag': dateDiff
    });
  } else {
    local = JSON.parse(this.localstorage.getItem('PARPack'));
    let index;
    index = local.findIndex(x => x.parID === this.paytmPack[i].pack_id);
    // array = (index>-1) ? local.splice(index, 1): local;
    if (index > -1) {
      // local.splice(index, 1)
      local[i].parFlag = dateDiff;
    } else {
        local.push({
          'parID': this.paytmPack[i].pack_id,
          'parFlag': dateDiff
        });
    }
    this.localPARstorage = local;
  }
    this.localstorage.setItem('PARPack', JSON.stringify(this.localPARstorage));
    this.showpaytmpopup = true;

  }
public channelSrcError (event: any) {
  if (event.srcElement) {
    event.srcElement.src =  environment.assetsBasePath + 'assets/default/epg_channel_logo.png';
  } else {
    event.currentTarget.src =  environment.assetsBasePath + 'assets/default/epg_channel_logo.png';
  }
}
public loadCollection(): void {
  if (this.networkService.getPopupStatus()) {
    if (this.processPending === false) {
      this.processPending = true;
      this.collectionPageNo++;
      if (this.totalCollectionPages >= this.collectionPageNo) {
        $('.auto-loader').css('display', 'block');
        let x, userType,content_language;
          if(this.pageName == 'news' ) {
    if(this.settingsService.getconsiderMusicnode()) {
      let content_lang = this.token ? localStorage.getItem('UserContentLanguage') : localStorage.getItem('ContentLang');
      let str1  =this.settingsService.getpasscontentLang()
      let str2 = str1.lang.join()
      if(str1.value == true) {
              let result = (content_lang + ',' + str2)
                                            .split(',')
                                              .filter(function(w, i, words) { return i === words.indexOf(w) })
                                                  .join(',')

        content_language = result;
      } else {
        content_language = null;
      }
    } else {
      content_language = null;
    }
    
    //if(content_lang)
  }
        x = new CollectionApi(this.http, null, this.config);
        userType = this.commonService.getUserType();
        x.v1DetailCollectionByIdGet(this.collectionID, this.collectionPageNo, this.collectionPageSize, this.itemLimit, this.countryCode, null, null, content_language, null, userType).timeout(environment.timeOut).takeUntil(this.ngUnsubscribe).subscribe(value => {
          this.apiRetryCount = 1;
          value.items = value.buckets;
          value.items = this.commonService.removeWebView(value.items);
          this.data = value;
          this.processPending = false;
          $('.auto-loader').css('display', 'none');
          this.initialiseData(this.data);
          /*--------------new ad implementation--------------------*/
          if (value.items && value.items.length > 0 && this.nativeAdPosition && this.nativeAdPosition.length > 0) {
            if (this.skippedAdIndex !== undefined) {
              this.googleAdCreation('native', this.skippedAdIndex);
              this.skippedAdIndex = undefined;
            }
            for (let index1 = 0; index1 < value.items.length; index1++) {
              if (value.items[index1].tags && (value.items[index1].tags[0] === 'banner')) {
                this.traylength++;
              } else {
                let adIndex, adPosition;
                adPosition = ((this.collectionPageNo - 1) * this.collectionPageSize) + index1 + 1 - this.traylength;
                adIndex = this.nativeAdPosition.indexOf(adPosition.toString());
                if (adIndex >= 0) {
                  // this.totalAds ++;
                  if (this.footerAd && adPosition === this.homepageData.length) {
                  // if (this.footerAd && this.footerAdRendered && adPosition === this.moviesCategory.length) {
                    this.skippedAdIndex = adIndex;
                  } else {
                    this.googleAdCreation('native', adIndex);
                  }
                }
              }
            }
            // this.ads_sum = this.ads_sum + this.totalAds;
          }
          /*--------------new ad implementation--------------------*/
          let scope;
          scope = this;
          setTimeout(() => {
            scope.commonService.updateTime();
          }, 0);
        },
        err => {
          $('#loaderPage').css('display', 'none');
          this.gtm.sendErrorEvent('api', err);
          if (err.status === 401 && this.apiRetryCount < this.apiRetry) {
            this.apiRetryCount ++;
            this.commonService.refreshToken().then(
              () => {
                this.processPending = false;
                this.collectionPageNo --;
                this.loadCollection();
              },
              () => {
                this.processPending = false;
              },
              );
          } else {
            this.processPending = false;
          }
        }
        );
      }
    }
  }
}
public routeChannel(name: any, id: any, xIndex: any, yIndex: any) {
  this.gtm.setContentClickDetails(xIndex, (yIndex + this.getYIndex()), this.channelsTitleEng);
  this.gtm.GAsubCategory = this.channelsTitleEng;
  let show_title = name.toLowerCase().replace(/ /g, '-');
  show_title = show_title.replace(/---/g, '-');
  show_title = show_title.replace(/&/g, 'and');
  this.router_link.navigate(['channels/details', show_title, id ]);
}

public getYIndex(): any {
  let addIndex;
  addIndex = 0;
  addIndex = (this.pageName === 'home' && this.continueShows) ? ++addIndex : ((this.pageName === 'news' && this.newsPageData) ? ++addIndex : addIndex);
  addIndex = (this.carousel && this.carousel.length > 0) ? ++addIndex : addIndex;
  this.addIndex = addIndex;
  return addIndex;
}

public dismiss (event: any) {
  if (this.networkService.getPopupStatus()) {
    let configUser;
    configUser = {
      apiKey: this.params,
      username: ' ',
      password: ' ',
      accessToken: ' ',
      withCredentials: false
    };
    let watchHistoryRequest;
    watchHistoryRequest = new  WatchHistoryApi(this.http, null, configUser);

    watchHistoryRequest.v1WatchhistoryDelete(event.id, event.asset_type).timeout(environment.timeOut).takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.continueShows.content = $.grep(this.continueShows.content, function(e) {
        return e.id !== event.id;
      });
    });
  }
}
public initialiseData(data: any): void {
  this.count ++;
  let scope;
  scope = this;
  if (data.items && data.items.length > 0) {
    for (let index = 0; index < data.items.length; index++) {
      if (data.items[index].tags && data.items[index] && data.items[index].items && (data.items[index].tags[0] === 'Popular' || data.items[index].tags[0] === 'popular')) {
        let popular;
        popular = [];
        this.popularData = data.items[index].items;
        if (this.popularData.length > 5) {
          this.showViewAll = true;
        }
        this.popularTitle = data.items[index].title;
        this.popularTitle_en = data.items[index].original_title;
        if (this.window.innerWidth < 769) {
          this.popularItems = this.popularData;
          this.banner = [undefined];
        } else {
          this.popularData[0].type = 'popular_banner';
          this.banner = [
          this.popularData[0]
          ];
          this.popularItems = this.popularData.slice(1, 5);
        }
        if (this.popularData.length > 0) {
          this.popularShow = true;
        } else {
          this.popularShow = false;
        }
        let idValueNative, adIndex, adStyle;
        idValueNative = '';
        if (this.nativeAdPosition && this.nativeAdPosition.length > 0) {
          adIndex = this.nativeAdPosition.indexOf((this.count_ad + 1).toString());
          if (adIndex >= 0 && this.nativeTag && this.nativeTag[adIndex]) {
            idValueNative = this.nativeTag[adIndex].div_id;
            adStyle = this.commonService.getAdType(this.nativeTag[adIndex].ad_type);
          }
        }
        this.popular = { 'id' : data.items[index].id, 'adNative': idValueNative, 'adStyle': adStyle, 'listType': 'popular', 'titleMain': this.popularTitle, 'titleMain_en': this.popularTitle_en, 'bannerItem': this.banner,  'type': 'home', 'link': 'collections',
          'content': this.popularItems, 'parentType': 'homeScreen', popularShow: this.popularShow
        };
        this.count_ad++;
        this.homepageData.push(this.popular);
      } else if (data.items[index] && data.items[index].items && data.items[index].tags && (data.items[index].tags[0] === 'banner')) {
        if (!this.carousel) {
          this.carouselTitle = {'title': data.items[index].title, 'original_title': data.items[index].original_title};
          // this.carousel_form = [];
          if (data.items[index].items && data.items[index].items.length > 0) {
            this.carousel = data.items[index].items;
            this.carouselCollection = data.items[index].id;
            this.collectionTags = data.items[index].tags;
            this.getYIndex();
            // $('.breadcrumInit').addClass('topCarousel');
            setTimeout(function() {
              if (scope.router.currentUrlTree.root.children.primary) {
                if (scope.router.currentUrlTree.root.children.primary.segments.length === 3) {
                  scope.currentRoute = scope.router.currentUrlTree.root.children.primary.segments[1].path;
                } else {
                  scope.currentRoute = scope.router.currentUrlTree.root.children.primary.segments[0].path;
                }
                if (scope.carousel_element && scope.currentRoute === 'search') {
                  scope.carousel_element.stopCarousel();
                }
              }
            }, 0);
          }
        }
      } else if (data.items[index] && data.items[index].items && data.items[index].tags && (data.items[index].tags[0] === 'channels')) {
        this.channelData = [];
        if (data.items[index].items) {
          for (let index_sub = 0; index_sub < data.items[index].items.length; index_sub++) {
            if (data.items[index].items[index_sub]) {
              if (this.data.items[index].items[index_sub].list_image)  {
                this.data.items[index].items[index_sub].image_url = this.settingsService.getbasePath() + this.data.items[index].items[index_sub].id + '/list/' + '170x120/' + this.data.items[index].items[index_sub].list_image;
              } else {
                this.data.items[index].items[index_sub].image_url = environment.assetsBasePath + 'assets/default/epg_channel_logo.png';
              }
              if (this.data.items[index].items[index_sub].cover_image)  {
                this.data.items[index].items[index_sub].cover_url = this.settingsService.getbasePath() + this.data.items[index].items[index_sub].id + '/cover/' + '170x120/' + this.data.items[index].items[index_sub].cover_image;
              } else {
                this.data.items[index].items[index_sub].cover_image = environment.assetsBasePath + 'assets/default/epg_channel_logo.png';
              }
              this.channelData.push(data.items[index].items[index_sub]);
            }
          }
          this.channelsTitle = data.items[index].title;
          this.channelsTitleEng = data.items[index].original_title;
          this.channels = this.channelData.slice(0, 6);
          this.channelHover = [false, false, false, false, false, false];
          let idValueNative, adIndex, adStyle;
          idValueNative = '';
          if (this.nativeAdPosition && this.nativeAdPosition.length > 0) {
            adIndex = this.nativeAdPosition.indexOf((this.count_ad + 1).toString());
            if (adIndex >= 0 && this.nativeTag && this.nativeTag[adIndex]) {
              idValueNative = this.nativeTag[adIndex].div_id;
              adStyle = this.commonService.getAdType(this.nativeTag[adIndex].ad_type);
            }
          }
          this.count_ad++;
          this.homepageData.push({'listType': 'channel', 'adNative': idValueNative, 'adStyle': adStyle, 'title': this.channelsTitle , 'original_title': data.items[index].original_title , 'seo_title': data.items[index].seo_title , 'modelname': data.items[index].modelName, 'content': this.channels, 'tags': data.items[index].tags});
        }
      } else {
        if (data.items[index] && data.items[index].tags && data.items[index].tags[0] === 'movies') {
          this.type = 'movies';
          this.link = 'movies';
        } else if (data.items[index] && data.items[index].tags &&  data.items[index].tags[0] === 'tvshows') {
          this.type = 'tvshows';
          this.link = 'tvshows';

        } else if (data.items[index] && data.items[index].tags &&  data.items[index].tags[0] === 'originals') {
          this.type = 'zee5originals';
          this.link = 'zee5originals';

        } else if (data.items[index] && data.items[index].tags && (data.items[index].tags[0] === 'Videos' || data.items[index].tags[0] === 'videos')) {
          this.type = 'videos';
          this.link = 'videos';

        } else if (data.items[index] && data.items[index].tags && (data.items[index].tags[0] === 'eventbanner' || data.items[index].tags[0] === 'Eventbanner')) {
          this.type = 'eventbanner';
          this.link = 'eventbanner';

        } else if (data.items[index]) {
          this.type = 'home';
          this.link = 'collections';
        }
        let idValueNative, adIndex, adStyle;
        idValueNative = '';
        if (this.nativeAdPosition && this.nativeAdPosition.length > 0) {
          adIndex = this.nativeAdPosition.indexOf((this.count_ad + 1).toString());
          if (adIndex >= 0 && this.nativeTag && this.nativeTag[adIndex]) {
            idValueNative = this.nativeTag[adIndex].div_id;
            adStyle = this.commonService.getAdType(this.nativeTag[adIndex].ad_type);
          }
        }
        if (data.items[index].items) {
          this.recommended = {
          'adNative': idValueNative,
          'adStyle': adStyle,
          'listType': 'default',
          'title': data.items[index].title,
          'original_title': data.items[index].original_title,
          'type': this.type, 'modelname': data.items[index].modelName,
          'link': this.link,
          'content': this.premiumPage ? this.commonService.restrictLength(data.items[index].items) : this.commonService.restrictLength(data.items[index].items),
          // 'content': this.premiumPage ? this.commonService.restrictLength(data.items[index].items) : this.commonService.restrictLength(this.commonService.filterListData(data.items[index].items)),
          'id':   data.items[index].id,
          'parentType': 'homeScreen',
          'original_length': data.items[index].items.length
        };
        this.count_ad++;
        this.homepageData.push(this.recommended);
      }
    }
  }
  // this.count_ad = this.homepageData.length + 1;
  } else {
    if ( this.count === 1) {
      this.dataAvailable = false;
    }
  }
  if (this.scrollCount > 0) {
    this.gtm.sendEventDetails({'event': 'scrollTracking', 'ScrollCount': '1'});
  }
  this.scrollCount++;
}
private fetchCall() {
    let translation;
    translation = this.filterService.gettranslation();
    this.type = 'home';
    this.link = 'news';
    let x;
    // x = new api.EpgApi(this.http, null, null);
    x = new EpgApi(this.http, null, null);
    let basePath, country;
    basePath = environment.catalogbasepath;
    country = this.settingsService.getCountry();
     let headers;
        headers = new Headers(); // https://github.com/angular/angular/issues/6845
         headers.append('X-Z5-AppPlatform', this.platform);
        headers.append('X-Z5-Appversion', this.version);
         const requestOptions: RequestOptionsArgs = new RequestOptions({
        method: RequestMethod.Get,
        headers: headers
    });
    this.http.request(environment.catalogbasepath + '/v1/channel?sort_by_field=channel_number&page_size=100&genres=News' + '&languages=' + this.languages + '&country=' + country + '&translation=' + translation, requestOptions).timeout(environment.timeOut).takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.newsPageResult = value.json();
      if (this.newsPageResult && this.newsPageResult.items && this.newsPageResult.items.length) {
        this.newsPageData = {'content': this.newsPageResult.items, 'title': 'NEWS_PAGE.LIVE_NEWS'};
        this.setAd();
      }
      this.getYIndex();
      this.livetvdata = true;
      this.loadervisible(); // gwapihomedata,watchlistdata,livedata
     }, err => {
      this.getYIndex();
      this.livetvdata = true;
      this.loadervisible(); // gwapihomedata,watchlistdata,livedata
     });
    }

public sublandingRoute(link: any, id: any, title: any) {
  this.router_link.navigate([link, this.commonService.convertToLowercase(title), id]);
}

// @HostListener('window:scroll', ['$event'])
// public onScrollEvent($event) {
//   let factor;
//   if (this.touchScreen) {
//     factor = 0.35;
//   } else if (!this.touchScreen) {
//     factor = 0.75;
//   }
//   if ($(this.window).scrollTop() >= ($(this.document).height() - $(this.window).height()) * factor) {
//     // this.loadCollection();
//   }
// }
public routeChannelAll(category): void {
  if (category && category.tags && category.tags.length && category.tags.indexOf(freeChannelTag) !== -1) {
    // this.commonService.setFreeChannels(true);
    sessionStorage.setItem('freeChannelTitle', category.title ? category.title : category.originalTitle);
    this.router_link.navigate(['channels'], { queryParams: { type: freeChannelTag } });
  } else {
    this.router_link.navigate(['channels']);
  }
}
public onHover(index): void {
  this.channelHover[index] = true;

}
public noHover(index): void {
  this.channelHover[index] = false;
}

public ngOnDestroy() {
  this.linkservice.removeCanonicalLink();
  // this.googletagAvailable = this.localstorage.getItem('googletag')
  this.googletagAvailable = this.commonService.checkGoogleTag();
  if (this.googletagAvailable === 'true' && googletag.destroySlots) {
    googletag.destroySlots();
  }
  let adFoxtagAvailable;
  adFoxtagAvailable = this.commonService.checkAdFoxTag();
  if (adFoxtagAvailable === 'true' && this.window.Ya.adfoxCode.destroy) {
  // if (adFoxtagAvailable === 'true' && this.window.Ya && this.window.Ya.adfoxCode && this.window.Ya.adfoxCode.destroy) {
    this.window.Ya.adfoxCode.destroy();
  }
  // clear all timers in the array
  for (let i = 0; i < this.timer.length; i++) {
    clearTimeout(this.timer[i]);
  }
  this.commonService.count = 0;
  this.showPopup = false;
  this.ngUnsubscribe.next();
  this.ngUnsubscribe.complete();
  // if  (this.carousel) {
  //   $('.breadcrumInit').removeClass('topCarousel');

  // }
   $('#breadcrumInit').css('display', '');
}
public trackByFn (index, show) {
  return show.id; // or item.id
}
public schemaToBeLoaded() {
  const s = this.renderer2.createElement('script');
  s.type = `application/ld+json`;
  s.id = `homePageOnly`;
  s.text = `
  {
    "@context" : "http://schema.org",
    "@type" : "Organization",
    "name" : "ZEE5",
    "url" : "https://www.zee5.com/",
    "potentialAction": {
      "@type": "SearchAction",
      "target": "https://www.zee5.com/search/result?q={search_term_string}",
      "query-input": "required name=search_term_string"
    },
    "logo": "https://www.zee5.com/assets/common/ZEE5_Logo50x50.png",
    "description": "100,000+ hours of TV Shows from ZEE network, Movies, International & Original content, music online in the language of your choice. Watch 90+ Live TV channels online including News anytime, anywhere on ZEE5 – where you feel the entertainment come alive!",
    "sameAs" :["https://www.facebook.com/ZEE5/","https://twitter.com/ZEE5India","https://www.instagram.com/zee5/","https://www.linkedin.com/company/zee5/","https://www.youtube.com/channel/UCXOgAl4w-FQero1ERbGHpXQ"]
  }
  `;
   this.pageName === 'home' ? this.renderer2.appendChild(this.doc.body, s) : (this.doc.getElementById('homePageOnly') ? this.renderer2.removeChild(this.doc.body, this.doc.getElementById('homePageOnly')) : this.renderer2.destroy());
}
  public loadervisible(): any {
    if (this.pageName === 'home') {
      if (this.gwapidata === true && this.watchlistdata === true) {
        $('#loaderPage').css('display', 'none');
        // } else {
        // $('#loaderPage').css('display', 'block');
        this.talamoosImpression = true;
      }
    } else if (this.pageName === 'news') {
      if (this.gwapidata === true && this.livetvdata === true) {
        $('#loaderPage').css('display', 'none');
      // } else {
      // $('#loaderPage').css('display', 'block');
        this.talamoosImpression = true;
      }
    } else {
        $('#loaderPage').css('display', 'none');
        this.talamoosImpression = true;
    }
  }
  public sendButtonClickDetails(ctadetails) {
    let buttonDetails;
    buttonDetails = {
      'event': 'buttonClicks',
      'cta': 'view all',
      'SubCategory': ctadetails ? ctadetails : 'NA',
      'PageName': this.gtm.getPageName(),
      'Previous_Screen': this.gtm.previousScreenName
    };
    this.gtm.sendEventDetails(buttonDetails);
  }
}
