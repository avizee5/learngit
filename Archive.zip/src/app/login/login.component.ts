import { Component, OnInit, Input, Output, EventEmitter , HostListener, ViewChild, AfterViewInit, AfterViewChecked, OnDestroy, ElementRef } from '@angular/core';
import * as $ from 'jquery';
import { HeaderservicesService } from '../services/headerservices.service';
import {Subscription} from 'rxjs/Rx';
import {TimerObservable} from 'rxjs/observable/TimerObservable';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/observable/timer';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import * as userApi from '../../data/user/api/api';
import { Http } from '@angular/http';
import { UserApiService } from '../services/user-api.service';
import { Location } from '@angular/common';
import { Router, NavigationEnd } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { RouteService } from '../services/route.service';
import {environment} from '../../environments/environment';
declare const FB: any;
// declare const gapi: any;
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import * as SettingsApi from '../../data/user/api/api';
import {  NetworkService  } from '../services/network.service';
import { UserApi } from '../../data/user/api/api';
import 'rxjs/add/operator/timeout';
declare const qg;
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { SettingsService } from '../services/settings.service';
import { UseractionapiService } from '../services/useractionapi.service';
import { LinkService } from '../services/link.service';
import { SeoService } from '../services/seo.service';
import { VideoService } from '../services/video.service';
import {CommonService} from '../services/common.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.less']
})
export class LoginComponent implements OnInit, AfterViewInit, OnDestroy {
@ViewChild('triggerClickLogin') public loaderPage: ElementRef;
@Input() private loginMobile: boolean;
@Input() private loginEmail: boolean;
@Input() private signinHide: any;
@Input() private signinDetailsFlag: any;
@Input() private bg_imageFlag: boolean;
@Input() private registerMobile: boolean;
@Input() private registerEmail: boolean;
@Input() private signInComponent: boolean;
@Input() private signinRightTop: boolean;
@Input() private signinLeftFlag: boolean;
@Input() private profileActivationFlag: any;
@Input() private countryListCCode: any;
  private assetbasepath: any;
  private emailCheck = false;
  private emailplace = false;
  private place = false;
  private place1 = false;
  private passwordCheck = false;
  private passwordCheck1 = false;
  private type: boolean;
  private source1 = this.assetbasepath + 'assets/sign_in/ic_eye_normal.png';
  private source2 = this.assetbasepath + 'assets/sign_in/ic_eye.png';
  private icon_source1 = this.assetbasepath + 'assets/sign_in/mobile_icon.png';
  private icon_source2 = this.assetbasepath + 'assets/sign_in/mail_icon.png';
  private verification_email = false;
  private email_return = false;
  private password_return = false;
  private mobile_return = false;
  private dropDownCheck = false;
  private selected_country: any;
  private id: any;
  private regex: any;
  private country_code: any;
  private mobile_return_keypress = false;
  private email_return_keypress = false;
  private password_return_keypress = false;
  private country_codeLength: number;
  private password_email_return_keypress = false;
  private password_email_return = false;
  public forgotPasswordEmail = false;
  public forgotPasswordEmailStep2 = false;
  public forgotPasswordMobile = false;
  public forgotPasswordMobileStep2 = false;
  private otp_return = false;
  private otp_return_keypress = false;
  private otpPlace = false;
  private otpCheck = false;
  private interval: any;
  private countdown_time = '20:00';
  public forgotPasswordMobileStep3 = false;
  private confirm_password_Check = false;
  private confirmPlace = false;
  private type_confirm = false;
  public forgotPasswordFinalStep = false;
  private confirm_return = false;
  private confirm_return_keypress = false;
  private new_password_return = false;
  private new_password_return_Keypress = false;
  private step3check = true;
  private forgot_email_return = false;
  private forgot_email_return_keypress = false;
  private timer_return = true;
  private timer_return_keypress = true;
  private timer2: string;
  private token: string;
  private userapi: any;
  private forgotcode: any;
  private forgotcode_mobile: any;
  private forgotpassword_mobile: any;
  private forgotpassword_email: any;
  private error_message: any;
  private userSettings: any;
  private gdprValue: any;
  public auth2: any;                                       // G+ Signin api call letiable
  private token1: any;
  private loged = false;
  private user = { name: 'Hello' };
  private saveToken: any;
  private FBTOKEN: any;
  private saveTokenFacebook: any;
  private pageName: any;
  private userId: any = null;
  private config: any;
  private count = 0;
  private count1 = 0;
  private profileShow: any;
  private buttonChange = false;
  private previousUrl: any;
  private signin_fail = 0;
  private tokenValue: any;
  private timestampTime: any;
  private timestampDateTime: any;
  private changePassword = 'LOGIN.PASSWORD';
  private changeEmail = 'LOGIN.EMAIL_ID';
  private changeNewPassword = 'LOGIN.NEW_PASS';
  private changeConfirmPassword = 'LOGIN.CONFIRM_PASS';
  private enter_mobile = 'LOGIN.ENTER_MOBILE_NO';
  private enter_mobile_incorrect = 'LOGIN.INCORRECT_MOBILE_NO';
  private errors: any;
  public error_message_Login: any;
  private responseMobile: any;
  private responseEmail: any;
  private responseMessage: string;
  public registerFlag = false;
  private email_verification = false;
  private mobile_verification = false;
  private timer_true = false;
  private enter_otp: any = 'LOGIN.ENTER_OTP';
  private email_ID: any = 'LOGIN.EMAIL_ID';
  private try_later: any = 'TOAST_MESSAGES.TRY_LATER';
  private default_settings: any;
  private countdown_time2 = '00:30';
  private timer_second: string;
  private second_interval: any;
  private otherContainerFlag: any;
  public loginPageFlag: any;
  private icon: any;
  private localstorage: any;
  private window: any;
  private document: any;
  private navigator: any;
  private phone_code: any;
  private currentIndex: any = 0;
  private previousIndex: any = 0;
  private country_selected_index: any = 0;
  private dropDownCheckforgot: any;
  private countryList: any;
  private configdata: any;
  private country: any;
  public gdprFlag: any;
  private gdprCountryChange = false;
  private login_type: any;
  private settingsResponse: any;
  private userData: any;
  private login_type_caps: any;
  private source_dropdown: any = this.assetbasepath + 'assets/sign_in/dropdwn_icn.png';
  private countrycode: any;
 private countries: any;
 private receivedValue: any = undefined;
 private socialFlag = false;
 private googleAccessToken: any;
 private googleObj: any;
 private socialType: any;
 private loginFrom: any;
 private sendToken: any;
 private promotional: any;
 private loginMethod: any;
 private countryToken: any;
 private cookiesLocal: any;
 private marketingLocal: any;
 private responsevalue: any;
 private countryListNew: any;
 private fireFoxdrop = false;
 private loginFromSub = false;
 private qgraph = true;
 public guest_token: any;
 private version_number: any;

 private sendForgotPwd: any; // send forgot password event to GA
 private GOOGLE_CLIENT_ID = environment.GOOGLE_CLIENT_ID;
 private clientID: any;
private marketingValue: any;
public expiredEmail = false;
public queryparams: any;
@Output() public update = new EventEmitter<boolean>(); // to send data back to component
  constructor(@Inject(PLATFORM_ID) private platformId: Object, private commonService: CommonService, private videoService: VideoService, private seoservice: SeoService, private linkservice: LinkService, private userAction: UseractionapiService, private settingsService: SettingsService, private networkService: NetworkService, private routeservice: RouteService, private headerservicesService: HeaderservicesService, private to: Location, private http: Http, private userapiService: UserApiService, private route: ActivatedRoute,  private router: Router, private gtm: GoogleAnalyticsService) {
    if (isPlatformBrowser(this.platformId)) {
          this.localstorage = localStorage;
          this.window = window;
          this.document = document;
          this.navigator = navigator;
        }
    this.assetbasepath = environment.assetsBasePath;
    this.headerservicesService.forgotEmailValue.subscribe(value => {  // email forgotpassward screen
        this.forgotPasswordEmail = value;
      });
    this.headerservicesService.forgotMobileValue.subscribe(value => {  // mobile forgotpassward screen
        this.forgotPasswordMobile = value;
      });
    this.headerservicesService.loginPageValue.subscribe(value => {    // outer div for login page
      this.loginPageFlag = value;
      });
    this.headerservicesService.otherContainerFlagValue.subscribe(value => { // right side div for login page
      this.otherContainerFlag = value;
      });
    this.headerservicesService.iconFlagValue.subscribe(value => {    // assets and text
      this.icon = value;
      });
    this.loginPageFlag = true;
    this.headerservicesService.LoginPageChange(true);
    this.otherContainerFlag = true;
    this.headerservicesService.OtherContanierFlagChange(true);
  this.source1 = this.assetbasepath + 'assets/sign_in/ic_eye_normal.png';
  this.source2 = this.assetbasepath + 'assets/sign_in/ic_eye.png';
  this.icon_source1 = this.assetbasepath + 'assets/sign_in/mobile_icon.png';
  this.icon_source2 = this.assetbasepath + 'assets/sign_in/mail_icon.png';
  this.source_dropdown = this.assetbasepath + 'assets/sign_in/dropdwn_icn.png';
  this.headerservicesService.blockeventsValue.subscribe(value => {
     this.qgraph = this.headerservicesService.getRemarketing();
    });
  }

  public ngOnInit() {
    this.queryparams = this.router.url.split('?')[1];
    $('.auto-loader').css('display', 'block');
    this.gtm.storeWindowError();
    this.qgraph = this.headerservicesService.getRemarketing();
    this.previousUrl = this.routeservice.getLoginRoute();
    this.forgotcode = this.routeservice.getforgotcode();
    this.cookiesLocal = this.localstorage.getItem('cookies');
    this.marketingLocal = this.localstorage.getItem('marketing');
    this.guest_token = this.localstorage.getItem('guestToken');
    this.version_number = this.navigator.userAgent;  // gdpr additional field version number while post
    $('#mobileNumber').focus();
    this.loginFromSub = this.headerservicesService.getloginFlag();
    if (this.loginEmail) {   // assets for email amd mobile
      this.icon = true;
      this.headerservicesService.IconFlagChange(true);
     } else if (this.loginMobile) {
        this.icon = false;
      this.headerservicesService.IconFlagChange(false);
     }
    if (this.routeservice.sendforgotSignal() === 'email') {   // route to detect and call function on direct call
      this.forgotEmail();
    } else if (this.routeservice.sendforgotSignal() === 'mobile') {
      this.forgotMobile();
    } else if (this.routeservice.sendforgotSignal() === '/resetpassword?code=' + this.forgotcode) {
      this.token = this.localstorage.getItem('token');
       if (this.token) {
         this.logoutPage();
       } else {
       this.resetPasswordEmail();
      }
    }
     this.window.scrollTo(0, 0);
     if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
        this.document.getElementById('body').classList.add('modal-open');
      }
  this.userapi = new userApi.UserApi(this.http, null, null);
  this.countrycode = this.settingsService.getCountry();
    let scope;
    scope = this;
$(this.document).mouseup(function(e) {
    if (e.target.id !== 'info' && !$('#info').find(e.target).length) {
        if (scope.dropDownCheck === true) {
          scope.dropDownCheck = false;
        }
        if (scope.dropDownCheckforgot === true) {
          scope.dropDownCheckforgot = false;
        }
    }
});
$(this.document).on('touchstart' , function(e) {
    if (e.target.id !== 'info' && !$('#info').find(e.target).length) {
        if (scope.dropDownCheck === true) {
          scope.dropDownCheck = false;
        }
        if (scope.dropDownCheckforgot === true) {
          scope.dropDownCheckforgot = false;
        }
    }
});
$(this.document).ready(function() {        // copy paste number
  $('#mobileNumber').on('paste', function (e) {
        setTimeout(function () {
              $('#mobileNumber').val($('#mobileNumber').val().replace(/[^0-9]/g, ''));
          }, 1);
      });
});
  this.configdata = this.settingsService.getCompleteConfig();
     this.countryListNew = this.countryListCCode;
      if (this.countryListNew && this.countryListNew.length >= 1) {
       this.country_code = '+' + this.countryListNew[0]['phone-code'] + ' - ';  // display
       this.phone_code = this.countryListNew[0]['phone-code'];    // send to api
      }

  this.country = this.settingsService.getCountryValue();
  setTimeout(() => {
this.countryList = this.settingsService.getcountryApiList();
if ( this.countryList === undefined || this.countryList.length === 0) {
this.settingsService.getCountryList().timeout(environment.timeOut).subscribe(value => {
      this.countries = value;
      if (this.countries.length === 0) {
        this.selected_country = this.countryListNew[0];
      } else {
      this.settingsService.setCountryListValue(value);
      let selected_country_apifirst;
       selected_country_apifirst = this.settingsService.getCountry();
         let country;
          for (country in this.countries) {
            if (this.countries[country].code === selected_country_apifirst) {
              this.currentIndex = country;
              this.country_selected_index = country;
              this.selected_country = this.countries[country];
              this.country_code = '+' + this.countries[country]['phone-code'] + ' - ';
              this.phone_code = this.countries[country]['phone-code'];
              if (this.countries[country].code === 'IN') {
                this.country_codeLength = 10;
              } else {

                this.country_codeLength = 13;
              }
              break;
            }
          }
        }
        $('.auto-loader').css('display', 'none');
    },
    error => {
        if (this.configdata === undefined || this.configdata === null) {
        this.currentIndex = 0;
        this.selected_country = {'name': this.country.country, 'code': this.country.code, 'phone-code': '-'};
        this.countries = [{'name': this.country.country, 'code': this.country.code, 'phone-code': '-'}];
        this.country_code = null;
        if (this.country.code !== 'IN') {
                this.country_codeLength = 20;
          } else {
                this.country_codeLength = 12;
          }
      } else {
        this.phone_code = this.configdata.region.IN.India.code;
        this.phone_code = this.configdata.region.IN.India.code.replace('+', '');
        this.selected_country = {'name': this.country.country, 'code': this.country.country_code, 'phone-code': this.phone_code};
        this.countries = [{'name': this.country.country, 'code': this.country.code, 'phone-code': this.phone_code}];
        this.country_code = this.configdata.region.IN.India.code + '-';
    }
    $('.auto-loader').css('display', 'none');
  });
} else {
  this.countries = this.countryList;
  let selected_country_api;
  selected_country_api = this.settingsService.getCountry();
  let country;
  for (country in this.countries) {
    if (this.countries[country].code === selected_country_api) {
      this.currentIndex = country;
      this.country_selected_index = country;
      this.selected_country = this.countries[country];
      this.country_code = '+' + this.countries[country]['phone-code'] + ' - ';
      this.phone_code = this.countries[country]['phone-code'];
      if (this.countries[country].code === 'IN') {
        this.country_codeLength = 10;
      } else {
        this.country_codeLength = 13;
      }
      break;
     }
  }
  $('.auto-loader').css('display', 'none');
}
}, 0);
   this.gtm.FacebookInitialization();
}
////////////////////////// login with social network////////////////
public ngAfterViewInit() {                                                                // G+ Signin api call start
  this.googleInit();
}
private deleteCookie(): any {  // for twitter
  document.cookie = 'PHPSESSID' + '=; Path=/;Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
  this.localstorage.removeItem('twitterTime');
}
private twitterGm() {
  let network;
  network = this.networkService.getPopupStatus();
 if (network === true) {
     this.deleteCookie();
         let x;
         x = new Date();
         let y;
         y = x.getTime();
    //  $('#twitterlogin1').attr('href', environment.twitterLogin + '&ver=' + y);
    location.href = environment.twitterLogin + '&ver=' + y;
     this.pageName = 'sign in/twitter';
     this.gtm.sendPageName(this.pageName);
     this.gtm.sendEvent();
     this.qgraphevent('signin_initiated', {'method': 'social_twitter', 'country' : this.countrycode, 'state': this.localstorage.getItem('state_code')});
     location.href = environment.twitterLogin + '&ver=' + y;
  }
}
private googleGm() {
  let network;
  network = this.networkService.getPopupStatus();
  this.pageName = 'sign in/google';
  this.gtm.sendPageName(this.pageName);
  this.gtm.sendEvent();
  this.qgraphevent('signin_initiated', {'method': 'social_google', 'country' : this.countrycode, 'state': this.localstorage.getItem('state_code')});
}
private facebookGm() {
   this.pageName = 'sign in/facebook';
   this.gtm.sendPageName(this.pageName);
   this.gtm.sendEvent();
   this.qgraphevent('signin_initiated', {'method': 'social_fb', 'country' : this.countrycode, 'state': this.localstorage.getItem('state_code')});
}
/////////////////////////////////// googleApi///////////////////////////
private googleInit() {
    if ( this.window && this.window.gapi) {
    this.window.gapi.load('auth2', () => {
       let that;
       that = this;
        this.auth2 = this.window.gapi.auth2.init({
        client_id:   that.GOOGLE_CLIENT_ID,
        cookiepolicy: 'single_host_origin',
        scope: 'profile'
      });

      this.attachSignin(this.document.getElementById('google'));
    });
  }
}
private attachSignin(element) {
    this.auth2.attachClickHandler(element, {},
      (googleUser) => {
          let profile;
          profile = googleUser.getBasicProfile();
  this.googleAccessToken = this.window.gapi.auth2.getAuthInstance().currentUser.get().getAuthResponse(true).access_token;
  this.googleloginApi(this.googleAccessToken);
  }, error => {
    // console.log(error, 'Error');
  });
  }
  ///////////////////////////// facebookApi////////////////////
  private checkLoginState() {
  let network;
  network = this.networkService.getPopupStatus();
 if (network === true) {
    this.error_message_Login = this.localstorage.getItem('header');
    if (this.error_message_Login != null) {
          if (this.error_message_Login === 'false') {
                  this.error_message_Login = 'TOAST_MESSAGES.TRACKING';
                  this.callToast();
          }
    }
          FB.getLoginStatus(response => {
      this.statusChangeCallback(response);
      });
  }
}
private statusChangeCallback(response: any) {
    if (response.status === 'connected') {
        this.login();
    } else {
        this.login();
    }
}
  private login() {
    FB.login(result => {
        this.loged = true;
        this.token1 = result;
        if (this.token1.authResponse != null) {
        this.FBTOKEN = this.token1.authResponse.accessToken;
         }
         this.facebookloginApi(this.FBTOKEN);
        this.me();
    }, { scope: 'public_profile,email' });
}
private me() {
    FB.api('/me?fields=id,name,first_name,email,gender,picture.width(150).height(150),age_range',
        function(result) {
            if (result && !result.error) {
                this.user = result;
            } else {
              // todo
            }
        });
}
//////////////////////////////// facebookApi///////////////
private googleloginApi(acces): any {
  if (acces) {
    this.removeSignin();
    this.userapi.v1UserLogingoogleGet(acces).timeout(environment.timeOut).subscribe(response => {
    this.loginMethod = 'login';
    this.saveToken = response.token;
    this.checkGdprNode(response.token, 'google');
    }, err => {
      this.openSignin();
                if (err.name === 'TimeoutError') {
                  this.error_message_Login = 'MESSAGES.TRY_LATER';
                  this.callToast();
                } else if (err.status === 404) {
                  this.qgraphevent('signin_failure', {'method': 'social_google', 'country' : this.countrycode, 'state': this.localstorage.getItem('state_code') });
                  this.GAUpdateCommon('LoginFailed', 'googleplus');
                  this.gtm.sendErrorEvent('api', err);
                  this.loginPageFlag = false;            // to cal GDPR screen                  this.gdprFlag = true;
                  this.gdprFlag = true;
                  this.socialFlag = true;
                  this.socialType = 'google';
                  this.loginFrom = 'register';
                  this.simulateUserGesture();
                  $('#loaderPage').css('display', 'block');
                  this.triggerClick();
                } else {
                  this.error_message_Login = 'MESSAGES.TRY_LATER';
                  this.callToast();
                }
    });
  }
}
private googleRegister(): any {
  this.createObject(this.googleAccessToken);   // to create object with token and additional values
  if (this.googleObj) {
     this.userapi.v1UserRegistergooglePost(this.googleObj).timeout(environment.timeOut).subscribe(response => {
       this.loginMethod = 'register';
       this.saveToken = response.token;
       // this.CommonConfigCall(this.saveToken);
        setTimeout(() => {
       this.updateSettingApi(this.saveToken, 'google', 'register');
       this.qgraphevent('signup_success', {'method': 'social_google', 'country' : this.countrycode, 'state': this.localstorage.getItem('state_code')});
        }, 0);
       this.GAUpdateCommon('RegisterSuccess', 'googleplus');
      }, error => {
             this.openSignin();
             if (error.name === 'TimeoutError') {
             this.error_message_Login = 'MESSAGES.TRY_LATER';
               this.callToast();
             } else if (error.status === 404) {
                this.error_message_Login  = this.errors.message;
                setTimeout(() => {
                     if (this.error_message_Login) {
                          this.callToast();
                      }
                }, 3000);
             } else if (error.status === 400) {
               this.loginPageFlag = true;
               this.gdprFlag = false;
                this.error_message_Login = 'MESSAGES.TRY_LATER';
                this.callToast();
             } else {
               this.error_message_Login = 'MESSAGES.TRY_LATER';
               this.callToast();
             }
           this.GAUpdateCommon('RegisterFailed', 'googleplus');
           this.qgraphevent('signup_failure', {'method': 'social_google', 'country' : this.countrycode, 'state': this.localstorage.getItem('state_code')});
           this.gtm.sendErrorEvent('api', error);
     });
  }
}
private facebookloginApi(FBTOKEN) {
 if (FBTOKEN) {
   this.removeSignin();
   this.userapi.v1UserLoginfacebookGet(FBTOKEN).timeout(environment.timeOut).subscribe(response => {
     this.loginMethod = 'login';
     this.saveTokenFacebook = response.token;
     this.checkGdprNode(this.saveTokenFacebook, 'facebook');    // check GDPR node
   }, error => {
        this.openSignin();
        if (error.name === 'TimeoutError') {
          this.error_message_Login = 'MESSAGES.TRY_LATER';
          this.callToast();
        } else if (error.status === 404) {
            this.qgraphevent('signin_failure', {'method': 'social_fb', 'country' : this.countrycode, 'state': this.localstorage.getItem('state_code') });
            this.GAUpdateCommon('LoginFailed', 'facebook');
            this.gtm.sendErrorEvent('api', error);
            this.loginPageFlag = false;        // for GDPR Screen
            this.gdprFlag = true;
            this.socialFlag = true;
            this.socialType = 'facebook';
            this.loginFrom = 'register';
            this.simulateUserGesture();
            $('#loaderPage').css('display', 'block');
            this.triggerClick();
        } else {
          this.error_message_Login = 'MESSAGES.TRY_LATER';
          this.callToast();
        }
   });
  }
}
private facebookRegister(): any {
this.createObject(this.FBTOKEN);   // create object with token and additional field
  if (this.googleObj) {
    this.userapi.v1UserRegisterfacebookPost(this.googleObj).timeout(environment.timeOut).subscribe(response => {
        this.loginMethod = 'register';
        this.saveTokenFacebook = response.token;
        // this.CommonConfigCall(this.saveTokenFacebook);
        setTimeout(() => {
        this.updateSettingApi(this.saveTokenFacebook, 'facebook', 'register');
          this.qgraphevent('signup_success', {'method': 'social_fb', 'country' : this.countrycode, 'state': this.localstorage.getItem('state_code')});
        }, 0);
        this.GAUpdateCommon('RegisterSuccess', 'facebook');
    }, errors => {
           this.openSignin();
           if (errors.name === 'TimeoutError') {
             this.error_message_Login = 'MESSAGES.TRY_LATER';
             this.callToast();
            } else if (errors.status === 404) {
              this.error_message_Login  = this.errors.message;
              setTimeout(() => {
                  if (this.error_message_Login) {
                    this.callToast();
                  }
              }, 3000);
            } else if (errors.status === 400 || errors.status === 401 ) {
               this.loginPageFlag = true;
               this.gdprFlag = false;
                this.error_message_Login = 'MESSAGES.TRY_LATER';
                this.callToast();
            } else {
               this.error_message_Login = 'MESSAGES.TRY_LATER';
               this.callToast();
            }
            this.GAUpdateCommon('RegisterFailed', 'facebook');
            this.qgraphevent('signup_failure', {'method': 'social_fb', 'country' : this.countrycode, 'state': this.localstorage.getItem('state_code')});
      this.gtm.sendErrorEvent('api', errors);
    });
  }
}
private createObject(accessToken): any {
  let policyValues, googleObjInt, country_Promotion;
  country_Promotion = this.settingsService.getCountryPromotionalValue();

  policyValues = [];
  for (let i = 0; i < 4; i++) {
      if (!(this.receivedValue.sendValues[i].status) || this.receivedValue.sendValues[i].status === undefined) {
          policyValues[i] = 'na';
      } else if (!(this.receivedValue.sendValues[i].userValue)) {
          policyValues[i] = 'no';
      } else if (this.receivedValue.sendValues[i].userValue === true) {
         policyValues[i] = 'yes';
      }
  }
  googleObjInt = {
     'token' : accessToken,
     'mac_address': '',
     'ip_address': '',
     'registration_country': '',
     'additional': {
        'gdpr_policy': [{
          'country_code': this.country_code,
          'gdpr_fields': {
            'policy': policyValues[0],
            'profiling': policyValues[1],
            'age': policyValues[2],
            'subscription': policyValues[3]
          }
        }],
        'guest_token': this.guest_token,
        'sourceapp' : 'Web',
        'version_number' : this.version_number,
        'promotional': {
            'on': country_Promotion.on,
            'token': country_Promotion.token
        },
        'first_time_login': '1'
      }
    };
    this.googleObj = this.gtm.checkUpdateCampaign(googleObjInt);
}
private updateSettingApi(token, method, type): any {
  if (token) {
    // this.CommonConfigCall(token);
      let params;
       params = 'bearer ' + token;
       this.config = {
          apiKey: params,
          username: '',
          password: '',
          accessToken: '',
          withCredentials: false
        };
  }
  let policyValues;
  policyValues = [];
  for (let i = 0; i < 4; i++) {
      if (!(this.receivedValue.sendValues[i].status) || this.receivedValue.sendValues[i].status === undefined) {
          policyValues[i] = 'na';
      } else if (!(this.receivedValue.sendValues[i].userValue)) {
          policyValues[i] = 'no';
      } else if (this.receivedValue.sendValues[i].userValue === true) {
         policyValues[i] = 'yes';
      }
  }
  if (!this.gdprCountryChange) {  // register
    let gdprValue, gdprsettings;
    gdprValue = [{
            'country_code': this.countrycode,
            'gdpr_fields': {
                'policy': policyValues[0],
                'profiling': policyValues[1],
                'age': policyValues[2],
                'subscription': policyValues[3]
                 }
            }];
    gdprsettings = {
              'key': 'gdpr_policy',
              'value': JSON.stringify(gdprValue)
           };
  this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
  this.userSettings.v1SettingsPost(gdprsettings).subscribe(responsePost => {
     if (type !== 'register') {    // login just reload with update GA and QG
       this.updateGMID(token, method);
     } else {                      // check for promotional
        let disp, valuecountryCode;
          disp = this.localstorage.getItem('display_language');
           valuecountryCode = this.settingsService.getCountryValueNew();
            if (valuecountryCode && valuecountryCode.length > 0) {
               this.promotional = valuecountryCode[0].promotional;
               this.countryToken = this.promotional.token;
                if (this.promotional && this.promotional.on === '1') {
                   this.promotionalAPIcallSocial(token, method);
                } else if (this.promotional && this.promotional.on === '0') {
                   this.setFirstTimeloginSocial('1', token, method);
                }
            }
     }
  }, err => {
    this.settingsFailsRegister(gdprsettings, type, token, method);
     // this.SettingapiFails();
  });
  } else {              // login
    let gdprValue1, gdprsettings;
    gdprValue1 = {
        'country_code': this.countrycode,
        'gdpr_fields': {
          'policy': policyValues[0],
          'profiling': policyValues[1],
          'age': policyValues[2],
          'subscription': policyValues[3]
        }
    };
    this.gdprValue.push(gdprValue1);
    gdprsettings = {
        'key': 'gdpr_policy',
        'value': JSON.stringify(this.gdprValue)
    };
    this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
    this.userSettings.v1SettingsPut(gdprsettings).subscribe(responsePost => {
       this.updateGMID(token, method);     // for only login
    }, err => {
      this.openSignin();
      this.error_message_Login = 'MESSAGES.TRY_LATER';
      this.callToast();
    });
  }
    if (type === 'register') {
     this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
      this.userSettings.v1SettingsGet().subscribe( response => {
        this.settingsResponse = response;
         this.cookieConcent(this.settingsResponse);
      }, err => {
        // todo
      });
  }
}
private checkGdprNode(token, method): any {
   if (token) {
    this.CommonConfigCall(token);
      this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
      this.userSettings.v1SettingsGet().subscribe( response => {
        this.settingsResponse = response;
        this.cookieConcent(this.settingsResponse);
          let gdpr_Flag;
          if ( response.length > 0) {
            for (let i = 0; i < response.length; i++) {
              if ( response[i].key === 'gdpr_policy') {
                gdpr_Flag = true;
                if (!(response[i].value[0] === '{')) {
                   this.gdprValue = JSON.parse(response[i].value);
                   let flagcheck = false;
                    for (let j = 0; j < this.gdprValue.length; j++) {
                    if (this.countrycode === this.gdprValue[j].country_code) {
                      flagcheck = true;
                      break;
                    } else if (j === this.gdprValue.length - 1) {   // no country code match so show GDPR screen with put request
                        flagcheck = false;
                      }
                    }
                    if (flagcheck) {
                      this.updateGMID(token, method);
                    } else {
                      this.gdprCountryChange = true;
                      this.showScreen(token, method);
                    }
                 } else {
                     this.userSettings.v1SettingsDelete('gdpr_policy', token).subscribe(responseput => {
                        this.showScreen(token, method);
                     });
                }
              }
            }
            if (gdpr_Flag === undefined) {
              this.getSocialUserDetails(token, method);
            }
          } else {
            if (gdpr_Flag === undefined) {
              this.getSocialUserDetails(token, method);
            }
          }
      }, err => {
        // todo
      });
    }
}
private getSocialUserDetails(token, method): any {
   let userDetails;
    userDetails = new UserApi(this.http, null, this.config);
    userDetails.v1UserGet().timeout(environment.timeOut).subscribe(value => {
      this.userData = value;
      this.localstorage.setItem('ID', this.userData.id);
      if (value.additional.gdpr_policy) {
              for (let j = 0; j < value.additional.gdpr_policy.length; j++) {
                  if (this.countrycode === value.additional.gdpr_policy[j].country_code) {
                        let gdprValue;
                          gdprValue = [{'country_code': this.countrycode,
                                'gdpr_fields': {
                                  'policy': value.additional.gdpr_policy[j].gdpr_fields.policy,
                                  'profiling': value.additional.gdpr_policy[j].gdpr_fields.profiling,
                                  'age': value.additional.gdpr_policy[j].gdpr_fields.age,
                                  'subscription': value.additional.gdpr_policy[j].gdpr_fields.subscription
                                }}];
                       const gdpr_settings = {
                        'key': 'gdpr_policy',
                        'value': JSON.stringify(gdprValue)
                      };
                    this.userSettings.v1SettingsPost(gdpr_settings).subscribe(responsePost => {
                     this.updateGMID(token, method);
                    }, err => {
                        this.SettingapiFails();
                    });
                  } else {
                   this.showScreen(token, method);
                  }
             }
      } else if (value.additional.gdpr_policy === undefined) { // GDPR post request no node
              this.showScreen(token, method);
        }
     }, err => {
              this.gtm.sendErrorEvent('api', err);
              if (err.name === 'TimeoutError') {
                this.error_message_Login = this.try_later;
                this.callToast();
              } else {
                this.errors = err.json();
                this.error_message_Login = this.errors.message;
                this.callToast();
              }
        });
}
private showScreen(token, method) {  // to show GDPR screen only for login flow
  this.loginPageFlag = false;
  this.gdprFlag = true;
  this.socialFlag = true;
  this.socialType = method;
  this.loginFrom = 'login';    // to differentate register r login
  this.sendToken = token;
  this.triggerClick();
  this.headerservicesService.loginComponentChange(true);
  this.headerservicesService.loginMobileChange(false);
  this.headerservicesService.loginEmailChange(false);
  this.headerservicesService.registerMobilechange(false);
  this.headerservicesService.bgImageValueChange(true);
  this.headerservicesService.signinDetailsChange(false);
  this.headerservicesService.signinRightTopChange(true);
  this.headerservicesService.signinLeftChange(true);
  this.simulateUserGesture();
}
private triggerClick() {
  let el: HTMLElement = this.loaderPage.nativeElement as HTMLElement;
  el.click();
}
private updateGMID(userId, method) {
    let userDetails;
 this.CommonConfigCall(userId);
  userDetails = new userApi.UserApi(this.http, null, this.config);
  userDetails.v1UserGet().timeout(environment.timeOut).subscribe(value => {
    this.userId = value.id;
    this.localstorage.setItem('ID', this.userId);
      if (method === 'facebook') {
          this.qgraphevent('signin_success', {'method': 'social_fb', 'country' : this.countrycode, 'state': this.localstorage.getItem('state_code')});
         this.GAUpdateCommon('LoginSuccess', 'facebook');
      }
      if (method === 'google') {
        this.qgraphevent('signin_success', {'method': 'social_google', 'country' : this.countrycode, 'state': this.localstorage.getItem('state_code')});
        this.GAUpdateCommon('LoginSuccess', 'googleplus');
      }
    this.updatePromotionSocial(value, userId, method);
  }, err => {
      this.userId = 'NA';
      this.callReload();
      this.gtm.sendErrorEvent('api', err);
  });
}
private SettingapiFails() {
  $('#loaderPage').css('display', 'none');
  this.error_message_Login = 'MESSAGES.TRY_LATER';
  this.callToast();
  this.gdprFlag = false;
  this.headerservicesService.registerMobilechange(false);
  this.headerservicesService.bgImageValueChange(true);
  this.headerservicesService.signinDetailsChange(true);
  this.headerservicesService.signinRightTopChange(true);
  this.headerservicesService.signinLeftChange(true);
  let scope;
  scope = this;
  setTimeout(function() { scope.callReload(); }, 2500);
}
private callReload() {
  $('#SignIncomponent').css('visibility', 'hidden');
  $('#loaderPage').css('display', 'block');
  this.localstorage.setItem('googletag', 'false');
  // if (!state) {
  //   location.href = this.window.location.origin + this.previousUrl;
  // } else {
    this.changeRoute();
  // }
}
private confirmationPage(type, token) {
  this.localstorage.setItem('googletag', 'false');
  $('#loaderPage').css('display', 'none');
  this.headerservicesService.RegisterSuccessChange(true);
  this.headerservicesService.loginComponentChange(false);
  this.headerservicesService.loginMobileChange(false);
  this.headerservicesService.loginEmailChange(false);
  this.headerservicesService.registerMobilechange(false);
  this.profileActivationFlag = true;
  this.otpCheck = false;
  this.otpPlace = false;
  this.verification_email = false;
  this.registerMobile = false;
  this.registerEmail = false;
  $('#body').addClass('scrolldisbale');
  this.otp_return_keypress = false;
  this.otp_return = false;
  this.signinRightTop = false;
  this.bg_imageFlag = false;
  this.loginMobile = false;
  this.loginEmail = false;
  this.gdprFlag = false;
  this.pass();
}
private removeSignin() {
  $('#loaderPage').css('display', 'block');
  // $('#ResponsiveTop').css('display', 'none');
  this.loginMobile = false;
  this.loginEmail = false;
  this.otherContainerFlag = false;
  this.headerservicesService.signinRightTopChange(false);
  this.headerservicesService.bgImageValueChange(false);
  this.headerservicesService.signinLeftChange(false);
}
private openSignin() {
  $('#loaderPage').css('display', 'none');
  $('#ResponsiveTop').css('display', 'block');
  this.loginMobile = true;
  this.loginEmail = false;
  this.otherContainerFlag = true;
  this.headerservicesService.signinRightTopChange(true);
  this.headerservicesService.bgImageValueChange(true);
  this.headerservicesService.signinLeftChange(true);
}
private updatePromotionSocial(value, token, method) {
  this.userData = value;
  if (this.userData === undefined || this.userData.length === 0) {
      let userDetails;
      userDetails = new UserApi(this.http, null, this.config);
      userDetails.v1UserGet().timeout(environment.timeOut).subscribe(valueUser => {
      this.userData = valueUser;
      if ( this.settingsResponse.length > 0) {
        for (let i = 0; i < this.settingsResponse.length; i++) {
          if ( this.settingsResponse[i].key === 'first_time_login') {  // promotion there
            if (this.settingsResponse[i].value === '1') {
               this.localstorage.setItem('login', method);
               this.localstorage.setItem('token', token);
               this.callReload();
            } else if (this.settingsResponse[i].value === '0') {
              let disp, valuecountryCode;
              disp = this.localstorage.getItem('display_language');
                 valuecountryCode = this.settingsService.getCountryValueNew();
                 if (valuecountryCode && valuecountryCode.length > 0) {
                   this.promotional = valuecountryCode[0].promotional;
                   this.countryToken = this.promotional.token;
                  if (this.promotional && this.promotional.on === '1') {
                    this.promotionalAPIcallSocial(token, method);
                  } else if (this.promotional && this.promotional.on === '0') {
                      this.setFirstTimeloginSocial('1', token, method);
                  }
              }
            }
          } else if (i === this.settingsResponse.length - 1) {
              if (this.userData.additional.first_time_login) {
                if (this.userData.additional.promotional && this.userData.additional.promotional.on === '1') {
                     this.promotionalAPIcallSocial(token, method);
                } else if (this.userData.additional.promotional && this.userData.additional.promotional.on === '0') {
                       this.setFirstTimeloginSocial('1', token, method);
                } else {
                      this.setFirstTimeloginSocial('1', token, method);
                }
              } else {
                    this.setFirstTimeloginSocial('1', token, method);
                  }
            }
        }
      }
    }, err => {
          this.openSignin();
          this.error_message_Login = 'MESSAGES.TRY_LATER';
          this.callToast();
    });
  } else if (this.userData) {
      if ( this.settingsResponse.length > 0) {
        for (let i = 0; i < this.settingsResponse.length; i++) {
          if ( this.settingsResponse[i].key === 'first_time_login') {
               this.localstorage.setItem('login', method);
               this.localstorage.setItem('token', token);
               this.callReload();
          } else if (i === this.settingsResponse.length - 1) {
              if (this.userData.additional.first_time_login) {
                if (this.userData.additional.promotional && this.userData.additional.promotional.on === '1') {
                    this.promotionalAPIcallSocial(token, method);
                } else if (this.userData.additional.promotional && this.userData.additional.promotional.on === '0') {
                    this.setFirstTimeloginSocial('1', token, method);
                } else {
                    this.setFirstTimeloginSocial('1', token, method);
                }
              } else {
                  this.setFirstTimeloginSocial('1', token, method);
              }
          }
        }
      } else if (this.userData.additional.first_time_login) {
            if (this.userData.additional.promotional && this.userData.additional.promotional.on === '1') {
                this.promotionalAPIcallSocial(token, method);
            } else if (this.userData.additional.promotional && this.userData.additional.promotional.on === '0') {
                this.setFirstTimeloginSocial('1', token, method);
            } else {
                this.setFirstTimeloginSocial('1', token, method);
            }
      } else {
               this.setFirstTimeloginSocial('1', token, method);
          }
  }
}
private setFirstTimeloginSocial(first_time_value, token, method) {
  let first_time_settings;
  first_time_settings = {
    key: 'first_time_login',
    value: first_time_value
  };
  this.userSettings.v1SettingsPost(first_time_settings).subscribe(responsePost => {
              this.localstorage.setItem('login', method);
              this.localstorage.setItem('token', token);
              if (this.loginMethod === 'login') {
                this.callReload();
              } else {
                let userDetails;
                userDetails = new UserApi(this.http, null, this.config);
                 userDetails.v1UserGet().timeout(environment.timeOut).subscribe(valueUser => {
                  this.userId = valueUser.id;
                  this.localstorage.setItem('ID', this.userId);
                 });
                this.confirmationPage(method, token);
              }
  }, err => {
    this.errors = err.json();
    if (this.errors.message === 'Item already exists') {   // for already node there
      this.userSettings.v1SettingsPut(first_time_settings).subscribe(responsePost => {
     this.localstorage.setItem('login', method);
     this.localstorage.setItem('token', token);
     this.callReload();
    }, error => {
     this.localstorage.setItem('login', method);
     this.localstorage.setItem('token', token);
     this.callReload();
    });
    } else {
      this.localstorage.setItem('login', method);
     this.localstorage.setItem('token', token);
     this.callReload();
    }
  });
  this.checkSubSilentLogin();
}
private promotionalAPIcallSocial(token, method) {
  let promotionalData, language, tokenType;
  tokenType = this.localstorage.getItem('token');
    if (tokenType) {
      language = localStorage.getItem('UserDisplaylanguage');
    } else {
      language = localStorage.getItem('display_language');
    }
  promotionalData = {
    'createPromo' : { 'token' : this.countryToken},
    'translation' : language
  };
  this.userAction.postPromotionalData(promotionalData, token).subscribe(value => {
      let promoDesc;
      if (value && value.subscription_plan && value.subscription_plan.description) {
        promoDesc = value.json().subscription_plan.description;
      }

      localStorage.setItem('promotionalDesc', promoDesc);
      this.localstorage.setItem('dialogCheck', 'true');
      /*Set settings first-time-login = 1*/
      this.setFirstTimeloginSocial('1', token, method);
     }, err => {
        if (err.status === 404 || err.status === 400) {
          /*Set settings first-time-login = 1*/
        this.setFirstTimeloginSocial('1', token, method);
        } else {
          /*Set settings first-time-login = 0*/
        this.setFirstTimeloginSocial('0', token, method);
        }
    });
}
private cookieConcent(settingValue) {
  if (this.cookiesLocal === null || undefined) {
    this.cookiesLocal = 'na';
  }
   if (this.marketingLocal === null || undefined) {
    this.marketingLocal = 'na';
  }
  let popup, popupValue, oldCookie, oldRTRM;
  if ( settingValue.length > 0) {
    for (let i = 0; i < settingValue.length; i++) {
      if ( settingValue[i].key === 'popups') {
        popup = true;
        this.responsevalue = JSON.parse(settingValue[i].value);
         oldCookie = this.responsevalue[0].Cookies;
         oldRTRM = this.responsevalue[0].RTRM;
        if (this.responsevalue[0].Cookies === 'na' && this.responsevalue[0].RTRM === 'na' ) {
            popupValue = [{'Cookies': this.cookiesLocal, 'RTRM': this.marketingLocal}];
           const cookies_settings = {
           'key': 'popups',
           'value': JSON.stringify(popupValue)
           };
           this.userSettings.v1SettingsPut(cookies_settings).subscribe(responseput => {
             // todo
           });
        } else if (this.responsevalue[0].RTRM === 'na' || this.responsevalue[0].Cookies === 'na') {
          if (this.responsevalue[0].RTRM === 'na') {
             popupValue = [{'Cookies': oldCookie, 'RTRM': this.marketingLocal}];
          }
          if (this.responsevalue[0].Cookies === 'na') {
             popupValue = [{'Cookies': this.cookiesLocal, 'RTRM': oldRTRM}];
          }
           const cookies_settings = {
           'key': 'popups',
           'value': JSON.stringify(popupValue)
           };
           this.userSettings.v1SettingsPut(cookies_settings).subscribe(responseput => {
             // todo
           });
        }
      }
    }
    if (popup === undefined) {
       let popupValue1;
       popupValue1 = [{'Cookies': this.cookiesLocal, 'RTRM': this.marketingLocal}];
       const cookies_settings = {
       'key': 'popups',
       'value': JSON.stringify(popupValue1)
       };
      this.userSettings.v1SettingsPost(cookies_settings).subscribe(responsePost => {
        // todo
      });
      // post
    }
  } else {
     let popupValue2;
       popupValue2 = [{'Cookies': this.cookiesLocal, 'RTRM': this.marketingLocal}];
       const cookies_settings = {
       'key': 'popups',
       'value': JSON.stringify(popupValue2)
       };
      this.userSettings.v1SettingsPost(cookies_settings).subscribe(responsePost => {
        // todo
      });
  }
}
private settingsFailsRegister(gdprsettings, type, token, method): any {
  this.userSettings.v1SettingsPost(gdprsettings).subscribe(responsePost => {
     if (type !== 'register') {    // login just reload with update GA and QG
       this.updateGMID(token, method);
     } else {                      // check for promotional
        let disp, valuecountryCode;
          disp = this.localstorage.getItem('display_language');
           valuecountryCode = this.settingsService.getCountryValueNew();
            if (valuecountryCode && valuecountryCode.length > 0) {
               this.promotional = valuecountryCode[0].promotional;
               this.countryToken = this.promotional.token;
                if (this.promotional && this.promotional.on === '1') {
                   this.promotionalAPIcallSocial(token, method);
                } else if (this.promotional && this.promotional.on === '0') {
                   this.setFirstTimeloginSocial('1', token, method);
                }
            }
     }
  }, err => {
     this.SettingapiFails();
  });
}
private simulateUserGesture() {
  $('#loaderPage').focus();
  $('#loaderPage').click();
  // console.log("Simulating spinner click event");
  setTimeout(() => {
    // nothing
  }, 0);
}
////////////////////////// login with social network end////////////////
private toggleMobile() {  // if mail show number right side and asset and text
  let network;
    network = this.networkService.getPopupStatus();
    if (network === true) {
      if (this.loginEmail) {
    this.to.replaceState('signin/mobile');
    $('.modal-background').scrollTop(0);
    this.loginEmail = false;
    this.loginMobile = true;
    this.headerservicesService.loginEmailChange(false);
    this.headerservicesService.loginMobileChange(true);
    this.passwordCheck1 = false;
    this.emailCheck = false;
    this.type = false;
    this.icon = false;
    this.email_return = false;
    this.password_return = false;
    this.mobile_return = false;
    this.password_return_keypress = false;
    this.mobile_return_keypress = false;
    $('#loginMobileErrorMsg').text('');
    $('.miniCharcter').css({'display': 'none'});
    $('.mobileContainerForm').css({'border-color': '#6e6e6e'});
    $('.passwordForm').css({'border-color': '#6e6e6e'});
    $('#body').addClass('scrolldisbale');
    this.routeservice.Signal(null);
    this.signin_fail = 0;
    this.pageName = 'sign in/mobile';
    this.gtm.sendPageName(this.pageName);
    this.gtm.sendEvent();
        this.seoservice.constructHrefLang({id: 1, url: '/signin/mobile'});
        this.linkservice.addTag({ rel: 'canonical', href: window.location.origin + '/' + this.routeservice.getBaseLocation() + 'signin/mobile'} );
    } else {
    this.togglemail();
  }
}
}
private togglemail() {
   let network;
    network = this.networkService.getPopupStatus();
    this.seoservice.constructHrefLang({id: 1, url: '/signin/email'});
        this.linkservice.addTag({ rel: 'canonical', href: window.location.origin + '/' + this.routeservice.getBaseLocation() + 'signin/email'} );
    if (network === true) {
    this.to.replaceState('signin/email');
    $('.modal-background').scrollTop(0);
    this.loginEmail = true;
    this.headerservicesService.loginEmailChange(true);
    this.headerservicesService.loginMobileChange(false);
    this.passwordCheck = false;
    this.type = false;
    this.icon = true;
    this.email_return = false;
    this.password_return = false;
    this.email_return_keypress = false;
    this.password_return_keypress = false;
    $('#body').addClass('scrolldisbale');
    this.routeservice.Signal(null);
    $('#mobileNumber').val('');
    this.signin_fail = 0;
    this.pageName = 'sign in/email';
    this.gtm.sendPageName(this.pageName);
    this.gtm.sendEvent();
  }
}
private MobileRestrictNumbers(e) {
        // Allow: backspace, delete, tab, escape, enter.
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
             // Allow: Ctrl+A, Command+A
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
            // Allow: Ctrl+V, Command+V
            (e.keyCode === 86 && (e.ctrlKey === true || e.metaKey === true)) ||
             // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
        $('#mobileNumber').on('paste', function (event) {
        setTimeout(function () {
              $('#mobileNumber').val($('#mobileNumber').val().replace(/[^0-9]/g, ''));
          }, 0);
      });
}
private typechange() {  // password to show and hide
  $('#body').addClass('scrolldisbale');
    this.type = !this.type;
}
private typechangeconfirm() {  // confirm password to show and hide
  $('#body').addClass('scrolldisbale');
  this.type_confirm = !this.type_confirm;
}
private confirmshowPassword() { // confirm placeholder to top
if (this.navigator.userAgent.match(/SM-T531/) && (this.window.orientation === 0 || this.window.orientation === 180)) {
  $('.forgotPasswordMobileStep3').css({'top': '-120px'});
}
  $('#body').addClass('scrolldisbale');
  $('.mismatchPassword').css({'display': 'none'});
  $('.confirmpasswordForm').css({'border-color': '#6e6e6e'});
  $('.confirmMiniCharcter').css({'display': 'none'});
  this.confirm_password_Check = true;
  this.confirmPlace = true;
}
private showPassword() {   // mobile password placeholder to top
  if (this.navigator.userAgent.match(/SM-T531/) && (this.window.orientation === 0 || this.window.orientation === 180)) {
  $('.registerMobileContainer').css({'top': '-120px'});
  $('.forgotPasswordMobileStep3').css({'top': '-120px'});
}
  $('#body').addClass('scrolldisbale');
  $('.InvalidPassword').css({'display': 'none'});
  $('.passwordForm').css({'border-color': '#6e6e6e'});
  $('.miniCharcter').css({'display': 'none'});
  $('.ForgotminiCharcter').css({'display': 'none'});
  this.passwordCheck = true;
  this.place = true;
}
private showPassword1() {  // email password placeholder to top
  if (this.navigator.userAgent.match(/SM-T531/) && (this.window.orientation === 0 || this.window.orientation === 180)) {
  $('.outer1login_email').css({'top': '-120px'});
}
  $('.InvalidPassword').css({'display': 'none'});
  $('.pwdForm').css({'border-color': '#6e6e6e'});
  $('.pwd_rule_block').css({'display': 'none'});
  this.passwordCheck1 = true;
  this.place1 = true;
}
private showEmail() { // email placeholder to top
  if (this.navigator.userAgent.match(/SM-T531/) && (this.window.orientation === 0 || this.window.orientation === 180)) {
  $('.outer1login_email').css({'top': '-120px'});
  $('.forgotPasswordEmail').css({'top': '-120px'});
}
 $('.InvalidEmail').css({'display': 'none'});
 $('.ForgotInvalidEmail').css({'display': 'none'});
 $('.email_text_block').css({'border-color': '#6e6e6e'});
 $('.InputEmail').css({'border-color': '#6e6e6e'});
  this.emailCheck = true;
  this.emailplace = true;
}
private focusOutFunction() {  // one character dont show placeholder password mobile
  if (this.navigator.userAgent.match(/SM-T531/) && (this.window.orientation === 0 || this.window.orientation === 180)) {
  $('.registerMobileContainer').css({'top': 'auto'});
}
  $('#body').addClass('scrolldisbale');
  let count;
  count = $('#mypassword').val().length;

  if ( count < 1 ) {
    this.passwordCheck = false;
  }
  this.place = false;
}
private focusOutFunction1() {   // one character dont show placeholder email
  if (this.navigator.userAgent.match(/SM-T531/) && (this.window.orientation === 0 || this.window.orientation === 180)) {
  $('.outer1login_email').css({'top': 'auto'});
}
  $('#body').addClass('scrolldisbale');
  let count1;
  count1 = $('#email').val().length;
  if ( count1 < 1 ) {
    this.emailCheck = false;
  }
  this.emailplace = false;
}
private focusOutFunction2() {  // one character dont show placeholder email password
  if (this.navigator.userAgent.match(/SM-T531/) && (this.window.orientation === 0 || this.window.orientation === 180)) {
    $('.outer1login_email').css({'top': 'auto'});
  }
    $('#body').addClass('scrolldisbale');
    $('.InvalidPassword').css({'display': 'none'});
    $('.pwd_text').css({'border-color': '#6e6e6e'});
    $('.pwd_rule_text').css({'color': '#6e6e6e'});
  let count2;
  count2 = $('#mypassword1').val().length;
  if ( count2 < 1 ) {
    this.passwordCheck1 = false;
  }
  this.place1 = false;
}
private focusOutFunctionEmail() {  // one character dont show placeholder email forgot password
 if (this.navigator.userAgent.match(/SM-T531/) && (this.window.orientation === 0 || this.window.orientation === 180)) {
  $('.forgotPasswordEmail').css({'top': 'auto'});
 }
  $('#body').addClass('scrolldisbale');
  let count1;
  count1 = $('#forgotemail').val().length;
  if ( count1 < 1 ) {
    this.emailCheck = false;
  }
  this.emailplace = false;
}

private confirmfocusOutFunction() {
  if (this.navigator.userAgent.match(/SM-T531/) && (this.window.orientation === 0 || this.window.orientation === 180)) {
$('.forgotPasswordMobileStep3').css({'top': 'auto'});
}
  $('#body').addClass('scrolldisbale');
  let count;
  count = $('#confirmMyPassword').val().length;
  if ( count < 1 ) {
    this.confirm_password_Check = false;
  }
  this.confirmPlace = false;
}
private newPasswordfocusOut() {
if (this.navigator.userAgent.match(/SM-T531/) && (this.window.orientation === 0 || this.window.orientation === 180)) {
$('.forgotPasswordMobileStep3').css({'top': 'auto'});
}
$('#body').addClass('scrolldisbale');
  let count;
  count = $('#newpassword').val().length;
  if ( count < 1 ) {
    this.passwordCheck = false;
  }
  this.place = false;
}
private closepopup() { // login button email
      let network;
      network = this.networkService.getPopupStatus();
      this.qgraphevent('signin_initiated', {'method': 'email', 'country' : this.countrycode, 'state': this.localstorage.getItem('state_code')});
      let x;
      x = $('.email_text').val();
      let y;
      y = $('.pwd_text').val();
      let user_data, user_email;
      user_data = {
          'email':  $('.email_text').val(),
          'password': $('.pwd_text').val(),
      };
      user_email = $('.email_text').val();
      this.password_return_keypress = false;
      this.password_return = false;
      this.email_return = false;
      this.email_return_keypress = false;
      this.userapiService.setEmailid(user_data);
      this.userapi.v1UserLoginemailGetWithHttpInfo(x, y).timeout(environment.timeOut).subscribe(response => {
      setTimeout(() => {
        this.qgraphevent('signin_success', {'method': 'email', 'country' : this.countrycode, 'state': this.localstorage.getItem('state_code')});
      }, 3000);
      this.responseEmail = response.json();
      this.token = this.responseEmail.token;
      this.error_message_Login = this.responseEmail.message;
      this.login_type = 'email';
      this.login_type_caps = 'Email';
      if (this.token) {
        this.CommonConfigCall(this.token);
        this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
        this.userSettings.v1SettingsGet().subscribe(responseSetting => {
          this.settingsResponse = responseSetting;
          this.cookieConcent(this.settingsResponse);
          let gdpr_Flag, firstTimeLoginNode;
          if ( responseSetting.length > 0) {
            for (let i = 0; i < responseSetting.length; i++) {
              if ( responseSetting[i].key === 'gdpr_policy') {
                gdpr_Flag = true;
                if (!(responseSetting[i].value[0] === '{')) {
                  this.gdprValue = JSON.parse(responseSetting[i].value);
                    let login = false;

                  for (let j = 0; j < this.gdprValue.length; j++) {
                   let k;
                   k = j;
                  if (this.countrycode === this.gdprValue[j].country_code) {
                    login = true;
                    break;
                    } else if ((k === this.gdprValue.length - 1) && login === false) {
                        login = false;
                        this.gdprCountryChange = true;
                        this.gdprFlag = true;
                        this.loginPageFlag = false;
                    }
                  }
                    if (login) {
                      this.GAUpdateCommon('LoginSuccess', this.login_type);
                      this.updatePromotion(this.userData);
                    }
                  } else {
                     this.userSettings.v1SettingsDelete('gdpr_policy', this.token).subscribe(responseput => {
                          this.gdprFlag = true;
                        this.loginPageFlag = false;
                     });
                  }
              }
              if ( responseSetting[i].key === 'first_time_login') {
                  firstTimeLoginNode = true;
              }
            }
            if (gdpr_Flag === undefined) {
              this.getUserDetails();
            }
            if (firstTimeLoginNode === undefined) {
              setTimeout(() => {
                if (!this.qgraph || this.qgraph === undefined) {
                  if (this.window.qg) {
                    qg('event', 'user_verification_status', {'verified': 'true', 'email': user_email, 'country' : this.countrycode, 'state': this.localstorage.getItem('state_code')});
                  }
                }
              }, 3000);
            }
          } else {
          if (gdpr_Flag === undefined) {
              this.getUserDetails();
            }
          }
        });
     }
  }, err => {
      this.signin_fail++;
      if (err.name === 'TimeoutError') {
        this.error_message_Login = this.try_later;
        this.callToast();
        this.password_return_keypress = true;
        this.password_return = true;
        this.email_return = true;
        this.email_return_keypress = true;
      } else {
      this.errors = err.json();
      this.qgraphevent('signin_failure', {'method': 'email', 'country' : this.countrycode, 'state': this.localstorage.getItem('state_code')});
      if (err.status === 401) {
      this.error_message_Login = this.errors.message;
      if (this.errors.message === 'The email address of the user is not confirmed.') {  // resendlink page without verfiying link
       this.setDisplay(this.token);
       this.callToast();
       this.passwordCheck1 = false;
       this.emailCheck = false;
       this.type = false;
       this.email_return = false;
       this.password_email_return = false;
       this.password_email_return_keypress = false;
       this.password_return = false;
       this.mobile_return = false;
       this.password_return_keypress = false;
       this.mobile_return_keypress = false;
       this.registerFlag = true;
       this.loginPageFlag = false;
       this.headerservicesService.LoginPageChange(false);
       this.headerservicesService.RegisterPageChange(false);
       this.headerservicesService.OtherContanierFlagChange(false);
       this.headerservicesService.loginEmailChange(false);
       this.headerservicesService.verificationEmailChange(true);
       this.email_verification = true;
       this.signin_fail++;
       this.userapi.v1UserResendconfirmationemailPost(x).timeout(environment.timeOut).subscribe(response => {
         // todo
        });
      }
    } else if (err.status === 0) {
        this.error_message_Login = this.try_later;
      }
      this.password_return_keypress = true;
      this.password_return = true;
      this.email_return = true;
      this.email_return_keypress = true;
      this.callToast();
      this.GAUpdateCommon('LoginFailed', this.login_type);
      this.gtm.sendErrorEvent('api', err);
    }
});
       this.headerservicesService.signReminderChange(false);
}
private setDisplay(n): void {
      this.userapiService.gettoken(n);
    }
private callToast() {
    let p;
    p = this.document.getElementById('snackbarLogin');
    p.className = 'show';
    setTimeout(function() { p.className = p.className.replace('show', ''); }, 5000);
}
private disableToast() {
    let p;
    p = this.document.getElementById('snackbarLogin');
    p.className = '';
}
private closepopupMobile() {  // login mobile button
      let network;
      network = this.networkService.getPopupStatus();
      this.disableToast();
      this.qgraphevent('signin_initiated', {'method': 'phone', 'country' : this.countrycode, 'state': this.localstorage.getItem('state_code')});
      this.phone_code = this.phone_code.replace(/-/g, '');
      let x;
      x = this.country_code ?  this.phone_code + $('.telNumber').val() : $('.telNumber').val();
      let y;
      y = $('#mypassword').val();
      this.password_return_keypress = false;
      this.password_return = false;
      this.email_return = false;
      this.email_return_keypress = false;
      let user_data, user_mobile;
      user_data = {
          'mobile':  this.country_code ? this.phone_code + $('.telNumber').val() : $('.telNumber').val(),
          'password':  $('#mypassword').val()
        };
        user_mobile = this.country_code ? this.phone_code + $('.telNumber').val() : $('.telNumber').val();
      this.userapiService.setEmailid(user_data);

      this.userapi.v1UserLoginmobileGetWithHttpInfo(x, y).timeout(environment.timeOut).subscribe(response => {
      setTimeout(() => {
      this.qgraphevent('signin_success', {'method': 'phone', 'country' : this.countrycode, 'state': this.localstorage.getItem('state_code')});
      },  3000);
      this.responseMobile = response.json();
      this.token = this.responseMobile.token;
      this.error_message_Login = this.responseMobile.message;
      this.login_type = 'mobile';
      this.login_type_caps = 'Mobile';
      if (this.token) {
       this.CommonConfigCall(this.token);
        this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
        this.userSettings.v1SettingsGet().subscribe(responseSetting => {
          this.settingsResponse = responseSetting;
          this.cookieConcent(this.settingsResponse);
          let gdpr_Flag, firstTimeLoginNode;
          if ( responseSetting.length > 0) {
            for (let i = 0; i < responseSetting.length; i++) {
              if ( responseSetting[i].key === 'gdpr_policy') {
                gdpr_Flag = true;
               if (!(responseSetting[i].value[0] === '{')) {
                  this.gdprValue = JSON.parse(responseSetting[i].value);
                    let login = false;
                  for (let j = 0; j < this.gdprValue.length; j++) {
                    let k;
                    k = j;
                  if (this.countrycode === this.gdprValue[j].country_code) {
                    login = true;
                    break;
                    } else if ((k === this.gdprValue.length - 1) && login === false) {
                        login = false;
                        this.gdprCountryChange = true;
                        this.gdprFlag = true;
                        this.loginPageFlag = false;
                    }
                  }
                  if (login) {
                    this.GAUpdateCommon('LoginSuccess', this.login_type);
                    this.updatePromotion(this.userData);
                  }
                } else {
                     this.userSettings.v1SettingsDelete('gdpr_policy', this.token).subscribe(responseput => {
                          this.gdprFlag = true;
                        this.loginPageFlag = false;
                     });
                  }
              }
              if ( responseSetting[i].key === 'first_time_login') {
                  firstTimeLoginNode = true;
              }
            }
            if (gdpr_Flag === undefined) {
              this.getUserDetails();
            }
            if (firstTimeLoginNode === undefined) {
               setTimeout(() => {
                if (!this.qgraph || this.qgraph === undefined) {
                  if (this.window.qg) {
                    qg('event', 'user_verification_status', {'verified': 'true', 'mobile': user_mobile, 'country' : this.countrycode, 'state': this.localstorage.getItem('state_code')});
                  }
                }
               }, 3000);
            }
          } else {
          if (gdpr_Flag === undefined) {
              this.getUserDetails();
            }
          }

        });
      }
  }, err => {
      this.signin_fail++;
      if (err.name === 'TimeoutError') {
        this.error_message_Login = this.try_later;
        this.callToast();
        this.password_return_keypress = true;
        this.password_return = true;
        this.email_return = true;
        this.email_return_keypress = true;
        this.signin_fail++;
      } else {
      this.errors = err.json();
      this.qgraphevent('signin_failure', {'method': 'phone', 'country' : this.countrycode, 'state': this.localstorage.getItem('state_code')});
      if (err.status === 401) {
      this.error_message_Login = this.errors.message;
      if (this.errors.message === 'The phone number of the user is not confirmed.') {  // without opt if closees opt page
       this.setDisplay(this.token);
       this.callToast();
       this.to.replaceState('register/mobile');
       this.passwordCheck = false;
       this.type = false;
       this.email_return = false;
       this.password_return = false;
       this.email_return_keypress = false;
       this.password_return_keypress = false;
       this.registerFlag = true;
       this.loginPageFlag = false;
       this.headerservicesService.LoginPageChange(false);
       this.headerservicesService.RegisterPageChange(false);
       this.headerservicesService.OtherContanierFlagChange(false);
       this.headerservicesService.loginMobileChange(false);
       this.headerservicesService.verificationMobileChange(true);
       this.mobile_verification = true;
       this.timer_true = true;
       this.signin_fail++;
       this.userapi.v2UserResendconfirmationmobilePost(x).subscribe( response => {
         // todo
        });
      }
    } else if (err.status === 0) {
        this.error_message_Login = this.try_later;
      }
      this.password_return_keypress = true;
      this.password_return = true;
      this.email_return = true;
      this.email_return_keypress = true;
      this.callToast();
      this.GAUpdateCommon('LoginFailed', this.login_type);
      this.gtm.sendErrorEvent('api', err);
}
});
       this.headerservicesService.signReminderChange(false);
}

private getUserDetails() {
        let userDetails;
        userDetails = new UserApi(this.http, null, this.config);
        userDetails.v1UserGet().timeout(environment.timeOut).subscribe(value => {
          this.userData = value;
          this.userId = value.id;
          this.localstorage.setItem('ID', this.userId);
          if (value.additional.gdpr_policy) {
                if (this.countrycode === value.additional.gdpr_policy[0].country_code) {
                  let gdprValue;
                       gdprValue = [{'country_code': this.countrycode,
                          'gdpr_fields':
                          {
                            'policy': value.additional.gdpr_policy[0].gdpr_fields.policy,
                            'profiling': value.additional.gdpr_policy[0].gdpr_fields.profiling,
                            'age': value.additional.gdpr_policy[0].gdpr_fields.age,
                            'subscription': value.additional.gdpr_policy[0].gdpr_fields.subscription
                          }
                        }];
             const gdpr_settings = {
              'key': 'gdpr_policy',
              'value': JSON.stringify(gdprValue)
            };
              this.userSettings.v1SettingsPost(gdpr_settings).subscribe(responsePost => {
              this.GAUpdateCommon('LoginSuccess', this.login_type);
              this.updatePromotion(value);
            },
            err => {
              this.error_message_Login = this.try_later;
              this.callToast();
            });
                } else {
                  this.gdprFlag = true;
                  this.loginPageFlag = false;
                }

          } else if (value.additional.gdpr_policy === undefined) {
            this.gdprFlag = true;
            this.loginPageFlag = false;
          }
        },
        err => {
          if (err.name === 'TimeoutError') {
        this.error_message_Login = this.try_later;
        this.callToast();
      } else {
      this.errors = err.json();
      this.error_message_Login = this.errors.message;
      this.callToast();
      }
      this.gtm.sendErrorEvent('api', err);
        });
}

private updatePromotion(value) {
  this.userData = value;
  if (this.userData === undefined || this.userData.length === 0) {
    let userDetails;
        userDetails = new UserApi(this.http, null, this.config);
        userDetails.v1UserGet().timeout(environment.timeOut).subscribe(valueUser => {
          this.userData = valueUser;
          this.localstorage.setItem('ID', this.userData.id);
          if ( this.settingsResponse.length > 0) {
            for (let i = 0; i < this.settingsResponse.length; i++) {
                  let loop_complete;
              if ( this.settingsResponse[i].key === 'first_time_login') {
                if (this.settingsResponse[i].value === '1') {
                loop_complete = true;
                this.localstorage.setItem('login', this.login_type_caps);
                this.localstorage.setItem('googletag', 'false');
                this.localstorage.setItem('token', this.token);
                // location.href = this.window.location.origin + this.previousUrl;
                this.changeRoute();
                break;
                } else if (this.settingsResponse[i].value === '0') {
                  this.promotional = this.settingsService.getCountryPromotionalValue();
                      if (this.promotional && this.promotional.on === '1') {
                        this.promotionalAPIcall();
                      } else if (this.promotional && this.promotional.on === '0') {
                          this.setFirstTimelogin('1');
                      }
                  }
               } else if (i === (this.settingsResponse.length - 1) && loop_complete === undefined) {
                 if (this.userData.additional.first_time_login) {
                   if (this.userData.additional.promotional && this.userData.additional.promotional.on === '1') {
                     this.promotionalAPIcall();
                     } else if (this.userData.additional.promotional && this.userData.additional.promotional.on === '0') {
                       this.setFirstTimelogin('1');
                     } else {
                       this.setFirstTimelogin('1');
                     }
                  } else {
                    this.setFirstTimelogin('1');
                  }
               }
            }
           }
        });
  } else if (this.userData) {
          this.localstorage.setItem('ID', this.userData.id);
          if ( this.settingsResponse.length > 0) {
            for (let i = 0; i < this.settingsResponse.length; i++) {
              if ( this.settingsResponse[i].key === 'first_time_login') {
                this.localstorage.setItem('login', this.login_type_caps);
                this.localstorage.setItem('googletag', 'false');
                this.localstorage.setItem('token', this.token);
                // location.href = this.window.location.origin + this.previousUrl;
                this.changeRoute();
              } else if (i === this.settingsResponse.length - 1) {
                 if (this.userData.additional.first_time_login) {
                   if (this.userData.additional.promotional && this.userData.additional.promotional.on === '1') {
                     this.promotionalAPIcall();
                   } else if (this.userData.additional.promotional && this.userData.additional.promotional.on === '0') {
                     this.setFirstTimelogin('1');
                   } else {
                       this.setFirstTimelogin('1');
                   }
                  } else {
                    this.setFirstTimelogin('1');
                  }
               }
            }
           } else if (this.userData.additional.first_time_login) {
                   if (this.userData.additional.promotional && this.userData.additional.promotional.on === '1') {
                     this.promotionalAPIcall();
                   } else if (this.userData.additional.promotional && this.userData.additional.promotional.on === '0') {
                     this.setFirstTimelogin('1');
                   } else {
                       this.setFirstTimelogin('1');
                   }
                  } else {
                    this.setFirstTimelogin('1');
                  }
  }

}
private promotionalAPIcall() {
  let promotionalData;
  let country_Promotion;
   country_Promotion = this.settingsService.getCountryPromotionalValue();
    promotionalData = {
      'createPromo' : { 'token' : country_Promotion.token},
      'translation' :  localStorage.getItem('display_language')
    };
    this.userAction.postPromotionalData(promotionalData, this.token).subscribe(value => {
      let promoDesc;
      if (value && value.subscription_plan && value.subscription_plan.description) {
        promoDesc = value.json().subscription_plan.description;
      }

      localStorage.setItem('promotionalDesc', promoDesc);
      /*Set settings first-time-login = 1*/
      this.setFirstTimelogin('1');
      this.localstorage.setItem('dialogCheck', 'true');

     }, err => {
       if (err.status === 404 || err.status === 400) {
        /*Set settings first-time-login = 1*/
        this.setFirstTimelogin('1');
      } else {
        /*Set settings first-time-login = 0*/
        this.setFirstTimelogin('0');
      }
    });
}
private setFirstTimelogin(first_time_value) {
  let first_time_settings;
  first_time_settings = {
    key: 'first_time_login',
    value: first_time_value
  };
  this.userSettings.v1SettingsPost(first_time_settings).subscribe(responsePost => {

              this.localstorage.setItem('login', this.login_type_caps);
              this.localstorage.setItem('googletag', 'false');
              // location.href = this.window.location.origin + this.previousUrl;
              this.localstorage.setItem('token', this.token);
              this.changeRoute();
  }, err => {
    this.errors = err.json();
    if (this.errors.message === 'Item already exists') {
      this.userSettings.v1SettingsPut(first_time_settings).subscribe(responsePost => {
      this.localstorage.setItem('login', this.login_type_caps);
      this.localstorage.setItem('googletag', 'false');
      // location.href = this.window.location.origin + this.previousUrl;
      this.localstorage.setItem('token', this.token);
      this.changeRoute();
    }, error => {
      location.href = this.window.location.origin + this.previousUrl;
    });
    } else {
      location.href = this.window.location.origin + this.previousUrl;
    }
  });
  this.checkSubSilentLogin();
}
private Timerupdate(reg) {
  this.timer_true = reg.t1;
}
  private emailValidation(): void {
     let count1;
     count1 = $('#email').val().length;
    if (count1 >= 0 ) {

      let scope;
      scope = this;
    $(this.document).ready(function() {
        let email_text;
        email_text = $('#email').val().trim();
        let re;
        // re = /^([a-zA-Z0-9]+)(([^-=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^-=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
          // re = /^([a-zA-Z0-9._+-]+)(@(?=.{1,}.[^.]*$)+)([A-Za-z0-9-]+)(.[A-Za-z0-9]+)*(.[A-Za-z]{1,})$/;
         // re = /^([_A-Za-z0-9-]+)(.[_A-Za-z0-9-]+)*(@(?=.{1,}.[^.]*$)+)([A-Za-z0-9-]+)(.[A-Za-z0-9]+)*(.[A-Za-z]{1,})$/;
            // re = /^([a-zA-Z0-9]+)(([^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
           // re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
        // re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/; // to validate c.abcd@gags.co
          re = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?/; // to validate c.@asd.adf and caps 
         let emailTest;
         emailTest = re.test(email_text);
         if (email_text.length === 0 ) {
              $('#loginEnterMsg').css({'display': 'block'});
              $('#loginErrMsg').css({'display': 'none'});
            } else {
              $('#loginEnterMsg').css({'display': 'none'});
              $('#loginErrMsg').css({'display': 'block'});
            }
          if (emailTest === false) {
               $('.email_text_block').css({'border-color': 'red'});
              scope.email_return = false;
          } else {
            scope.email_return = true;
            $('#loginErrMsg').css({'display': 'none'});
          }
          return scope.email_return;
      });
    }
    }

private emailValidationkeypress() {
  let count1;
  count1 = $('#email').val().length;
    if (count1 >= 0) {
      let scope;
      scope = this;
    $(this.document).ready(function() {
        let email_text;
        email_text = $('#email').val().trim();
          let re;
        // re = /^([a-zA-Z0-9]+)(([^-=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^-=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
          // re = /^([a-zA-Z0-9._]+)(@(?=.{1,}.[^.]*$)+)([A-Za-z0-9-]+)(.[A-Za-z0-9]+)*(.[A-Za-z]{1,})$/;
          // re = /^([_A-Za-z0-9-]+)(.[_A-Za-z0-9-]+)*(@(?=.{1,}.[^.]*$)+)([A-Za-z0-9-]+)(.[A-Za-z0-9]+)*(.[A-Za-z]{1,})$/;
            // re = /^([a-zA-Z0-9]+)(([^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
           // re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
          // re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/; // to validate c.abcd@gags.co 
          re = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?/; // to validate c.@asd.adf and caps 
          let emailTest;
          emailTest = re.test(email_text);
          if (emailTest === false) {
              scope.email_return_keypress = false;
          } else {
            scope.email_return_keypress = true;
          }
          return scope.email_return_keypress;
      });
    }

}
 private pwdValidationEmail(): any {
     let count1;
     count1 = $('#mypassword1').val().length;
    if (count1 >= 0 ) {
      let scope;
      scope = this;
      $(this.document).ready(function() {
        let pw_text;
        pw_text = $('#mypassword1').val();


         if (pw_text.length < 6) {
             $('.InvalidPassword').css({'display': 'none'});
             $('.pwdForm').css({'border-color': 'red'});
             $('.pwd_rule_text').css({'color': 'red'});
             $('.pwd_rule_block').css({'display': 'block'});
           scope.password_email_return = false;
         } else {
            scope.password_email_return = true;
          }
          return scope.password_email_return;
      });
    }
  }
  private pwdValidationKeypress(): any {
     let count1;
     count1 = $('#mypassword1').val().length;
    if (count1 >= 0) {
      let scope;
      scope = this;
      $(this.document).ready(function() {
        let pw_text;
        pw_text = $('#mypassword1').val();
         if (pw_text.length < 6) {
           scope.password_email_return_keypress = false;
         } else {
            scope.password_email_return_keypress = true;
          }
          return scope.password_email_return_keypress;
      });
    }
  }
private pwdValidationMobile(): any {
     let count1;
     count1 = $('#mypassword').val().length;
    if (count1 >= 0) {
      let scope;
      scope = this;
      $(this.document).ready(function() {
        let pw_text;
        pw_text = $('#mypassword').val();
         if (pw_text.length < 6) {
             $('.InvalidPassword').css({'display': 'none'});
             $('.passwordForm').css({'border-color': 'red'});
             $('.miniCharcter').css({'color': 'red'});
             $('.miniCharcter').css({'display': 'block'});

           scope.password_return = false;
         } else {
            scope.password_return = true;
          }
          return scope.password_return;
      });
    }
  }
 private pwdValidationMobileKeypress(): any {
     let count1;
     count1 = $('#mypassword').val().length;
     if (count1 >= 0 ) {
      let scope;
      scope = this;
      $(this.document).ready(function() {
        let pw_text;
        pw_text = $('#mypassword').val();

         if (pw_text.length < 6) {

           scope.password_return_keypress = false;
         } else {
            scope.password_return_keypress = true;
          }
          return scope.password_return_keypress;
      });
    }
  }
 private mobileEnter() {
    if (this.navigator.userAgent.match(/SM-T531/) && (this.window.orientation === 0 || this.window.orientation === 180)) {
  $('.registerMobileContainer').css({'top': '-120px'});
  $('.forgotPasswordMobile').css({'top': '-120px'});
}
   $('.mobileContainerForm').css({'border-color': '#6e6e6e'});
   $('.ForgotmobileContainerForm').css({'border-color': '#6e6e6e'});
   $('.InvalidMobile').css({'display': 'none'});
   $('.ForgotInvalidMobile').css({'display': 'none'});
}
private mobileValidation() {
 $('.registerMobileContainer').css({'top': 'auto'});
 $('.forgotPasswordMobile').css({'top': 'auto'});
    let minMobileLength = 10;
    let maxMobileLength = 10;
    if (this.selected_country.code === 'IN') {
      if (this.country_code) {
      this.regex = /^\d{10}$/;
      minMobileLength = 10;
      maxMobileLength = 10;
     } else {
      this.regex = /^\d{12}$/;
      minMobileLength = 12;
      maxMobileLength = 12;
      this.country_codeLength = 12;
     }

    } else {
      if (this.country_code) {
      this.regex = /^\d{4,20}$/;
      minMobileLength = 4;
      maxMobileLength = 20;
    }
      this.regex = /^\d{4,20}$/;
      minMobileLength = 4;
      maxMobileLength = 20;
    }

    let count1;
    count1 = $('#mobileNumber').val().length;
    if (count1 >= 0 ) {
      let scope;
      scope = this;
      $(this.document).ready(function() {

     let mobile_number;
     mobile_number = $('#mobileNumber').val();

              if (mobile_number !== undefined && mobile_number.length === 0 ) {
                $('#loginMobileEnterMsg').css({'display': 'block'});
                $('#loginMobileErrorMsg').css({'display': 'none'});
                $('#ForgotMobileEnterMsg').css({'display': 'block'});
                $('#ForgotMobileErrorMsg').css({'display': 'none'});
                 } else {
                   if (mobile_number[0] === '0' || (mobile_number.length < minMobileLength)) {
                    $('#loginMobileEnterMsg').css({'display': 'none'});
                    $('#loginMobileErrorMsg').css({'display': 'block'});
                    $('#ForgotMobileEnterMsg').css({'display': 'none'});
                    $('#ForgotMobileErrorMsg').css({'display': 'block'});
                    $('.mobileContainerForm').css({'border-color': 'red'});
                    $('.ForgotmobileContainerForm').css({'border-color': 'red'});
                   }
               }
     if ((mobile_number.length < minMobileLength) ) {
        $('.mobileContainerForm').css({'border-color': 'red'});
        $('.ForgotmobileContainerForm').css({'border-color': 'red'});
        scope.mobile_return = false;
     } else {
       // todo
            }
          });
      } else {
            this.mobile_return = true;
             $('.mobileContainerForm').css({'border-color': '#6e6e6e'});
             $('#loginMobileErrorMsg').css({'display': 'none'});
             $('#ForgotMobileErrorMsg').css({'display': 'none'});
             $('.ForgotmobileContainerForm').css({'border-color': '#6e6e6e'});
         }
         return this.mobile_return;
      }
private mobileValidationkeypress() {
    let minMobileLength = 10;
    let maxMobileLength = 10;
    if (this.selected_country.code === 'IN') {
      if (this.country_code) {
      this.regex = /^\d{10}$/;
      minMobileLength = 10;
      maxMobileLength = 10;
     } else {
      this.regex = /^\d{12}$/;
      minMobileLength = 12;
      maxMobileLength = 12;
     }
    } else {
      if (this.country_code) {
      this.regex = /^\d{4,13}$/;
      minMobileLength = 4;
      maxMobileLength = 13;
    }
      this.regex = /^\d{4,20}$/;
      minMobileLength = 4;
      maxMobileLength = 20;
    }
    let count1;
    count1 = $('#mobileNumber').val().length;
    if (count1 >= 0) {
      let scope;
      scope = this;
      $(this.document).ready(function() {

     let mobile_number;
     mobile_number = $('#mobileNumber').val();
     if ((mobile_number.length < minMobileLength)) {
        scope.mobile_return_keypress = false;
     } else {

              if ($('#mobileNumber').val().match(this.regex)) {
                scope.mobile_return_keypress = true;
              } else {
                scope.mobile_return_keypress = false;
              }
            }
      });
      } else {
          this.mobile_return_keypress = true;
         }
         return this.mobile_return_keypress;
  }

private checkLength() {
    if (!(this.email_return && this.password_email_return)) {
        $('.loginbtn_block_highlighted').css({'background-color': '#50012f', 'color': '#703055'});
        return true;
      } else {
         $('.loginbtn_block_highlighted').css({'background-color': '#bf006b', 'color': '#eeeeee'});
        return false;
    }
  }
    private checkLengthOnkeypress() {
      if (!(this.email_return_keypress && this.password_email_return_keypress)) {
          $('.loginbtn_block_highlighted').css({'background-color': '#50012f', 'color': '#703055'});
          return true;
        } else {
           $('.loginbtn_block_highlighted').css({'background-color': '#bf006b', 'color': '#eeeeee'});
          return false;
      }
    }

    private checkLengthMobilekeypress() {
      let count1;
      count1 = $('#mobileNumber').val().length;
      let count2;
      count2 = $('#mypassword').val().length;
      if (!(this.mobile_return_keypress && this.password_return_keypress)) {
          $('.registerSubmit_highlighted').css({'background-color': '#50012f', 'color': '#703055'});
          return true;
        } else {
           $('.registerSubmit_highlighted').css({'background-color': '#bf006b', 'color': '#eeeeee'});
          return false;
      }
   }
   private checkLengthMobile() {
    let count1;
    count1 = $('#mobileNumber').val().length;
    let count2;
    count2 = $('#mypassword').val().length;
    if (!(this.mobile_return && this.password_return)) {
        $('.registerSubmit_highlighted').css({'background-color': '#50012f', 'color': '#703055'});
        return true;
      } else {
         $('.registerSubmit_highlighted').css({'background-color': '#bf006b', 'color': '#eeeeee'});
        return false;
    }
   }
private dropdownforgot() {
this.dropDownCheckforgot = !this.dropDownCheckforgot;
    if (this.dropDownCheckforgot) {
      this.currentIndex = this.country_selected_index;
      let index;
      index = 'countryList' + this.currentIndex;
      let scope;
      scope = this;
        setTimeout(() => {
        document.getElementById(index).focus();
      }, 100);
    }
}
 private dropdown() {
   let browser;
   browser = this.videoService.get_browser();
  if (browser.name === 'Firefox') {
    this.fireFoxdrop = true;
   }
    this.dropDownCheck = !this.dropDownCheck;
    if (this.dropDownCheck && this.currentIndex) {
        this.currentIndex = this.country_selected_index;
      let index;
      index = 'countryList' + this.currentIndex;
      let scope;
      scope = this;
        setTimeout(() => {
        document.getElementById(index).focus();
      }, 100);
    }
  }
  private increment() {
    this.previousIndex = this.currentIndex;
    this.currentIndex ++;
    let index;
    index = 'countryList' + this.currentIndex;
    document.getElementById(index).focus();
}
private decrement() {
  this.previousIndex = this.currentIndex;
  if ((this.currentIndex - 1 ) >= 0) {
    this.currentIndex --;
    let index;
    index = 'countryList' + this.currentIndex;
  document.getElementById(index).focus();
 }
}
@HostListener('window:keydown', ['$event'])
public keyEvent(event: KeyboardEvent) {
  if ( (this.dropDownCheck || this.dropDownCheckforgot) && event.keyCode === 40 ) {
    event.preventDefault();
    this.increment();
  }
  if ((this.dropDownCheck || this.dropDownCheckforgot) && event.keyCode === 38 ) {
    event.preventDefault();
    this.decrement();
  }
  if ((this.dropDownCheck || this.dropDownCheckforgot) && event.keyCode === 9 ) {
    this.dropdown();
  }
}
   private changeValue(event, index) {
     this.dropDownCheck = false;
     this.selected_country = event;
     if (this.country_code) {
     this.country_code = '+' + event['phone-code'] + ' - ';
      }
     this.currentIndex = index;
     this.country_selected_index = index;
     $('#mobileNumber').val('');
     $('.registerSubmit_highlighted').css({'background-color': '#50012f', 'color': '#703055'});
     $('.mobileContainerForm').css({'border-color': '#6e6e6e'});
     $('.ForgotmobileContainerForm').css({'border-color': '#6e6e6e'});
     $('.InvalidMobile').css({'display': 'none'});
     $('.ForgotInvalidMobile').css({'display': 'none'});
     $('.ForgotmobileContainerForm').css({'border-color': '#6e6e6e'});
     this.phone_code = event['phone-code'];
     this.mobile_return = false;
     this.mobile_return_keypress = false;
     if (event['phone-code'].length > 5) {
        $('.code').css({'padding-right': '6px'});
        $('.code').css({'width': 'calc(23.71159%)'});
     } else if (event['phone-code'].length > 3) {
        $('.code').css({'padding-right': '6px'});
        $('.code').css({'width': 'calc(18.71159%)'});
     } else {
        $('.code').css({'padding-right': '0'});
        $('.code').css({'width': 'calc(16.71159%)'});
     }
     if (event.code === 'IN') {
      if (this.country_code) {
       this.country_codeLength = 10;
       this.regex = /^\d{10}$/;
       } else {
        this.country_codeLength = 12;
        this.regex = /^\d{12}$/;
       }
     } else {
      if (this.country_code) {
       this.country_codeLength = 13;
       this.regex = /^\d{4,13}$/;
      } else {
        this.country_codeLength = 20;
       this.regex = /^\d{4,20}$/;
      }
     }
   }

private forgotEmail() {
   let network;
   network = this.networkService.getPopupStatus();
   if (network  === true) {
     if (this.signin_fail > 0) {
       this.qgraphevent('signin_failure', {'method': 'email', 'forgotpassword': 'yes', 'country' : this.countrycode, 'state': this.localstorage.getItem('state_code')});
    }
    if (this.queryparams && this.queryparams.length > 0) {
        this.to.replaceState('forgotpassword/email?' + this.queryparams);
      } else {
        this.to.replaceState('forgotpassword/email');
      }
  // send forget password event to GA
  this.tokenValue = this.gtm.fetchToken();
  this.timestampTime = this.gtm.fetchCurrentTime();
  this.timestampDateTime = this.gtm.fetchCurrentDate();
  this.clientID = this.gtm.fetchClientId();
  this.marketingValue = this.gtm.fetchMarketing();
  this.sendForgotPwd = {
      'event': 'ForgetPassword',
      'G_ID': this.tokenValue,
      'Client_ID': this.clientID,
      'retargeting_remarketing' : this.marketingValue,
      'TimeHHMMSS': this.timestampTime,
      'DateTimeStamp': this.timestampDateTime
    };
  this.gtm.logEvent(this.sendForgotPwd);
  this.routeservice.forgotSignal(null);
  this.emailCheck = false;
  this.emailplace = false;
  this.loginEmail = false;
  this.otherContainerFlag = false;
  this.headerservicesService.OtherContanierFlagChange(false);
  this.loginPageFlag = false;
  this.headerservicesService.LoginPageChange(false);
  this.forgotPasswordEmail = true;
  this.headerservicesService.forgotEmailValueChange(true);
  this.headerservicesService.loginEmailChange(false);
  this.email_return = false;
  this.email_return_keypress = false;
  this.place = false;
  this.passwordCheck1 = false;
  this.password_email_return = false;
  this.password_email_return_keypress = false;
  this.type = false;
  $('#body').addClass('scrolldisbale');
  this.pageName = 'forgot password/email';
  this.gtm.sendPageName(this.pageName);
  this.gtm.sendEvent();
}
}

private step2ForgotPasswordEmail() {
   let network;
   network = this.networkService.getPopupStatus();
   if (network === true) {
    this.forgotpassword_email = $('.InputregisteredEmail').val();
   this.forgot_email_return_keypress = false;
   this.forgot_email_return = false;
  this.userapi.v1UserPasswordforgottenemailPost(this.forgotpassword_email).timeout(environment.timeOut).subscribe(response => {
    this.loginEmail = false;
    this.forgotPasswordEmail = false;
    this.forgotPasswordEmailStep2 = true;
    this.forgot_email_return_keypress = false;
    this.forgot_email_return = false;
    this.expiredEmail = false;
    $('#body').addClass('scrolldisbale');
    this.gtm.sendResendLinkData(); // send resend GA data
     },
     err => {
      this.forgot_email_return_keypress = true;
      this.forgot_email_return = true;
      this.count1 = 0;
      if (err.name === 'TimeoutError') {
        this.error_message_Login = this.try_later;
        this.callToast();
      } else {
        this.errors = err.json();
        if (err.status === 404) {
            this.error_message_Login = this.errors.message;
            this.callToast();
        } else {
          this.error_message_Login = this.errors.message;
          this.callToast();
        }
      }
      this.gtm.sendErrorEvent('api', err);
    });
  }
}
private forgotMobile() {
   let network;
   network = this.networkService.getPopupStatus();
   if (this.signin_fail > 0) {
    this.qgraphevent('signin_failure', {'method': 'phone', 'forgotpassword': 'yes', 'country' : this.countrycode, 'state': this.localstorage.getItem('state_code')});
 }
 $('#mobileNumber').focus();
   if (network === true) {
    if (this.queryparams && this.queryparams.length > 0) {
        this.to.replaceState('forgotpassword/mobile?' + this.queryparams);
      } else {
        this.to.replaceState('forgotpassword/mobile');
      }
 // send forget password event to GA
 this.tokenValue = this.gtm.fetchToken();
 this.timestampTime = this.gtm.fetchCurrentTime();
 this.timestampDateTime = this.gtm.fetchCurrentDate();
 this.clientID = this.gtm.fetchClientId();
this.marketingValue = this.gtm.fetchMarketing();
  this.sendForgotPwd = {
      'event': 'ForgetPassword',
      'G_ID': this.tokenValue,
      'Client_ID': this.clientID,
      'retargeting_remarketing' : this.marketingValue,
      'TimeHHMMSS': this.timestampTime,
      'DateTimeStamp': this.timestampDateTime
    };
  this.gtm.logEvent(this.sendForgotPwd);
 this.routeservice.forgotSignal(null);
 this.loginMobile = false;
 this.loginPageFlag = false;
 this.headerservicesService.LoginPageChange(false);
 this.otherContainerFlag = false;
 this.headerservicesService.OtherContanierFlagChange(false);
 this.forgotPasswordMobile = true;
 this.headerservicesService.forgotMobileValueChange(true);
 this.headerservicesService.loginMobileChange(false);
 this.passwordCheck = false;
 this.place = false;
 this.password_return = false;
 this.password_return_keypress = false;
 this.mobile_return_keypress = false;
 this.mobile_return = false;
 $('#body').addClass('scrolldisbale');
 this.type = false;
 this.pageName = 'forgot password/mobile';
 this.gtm.sendPageName(this.pageName);
 this.gtm.sendEvent();
}
}
private step2ForgotPasswordMobile() {
   let network;
   network = this.networkService.getPopupStatus();
   if (network === true) {
     this.phone_code = this.phone_code.replace(/-/g, '');
     this.forgotpassword_mobile = this.country_code ?  this.phone_code + $('.ForgotTelNumber').val() : $('.ForgotTelNumber').val();
     this.mobile_return = false;
     this.mobile_return_keypress = false;
     this.userapi.v2UserPasswordforgottenmobilePost(this.forgotpassword_mobile).timeout(environment.timeOut).subscribe(response => {
      this.otpCheck = false;
      this.otpPlace = false;
      this.otp_return = false;
      this.otp_return_keypress = false;
      this.step3check = true;

       this.loginMobile = false;
       this.forgotPasswordMobile = false;
       this.forgotPasswordMobileStep2 = true;
       this.mobile_return = false;
       this.mobile_return_keypress = false;
       $('#body').addClass('scrolldisbale');
       this.setTimer();
       this.SecondTimer();
       }, err => {
       this.mobile_return = true;
       this.mobile_return_keypress = true;
       this.count = 0;
       if (err.name === 'TimeoutError') {
            this.error_message_Login = this.try_later;
            this.callToast();
        } else {
          this.errors = err.json();
          this.error_message_Login = this.errors.message;
          this.callToast();
          if (err.status === 404) {
              this.error_message_Login = this.errors.message;
              this.callToast();
          }
        }
          this.gtm.sendErrorEvent('api', err);
        });
    }
}
 private setTimer() {
  let that;
  that = this;
  $('.countdown').html('20:00');
  that.timer2 = '20:00';
  that.interval = setInterval(function() {
  that.countdown_time = '';
  let timer , seconds, minutes;
  timer = that.timer2.split(':');
  // by parsing integer, I avoid all extra string processing
  minutes = parseInt(timer[0], 10);
  seconds = parseInt(timer[1], 10);
  --seconds;
  minutes = (seconds < 0) ? --minutes : minutes;

  if (minutes < 0) {
    minutes  = 0;
    seconds = 0;
    clearInterval(that.interval);
  }
  seconds = (seconds < 0) ? 59 : seconds;
  seconds = (seconds < 10) ?  '0' + seconds : seconds;
  minutes = (minutes < 10) ?  '0' + minutes : minutes;
  $('.countdown').text(minutes + ':' + seconds);
  that.timer2 = minutes + ':' + seconds;
}, 1000);
}
private resendOtpcheck() {
 if (this.timer_return === false) {
      this.resendOtp();
      this.timer_return = true;
  }
}
private resendOtp() {
  $('.resendOtpText').css({'color': '#703055', 'cursor': 'not-allowed'});
  let network;
  network = this.networkService.getPopupStatus();
  if (network === true) {
    this.userapi.v2UserPasswordforgottenmobilePost(this.forgotpassword_mobile).timeout(environment.timeOut).subscribe(response => {
      this.error_message_Login = response.message;
      this.callToast();
      clearInterval(this.second_interval);
      clearInterval(this.interval);
      this.setTimer();
      this.SecondTimer();
      this.otpCheck = false;
      this.otpPlace = false;
      $('.otpInput').val('');
      this.otp_return = false;
      this.otp_return_keypress = false;
      this.timer_return = true;
      this.timer_return_keypress = true;
      $('.Invalidotp').css({'display': 'none'});
      $('.otpContainer').css({'border-color': '#6e6e6e'});
    }, err => {
          if (err.name === 'TimeoutError') {
            this.error_message_Login = this.try_later;
            this.callToast();
          } else {
            this.errors = err.json();
            this.error_message_Login = this.errors.message;
            this.callToast();
            if (err.status === 404) {
              this.error_message_Login = this.errors.message;
              this.callToast();
            }
        }
        this.gtm.sendErrorEvent('api', err);
      });
  }
}
private SecondTimer() {
  let that;
  that = this;
  $('.countdown_second').html('00:30');
  that.timer_second = '00:30';
  that.second_interval = setInterval(function() {
  that.countdown_time2 = '';
  let timer , seconds, minutes;
  timer = that.timer_second.split(':');
  // by parsing integer, I avoid all extra string processing
  minutes = parseInt(timer[0], 10);
  seconds = parseInt(timer[1], 10);
  --seconds;
  minutes = (seconds < 0) ? --minutes : minutes;
  if (minutes < 0) {
    minutes  = 0;
    seconds = 0;
    that.timer_return = false;
    that.timer_return_keypress = false;
    clearInterval(that.second_interval);
     $('.resendOtpText').css({'color': '#bf006b', 'cursor': 'pointer'});
  }
  seconds = (seconds < 0) ? 59 : seconds;
  seconds = (seconds < 10) ?  '0' + seconds : seconds;
  minutes = (minutes < 10) ?  '0' + minutes : minutes;
  $('.countdown_second').text(minutes + ':' + seconds);
  that.timer_second = minutes + ':' + seconds;
  }, 1000);
}
private resendLink() {
  let network;
  network = this.networkService.getPopupStatus();
  if (network === true) {
    this.userapi.v1UserPasswordforgottenemailPost(this.forgotpassword_email).timeout(environment.timeOut).subscribe(response => {
      this.error_message_Login = response.message;
      this.callToast();
    }, err => {
        if (err.name === 'TimeoutError') {
          this.error_message_Login = this.try_later;
          this.callToast();
        } else {
          this.errors = err.json();
          if (err.status === 404) {
              this.error_message_Login = this.errors.message;
              this.callToast();
          } else {
             this.error_message_Login = this.errors.message;
             this.callToast();
          }
        }
        this.gtm.sendErrorEvent('api', err);
      });
  }
}
private showOtp() {
if (this.navigator.userAgent.match(/SM-T531/) && (this.window.orientation === 0 || this.window.orientation === 180)) {
   $('.forgotPasswordMobileStep2').css({'top': '-120px'});
}
  $('.Invalidotp').css({'display': 'none'});
  $('.otpContainer').css({'border-color': '#6e6e6e'});
  this.otpCheck = true;
  this.otpPlace = true;
}
private removeOtp() {
if (this.navigator.userAgent.match(/SM-T531/) && (this.window.orientation === 0 || this.window.orientation === 180)) {
  $('.forgotPasswordMobileStep2').css({'top': 'auto'});
}
  let count1;
  count1 = $('#otpInput').val().length;
  if ( count1 < 1 ) {
    this.otpCheck = false;
  }
  this.otpPlace = false;
}
private otpValidation() {
   let count1;
   count1 = $('#otpInput').val().length;
    if (count1 >= 0) {
      let scope;
      scope = this;
      $(this.document).ready(function() {
        let pw_text;
        pw_text = $('#otpInput').val();
           if (pw_text.length === 0 ) {
                $('#ForgotOtpEnterMsg').css({'display': 'block'});
                $('#ForgotOtpErrorMsg').css({'display': 'none'});
             } else {
                $('#ForgotOtpEnterMsg').css({'display': 'none'});
                $('#ForgotOtpErrorMsg').css({'display': 'block'});
             }
         if (pw_text.length < 4) {
             $('.otpContainer').css({'border-color': 'red'});

           scope.otp_return = false;
         } else {
            scope.otp_return = true;
             $('#ForgotOtpErrorMsg').css({'display': 'none'});
          }
          return scope.otp_return;
      });
    }
}
private otpValidationkeypress() {
  let count1;
  count1 = $('#otpInput').val().length;
  if (count1 >= 0 ) {
      let scope;
      scope = this;
      $(this.document).ready(function() {
        let pw_text;
        pw_text = $('#otpInput').val();
         if (pw_text && pw_text.length >= 4) {  // changes done because of for length 0 not disabled
           scope.otp_return_keypress = true;
         } else {
            scope.otp_return_keypress = false;
          }
          return scope.otp_return_keypress;
      });
    }
}
// otpEnable() {
//     if ((this.otp_return ) === false) {
//         $('.continueButton').css({'background-color': '#50012f', 'color': '#703055'});
//         return true;
//       } else {
//          $('.continueButton').css({'background-color': '#bf006b', 'color': '#eeeeee'});
//         return false;
//     }
// }
// otpEnableKeypress() {
//   if ((this.otp_return_keypress ) === false) {
//         $('.continueButton').css({'background-color': '#50012f', 'color': '#703055'});
//         return true;
//       } else {
//          $('.continueButton').css({'background-color': '#bf006b', 'color': '#eeeeee'});
//         return false;
//     }
// }
private otpRestrict(e) {
        // Allow: backspace, delete, tab, escape, enter.
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
             // Allow: Ctrl+A, Command+A
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
            // Allow: Ctrl+V, Command+V
            (e.keyCode === 86 && (e.ctrlKey === true || e.metaKey === true)) ||
             // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
}
private mobileRestrict(e) {
        // Allow: backspace, delete, tab, escape, enter.
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
             // Allow: Ctrl+A, Command+A
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
            // Allow: Ctrl+V, Command+V
            (e.keyCode === 86 && (e.ctrlKey === true || e.metaKey === true)) ||
             // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
            // e.stopPropagation();
        }
        $('#mobileNumber').on('paste', function ( event ) {
        setTimeout(function () {
              $('#mobileNumber').val($('#mobileNumber').val().replace(/[^0-9]/g, ''));
          }, 0);
      });
}
private getEnable() {
    if (this.mobile_return === false) {
        $('.getOtp').css({'background-color': '#50012f', 'color': '#703055'});
        return true;
      } else {
         $('.getOtp').css({'background-color': '#bf006b', 'color': '#eeeeee'});
        return false;
    }
}
private getEnableKeypress() {
  if (this.mobile_return_keypress === false) {
        $('.getOtp').css({'background-color': '#50012f', 'color': '#703055'});
        return true;
      } else {
         $('.getOtp').css({'background-color': '#bf006b', 'color': '#eeeeee'});
        return false;
    }
}
// step3ForgotPasswordMobile() {
//   let network
//   network = this.networkService.getPopupStatus()
//     if (network === true) {
//     this.forgotcode_mobile = $('.otpInput').val();
//     this.loginMobile = false;
//     this.forgotPasswordMobile = false;
//     this.forgotPasswordMobileStep2 = false;
//     this.forgotPasswordMobileStep3 = true;
//     this.otpCheck = false;
//     this.otpPlace = false;
//     clearInterval(this.interval);
//     clearInterval(this.second_interval)
//     this.countdown_time2 = '00:30';
//     this.countdown_time = '20:00';
//     this.otp_return = false;
//     this.otp_return_keypress = false;
//     this.step3check = true;
//     this.timer_return = true;
//     this.timer_return_keypress = true;
//     $('#body').addClass('scrolldisbale');
//   }
// }
private FinalForgotPasswordMobile() {
  this.forgotcode_mobile = $('.otpInput').val();
let network, newpassword_data;
network = this.networkService.getPopupStatus();
      if (network === true) {
  if ((this.step3check === true) && (this.new_password_return === true || this.new_password_return_Keypress === true) && (this.forgotcode_mobile)) {
      newpassword_data = {
         'code': this.forgotcode_mobile,
         'new_password': $('.passwordInput').val()
      };
    this.userapi.v1UserRecreatepasswordmobilePost(newpassword_data).timeout(environment.timeOut).subscribe(response => {
      this.window.scrollTo(0, 0);
      this.loginMobile = false;
      this.forgotPasswordMobile = false;
      this.forgotPasswordMobileStep2 = false;
      this.forgotPasswordMobileStep3 = false;
      this.forgotPasswordFinalStep = true;
      this.confirmPlace = false;
      this.confirm_password_Check = false;
      this.place = false;
      this.passwordCheck = false;
      this.type_confirm = false;
      this.type = false;
      this.password_return = false;
      this.password_return_keypress = false;
      this.confirm_return = false;
      this.confirm_return_keypress = false;
      this.new_password_return = false;
      this.new_password_return_Keypress = false;
      this.otp_return = false;
      this.otp_return_keypress = false;
      $('#body').addClass('scrolldisbale');
    }, err => {
        if (err.name === 'TimeoutError') {
          this.error_message_Login = this.try_later;
          this.callToast();
        } else {
        this.errors = err.json();
        this.error_message_Login = this.errors.message;
        this.callToast();
      if (err.status === 404) {
          this.error_message_Login = this.errors.message;
          this.callToast();
          // this.forgotPasswordMobileStep3 = false;
          this.loginMobile = false;
          this.forgotPasswordMobile = false;
          this.forgotPasswordMobileStep2 = true;
          this.mobile_return = false;
          this.mobile_return_keypress = false;
          this.confirmPlace = false;
          this.confirm_password_Check = false;
          this.place = false;
          this.passwordCheck = false;
          this.type_confirm = false;
          this.type = false;
          this.password_return = false;
          this.password_return_keypress = false;
          this.confirm_return = false;
          this.confirm_return_keypress = false;
          // this.new_password_return = false;
          // this.new_password_return_Keypress = false;
          $('#body').addClass('scrolldisbale');
          // this.setTimer();
          // this.SecondTimer();
      }
    }
      this.gtm.sendErrorEvent('api', err);
      });
  } else if (this.step3check === false) {
      let newpassword_dataEmail;
      newpassword_dataEmail = {
         'code': this.forgotcode,
         'new_password': $('.passwordInput').val()
      };
      this.userapi.v1UserRecreatepasswordemailPost(newpassword_dataEmail).timeout(environment.timeOut).subscribe(response => {
        this.window.scrollTo(0, 0);
        this.loginMobile = false;
        this.forgotPasswordMobile = false;
        this.forgotPasswordMobileStep2 = false;
        this.forgotPasswordMobileStep3 = false;
        this.forgotPasswordFinalStep = true;
        this.confirmPlace = false;
        this.confirm_password_Check = false;
        this.place = false;
        this.passwordCheck = false;
        this.type_confirm = false;
        this.type = false;
        this.password_return = false;
        this.password_return_keypress = false;
        this.confirm_return = false;
        this.confirm_return_keypress = false;
        this.new_password_return = false;
        this.new_password_return_Keypress = false;
        $('#body').addClass('scrolldisbale');
      }, err => {
        if (err.name === 'TimeoutError') {
          this.error_message_Login = this.try_later;
          this.callToast();
        } else {
            this.errors = err.json();
            if (err.status === 404) {
              this.loginEmail = false;
              this.forgotPasswordEmail = false;
              this.forgotPasswordMobileStep3 = false;
              this.forgot_email_return_keypress = false;
              this.forgot_email_return = false;
              this.expiredEmail = true;
              // this.error_message_Login = this.errors.message;
              // this.callToast();
            } else {
            this.error_message_Login = this.errors.message;
            this.callToast();
            }
        }
        this.gtm.sendErrorEvent('api', err);
      });
    }
  }
}
private LoginPage() {
  this.router.navigate(['/signin']);
  // window.location.reload();
  setTimeout(() => {
   this.window.location.reload();
 }, 100);
}
private NewPasswordError(): any {
     let count1, count2, pw_text;
     count1 = $('#newpassword').val().length;
     count2 = $('#confirmMyPassword').val().length;
     if (count1 >= 0) {
       pw_text = $('#newpassword').val();
       if (pw_text.length < 6) {
           $('.passwordForm').css({'border-color': 'red'});
           $('.ForgotminiCharcter').css({'color': 'red'});
           $('.ForgotminiCharcter').css({'display': 'block'});
        } else {
          $('.passwordForm').css({'border-color': '#6e6e6e'});
           $('.ForgotminiCharcter').css({'color': 'red'});
           $('.ForgotminiCharcter').css({'display': 'none'});
      }
     }
}
private ConfirmPasswordError() {
      let count2, pw_text2;
      count2 = $('#confirmMyPassword').val().length;
     if (count2 >= 0) {
      pw_text2 = $('#confirmMyPassword').val();
        if (pw_text2.length < 6) {
           $('.confirmpasswordForm').css({'border-color': 'red'});
           $('.confirmMiniCharcter').css({'color': 'red'});
           $('.confirmMiniCharcter').css({'display': 'block'});

        } else {
          $('.confirmpasswordForm').css({'border-color': '#6e6e6e'});
          $('.confirmMiniCharcter').css({'color': 'red'});
          $('.confirmMiniCharcter').css({'display': 'none'});
      }
    }
  }
private NewpwdValidationMobile(): any {
     let count1;
     count1 = $('#newpassword').val().length;
     let count2;
     count2 = $('#confirmMyPassword').val().length;
    if ((count1 >= 6) && (count2 >= 6)) {
      let scope;
      scope = this;
      $(this.document).ready(function() {
        let pw_text;
        pw_text = $('#newpassword').val();
        let pw_text2;
        pw_text2 = $('#confirmMyPassword').val();

        if ((pw_text !== pw_text2)) {
          $('.mismatchPassword').css({'display': 'block'});

            scope.new_password_return = false;
         } else {
             $('.mismatchPassword').css({'display': 'none'});
             scope.new_password_return = true;
          }
          return scope.new_password_return;
      });
    }
  }
private NewpwdValidationMobileKeypress() {
    let count1;
    count1 = $('#newpassword').val().length;
    let count2;
    count2 = $('#confirmMyPassword').val().length;
    let scope;
    scope = this;
    if ((count1 >= 6) && (count2 >= 6)) {
      $(this.document).ready(function() {
        let pw_text;
        pw_text = $('#newpassword').val();
        let pw_text2;
        pw_text2 = $('#confirmMyPassword').val();
         if ((pw_text !== pw_text2)) {
           $('.mismatchPassword').css({'display': 'display'});
           scope.new_password_return_Keypress = false;
         } else {
            $('.mismatchPassword').css({'display': 'none'});
            scope.new_password_return_Keypress = true;
          }
          return scope.new_password_return_Keypress;
      });
    } else {
         return scope.new_password_return_Keypress = false;
    }
  }
private newPasswordfocusout() {
  $('#body').addClass('scrolldisbale');
  $('.mismatchPassword').css({'display': 'none'});
  let count;
  count = $('#newpassword').val().length;
  if ( count < 1 ) {
    this.passwordCheck = false;
  }
  this.place = false;
}
private resetEnable() {
    if ( this.new_password_return === false && this.otp_return === false ) {
        $('.continueButton').css({'background-color': '#50012f', 'color': '#703055'});
        return true;
      } else if ( this.new_password_return === true && this.otp_return === true ) {
         $('.continueButton').css({'background-color': '#bf006b', 'color': '#eeeeee'});
        return false;
    }
}
private resetEnableKeypress() {
  if ( this.new_password_return_Keypress === false || this.otp_return_keypress === false) {
        $('.continueButton').css({'background-color': '#50012f', 'color': '#703055'});
        return true;
      } else if ( this.new_password_return_Keypress === true && this.otp_return_keypress === true) {
         $('.continueButton').css({'background-color': '#bf006b', 'color': '#eeeeee'});
        return false;
    }
}


private resetemailKeypress() {
  if ( this.new_password_return_Keypress === false && this.otp_return_keypress === false) {
        $('.continueButton').css({'background-color': '#50012f', 'color': '#703055'});
        return true;
      } else if ( this.new_password_return_Keypress === true && this.otp_return_keypress === true) {
         $('.continueButton').css({'background-color': '#bf006b', 'color': '#eeeeee'});
        return false;
    }
}


private resetEnable1() {
    if ( this.new_password_return === false ) {
        $('.reset').css({'background-color': '#50012f', 'color': '#703055'});
        return true;
      } else {
         $('.reset').css({'background-color': '#bf006b', 'color': '#eeeeee'});
        return false;
    }
}
private resetEnableKeypress1() {
  if ( this.new_password_return_Keypress === false ) {
        $('.reset').css({'background-color': '#50012f', 'color': '#703055'});
        return true;
      } else  {
         $('.reset').css({'background-color': '#bf006b', 'color': '#eeeeee'});
        return false;
    }
}

private ForgotPasswordEmailValidation(): void {
     let count1;
     count1 = $('#forgotemail').val().length;
    if (count1 >= 0) {
      let scope;
      scope = this;
    $(this.document).ready(function() {
        let email_text, re, emailTest;
        email_text = $('#forgotemail').val().trim();
        // re = /^([a-zA-Z0-9]+)(([^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;         /* let re = /^([a-zA-Z0-9._+-]+)(@[a-zA-Z0-9-.]+)(.[a-zA-Z]{2,4}){2,}$/;*/
        // re = /^([a-zA-Z0-9._]+)(@(?=.{1,}.[^.]*$)+)([A-Za-z0-9-]+)(.[A-Za-z0-9]+)*(.[A-Za-z]{1,})$/;
        // re = /^([a-zA-Z0-9]+)(([^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
          // re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/; // to validate c.abcd@gags.co
          re = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?/; // to validate c.@asd.adf and caps 
         emailTest = re.test(email_text);
          if (email_text.length === 0 ) {
              $('#ForgotEmailEnterMsg').css({'display': 'block'});
              $('#ForgotEmailErrorMsg').css({'display': 'none'});
            } else {
              $('#ForgotEmailEnterMsg').css({'display': 'none'});
              $('#ForgotEmailErrorMsg').css({'display': 'block'});
            }
          if (emailTest === false) {
               $('.InputEmail').css({'border-color': 'red'});
              scope.forgot_email_return = false;
          } else {
            scope.forgot_email_return = true;
            $('#ForgotEmailErrorMsg').css({'display': 'none'});
          }
          return scope.forgot_email_return;
      });
    }
}
private ForgotPasswordEmailValidationkeypress() {
  let count1;
  count1 = $('#forgotemail').val().length;
    if (count1 >= 0) {
      let scope;
      scope = this;
    $(this.document).ready(function() {
        let email_text, re , emailTest;
        email_text = $('#forgotemail').val().trim();
        // re = /^([a-zA-Z0-9]+)(([^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;         /* let re = /^([a-zA-Z0-9._+-]+)(@[a-zA-Z0-9-.]+)(.[a-zA-Z]{2,4}){2,}$/;*/
           // re = /^([a-zA-Z0-9._]+)(@(?=.{1,}.[^.]*$)+)([A-Za-z0-9-]+)(.[A-Za-z0-9]+)*(.[A-Za-z]{1,})$/;
            // re = /^([a-zA-Z0-9]+)(([^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
          // re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/; // to validate c.abcd@gags.co  
          re = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?/; // to validate c.@asd.adf and caps 
         emailTest = re.test(email_text);
          if (emailTest === false) {
              scope.forgot_email_return_keypress = false;
          } else {
            scope.forgot_email_return_keypress = true;
          }
          return scope.forgot_email_return_keypress;
      });
    }
}
private SendlinkEnable() {
    if ((this.forgot_email_return) === false) {
        $('.sendLink').css({'background-color': '#50012f', 'color': '#703055'});
        return true;
      } else {
         $('.sendLink').css({'background-color': '#bf006b', 'color': '#eeeeee'});
        return false;
    }
  }
private SendlinkEnablekeypress() {
      if ((this.forgot_email_return_keypress) === false) {
          $('.sendLink').css({'background-color': '#50012f', 'color': '#703055'});
          return true;
        } else {
           $('.sendLink').css({'background-color': '#bf006b', 'color': '#eeeeee'});
          return false;
      }
  }
private resetPasswordEmail() {   //  confirm passward screen step3
  this.loginPageFlag = false;
  this.headerservicesService.LoginPageChange(false);
  this.forgotPasswordEmailStep2 = false;
  this.forgotPasswordMobileStep3 = true;
  this.step3check = false;
  this.emailplace = false;
  this.emailCheck = false;
  this.email_return = false;
  this.email_return_keypress = false;
  $('#body').addClass('scrolldisbale');
  this.window.scrollTo(0, 0);
}
private logoutPage() {          // logout screen profile
      this.loginPageFlag = false;
      this.headerservicesService.LoginPageChange(false);
      this.headerservicesService.ButtonChange(undefined);
      this.buttonChange = undefined;
      this.setDisplay(this.token);
      this.profileActivationFlag = true;
      this.verification_email = false;
      this.registerMobile = false;
      this.registerEmail = false;
      $('#body').addClass('scrolldisbale');
      this.signinRightTop = false;
      this.bg_imageFlag = false;
      this.loginMobile = false;
      this.loginEmail = false;
      this.pass();
}
private pass(): any {
  this.profileShow = {profile: this.profileActivationFlag};
  this.update.emit(this.profileShow);
  this.headerservicesService.signinLeftChange(false);
  this.headerservicesService.ProfileActivationChange(true);
}
private bridgeEnter(event) {
  if (event.keyCode === 13) {

       $('.registerSubmit_highlighted').click();
       $('.loginbtn_block_highlighted').click();
        setTimeout(() => {
           if (this.count1 < 1) {
        $('.sendLink').click();
        this.count1++;
       } }, 0);

       setTimeout(() => {
         if (this.count < 1) {
        $('.getOtp').click();
        this.count++;
       } }, 0);
       $('.continueButton').click();
       // $('.reset').click();
    }
}
 private sendData(value) {
   this.receivedValue = value ;
  }
private AcceptEnable() {
  if (!(this.receivedValue.sendFlag)) {
        $('.AcceptLogin').css({'background-color': '#50012f', 'color': '#703055'});
        return true;
      } else {
         $('.AcceptLogin').css({'background-color': '#bf006b', 'color': '#eeeeee'});
        return false;
    }
}
private GdprUpdate() {
  if (this.socialFlag === true) {
    $('#loaderPage').css('display', 'block');
     if (this.loginFrom === 'register') {
        if (this.socialType === 'google') {
          this.googleRegister();
        } else {
          this.facebookRegister();
        }
      } else if (this.loginFrom === 'login') {
          this.updateSettingApi(this.sendToken, this.socialType, this.loginFrom);
      }
  } else {
    let policyValues;
    policyValues = [];
  for (let i = 0; i < 4; i++) {
    if (!(this.receivedValue.sendValues[i].status) || this.receivedValue.sendValues[i].status === undefined) {
       policyValues[i] = 'na';
    } else if (!(this.receivedValue.sendValues[i].userValue)) {
       policyValues[i] = 'no';
    } else if (this.receivedValue.sendValues[i].userValue === true) {
       policyValues[i] = 'yes';
    }
  }
   if (this.token) {
      this.CommonConfigCall(this.token);
      if (!this.gdprCountryChange) {
        let gdprValue, gdprsettings;
        gdprValue = [{
                'country_code': this.countrycode,
                'gdpr_fields': {
                'policy': policyValues[0],
                'profiling': policyValues[1],
                'age': policyValues[2],
                'subscription': policyValues[3]
                 }}];
         gdprsettings = {
            'key': 'gdpr_policy',
            'value': JSON.stringify(gdprValue)
         };
        this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
        this.userSettings.v1SettingsPost(gdprsettings).subscribe(responsePost => {
          this.GAUpdateCommon('LoginSuccess', this.login_type);
          this.updatePromotion(this.userData);
        }, err => {
          // todo
        });
      } else {
       let gdprValue1, gdprsettings;
        gdprValue1 = {
                'country_code': this.countrycode,
                'gdpr_fields': {
                  'policy': policyValues[0],
                  'profiling': policyValues[1],
                  'age': policyValues[2],
                  'subscription': policyValues[3]
                 }
              };
         this.gdprValue.push(gdprValue1);
         gdprsettings = {
            'key': 'gdpr_policy',
            'value': JSON.stringify(this.gdprValue)
         };
        this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
        this.userSettings.v1SettingsPut(gdprsettings).subscribe(responsePost => {
          this.GAUpdateCommon('LoginSuccess', this.login_type);
          this.updatePromotion(this.userData);
        }, err => {
          // todo
        });
      }
    }
  }
}
private CommonConfigCall(token) {
   let params;
        params = 'bearer ' + token ;
       this.config = {
          apiKey: params,
          username: '',
          password: '',
          accessToken: '',
          withCredentials: false
        };
}
private GAUpdateCommon(gAEvent, loginMethod) {    ///  GA event = LoginSuccess/registerFailure  /// loginMethod = fb,g+,tw,mob,em
  this.tokenValue = this.gtm.fetchToken();
  this.timestampTime = this.gtm.fetchCurrentTime();
  this.timestampDateTime = this.gtm.fetchCurrentDate();
  this.clientID = this.gtm.fetchClientId();
  this.marketingValue = this.gtm.fetchMarketing();
  let sendData;
  sendData = {
    'event' : gAEvent,
    'G_ID' : this.tokenValue,
    'Client_ID': this.clientID,
    'retargeting_remarketing' : this.marketingValue,
    'LoginMethod' : loginMethod,
    'operator': 'NA',
    'TimeHHMMSS': this.timestampTime,
    'DateTimeStamp': this.timestampDateTime
  };
  this.gtm.appendPara(gAEvent, sendData);
}
public ngOnDestroy() {
   clearInterval(this.interval);
   clearInterval(this.second_interval);
   this.signin_fail = 0;
   this.headerservicesService.storeNavigateLoginSub(false);
   this.document.getElementById('body').classList.remove('modal-open');
}

private changeRoute(): any {
  let postRoute;
  postRoute = this.localstorage.getItem('postSubscriptionRoute');
  if (this.previousUrl !== '/myaccount/subscription' && postRoute) {
    this.localstorage.removeItem('postSubscriptionRoute');
    this.commonService.getPostSubscriptionRoute(postRoute, 'login');
  } else {
    location.href = this.window.location.origin + this.previousUrl;
  }
}

private qgraphevent(eventname, object) {
  if (this.window.qg) {
    // if (this.qgraph) {
    //   delete object.country;
    //   delete object.state;
    //   qg('event', eventname, object);
    // } else {
      qg('event', eventname, object);
    // }
  }
}

private checkSubSilentLogin(): any {
  let recVal, sendVal;
  recVal = this.localstorage.getItem('subSilentLogin');
  if (recVal) {
    sendVal = {
      'subValue' : true,
      'loginValue' : true
    };
    this.localstorage.setItem('subSilentLogin', JSON.stringify(sendVal));
  }
}
}
