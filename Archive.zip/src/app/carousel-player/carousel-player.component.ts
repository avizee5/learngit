import { Component, OnInit, Input, HostListener, OnDestroy, OnChanges, ViewChild, ElementRef, Output, EventEmitter} from '@angular/core';
declare let jwplayer: any;
import * as $ from 'jquery';
import { Subscription } from 'rxjs/Subscription';
import { Subject } from 'rxjs/Subject';
import { Http } from '@angular/http';

import { VideoAnalyticsService } from '../services/video-analytics.service';
import { VideoService } from '../services/video.service';

import { HeaderservicesService } from '../services/headerservices.service';
import { SettingsService } from '../services/settings.service';
import { NetworkService } from '../services/network.service';
import { UseractionapiService } from '../services/useractionapi.service';

import { WatchHistoryApi } from '../../data/user/api/api';
import { SubscriptionService } from '../services/subscription.service';
import {environment} from '../../environments/environment';
import 'rxjs/add/operator/timeout';
import 'rxjs/add/operator/takeUntil';

import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';

const noNetworkText = 'MESSAGES.NETWORK_ERROR'; // 'Please check your network connection and retry!'
const noUrlText = 'MESSAGES.NO_DATA'; // 'No data available'
const tryAgainMessage = 'MESSAGES.TIMEOUT_ERROR'; // 'Sorry, something went wrong, please try again.'
const fallbackBasepath = environment.aesBasePath;
const akamaiBasePath = environment.videoBasePath;

const epgAssetType = 10;
const continueWatchingTime = 60; // seconds
const closeTimeout = 3000; // ms, timeout to close the player
const retryCount = 1; // seconds

@Component({
  selector: 'app-carousel-player',
  templateUrl: './carousel-player.component.html',
  styleUrls: ['./carousel-player.component.less']
})

export class CarouselPlayerComponent implements OnInit, OnDestroy, OnChanges {

  @Input() public videoObject: any;
  @Input() public xIndex: any;
  @Input() public yIndex: any;
  @Input() public videoIsLive: any = false;
  @Input() public canShowPlayer: any = false;
  @Output() public showplayer: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() public closeplayer: EventEmitter<boolean> = new EventEmitter<boolean>();
	@ViewChild('backgroundImage') public image_container: ElementRef;

  public defaultImage = environment.assetsBasePath + 'assets/default/popular.png';
  public full_volume_icon =  environment.assetsBasePath + 'assets/player_icons/autoplay_volume.png';
  public mute_icon = environment.assetsBasePath + 'assets/player_icons/autoplay_mute_volume.png';
  public volumeIcon: any;
  public play = environment.assetsBasePath + 'assets/player_icons/player_icons.svg#play_icon-view';

	private showCredits: any = 5; // in seconds

	private contentUrl: any;
	public retryCounter: any = retryCount;
	// public currentAdId: any;
	public loader = environment.assetsBasePath + 'assets/common/loading.gif';

  public player: any;
  public resourceUrl: any;
  public resourceUrlConviva: any;
  public currentTime: any = '00:00';
  public totalTimeMS: number;
  public volume: any = false;

  public buffering: boolean;
  public drm: any;
  public drmFlag: boolean;

  // public enablePlayback: any = false;
  // public currentTimeSec: number;

  public playlist: any;
  public precisionAPI: any;
  public error: any = false;
  public customData: any;

  public watchHistoryApi: any;

  public touchScreen = false;
  public cdnData: any;
  public videoToken: any;

  public advertisement: any;
  public inHistory: any = false;
  public updatedHistoryTime: any;
  public deletedInHistory: any = false;
  public unsupported: any = false;
  public errorMsg: string;
  public streamProtocol: any;

  public mobile: any;

  public token: any;
  public params: any;
  public configUser: any;
  public drmBasePath: any;
  private ngUnsubscribe = new Subject<any>();
  public postHistoryAPI: Subscription;
  public putHistoryAPI: Subscription;
  public deleteHistory: Subscription;
  public background: any;
  public showBackgroundImage: any = true;

  public browser: any;

  public androidORiOS: any;

  public startPlayback: any = true;
  public autoStart: any = false;
  public unsupportederrorMsg: any;

  public window: any;
  public navigator: any;
  public localStorage: any;
  public document: any;

  public muteLaunch: any = false;
  public mobile_UC = false;
  public xiaomi = false;
  public browserUnSupported: any = false;

  public configData: any;
  public notAvailable: any = 'NA';
  public videoItemforGA: any;
  public gaSubCategory: any;

  public networkStatus: any;

  public playAES: any;

  public gaFirstAPIAudioLang: any;
  public audioLangsString: any; // comma seperated audio languages string
  public selectedAudioqg: any;

  public popUps: any = false;
  private videoPaused: any = false;

  public userId: any;
  public showWaterMark: any = false;
  public isLastFiveSec: any = false;

  public searchOpen: any = false;

  public languages: any;
  public errorTimeout: any;
  private showPlayer: any = false;
  private canSetupPlayer: any = false;
  private playerReady: any = false;
  public selectedBitrate: any;
  public autoplay: any;

  constructor(@Inject(PLATFORM_ID) private platformId: Object, private sub: SubscriptionService, private userapiService: UseractionapiService, private networkService: NetworkService, private settingsService: SettingsService, private headerService: HeaderservicesService, private videoAnalyticsService: VideoAnalyticsService, private videoService: VideoService, private http: Http) {
    this.headerService.subscribeReminder.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.playerStateOnPopup(value);
    });
    this.headerService.signInReminder.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.playerStateOnPopup(value);
    });
    this.headerService.contentLanguageValue.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.playerStateOnPopup( value.boolean);
    });
    this.headerService.searchValue.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.searchOpen = value;
      this.playerStateOnPopup( value.boolean);
    });
    this.headerService.profileDropValue.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.playerStateOnPopup(value);
    });
    this.headerService.moreValue.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.playerStateOnPopup(value);
    });
    this.headerService.modelValue.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.playerStateOnPopup(value);
    });
      this.headerService.parentalValue.takeUntil(this.ngUnsubscribe).subscribe(value => {
        this.playerStateOnPopup(value.flag);
    });
  }

  public playerStateOnPopup(value: any): any {
    this.popUps = this.headerService.popupsShown();
    if (!this.player || (this.player && this.player.getState() === 'idle') || this.error) {
      return;
    }
    if (!this.popUps) {
      if (this.player.getState() === 'paused' || this.player.getState() === 'buffering') {
          this.playVideo();
      }
    } else {
      if (this.player.getState() === 'playing') {
          this.pauseVideo();
      }
    }
  }

  public ngOnInit(): any {
    if (isPlatformBrowser(this.platformId)) {
      this.localStorage = localStorage;
      this.window = window;
      this.navigator = navigator;
      this.document = document;
    }
    this.popUps = this.headerService.popupsShown();

    this.networkStatus = this.navigator.onLine ? 'online' : 'offline';
    this.configData = this.settingsService.getCompleteConfig();

    this.setBackgroundImage();
    this.gaSubCategory = this.videoObject[0].carousel_name || this.notAvailable;
    this.browser = this.videoService.get_browser();
    if ((this.browser.name.match(/UCBrowser/i) || this.browser.name.match(/UBrowser/i)) && this.navigator.userAgent.match(/mobile|iPhone|iPod|iPad/i)) {
         this.mobile_UC = true;
    }
    if (this.browser.name.match(/MiuiBrowser|XiaoMi/i) && this.navigator.userAgent.match(/mobile|iPhone|iPod|iPad/i)) {
         this.xiaomi = true;
    }

    this.initializeOnVideoObjectChange();
    this.androidORiOS = this.navigator.userAgent.match(/Android|iPhone|iPad|iPod/i);
    this.checkForAES();
    this.videoService.storeWindowError();

    this.videoService.enableCastView = false;
    if (this.window.innerWidth < 481) {
      this.mobile = true;
    }
    this.touchScreen = this.navigator.userAgent.match(/mobile|Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i) ? true : false;

    if (this.unsupported) {
      return;
    }

    this.fetchConfig();
    this.videoAnalyticsService.init();
    this.autoplay = this.videoService.autoPlay;
    this.selectedBitrate = this.videoService.bitRate;
    this.token = this.localStorage.getItem('token');
    if (this.token)  {
      this.userId = this.localStorage.getItem('ID');
    }
    this.startVideo();
  }

  public startVideo(): any {
    if (this.player) {
      this.player.remove();
    }
    if (this.videoObject[0].drm && !this.playAES) {
      this.generateCustomkey();
    } else {
      this.getVideoToken(this.videoObject[0].type);
    }
  }


  public initializeOnVideoObjectChange(): any {
    this.retryCounter = retryCount;
    this.error = false;
    this.unsupported = false;
    this.showBackgroundImage = true;

    this.playAES = false;

    this.audioLangsString = '';
    this.gaFirstAPIAudioLang = '';

    this.buffering = true;
    if (this.errorTimeout) {
      clearTimeout(this.errorTimeout);
    }
    // this.videoPaused = false;
    this.showPlayer = false;
    this.canSetupPlayer = false;
    this.playerReady = false;
  }

  public checkForAES(): any {
    let businessType;
    businessType = this.videoObject[0].business_type;
    this.browserUnSupported = this.videoService.checkWindows(this.videoObject[0]);
    if (businessType !== 'premium' && businessType !== 'premium_downloadable' && this.videoObject[0].drm && this.videoObject[0].type === 'vod') {
      this.playAES = true;
    } else {
      this.unsupported = this.browserUnSupported;
      this.unsupportederrorMsg = this.videoService.errorMsg;
      if (this.unsupported) {
        this.closePlayer();
      }
    }
  }

  public getVideoToken(live): any {
    this.drm = null;
    live = this.playAES ? 'fallback' : live;
    this.videoService.getToken(live, this.videoObject[0].business_type).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
      this.videoToken = value.video_token;
      this.initializePlayer();
    },
    err => {
      if (err.name === 'TimeoutError') {
        this.showErrorState(tryAgainMessage);
      } else {
        this.videoToken = null;
        this.showErrorState(tryAgainMessage);
      }
      this.videoService.apiErrorEvent(err);
    });
  }

  public setBackgroundImage(): any {
    this.background = this.videoService.getImageUrl(this.videoObject[0], false);
    // this.background = 'https://akamaividz.zee5.com/resources/0-10-chn-033800011-20190508070000/list/1242x699/010chn03380001120190508070.jpg'
  }

  public showErrorState(message): any {
    if (message !== tryAgainMessage && message !== noNetworkText && message !== noUrlText) {
      this.errorMsg = tryAgainMessage;
    } else {
      this.errorMsg = message;
    }
    if ((this.mobile_UC || this.xiaomi) && this.player) {
      this.player.remove();
    }
    if (this.retryCounter && message !== noUrlText && message !== noNetworkText) {
      --this.retryCounter;
      this.retryClick();
    } else {
      this.buffering = false;
      this.showBackgroundImage = true;
      this.error = true;
      this.startPlayback = true; // not to show play icon in UC browser
      this.closePlayer();
    }
  }

  private closePlayer(): any {
    let timeout;
    timeout = this.showPlayer ? closeTimeout : 0;
    this.errorTimeout = setTimeout(() => this.closeplayer.emit(true), timeout);
  }

  public retryClick(): any {
    this.tryAgain();
  }

  public fetchConfig(): void {
    let value;
    value = this.configData;
    this.cdnData = value.cdn;
    this.languages = value.languages;
    if (!this.cdnData || this.cdnData.length < 1) {
      this.drmBasePath = akamaiBasePath;
    } else {
      this.drmBasePath = this.cdnData[0].url_in;
    }
  }

  @HostListener('window:resize', ['$event'])
  public fontReScale(event) {
    if (this.window.innerWidth < 481) {
      this.mobile = true;
    } else {
      this.mobile = false;
    }
  }

  @HostListener('window:online', ['$event'])
  @HostListener('window:offline', ['$event'])
  public networkChange(event) {
    this.networkStatus = event.type;
    let network;
    network = this.networkStatus === 'offline' ? false : true;
    if (!network) {
      this.showErrorState(noNetworkText);
    }
  }

  /*
    Code to Setup Player and Play Video based on selection.
  */
  public initializePlayer(): any {
    this.player = jwplayer('playerDiv');
    this.fetchUrl(this.videoObject[0]);
  }

  public fetchUrl(videoObject): any {
    this.drmFlag = videoObject.drm && !this.playAES;
    if (videoObject) {
      if (videoObject.stream_url_dash && videoObject.stream_url_hls && this.drmFlag) {
        this.resourceUrl = videoObject.stream_url_dash;
        if (this.navigator.platform.match(/Mac/i) && this.browser.name === 'Safari') {
          if (videoObject.type === 'live') {
            this.resourceUrl = this.resourceUrl.replace('.mpd', '.m3u8');
          } else if (videoObject.type === 'vod') {
            this.resourceUrl = videoObject.stream_url_hls;
          }
        } else if (videoObject.type === 'live') {
        // } else if ((this.androidORiOS || this.browser.name.match(/firefox/i)) && videoObject.type === 'live') {
          this.resourceUrl = videoObject.stream_url_hls;
          this.drm = null;
          this.drmFlag = false;
        }
        this.generateUrl(true);
      } else if (videoObject.stream_url_hls) {
        this.resourceUrl = videoObject.stream_url_hls; // default stream_url/url
        this.generateUrl(true);
      } else if (videoObject.stream_url_dash) {
        this.resourceUrl = videoObject.stream_url_dash; // hls if present i.e stream_urlHls
        this.generateUrl(true);
      } else {
        this.errorUrl();
      }
    }
  }

  public errorUrl(): any {
    this.resourceUrl = '';
    this.showErrorState(noUrlText);
  }

  /*
    video URL formation
  */
  public generateUrl(checkSubtitle): any {
    if (checkSubtitle) {
      let subtitleUrl;
      if (this.resourceUrl.indexOf('/') === 0) {
        subtitleUrl = akamaiBasePath + this.resourceUrl;
        if (this.playAES || (this.navigator.platform.match(/Mac/i) && this.browser.name === 'Safari' && this.videoObject[0].type === 'vod' && this.drmFlag)) {
          subtitleUrl = subtitleUrl.replace('index.m3u8', 'manifest.mpd');
        }
      } else {
        subtitleUrl = this.resourceUrl;
      }
      if (subtitleUrl && subtitleUrl[4] !== 's') {
        subtitleUrl = subtitleUrl.replace('http', 'https');
      }
    }

    if (this.resourceUrl.indexOf('/') === 0) {
      if (this.playAES) {
        this.resourceUrl = this.resourceUrl.replace('/drm', '/hls');
        this.resourceUrl = fallbackBasepath + this.resourceUrl;
        this.contentUrl = this.resourceUrl;
      } else {
        let callPrecision;
        callPrecision = (this.configData.default_values && this.configData.default_values.precision_enabled && this.configData.default_values.precision_enabled.web !== undefined) ? this.configData.default_values.precision_enabled.web : true;
        if (this.cdnData && this.cdnData.length > 1 && this.configData.default_values.precision_enabled.web) {
          this.getPrecision();
          return;
        } else {
          this.precisionAPI = null;
          this.resourceUrl = this.drmBasePath + this.resourceUrl;
          this.contentUrl = this.resourceUrl;
        }
      }
    }
    if (this.resourceUrl && this.resourceUrl[4] !== 's') {
      this.resourceUrl = this.resourceUrl.replace('http', 'https');
    }
    if (!this.drmFlag) {
    // } else {
      this.contentUrl = this.resourceUrl;
      this.resourceUrl = this.resourceUrl + this.videoToken;
      this.resourceUrlConviva = this.resourceUrl;
    }
    this.createPlaylist();
  }


  public getPrecision(): any {
    let index;
    if (this.videoObject[0]) {
      let id;
      id = this.videoObject[0].id || '';
      this.videoService.getAPI(this.drmFlag, id).takeUntil(this.ngUnsubscribe).timeout(this.videoService.getPrecisionTimeout()).subscribe(value => {
        this.precisionAPI = value;
        if (this.precisionAPI.resource_list && this.precisionAPI.resource_list.length > 0) {
          index = this.cdnData.findIndex(i => i.id === this.precisionAPI.resource_list[0].resource);
          if (index !== -1) {
            this.drmBasePath = this.cdnData[index].url_in;
          }
          this.resourceUrl = this.drmBasePath + this.resourceUrl;
          if (this.precisionAPI['c3.ri']) {
            this.contentUrl = this.resourceUrl;
            this.resourceUrlConviva = this.resourceUrl + '?c3.ri=' + this.precisionAPI['c3.ri'];
          } else {
            this.contentUrl = this.resourceUrl;
            this.resourceUrlConviva = this.resourceUrl;
          }
          this.generateUrl(false);
        }
      },
      err => {
        this.precisionAPI = null;
        this.resourceUrl = this.drmBasePath + this.resourceUrl;
        this.contentUrl = this.resourceUrl;
        this.resourceUrlConviva = this.resourceUrl;
        this.generateUrl(false);
        this.videoService.apiErrorEvent(err);
      });
    }
  }

  /*
    Setup player
  */
  public createPlaylist(): any {
		this.playlist = [{
			'file': this.resourceUrl,
			'drm': this.drm,
		}];
		this.setupPlayer();
	}

  public setupPlayer(): any {
    let mute, autostart, androidFF, firefox, muteStart;
    muteStart = this.videoObject[0].play_type === 'auto_play_unmute' ? false : true;
    if (muteStart) {
      this.muteLaunch = true;
      mute = true;
    } else if (this.navigator.userAgent.match(/mobile|iPhone|iPod|iPad/i) && !this.mobile_UC) {
      this.muteLaunch = true;
      mute = true;
    } else {
      this.muteLaunch = false;
      mute = false;
    }
    autostart =  this.mobile_UC ? false : true;
    androidFF = this.navigator.userAgent.match(/Android/i) && this.browser.name.match(/firefox/i);
    this.startPlayback = autostart;
    this.autoStart = autostart;
    this.volume = !mute;
    if (this.volume) {
      this.volumeIcon = this.full_volume_icon;
    } else {
      this.volumeIcon = this.mute_icon;
    }
    let playerSetup = {
      'playlist': this.playlist,
      'width': '100%',
      'height': '100%',
      'controls': false,
      'autostart': !this.navigator.userAgent.match(/mobile|iPhone|iPod|iPad/i) ? false : autostart,
      'mute': mute,
      'primary': 'html5',
      'hlshtml': true,
      'defaultBandwidthEstimate': 250000,
      'preload': 'auto'
    };
    if (androidFF) {
      firefox = {
                    'androidhls': false,
                    'hlsjsdefault': true
                  };
      playerSetup = $.extend({}, playerSetup, firefox);
    }
    // console.log('time logic', playerSetup);
    this.canSetupPlayer = true;
    if (!this.navigator.userAgent.match(/mobile|iPhone|iPod|iPad/i) || (this.navigator.userAgent.match(/mobile|iPhone|iPod|iPad/i) && this.canShowPlayer)) {
      // console.log('time logic - player initialized');
      this.canSetupPlayer = false;
      this.player.setup(playerSetup);
      this.addPlayerEventListeners();
      if (this.mobile_UC) {
        this.buffering = false;
        this.showPlayer = true;
        this.showplayer.emit(true);
      }
    }
  }

  public generateCustomkey(): any {
    let object;
    object = this.videoService.getEntitlementObject(this.videoObject[0]);
    this.postEntitlement(object);
  }

  public postEntitlement(object: any): any {
    this.userapiService.postEntitlementV3(object).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
      if (value && value !== null && !this.userapiService.isEmptyObject(value)) {
        this.customData = value.drm;
        this.setDRM();
        this.initializePlayer();
      } else {
            this.showErrorState(tryAgainMessage);
      }
    }, error => {
      if (error.name === 'TimeoutError') {
        this.showErrorState(tryAgainMessage);
      } else {
        this.showErrorState(tryAgainMessage);
      }
      this.videoService.apiErrorEvent(error);
    });
  }

  public setDRM(): any {
    var base64EncodeUint8Array;
    base64EncodeUint8Array = function(a) {
      for (var d, e, f, g, h, i, j, b = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=', c = '', k = 0; k < a.length; ) {
        d = a[k++], e = k < a.length ? a[k++] : Number.NaN, f = k < a.length ? a[k++] : Number.NaN, g = d >> 2, h = (3 & d) << 4 | e >> 4, i = (15 & e) << 2 | f >> 6, j = 63 & f, isNaN(e) ? i = j = 64 : isNaN(f) && (j = 64), c += b.charAt(g) + b.charAt(h) + b.charAt(i) + b.charAt(j);
      }
      return c;
    };
    var _contentId;
      this.drm = {'widevine': {
        'url': '//wv-keyos-aps1.licensekeyserver.com',
          'headers': {
            'name': 'customData',
            'value'  : this.customData
          }
        },
        'playready': {
          'url': '//pr-keyos-aps1.licensekeyserver.com/core/rightsmanager.asmx',
          'headers': {
            'name': 'customData',
            'value'  : this.customData
          }
        },
        'fairplay': {
          licenseResponseType: 'text',
          processSpcUrl: '//fp-keyos-aps1.licensekeyserver.com/getkey/',

          // FairPlay's certificate. If you are not sure, please ask KeyOS Support for the exact URL
          certificateUrl: '//fp-keyos.licensekeyserver.com/cert/b19d422d890644d5112d08469c2e5946.der',

          licenseRequestHeaders: [{
            name: 'customdata',
            value: this.customData
          }],

          licenseRequestMessage: function (licenseKeyMessage) {
            return 'spc=' + base64EncodeUint8Array(licenseKeyMessage) + '&assetId=' + _contentId;
          },

          extractContentId: function (contentId) {
            if (contentId.indexOf('skd://') > -1) {
              _contentId = contentId.split('skd://')[1].substr(0, 32);
              return _contentId;
            }
          //  console.log('Invalid Content ID format. The format of the Content ID must be the following: skd://xxx where xxx is the Key ID in hex format.');
          },

          extractKey: function(ckc) {
            let base64EncodedKey;
            base64EncodedKey = ckc.trim();
            if (base64EncodedKey.substr(0, 5) === '' && base64EncodedKey.substr(-6) === '') {
              base64EncodedKey = base64EncodedKey.slice(5, -6);
            }
            return base64EncodedKey;
          }
        },
       clearkey: ''
    };
  }

  /*
    Sets up Event Listners to the Player:
    - Append the respective event Listeners to the player
  */
  public addPlayerEventListeners(): any {
    this.player.on('ready', (event) => this.onPlayerReady(event));
    this.player.on('setupError', (event) => this.onSetupErrors(event));
  }

  public onPlayerReady(event): any {
    this.playerReady = true;
    // console.log('time logic - player is ready', this.canShowPlayer);
    if (this.canShowPlayer && !this.navigator.userAgent.match(/mobile|iPhone|iPod|iPad/i)) {
      this.player.play();
    }
    this.player.on('playlistItem', () => this.onPlaylistItem());
    this.player.on('firstFrame', (e) => this.initialization(e));
    this.player.on('complete', () => this.onComplete());
    this.player.on('error', (e) => this.onErrors(e));
    this.player.on('buffer', (e) => this.onBuffer(e));
    this.player.on('play', (e) => this.onplay(e));
    this.player.on('pause', (e) => this.onpause(e));
    this.player.on('time', (e) => this.updateCurrentTime(e));
    this.player.on('autostartNotAllowed', (e) => this.onautostartNotAllowed(e));
    this.player.on('viewable', (e) => this.onViewable(e));
    // this.player.on('all', (e) => this.onall(e));
  }

  public onall(event): any {
    console.log(event, 'all');
  }
  public onViewable(event): any {
    if (event.viewable && this.player.getState() === 'paused') {
      this.playVideo();
    } else if (!event.viewable && this.player.getState() === 'playing') {
      this.pauseVideo();
    }
  }

  public onautostartNotAllowed(event): any {
    if (event.reason === 'autoplayDisabled') { // Android firefox
      this.buffering = false;
      this.startPlayback = false;
      this.autoStart = false;
      this.showBackgroundImage = true;
      this.showPlayer = true;
      this.showplayer.emit(this.showPlayer);
    }
  }

  public onplay(event): any {
    if ($('.jw-open').length) {
      $('.jw-open').removeClass('jw-open');
    }
    if (this.popUps || !this.player.getViewable()) {
      this.pauseVideo();
      // return;
    }
    this.showBackgroundImage = false;
    this.buffering = false;
    // if (this.videoPaused) {
    //   this.videoPaused = false;
    //   let details;
    //   details = {
    //     'event': 'VideoResume',
    //     'ResumMetrics': '1'
    //   };
    //   this.googleAnalyticPost(details);
    // }
    if (this.error) {
      this.error = false;
    }
  }

  public onpause(event): any {
    // this.videoPaused = true;
    // let details;
    // details = {
    //   'event': 'VideoPause',
    //   'PauseMetrics': '1'
    // };
    // this.googleAnalyticPost(details);
  }

  public onBuffer(event): any {
    let network;
    network = this.networkStatus === 'offline' ? false : true;
    if (!network) {
      this.showErrorState(noNetworkText);
      return;
    } else {
      this.buffering = true;
      this.error = false;
    }
  }

  public onComplete(): any {
    this.showBackgroundImage = true;
    this.currentTime = '00:00';
    this.totalTimeMS = 0;
    this.buffering = false;
    this.videoAnalyticsService.updateMetaTags(this.player, 'videoEndPoint', this.currentTime);
    this.closePlayer();
  }

  public onErrors(event): any {
    if (this.networkStatus === 'offline' || !this.navigator.onLine) {
      event.message = noNetworkText;
    }
    if (!this.unsupported) {
      if (!(event.message === 'Captions failed to load')) {
        this.showErrorState(event.message);
      }
    }
  }

  public tryAgain(): any {
    this.error = false;
    this.startVideo();
  }

  public onSetupErrors(event): any {
    this.buffering = false;
    this.showErrorState(event.message);
  }

  public GAvideoClick(): any {
    let details, userAccessType, talamoosData;
    userAccessType = this.getUserAccessType();
    details = {
      'event': 'VideoClicks',
      'userCountry': this.sub.getCountryName(),
      'ClickMetrics': 1,
      'Business_Type': this.videoObject[0].business_type.indexOf('premium') !== -1 ? 'Premium' : 'Free',
      'User_Access_Type': userAccessType,
      'AudLan': (this.videoObject[0].audio_languages && this.videoObject[0].audio_languages.length) ? this.gaFirstAPIAudioLang : this.notAvailable,
      // new parameters
      'Carousal_Name': this.videoObject[0].carousel_name || this.notAvailable,
      'carousalVideoPlayType': this.autoStart ? 'autoplay' : 'tap',
      'Content_Show': this.videoObject[0].episode_name_en || this.videoObject[0].title_en || this.notAvailable,
      'qualityChoice': this.selectedBitrate ? this.selectedBitrate : 'NA',
      'autoPlay': this.autoplay ? 'on' : 'off'
    };
    talamoosData = this.videoObject[0].talamoos_data || this.notAvailable;
    details = $.extend({}, details, talamoosData);
    this.googleAnalyticPost(details);
  }

  public getUserAccessType(): any {
    let active, expired;
    if (!this.token) {
      return 'Free';
    } else {
      active = this.sub.checkPlanApiSuccess(false);
      if (active && active.length > 0) {
        return 'Premium';
      } else {
        expired = this.sub.getAllHistoryPlan();
        return (expired && expired.length) > 0 ? 'Expired' : 'Free';
      }
    }
  }

  public onPlaylistItem(): any {

    if (this.navigator.userAgent.match(/mobile|iPhone|iPod|iPad/i) && this.startPlayback) {
      this.showBackgroundImage = false;
      this.showPlayer = true;
      this.showplayer.emit(this.showPlayer);
    }

    let streamProtocol;
    if (this.resourceUrl.indexOf('.m3u8') >= 0) {
      streamProtocol = 'HLS';
    } else if (this.resourceUrl.indexOf('.mpd') >= 0) {
      streamProtocol = 'DASH';
    }
    this.videoAnalyticsService.updateMetaTags(this.player, 'streamProtocol', streamProtocol);
    this.videoAnalyticsService.createAnalyticSession(this.player, this.videoObject[0], this.resourceUrlConviva);

    this.getAudioLanguages();

  }

  public getAudioLanguages(): any {
    if (!this.videoObject[0].audio_languages || !this.videoObject[0].audio_languages.length) {
      return;
    }
    let language, gaAudioLanguages, counter;
    counter = 0;
    gaAudioLanguages = '';
    for (let i = 0; i < this.videoObject[0].audio_languages.length; i++) {
      language = this.languages.findIndex(index => index.id === this.videoObject[0].audio_languages[i]);
      if (i === 0) {
        this.gaFirstAPIAudioLang = language ? this.languages[language].name : 'Audio Language 1';
      }
      if (language !== -1) {
        gaAudioLanguages += (i !== 0 ? ',' : '') + this.languages[language].name;
      } else {
        gaAudioLanguages += (i !== 0 ? ',' : '') + 'Audio Language ' + (++counter);
      }
    }
    this.audioLangsString = gaAudioLanguages;
    this.selectedAudioqg = this.gaFirstAPIAudioLang;
    this.videoAnalyticsService.updateMetaTags(this.player, 'audioLanguage', this.selectedAudioqg);
  }

  public initialization(event): any {
    this.showBackgroundImage = false;

    this.showPlayer = true;
    this.showplayer.emit(this.showPlayer);
    this.GAvideoClick();
    this.totalTimeMS = this.player.getDuration();
    let time;
    time = this.updateTime(this.player.getPosition());
    this.videoAnalyticsService.updateMetaTags(this.player, 'videoStartPoint', time);
    // new events for carousel auto play
    this.videoAnalyticsService.updateMetaTags(this.player, 'Player Initialization', this.videoObject[0].title_en);
    this.videoAnalyticsService.updateMetaTags(this.player, 'Autoplay', this.autoStart);
    // this.videoAnalyticsService.updateMetaTags(this.player, 'Unmute', !this.volume);
  }

  public playVideo(): void {
    if (!this.player) {
    // if (!this.player || (this.player && this.player.getState() === 'idle')) {
      return;
    }
    this.startPlayback = true;
    if (!this.error) {
      this.showBackgroundImage = false;
    }
    this.player.play(true);
  }

  public pauseVideo(): void {
    if (!this.player || (this.player && this.player.getState() === 'idle')) {
      return;
    }
    this.player.pause(true);
  }


  public getTotalDuration(duration): any {
    if (duration && (!this.totalTimeMS || this.totalTimeMS !== duration)) {
      this.totalTimeMS = duration;
    }
  }

  public updateCurrentTime(currentTime): any {

    let currentTimeSec;
    currentTimeSec = currentTime.position;

    this.getTotalDuration(currentTime.duration);

    if (currentTimeSec > this.totalTimeMS) {
      this.currentTime = this.updateTime(this.totalTimeMS);
    } else {
      this.currentTime = this.updateTime(currentTimeSec);
    }

    if (this.token) {
      this.getWaterMark(currentTimeSec);
    }
  }

  public getWaterMark(value) {
    let waterMarkData, time, watermarkDuration, businessType, videoDur, count, lastFiveSec;
    videoDur = [];
    lastFiveSec = 5;
    waterMarkData = this.configData && this.configData.watermark_properties;
    if (waterMarkData && waterMarkData.watermark === true && waterMarkData.watermark_position) {
    watermarkDuration = waterMarkData.watermark_duration * 1000;
    businessType = this.videoObject[0].business_type;
    time = Math.floor(value);
    for (let k = 1; k <= lastFiveSec; k++) {
      count = Math.floor(this.totalTimeMS) - k;
      videoDur.push(count);
     }

     for (let j = 1; j <= videoDur.length; j++) {
      if (time === videoDur[j]) {
        this.isLastFiveSec = true;
        this.showWaterMark = false;
      }
     }

    if (!this.isLastFiveSec) {
     if (!this.showWaterMark) {
       for (let i = 0; i < waterMarkData.watermark_position.length; i++) {
         if (time > (waterMarkData.watermark_position[i] * 60) && time < ((waterMarkData.watermark_position[i] * 60) + waterMarkData.watermark_duration)) {
            this.showWaterMark = true;
            setTimeout(() => {
             this.showWaterMark = false;
           }, watermarkDuration);
         }
      }
    }
  }
 }
}

  public updateTime(s): any {
    let secs, mins, hrs, time, hrsStr;
    secs = s % 60;
    s = (s - secs) / 60;
    mins = s % 60;
    s = (s - mins) / 60;
    hrs = s % 60;
    secs = Math.floor(secs);
    hrsStr = hrs ? ((hrs < 10 ? '0' + hrs : hrs) + ':') : '';
    time = hrsStr + (mins < 10 ? '0' + mins : mins) + ':' + (secs < 10 ? '0' + secs : secs);
    return time;
  }

  public mute(): any {
    let network, muted;
    network = this.networkService.getPopupStatus();
    if (!network) {
      return;
    }
    muted = this.player.getMute();
    if (muted) {
      this.player.setMute(false);
      this.player.setVolume(100);
      this.volume = true;
      this.volumeIcon = this.full_volume_icon;
    } else {
      this.player.setMute(true);
      this.volume = false;
      this.volumeIcon = this.mute_icon;
    }
    this.videoAnalyticsService.updateMetaTags(this.player, 'Unmute', !this.volume);
  }

  public routeClick(event): any {
    this.videoAnalyticsService.updateMetaTags(this.player, 'Interacted with video', true);
  }

  public imageError(): any {
    if (this.image_container.nativeElement.src !== (this.window.location.origin + '/assets/default/popular.png')) {
      this.image_container.nativeElement.src = this.defaultImage;
    } else {
      this.showBackgroundImage = false;
      this.closeplayer.emit(true);
    }
  }

  public googleAnalyticPost(details): any {
    if (!this.videoItemforGA || this.videoItemforGA.Content_ID !== this.videoObject[0].id) {
      this.videoDetails();
    }
    let videoItemforGA, clickDetails;
    clickDetails = {
      'Horizontal_Index': this.xIndex || (this.xIndex !== 0 ? this.notAvailable : this.xIndex),
      'Vertical_Index': this.yIndex || (this.yIndex !== 0 ? this.notAvailable : this.yIndex),
      'SubCategory': this.gaSubCategory
    };
    videoItemforGA = $.extend({}, this.videoItemforGA, details);
    this.videoService.googleAnalyticPost(videoItemforGA, this.gaSubCategory, clickDetails);
  }

  public videoDetails(): any {
    let image;
    image = this.settingsService.getbasePath() + this.videoObject[0].id + '/list/' + '270x152/' + this.videoObject[0].image;
    this.videoItemforGA = {
      'VideoName': this.videoObject[0].title_en || this.notAvailable,
      'VideoCategory': this.videoObject[0].genre ? this.videoObject[0].genre.replace(', ', ',') : this.notAvailable,
      'VideoSection': this.videoService.getVideoSection(this.videoObject[0].asset_type, this.videoObject[0].category),
      'Content_Specification': this.videoService.getContentSpec(this.videoObject[0].content_type), // asset sub_type
      'VideoSubTitle': this.videoObject[0].episode_name_en || this.videoObject[0].title_en || this.notAvailable,
      'TVChannels': this.videoService.getChannels(this.videoObject[0].channel_name),
      'VideoDuration': this.videoObject[0].duration || 0,
      'Time_Slot': this.videoObject[0].time_slot || this.notAvailable, // pass time slot of the programme
      'Episode_Number': this.videoObject[0].episode_no || this.notAvailable,
      'Tumbnail_Image': image || this.notAvailable,
      'Content_Date': this.videoObject[0].release_date || this.notAvailable,
      'TopCategory': this.videoAnalyticsService.getTopCategory(this.videoObject[0].category),
      'Video_Language': this.audioLangsString || this.notAvailable,
      'Content_ID': this.videoObject[0].id || this.notAvailable,
      'Show_ID': (this.videoObject[0].asset_type === 1 ? this.videoObject[0].series_id : this.videoObject[0].id) || this.notAvailable,
      'Season_ID': this.videoObject[0].season_id || this.notAvailable,
      'ShowSubtype': this.videoService.getShowSubtype(this.videoObject[0].asset_type, this.videoObject[0].category, this.videoObject[0].content_type) || this.notAvailable,
      'BroadcastState': (this.videoObject[0].asset_type === 1 ? this.videoObject[0].broadcastState : this.notAvailable) || this.notAvailable,
    };
    this.videoItemforGA = $.extend({}, this.videoItemforGA, this.videoService.getDisplayContentLang());
  }

  public close(): void {
    if (!this.player || (this.player && this.player.getState() === 'idle')) {
      return;
    }
    this.videoAnalyticsService.updateMetaTags(this.player, 'videoEndPoint', this.currentTime);
    this.player.remove();
  }

  public ngOnChanges(changes: any) {
    if (changes['canShowPlayer'] && changes['canShowPlayer'].currentValue === true && !this.showPlayer) {
      // console.log('time logic - ngonchanges', Date.now());
      // if (this.navigator.userAgent.match(/mobile|iPhone|iPod|iPad/i) && this.canSetupPlayer) {
      //   this.setupPlayer();
      // } else {
      //   this.showBackgroundImage = false;
      //   this.showPlayer = true;
      //   this.showplayer.emit(this.showPlayer);
      // }
      if (this.canSetupPlayer && this.navigator.userAgent.match(/mobile|iPhone|iPod|iPad/i)) {
        this.setupPlayer();
        if (this.mobile_UC) {
          this.buffering = false;
          this.showPlayer = true;
          this.showplayer.emit(true);
        }
      } else if (this.playerReady && !this.navigator.userAgent.match(/mobile|iPhone|iPod|iPad/i)) {
        this.player.play();
      }
    }
  }

  public ngOnDestroy(): any {
    // console.log('ngOnDestroy', this.videoObject[0].title);
    if (this.errorTimeout) {
      clearTimeout(this.errorTimeout);
    }
    this.close();
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

}
