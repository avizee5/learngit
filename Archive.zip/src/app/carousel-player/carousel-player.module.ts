import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CarouselPlayerComponent } from './carousel-player.component';
import { SharedModule } from '../shared.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule
  ],
  declarations: [CarouselPlayerComponent],
  exports: [CarouselPlayerComponent]
})
export class CarouselPlayerModule { }



