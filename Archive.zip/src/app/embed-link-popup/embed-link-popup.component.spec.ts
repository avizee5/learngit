import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmbedLinkPopupComponent } from './embed-link-popup.component';

describe('EmbedLinkPopupComponent', () => {
  let component: EmbedLinkPopupComponent;
  let fixture: ComponentFixture<EmbedLinkPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmbedLinkPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmbedLinkPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
