import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { environment } from '../../environments/environment';
import * as $ from 'jquery';

@Component({
  selector: 'app-embed-link-popup',
  templateUrl: './embed-link-popup.component.html',
  styleUrls: ['./embed-link-popup.component.less']
})
export class EmbedLinkPopupComponent implements OnInit {
  private document: any;
  private videoUrl: any;
  public embedIcon: any;
  public closeIcon: any;
  public assetbasepath: any;

  public iframe: any = '<iframe width="560" height="315" src=contentURL frameborder="0" allow="autoplay;encrypted-media" allowfullscreen></iframe>';
  @Input() public contentId: any;
  @Output() public close = new EventEmitter<boolean>();
  constructor(@Inject(PLATFORM_ID) private platformId: Object) { }

  public ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.document = document;
    }
    this.assetbasepath = environment.assetsBasePath;
    this.embedIcon = this.assetbasepath + 'assets/common/embed_icon.png';
    this.closeIcon = this.assetbasepath + 'assets/common/close_icon.png';

    let url;
    this.document.getElementById('body').classList.add('modalOpen');
    this.videoUrl = environment.shareUrl + 'embed/' + this.contentId;
    url =  '"' +  this.videoUrl +  '"';
    this.iframe = this.iframe.replace('contentURL',  url);
  }

  public closePopup() {
  	  this.close.emit(false);
      this.document.getElementById('body').classList.remove('modalOpen');
  }
  public callToast() {
    let p, scope;
    scope = this;
    p = this.document.getElementById('embed_snackbar');
    p.className = 'show';
    setTimeout (function() {
          p.className = p.className.replace('show', '');
          setTimeout(function() {  scope.closePopup(); }, 500);
    }, 2000);
  }
  public copyText(): void {
    const el = this.document.createElement('textarea');
    el.value = this.iframe;
    this.document.body.appendChild(el);
    el.select();
    this.document.execCommand('copy');
    this.document.body.removeChild(el);
    this.callToast();
    $('.embedModal').css ('display', 'none');
    $('.embedModal-background').css ('display', 'none');
  }
}
