import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmbedLinkPopupComponent } from './embed-link-popup.component';
import { SharedModule } from '../shared.module';

@NgModule({
  imports: [
    CommonModule, SharedModule
  ],
  declarations: [EmbedLinkPopupComponent],
  exports: [EmbedLinkPopupComponent]
})
export class EmbedLinkPopupModule { }
