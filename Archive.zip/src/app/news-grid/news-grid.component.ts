import { Component, OnInit, Input, ViewChild, ElementRef, Output , EventEmitter, OnChanges , OnDestroy} from '@angular/core';
import * as $ from 'jquery';
import { environment } from '../../environments/environment';
import { SettingsService } from '../services/settings.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import {  NetworkService  } from '../services/network.service';
import { Router } from '@angular/router';
import { CommonService } from '../services/common.service';

/* Angular Universal */
import { isPlatformBrowser } from '@angular/common';
import { Inject , PLATFORM_ID } from '@angular/core';

@Component({
  selector: 'app-news-grid',
  templateUrl: './news-grid.component.html',
  styleUrls: ['./news-grid.component.less']
})
export class NewsGridComponent implements OnInit, OnChanges, OnDestroy {

  private showImage: Array<any> = [];
 @Input() public arrayList: any;
 @Input() public consumptionPage: any = false;
 @Input() public yIndex: any = 'NA';
 // @ViewChild('left') public previous_select: ElementRef;
 // @ViewChild('right') public next_select: ElementRef;
 @ViewChild('list') public element_select: ElementRef;
 private count: any;
 private gridWidth: any;
 private containerWidth: any;
 private scrollEnable = false;
 public arrows: any;
 private image_url: string;
 private basepath: string;
 private name: any;
 private errorImage: any;
 public isDesktop: any = true;
  private localStorage: any;
  private window: any;
  private document: any;
  private navigator: any;
  public right_arrow: any = true;
  public left_arrow: any = false;
  public isNewsPage: boolean;
  public scrollEvent: any;
  public scrollLeft: any = 0;

 // Asset basepath letiable
  private assetbasepath = environment.assetsBasePath;

  constructor(@Inject(PLATFORM_ID) private platformId: Object, private gtm: GoogleAnalyticsService, private router: Router,  private settingsService: SettingsService, private networkService: NetworkService, private commonService: CommonService) { }
   public ngOnChanges() {
      if (isPlatformBrowser(this.platformId)) {
        this.localStorage = localStorage;
        this.window = window;
        this.document = document;
        this.navigator = navigator;
      }
      this.basepath = this.settingsService.getbasePath();
      this.errorImage = this.assetbasepath + 'assets/default/tvshow.png';
      for ( let index = 0; index < this.arrayList.content.length; index++) {
          this.arrayList.content[index].image_url = this.basepath + this.arrayList.content[index].id + '/list/' + '170x170/' + this.arrayList.content[index].list_image;
      }
      if ( this.arrayList.content ) {
        if (this.arrayList.content.length < 5 || this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
          this.arrows = false;
        } else {
          this.isDesktop = true;
          this.arrows = true;
        }
        if ( this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
        this.isDesktop = false;
      } else {
        this.isDesktop = true;
      }

     if (this.window.innerWidth > 768) {
        this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
        this.containerWidth = 25 * this.arrayList.content.length * 0.941;
      } else if (this.window.innerWidth <= 768 && this.window.innerWidth > 480) {
        this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
        this.containerWidth = 25 * this.arrayList.content.length * 1.5;
      } else if (this.window.innerWidth <= 480) {
        this.containerWidth = 25 * this.arrayList.content.length * 2.75;
        if (this.arrayList.type === 'movies'  || this.arrayList.type === 'movie'  || this.arrayList.type === 'movies_details'  ) {
             this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
             this.containerWidth = 25 * this.arrayList.content.length * 1.5;
        } else {
            if (this.arrayList.content.length !== 1) {
          this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
        } else {
          this.gridWidth = 10;
        }

          // if (this.isDesktop === true) {
          //     this.containerWidth = 25 * this.arrayList.content.length * 2.75;
          //  } else {
          //     // this.containerWidth = 8.33 * this.arrayList.content.length;
          //        this.containerWidth = 13.96 * this.arrayList.content.length;
          //  }
        }
      }
    }
}

  public ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.localStorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }

    this.basepath = this.settingsService.getbasePath();
    for ( let index = 0; index < this.arrayList.content.length; index++) {
        if ( this.arrayList.content[index].list_image !== null || this.arrayList.content[index].list_image !== undefined) {
        this.arrayList.content[index].image_url = this.basepath + this.arrayList.content[index].id + '/list/' + '170x170/' + this.arrayList.content[index].list_image;
        } else {
        this.arrayList.content[index].image_url = this.assetbasepath + '/assets/default/channel_logo.png';
        }
      }
        this.count = 0;
        if (this.arrayList.content.length < 5 || this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
          this.arrows = false;
        } else {
          // this.isDesktop=true;
          this.arrows = true;
        }

        if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
          this.scrollEnable = true;
          }

        if (this.window.innerWidth > 768) {
        this.gridWidth = (( 4 * 25) / this.arrayList.content.length) * 0.941;
        this.containerWidth = 25 * this.arrayList.content.length;
      } else if (this.window.innerWidth <= 768 && this.window.innerWidth > 480) {
        this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
        this.containerWidth = 25 * this.arrayList.content.length * 1.5;
      } else if (this.window.innerWidth <= 480) {
        this.containerWidth = 25 * this.arrayList.content.length * 2.75;
        if (this.arrayList.type === 'movies'  || this.arrayList.type === 'movie'  || this.arrayList.type === 'movies_details'  ) {
          this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
          this.containerWidth = 25 * (this.arrayList.content.length) * 1.5;
        } else {
          if (this.arrayList.content.length !== 1) {
          this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
        } else {
          this.gridWidth = 10;
        }

          // if (this.isDesktop === true) {
          //   this.containerWidth = 25 * this.arrayList.content.length * 2.75;
          // } else {
          //    this.containerWidth = 13.96 * this.arrayList.content.length;
          //   }
          }
        }
        }
        private previous(): void {
          this.collectionSwipeDetails('right');
        if (this.count < 0) {
          this.count += 25;
          if (this.count + 25 === 25 && this.arrayList.content.length === 5) {
            // this.previous_select.nativeElement.src = this.assetbasepath + 'assets/common/left_nav.png';
            // this.next_select.nativeElement.src = this.assetbasepath + 'assets/common/right_nav_selected.png';
                    this.right_arrow = true;
        this.left_arrow = false;
          } else if (this.count + 25 === 25 && this.arrayList.content.length !== 5) {
            // this.previous_select.nativeElement.src = this.assetbasepath + 'assets/common/left_nav.png';
            // this.next_select.nativeElement.src = this.assetbasepath + 'assets/common/right_nav_selected.png';
                  this.right_arrow = true;
        this.left_arrow = false;
          } else if (this.count < - (this.arrayList.content.length - 4) * 25 + 50) {
            // this.next_select.nativeElement.src = this.assetbasepath + 'assets/common/right_nav_selected.png';
        this.right_arrow = true;
          }
          // this.element_select.nativeElement.style.marginLeft = this.count + '%';
      this.element_select.nativeElement.style.marginLeft = (this.count * 23.525 / 25) + '%';

        }
      }

      private next(): void {
        this.collectionSwipeDetails('left');
        if (this.count >= - (this.arrayList.content.length - 4) * 25 + 25) {
      let last;
          this.count -= 25;
          if (this.count === -25 && this.arrayList.content.length === 5) {
            // this.previous_select.nativeElement.src = this.assetbasepath + 'assets/common/left_nav_selected.png';
            // this.next_select.nativeElement.src = this.assetbasepath + 'assets/common/right_nav.png';
            this.left_arrow = true;
            this.right_arrow = false;

          } else if (this.count === -25 && this.arrayList.content.length !== 5) {
            // this.previous_select.nativeElement.src = this.assetbasepath + 'assets/common/left_nav_selected.png';
            this.left_arrow = true;
          } else if ( this.count <= -(this.arrayList.content.length - 4) * 25 ) {
            // this.next_select.nativeElement.src = this.assetbasepath + 'assets/common/right_nav.png';
            this.right_arrow = false;
            last = true;
          }
          // this.element_select.nativeElement.style.marginLeft = this.count + '%';
                if (last) {
        this.element_select.nativeElement.style.marginLeft = ((this.count * 23.525 / 25) + (23.525 / 4)) + '%';
      } else {
        this.element_select.nativeElement.style.marginLeft = (this.count * 23.525 / 25) + '%';
      }
        }
      }

      public onResize(event: any): void {
            if (this.arrayList.content.length < 5 || this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
      this.arrows = false;
    } else {
      this.arrows = true;
    }
        if (this.window.innerWidth > 768) {
          this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
          this.containerWidth = 25 * this.arrayList.content.length * 0.941;
        } else if (this.window.innerWidth <= 768 && this.window.innerWidth > 480) {
          this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
          this.containerWidth = 25 * this.arrayList.content.length * 1.5;
        } else if (this.window.innerWidth <= 480) {
          this.containerWidth = 25 * this.arrayList.content.length * 2.75;
          if (this.arrayList.type === 'movies' || this.arrayList.type === 'movie' || this.arrayList.type === 'movies_details' ) {
            this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
            this.containerWidth = 25 * this.arrayList.content.length * 1.5;
          } else {
            if (this.arrayList.content.length !== 1) {
            this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
            } else {
              this.gridWidth = 10;
            }
            // if (this.isDesktop === true) {
          //     this.containerWidth = 25 * this.arrayList.content.length * 2.75;
            // } else {
          //     // this.containerWidth = 8.33 * this.arrayList.content.length;
          //      this.containerWidth = 13.96 * this.arrayList.content.length;
            // }
          }
        }
    }

      private callChannel(name, id, title, xIndex) {
        let gAtitle;
        if (title === 'SUSCRIPTION.SIMILAR_CHANNELS') {
          gAtitle = 'Similar Channels';
        } else if (title === 'SUSCRIPTION.RELATED_CHANNELS') {
          gAtitle = 'Related Channels';
        }
        this.gtm.GAsubCategory = gAtitle;
        this.gtm.setContentClickDetails(xIndex, this.yIndex, gAtitle);
        this.commonService.updateCollectionId(null);
        this.commonService.setTalamoosData('', '', '');
        this.name = name.toLowerCase().replace(/ /g, '-');
        this.name = this.name.toLowerCase().replace(/--/g, '-');
        this.name = this.name.toLowerCase().replace(/---/g, '-');
        this.name = this.name.toLowerCase().replace(/&/g, 'and');
        this.router.navigate(['/channels/details', this.name , id ]);
      }
      public sublandingRoute() {
        this.commonService.setNewsPage(true);
        this.router.navigate(['/channels']);
        this.sendButtonClickDetails('view all');
      }

        public ngOnDestroy() {
         $('#schema').remove();
        }
        public scrollData(event) {
          clearTimeout(this.scrollEvent);
          this.scrollEvent = setTimeout(() => {
            if (this.scrollLeft < event.path[0].scrollLeft) {
              this.collectionSwipeDetails('left');
            } else {
              this.collectionSwipeDetails('right');
            }
            this.scrollLeft = event.path[0].scrollLeft;
          }, 100);
        }
        public collectionSwipeDetails(direction) {
          let swipeDetails;
          swipeDetails = {
            'event': 'swipeClick',
            'SwipeType': 'collection',
            'SwipeDirection': direction,
            'SubCategory': 'Live News',
            'Vertical_Index': this.yIndex || (this.yIndex !== 0 ? 'NA' : this.yIndex)
          };
          this.gtm.sendEventDetails(swipeDetails);
        }
        public sendButtonClickDetails(ctadetails) {
          let buttonDetails;
          buttonDetails = {
            'event': 'buttonClicks',
            'cta': ctadetails,
            'SubCategory': 'Live News'
          };
          setTimeout(() => {
            this.gtm.sendEventDetails(buttonDetails);
          }, 100);
        }
}
