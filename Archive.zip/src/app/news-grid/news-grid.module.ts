import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NewsGridComponent } from './news-grid.component';
import { SharedModule } from '../shared.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule
  ],
  declarations: [NewsGridComponent],
  exports: [NewsGridComponent]

})
export class NewsGridModule {
}



