import { Component, OnInit, Input, Output, ViewChild, EventEmitter} from '@angular/core';
import { UserProfileService } from '../services/user-profile.service';
import { HeaderservicesService } from '../services/headerservices.service';
import { NetworkService } from '../services/network.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { SettingsService } from '../services/settings.service';
import { VideoService } from '../services/video.service';
import { Router } from '@angular/router';
import { MdMenuTrigger} from '@angular/material';
import { environment } from '../../environments/environment';
import * as $ from 'jquery';
import { Http} from '@angular/http';
import {FavoritesApi, RemindersApi, UserApi, WatchHistoryApi, WatchlistApi } from '../../data/user/api/api';
import {CommonService} from '../services/common.service';
import {EpgApi} from '../../data/catalog/api/EpgApi';
import { RouteService} from '../services/route.service';
import {TranslateService} from '@ngx-translate/core';
import { UseractionapiService } from '../services/useractionapi.service';
import { VideoAnalyticsService } from './../services/video-analytics.service';



/* Angular Universal */
import { isPlatformBrowser } from '@angular/common';
import { Inject , PLATFORM_ID } from '@angular/core';
declare const qg;

@Component({
  selector: 'app-scroll-grid',
  templateUrl: './scroll-grid.component.html',
  styleUrls: ['./scroll-grid.component.less']
})

export class ScrollGridComponent implements OnInit {
  @ViewChild(MdMenuTrigger) public trigger: MdMenuTrigger;
  @Input() private subCategory: any;
  @Input() public show: any;
  @Input() private modalVideoPopup: any;
  @Input() private type: any;
  @Input() private channelName: any;
  @Input() private channelId: any;
  @Input() public episode: boolean;
  @Input() private category: any;
  @Input() private tvshow: any;
  @Input() public movie: any;
  @Input() public collectionId: any;
  @Input() public modelName: any = 'NA';

  @Input() public xIndex: any = 'NA';
  @Input() public yIndex: any = 'NA';

  private menuOpen: any;   /*Overflow menu*/
  private reminder: any = false;
  public showShare: boolean;
  private shareUrl: any;
  private route: any;
  private storedReminderData: any;
  private timestampTime: any;
  private timestampDateTime: any;
  public showUrl: any;
  private basepath: any;
  private addReminder: any;
  public errorImage1: any;
  private tokenValue: any;
  private storedWatchData: any;
  private storedData: any;
  private localStorage: any;
  private window: any;
  private document: any;
  private navigator: any;
  private months: any = ['Jan', 'Feb', 'Mar',
  'Apr', 'May', 'Jun', 'Jul',
  'Aug', 'Sep', 'Oct',
  'Nov', 'Dec'
  ];
  private configUser: any;
  private watched = false;
  private favorite = false;
  // Asset basepath variable
  public assetbasepath = environment.assetsBasePath;
  private clientID: any;
  private marketingValue: any;
  public content_owner: any;
  public thumbnailClickEvent: any;
  public userToken: any;
  public configValue: any;
  public display: any;
  public content: any;

  constructor(private useractionapi: UseractionapiService, private routeservice: RouteService, private videoService: VideoService, private commonService: CommonService, private http: Http, @Inject(PLATFORM_ID) private platformId: Object, private settingsService: SettingsService, private networkService: NetworkService, private gtm: GoogleAnalyticsService, private headerservicesService: HeaderservicesService, private router: Router, private userProfileService: UserProfileService, private videoAnalyticsService: VideoAnalyticsService, private translate: TranslateService) { }

  public ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.localStorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
    this.tokenValue = this.localStorage.getItem('token');
    this.display = this.tokenValue ? this.localStorage.getItem('UserDisplayLanguage') : this.localStorage.getItem('display_language');
    this.content = this.tokenValue ? this.localStorage.getItem('UserContentLanguage') : this.localStorage.getItem('ContentLang');
    this.errorImage1 = this.assetbasepath + 'assets/default/epg_channel_logo.png';
    this.basepath = this.settingsService.getbasePath();
    this.gtm.storeWindowError();
    this.userToken = this.localStorage.getItem('token');
    this.configValue = this.settingsService.getCompleteConfig();


    let params;
    params = 'bearer ' + this.tokenValue;
    if (this.tokenValue) {
      this.configUser = {
        apiKey: params,
        username: ' ',
        password: ' ',
        accessToken: ' ',
        withCredentials: false
      };
    }
    if (this.show.list_image !== null || this.show.list_image !== undefined) {
      if (this.episode) {
       // this.showUrl = this.basepath + this.show.id + '/list/' + '270x152/' + this.show.list_image;
       if (this.show.list_image) {
                 this.showUrl = this.commonService.getEpisodeUrl(this.show.release_date, this.tvshow.original_title, this.show, '270x152/');
       }
      } else if (this.movie) {
          this.showUrl = this.commonService.getEpisodeUrl(this.show.release_date, this.tvshow.original_title, this.show, '270x152/');
      } else {
        this.showUrl = this.basepath + this.show.id + '/list/' + '138x78/' + this.show.list_image;
      }


    } else {
      this.showUrl = this.assetbasepath + 'assets/default/epg_channel_logo.png';
    }
    this.menuOpen = false;

    this.show.genres = this.show.genres ? this.show.genres : (this.show.genre ? this.show.genre : []);
    if (this.show.asset_subtype === 'video' && this.show.genres.findIndex(i => i.id === 'News') !== -1) {
          this.content_owner = this.commonService.getSubcategory(this.show.tags, 0, this.show.asset_subtype, this.show.genres, this.show.content_owner).join(', ');
          // console.log(subCategory, 'subCategory')
          // if (subCategory.length <= 1) {
          //   this.content_owner = subCategory[0] ? subCategory[0] : '';
          // } else {
          //   this.content_owner = subCategory.join(', ');
          // }
    }
  }

private updateEpisodeDuration(duration, index, date): any {
  let text;
  if (index) {
          text = 'Ep ' + index + this.dateChange(date, true) + this.secondsToHms(duration, date, index);
            return text;
  } else {
          text = this.dateChange(date, false) + this.secondsToHms(duration, date, index);
            return text;
  }
}
private dateCalculate(date): any {
  date = this.dateChange(date, false);
  return date;
}
private dateChange(value, index) {
    let date;
    let day, monthIndex, year;
          if ( value ) {
            date = new Date(value);
            day = date.getDate();
            monthIndex = date.getMonth();
            year = date.getFullYear().toString();
            let crctdate;
            crctdate = index ? ' | ' +  day  : day;
            return (crctdate + ' ' + this.translate.instant('TVGUIDE.' + this.months[monthIndex].toUpperCase())  + ' ' +  year.substring(2)) ;
          } else {
            return '';
          }
        }
  private updateGMTime(UTC): any {
    let x;
    x = new Date(UTC);
    let time;
    if ( x.getMinutes() < 9 ) {
      time = x.getHours() + ':' + '0' + x.getMinutes();
    } else {
      time = x.getHours() + ':' + x.getMinutes();
    }
    return time;
  }
    private watchNow(event: any): void {
      this.gtm.logEvent(this.threeDotEvent('watch now'));
      this.episodeCall();
    }
    private watchList(event: any): void {
    let ctaString;
    ctaString = this.watched ? 'remove from watchlist' : 'add to watchlist';
    if (this.networkService.getPopupStatus()) {
      if (this.tokenValue) {
        $('.auto-loader-watch_scroll').css('display', 'inline-block');
        $('#watch_Later_scroll').css('display', 'none');
        event.stopPropagation();
        let watchListRequest;
        watchListRequest = new  WatchlistApi(this.http, null, this.configUser);
        if (this.watched === true ) {
          watchListRequest.v1WatchlistDelete(this.show.id, this.show.asset_type).subscribe(value => {
            this.watched = false;
            this.userProfileService.removeWatchData(this.show);
           $('.auto-loader-watch_scroll').css('display', 'none');
            $('#watch_Later_scroll').css('display', '');
          },
          err => {
            this.watched = true;
            $('.auto-loader-watch_scroll').css('display', 'none');
            $('#watch_Later_scroll').css('display', '');

          });
        } else {
                    let obj;
                    obj = this.userProfileService.createObject(this.show);
          watchListRequest.v1WatchlistPost(obj).subscribe(value => {
            this.watched = true;
            this.userProfileService.setWatchData(this.show);
            $('.auto-loader-watch_scroll').css('display', 'none');
            $('#watch_Later_scroll').css('display', '');
          },
          err => {
            this.watched = false;
            this.gtm.sendErrorEvent('api', err);
            $('.auto-loader-watch_scroll').css('display', 'none');
            $('#watch_Later_scroll').css('display', '');
          });
        }
      } else {
        this.headerservicesService.signReminderChange(true);
      }
    }
    this.gtm.logEvent(this.threeDotEvent(ctaString));
  }
    private addFavorite(event: any): void {
      let ctaString;
      ctaString = this.favorite ?  'remove from favourite' : 'add to favourite';
    if (this.networkService.getPopupStatus()) {
      if (this.tokenValue) {
        event.stopPropagation();
        $('.auto-loader-fav_scroll').css('display', 'inline-block');
        $('#favorite_scroll').css('display', 'none');
        let favoritesRequest;
        favoritesRequest = new  FavoritesApi(this.http, null, this.configUser);
        if (this.favorite === true ) {
          favoritesRequest.v1FavoritesDelete(this.show.id, this.show.asset_type).subscribe(value => {
            this.favorite = false;
            this.userProfileService.removeFavoriteData(this.show);
            $('.auto-loader-fav_scroll').css('display', 'none');
            $('#favorite_scroll').css('display', '');
          },
          err => {
            this.favorite = true;
            this.gtm.sendErrorEvent('api', err);
           $('.auto-loader-fav_scroll').css('display', 'none');
            $('#favorite_scroll').css('display', '');
          });
        } else {
          let obj;
          obj = this.userProfileService.createObject(this.show);
          favoritesRequest.v1FavoritesPost(obj).subscribe(value => {
            this.favorite = true;
            this.userProfileService.setFavoriteData(this.show);
            $('.auto-loader-fav_scroll').css('display', 'none');
            $('#favorite_scroll').css('display', '');
          },
          err => {
            this.favorite = false;
            this.gtm.sendErrorEvent('api', err);
            $('.auto-loader-fav_scroll').css('display', 'none');
            $('#favorite_scroll').css('display', '');
          });
        }
      } else {
        this.headerservicesService.signReminderChange(true);
      }
    }
    this.gtm.logEvent(this.threeDotEvent(ctaString));
  }
  private secondsToHms(s, date, index): any {
      let secs, mins, hrs, secs_new, mins_new, time;
      if (s) {
        secs = s % 60;
        s = (s - secs) / 60;
        mins = s % 60;
        s = (s - mins) / 60;
        hrs = s % 60;
        if (mins < 10) {
          mins_new = '0' + mins;
        } else {
          mins_new = '' + mins;
        }
        if (secs < 10) {
          secs_new = '0' + secs;
        } else {
         secs_new = '' + secs;
        }
        if (this.display === 'ru') {
           time = (hrs ? hrs + 'ч' : '') + (mins ? (' ' + mins_new) + 'м' : '') + (secs ? (' ' + secs_new) + 'с' : '');
        } else {
            time = (hrs ? hrs + 'h' : '') + (mins ? (' ' + mins_new) + 'm' : '') + (secs ? (' ' + secs_new) + 's' : '');
        }
    if (date || index) {
      time = ' | ' + time;
    } else {
      time = time;
    }
     return time;
      } else {
         time = '';
         return time;
      }
  }


  public share(event: any): void  {     /*Share*/
    let tempTitle, temptitle;
    if (this.movie || this.episode) {
      // if (this.tvshow.extended && this.tvshow.extended.seo_title) {
      //       tempTitle = (this.tvshow.extended.seo_title !== null || this.tvshow.extended.seo_title !== undefined || this.tvshow.extended.seo_title !== '') ? this.tvshow.extended.seo_title : this.tvshow.original_title;
      // } else {
      //       tempTitle = (this.tvshow.seo_title && (this.tvshow.seo_title !== null || this.tvshow.seo_title !== undefined || this.tvshow.seo_title !== '')) ? this.tvshow.seo_title : this.tvshow.original_title;
      // }
      // if (this.show.extended && this.show.extended.seo_title) {
      //       temptitle = (this.show.extended.seo_title !== null || this.show.extended.seo_title !== undefined || this.show.extended.seo_title !== '') ? this.show.extended.seo_title : this.show.original_title;
      //     } else {
      //       temptitle = (this.show.seo_title && (this.show.seo_title !== null || this.show.seo_title !== undefined || this.show.seo_title !== '')) ? this.show.seo_title : this.show.original_title;
      // }
      tempTitle = this.tvshow.original_title;
      temptitle = this.show.original_title;
    }
    if (this.networkService.getPopupStatus()) {
      event.stopPropagation();
      this.showShare = true;
      this.shareUrl =  (this.episode)  ? this.category  + this.commonService.convertToLowercase(tempTitle) + '/' + this.tvshow.id + '/' + this.commonService.convertToLowercase(temptitle) + '/' + this.show.id :  (this.movie ? this.category + this.commonService.convertToLowercase(temptitle) + '/' + this.show.id : this.router.url);
      // (this.movie? this.category + this.commonService.convertToLowercase(tempTitle) + '/' + this.show.id: this.rouuter.url)
    }
    this.gtm.logEvent(this.threeDotEvent('share'));
  }
private closeShare(eve: any): any {
    this.showShare = false;
  }

  private stopEvent(event: any) {
    event.stopPropagation();
  }

  private setreminder(event: any): void {
    let ctaString;
    ctaString = this.reminder ? 'remove reminder' : 'set reminder';
    let network;
    network = this.networkService.getPopupStatus();
    if ( network === true) {
      let token;
      token = this.localStorage.getItem('token');
      if (token) {
        let login_type;
        login_type = this.localStorage.getItem('login');
        let reminderType;
        reminderType = (( login_type === 'Mobile') ? 'Mobile' : 'Email');
        event.stopPropagation();

        if (this.reminder === true ) {
          this.reminder = false;
          this.userProfileService.removeReminderData(this.show.vod_id, this.show.vod_asset_type );
        } else {
          this.reminder = true;
          this.userProfileService.setReminderData({'id': this.show.vod_id, 'asset_type': this.show.vod_asset_type , 'reminder_type' : reminderType});
          // this.timestampTime = this.gtm.fetchCurrentTime();
          // this.timestampDateTime = this.gtm.fetchCurrentDate();
          // this.clientID = this.gtm.fetchClientId();
          // this.marketingValue = this.gtm.fetchMarketing();
          // let genres;
          // genres = [];
          // for ( let index = 0; index < this.show.genres.length; index++) {
          //   genres.push(this.show.genres[index].value);
          // }
          // let genresdata;
          // genresdata = genres.join(',');

          // this.addReminder =  {
          //   'event' : 'AddRemider',
          //   'VideoName' : this.show.title,
          //   'VideoCategory': genresdata,
          //   'VideoSection': 'NA',
          //   'VideoSubTitle': 'NA',
          //   'TVChannels': '',
          //   'VideoDuration': this.show.duration,
          //   'VideoStartTime': this.show.start_time,
          //   'Time_Slot': 'NA',
          //   'Episode_Number': 'NA',
          //   'Tumbnail_Image': this.showUrl,
          //   'G_ID': this.tokenValue,
          //   'Client_ID': this.clientID,
          //   'retargeting_remarketing' : this.marketingValue,
          //   'TimeHHMMSS': this.timestampTime,
          //   'DateTimeStamp': this.timestampDateTime
          // };
          // this.gtm.logEvent(this.addReminder);
        }
      } else {
        this.headerservicesService.signReminderChange(true);
      }
    }
    this.gtm.logEvent(this.threeDotEvent(ctaString));
  }

  private callToast() {  /*Calling Toast on saving changes */
    let p;
    p = this.document.getElementById('snackbar');
    p.className = 'show';
    setTimeout(function() { p.className = p.className.replace('show', ''); }, 3000);
  }
private loadMoreMenu() {
  if (this.episode) {
    this.storedData = this.userProfileService.getFavoriteData();
    this.storedWatchData = this.userProfileService.getWatchData();
    if (this.storedData) {
      for (let index = 0; index < this.storedData.length; index++) {
        if (this.storedData[index].id === this.show.id) {
          this.favorite = true;
          break;
        } else {
          this.favorite = false;
        }
      }
     // this.favorite = this.storedData.some(x => x.id === this.show.id)
    }
    if (this.storedWatchData) {
      for (let index1 = 0; index1 < this.storedWatchData.length; index1++) {
        if (this.storedWatchData[index1].id === this.show.id) {
          this.watched = true;
          break;
        } else {
          this.watched = false;
        }
      }
            // this.watched = this.storedData.some(x => x.id === this.show.id)
    }
  } else {
      this.storedReminderData = this.userProfileService.getReminderData();
  if ( this.storedReminderData) {
    for ( let index2 = 0; index2 < this.storedReminderData.length; index2++) {
      if (this.storedReminderData[index2].id === this.show.vod_id) {
        this.reminder = true;
      }
    }
  }
}
}
  public showMenu = function() {
    this.menuOpen = true;
    this.loadMoreMenu();

    $('.cdk-overlay-backdrop').css('pointer-events', 'none');

    $(this.document).mouseup((e) => this.hideMenu(e));
    $('#featureouter').scroll((e) => this.hideMenu(e));
  };

  private hideMenu(e): any {
    let scope, container;
    scope = this;
    container = $('.mat-menu-content');
    // console.log(e.type);
    // if the target of the click isn't the container nor a descendant of the container
    if (!container.is(e.target) && container.has(e.target).length === 0 && scope.menuOpen === true) {
      scope.trigger.closeMenu();
      scope.menuOpen = false;
      $(this.document).unbind('mouseup');
      $('#featureouter').unbind('scroll');
    }
  }

  public episodeCall(): any {
                  if (this.modelName && this.show.clickID) {
                let data;
                data = {
              'type': 'zee5',
              'action': 'click',
              'modelName': this.modelName,
              // 'userID': this.localstorage.getItem('ID') ? this.localstorage.getItem('ID') : this.localstorage.getItem('guestToken'),
              // 'userID': this.localstorage.getItem('token') ? this.localstorage.getItem('token') : this.localstorage.getItem('guestToken'),
              'itemID': this.show.id,
              'clickID': this.show.clickID
            };

            this.useractionapi.talamoosClick(data).subscribe(callback => {
              // console.log(callback, 'callback');
            });
              }


    this.videoService.autoPlayed('');
    this.commonService.updateCollectionId(this.collectionId);
    this.commonService.setTalamoosData(this.modelName, this.show.clickID, this.show.origin);
    this.gtm.GAsubCategory = this.subCategory;
    this.gtm.setContentClickDetails(this.xIndex, this.yIndex, this.gtm.GAsubCategory);

    if (this.show.asset_subtype === 101) {
      this.commonService.assetCheck(this.show, this.router, this.showUrl, 'videoNameClick', '');
    } else {
      let tempTitle ;
        // if (this.show && this.show.extended && this.show.extended.seo_title) {
        //   tempTitle = (this.show.extended.seo_title !== null || this.show.extended.seo_title !== undefined || this.show.extended.seo_title !== '') ? this.show.extended.seo_title : this.show.original_title;
        // } else {
        //   tempTitle = (this.show.seo_title && (this.show.seo_title !== null || this.show.seo_title !== undefined || this.show.seo_title !== '')) ? this.show.seo_title : this.show.original_title;
        // }
        tempTitle = this.show.original_title;
        let scope;
        scope = this;
      if (this.networkService.getPopupStatus()) {
        if (this.show.asset_type === 0) {
          if (this.show.asset_subtype === 'movie') {
            this.router.navigate(['movies/details/' , this.commonService.convertToLowercase(tempTitle) , this.show.id ]);
          } else if (this.show.asset_subtype === 'video' && this.show.genres.findIndex(i => i.id === 'News') !== -1) {
            this.router.navigate(['news/details/' , this.commonService.convertToLowercase(tempTitle) , this.show.id]);
          } else {
            this.router.navigate(['videos/details/' , this.commonService.convertToLowercase(tempTitle) , this.show.id]);
          }
        }  else if (this.show.asset_type === 8) {
          this.router .navigate(['/collections', this.commonService.convertToLowercase(tempTitle), this.show.id ]);
        } else if (this.show.asset_type === 2 ) {
            let base;
            base = (this.show.tvshow.asset_subtype === 'original') ? 'zee5originals/details/' : 'tvshows/details/';
            tempTitle = this.show.tvshow.original_title;
            if (this.show.orderid === 1) {
                this.router.navigate([base , this.commonService.convertToLowercase(tempTitle) , this.show.tvshow.id  , 'episodes']);
            } else {
                this.router.navigate([base , this.commonService.convertToLowercase(tempTitle) , this.show.tvshow.id , 'season-' + this.show.orderid , 'episodes']);
            }
        } else if (this.show.asset_type === 6 ) {
          this.router.navigate([(this.show.asset_subtype === 'original' ? 'zee5originals' : 'tvshows') + '/details/' , this.commonService.convertToLowercase(tempTitle), this.show.id, 'latest'  ]);
        } else if (this.show.asset_type === 9 ) {
          this.router.navigate(['/channels/details', this.commonService.convertToLowercase(tempTitle), this.show.id ]);
        } else if (this.show.asset_type === 1) {
          let showTitle;
          showTitle = this.show.tvshow.original_title;
          if ( this.show.tvshow && this.show.tvshow.asset_subtype === 'original') {
            this.router.navigate(['zee5originals/details/' , this.commonService.convertToLowercase(showTitle) , this.show.tvshow.id ,  this.commonService.convertToLowercase(tempTitle)  , this.show.id  ]);
          } else if (this.show.tvshow && this.show.tvshow.asset_subtype ) {
            this.router.navigate(['tvshows/details/' , this.commonService.convertToLowercase(showTitle) , this.show.tvshow.id ,  this.commonService.convertToLowercase(tempTitle)  , this.show.id  ]);
          }
        } else if (this.show.asset_type === 10) {
          if (this.type !== 'live') {
            if (this.show.channel_id ) {
              this.router.navigate(['/channels/details', this.commonService.convertToLowercase(this.show.channel_original_title), this.show.channel_id ]);
            } else {
              let x, countryCode, config;
              config = {
                    apiKey: ' ',
                    username: ' ',
                    password: ' ',
                    accessToken: ' ',
                    withCredentials: false
                  };
              x = new EpgApi(this.http, null, config);
              countryCode = this.settingsService.getCountry();
              x.v1EpgGetById(this.show.id, undefined, countryCode).subscribe(value => {
                this.show.channel_id = value.channel.id;
                this.router.navigate(['channels/details', this.commonService.convertToLowercase(this.show.channel), this.show.channel_id ]);
              }
              );
            }
          }
        }
      }
    }
    }

    public  clickGAEvents(eventname) {
          let availableChannelOriginal, langObj, userAccessType;
          availableChannelOriginal = (this.show.channels && this.show.channels !== (null && undefined) && this.show.channels.length > 0) ? this.show.channels.map(function(elem) {return elem.original_title; }).join(', ') : 'NA';
          langObj = this.gtm.displayContentLan();
          userAccessType = this.commonService.getUserAccessType();
          this.thumbnailClickEvent = {
            'event': eventname,
            'VideoName': this.show.original_title ? this.show.original_title : 'NA',
            'VideoCategory': this.show.genres ? this.show.genres.map(function(elem) {return elem.id; }).join(', ') : 'NA',
            'VideoSection': this.videoService.getVideoSection(this.show.asset_type, this.show.asset_subtype) || 'NA',
            'VideoSubTitle': this.show.original_title || this.show.tvshow_details.original_title || 'NA',
            'TVChannels': availableChannelOriginal || 'NA' ,
            'VideoDuration': this.show.duration || 0,
            'VideoStartTime': this.show.start_time ? this.show.start_time : 'NA',
            'Time_Slot': this.show.time_slot || 'NA',
            'Episode_Number': this.show.index ? this.show.index : 'NA',
            'Tumbnail_Image': this.showUrl,
            'Content_Specification': this.videoService.getContentSpec(this.show.asset_subtype) || 'NA',
            'Content_Show': this.show.original_title || this.show.title || 'NA',
            'Content_Date': this.commonService.dateChange(this.show.release_date) || 'NA',
            'PageName': this.gtm.getPageName(),
            'Previous_Screen': this.gtm.previousScreenName,
            'Vertical_Index': this.yIndex || (this.yIndex !== 0 ? 'NA' : this.yIndex),
            'Horizontal_Index': this.xIndex || (this.xIndex !== 0 ? 'NA' : this.xIndex),
            'SubCategory': this.subCategory || 'NA',
            'modelName': this.modelName || 'NA',
            'clickID' : this.show.clickID || 'NA',
            'origin': this.show.origin || 'NA',
            'CarousalCategory': (this.modelName && this.modelName !== 'NA') ? 'Talamoos' : 'Non-Talamoos',
            'TopCategory' : this.videoAnalyticsService.getTopCategory(this.show.asset_subtype),
            'Video_Language' : this.commonService.getVideoLanguages(this.show) || 'NA',
            'Content_ID': this.show.id || 'NA',
            'Show_ID': (this.show.asset_type === 1 ? (this.show.tvshow_details ? this.show.tvshow_details.id : '') : this.show.id) || 'NA',
            'Season_ID': this.show.season_details ? this.show.season_details.id  : 'NA',
            'ShowSubtype': this.show.asset_type === 0 ? this.show.asset_subtype || 'NA' : ((this.show.asset_type === 1 && this.show.tvshow_details) ? this.show.tvshow_details.asset_subtype || 'NA' : 'NA'),
            'Content_Lang': langObj.contentLang,
            'Display_Lang': langObj.displayLang,
            'Business_Type': (this.show.business_type && this.show.business_type.indexOf('premium') !== -1) ? 'Premium' : 'Free' || 'NA',
            'User_Access_Type': userAccessType,
            'G_ID': this.gtm.fetchToken(),
            'Client_ID': this.gtm.fetchClientId(),
            'TimeHHMMSS': this.gtm.fetchCurrentTime(),
            'DateTimeStamp': this.gtm.fetchCurrentDate()
      };
      this.gtm.logEvent(this.thumbnailClickEvent);
    }


      public threeDotEvent(ctadetails) {
        let langObj, availableChannelOriginal;
        langObj = this.gtm.displayContentLan();
        availableChannelOriginal = (this.show.channels && this.show.channels !== (null && undefined) && this.show.channels.length > 0) ? this.show.channels.map(function(elem) {return elem.original_title; }).join(', ') : 'NA';
        return {
        'event': 'buttonClicks',
        'PageName': this.gtm.getPageName(),
        'UserType': this.userToken ? 'loggedin' : 'guest',
        'ContentLang': langObj.contentLang,
        'DisplayLang': langObj.displayLang,
        'NetworkType': '',
        'GoogleID': this.gtm.fetchToken(),
        'cta': ctadetails,
        'VideoName': this.show.original_title ? this.show.original_title : 'NA',
        'VideoCategory': this.show.genres ? this.show.genres.map(function(elem) {return elem.id; }).join(', ') : 'NA',
        'VideoSection': this.videoService.getVideoSection(this.show.asset_type, this.show.asset_subtype) || 'NA',
        'VideoSubTitle': this.show.original_title ? this.show.original_title : 'NA',
        'TVChannels': availableChannelOriginal || 'NA',
        'VideoDuration': this.show.duration || 0,
        'VideoStartTime': this.show.start_time ? this.show.start_time : 'NA' ,
        'Time_Slot': this.show.time_slot || 'NA',
        'Episode_Number': this.show.index ? this.show.index : 'NA',
        'Tumbnail_Image': this.showUrl,
        'Content_Specification': this.videoService.getContentSpec(this.show.asset_subtype) || 'NA',
        'Content_Show': this.show.original_title || this.show.title || 'NA',
        'Content_Date': this.commonService.dateChange(this.show.release_date) || 'NA',
        'Vertical_Index': this.yIndex || (this.yIndex !== 0 ? 'NA' : this.yIndex),
        'Horizontal_Index': this.xIndex || (this.xIndex !== 0 ? 'NA' : this.xIndex),
        'SubCategory': this.subCategory || 'NA',
        'modelName': this.modelName || 'NA',
        'clickID': this.show.clickID || 'NA',
        'Click_Metrics': '1',
        'Carousal_Name': this.subCategory || 'NA'
        };
      }


}
