import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared.module';
import { ScrollGridComponent } from './scroll-grid.component';
import { MdMenuModule, MdButtonModule } from '@angular/material';
import { ShareoptionsModule } from '../share-options/share-options.module';

@NgModule({
  imports: [
    CommonModule, SharedModule, MdMenuModule, MdButtonModule, ShareoptionsModule
  ],
  declarations: [ScrollGridComponent],
  exports: [ScrollGridComponent]
})
export class ScrollGridModule { }
