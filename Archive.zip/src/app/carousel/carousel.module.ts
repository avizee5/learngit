import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CarouselComponent } from './carousel.component';
import { SharedModule } from '../shared.module';
import { CarouselPlayerModule } from '../carousel-player/carousel-player.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    CarouselPlayerModule
  ],
  declarations: [CarouselComponent],
  exports: [CarouselComponent]

})
export class CarouselModule { }



