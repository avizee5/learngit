import { Component, OnInit, Input, Output, EventEmitter , OnDestroy, HostListener, ElementRef, ViewChild } from '@angular/core';
// import { Component, OnInit, Input, Output, EventEmitter , OnDestroy, HostListener, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import * as $ from 'jquery';
import { HeaderservicesService } from '../services/headerservices.service';
import { Subscription } from 'rxjs/Subscription';
import { SettingsService } from '../services/settings.service';
import { Http} from '@angular/http';
// import {MovieApi} from '../../data/gwapi_catalog/api/MovieApi';
// import {TvShowApi} from '../../data/gwapi_catalog/api/TvShowApi';
// import {EpisodeApi} from '../../data/gwapi_catalog/api/EpisodeApi';
import { Location } from '@angular/common';
import { environment } from '../../environments/environment';
import { UserProfileService } from '../services/user-profile.service';
import { Router } from '@angular/router';
import {  NetworkService  } from '../services/network.service';
import { VideoService } from '../services/video.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { SubscriptionService } from '../services/subscription.service';
import {CommonService} from '../services/common.service';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import {EpgApi} from '../../data/catalog/api/EpgApi';
import {ChannelApi} from '../../data/catalog/api/ChannelApi';
import { RouteService } from '../services/route.service';
import { VideoAnalyticsService } from './../services/video-analytics.service';

import 'rxjs/add/operator/timeout';
import 'rxjs/add/operator/takeUntil';
import { Subject } from 'rxjs/Subject';

declare var googletag;
const autoplay_api_timeout = 1200;
const autoplay_playback_timeout = 1200;

@Component({
  selector :  'app-carousel',
  templateUrl :  './carousel.component.html',
  styleUrls :  ['./carousel.component.less']
})
export class CarouselComponent implements OnInit , OnDestroy  {
// export class CarouselComponent implements OnInit , OnDestroy, AfterViewInit  {
  @ViewChild('middlecontent') public elementView: ElementRef;
  @Input() public carousel: any;
  @Input() public carouselTitle: any;
  @Input() public collectionTags: any;
  @Input() public collectionId: any = '';


  public localStorage: any;
  public token: any;
  public notAvailable: any = 'NA';
  public audioLangsString: any = '';
  public carousalBannerClick: any = '';
  public current: any;
  public selected: any;
  public currentIndex: number;
  public checkSrc: Array<string>;
  public checkSrcMobile: Array<string>;
  public check: any;
  public uncheck: any;
  public checkMobile: any;
  public uncheckMobile: any;
  public prevSelect: any;
  public timer: any;
  public loading: any;
  public scope: any;
  public limit: number;
  public image_url: any;
  public SWIPE_ACTION = { LEFT: 'swipeleft', RIGHT: 'swiperight' };
  public count = 0;
  public previous_image: any;
  public next_image: any;
  public current_image: any;
  public current_index: any = 0;
  public nextFlag: any = true;
  public previousFlag: any = true;
  public changeFlag: any = true;
  public image_src: any;
  public basepath: any;
  public carouselSlot: any;
  public seasonApi: any;
  public data: any;
  public tvshowData: any;
  public genres: any;
  public channels: any;
  public premium: any;
  public catchUpFlag: any = 'N';
  public subscription: any;
  public enable: any;
  public subtitle: any;
  public mobileEnable: any;
  public tvshow: any;
  public enableCarousel: any = false;
  public stop = false;
  public welcome: any;
  public months: any = ['Jan', 'Feb', 'Mar',
  'Apr', 'May', 'Jun', 'Jul',
  'Aug', 'Sep', 'Oct',
  'Nov', 'Dec'
  ];
  // public adTag: any;
  public config: any;
  public carouselSlotMobile: any;
  public carouselSlotDesktop: any;
  public googletagAvailable: any;
  // public rgb: any;
  public blockSize: any;
  // public defaultRGB: any;
  public canvas: any;
  public context: any;
  public height: any;
  public width: any;
  public dataImage: any;
  public length: any;
  public total: any;
  public color: any;
  public basepathnew: any;
  public carouselTimer: any;
  public bannerError: any;
  public adPosition: any;
  public localstorage: any;
  public window: any;
  public document: any;
  public navigator: any;
  // public browserTimer: any;
  // public error: any;
  // public mobileTag: any;
  // public desktopTag: any;
  public changeDisable: any = true;
  // public enableAd: any = true;
  public countryCode: any;
  public descriptionSet = false;
  // public divIdDesktop = 'div-gpt-ad-1512639061571-0';
  // public divIdMobile = 'div-gpt-ad-1515497654074-0';
  // public divId: any;
  public configData: any;
  public mobile: any = false;
  public plans: any;
  public premiumUser: any = false;
  // public showMastAds: any = false;
  public carouselLoader: any = false;
  // public imagesrc: any;
  public premiumimagesrc: any;
  public isNewsPage = false;
  public mobileDots = false;
  public autoPlayDivHeight = 0;
  public autoPlayDivWidth = 0;
  public gradientW = 0;
   public currentTag: any;

 private ngUnsubscribe = new Subject<any>();
 public enableVideoPlayback: any = false;
 public showPlayer: any = false; // player
 public autoPlay: any = false;
 public canShowPlayer: any = false;
 public apiCallbackTimeout: any = false;
 public playerCallbackTimeout: any = false;
 private apiSubscribed: any;

 private yIndex: any = 0;
 public  carouselBannerVideoView: any;
 public gaFirstAPIAudioLang: any;

  constructor (private videoService: VideoService,
    private routeservice: RouteService,
    private router_link: Router,
    @Inject(PLATFORM_ID) private platformId: Object,
    private commonService: CommonService,
    private subscriptionService: SubscriptionService,
    private gtm: GoogleAnalyticsService,
    private networkService: NetworkService,
    private location: Location,
    private userProfileService: UserProfileService,
    private videoAnalyticsService: VideoAnalyticsService,
    private headerservicesService: HeaderservicesService,
    private settingsService: SettingsService,
    private http: Http  ) {}
 //  public ngAfterViewInit(): any {
 //    this.autoPlayDivHeight = this.elementView.nativeElement.offsetHeight;
 //    this.autoPlayDivWidth = this.elementView.nativeElement.offsetHeight * (16 / 9);
 //    this.gradientW = this.elementView.nativeElement.offsetHeight * (1091 / 779);
 // }
  @HostListener('window:resize', ['$event'])
  public fontReScale(event) {
    this.onResize(event);
    if (this.window.innerWidth < 769) {
      this.mobileDots = true;
      this.autoPlayDivHeight = this.elementView.nativeElement.offsetHeight;
      this.autoPlayDivWidth = this.elementView.nativeElement.offsetWidth;
    } else {
      this.autoPlayDivHeight = this.elementView.nativeElement.offsetHeight - 70;
      this.autoPlayDivWidth = this.autoPlayDivHeight * (16 / 9);
      this.gradientW = this.elementView.nativeElement.offsetHeight * (1091 / 779);
      this.mobileDots = false;
    }
  }

  public ngOnInit () {
    this.countryCode = this.settingsService.getCountry();
    this.configData = this.settingsService.getCompleteConfig();
    if (isPlatformBrowser(this.platformId)) {
      this.localstorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
    if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
      this.mobile = true;
    }
    this.plans = this.subscriptionService.checkPlanApiSuccess(false);
    if (this.plans && this.plans.length > 0) {
      this.premiumUser = true;
    }
    this.token = this.localStorage ? this.localStorage.getItem('token') : null;
    this.gtm.storeWindowError();
    // Limiting the carousel length to 7
    if (this.carousel.length > 7) {
      this.carousel = this.carousel.slice(0, 7);
    }

    for (let i = this.carousel.length - 1; i >= 0; i--) {
      let currentTag;
      currentTag = this.commonService.getSubcategory(this.carousel[i].tags, this.carousel[i].asset_type, this.carousel[i].asset_subtype, this.carousel[i].genres, this.carousel[i].content_owner);
      if (currentTag.length <= 1) {
        this.carousel[i].currentTag = currentTag[0] ? currentTag[0] : '';
      } else {
        this.carousel[i].currentTag = currentTag.join(', ');
      }
      this.carousel[i].showPremium = (this.carousel[i].asset_type !== 8 && this.carousel[i].asset_type !== 101 && this.carousel[i].asset_subtype !== 'trailer' && this.carousel[i].business_type && this.carousel[i].business_type.indexOf('premium') !== -1) ? true : false;
      if (this.plans && this.plans.length > 0) {
        let carousel_asset_type;
        carousel_asset_type = this.carousel[i].asset_type.toString();
        if (carousel_asset_type === 10) {
          carousel_asset_type = '9';
        } else if (carousel_asset_type === 1) {
          carousel_asset_type = '6';
        }
        if (this.plans.indexOf(carousel_asset_type) >= 0 && this.subscriptionService.checkAssetLang(carousel_asset_type, this.carousel[i].audio_languages)) {
          this.carousel[i].showPremium = false;
        }
      }
      if (this.carousel[i].title.includes(' ')) {
        this.carousel[i].restrict_lines = true;
      } else {
        this.carousel[i].restrict_lines = false;
      }
    }
    if (this.router_link.url.match(/news/g)) {
      this.isNewsPage = true;
    } else {
      this.isNewsPage = false;
    }
    if (this.window.innerWidth < 769) {
      this.mobileDots = true;
      // this.imagesrc = environment.assetsBasePath + 'assets/common/Play_news.png';
      this.premiumimagesrc = environment.assetsBasePath + 'assets/common/PlayIconPremium.png';
      this.autoPlayDivHeight = this.elementView.nativeElement.offsetHeight;
      this.autoPlayDivWidth = this.elementView.nativeElement.offsetWidth;
    } else {
      this.mobileDots = false;
      // this.imagesrc = environment.assetsBasePath + 'assets/common/PlayIcon.png';
      this.premiumimagesrc = environment.assetsBasePath + 'assets/common/PlayIconPremium.png';
      this.autoPlayDivHeight = this.elementView.nativeElement.offsetHeight - 70;
      this.autoPlayDivWidth = this.autoPlayDivHeight * (16 / 9);
      this.gradientW = this.elementView.nativeElement.offsetHeight * (1091 / 779);
    }
    // Carousel auto play
    this.autoPlay = false; // added this to disable carousel playback - to be enabled when kaltura changes are completed
    // this.autoPlay = this.collectionTags ? this.collectionTags.includes('collection_play') : false;
    // Carousel auto play

    // // Fetch Ad from Api
    // this.browserTimer = 0;

    // if (this.navigator.userAgent.indexOf('Firefox') !== -1) {
    //   this.browserTimer = 3000;
    // }
    // this.loadAd();
    let scope;
    scope = this;
    // this.imagesrc = environment.assetsBasePath + 'assets/common/PlayIcon.png';
    scope.uncheckMobile =  environment.assetsBasePath + 'assets/common/ellipse_mobile_normal.png';
    scope.checkMobile =  environment.assetsBasePath + 'assets/common/ellipse_mobile_selected.png';
    scope.uncheck =  environment.assetsBasePath + 'assets/common/ellipse_normal.png';
    scope.check =  environment.assetsBasePath + 'assets/common/ellipse_selected.png';

    scope.enableCarousel = false;

// Stop Carousel on welcome screen popup

// stop carousel on other popups
 this.headerservicesService.modelValue.subscribe(value => {      // when moreview is open and clicked outside update varible
   this.stop = value;
   if (this.stop === true) {
     setTimeout(function() {
       scope.stopCarousel();
     }, 0);
   }
 });

  // Set flag for small screensnsns
  if (this.window.innerWidth < 480) {
    this.mobileEnable = true;
  } else {
    this.mobileEnable = false;
  }
  this.config = {
    apiKey: ' ',
    username: ' ',
    password: ' ',
    accessToken: ' ',
    withCredentials: false
  };
  // this.googletagAvailable = this.localstorage.getItem('googletag')
    this.googletagAvailable = this.commonService.checkGoogleTag();
  this.basepath = this.settingsService.getbasePath();
  this.basepathnew = this.settingsService.getbasePathNew();
  let self;
  self = this;
  let index;
  // Initialising images
  for ( index = 0; index < this.carousel.length; index++) {
    if (this.carousel[index].asset_type === 101) {
      this.carousel[index].image_url = this.basepath + this.carousel[index].id + '/cover/' + '1920x770/' + this.carousel[index].cover_image + '?imwidth=1920&impolicy=akamai_vidz1_zee5_com-IPM';
      this.carousel[index].image_url_mobile = this.basepath + this.carousel[index].id + '/appcover/' + '1440x810/' + this.carousel[index].appcover_image + '?imwidth=480&impolicy=akamai_vidz_zee5_com-IPM';
    } else {
        if (this.carousel[index].list_image && this.carousel[index].asset_type === 8) {
        this.genhrefurl(this.carousel[index])
        this.carousel[index].image_url = this.basepath + this.carousel[index].id + '/list/' + '1920x770/' + this.carousel[index].list_image;
        this.carousel[index].image_url_mobile = this.basepath + this.carousel[index].id + '/list/' + '1440x810/' + this.carousel[index].list_image;
      } else if (this.carousel[index].list_image && this.carousel[index].asset_type !== 8) {
        this.genhrefurl(this.carousel[index])
        this.carousel[index].image_url = this.basepathnew + this.carousel[index].id + '/list/' + '1920x770/' + this.carousel[index].list_image + '?imwidth=1920&impolicy=akamai_vidz1_zee5_com-IPM';
        this.carousel[index].image_url_mobile = this.basepathnew + this.carousel[index].id + '/list/' + '1440x810/' + this.carousel[index].list_image + '?imwidth=480&impolicy=akamai_vidz1_zee5_com-IPM';
      } else if (this.carousel[index].list_image && this.carousel[index].asset_type === 101) {
        this.carousel[index].image_url = this.basepathnew + this.carousel[index].id + '/list/' + '1920x770/' + this.carousel[index].list_image + '?imwidth=1920&impolicy=akamai_vidz1_zee5_com-IPM';
        this.carousel[index].image_url_mobile = this.basepathnew + this.carousel[index].id + '/list/' + '1440x810/' + this.carousel[index].list_image + '?imwidth=480&impolicy=akamai_vidz1_zee5_com-IPM';
      } else {
        this.genhrefurl(this.carousel[index])
        this.carousel[index].image_url = environment.assetsBasePath + 'assets/default/banner.png';
        this.carousel[index].image_url_mobile = environment.assetsBasePath +  'assets/default/banner_mobile.png';
      }

    }

    // this.carousel[0].image_url = this.basepathnew + '0-101-externall_2140541351' + '/cover/' + '1920x770/' + this.carousel[index].image.cover + '.jpg?imwidth=1920&impolicy=akamai_vidz1_zee5_com-IPM';

  }

  this.limit = 190;
  let index_indicator = 0;
  this.checkSrc = [];
  this.checkSrcMobile = [];

 // Initialise the carousel indicators
 while (index_indicator < this.carousel.length) {
   if (index_indicator === 0) {
     this.checkSrc.push(this.check);
     this.checkSrcMobile.push(this.checkMobile);
   } else {
     this.checkSrc.push(this.uncheck);
     this.checkSrcMobile.push(this.uncheckMobile);
   }
   index_indicator ++;
 }
 // Initalise the first image of carousel
 // this.previous_image = this.carousel[this.modular(this.current_index - 1)]
 this.next_image = this.carousel[this.modular(this.current_index + 1)];
 this.current_image = this.carousel[this.modular(this.current_index)];
 this.checkForPlayback();
 this.prevSelect = 0;

 scope.startCarousel();
}

public genhrefurl(carouselindex) {
    if(this.localstorage.getItem('token')) {
      if(this.localstorage.getItem('UserDisplayLanguage') !== 'en') {
        carouselindex.slug = this.localstorage.getItem('UserDisplayLanguage') + '/' + carouselindex.slug
      }
    } else {
      if(this.localstorage.getItem('display_language') !== 'en') {
        carouselindex.slug = this.localstorage.getItem('display_language') + '/' + carouselindex.slug
      }
    }
}

// to be called whenever current image changed
public checkForPlayback(): any {
  // console.log('autoplay', this.current_image);
  this.closePlayer(true);

    if (this.autoPlay && this.current_image) {
      if (this.current_image.asset_type === 101 && this.current_image.genres && this.current_image.genres[0] && this.current_image.genres[0].id === 'internal_link') {
        let channel_id;
        channel_id = this.getChannelId(this.current_image.slug);
        if (channel_id && this.configData && this.configData.carousel_auto_play && this.configData.carousel_auto_play.channel_list && this.configData.carousel_auto_play.channel_list.includes(channel_id)) {
          let apiTimeout, playbackTimeout;
          apiTimeout = this.configData.carousel_auto_play.web && this.configData.carousel_auto_play.web.api ? this.configData.carousel_auto_play.web.api : autoplay_api_timeout;
          playbackTimeout = this.configData.carousel_auto_play.web && this.configData.carousel_auto_play.web.playback ? this.configData.carousel_auto_play.web.playback : autoplay_playback_timeout;
          // console.log('time logic - on load', Date.now());
          this.apiCallbackTimeout = setTimeout(() => this.getChannelDetails(channel_id), apiTimeout);
          this.playerCallbackTimeout = setTimeout(() => {
            this.canShowPlayer = true;
          }, playbackTimeout);
        }
      // } else if (this.autoPlay && this.current_image.collection_auto_play_b) { // for VOD
      //   let asset_types;
      //   asset_types = [0, 1, 6];
      //   if (asset_types.includes(this.current_image.asset_type)) {
      //   }
      }
    }

  }

  private getChannelId(slug): any {
    let id, asset_type;
    slug = slug.split('/');
    id = slug[slug.length - 1];
    asset_type = id && id.split('-');
    if (asset_type && asset_type[1] === '9') {
      return id;
    } else {
      return false;
    }
  }

  private getPlayType(tags): any {
    if (tags && tags.length > 0) {
      return tags.indexOf('auto_play_unmute') ? 'auto_play_unmute' : 'auto_play_mute';
    } else {
      return'auto_play_mute';
    }
  }

  private getChannelDetails(id): any {
    // console.log('time logic - API', Date.now());
    let y;
    y = new ChannelApi(this.http, null, null);
    this.apiSubscribed = y.v1ChannelByIdGet(id, undefined, this.countryCode).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(response => {
      // console.log(response);
      this.data = [
      {
      carousel_name: this.carouselTitle ? this.carouselTitle.original_title : '',
      talamoos_data: {
        'modelName': this.notAvailable,
        'clickID': this.notAvailable,
        'origin': this.notAvailable
      },
      play_type: this.getPlayType(this.current_image.tags),
      id: '',
      duration: '',
      subtitles: response.subtitle_languages,
      audio_languages: response.languages,
      stream_url_dash: response.stream_url,
      stream_url_hls: response.stream_url_hls,
      drm: response.is_drm,
      drm_keyid: response.drm_key_id ,
      type: 'live',
      title: this.current_image.title,
      title_en: this.current_image.original_title,
      season_no: '',
      episode_no: '' ,
      episode_name: '',
      episode_name_en: '',
      channel_name: response.original_title,
      channel_id: response.id,
      category: 'Live TV' ,
      content_type: '',
      genre: (response.genres && response.genres !== (null && undefined) && response.genres.length > 0) ? response.genres.map(function(elem) {return elem.id; }).join(',') : '',
      sub_genre: '' ,
      catch_up: 'N' ,
      series_id: '' ,
      rating: '',
      release_date: '',
      business_type: response.business_type,
      description: '',
      image: '',
      elapsed_time: '',
      asset_type: response.asset_type,
      share_url: 'channels/details/' + this.commonService.convertToLowercase(response.original_title) + '/' + response.id,
      sub_category: ''
      }];
      this.enableVideoPlayback = true;
      this.onCarousalBannerClickEvent();
    }, error => {
      this.enableVideoPlayback = false;
    });
  }

  public showplayer(event): any {
    // console.log(event, 'showplayer');
    this.showPlayer = event;
  }

  public closePlayer(event): any {
    // console.log('closeplayer')
    clearTimeout(this.apiCallbackTimeout);
    clearTimeout(this.playerCallbackTimeout);
    if (this.apiSubscribed) {
      this.apiSubscribed.unsubscribe();
    }
    this.data = undefined;
    this.showPlayer = false;
    this.enableVideoPlayback = false;
    this.canShowPlayer = false;
    this.carousalBannerClick = '';
    this.carouselBannerVideoView = '';
  }

  // Fallback image url set when image src error
  public imageError(event: any): void {
    if (event.srcElement) {
      if (this.mobileEnable) {
        event.srcElement.src =  environment.assetsBasePath + 'assets/default/banner_mobile.png';
      } else {
        event.srcElement.src =  environment.assetsBasePath + 'assets/default/banner.png';
      }
    } else {
      if (this.mobileEnable) {
        event.currentTarget.src =  environment.assetsBasePath + 'assets/default/banner_mobile.png';
      } else {
        event.currentTarget.src =  environment.assetsBasePath + 'assets/default/banner.png';
      }
    }
  }
  // Limits the description with ellipses
  public transformDescription(value: any): any {
    let new_string;
    if (value) {
      if (value.length > 200) {
        new_string = value.slice(0, 200) + '..';
      } else {
        new_string = value;
      }
    } else {
      new_string = '';
    }
    return new_string;
  }
  // modify flag on device resize
  public onResize(event: any): void {
    if (this.window.innerWidth < 480) {
      this.mobileEnable = true;
    } else {
      this.mobileEnable = false;
    }
    if (this.window.innerWidth < 769) {
      // this.imagesrc = environment.assetsBasePath + 'assets/common/Play_news.png';
      this.premiumimagesrc = environment.assetsBasePath + 'assets/common/PlayIconPremium.png';
    } else {
      // this.imagesrc = environment.assetsBasePath + 'assets/common/PlayIcon.png';
      this.premiumimagesrc = environment.assetsBasePath + 'assets/common/PlayIconPremium.png';
    }
  }
  // Carousel timer
  public timerFunction = function() {
    let scope;
    scope = this;
    this.timer = setInterval(function() {
      scope.next();
    }, 5000);
  };
  // Changes image on swipe of carousel banner image
  public swipe(event: any) {
    if (event.type === 'swipeleft') {
      this.next();
    } else if (event.type === 'swiperight') {
      this.previous();
    }
  }

  // Navigate to specific carousel banner image on click of selector
  public changeCarousel(index: any) {
    let scope;
    scope = this;
    // if (this.error) {
    //   setTimeout(function() {
    //     if (scope.adPosition === 1 && scope.carousel[0].type === 'ad') {
    //       scope.carousel.splice(0, 1);
    //       // scope.checkSrc[scope.current_index] = scope.uncheck;
    //       // scope.current_index = 0;
    //       // scope.checkSrc[scope.current_index] = scope.check;
    //       // scope.current_index = this.modular(scope.current_index)
    //       scope.error = false;
    //       scope.changeFlag = false;
    //     }
    //   }, 0);
    // }
    if (this.nextFlag === false && this.previousFlag === false && this.changeFlag === false) {
      this.changeFlag = true;
      if (index < this.current_index) {
        scope.checkSrc[scope.current_index] = scope.uncheck;
        scope.checkSrcMobile[scope.current_index] = scope.uncheckMobile;
        this.previous_image = this.carousel[index];
        // scope.stopCarousel()
        $('.slides').animate({
          left: '0%'}, 300 , 'linear', function() {
            scope.current_index = scope.modular(index);
            scope.checkSrc[scope.current_index] = scope.check;
            scope.checkSrcMobile[scope.current_index] = scope.checkMobile;
            scope.previous_image = scope.carousel[scope.modular(scope.current_index - 1)];
            scope.next_image = scope.carousel[scope.modular(scope.current_index + 1)];
            scope.current_image = scope.carousel[scope.modular(scope.current_index)];
            scope.checkForPlayback();
            setTimeout(() => {
              $('.slides').css({left: '-100%'});
            }, 0);
            // scope.startCarousel()
            scope.changeFlag = false;
          }
          );
        this.carousalSwipeDetails('right');
      } else if (index > this.current_index) {
        scope.checkSrc[scope.current_index] = scope.uncheck;
        scope.checkSrcMobile[scope.current_index] = scope.uncheckMobile;
        this.next_image = this.carousel[index];
        // scope.stopCarousel()
        $('.slides').animate({
          left: '-200%'}, 300 , 'linear', function() {
            scope.current_index = scope.modular(index);
            scope.checkSrc[scope.current_index] = scope.check;
            scope.checkSrcMobile[scope.current_index] = scope.checkMobile;
            scope.previous_image = scope.carousel[scope.modular(scope.current_index - 1)];
            scope.next_image = scope.carousel[scope.modular(scope.current_index + 1)];
            scope.current_image = scope.carousel[scope.modular(scope.current_index)];
            scope.checkForPlayback();
            setTimeout(() => {
              $('.slides').css({left: '-100%'});
            }, 0);
            scope.changeFlag = false;
            // scope.startCarousel()
          }
          );
        this.carousalSwipeDetails('left');
      } else {
        scope.changeFlag = false;
      }
    }
  }

  public modular(index: number): number {
    if (index < 0) {
      return (index + this.carousel.length);
    } else if (index > this.carousel.length - 1 ) {
      return (index % this.carousel.length);
    } else {
      return index;
    }
  }
  // Displays next carousel banner
  public next(): void {
    this.carousalSwipeDetails('left');
    let scope;
    scope = this;
    // if (this.error === true) {
    //   setTimeout(function() {
    //     if (scope.adPosition === 1 && scope.carousel[0].type === 'ad') {
    //       scope.carousel.splice(0, 1);
    //       scope.checkSrc[scope.current_index] = scope.uncheck;
    //       scope.checkSrcMobile[scope.current_index] = scope.uncheckMobile;
    //       scope.current_index = 0;
    //       scope.checkSrc[scope.current_index] = scope.check;
    //       scope.checkSrcMobile[scope.current_index] = scope.checkMobile;
    //       // scope.current_index = this.modular(scope.current_index)
    //       scope.error = false;
    //     }
    //   }, 0);
    // }
    if (this.nextFlag === false && this.changeFlag === false && this.previousFlag === false) {
      this.nextFlag = true;
      scope.checkSrc[scope.current_index] = scope.uncheck;
      scope.checkSrcMobile[scope.current_index] = scope.uncheckMobile;
      this.current_index++;
      this.current_index = this.modular(scope.current_index);
      // scope.stopCarousel()
      $('.slides').animate({
        left: '-200%'}, 300 , 'linear',
        function() {
          setTimeout(() => {
            $('.slides').css({left: '-100%'});
          }, 0);
          scope.checkSrc[scope.current_index] = scope.check;
          scope.checkSrcMobile[scope.current_index] = scope.checkMobile;
          scope.previous_image = scope.carousel[scope.modular(scope.current_index - 1)];
          scope.next_image = scope.carousel[scope.modular(scope.current_index + 1)];
          scope.current_image = scope.carousel[scope.modular(scope.current_index)];
          scope.checkForPlayback();
          scope.nextFlag = false;
          // scope.startCarousel()
        }
        );
    }
  }
   // Displays previous carousel banner
   public previous() {
     this.carousalSwipeDetails('right');
     let scope;
     scope = this;
     // if (this.error === true) {
     //   setTimeout(function() {
     //     if (scope.adPosition === 1 && scope.carousel[0].type === 'ad') {
     //       scope.carousel.splice(0, 1);
     //       scope.checkSrc[scope.current_index] = scope.uncheck;
     //       scope.checkSrcMobile[scope.current_index] = scope.uncheckMobile;
     //       scope.current_index = 0;
     //       scope.checkSrc[scope.current_index] = scope.check;
     //       scope.checkSrcMobile[scope.current_index] = scope.checkMobile;
     //       // scope.current_index = this.modular(scope.current_index)
     //       scope.error = false;
     //       // scope.changeFlag = false;
     //     }
     //   }, 0);
     // }
     if (this.previousFlag === false && this.changeFlag === false && this.nextFlag === false) {
       this.previousFlag = true;
       scope.checkSrc[scope.current_index] = scope.uncheck;
       scope.checkSrcMobile[scope.current_index] = scope.uncheckMobile;
       this.current_index--;
       this.current_index = this.modular(scope.current_index);
            // scope.stopCarousel()
            $('.slides').animate({
              left: '0%'}, 300 , 'linear', function() {
                scope.checkSrc[scope.current_index] = scope.check;
                scope.checkSrcMobile[scope.current_index] = scope.checkMobile;
                scope.previous_image = scope.carousel[scope.modular(scope.current_index - 1)];
                scope.next_image = scope.carousel[scope.modular(scope.current_index + 1)];
                scope.current_image = scope.carousel[scope.modular(scope.current_index)];
                scope.checkForPlayback();
                setTimeout(() => {
                  $('.slides').css({left: '-100%'});
                }, 0);
                scope.previousFlag = false;
                // scope.startCarousel()
              }
              );
          }
        }
        // Opens video pop up
        public startVideo(current: any): void {
          let scope, tempTitle;
          scope = this;
          this.videoService.autoPlayed('');
          this.commonService.updateCollectionId(this.collectionId);
          this.commonService.setTalamoosData('', '', ''); 
          this.gtm.GAsubCategory = this.carouselTitle ? this.carouselTitle.original_title : '';
          this.gtm.setContentClickDetails(this.current_index, this.yIndex, this.gtm.GAsubCategory);
            let data;
            data = this.showPlayer ? this.carousalBannerClick : this.carouselBannerVideoView;
          if (current.asset_type === 101) {      
             this.commonService.assetCheck(current, this.router_link, this.current_image.image_url, 'carousalBannerClick', data);
          } else {
             this.commonService.assetCheck(current, this.router_link, this.current_image.image_url, 'carousalBannerClick', data);
          // if (current.extended && current.extended.seo_title) {
          //   tempTitle = (current.extended.seo_title !== null || current.extended.seo_title !== undefined || current.extended.seo_title !== '') ? current.extended.seo_title : current.original_title;
          // } else {
          //   tempTitle = (current.seo_title && (current.seo_title !== null || current.seo_title !== undefined || current.seo_title !== '')) ? current.seo_title : current.original_title;
          // }
            tempTitle = current.original_title;
          if (current.asset_type === 0) {
            this.gtm.GAsubCategory = this.carouselTitle ? this.carouselTitle.original_title : '';
            this.gtm.setContentClickDetails(this.current_index, this.yIndex, this.gtm.GAsubCategory);
            this.router_link.navigate([(current.asset_subtype === 'movie' ? 'movies' : ((current.asset_subtype === 'video' && current.genres.findIndex(i => i.id === 'News') !== -1) ? 'news' : 'videos')) + '/details/' , this.commonService.convertToLowercase(tempTitle) , current.id ]);
            // this.router_link.navigate([(current.asset_subtype === 'movie' ? 'movies' : 'videos') + '/details/' , this.commonService.convertToLowercase(tempTitle) , current.id ]);
          } else if (current.asset_type === 8) {
            this.router_link.navigate(['/collections', this.commonService.convertToLowercase(tempTitle), current.id ]);
          } else if (current.asset_type === 6) {
            this.gtm.GAsubCategory = this.carouselTitle ? this.carouselTitle.original_title : '';
            this.gtm.setContentClickDetails(this.current_index, this.yIndex, this.gtm.GAsubCategory);
            this.router_link.navigate([(current.asset_subtype === 'original' ? 'zee5originals' : 'tvshows') + '/details/' , this.commonService.convertToLowercase(tempTitle), current.id, 'latest'  ]);
          } else if (current.asset_type === 9) {
            this.gtm.GAsubCategory = this.carouselTitle ? this.carouselTitle.original_title : '';
            this.gtm.setContentClickDetails(this.current_index, this.yIndex, this.gtm.GAsubCategory);
            this.router_link.navigate([ 'channels/details/', this.commonService.convertToLowercase(current.channel_original_title), current.id ]);
          } else if (current.asset_type === 1) {
          // } else if (current.asset_type === 1  && current.video && current.tvshow ) {
            this.gtm.GAsubCategory = this.carouselTitle ? this.carouselTitle.original_title : '';
            this.gtm.setContentClickDetails(this.current_index, this.yIndex, this.gtm.GAsubCategory);
            let tvShowTempTitle;
            // if (current.tvshow && current.tvshow.extended && current.tvshow.extended.seo_title) {
            //   tvShowTempTitle = (current.tvshow.extended.seo_title !== null || current.tvshow.extended.seo_title !== undefined || current.tvshow.extended.seo_title !== '') ? current.tvshow.extended.seo_title : current.tvshow.original_title;
            // } else if (current.tvshow) {
            //   tvShowTempTitle =  (current.tvshow.seo_title && (current.tvshow.seo_title !== null || current.tvshow.seo_title !== undefined || current.tvshow.seo_title !== '')) ? current.tvshow.seo_title : current.tvshow.original_title;
            if (current.tvshow) {
              tvShowTempTitle = current.tvshow.original_title;
            } else {
              current.tvshow = {};
              current.tvshow.id = '0-6-0';
              tvShowTempTitle =  'title';
            }
            this.router_link.navigate([(current.tvshow.asset_subtype === 'original' ? 'zee5originals' : 'tvshows') + '/details/' , this.commonService.convertToLowercase(tvShowTempTitle) , current.tvshow.id, this.commonService.convertToLowercase(tempTitle) , current.id ]);
          } else {
            this.commonService.updateCollectionId(null);
            this.commonService.videoError();
          }
          }
        }

        public startVideoPremium(current: any) {
            let scope;
            scope = this;
          if (current.showPremium) {
            /*let displayEvent;
            displayEvent = {
              'event': 'inAppClicks',
              'pageName': this.gtm.getPageName(),
              'buttonName': 'Subscribe Now',
              'Content Bucket': 'Banner Card',
              'contentID': current.id
            };
            this.gtm.logEvent(displayEvent);*/
            // this.router_link.navigate(['/myaccount/subscription']);
            this.headerservicesService.MygpSubscriptionroute();
            this.subscriptionService.storeRedirectSubscribe(true);
          } else {
            this.startVideo(current);
          }
          this.sendSubscribeNowClickGA(current);
        }

        public routeFunction(element: any) {
          if (element.type !== 'ad' && this.networkService.getPopupStatus()) {
            this.carouselClickVideoViewEvents(element);
            this.startVideo(element);
            this.onCarousalBannerClickEvent();
          }
        }
        // stops carousel timer
        public stopCarousel(): void {
          // if (this.enableCarousel === true) {
          if (this.enableCarousel === true && !this.autoPlay) {
            clearInterval(this.timer);
            this.enableCarousel = false;
          }
        }
        public updateTime(s: number): any {
              // convert seconds to hrs and minutes
              let secs, mins, hrs, hrsStr, mins_new, time;
              secs = s % 60;
              s = (s - secs) / 60;
              mins = s % 60;
              s = (s - mins) / 60;
              hrs = s % 60;
              hrsStr = hrs ? ((hrs < 10 ? '0' + hrs : hrs) + ':') : '';
              if (mins < 10) {
                mins_new = '0' + mins;
              } else {
                mins_new = '' + mins;
              }
              time = (hrs ? hrs + 'h' : '') + ' ' + (mins ? mins_new + 'm' : '') + ' ' + (secs ? secs + 's' : '');
              return time;
            }
        // starts carousel timer
        public startCarousel(): void {
          if (this.carousel.length > 1) {
            this.changeFlag = false;
            this.nextFlag = false;
            this.previousFlag = false;
            if (this.enableCarousel === false && !this.autoPlay) {
              this.timerFunction();
              this.enableCarousel = true;
            }
          }
        }
        // Called on destroy of component
        public ngOnDestroy () {
          this.stopCarousel();
          // this.googletagAvailable = this.localstorage.getItem('googletag')
          this.googletagAvailable = this.commonService.checkGoogleTag();
          if (this.googletagAvailable === 'true' && googletag.destroySlots) {
            googletag.destroySlots();
            clearTimeout(this.bannerError);
            clearTimeout(this.carouselTimer);
          }
          this.closePlayer(true);
          this.ngUnsubscribe.next();
          this.ngUnsubscribe.complete();
        }
        // stops carousel on hovering
        public onHover(): void {
          this.stopCarousel();
        }
        // stops carousel on hovering stop
        public noHover(): void {
          this.startCarousel();
        }
        public getAudioLanguages(): any {
          if ((!this.configData) && (!this.data[0].audio_languages || !this.data[0].audio_languages.length)) {
            return;
          }
          let language, gaAudioLanguages, counter;
          counter = 0;
          gaAudioLanguages = '';
          for (let i = 0; i < this.data[0].audio_languages.length; i++) {
            language = this.configData.languages.findIndex(index => index.id === this.data[0].audio_languages[i]);
            if (language !== -1) {
              gaAudioLanguages += (i !== 0 ? ',' : '') + this.configData.languages[language].name;
            } else {
              gaAudioLanguages += (i !== 0 ? ',' : '') + 'Audio Language ' + (++counter);
            }
          }
          this.audioLangsString = gaAudioLanguages;
          return this.audioLangsString;
        }

        public onCarousalBannerClickEvent(): any {
          if (this.data && this.data[0]) {
          let image;
          image = this.settingsService.getbasePath() + this.data[0].id + '/list/' + '270x152/' + this.data[0].image;
          let  userAccessType;
          userAccessType = this.commonService.getUserAccessType();
          this.carousalBannerClick = {
            'carousIndex': this.current_index,
            'Vertical_Index': 0,
            'Horizontal_Index': this.current_index,
            'Click_Metrics': '1',
            'Carousal_Name': this.carouselTitle ? this.carouselTitle.original_title : this.notAvailable,
            'Scrub_Position': this.notAvailable,
            'Business_Type': this.data[0].business_type.indexOf('premium') !== -1 ? 'Premium' : 'Free',
            'User_Access_Type': userAccessType,
            'TopCategory': this.videoAnalyticsService.getTopCategory(this.data[0].category),
            'Video_Language': this.getAudioLanguages() || this.notAvailable,
            'Content_ID': this.data[0].id || this.notAvailable,
            'Show_ID': (this.data[0].asset_type === 1 ? this.data[0].series_id : this.data[0].id) || this.notAvailable,
            'Season_ID': this.data[0].season_id || this.notAvailable,
            'ShowSubtype': this.videoService.getShowSubtype(this.data[0].asset_type, this.data[0].category, this.data[0].content_type) || this.notAvailable,
            'BroadcastState': (this.data[0].asset_type === 1 ? this.data[0].broadcastState : this.notAvailable) || this.notAvailable,
            'SubCategory': this.carouselTitle ? this.carouselTitle.original_title : this.notAvailable,
            'G_ID': this.gtm.fetchToken(),
            'Client_ID': this.gtm.fetchClientId(),
            'TimeHHMMSS': this.gtm.fetchCurrentTime(),
            'DateTimeStamp': this.gtm.fetchCurrentDate(),
            'retargeting_remarketing' : this.gtm.fetchMarketing()
          };
        }
      }
      // send swipes on  Carousal
      public carousalSwipeDetails(direction) {
        let swipeDetails;
        swipeDetails = {
          'event': 'swipeClick',
          'SwipeType': 'banner',
          'SwipeDirection': direction
        };
        this.gtm.sendEventDetails(swipeDetails);
      }
      // send subscribe now click details
      public sendSubscribeNowClickGA(details) {
        // console.log(details);
        let subscribeNowClick, talamoosData;
        talamoosData = this.commonService.getTalamoosData();
        subscribeNowClick = {
          'event': 'subscribeNowClick',
          'VideoName':  details.original_title ? details.original_title : 'NA',
          'VideoCategory':  details.genres  ? details.genres.map(function(elem) { return elem.id; }).join(', ') : 'NA',
          'VideoSection': this.videoService.getVideoSection(details.asset_type, details.asset_subtype),
          'VideoSubTitle': details.original_title ? details.original_title : 'NA',
          'TVChannels': 'NA',
          'VideoDuration': details.duration ? details.duration : 'NA',
          'PageName': this.gtm.getPageName() ? this.gtm.getPageName() : 'NA',
          'VideoStartTime': 'NA',
          'Time_Slot': 'NA',
          'Episode_Number': 'NA',
          'Thumbnail_Image': this.mobileEnable ? this.current_image.image_url_mobile : this.current_image.image_url,
          'Content_Specification': this.videoService.getContentSpec(details.asset_subtype),
          'Content_Show': details.description,
          'Content_Date': details.release_date,
          'carousIndex': this.current_index,
          'Vertical_Index': 0,
          'Horizontal_Index': this.current_index,
          'SubCategory': this.carouselTitle ? this.carouselTitle.original_title : this.notAvailable,
          'modelName': 'NA',
          'cta': 'subscribe now'
        };
        this.gtm.sendEventDetails(subscribeNowClick);
      }
      public carouselClickVideoViewEvents(element) {
        let langObj, userAccessType;
         langObj = this.gtm.displayContentLan();
         userAccessType = this.commonService.getUserAccessType();
         this.carouselBannerVideoView = {
        'carousIndex': this.current_index,
        'SubCategory': this.carouselTitle ? this.carouselTitle.original_title : 'NA',
        'TopCategory' : this.videoAnalyticsService.getTopCategory(element.asset_subtype),
        'Video_Language' : this.commonService.getVideoLanguages(element) || this.notAvailable,
        'Content_ID': element.id || this.notAvailable,
        'Show_ID': (element.asset_type === 1 ? (element.tvshow_details ? element.tvshow_details.id : '') : element.id) || this.notAvailable,
        'Season_ID': element.season_details ? element.season_details.id : this.notAvailable,
        // 'ShowSubtype': this.videoService.ShowSubType(element.asset_type, element.tvshow_details.asset_subtype, element.asset_subtype) || this.notAvailable,
        'ShowSubtype': element.asset_type === 0 ? element.asset_subtype || 'NA' : ((element.asset_type === 1 && element.tvshow_details) ? element.tvshow_details.asset_subtype || 'NA' : 'NA'),
        'Content_Lang': langObj.contentLang,
        'Display_Lang': langObj.displayLang,
        'Business_Type': (element.business_type && element.business_type.indexOf('premium') !== -1) ? 'Premium' : 'Free' || 'NA',
        'User_Access_Type': userAccessType,
        // 'AudLan':  this.getCarouselAudioLanguages(element) || this.notAvailable,
        'G_ID': this.gtm.fetchToken(),
        'Client_ID': this.gtm.fetchClientId(),
        'TimeHHMMSS': this.gtm.fetchCurrentTime(),
        'DateTimeStamp': this.gtm.fetchCurrentDate()
        };
      }
    }

