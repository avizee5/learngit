import { Component, OnInit, Output, EventEmitter, Input, OnChanges, Inject, PLATFORM_ID } from '@angular/core';
import * as $ from 'jquery';
import { FilterService } from '../services/filter.service';
import { environment } from '../../environments/environment';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { isPlatformBrowser } from '@angular/common';

@Component({
  selector: 'app-sort',
  templateUrl: './sort.component.html',
  styleUrls: ['./sort.component.less']
})
export class SortComponent implements OnInit, OnChanges {
  public sortTypes: any;
  private selectedSort: Array<any> = [];
  private IE: boolean;
  private controlRipple: any;
  public enabled: boolean;
  public assetbasepath: any;
  @Input() private sortbar: boolean;
    private window: any;
   private document: any;
   private navigator: any;
  @Output() public changeStatus: EventEmitter<boolean> = new EventEmitter<boolean>();

  constructor(@Inject(PLATFORM_ID) private platformId: Object, private gtm: GoogleAnalyticsService, private filterService: FilterService) {
  if (isPlatformBrowser(this.platformId)) {
    this.window = window;
    this.document = document;
    this.navigator = navigator;
}
}
  public ngOnInit() {
    let scope , index;
    this.enabled = false;
    this.gtm.storeWindowError();
    this.assetbasepath = environment.assetsBasePath;
    index = this.filterService.getSort();
    this.sortTypes = [{'code': '1', 'name': 'COMMON.POPULARITY', 'id': 'Popularity'}, {'code': '2', 'name': 'COMMON.A-Z', 'id': 'A-Z'}];
    this.getValue(this.sortTypes[index].name, index);
    this.IE = false;
    this.getbrowser();
    scope = this;
    $(this.document).mouseup(function(e) {
      this.container = $('.sortContainer');
      // if clicked element is not your element and parents aren't your div
      if (scope.sortbar) {
        if (!this.container.is(e.target) && this.container.has(e.target).length === 0) {
          scope.closeSort();
        }
      }
    });
    $(this.document).on('touchstart', function (e) {
      this.container = $('.sortContainer');
      // if clicked element is not your element and parents aren't your div
      if (scope.sortbar) {
        if (!this.container.is(e.target) && this.container.has(e.target).length === 0) {
          scope.closeSort();
        }
      }
    });
  }
  private getbrowser(): void {
    if (this.navigator.userAgent.indexOf('Trident') !== -1 ) {
      this.IE = true;
    }
  }
  public closeSort(): void {
    this.sortbar = false;
    this.changeStatus.emit(this.sortbar);
    this.document.getElementById('body').classList.remove('modalOpen');
    this.mouseLeave();
  }
  private getValue(option, i): void {
    this.selectedSort = [];
    this.selectedSort.push(option);
    setTimeout(() => {
      this.setService(i);
    }, 0);
  }
  private setService(n): void {
    this.filterService.setSort(n);
  }
  private isChecked(name): boolean {
    return this.selectedSort.indexOf(name) > -1;
  }
  public ngOnChanges(changes: any) {
    if (this.sortbar) {
      if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
        this.document.getElementById('body').classList.add('modalOpen');
      }
    }
  }
// if the mouse enters on the div -- browser scroll disable
public mouseEnter() {
  if (this.IE) {
        this.document.getElementById('body').classList.add('overlay-open');
  } else {
    let x, y;
    x = this.window.scrollX;
    y = this.window.scrollY;
    this.window.onscroll = function() {this.window.scrollTo(x, y); };
  }
}
// if the mouse leaves the div -- browser scroll enable
public mouseLeave() {
  if (this.IE) {
        this.document.getElementById('body').classList.remove('overlay-open');
  } else {
        this.window.onscroll = function() {
          // todo
        };
  }
}
public sendSortDetails(buttonName) {
  this.gtm.sendEventDetails({'event': 'sortOptionClick', 'buttonName': buttonName});
}
}
