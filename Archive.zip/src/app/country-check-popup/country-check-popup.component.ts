import { Component, OnInit, OnDestroy, Input, HostListener } from '@angular/core';
import { SubscriptionService } from '../services/subscription.service';
import { SettingsService } from '../services/settings.service';
import { environment } from '../../environments/environment';
import * as $ from 'jquery';
import { Http } from '@angular/http';
import * as SettingsApi from '../../data/user/api/api';
import { Router} from '@angular/router';
import { TranslateService} from '@ngx-translate/core';
import { EpgService } from '../services/epg.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { HeaderservicesService } from '../services/headerservices.service';
import {CurrencyPipe} from '@angular/common';
/* Angular Universal */
import { isPlatformBrowser } from '@angular/common';
import { Inject, PLATFORM_ID } from '@angular/core';
import { Subject } from 'rxjs/Subject';

@Component({
  selector: 'app-country-check-popup',
  templateUrl: './country-check-popup.component.html',
  styleUrls: ['./country-check-popup.component.less'],
  // providers: [ ShiftPosition ]
})
export class CountryCheckPopupComponent implements OnInit, OnDestroy {
    private ngUnsubscribe = new Subject<any>();
  @Input() public popupName: any;
  @Input() private gdprCheck: any;
  @Input () private country: any;
  @Input() private paytmIndex: any;
  @Input() public countryListCCode: any;
// private Error_message_Login: any;
  public receivedValue: any;
	private close: any;
	private basepath: any;
	public popUpVisible: any = false;
	private visitedCountries: any = [];
	private loginToken: any;
	private showSubPopUp: any;
  private subscriptionSuccess: any;
	private localStorage: any;
  public showPopUp = false;
  private countrycode: any;
  private token: any;
  private config: any;
  private gdprValue: any;
  private userSettings: any;
  private localstorage: any;
private window: any;
private document: any;
private navigator: any;
public lessValue = false;
public fontWidth = false;
private paytmPack: any;
  private paytmPrice: any;
private paytmDate: any;
private parReceived: any;
private months: any; // array to check month number and string
private textReceived: any;
public datePriceTxt: any;
private today: any;
private countryCode: any;
private configValue: any;
private currencyCode: any;
private notTodestroy = false;
  constructor (private cp: CurrencyPipe, private headerservicesService: HeaderservicesService, private route: Router, private http: Http, @Inject(PLATFORM_ID) private platformId: Object, private gtm: GoogleAnalyticsService, private epgService: EpgService, private subscriptionService: SubscriptionService, private settingsService: SettingsService, private translate: TranslateService) {
  // check my plan flag
    this.subscriptionService.planApiSuccess.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.showSubPopUp = value;
      if (this.showSubPopUp !== undefined && this.subscriptionSuccess === undefined && this.popupName !== 'country') {
         this.ngOnInit();
      }
    });
     this.headerservicesService.contentLanguageValue.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.notTodestroy = value.boolean;
      });
  }

  public ngOnInit() {
  if (isPlatformBrowser(this.platformId)) {
   this.localstorage = localStorage;
   this.window = window;
   this.document = document;
   this.navigator = navigator;
  }
  let tracker;
  tracker = this.headerservicesService.getcontentLanguageChanges();
  this.notTodestroy = tracker && tracker.boolean ? tracker.boolean : false; // not to remove scroll whn contentlangpopup thr
  this.months = ['Jan' , 'Feb' , 'Mar' , 'Apr' , 'May' , 'Jun' , 'Jul' , 'Aug' , 'Sep' , 'Oct' , 'Nov' , 'Dec'];
  this.countryCode = this.settingsService.getCountry();
  this.configValue = this.settingsService.getCompleteConfig();
    this.popUpVisible = false;
    this.showPopUp = false;
    if (this.popupName === 'traveller') {
    this.loginToken = localStorage.getItem ( 'token' );
    this.showSubPopUp = this.subscriptionService.getPlanApiSucess();
    // if (!this.loginToken) {
    //       return;
    // }
    this.subscriptionSuccess = true;
     if (isPlatformBrowser(this.platformId)) {
  	    this.localStorage = localStorage;
  	 }
     this.basepath = environment.assetsBasePath;
     this.close = this.basepath + 'assets/common/close_ic1.png';
     let countrySubscriptionActive, countryActive;
     countrySubscriptionActive = this.subscriptionService.getActiveCountry();
     countryActive = this.settingsService.getCountry();
     if (this.localStorage.getItem('visitedCountries') !== null) {
    	 	let visited;
    	 	this.visitedCountries = [];
    	 	visited = this.localStorage.getItem('visitedCountries');
        if (visited.length > 0) {
                 this.visitedCountries = visited.split(',');
        }
    	 		if (this.visitedCountries.indexOf(countryActive) < 0 ) {
    	 			// this.visitedCountries.push(countryActive);
    	 			this.showPopup();
    	 		} else {
             this.subscriptionService.paytm(false);
		  if (this.route.url === '/' && this.countryCode === 'CA' && this.configValue && this.configValue.canadaLaunchOffer && !this.showPopUp) {
                    this.headerservicesService.launchOfferChange(true);
                  }
           }
    	 } else {
        	this.visitedCountries = [];
          //  this.visitedCountries.push(countryActive);
           this.setCountry(countryActive);
    	 	   this.showPopup();
       }
       this.closeContainer();
      } else if (this.popupName === 'country') {
        $('#body').addClass('scrolldisbale');
         setTimeout(() => {$('.auto-loader1').css('display', 'block');
        }, 0);
        this.popUpVisible = true;
        this.showPopUp = true;
        this.lessValue = true;   // for adding  class width
        this.countrycode = this.settingsService.getCountry();
        this.token = localStorage.getItem('token');
	      this.componentResize();
        this.fontWidth = true;
        $('#body').addClass('scrolldisbale');
         setTimeout(() => {$('.auto-loader1').css('display', 'none');
        }, 1000);
        this.GdprUpdate();
        // Ashwini
      } else if (this.popupName === 'paytm') {
        this.popUpVisible = true;
        this.showPopUp = true;
        this.paytmPack = this.subscriptionService.getActivePAR();
        if (this.paytmPack) {
          this.paytmPrice = this.paytmPack[this.paytmIndex].price;
          let dateRec;
          dateRec = new Date(this.paytmPack[this.paytmIndex].sub_end);
          this.paytmDate = ('0' + dateRec.getDate()).slice(-2) + ' ' + this.months[dateRec.getMonth()] + ', ' + dateRec.getFullYear();
          this.displayCurrency();
          this.setString();
        }
        this.getServerTime();
      }
  }
  private showPopup(): void {
      let countryActive, countrySubscriptionActive;
  	  countryActive = this.settingsService.getCountry();
  	  countrySubscriptionActive = this.subscriptionService.getActiveCountry();
        // if (countrySubscriptionActive !== undefined && countrySubscriptionActive.indexOf(countryActive) < 0) {
  	  	// if (countrySubscriptionActive !== undefined) {
    	 	// for (let i = 0; i < countrySubscriptionActive.length; i++) {
          // if (countrySubscriptionActive[i] !== countryActive) {
    	 		// for (let j = 0; j < this.visitedCountries.length; j++) {
            // if ( countrySubscriptionActive[i] !== this.visitedCountries[j] ) {
  	  	 		if (!this.visitedCountries || (this.visitedCountries && this.visitedCountries.length <= 0) || (this.visitedCountries && this.visitedCountries.indexOf(countryActive) < 0) ) {
  	    			$('#body').addClass('scrolldisbale');
  		         this.popUpVisible = true;
              setTimeout(() => {
                this.showPopUp = true;
              }, 0);

    	 				// this.setCountry(countryActive);
  		  	 	 }
    	 		// }
         // }
  	  	// }
  	//  }
     if (this.popUpVisible) {
        this.subscriptionService.paytm(true);
     } else {
        this.subscriptionService.paytm(false);
	    setTimeout(() => {
        if (this.route.url === '/' && this.countryCode === 'CA' && this.configValue && this.configValue.canadaLaunchOffer && !this.showPopUp) {
        this.headerservicesService.launchOfferChange(true);
        }
      }, 0);
     }

  }
  private setCountry(countryActive): void {
     let str;
     this.visitedCountries.push(countryActive);
  	 str = this.visitedCountries.join();
  	 this.localStorage.setItem('visitedCountries', str);
  }
  public closeContainer() {
     $('#body').removeClass('scrolldisbale');
     this.popUpVisible = false;
     let countryActive = this.settingsService.getCountry();
     this.setCountry(countryActive);
    //  window.location.href = window.location.origin;
     //this.settingsService.clearRobiToken(); // clear robi token on country change
     this.subscriptionService.paytm(false);
	       if (this.route.url === '/' && this.countryCode === 'CA' && this.configValue && this.configValue.canadaLaunchOffer) {
      this.headerservicesService.launchOfferChange(true);
    }
  }
  /////////////////////////// GDRPR////////////////
  @HostListener('window:resize', ['$event'])
  public componentResize() {
      if (this.window.innerWidth < 800) {
         this.lessValue = true;
          setTimeout(function () {
         $('#gdprOuter').css('top', 0 + 'px');
          }, 1);
      }
  }
  public AcceptEnable() {
  if (!(this.receivedValue.sendFlag)) {
        $('.Accept').css({'background-color': '#50012f', 'color': '#703055'});
        return true;
      } else {
         $('.Accept').css({'background-color': '#bf006b', 'color': '#eeeeee'});
        return false;
    }
}
public GdprUpdate() {
// let policyValues;
//     policyValues = [];
//   for (let i = 0; i < 4; i++) {
//     if (!(this.receivedValue.sendValues[i].status) || this.receivedValue.sendValues[i].status === undefined) {
//      policyValues[i] = 'na';
//  } else if (!(this.receivedValue.sendValues[i].userValue)) {
//      policyValues[i] = 'no';
//  } else if (this.receivedValue.sendValues[i].userValue === true) {
//      policyValues[i] = 'yes';
//  }
// }

 if (this.token) {
        let params;
        params = 'bearer ' + this.token ;
       this.config = {
          apiKey: params,
          username: '',
          password: '',
          accessToken: '',
          withCredentials: false
        };
      if (this.gdprCheck === undefined || this.gdprCheck === false) {
        let gdprValue;
        gdprValue = [{
                'country_code': this.countrycode,
                'gdpr_fields': {
                'policy': 'yes',
                'profiling': 'yes',
                'age': 'yes',
                'subscription': 'yes'
                 }
            }];
         let gdprsettings;
         gdprsettings = {
            'key': 'gdpr_policy',
            'value': JSON.stringify(gdprValue)
         };
        this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
        this.userSettings.v1SettingsPost(gdprsettings).subscribe(responsePost => {
        this.setLocalStorage();
        this.settingsService.gdprTraveller(true);
        $('#body').removeClass('scrolldisbale');
         this.popUpVisible = false;
      },
      err => {
        this.callToast();
      });
     } else {
       this.gdprValue = this.settingsService.getSettingsValue();
       let gdprValue1, gdprsettings;
        gdprValue1 = {
                'country_code': this.countrycode,
                'gdpr_fields': {
                  'policy': 'yes',
                  'profiling': 'yes',
                  'age': 'yes',
                  'subscription': 'yes'
                 }
            };
         this.gdprValue.push(gdprValue1);
         gdprsettings = {
            'key': 'gdpr_policy',
            'value': JSON.stringify(this.gdprValue)
         };
        this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
        this.userSettings.v1SettingsPut(gdprsettings).subscribe(responsePost => {
          this.setLocalStorage();
          this.settingsService.gdprTraveller(true);
          $('#body').removeClass('scrolldisbale');
         this.popUpVisible = false;
      },
      err => {
          this.callToast();
      });
     }
    }
  }
  private setLocalStorage() {
  let token;
  token = this.localstorage.getItem('token');
      if (token === null) {
         this.localstorage.setItem('token', this.token);
      }
}
 public sendData(value) {
      this.receivedValue = value ;
      setTimeout(function () {
        $('.loaderImage').css('display', 'none');
          }, 500);
  }
 public closeGdprContainer() {
      this.localstorage.removeItem('token');
      let login_type;
      login_type = this.localstorage.getItem('login');
      if (login_type === 'Mobile') {
        this.route.navigate(['signin/mobile']);
         $('#body').removeClass('scrolldisbale');
         this.popUpVisible = false;
         this.window.location.reload();
      } else if (login_type === 'Email') {
        this.route.navigate(['signin/email']);
         $('#body').removeClass('scrolldisbale');
         this.popUpVisible = false;
         this.window.location.reload();
      } else {
         this.route.navigate(['signin']);
         $('#body').removeClass('scrolldisbale');
         this.popUpVisible = false;
         this.window.location.reload();
      }
      this.localstorage.removeItem('login');
  }
  private callToast() {
    let p;
    p = this.document.getElementById('snackbarLogin');
    p.className = 'show';
    setTimeout(function() { p.className = p.className.replace('show', ''); }, 5000);
}
///////////////////////////// gdpr//////////////////////////
   public ngOnDestroy(): void {
     this.lessValue = false;
     this.fontWidth = false;
     if (!this.notTodestroy) {
       $('#body').removeClass('scrolldisbale');
     }
     this.ngUnsubscribe.next();
  this.ngUnsubscribe.complete();
  }
  public checkClick(): void {
       this.paytmIndex++;
       if (this.paytmIndex <= (this.paytmPack.length - 1)) {
          this.subscriptionService.shownextpopup(this.paytmIndex);
          this.paytmDate = new Date(this.paytmPack[this.paytmIndex].sub_end);
          this.displayCurrency();
          this.setString();
       } else {
         this.subscriptionService.shownextpopup(-1);
       }
  }

  private displayCurrency(): any {
    // currency code
    if (this.paytmPack[this.paytmIndex].currency === 'SGD') {
       this.paytmPrice = 'SG$' + ' ' + this.paytmPack[this.paytmIndex].price;
    } else {
      this.paytmPack[this.paytmIndex].price = ' ' + this.paytmPack[this.paytmIndex].price;
      this.currencyCode = this.cp.transform(this.paytmPack[this.paytmIndex].price, this.paytmPack[this.paytmIndex].currency, true, '1.0');
      this.paytmPrice = this.currencyCode ;
    }

  }
  public changeFlag(): void {
    this.parReceived = JSON.parse(this.localstorage.getItem('PARPack'));
    for (let k = 0; k < this.parReceived.length; k++) {
        if (this.paytmPack[this.paytmIndex - 1].pack_id === this.parReceived[k].parID) {
            this.parReceived[k].parFlag = 0;
           this.localstorage.setItem('PARPack', JSON.stringify(this.parReceived));
           this.setPayTMconsent(this.paytmPack[this.paytmIndex - 1].pack_id);
      }
    }
  }

  private setPayTMconsent(subscriptionid: any): any {
    let params, token;
    token = localStorage.getItem('token');
    if (token) {
      params = 'bearer ' +  token;
      this.config = {
        apiKey: params,
        username: '',
        password: '',
        accessToken: '',
        withCredentials: false
      };
      this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
      this.userSettings.v1SettingsGet().subscribe( settingValue => {
          let nodeValue;
          nodeValue = [{'subscriptionid': subscriptionid, 'consentdate': this.today}];

        if ( settingValue.length > 0) {
          let index, settingsPack;
          index = settingValue.findIndex(idx => idx.key === 'paytmconsent_v2');
          if (index !== -1) {
            settingsPack = JSON.parse((settingValue[index].value));
           let idValue;
           idValue = settingsPack.findIndex(idx => idx.subscriptionid === subscriptionid);
           if (idValue !== -1) {
             // id matches update node
            /*   settingsPack[idValue] = {'subscriptionid': subscriptionid, 'consentdate': this.today};
                const cookies_settings_update = {
                  'key': 'paytmconsent_v2',
                  'value': JSON.stringify(settingsPack)
                };
                this.userSettings.v1SettingsPut(cookies_settings_update).subscribe(responseput => {
                // todo
              });*/
              
                // id matches append node not update
                settingsPack.push((nodeValue[0]));
                const cookies_settings_add = {
                  'key': 'paytmconsent_v2',
                  'value': JSON.stringify(settingsPack)
                };
                this.userSettings.v1SettingsPut(cookies_settings_add).subscribe(responseput => {
                // todo
              });
            } else {
              // id does not matches
              settingsPack.push((nodeValue[0]));
              const cookies_settings_add = {
                'key': 'paytmconsent_v2',
                'value': JSON.stringify(settingsPack)
              };
              this.userSettings.v1SettingsPut(cookies_settings_add).subscribe(responseput => {
                // todo
            });
            }
          } else {
            // node does not exist
            const cookies_settings = {
              'key': 'paytmconsent_v2',
              'value': JSON.stringify(nodeValue)
            };
            this.userSettings.v1SettingsPost(cookies_settings).subscribe(responsePost => {
              // todo
            });
          }
        }
      }, err => {
        // todo
      });
    }
  }

  private getServerTime(): any {
    let time;
      this.epgService.getcurrentTime(environment.serverTimeUrl).timeout(environment.timeOut).subscribe(value => {
          time = value;
          if (time != null) {
              this.today = time.serverdate;
          } else {
              this.today = new Date();
          }
        }, error => {
           this.today = new Date();
           this.gtm.sendErrorEvent('api', error);
        });
  }

  private setString(): void {
     this.translate.get(['SUSCRIPTION.PAR_LINE2']).subscribe(value => {
      this.textReceived = value['SUSCRIPTION.PAR_LINE2'];
       let added;
       added = this.textReceived.replace(/Rs 99/g,  this.paytmPrice).replace(/16 Jun, 2018/g, this.paytmDate);
      this.datePriceTxt = added;
    });
   }

}
