import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CountryCheckPopupComponent } from './country-check-popup.component';

describe('CountryCheckPopupComponent', () => {
  let component: CountryCheckPopupComponent;
  let fixture: ComponentFixture<CountryCheckPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CountryCheckPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CountryCheckPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
