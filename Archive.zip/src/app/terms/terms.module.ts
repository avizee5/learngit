import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared.module';
import { TermsComponent } from './terms.component';

const routes: Routes = [
    { path: '', component: TermsComponent},

];
@NgModule({
 exports: [RouterModule],
  imports: [RouterModule.forChild(routes), CommonModule, SharedModule],
  declarations: [TermsComponent]
})
export class TermsModule {}
