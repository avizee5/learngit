import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { RouteService } from '../services/route.service';
import { HeaderservicesService } from '../services/headerservices.service';
import {  NetworkService  } from '../services/network.service';
import { FooterService } from '../services/footerdata.service';
import * as $ from 'jquery';
import { LinkService } from '../services/link.service';
import { SettingsService } from '../services/settings.service';
import {DomSanitizer} from '@angular/platform-browser';
import {environment} from '../../environments/environment';
import { Http } from '@angular/http';
import { ActivatedRoute } from '@angular/router';
import * as subscritionplanApi from '../../data/subscription/api/api';
import { Subject } from 'rxjs/Subject';
@Component({
  selector: 'app-terms',
  templateUrl: './terms.component.html',
  styleUrls: ['./terms.component.less']
})
export class TermsComponent implements OnInit, OnDestroy {
  private router: any;
    private router2: any;
    private pageName: any;
    private data: any;
    public contentValue: any;
    private contentValuePara: any;
    private fathersday: boolean;
    private privacy_policy_src: any;
    private country_code: any;
    private termsBreadCrump: any;
    private translation: any;
    private subTncFlag = false;
    private paraValue = false;
    private planapicall: any;
    private ngUnsubscribe = new Subject<any>();
    private packIdRec: any;
  constructor(private route: ActivatedRoute, private http: Http, private sanitizer: DomSanitizer, private settingsService: SettingsService, private linkservice: LinkService, private footerservice: FooterService, private networkService: NetworkService, private routeservice: RouteService, private gtm: GoogleAnalyticsService, private routerLink: Router, private headerservicesService: HeaderservicesService) {
    const scope = this;
    this.router = routerLink;
    this.router2 = window.location.pathname;
    this.headerservicesService.viewChange(this.router2);
    this.routeservice.setRoute(this.router2);
    this.routeservice.setLoginRoute(window.location.pathname);
    let config;
    config = this.settingsService.getCompleteConfig();
    this.fathersday = config ? (config.fathersday ? config.fathersday : false) : false;
  }


  public ngOnInit() {

    this.country_code = this.settingsService.getCountry();
    this.gtm.storeWindowError();

    this.termsBreadCrump = [
        {
          'label': 'BREADCRUMB.HOME',
          'url': '/',
          'enable': true
        },
        {
          'label': 'BREADCRUMB.TERMS',
          'url': '/termsofuse',
          'enable': false
        }
      ];

      let token;
      token = localStorage.getItem('token');
        if (token) {
            this.translation = localStorage.getItem('UserDisplayLanguage');
        } else {
            this.translation = localStorage.getItem('display_language');
        }
      this.headerservicesService.breadCrump(this.termsBreadCrump);
    let network;
    this.linkservice.addTag({ rel: 'canonical', href: window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'termsofuse'  } );    network = this.networkService.getScreenStatus();
    this.pageName = 'terms of use';
    this.gtm.sendPageName(this.pageName);
    this.gtm.sendEvent();
    window.scrollTo(0 , 0);

    // check query param
    this.route.queryParams.subscribe(queryparams => {
      let para;
      para = queryparams ['pack'];
      this.paraValue = (para && para.length > 0) ? (true) : (false);
    if (this.paraValue) {
          this.packIdRec = para;
          this.checkSubPlan();
        } else {
            this.privacy_policy_src = environment.shareUrl + 'zeeaction.php?ccode=' + this.country_code + '&text_type=terms_text' + '&translation=' + this.translation;
            // this.privacy_policy_src = 'https://stage.zee5.com/zeeaction.php?ccode=IN&text_type=terms_text';
            this.footerservice.getFooterdata1(this.privacy_policy_src).subscribe( value => {
              this.contentValue = value._body;
              $('#loaderPage').css('display', 'none');

            });
        }

        });



    $('#loaderPage').css('display', 'none');
  }
   public ngOnDestroy () {
    this.linkservice.removeCanonicalLink();
  }

  private checkSubPlan(): any {
    let packValid, recData, scope, termsData;
    scope = this;
    this.planapicall = new subscritionplanApi.SubscriptionPlanApi(this.http, null, null);
    this.planapicall.v1SubscriptionplanGet(this.country_code).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe( value => {
        recData = value;
        packValid = $.grep(recData, function(e) {
        //  return freePackId.indexOf(e[0].pack_id) >= 0;
        return e.id === scope.packIdRec;
        });
        termsData = packValid[0].terms_and_conditions;
        this.contentValue = (termsData && termsData.length > 0 && termsData !== '') ? (termsData) : '';
     }, err => {
       this.contentValue = '';
     }); // API CALL
  }



}
