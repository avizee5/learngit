import { Component, OnInit, ViewEncapsulation, Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import * as $ from 'jquery';
import { HeaderservicesService } from '../services/headerservices.service';
import { CommonService } from '../services/common.service';
@Component({
  selector: 'app-bread-crumb',
  templateUrl: './bread-crumb.component.html',
  styleUrls: ['./bread-crumb.component.less'],
  encapsulation: ViewEncapsulation.None
})
export class BreadCrumbComponent implements OnInit {
  @Input() public breadcrumb: any;
  @Output() public updateBreadCrump = new EventEmitter<any>();
  public lengthofArray: any;
  public episodeNumber = null;
  public breadcrumbs: {
  label: any;
  url: any;
  enable: any;
  }[] = [];
  constructor(private router: Router, private headerservicesService: HeaderservicesService, private commonService: CommonService) {
    this.headerservicesService.breadcrumpValue.subscribe(value => {     // route
      this.constructBreadCrumb(value);
    });
  }

  public ngOnInit() {
    this.updateBreadCrump.emit(this.breadcrumb);
  }
  private constructBreadCrumb(data) {
    this.breadcrumbs = [];
    let  label1, path1, enable1;
     for (let i = 0 ; i < data.length; i++) {
      this.episodeNumber = null;
        label1 = data[i].label;
        path1 = data[i].url;
        enable1 = data[i].enable;
         this.breadcrumbs.push({
                  label: label1,
                  url: path1,
                  enable: enable1,
                });
        if (data[i].number && data[i].number !== null) {
          this.episodeNumber = data[i].number;
        }
     }
     this.lengthofArray = this.breadcrumbs.length;
  }

  public goTo(url): any {
    this.commonService.updateCollectionId(null);
    this.commonService.setTalamoosData('', '', '');
    this.commonService.clearContentClickDetails();
    this.router.navigate([url]);
  }

  private removeData(event, data) {
    let len =  this.lengthofArray - 1;
    for (; len > data ; len--) {
      $('#hideDiv' + len).hide();
    }
    this.lengthofArray = data + 1;
  }
}
