import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomErrorScreenComponent } from './custom-error-screen.component';

describe('CustomErrorScreenComponent', () => {
  let component: CustomErrorScreenComponent;
  let fixture: ComponentFixture<CustomErrorScreenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomErrorScreenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomErrorScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
