import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared.module';
import { CustomErrorScreenComponent } from './custom-error-screen.component';
import { ScrollListModule } from '../scroll-list/scroll-list.module';

const routes: Routes = [
    { path: '', component: CustomErrorScreenComponent},

];
@NgModule({
 exports: [RouterModule, CustomErrorScreenComponent],
  imports: [RouterModule.forChild(routes), CommonModule, SharedModule, ScrollListModule],
  declarations: [CustomErrorScreenComponent]
})
export class CustomErrorScreenModule {}

