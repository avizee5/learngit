import { Component, OnInit, OnDestroy } from '@angular/core';
import { SettingsService } from '../services/settings.service';
import {CollectionApi} from '../../data/catalog/api/CollectionApi';
import {environment} from '../../environments/environment';
import {CommonService} from '../services/common.service';
import { Router } from '@angular/router';
import { Http} from '@angular/http';
import * as $ from 'jquery';
import { HeaderservicesService } from '../services/headerservices.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { Location } from '@angular/common';
import { Meta, Title} from '@angular/platform-browser';
import { Subject } from 'rxjs/Subject';

/* Angular Universal */
import { isPlatformBrowser } from '@angular/common';
import { Inject , PLATFORM_ID } from '@angular/core';
const changeRoute = 3000; // msec

@Component({
  selector: 'app-custom-error-screen',
  templateUrl: './custom-error-screen.component.html',
  styleUrls: ['./custom-error-screen.component.less']
})
export class CustomErrorScreenComponent implements OnInit, OnDestroy {
  public popularCollection: any;
  public assetbasepath = environment.assetsBasePath;  // Asset basepath letiable
  public config: any;
  public countryCode: any;
  public placeholder: any = 'MENU.SEARCH';
  public pageName: any;
  public localStorage: any; /*Angular Universal Global letiables*/
  public window: any;
  public document: any;
  public navigator: any;
  public router2: any;
  public display: any;
  public content: any;
  public userToken: any;
  public ngUnsubscribe = new Subject<any>();
  constructor(@Inject(PLATFORM_ID) private platformId: Object,
    private titleService: Title,
    private metaService: Meta,
    private location: Location,
    private headerservicesService: HeaderservicesService,
    private router: Router,
    private http: Http,
    private settingsService: SettingsService,
    private commonService: CommonService,
    private gtm: GoogleAnalyticsService) {
    if (isPlatformBrowser(this.platformId)) {
      this.localStorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
    this.router = router;
    this.router2 = this.window.location.pathname;
    this.headerservicesService.viewChange(this.router2);
  }

  public ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.localStorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
    $('#loaderPage').css('display', 'block');


    this.countryCode = this.settingsService.getCountry();
    this.userToken = this.localStorage.getItem('token');
    this.display = this.userToken ? this.localStorage.getItem('UserDisplayLanguage') : this.localStorage.getItem('display_language');
    this.content = this.userToken ? this.localStorage.getItem('UserContentLanguage') : this.localStorage.getItem('ContentLang');

    this.titleService.setTitle('404 - Page Cannot Be found');
    this.metaService.updateTag({name: 'description', content : 'Sorry! the page you are looking for cannot be found'});
    this.metaService.updateTag({name: 'og:description', content : 'Sorry! the page you are looking for cannot be found'});
    this.metaService.updateTag({ name: 'og:title', content: '404 - Page Cannot Be found' });
    this.metaService.updateTag({ name: 'twitter:title', content: '404 - Page Cannot Be found' });

    /* Google Analytics */
    // this.pageName = '404 - Page Cannot Be found';
    // this.gtm.sendPageName(this.pageName)
    // this.gtm.sendEvent();
    // this.gtm.storeWindowError();

  	this.config = {
      apiKey: ' ',
      username: ' ',
      password: ' ',
      accessToken: ' ',
      withCredentials: false
    };

    this.getConvivaPopular();

    //setTimeout(() => { this.navigateHome(); }, changeRoute);
}

  public getConvivaPopular() {
    let url;
    url = environment.convivaPopular + this.content + '&translation=' + this.display + '&country=' + this.countryCode;
    this.http.get(url).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).map(response => response.json()).subscribe(value => {
      $('#loaderPage').css('display', 'none');
      if (value.docs.length > 0) {
        this.popularCollection = { 'title': 'SEARCH.VIEW_POPULAR', 'original_title': 'You may view our Most Popular Shows and Movies', 'type': 'tvshows', 'content': value.docs };
      }
    });
  }

  public goSearch(event) {
    let searchquery;
    searchquery = (<HTMLInputElement>this.document.getElementById('textfield')).value;
    searchquery = searchquery.replace(/[`~!@#$%^&*()|+\=?;:'',.<>\{\}\[\]]/gi, '');
    if (searchquery.length > 2) {
      this.router.navigate(['/search/result'], { queryParams: { q: searchquery} });
    }
  }

  public navigateHome() {
    this.router.navigate(['/']);
  }

 public ngOnDestroy(): any {
   this.ngUnsubscribe.next();
   this.ngUnsubscribe.complete();
 }

}
