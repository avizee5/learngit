import { Component, OnInit, ViewChild, OnDestroy, ElementRef} from '@angular/core';
import { HeaderservicesService } from '../services/headerservices.service';    // services for variable update
import { UserProfileService } from '../services/user-profile.service';
import { Subscription } from 'rxjs/Subscription';
import * as $ from 'jquery';
import {Observable} from 'rxjs/Rx';
import { Router } from '@angular/router';
import {FavoritesApi, RemindersApi, UserApi, WatchHistoryApi, WatchlistApi } from '../../data/user/api/api';
import { Http} from '@angular/http';
import { UserApiService } from '../services/user-api.service';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { VideoService } from '../services/video.service';
import {MovieApi} from '../../data/catalog/api/MovieApi';
import {EpisodeApi} from '../../data/catalog/api/EpisodeApi';
import {TvShowApi} from '../../data/gwapi_catalog/api/TvShowApi';
import { RouteService } from '../services/route.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import {  NetworkService  } from '../services/network.service';
import { environment } from '../../environments/environment';
import {CommonService} from '../services/common.service';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { LinkService } from '../services/link.service';
import { SettingsService } from '../services/settings.service';

declare const qg;

@Component({
  selector: 'app-profile-screen',
  templateUrl: './profile-screen.component.html',
  styleUrls: ['./profile-screen.component.less']
})
export class ProfileScreenComponent implements OnInit, OnDestroy {
  @ViewChild('load') public load_button: ElementRef;
  public carousel: any;
  public shows: any;
  public menuTabs: any;
  public previousTab: any;
  public followed: any;
  public reminders: any;
  public totalData: any;
  public serviceScope: any;
  public favorites: any;
  public modalVideoPopup: any;
  public modalVideoDetails: any;
  public cover = true;
  public favoriteMovies: any;
  public watchMovies: any;
  public favoriteEpisode: any;
  public watchEpisode: any;                                                                             // for yeterday title to display
  public router: any;
  public router2: any;
  public profile: any;                                                            // profile user data
  public data: any;
  public id: any;
  public name: any;
  public watch: any;
  public sub: any;
  public urlString: any;
  public fullName: any;
  public showFlag: any = false;
  public showEmptyFlag: any = false;
  public loginType: any;
  public config: any;
  public demotext: any = null;
  public removedItem: any;
  public pageName: any;
  public displayLang: any;
  public contentLang: any;
  public getToken: any;
  public userType: any;
  public basepath: any;
  public reminderMovie: any;
  public reminderShow: any;
  public localstorage: any;
  public window: any;
  public document: any;
  public navigator: any;
  public path: any;
  public countryCode: any;
  public qgraph: any;
  public removeLink = false;
  public sendType: any;
  public sendTitle: any;
  public assetBasePath = environment.assetsBasePath;
  public flag = true;
  public staticData: any = {                                                       // Static data used in html
    'assets': {
      'profile_cover': this.assetBasePath + 'assets/profile-user/profile_cover.png',
      'profile_image': this.assetBasePath + 'assets/profile-user/no_profile.png',
      'fb_icon': this.assetBasePath + 'assets/profile-user/fb_icon.png',
      'twitter_icon': this.assetBasePath + 'assets/profile-user/twitter_icon.png',
      'camera_icon': this.assetBasePath + 'assets/profile-user/camera_icon.png'
    },
    'data': {
      'profile': {
        'edit': 'PROFILE.EDIT_PROF',
        'actions': 'PROFILE.REMAINING_ACTIONS'
      },
      'empty': {
        'watchList': {
          'image': this.assetBasePath + 'assets/default/profile_watchlist.png',
          'first_line': 'PROFILE.Nothing_TO_WATCH',
          'second_line': 'PROFILE.WATCHLIST_EMPTY',
          'third_line' : 'PROFILE.WAITING_QUES'
        },
        'favorites': {
          'image': this.assetBasePath + 'assets/default/profile_my_fav.png',
          'first_line': 'PROFILE.NO_FAVOURITES',
          'second_line': 'PROFILE.FAVOURITE_INFO',
          // 'third_line' : 'see them here.'
        },
        'follow': {
          'image': this.assetBasePath + 'assets/default/profile_followed_shows.png',
          'first_line': 'PROFILE.OH_SNAP',
          'second_line': 'PROFILE.NO_FOLLOWED_SHOWS'
        },
        'reminder': {
          'image': this.assetBasePath + 'assets/default/profile_reminders.png',
          'first_line': 'PROFILE.SORRY',
          'second_line': 'PROFILE.NO_REMINDER_INFO'

        }
      }
    }
  };
  public ngUnsubscribe = new Subject<any>();
  constructor(private settingsService: SettingsService , private linkservice: LinkService, @Inject(PLATFORM_ID) private platformId: Object, private commonService: CommonService, private networkService: NetworkService, private gtm: GoogleAnalyticsService, private routeservice: RouteService ,
    private videoService: VideoService, private location: Location, private route: ActivatedRoute , private userapiService: UserApiService, private routerLink: Router, private headerservicesService: HeaderservicesService , private userProfileService: UserProfileService, private http: Http ) {
    this.router = routerLink;
    if (this.router.currentUrlTree.root.children.primary.segments.length === 2) {
      this.path = this.router.currentUrlTree.root.children.primary.segments[1].path;
    }
    if (isPlatformBrowser(this.platformId)) {
      this.localstorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
    this.router2 = this.window.location.pathname;
    this.routeservice.setRoute(this.router2);
    this.headerservicesService.viewChange(this.router2);
  this.headerservicesService.blockeventsValue.subscribe(value => {
     this.qgraph = this.headerservicesService.getRemarketing();
    });
  }
  public ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.localstorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
    this.gtm.storeWindowError();
    this.qgraph = this.headerservicesService.getRemarketing();
    this.gtm.setGaFlag(false);
    this.countryCode = this.settingsService.getCountry();
    this.routeservice.setLoginRoute(this.window.location.pathname); // preserve previous route
    this.sub = this.route.params.subscribe(params => {
    this.menuTabs = [ true, false, false, false, false ]; // Tab States
      this.previousTab = 0; // previous tab selected
      if (this.path) {
        this.id = params['id'];
        if ( this.path  === 'favorites') {

          this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'myprofile/favorites' } );
          this.openTab(1);
        } else if ( this.path === 'watchlist') {
          this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'myprofile/watchlist' } );
          this.openTab(0);
        } else if ( this.path === 'reminders') {
          this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'myprofile/reminders' } );
          this.openTab(3);
        }
      } else {
        this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'myprofile/watchlist' } );
        this.openTab(0);
      }
    });
// this.location.go('myprofile/watchlist')
let scope;
scope = this;
let token, params_bearer, userDetails, network;
token = this.localstorage.getItem('token');
this.loginType = this.localstorage.getItem('login');
if (token) {
  params_bearer = 'bearer ' + token;
  this.window.scrollTo(0, 0);
  this.config = {
    apiKey: params_bearer,
    username: ' ',
    password: ' ',
    accessToken: ' ',
    withCredentials: false
  };
  userDetails = new UserApi(this.http, null, this.config);
  network = this.networkService.getScreenStatus();
  if (this.networkService.getScreenStatus()) {
    $('#loaderPage').css('display', 'block');
    userDetails.v1UserGet().subscribe(value => {
      this.data = value;
      this.userProfileService.setUserdata(this.data);
      this.initialiseUser(this.data);
      this.showFlag = true;
    },
    err => {
      this.gtm.sendErrorEvent('api', err);
    }
    );
  }
  this.shows = { 'title': 'MENU.WATCHLIST',  'type': 'watchList',
  'content': []};
  this.favorites = {    'title': 'MENU.MYFAV',  'type': 'favorites',
  'content': []};
  this.followed = { 'type': 'follow', 'title': 'MENU.FOLLOWED',
  'content': [] };
  this.reminders = { 'type': 'reminder', 'title': 'MENU.REMINDERS',
  'content': [] };
  this.profile = {};
} else {
  this.routerLink.navigate(['/']);
}
}

public dismiss(event: any, type: any) {
  if (type === 'favorites') {
    this.favorites.content = $.grep(this.favorites.content, function(e) {
      return e.id !== event.id;
    });
  } else if (type === 'watchlist') {
    this.shows.content = $.grep(this.shows.content, function(e) {
      return e.id !== event.id;
    });
  }
}
public deleteItem(event: any): void {
  if (this.networkService.getPopupStatus()) {
    if (event.type === 'favorites') {
      this.favorites.content = $.grep(this.favorites.content, function(e) {
        return e.id !== event.show.id;
      });

      $('#snackbar-profile').addClass('show');
      $('#toast').css(
      {
        'display': 'block'
      });
      this.demotext = 'MESSAGES.REMOVE_FAVOURITE';
      this.removedItem = event.title;
      setTimeout(function() {$('#snackbar-profile').removeClass('show') ;
        $('#toast').css(
        {
          'display': 'none'
        });
      }, 1000);
    } else if (event.type === 'watchList') {
      this.shows.content = $.grep(this.shows.content, function(e) {
        return e.id !== event.show.id;
      });


      $('#snackbar-profile').addClass('show');
      $('#toast').css(
      {
        'display': 'block'
      });
      this.demotext = 'MESSAGES.REMOVE_WATCHLIST';
      this.removedItem = event.title;
      setTimeout(function() {$('#snackbar-profile').removeClass('show') ;
        $('#toast').css(
        {
          'display': 'none'
        });
      }, 1000);
    }
  }
}
// Tab selection function
// Input -> Tab index(0,1,2,3,4)
public openTab(index: any): void {
  let params, token;
  token = this.localstorage.getItem('token');
  this.loginType = this.localstorage.getItem('login');

  if (token) {
    params = 'bearer ' + token;
    this.config = {
      apiKey: params,
      username: ' ',
      password: ' ',
      accessToken: ' ',
      withCredentials: false
    };
    let watchListRequest, favoritesRequest, remindersRequest;
    watchListRequest = new  WatchlistApi(this.http, null, this.config);
    favoritesRequest = new  FavoritesApi(this.http, null, this.config);
    remindersRequest = new  RemindersApi(this.http, null, this.config);
    if (this.networkService.getPopupStatus()) {
      this.menuTabs[this.previousTab] = false;
      this.menuTabs[index] = true;
      this.previousTab = index;
      $('#loaderPage').css('display', 'block');
      if (index === 0) {
        this.updateBreadCrump('MENU.WATCHLIST');
        this.pageName = 'user profile/watchlist';
        // this.location.replaceState('myprofile/watchlist')
        this.headerservicesService.viewChange('/myprofile/watchlist');

        watchListRequest.v1WatchlistGet().subscribe(value => {
          this.shows = { 'title': 'MENU.WATCHLIST',  'type': 'watchList',
          'content': value};
          setTimeout( function() {
            $('#loaderPage').css('display', 'none');
          }, 300);
        },
        err => {
          setTimeout( function() {
            $('#loaderPage').css('display', 'none');
          }, 300);
          if (JSON.parse(err._body).code === 1) {
            this.shows.content = [];
            this.showEmptyFlag = true;
          }
          this.gtm.sendErrorEvent('api', err);
        });

      // UserProfileFavorite
    } else if (index === 1) {
      this.updateBreadCrump('MENU.MYFAV');
      this.pageName = 'user profile/favorites';
      // this.location.replaceState('myprofile/favorites')
      this.headerservicesService.viewChange('/myprofile/favorites');
      $('#loaderPage').css('display', 'block');
      favoritesRequest.v1FavoritesGet().subscribe(value => {
        this.favorites = {    'title': 'MENU.MYFAV',  'type': 'favorites',
        'content': value};
        setTimeout( function() {
          $('#loaderPage').css('display', 'none');
        }, 300);
      },
      err => {
        setTimeout( function() {
          $('#loaderPage').css('display', 'none');
        }, 300);
        if (JSON.parse(err._body).code === 1) {
          this.favorites.content = [];
        }
        this.gtm.sendErrorEvent('api', err);
      });
    } else if (index === 3) {
      this.updateBreadCrump('MENU.REMINDERS');
      this.pageName = 'user profile/reminders';
      // this.location.replaceState('myprofile/reminders')
      this.headerservicesService.viewChange('/myprofile/reminders');
      $('#loaderPage').css('display', 'block');
      remindersRequest.v1RemindersGet().subscribe(value => {
        this.reminders = { 'type': 'reminder', 'title': 'MENU.REMINDERS',
        'content': [] };
        this.reminderMovie = [];
        this.reminderShow = [];
        for (let index_new = 0; index_new < value.length; index_new++) {
          if (value[index_new].asset_type === 0 ) {
            this.reminderMovie.push(value[index_new].id);
            this.flag = true;
          } else if (value[index_new].asset_type === 6) {
            this.reminderShow.push(value[index_new].id);
            this.flag = true;
          } else {
            this.flag = false;
          }
        }
        if (value.length === 0 || null) {
            this.flag = false;
        }
        let config;
        config = {
          apiKey: ' ',
          username: ' ',
          password: ' ',
          accessToken: ' ',
          withCredentials: false
        };
        for (let index_new = 0; index_new < this.reminderShow.length; index_new++) {
          let x, userType;
          x = new TvShowApi(this.http, null, config);
          userType = this.commonService.getUserType();
          x.v1TvshowByIdGet(this.reminderShow[index_new], undefined, this.countryCode, null, null, userType).subscribe(result => {
              this.reminders.content.push(result);
            },
            err => this.gtm.sendErrorEvent('api', err)
            );
        }
        setTimeout( function() {
          $('#loaderPage').css('display', 'none');
        }, 300);
      },
      err => {
        setTimeout( function() {
          $('#loaderPage').css('display', 'none');
        }, 300);
        this.gtm.sendErrorEvent('api', err);
        this.flag = false;
      },
      );
    }

    this.gtm.sendPageName(this.pageName);
    this.gtm.sendEvent();
  }
}
}
public editRoute() {
  if (this.networkService.getPopupStatus()) {
    let route;
    route = 'myprofile/edit';
    this.routerLink.navigate([route]);
  }
}
public updateBreadCrump(title: any) {
  let breadcrump;
  breadcrump = [
  {
    'label': 'BREADCRUMB.HOME',
    'url': '/',
    'enable': true
  },
  {
    'label': 'MENU.MYPROFILE',
    'url': '/myprofile/watchlist',
    'enable': false
  },
  {
    'label': title,
    'url': this.router2,
    'enable': false
  }
  ];
  this.headerservicesService.breadCrump(breadcrump);
}
public removeAll(type: any , title: any): void {
  if (this.networkService.getPopupStatus()) {
    let scope;
    scope = this;
    if (type === 'watchList') {
      for (let index = 0; index < this.shows.content.length; index++) {
        let watchListRequest;
        watchListRequest = new  WatchlistApi(this.http, null, this.config);
        watchListRequest.v1WatchlistDelete(this.shows.content[index].id, this.shows.content[index].asset_type).subscribe(value => {
          this.shows.content = this.shows.content.slice(index, this.shows.content.length - 1);
        },
        err => {
          this.gtm.sendErrorEvent('api', err);

        });
      }
      this.userProfileService.fullWatchData([]);
      this.shows.content = [];
      this.demotext = 'MESSAGES.REMOVE_WATCHLIST';
      this.removedItem = 'All';
        $('#snackbar-profile').addClass('show');
        $('#toast').css({'display': 'block'});
      setTimeout(function() {$('#snackbar-profile').removeClass('show') ;
        $('#toast').css({'display': 'none'});
      }, 1000);
    } else if (type === 'favorites') {
      for (let index = 0; index < this.favorites.content.length; index++) {
        let favoritesRequest;
        favoritesRequest = new  FavoritesApi(this.http, null, this.config);
        favoritesRequest.v1FavoritesDelete(this.favorites.content[index].id, this.favorites.content[index].asset_type).subscribe(value => {
          // empty
        },
        err => {
          this.gtm.sendErrorEvent('api', err);
        });
      }
      this.userProfileService.fullFavData([]);
        $('#snackbar-profile').addClass('show');
        $('#toast').css({'display': 'block'});
      this.favorites.content = [];
      this.demotext = 'MESSAGES.REMOVE_FAVOURITE';
      this.removedItem = 'All';
      setTimeout(function() {$('#snackbar-profile').removeClass('show') ;
        $('#toast').css(
        {
          'display': 'none'
        });
      }, 1000);
    }
  }
}
public removeImage() {
  this.cover = false;
}
public initialiseUser(data: any ): void {
  this.profile = data;
  if (this.profile.first_name) {
    this.fullName = (this.profile.first_name + ' ' + this.profile.last_name);
  }
  let age, ageValue;
  age = new Date(this.profile.birthday);
  ageValue = (new Date()).getFullYear() - age.getFullYear();
  this.qgraphevent('identify', {'email_id': this.profile.email === undefined ? '' : this.profile.email, 'phone': this.profile.mobile === undefined ? '' : this.profile.mobile ,
       'gender': this.profile.gender === undefined ? '' : this.profile.gender, 'age': ageValue, 'state': localStorage.getItem('state_code')});
}
public deleteReminderItem(event: any) {
  this.flag = false;
  $('#snackbar-profile').addClass('show');
  $('#toast').css(
  {
    'display': 'block'
  });
  this.demotext = 'MESSAGES.REMINDER_REMOVE';
  this.removedItem = event.title;
  // $('#snackbar-profile').text( this.demotext);
  setTimeout(function() {$('#snackbar-profile').removeClass('show') ;
    $('#toast').css(
    {
      'display': 'none'
    });
  }, 1000);
  if (event.all) {
    this.reminders.content = [];
  } else {
    this.reminders.content = $.grep(this.reminders.content, function(e) {
      return e.id !== event.show.id;
    });
  }
}
public openTabLink(tab: any) {
  switch (tab) {
    case 0:
    this.routerLink.navigate(['myprofile/', 'watchlist']);
      // code...
      break;
      case 1:
      this.routerLink.navigate(['myprofile/', 'favorites']);
      // code...
      break;
      case 3:
      this.routerLink.navigate(['myprofile/', 'reminders']);
      // code...
      break;
      default:
      this.routerLink.navigate(['myprofile/', 'watchlist']);
      // code...
      break;
    }
  }
  public ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
    this.linkservice.removeCanonicalLink();
  }
    public qgraphevent(eventname, object) {
    if (this.window.qg) {
      if (this.qgraph) {
        delete object.email_id;
        delete object.phone;
        // delete object.gender;
        // delete object.age;
        // delete object.state;
        qg(eventname, object);
      } else {
        qg(eventname, object);
      }
    }
  }

  public openRemoveConfirm(type , title): any {
    this.removeLink = true;
    this.sendType = type;
    this.sendTitle = type;
  }

  public closeEmbed(event): any {
    this.removeLink = event;
  }
  public deleteAll(event): any {
    this.removeAll(this.sendType, this.sendTitle);
  }
  public sendProfileClicksDetails(tabname) {
    let profileClicks;
    profileClicks = {
      'event': 'profileClicks',
      'TabName': tabname
    };
    this.gtm.sendEventDetails(profileClicks);
  }
}
