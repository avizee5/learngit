import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FollowedShowGridComponent } from './followed-show-grid.component';

describe('FollowedShowGridComponent', () => {
  let component: FollowedShowGridComponent;
  let fixture: ComponentFixture<FollowedShowGridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FollowedShowGridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FollowedShowGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
