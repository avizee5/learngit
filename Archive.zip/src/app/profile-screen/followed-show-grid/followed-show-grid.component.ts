import { Component, OnInit, Input, ElementRef, EventEmitter, Output } from '@angular/core';
import { UserProfileService } from '../../services/user-profile.service';
import * as $ from 'jquery';
import {  NetworkService  } from '../../services/network.service';
import { environment } from '../../../environments/environment';
import { Router } from '@angular/router';
import { SettingsService } from '../../services/settings.service';
import { GoogleAnalyticsService } from '../../services/google-analytics.service';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import {CommonService} from '../../services/common.service';

@Component({
	selector: 'app-followed-show-grid',
	templateUrl: './followed-show-grid.component.html',
	styleUrls: ['./followed-show-grid.component.less']
})
export class FollowedShowGridComponent implements OnInit {
	@Input() public showItem: any;
	@Output() public onChange = new EventEmitter<any>();
	@Output() public update = new EventEmitter<any>();
	public basepath: any;
	public basepathNew: any;
	public localstorage: any;
	public window: any;
	public document: any;
	public navigator: any;

	constructor(private commonService: CommonService, @Inject(PLATFORM_ID) private platformId: Object, private gtm: GoogleAnalyticsService, private settingsService: SettingsService , private routerLink: Router, private networkService: NetworkService, private userProfileService: UserProfileService ) { }

	public ngOnInit() {
		if (isPlatformBrowser(this.platformId)) {
			this.localstorage = localStorage;
			this.window = window;
			this.document = document;
			this.navigator = navigator;
		}
		this.gtm.storeWindowError();
		this.basepath = this.settingsService.getbasePath();
		this.basepathNew = this.settingsService.getbasePathNew();
	}
	public imageError(event: any): void {
		if (event.srcElement) {
			event.srcElement.src = environment.assetsBasePath + 'assets/default/tvshow.png';
		} else {
			event.currentTarget.src = environment.assetsBasePath + 'assets/default/tvshow.png';
		}
	}
	public getImagePath(show): any {
		let url;
		if (show.list_image) {
			url = this.basepathNew + show.id + '/list/' + '270x152/' + show.list_image + '?imwidth=270&impolicy=akamai_vidz1_zee5_com-IPM';
		} else {
			url =  environment.assetsBasePath + 'assets/default/tvshow.png';
		}
		return url;
	}
	public routeClick(show): void {
		this.routerLink.navigate(['tvshows/details', this.commonService.convertToLowercase(show.original_title), show.id ]);
	}
	public remove(index: any): void {
		if (this.networkService.getPopupStatus()) {
			this.userProfileService.removeReminderData(index.id, index.asset_type );
			this.onChange.emit({'show': index, 'type': this.showItem.type, 'all': false});
		}
	}
	public removeAll(type: any): void {
		if (this.networkService.getPopupStatus()) {
			for (let index = 0; index < this.showItem.content.length; index++) {
				this.userProfileService.removeReminderData(this.showItem.content[index].id, this.showItem.content[index].asset_type);
			}
			this.onChange.emit({'show': 'index', 'type': this.showItem.type, 'all': true});
		}

	}
}
