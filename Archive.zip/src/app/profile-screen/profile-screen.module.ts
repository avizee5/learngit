import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared.module';
import { ProfileScreenComponent } from './profile-screen.component';
import { FollowedShowGridComponent } from './followed-show-grid/followed-show-grid.component';
import { HomeGridModule } from '../home-grid/home-grid.module';
import { RemoveAllComponent } from './remove-all/remove-all.component';

const routes: Routes = [
{
	path: '',
	component: ProfileScreenComponent
},
{
	path: 'favorites',
	component: ProfileScreenComponent
},
{
	path: 'watchlist',
	component: ProfileScreenComponent
},
{
	path: 'reminders',
	component: ProfileScreenComponent
},
// {
// 	path: 'edit',
// 	// component: ProfileScreenComponent
//     loadChildren: './profile-screen/edit-profile/edit-profile.module#EditProfileModule'
// }
];

@NgModule({
 exports: [RouterModule],
  imports: [RouterModule.forChild(routes), CommonModule, SharedModule, HomeGridModule],
  declarations: [ProfileScreenComponent, FollowedShowGridComponent, RemoveAllComponent]
})
export class ProfileScreenModule {
}
