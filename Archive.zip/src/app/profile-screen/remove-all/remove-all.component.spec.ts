import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RemoveAllComponent } from './remove-all.component';

describe('RemoveAllComponent', () => {
  let component: RemoveAllComponent;
  let fixture: ComponentFixture<RemoveAllComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RemoveAllComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RemoveAllComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
