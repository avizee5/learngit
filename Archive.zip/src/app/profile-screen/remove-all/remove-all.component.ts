import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { environment } from '../../../environments/environment';
import * as $ from 'jquery';

@Component({
  selector: 'app-remove-all',
  templateUrl: './remove-all.component.html',
  styleUrls: ['./remove-all.component.less']
})
export class RemoveAllComponent implements OnInit {
  public document: any;
  public embedIcon: any;
  public closeIcon: any;
  public assetbasepath: any;
  public watchshow = false;
  public textChange: any;
  @Input() public type: any;
  @Output() public close = new EventEmitter<boolean>();
  @Output() public delete = new EventEmitter<boolean>();
  constructor(@Inject(PLATFORM_ID) private platformId: Object) { }

  public ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.document = document;
    }
    if (this.type === 'favorites') {
      this.textChange = false;
    } else {
      this.textChange = true;
    }
    this.assetbasepath = environment.assetsBasePath;
    this.embedIcon = this.assetbasepath + 'assets/common/embed_icon.png';
    this.closeIcon = this.assetbasepath + 'assets/common/close_icon.png';
    this.document.getElementById('body').classList.add('modalOpen');
  }

  public closePopup() {
      this.close.emit(false);
      this.document.getElementById('body').classList.remove('modalOpen');
  }
  public deleteFunction() {
    this.delete.emit(true);
    this.close.emit(false);
    this.document.getElementById('body').classList.remove('modalOpen');

  }
}
