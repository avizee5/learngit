import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared.module';
import { EditProfileComponent } from './edit-profile.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { MdDatepickerModule } from '@angular/material';
import { FormsModule } from '@angular/forms';

const routes: Routes = [
    { path: '', component: EditProfileComponent},
];

@NgModule({
 exports: [RouterModule],
  imports: [RouterModule.forChild(routes), CommonModule, SharedModule, MdDatepickerModule, FormsModule],
  declarations: [EditProfileComponent, ResetPasswordComponent]
})
export class EditProfileModule {
}
