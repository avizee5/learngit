import { Component, OnInit, ViewChild, OnDestroy, ElementRef, HostListener } from '@angular/core';
import * as $ from 'jquery';
import {MdNativeDateModule} from '@angular/material';
import {UserApi } from '../../../data/user/api/UserApi';
import { Http} from '@angular/http';
import { ActivatedRoute, Router } from '@angular/router';
import { RouteService } from '../../services/route.service';
import { GoogleAnalyticsService } from '../../services/google-analytics.service';
import {  NetworkService  } from '../../services/network.service';
import { HeaderservicesService } from '../../services/headerservices.service';
import { environment } from '../../../environments/environment';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { SettingsService } from '../../services/settings.service';
import { LinkService } from '../../services/link.service';

@Component({
	selector: 'app-edit-profile',
	templateUrl: './edit-profile.component.html',
	styleUrls: ['./edit-profile.component.less']
})
export class EditProfileComponent implements OnInit, OnDestroy {
	@ViewChild('pickerTouch') public pickerTouch: ElementRef;
	public countries: any;
	public dropDownCheck: any = false;
	public selected_country: any;
	public registercountry: any;
	public currentDay: any;
	// selected_country: any;
	public id: any;
	public country_code: any;
	public email_return_keypress = false;
	public password_return_keypress = false;
	public mobile_return_keypress = false;
	public country_codeLength: number;
	public genderdropDownCheck = false;
	public selected_gender: any;
	public gender: any;
	public username: any;
	public fb_src: any;
	public twitter_src: any;
	public google_src: any;
	public calendar_src: any;
	public date: any;
	public mobile_return: any = false;
	public password: any;
	public name_return: any;
	public errorMsg: any;
	public errorMsg1: any;
	public actualDate: any;
	// for displaying change pwd screen
	public showChngPwd = false;
	public data: any;
	public profile: any;
	public fullName: any;
	public showName: any = true;
	public place1 = false;
	public months: any;
	public calendar: any;
	public touchScreen = false;
	public params: any;
	public date_valid: any;
	public dateValue: any;
	public selectedDate: any;
	public loginType: any;
	public isEmail = false;
	public router: any;
	public router2: any;
	public pageName: any;
	public previousDate: any;
	public assetBasePath = environment.assetsBasePath;
	public showEmail: any = true;
	public placeEmail: any;
	public showGender: any = false;
	public placeGender: any;
	public saveToastMessage: any;
	public localstorage: any;
	public window: any;
	public document: any;
	public navigator: any;
	public code: any;
	public configData: any;
	public currentIndex: any = 0;
	public previousIndex: any = 0;
	public genderIndex: any = 0;
	public maxLength: any = 13;
	public ageValidation: any;
	public requireAge: any;
	private maxDate: any;
	public selected_country_mobile = {};
	public usernumber: any; 
	constructor(private settingsService: SettingsService, private linkservice: LinkService, @Inject(PLATFORM_ID) private platformId: Object, private networkService: NetworkService, private gtm: GoogleAnalyticsService, private routeservice: RouteService ,  private route: ActivatedRoute ,  private routerLink: Router , private http: Http, private headerservicesService: HeaderservicesService  ) {
		this.router = routerLink;
		this.router2 = window.location.pathname;
		this.routeservice.setRoute(this.router2);
		this.headerservicesService.viewChange(this.router2);
	}

	public ngOnInit() {
		this.gtm.storeWindowError();
		if (isPlatformBrowser(this.platformId)) {
			this.localstorage = localStorage;
			this.window = window;
			this.document = document;
			this.navigator = navigator;
		}
		let breadcrump;
		breadcrump = [
		{
			'label': 'BREADCRUMB.HOME',
			'url': '/',
			'enable': true
		},
		{
			'label': 'MENU.MYPROFILE',
			'url': '/myprofile',
			'enable': true
		},
		{
			'label': 'PROFILE.EDIT_PROF',
			'url': this.router2,
			'enable': false
		}
		];
		this.headerservicesService.breadCrump(breadcrump);
		this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'myprofile/edit' } );
		let network;
		network = this.networkService.getScreenStatus();
		if (network) {
			this.pageName = 'user profile/edit';
			this.gtm.sendPageName(this.pageName);
			this.gtm.sendEvent();
			$('#loaderPage').css('display', 'block');
			this.currentDay = new Date();
			if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPod|Opera Mini|IEMobile/i) || window.innerWidth <= 767) {
				this.touchScreen = true;

			}
			this.configData = this.settingsService.getCompleteConfig();
			this.profile = [];
			this.months = {
				'Jan': '01' ,
				'Feb' : '02',
				'Mar' : '03',
				'Apr' : '04',
				'May': '05',
				'Jun': '06',
				'Jul': '07',
				'Aug': '08',
				'Sep': '09',
				'Oct': '10',
				'Nov': '11',
				'Dec': '12'
			};
			this.loginType = this.localstorage.getItem('login');
			if (this.loginType === 'facebook' ||  this.loginType === 'twitter' || this.loginType === 'google') {
				$('#changePassword').attr('disabled', 'disabled');
				$('#changePassword').css('color', '#703055');
				this.isEmail = true;
			} else if (this.loginType === 'Email' ) {
				this.isEmail = true;
			}
			let token;
			token = this.localstorage.getItem('token');
			if (token) {

				this.params = 'bearer ' + token;

				let config;
				config = {
					apiKey: this.params,
					username: ' ',
					password: ' ',
					accessToken: ' ',
					withCredentials: false
				};
				let userDetails;
				userDetails = new UserApi(this.http, null, config);
				userDetails.v1UserGet().subscribe(value => {
					this.data = value;
					this.countries = this.settingsService.getcountryApiList();
					let selected_country_api, country, selected_country_mobile_api;
					if (this.countries.length === 0) {
						this.settingsService.getCountryList().timeout(environment.timeOut).subscribe( value_country => {
							$('#loaderPage').css('display', 'none');
							this.settingsService.setCountryListValue(value_country);
							this.countries = value_country;
							selected_country_api = this.settingsService.getCountry();
							selected_country_mobile_api = this.data.registration_country;
							for (country in this.countries) {
								if (this.countries[country].code === selected_country_mobile_api) {
									this.selected_country_mobile = this.countries[country];
									this.registercountry = this.countries[country];
									break;
								}
							}
							for (country in this.countries) {
								if ( this.countries[country].code === selected_country_api) {
									this.selected_country = this.countries[country];
									this.currentIndex = country;
									this.ageValidation = (this.selected_country.age_validation && this.selected_country.age_validation.age !== null) ? this.selected_country.age_validation.age : this.configData.default_values.age_validation.age;
									this.requireAge = (this.selected_country.age_validation && this.selected_country.age_validation.validation_require !== null) ? this.selected_country.age_validation.validation_require : this.configData.default_values.age_validation.validation_require;
									break;
								}
							}
							this.maxLength = 13;
							$('#mobileNumber').attr('maxlength', '13');

							this.code = '+' + this.selected_country['phone-code'] + '-';
							if (this.code.length < 5) {
								$('#countryCode').css('width', '35px');
							} else if (this.code.length < 7 && this.code.length > 4) {
								$('#countryCode').css('width', '65px');
							} else if (this.code.length >= 7) {
								$('#countryCode').css('width', '85px');
							}
							this.initialiseUser(this.data);
						},
						err => {
							$('#loaderPage').css('display', 'none');
							country = this.settingsService.getCountryValue();
							this.ageValidation = this.configData.default_values.age_validation.age;
							this.requireAge = this.configData.default_values.age_validation.validation_require;
							this.maxLength = 20;
							$('#mobileNumber').attr('maxlength', '20');
							this.selected_country = {'name': country.country, 'code': country.country_code, 'phone-code': undefined};
							this.countries = [{'name': country.country, 'code': country.country_code, 'phone-code': undefined}];
							this.initialiseUser(this.data);
						}
						);
					} else {
						$('#loaderPage').css('display', 'none');
						let selected_country_api1, country1;
						selected_country_api1 = this.settingsService.getCountry();
						selected_country_mobile_api = this.data.registration_country;
							for (country in this.countries) {
								if (this.countries[country].code === selected_country_mobile_api) {
									this.selected_country_mobile = this.countries[country];
									this.registercountry = this.countries[country];
									// console.log(this.selected_country_mobile);
									break;
								}
							}
						for (country1 in this.countries) {
							if (this.countries[country1].code === selected_country_api1) {
								this.selected_country = this.countries[country1];
								this.currentIndex = country1;
								this.ageValidation = (this.selected_country.age_validation && this.selected_country.age_validation.age !== null) ? this.selected_country.age_validation.age : this.configData.default_values.age_validation.age;
								this.requireAge = (this.selected_country.age_validation && this.selected_country.age_validation.validation_require !== null) ? this.selected_country.age_validation.validation_require : this.configData.default_values.age_validation.validation_require;
								break;
							}
						}
						this.maxLength = 13;
						$('#mobileNumber').attr('maxlength', '13');
						this.code = '+' + this.selected_country['phone-code'] + '-';
						if (this.code.length < 5) {
							$('#countryCode').css('width', '35px');
						} else if (this.code.length < 7 && this.code.length > 4) {
							$('#countryCode').css('width', '65px');
						} else if (this.code.length >= 7) {
							$('#countryCode').css('width', '85px');
						}
						this.initialiseUser(this.data);
					}
				},

				err => {
					$('#loaderPage').css('display', 'none');
					this.gtm.sendErrorEvent('api', err);
				}
				);
				window.scrollTo(0, 0);
				this.fb_src = this.assetBasePath + 'assets/social/fb_icon_selected.svg';
				this.twitter_src = this.assetBasePath + 'assets/social/twitter_icon_selected.svg';
				this.google_src = this.assetBasePath + 'assets/social/google_profile.png';
				this.calendar_src = this.assetBasePath + 'assets/profile-user/calendar_icon.png';
				this.password = 'Kelly Stevens';
				this.gender = [
				{id: '0' , name: 'PROFILE.MALE'},
				{id: '1' , name: 'PROFILE.FEMALE'},

				];
				this.country_codeLength = 10;
				this.country_code = '+91 - ';
				$(this.document).ready(function() {
					$('#mobileNumber').keydown(function (e) {
							// Allow: backspace, delete, tab, escape, enter.
							if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
								// Allow: Ctrl+A, Command+A
								(e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
								// Allow: home, end, left, right, down, up
								(e.keyCode >= 35 && e.keyCode <= 40)) {
								// let it happen, don't do anything
							return;
						}
						// Ensure that it is a number and stop the keypress
						if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
							e.preventDefault();
						}
					});
					$('#nameField').keydown(function (e) {
							// Allow: backspace, delete, tab, escape, enter.
							if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 32]) !== -1 ||
								// Allow: Ctrl+A, Command+A
								(e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
								// Allow: home, end, left, right, down, up
								(e.keyCode >= 35 && e.keyCode <= 40)) {
								// let it happen, don't do anything
							return;
						}
						// Ensure that it is a number and stop the keypress
						if ( (e.keyCode < 48 || e.keyCode > 105) ) {
							e.preventDefault();
						}
					});
					$('#date').keydown(function (e) {
						let key;
						key = e.keyCode;
						if ( $('#date').val().length === 2 &&  key !== 8 && key !== 46 ) {
							$('#date').val($('#date').val() + '.');
						} else if (( $('#date').val().length === 3 || $('#date').val().length === 6) && key === 8 ) {
							let str;
							str = $('#date').val();
							$('#date').val(str.substring(0, str.length - 1));
						} else if ($('#date').val().length === 5 &&  key !== 8 && key !== 46 ) {
							$('#date').val($('#date').val() + '.');
						}
							// Allow: backspace, delete, tab, escape, enter.
							if ($.inArray(e.keyCode, [ 8, 9, 27, 13, 46]) !== -1 ||
								// Allow: Ctrl+A, Command+A
								(e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
								// Allow: home, end, left, right, down, up
								(e.keyCode >= 35 && e.keyCode <= 40)) {
								// let it happen, don't do anything
							return;
						}
						// Ensure that it is a number and stop the keypress
						if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || (e.keyCode > 105 ))) {
							e.preventDefault();
						}
					});
				});

				this.selected_gender = '';

				let scope;
				scope = this;
				$(this.document).mouseup(function(e) {

						// check that your clicked
						// element has no id=info
						// and is not child of info
						if (e.target.id !== 'info' && !$('#info').find(e.target).length) {
							if (scope.dropDownCheck === true) {
								scope.dropDownCheck = false;
							}
						}
					});
				$(this.document).mouseup(function(e) {

						// check that your clicked
						// element has no id=info
						// and is not child of info
						if (e.target.id !== 'gender' && !$('#gender').find(e.target).length) {
							if (scope.genderdropDownCheck === true) {
								scope.genderdropDownCheck = false;
							}
						}
					});
				$(this.document).on('touchstart' , function(e) {
					if (e.target.id !== 'gender' && !$('#gender').find(e.target).length) {
						if (scope.genderdropDownCheck === true) {
							scope.genderdropDownCheck = false;
						}
					}
				});
				$(this.document).on('touchstart' , function(e) {

						// check that your clicked
						// element has no id=info
						// and is not child of info
						if (e.target.id !== 'info' && !$('#info').find(e.target).length) {
							if (scope.dropDownCheck === true) {

								scope.dropDownCheck = false;
							}
						}
					});
			} else {
				this.routerLink.navigate(['/']);
			}
		}}
		public onResize(event: any) {
			if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPod|Opera Mini|IEMobile/i) || window.innerWidth <= 767) {
				this.touchScreen = true;
			}
		}
		public scrollFunction(element: any, uiElement: any): void {
			let scope;
			scope = this;
			this.ondatefocus();
			if (window.innerWidth <= 767) {
				this.touchScreen = true;
			}
			if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPod|Opera Mini|IEMobile/i) && window.innerWidth > 767 ) {
				window.scrollTo(0, 100);
			}
			if (this.touchScreen === true) {
				uiElement.open();
			} else {
				element.open();
			}
			$(this.document).mouseup(function(e) {
				let container;
				container = $('.mat-datepicker-content');
					// if the target of the click isn't the container nor a descendant of the container
					if (!container.is(e.target) && container.has(e.target).length === 0 && scope.touchScreen === true )	{
						uiElement.close();
					}
				});
		}
		public updateDate (element: any) {
			let scope;
			scope = this;
			this.calendar = false;
			let input, monthValue, dateValue, output, bla;
			input = new Date(element);
			monthValue = input.getMonth() + 1;
			dateValue = input.getDate();
			output = (dateValue > 9 ? dateValue : '0' +  dateValue) + '.' + (monthValue > 9 ? monthValue : '0' +  monthValue) + '.' + input.getFullYear();
			bla = $('#date').val();
			$('#date').val(output);
			scope.dateValidation();
		}
		public initialiseUser(data: any ): void {
			let show_code, country, country_code;
			this.profile = data;
			this.fullName = this.profile.first_name + ' ' + this.profile.last_name;
			for (country in this.countries) {
				if (this.countries[country].code === this.profile.registration_country) {
					country_code = this.countries[country]['phone-code'];
					show_code = true;
					break;
				} else {
					show_code = false;
				}
			}
			if (show_code && this.profile && this.profile.mobile) {
				// this.profile.mobile_format = '+' + country_code + '-' + this.profile.mobile.slice(country_code.length);
				this.profile.mobile_format = '+' + this.profile.mobile;
			} else if (!show_code && this.profile && this.profile.mobile) {
				this.profile.mobile_format = this.profile.mobile;
			}
			if (this.profile && this.profile.first_name && this.profile.first_name.length > 0) {
				$('#nameField').val(this.profile.first_name);
				this.place1 = false;
				this.showName = false;
			}
			if (this.profile.mobile) {
				this.usernumber = this.profile.mobile;
				// $('#mobileNumber').val( "+" + this.profile.mobile);
			}
			if (this.profile.birthday) {
				let input, monthValue, dateValue, output, birthdate;
				if (this.profile.birthday.length === 19) {
					this.profile.birthday = this.profile.birthday + 'Z';
				}
				input = new Date(this.profile.birthday);
				monthValue = input.getMonth() + 1;
				dateValue = input.getDate();
				output = (dateValue > 9 ? dateValue : '0' +  dateValue) + '.' + (monthValue > 9 ? monthValue : '0' +  monthValue) + '.' + input.getFullYear();
				birthdate = output;
				$('#date').val(birthdate);
				this.selectedDate = $('#datePicker').val(this.profile.birthday);

			}
			if ( this.profile.gender === 'male') {
				this.selected_gender = this.gender[0];
				this.genderIndex = 0;
				this.showGender = false;
			} else if (this.profile.gender === 'female') {
				this.selected_gender = this.gender[1];
				this.showGender = false;
				this.genderIndex = 1;
			} else {
				this.showGender = true;
				this.selected_gender = {'name' : 'PROFILE.GENDER'};
				this.genderIndex = 0;
			}
			this.showEmail = this.profile.email ? false : true;
			if (this.profile.email) {  // to disable edit once emailid got from Api
				$ ('#emailid').attr('disabled', 'disabled');
			}
		}

		public mobileValidation() {
			const scope = this;
			let mobile_number;
			mobile_number = $('#mobileNumber').val();
			let minMobileLength;
			let maxMobileLength;
			let count1;
			minMobileLength = 4;
			maxMobileLength = this.maxLength;
			count1 = $('#mobileNumber').val().length;
			if ( (mobile_number !== undefined && mobile_number.length === 0) || (this.profile.mobile) ) {
				$('.mobileContainerForm').css({'border-bottom-color': '#bbbbbb'});
				$('#InvalidMobile').css({'display': 'none'});
				scope.mobile_return = true;
				return this.mobile_return;
			} else {
				$('#InvalidMobile').css({'display': 'block'});
				if (mobile_number !== undefined && ((mobile_number.length < minMobileLength) || (mobile_number.length > maxMobileLength)) && mobile_number[0] !== '0') {
					$('#InvalidMobile').css({'display': 'block'});
					$('.mobileContainerForm').css({'border-bottom-color': 'red'});
					scope.mobile_return = false;
					return this.mobile_return;
				} else {
					if (scope.selected_country.code === 'IN' && this.code && mobile_number.length === 10  && mobile_number[0] !== '0') {
						scope.mobile_return = true;
						$('.mobileContainerForm').css({'border-bottom': '1px solid'});
						$('#InvalidMobile').css({'display': 'none'});
						return this.mobile_return;
					} else if (scope.selected_country.code !== 'IN' && this.code && mobile_number[0] !== '0' ) {
						scope.mobile_return = true;
						$('.mobileContainerForm').css({'border-bottom': '1px solid'});
						$('#InvalidMobile').css({'display': 'none'});
						return this.mobile_return;
					} else if (!this.code && ((mobile_number.length > minMobileLength) && (mobile_number.length < maxMobileLength)) && mobile_number[0] !== '0') {
						scope.mobile_return = true;
						$('.mobileContainerForm').css({'border-bottom': '1px solid'});
						$('#InvalidMobile').css({'display': 'none'});
						return this.mobile_return;
					} else {
						$('.mobileContainerForm').css({'border-bottom': '1px solid red'});
						scope.mobile_return = false;
						return this.mobile_return;
					}
				}
			}
		}
		public ondatefocus() {
			if (this.requireAge === 'yes')	{
				this.maxDate =  new Date((this.currentDay.getFullYear() - this.ageValidation), this.currentDay.getMonth(), this.currentDay.getDate());
			}
			$('#dateContainerForm').css({'border-color': '#bbbbbb'});
			$('#InvalidDate').css({'display': 'none'});

		}
		public onfocus() {
			$('.mobileContainerForm').css({'border-color': '#bbbbbb'});
			$('#InvalidMobile').css({'display': 'none'});
		}
		public onEmailfocus() {
			$('#emailContainerForm').css({'border-color': '#bbbbbb'});
			$('#InvalidEmail').css({'display': 'none'});
			this.showEmail = false;
			this.placeEmail = true;
		}
		public emailValidation(): any {
			let count1;
			count1 = $('#emailAddress').val().length;
			if (count1 === 0) {
				this.showEmail = true;
				this.placeEmail = false;
			}
			let re;
          re = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?/; // to validate c.@asd.adf and caps 
            // re = /^([a-zA-Z0-9]+)(([^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        	// re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/; // to validate c.abcd@gags.co

			// re = /^([a-zA-Z0-9._+-]+)(@[a-zA-Z0-9-.]+)(.[a-zA-Z]{2,4}){2,}$/;
			// re = /^(([^<>()[\]\\.,;:\s@\']+(\.[^<>()[\]\\.,;:\s@\']+)*)|(\'.+\'))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
			if ($('#emailAddress').val().length > 0) {
				if ($('#emailAddress').val().trim().match(re)) {
					return true;
				} else {
					$('#emailContainerForm').css({'border-color': 'red'});
					$('#InvalidEmail').css({'display': 'block'});
					return false;
				}
			} else {
				return true;
			}
		}

		public regEmailValidation(): any {
			let count1;
			count1 = $('#emailid').val().length;
			if (count1 === 0) {
				this.showEmail = true;
				this.placeEmail = false;
			}
			let re;
          	re = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?/; // to validate c.@asd.adf and caps 
            // re = /^([a-zA-Z0-9]+)(([^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        	// re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/; // to validate c.abcd@gags.co

			// re = /^([a-zA-Z0-9._+-]+)(@[a-zA-Z0-9-.]+)(.[a-zA-Z]{2,4}){2,}$/;
			// re = /^(([^<>()[\]\\.,;:\s@\']+(\.[^<>()[\]\\.,;:\s@\']+)*)|(\'.+\'))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
			if ($('#emailid').val().length > 0) {
				if ($('#emailid').val().trim().match(re)) {
					return true;
				} else {
					$('#emailContainerForm').css({'border-color': 'red'});
					$('#InvalidEmail').css({'display': 'block'});
					return false;
				}
			} else {
				return true;
			}
		}

		public getAge (dateString: any) {
			let today, birthDate, m, age;
			today = new Date();
			birthDate = new Date(dateString);
			age = today.getFullYear() - birthDate.getFullYear();
			m = today.getMonth() - birthDate.getMonth();
			if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
				age--;
			}
			return age;
		}
		public dateValidation(): any {
			this.date_valid = true;
			let dateValue;
			dateValue = $('#date').val();
			let dateReg;
			dateReg = /^\d{2}[./-]\d{2}[./-]\d{4}$/;
			if (dateValue.match(dateReg)) {
				// todo
			} else {
				if (dateValue.length === 0) {
					// todo
				} else {
					this.nameError();
					this.date_valid = false;
				}
			}
			if (dateValue.length === 10) {
				let dd, mm, yy, day;
				dd = parseInt (dateValue.slice(0, 2), 10);
				mm  = parseInt (dateValue.slice(3, 5), 10);
				yy = parseInt (dateValue.slice(6, 10), 10);
				day = dd + 1;
				this.dateValue = new Date((mm) + '/' + dd + '/' + yy);
				this.actualDate = this.dateValue;
						// let tomorrow = new Date();
				if (this.currentDay  <= this.actualDate || (this.requireAge === 'yes' && (this.getAge(this.actualDate) < this.ageValidation))) {
							this.nameError();
							this.date_valid = false;
						}
						if (dd <= 0) {
							this.nameError();
							this.date_valid = false;
						}
						if (yy < 1900) {
							this.nameError();
							this.date_valid = false;
						}
						if (mm > 12 || mm === 0) {
							this.nameError();
							this.date_valid = false;
						}
							// Create list of days of a month [assume there is no leap year by default]
							let listofDays;
							listofDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
							if (mm === 1 || mm > 2) {
								if (dd > listofDays[mm - 1]) {
									this.nameError();
									this.date_valid = false;
								}
							}
							if (mm === 2) {
								let lyear = false;
								if ( (!(yy % 4) && yy % 100) || !(yy % 400)) {
									lyear = true;
								}
								if ((lyear === false) && (dd >= 29)) {
									this.nameError();
									this.date_valid = false;
								}
								if ((lyear === true) && (dd > 29)) {
									this.nameError();
									this.date_valid = false;
								}
							}
						} else {
							if (dateValue.length === 0) {
								// todo
							} else {
								this.nameError();
								this.date_valid = false;

							}
						}
						if (this.date_valid) {
							$('#datePicker').val(this.dateValue);
						}
						return this.date_valid;
					}
					public nameError() {
						$('#dateContainerForm').css({'border-color': 'red'});
						$('#InvalidDate').css({'display': 'block'});
					}
					public nameonfocus() {
						let count2;
						count2 = $('#nameField').val().length;
						this.showName = false;
						this.place1 = true;
						$('#InvalidName').css({'display': 'none'});
						$('#nameContainerForm').css({'border-color': '#bbbbbb'});
					}
					public nameValidation() {
						let count1;
						count1 = $('#nameField').val().length;
						if (count1 === 0) {
							this.showName = true;
							this.place1 = false;
							return true;
						} else {
							let nameRegex;
							nameRegex = /[`~!@#$%^&*()|+\=?;:'",.<>\{\}\[\]]/gi;
							if ($('#nameField').val().match(nameRegex)) {
								$('#InvalidName').css({'display': 'block'});
								$('#nameContainerForm').css({'border-color': 'red'});
								return false;
							} else {
								return true;
							}
						}
					}
					public changeValue(event: any, selectedIndex: number) {
						this.selected_country = event;
						this.registercountry = event;
						// this.usernumber = ''
						this.code = this.selected_country['phone-code'] ? '+' + this.selected_country['phone-code'] + '-' : undefined;
						let index;
						index = 'countryList' + selectedIndex;
						this.currentIndex = selectedIndex;
						document.getElementById(index).focus();
						if (this.code && this.code.length < 5) {
							$('#countryCode').css('width', '35px');
						} else if (this.code && this.code.length < 7 && this.code.length > 4) {
							$('#countryCode').css('width', '65px');
						} else if (this.code && this.code.length >= 7) {
							$('#countryCode').css('width', '85px');
						}
						this.dropDownCheck = false;
					}
					public dropdown() {
						if (this.loginType !== 'Mobile') {
							this.dropDownCheck = !this.dropDownCheck;
							if (this.dropDownCheck) {
								let index, scope;
								index = 'countryList' + this.currentIndex;
								scope = this;
								setTimeout(() => {
									document.getElementById(index).focus();
								}, 200);
							}
						}
					}
					public increment() {
						this.previousIndex = this.currentIndex;
						this.currentIndex ++;
						let index;
						index = 'countryList' + this.currentIndex;
						document.getElementById(index).focus();

					}
					public decrement() {
						this.previousIndex = this.currentIndex;
						if ((this.currentIndex - 1) >= 0) {
							this.currentIndex --;
							let index;
							index = 'countryList' + this.currentIndex;
							document.getElementById(index).focus();
						}
					}
					@HostListener('window:keydown', ['$event'])
					public keyEvent(event: KeyboardEvent) {
						if ( this.dropDownCheck && event.keyCode === 40 ) {
							event.preventDefault();
							this.increment();
						}
						if (this.dropDownCheck && event.keyCode === 38 ) {
							event.preventDefault();
							this.decrement();
						}
						if (this.dropDownCheck && event.keyCode === 9 ) {
							this.dropdown();
						}
						if ( this.genderdropDownCheck && (event.keyCode === 40 || event.keyCode === 38)) {
							event.preventDefault();
							if (this.genderIndex === 0) {
								this.genderIndex = 1;
							} else {
								this.genderIndex = 0;
							}
							let index;
							index = 'gender' + this.genderIndex;
							document.getElementById(index).focus();
						}
						if (this.genderdropDownCheck && event.keyCode === 9 ) {
							this.genderdropdown();
						}
					}
					public genderdropdown() {
						this.genderdropDownCheck = !this.genderdropDownCheck;
						if (this.genderdropDownCheck) {
							let index;
							index = 'gender' + this.genderIndex;
							setTimeout(() => {
								document.getElementById(index).focus();
							}, 200);
						}
					}

					public changeGender(event) {
						let id;
						id = event.id;
						this.selected_gender = this.gender[id];
						this.showGender = false;
						this.genderdropdown();
					}

					public changeDate(event: any) {
						// todo
					}
					public saveChanges() {
						if (this.networkService.getPopupStatus()) {
							if (this.loginType === 'Mobile') {
								if (this.nameValidation() && this.dateValidation() && this.emailValidation()) {
									this.putApiRequest();
								}
							} else if (this.loginType === 'email') {
								this.mobileValidation();
								this.nameValidation();
								if (this.nameValidation() && this.mobileValidation() && this.dateValidation()) {
									this.putApiRequest();
								}
							} else {
								if (this.nameValidation() && this.dateValidation() && this.regEmailValidation()) {
									this.putApiRequest();
								}
							}
						}
					}
					public putApiRequest() {
						let config, inputMobile;
						config = {
							apiKey: this.params,
							username: ' ',
							password: ' ',
							accessToken: ' ',
							withCredentials: true
						};
						let gendervalue;
						// let emailput;
						if (this.selected_gender.name === 'PROFILE.MALE') {
							gendervalue = 'male';
						} else if (this.selected_gender.name === 'PROFILE.FEMALE') {
							gendervalue = 'female';
						}
						// emailput = (this.loginType === 'Mobile') ? $('#emailAddress').val() : $('#emailid').val();
						if (!this.profile.mobile) {
							inputMobile = (($('#mobileNumber').val() !== '') && this.selected_country['phone-code'] && this.loginType !== 'Mobile' ? this.selected_country['phone-code'] + $('#mobileNumber').val() : ($('#mobileNumber') ? $('#mobileNumber').val() : ''));
						} else {
							inputMobile = ($('#mobileNumber').val() !== '') && this.loginType !== 'Mobile' && ($('#mobileNumber').val().indexOf('+') !== -1)  ? $('#mobileNumber').val().split('+')[1] : '';
						}
						let userPostDetails, userDetails;
						userPostDetails = {
							first_name: $('#nameField').val() ,
							last_name:  $('#nameField').val() ,
							birthday: this.actualDate,
							gender: gendervalue,
							mobile: this.loginType !== 'Mobile' ? inputMobile : '',
							email: (this.loginType === 'Mobile') ? $('#emailAddress').val() : $('#emailid').val()
						};
						userDetails = new UserApi(this.http, null, config);
						userDetails.v1UserPut(userPostDetails).subscribe(value => {
							$('#snackbar-save').addClass('visible');
							// $('#snackbar-save').text('Changes Saved Succesfully');
							// this.saveToastMessage = 'MESSAGES.CHANGES_SAVED';
							this.saveToastMessage = value.message;
							let scope;
							scope = this;
							setTimeout( function() {
								$('#snackbar-save').removeClass('visible') ;
								let route;
								route = 'myprofile/watchlist';
								scope.routerLink.navigate([route]); }, 2000);


						},
						err => {
							// console.log(err);
							$('#snackbar-save').addClass('visible');
							// this.saveToastMessage = 'TOAST_MESSAGES.CHANGES_NOTSAVED';
							this.saveToastMessage = JSON.parse(err._body).message;
							setTimeout(function() {$('#snackbar-save').removeClass('visible') ; }, 2000);
						}
						);
					}
					public showChangePasswordScreen() {
						if (this.networkService.getPopupStatus()) {
							this.showChngPwd = true;
						}
					}
					public closeFilter = function(event) {
						this.showChngPwd = false;
					};
					public routeFunction() {
						if (this.networkService.getPopupStatus()) {
							let route;
							route = 'myprofile/watchlist';
							this.routerLink.navigate([route]);
						}
					}
					public ngOnDestroy() {
						this.linkservice.removeCanonicalLink();
					}
				}


