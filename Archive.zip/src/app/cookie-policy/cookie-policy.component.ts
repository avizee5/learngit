import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { RouteService } from '../services/route.service';
import { HeaderservicesService } from '../services/headerservices.service';
import {  NetworkService  } from '../services/network.service';
import { FooterService } from '../services/footerdata.service';
import * as $ from 'jquery';
import { LinkService } from '../services/link.service';
import { SettingsService } from '../services/settings.service';
import {DomSanitizer} from '@angular/platform-browser';
import {environment} from '../../environments/environment';
import { Http} from '@angular/http';


@Component({
  selector: 'app-cookie-policy',
  templateUrl: './cookie-policy.component.html',
  styleUrls: ['./cookie-policy.component.less']
})
export class CookiePolicyComponent implements OnInit, OnDestroy {

 	 private router: any;
   private router2: any;
   private pageName: any;
   private data: any;
   public contentValue: any;
   private paraValue: any;
   private contentValuePara: any;
   private fathersday: boolean;
   private cookie_policy_src: any;
   private country_code: any;
   private cookiesBreadCrump: any;
   private translation: any;

  constructor(private http: Http, private sanitizer: DomSanitizer, private settingsService: SettingsService, private linkservice: LinkService, private footerservice: FooterService, private networkService: NetworkService, private routeservice: RouteService, private gtm: GoogleAnalyticsService, private routerUrl: Router, private headerservicesService: HeaderservicesService) {
  	const scope = this;
    this.router = routerUrl;
    this.router2 = window.location.pathname;
    this.headerservicesService.viewChange(this.router2);
    this.routeservice.setRoute(this.router2);
    this.routeservice.setLoginRoute(window.location.pathname);
  }

  public ngOnInit() {
    this.country_code = this.settingsService.getCountry();
    this.gtm.storeWindowError();
    let network;

        this.cookiesBreadCrump = [
        {
          'label': 'BREADCRUMB.HOME',
          'url': '/',
          'enable': true
        },
        {
          'label': 'MENU.COOKIES',
          'url': '/cookiePolicy',
          'enable': false
        }
      ];

      let token;
      token = localStorage.getItem('token');
        if (token) {
            this.translation = localStorage.getItem('UserDisplayLanguage');
        } else {
            this.translation = localStorage.getItem('display_language');
        }
    this.headerservicesService.breadCrump(this.cookiesBreadCrump);
    this.linkservice.addTag({ rel: 'canonical', href: window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'cookiePolicy'  } );
    network = this.networkService.getScreenStatus();
  	this.pageName = 'cookie policy';
    this.gtm.sendPageName(this.pageName);
    this.gtm.sendEvent();
  	window.scrollTo(0 , 0);
    this.cookie_policy_src = environment.shareUrl + 'zeeaction.php?ccode=' + this.country_code + '&text_type=cookies_text' + '&translation=' + this.translation;
    this.footerservice.getFooterdata1(this.cookie_policy_src).subscribe( value => {
      this.contentValue = value._body;
      $('#loaderPage').css('display', 'none');
    });
  }
   public ngOnDestroy () {
    this.linkservice.removeCanonicalLink();
  }
}
