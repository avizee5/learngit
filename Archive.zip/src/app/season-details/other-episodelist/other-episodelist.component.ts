import { Component, OnInit, Input} from '@angular/core';
// import { Component, OnInit, Input , ViewChild , Output, ElementRef , EventEmitter, OnChanges } from '@angular/core';
// import {OtherEpisodesComponent} from '../other-episodes/other-episodes.component';
// import * as api from '../../../data/catalog/api/api';
// import {FavoritesApi, RemindersApi, UserApi, WatchHistoryApi, WatchlistApi } from '../../../data/user/api/api';
// import { Http} from '@angular/http';
// import { UserProfileService } from '../../services/user-profile.service';
// import { GoogleAnalyticsService } from '../../services/google-analytics.service';
import { ActivatedRoute } from '@angular/router';
import 'rxjs/add/operator/timeout';
// import { environment } from '../../../environments/environment';
import { Subject } from 'rxjs/Subject';


@Component({
  selector: 'app-other-episodelist',
  templateUrl: './other-episodelist.component.html',
  styleUrls: ['./other-episodelist.component.less']
})
export class OtherEpisodelistComponent implements OnInit {
// export class OtherEpisodelistComponent implements OnInit, OnChanges {


   private ngUnsubscribe = new Subject<any>();
  @Input() public arrayList: any;
  @Input() private id: any;
  @Input() private totalPage: any;
  @Input() private channelNames: any;
  @Input() private dataFromParent: any;

  // private favorite: boolean;
  // private watched: boolean;
  // private episodeDataAllPages: any;

  // private storedData: any;
  // private storedWatchData: any;

  // private favouritData: any;
  // private watchedData: any;
  private subs: any;
  // private loginToken: any;
  private showId: any;
  // private total_pages: any;
  private dataForChild: any;
  constructor(
    // private http: Http,
    //  private gtm: GoogleAnalyticsService,
    //   private userProfileService: UserProfileService,
       private route: ActivatedRoute) {
        this.subs = this.route.params.subscribe(params => {
        this.showId =  params['id'] ;
     });
  }

  public ngOnInit() {
     // this.loginToken = localStorage.getItem('token');
     // this.episodeDataAllPages = [];
    //  let paramsvalue;
    //  paramsvalue = 'bearer ' + this.loginToken;

    //    if ( this.loginToken != null ) {
    //             let configUser, watchListRequest, favoritesRequest;
    //             configUser = {
    //             apiKey: paramsvalue,
    //             username: ' ',
    //             password: ' ',
    //             accessToken: ' ',
    //             withCredentials: false
    //           };
    //           watchListRequest = new  WatchlistApi(this.http, null, configUser);
    //           favoritesRequest = new  FavoritesApi(this.http, null, configUser);

    //            this.total_pages = this.totalPage;
    //          watchListRequest.v1WatchlistGet().takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
    //            this.userProfileService.fullWatchData(value);
    //          favoritesRequest.v1FavoritesGet().takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value1 => {
    //           this.userProfileService.fullFavData (value1);
    //           this.loadFavWatchData ();
    //         },
    //         err => {
    //           this.userProfileService.fullFavData([]);
    //         this.loadFavWatchData();
    //         this.gtm.sendErrorEvent('api', err);
    //         });
    //       },
    //       err => {
    //         this.userProfileService.fullWatchData([]);
    //         favoritesRequest.v1FavoritesGet().takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
    //           this.userProfileService.fullFavData(value);
    //            this.loadFavWatchData();
    //         },
    //         err2 => {
    //           this.userProfileService.fullFavData([]);
    //           this.loadFavWatchData();
    //         this.gtm.sendErrorEvent('api', err2);
    //       });
    //       this.gtm.sendErrorEvent('api', err);
    //     });

    // } else {
    //   this.total_pages = this.totalPage;
    //   this.loadFavWatchData();
    // }

    // this.total_pages = this.totalPage;
    // this.loadFavWatchData();

    this.dataForChild = {
      originalShowName: this.dataFromParent.originalShowName,
      showName: this.dataFromParent.showName,
      showId: this.showId,
      allChannel: this.dataFromParent.allchannels,
      business_type: this.dataFromParent.business_type,
      assetType: this.dataFromParent.assetType,
      genres: this.dataFromParent.genres,
      original_title: this.dataFromParent.original_title,
      assetSubtype: this.dataFromParent.asset_subtype,
      season_id: this.dataFromParent.season_id
     };
  }
  // public ngOnChanges() {

  //      if ( this.episodeDataAllPages != null && this.arrayList != null) {
  //         this.episodeDataAllPages = [];
  //        this.loadFavWatchData();
  //      }

  // }

    // private loadFavWatchData() {
    //   this.favouritData = [];
    //   this.watchedData = [];
    //    if ( this.arrayList != null ) {
    //                this.episodeDataAllPages = this.episodeDataAllPages.concat(this.arrayList);
    //                this.episodeDataAllPages = this.formatData(this.episodeDataAllPages , 'id');
    //                 this. fetchFavAndWatch();
    //     }
    //  }

    // private fetchFavAndWatch() {
    //    if ( this.loginToken != null ) {
    //      if ( this.storedData == null ) {
    //      this.storedData = this.userProfileService.getFavoriteData();
    //      }
    //      if ( this.storedWatchData == null) {
    //      this.storedWatchData = this.userProfileService.getWatchData();
    //      }
    //      for ( let i = 0; i < this.episodeDataAllPages.length; i++) {
    //        for ( let j = 0; j < this.storedData.length; j++) {
    //             if ( this.storedData[j].id === this.episodeDataAllPages[i].id ) {
    //                this.favouritData.push(this.episodeDataAllPages[i].id);
    //             }
    //         }
    //         for ( let k = 0; k < this.storedWatchData.length; k++) {
    //              if ( this.storedWatchData[k].id === this.episodeDataAllPages[i].id) {
    //                  this.watchedData.push(this.episodeDataAllPages[i].id);
    //             }
    //         }
    //      }
    //     }

    // }

    // private formatData(myArr, prop): any {
    //    return myArr.filter((obj, pos, arr) => {
    //    return arr.map(mapObj => mapObj[prop]).indexOf(obj[prop]) === pos;
    // });
    // }
}
