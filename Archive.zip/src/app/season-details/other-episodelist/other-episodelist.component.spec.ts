import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtherEpisodelistComponent } from './other-episodelist.component';

describe('OtherEpisodelistComponent', () => {
  let component: OtherEpisodelistComponent;
  let fixture: ComponentFixture<OtherEpisodelistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtherEpisodelistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtherEpisodelistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
