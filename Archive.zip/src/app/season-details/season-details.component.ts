// import { Component, OnInit } from '@angular/core';
import { Component, OnInit , HostListener, ViewChild, Output, EventEmitter, ElementRef, OnDestroy } from '@angular/core';
import * as $ from 'jquery';
import { Http} from '@angular/http';
import {SeasonApi, TvShowApi} from '../../data/gwapi_catalog/api/api';
import { environment } from '../../environments/environment';
import { RouteService } from '../services/route.service';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs/Subject';
import { Location } from '@angular/common';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { Meta } from '@angular/platform-browser';

import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { HeaderservicesService } from '../services/headerservices.service';
import { SettingsService } from '../services/settings.service';
import {CommonService} from '../services/common.service';
import { LinkService } from '../services/link.service';
import { SeoService } from '../services/seo.service';
import { UserProfileService } from '../services/user-profile.service';
const apiRetry = 2;

@Component({
  selector: 'app-season-details',
  templateUrl: './season-details.component.html',
  styleUrls: ['./season-details.component.less']
})
export class SeasonDetailsComponent implements OnInit, OnDestroy {
    private load_count: any;
    private category: any;
    private id: any;
    private name: any;
    private season: any;
    private router: any;
    private router2: any;
    private country_code: any;
  	private ngUnsubscribe = new Subject<any>();
  	private loginToken: any;
  	private desktop: any;
  	private displaylanguage: any;
  	private configData: any;
  	private apiRetryCount: any = 1;
  	// public showError: any = false;
  	private configUser: any;
  	public dataAvailable: any = false;
  	public processPending: any = false;
  	public tvshowData: any;
  	public seasons: any;
    public selectedSeason: any = 0;
  	public selectedSeasonOrderid: any = 1;
  	public totalPages: any;
    private sort_order: any = 'DESC';
    public tvshow: any;
    public episodeList: any;
    private urlcategory: any;
  	public infiniteScrollDistance: any = 0.5;
  	public localstorage: any;
  	public window: any;
  	public document: any;
  	public navigator: any;
  	public assetbasepath: any;
  	private onErrorBanner = environment.assetsBasePath + 'assets/default/banner.png';
  	private image_url: any;
  	public right_arrow: any = false;
  	public left_arrow: any = false;
  	private availableChannelOriginal: any;
    private assetType: any;
  	private actorDetails: any;
  	private tvShowsGenreEng: any;
  	private tvShowGenre: any;
  	private languagesEng: any;
    public arrow_visible = false;
    public tableWidth: any;
    public columnWidth: any;
    public show_arrows: any;
    public seasons_length: any;
    public scrollLeft = 0;
    public scrollRight = 0;
    public reachedEnd = false;
    public scrollInVw: any;
  	constructor(private userProfileService: UserProfileService,
    private http: Http,
   	private settingsService: SettingsService,
    private gtm: GoogleAnalyticsService,
    private routeservice: RouteService,
    private headerservicesService: HeaderservicesService,
    private location: Location,
    private routerLink: Router,
    private route: ActivatedRoute,
    private commonService: CommonService,
    @Inject(PLATFORM_ID) private platformId: Object,
    private seoService: SeoService,
    private linkservice: LinkService,
    private metaService: Meta) {
	    this.routeservice.setLoginRoute(window.location.pathname);
	    this.router = routerLink;
	    this.router2 = window.location.pathname;
	    this.routeservice.setRoute(this.router2);
	    this.headerservicesService.viewChange(this.router2);
	    if (isPlatformBrowser(this.platformId)) {
	      this.localstorage = localStorage;
	      this.window = window;
	      this.document = document;
	      this.navigator = navigator;
	    }
   }

  public ngOnInit() {
       $('#loaderPage').css('display', 'block');
        this.gtm.storeWindowError();
       this.configData = this.settingsService.getCompleteConfig();
       this.loginToken = localStorage.getItem('token');
      this.assetbasepath = environment.assetsBasePath;
      this.fontReScale();
        if (this.loginToken) {
          this.displaylanguage = localStorage.getItem('UserDisplayLanguage');
          this.userProfileService.httpgetFavoriteData();
          this.userProfileService.httpgetWatchData();
        } else {
          this.displaylanguage = localStorage.getItem('display_language');
        }
        if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i) || this.window.innerWidth <= 768) {
	      this.infiniteScrollDistance = 6;
	    }
        // this.fetchLabel = this.configData.languages_labels[this.displaylanguage];
  	  this.country_code = this.settingsService.getCountry();
      this.route.params.takeUntil(this.ngUnsubscribe).subscribe(params => {
      // this.load_count = 1;
      this.category = params['category'];
      this.id = params['id'];
      this.name = params['name'] ;
      this.season = params['seasons'];
      if (this.season) {
        this.selectedSeasonOrderid = parseInt(this.extractSeasonnumber(this.season), 10);
      } else {
        this.selectedSeasonOrderid = 1;
      }
      // this.selectedSeason = parseInt(this.extractSeasonnumber(this.season), 10) - 1;
      if (this.window.innerWidth > 768) {
        this.arrow_visible = true;
      } else {
        this.arrow_visible = false;
      }
      // this.showError = false;
      // console.log(this.tvshowData)
      if (!this.tvshowData) {
      	this.loadOnChange();
      } else {
        this.setSeason();
      }
      // this.loadOnChange();
    });
  }
  @HostListener('window:resize', ['$event'])
  public fontReScale() {
    let h, top;
    top = (window.innerWidth <= 768) ? (window.innerWidth <= 480)  ? (h + 50) : (h + 100) : (h + 10);
    $('#breadcrumInit').css('top', top + 'px');
    if (navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i) || window.innerWidth <= 480) {
      this.desktop = false;
    } else {
      this.desktop = true;
    }
    let e;
    e = event;
    this.onresize(e);
  }
  public onresize(event) {
    this.tableWidth = $('tbody').outerWidth();
    this.columnWidth = $('th').outerWidth();
    if (this.window.innerWidth > 768) {
        this.arrow_visible = true;
      } else {
        this.arrow_visible = false;
        $('tbody').animate({left : 0 + 'vw'}, 300);
        this.scrollLeft = 0;
      }
    if (this.tableWidth !== undefined && this.columnWidth !== undefined) {
      this.show_arrows = (Math.floor(this.tableWidth / this.columnWidth) < this.seasons_length) ? true : false;
        if ((this.tableWidth / this.columnWidth) >= this.seasons_length) {
          $('tbody').animate({left : 0 + 'vw'}, 300);
          this.scrollLeft = 0;
        }
        if (this.show_arrows) {
          this.reachedEnd = false;
        }
        }
      // if (this.scrollInVw  < 0) {
      //     let decScroll = this.tableWidth - this.scrollLeft;
      //     let pxToVw = this.scrollInVw + Math.abs((100 * decScroll) / this.window.innerWidth);
      //     $('tbody').animate({left : pxToVw + 'vw'}, 300);
      //     this.scrollLeft = (pxToVw * this.window.innerWidth / 100);
      // }
  }
  public setArrows(length) {
    $( document ).ready(function() {
      this.tableWidth = $('tbody').outerWidth();
      this.columnWidth = $('th').outerWidth();
      this.show_arrows = (Math.floor(this.tableWidth / this.columnWidth) < length) ? true : false;
      });
  }
  private movePrevious(): void {
    if (this.scrollLeft < 0 ) {
      this.reachedEnd = false;
      let rowWidth;
      rowWidth  = $('tr').outerWidth();
      this.tableWidth = $('tbody').outerWidth();
      this.columnWidth = $('th').outerWidth();
      let scroll;
      let pxToVw;
      if (Math.abs(this.scrollLeft)  >= this.columnWidth) {
      scroll = this.scrollLeft + Math.abs(this.tableWidth - (this.columnWidth * this.seasons_length));
    } else {
      scroll = 0;
    }
    if (scroll !== 0) {
       pxToVw = (100 * scroll) / this.window.innerWidth;
       this.scrollInVw = pxToVw;
    } else if (scroll === 0) {
      pxToVw = 0 ;
    }
      $('tbody').animate({left : pxToVw + 'vw'}, 300);
      this.scrollLeft = scroll;
    }
  }
  private moveNext(): void {
     let rowWidth;
     rowWidth = $('tr').outerWidth();
      this.tableWidth = $('tbody').outerWidth();
      this.columnWidth = $('th').outerWidth();
      if (rowWidth + (this.scrollLeft) > this.tableWidth) {
        let scroll;
          if ((rowWidth + (this.scrollLeft)) - this.tableWidth >= this.columnWidth) {
            scroll = this.scrollLeft + (this.tableWidth - (this.columnWidth * this.seasons_length) );
            if (Math.abs(scroll) < this.columnWidth) {
              this.reachedEnd = true;
            }
          } else {
            scroll = this.scrollLeft - 10 - ((rowWidth + (this.scrollLeft)) - this.tableWidth);
            this.reachedEnd = true;
          }
         let pxToVw;
         pxToVw = (100 * scroll) / this.window.innerWidth;
         this.scrollInVw = pxToVw;
        $('tbody').animate({left : pxToVw + 'vw'}, 300);
        this.scrollLeft = scroll;
    }
    // if (this.movecount < (this.timecount - this.visibleCount) && this.timecount > this.visibleCount) {
    //   this.movecount++;
    //   this.scrolLeft =  $('#slide-wrap')[0].scrollLeft + this.timeslotWidthScroll;
    //   $('#slide-wrap').animate({scrollLeft: '+=' + this.timeslotWidthScroll + 'px'});
    //   $('.epgProgramColumn').animate({scrollLeft: '+=' + (this.timeslotWidthScroll) + 'px'});
    // }
  }
  private extractSeasonnumber(content) {
    let rx, arr;
    rx = /season-(.*)/g;
    arr = rx.exec(content);
    return arr[1];
  }
    private loadOnChange() {
    // api integation
    let config, dataObject, userType;
         config = {
            apiKey: ' ',
            username: ' ',
            password: ' ',
            accessToken: ' ',
            withCredentials: false
          };

          this.processPending = true;
        dataObject = new TvShowApi(this.http, null, config);
        userType = this.commonService.getUserType();
     dataObject.v1TvshowByIdGet(this.id, null, this.country_code, null, null, userType).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
      this.apiRetryCount = 1;
      this.tvshowData = value;
      this.seasons = value.seasons;
      this.setSeason();
      this.setData(value);
      this.processPending = false;
      this.dataAvailable = true;
     }, err => {
    $('#loaderPage').css('display', 'none');
    this.gtm.sendErrorEvent('api', err);
    if (err.status === 401 && this.apiRetryCount <= apiRetry) {
      this.apiRetryCount ++;
      this.processPending = true;
      this.commonService.refreshToken().then(
        () => {
          this.loadOnChange();
        },
        () => {
          this.processPending = true;
          this.dataAvailable = false;
      	  this.headerservicesService.breadCrump('');
        },
        );
    }  else {
      this.processPending = false;
      this.dataAvailable = false;
      this.headerservicesService.breadCrump('');
    }
    });
    window.scrollTo(0, 0);
  }

  private setSeason(): any {
    this.selectedSeason = this.seasons.findIndex(season => season.orderid === this.selectedSeasonOrderid);
    if (this.selectedSeason === -1) {
      this.selectedSeason = 0;
      this.selectedSeasonOrderid = this.seasons[this.selectedSeason].orderid;
      this.tvshow.season_id = this.seasons[this.selectedSeason].id;
    }
  }

  public setData(value): any {
  	// this.setTotalPages()
    this.seasons_length = value.seasons.length;
  	this.setTvshow();
  	this.setEpisodeList();
  	if (this.tvshowData.extended) {
        this.sort_order = ((this.tvshowData.extended.broadcast_state !== (null || undefined)) && this.tvshowData.extended.broadcast_state === 'ARCHIVE') ? 'ASC' : 'DESC';
    }
    let tempTitle, show_title;
    this.urlcategory =   (value.asset_subtype === 'original') ? 'zee5originals/details' : 'tvshows/details';
     // if (value.extended && value.extended.seo_title) {
     //  tempTitle = (value.extended.seo_title !== null || value.extended.seo_title !== undefined || value.extended.seo_title !== '') ? value.extended.seo_title : value.original_title;
     // } else {
     //  tempTitle = (value.seo_title && (value.seo_title !== null || value.seo_title !== undefined || value.seo_title !== '')) ? value.seo_title : value.original_title;
     // }
    tempTitle = value.original_title;
    show_title = this.commonService.convertToLowercase(tempTitle);
    if (window.location.pathname.indexOf(this.urlcategory) < 0 || show_title !== this.name) {
        this.name = show_title;
        if (this.selectedSeasonOrderid !== 1) {
            this.location.replaceState(this.urlcategory + '/' + show_title + '/' + this.id + '/' + 'season-' + this.tvshowData.seasons[this.selectedSeason].orderid + '/episodes');
        } else {
            this.location.replaceState(this.urlcategory + '/' + show_title + '/' + this.id + '/episodes');
        }
    }

    this.setCanonical();
    this.updateMeta();
    this.setGA();
    this.setBreadcrumb();
    this.seasonschemaUpdate();
    this.setSeo();
    this.setArrows(this.seasons_length);
  }


  public setTvshow(): any {
    this.availableChannelOriginal = (this.tvshowData.channels && this.tvshowData.channels !== (null && undefined) && this.tvshowData.channels.length > 0) ? this.tvshowData.channels.map(function(elem) {return elem.original_title; }).join(', ') : 'NA';
    this.assetType = (this.tvshowData.asset_subtype && this.tvshowData.asset_subtype != null && this.tvshowData.asset_subtype === 'original') ? 'Original' : 'Show';
    this.tvShowGenre = (this.tvshowData.genres && this.tvshowData.genres !== (null && undefined) && this.tvshowData.genres.length > 0) ? this.tvshowData.genres.map(function(elem) {return elem.value; }).join(', ') : 'NA';
    this.tvShowsGenreEng = (this.tvshowData.genres && this.tvshowData.genres !== (null && undefined) && this.tvshowData.genres.length > 0) ? this.tvshowData.genres.map(function(elem) {return elem.id; }).join(',') : '';
  	this.actorDetails = [];
  	if ( this.tvshowData.actors && this.tvshowData.actors.lenght > 0 && this.tvshowData.actors[0] != null) {
        for (let i = 0; i < this.tvshowData.actors.length; i++) {
            this.actorDetails[i] = {
              '@type': 'Person', 'name': this.tvshowData.actors[i]
            };
        }
    }
    if (!this.tvshowData.countries) {
        this.tvshowData['countries'] = ['IN'];
    }
    let language_array;
    language_array = [];
    for (let j = 0; j < this.tvshowData.languages.length; j++ ) {
      let language = this.configData.languages_labels['en'][this.tvshowData.languages[j]];
      language = (language_array !== undefined) ? language_array : this.tvshowData.languages[j];
      language_array.push(language);
    }
    if (language_array && language_array.length > 0) {
    	this.languagesEng = language_array.join(',');
    } else {
    	this.languagesEng = '';
    }

  	this.tvshow = {
      originalShowName: this.tvshowData.original_title,
      showName: this.tvshowData.showName,
      showId: this.tvshowData.id,
      allChannel: this.availableChannelOriginal,
      business_type: this.tvshowData.business_type,
      assetType: this.assetType,
      genres: this.tvshowData.genres.map(function(elem) {return elem.id; }).join(', '),
      original_title: this.tvshowData.original_title,
      assetSubtype: this.tvshowData.asset_subtype,
    };
  }

  private setBreadcrumb(): any {
    let breadCrumbArray;
    breadCrumbArray = [{'label': 'BREADCRUMB.HOME', 'url': '/', 'enable': true},
    {'label': (this.tvshowData.asset_subtype === 'original' ) ? 'BREADCRUMB.ZEEORIGINALS' : 'BREADCRUMB.SHOWS', 'url': (this.tvshowData.asset_subtype === 'original' ) ?  '/zee5originals' : '/tvshows' , 'enable': true},
    {'label': this.tvshowData.title, 'url': this.urlcategory + '/' + this.commonService.convertToLowercase(this.tvshowData.original_title) + '/' + this.tvshowData.id, 'enable': true}];
    this.headerservicesService.breadCrump(breadCrumbArray);
  }

    private updateMeta(): any {
        this.image_url = ( this.tvshowData.list_image != null ) ? this.settingsService.getbasePathNew() + this.id + '/list/' + '1920x770/' + this.tvshowData.list_image  + '?imwidth=1920&impolicy=akamai_vidz1_zee5_com-IPM' : this.onErrorBanner;
  	    this.metaService.updateTag({ property: 'og:image', content: this.image_url, itemprop: 'image' });
        this.metaService.updateTag({ property: 'og:image:url', content: this.image_url, itemprop: 'image' });
        this.metaService.updateTag({ property: 'og:image:type', content: 'image/png' });
        this.metaService.updateTag({ name: 'twitter:image', content: this.image_url});
    }
    private setGA(): void {
	    let pageName;
	    pageName = this.languagesEng + 'Episode' + this.tvShowsGenreEng + '|' +  this.availableChannelOriginal + '|' +  this.tvshowData.originalTitle;
	    this.gtm.sendPageName(pageName);
	    this.gtm.sendTvChannel(this.availableChannelOriginal);
	    this.gtm.sendEvent();
  	}

  private setCanonical(): void {
    if (this.selectedSeason !== 0) {
	    this.linkservice.addTag({ rel: 'canonical', href: window.location.origin + '/' + this.routeservice.getBaseLocation()  +  this.urlcategory + '/' + this.commonService.convertToLowercase(this.tvshowData.original_title) + '/' + this.id + '/' + this.tvshowData.seasons[this.selectedSeason].orderid + '/episodes' } );
	} else {
	    this.linkservice.addTag({ rel: 'canonical', href: window.location.origin + '/' + this.routeservice.getBaseLocation()  +  this.urlcategory + '/' + this.commonService.convertToLowercase(this.tvshowData.original_title) + '/' + this.id + '/episodes' } );
	}
  }

  private setSeo(): any {
  	let seasonData, track;
  	seasonData = this.tvshowData.seasons[this.selectedSeason];
    track = seasonData && seasonData.episodes && seasonData.episodes[0] && seasonData.episodes[0].video_details && seasonData.episodes[0].video_details.audiotracks && seasonData.episodes[0].video_details.audiotracks[0] ? seasonData.episodes[0].video_details.audiotracks[0] : 'NA';
    this.seoService.blueKaifunction(
	   this.tvshowData.original_title,
	   this.tvshowData.asset_subtype,
	   this.assetType,
	   'NA',
	   this.tvShowGenre,
	   track
	);
    this.metatagUpdate(seasonData, track);
  }

  private metatagUpdate(seasonData, track): void {
    let karenjitKaur;
     karenjitKaur = '0-6-tvshow_984782182';
     let tempTitle;
     if (this.tvshowData && this.tvshowData.extended && this.tvshowData.extended.seo_title) {
          tempTitle = (this.tvshowData.extended.seo_title !== null || this.tvshowData.extended.seo_title !== undefined || this.tvshowData.extended.seo_title !== '') ? this.tvshowData.extended.seo_title : this.tvshowData.original_title;
      } else {
          tempTitle = (this.tvshowData.seo_title && (this.tvshowData.seo_title !== null || this.tvshowData.seo_title !== undefined || this.tvshowData.seo_title !== '')) ? this.tvshowData.seo_title : this.tvshowData.original_title;
      }
     if (this.assetType === 'Original') {
       if (this.id === karenjitKaur) {
         this.KarenjitKaur(seasonData);
       } else {
         this.seoService.originalsEpisodes(tempTitle, seasonData.orderid, track, this.tvShowsGenreEng);
       }
     } else if (this.tvshowData.countries[0] !== 'IN' && (this.tvshowData.countries[0].toLowerCase().indexOf('india') < 0)) {
         this.seoService.internationalEpisodepage(tempTitle, seasonData.orderid, track, this.tvShowsGenreEng);
     } else {
         this.seoService.showPagesEpisode(tempTitle, this.availableChannelOriginal, track, this.tvShowsGenreEng);
    }
  }
private KarenjitKaur(seasonData): void {
   let obj;
    obj = [];
    if (seasonData.title === 'Season 1') {
      obj[0] = 'View All Episodes of Karenjit Kaur: The Untold Story of Sunny Leone - Season 1 (Hindi) ZEE5 Originals Series Online | {ZEE5} | (Drama)', obj[1] = 'Browse all episodes of Karenjit Kaur: The Untold Story of Sunny Leone - Season 1, a ZEE5 Original web series online in full HD anytime, anywhere only on ZEE5.';
      this.seoService.update(obj[0], obj[1]);
    } else if (seasonData.title === 'Season 2') {
      obj[0] = 'Watch Karenjit Kaur: The Untold Story of Sunny Leone - Season 2  Online | {ZEE5} | (Drama)', obj[1] = 'Watch all episodes of Karenjit Kaur: The Untold Story of Sunny Leone - Season 2. Watch Sunny Leone\92s biopic, a ZEE5 Original web series online in full HD only on ZEE5.';
      this.seoService.update(obj[0], obj[1]);
    }
}

private seasonschemaUpdate(): void {
		    let seasonData;
    		seasonData = this.tvshowData.seasons[this.selectedSeason];
              const json_ld = {
                    '@context': 'http://schema.org',
                    '@type': 'TVSeries',
                    'actor': this.actorDetails,
                    'name': this.tvshowData.original_title,
                  };
                     json_ld['containsSeason'] = [
                                {
                                      '@type': 'TVSeason',
                                      'datePublished': this.formatDate(this.tvshowData.release_date),
                                      'episode': {
                                        '@type': 'TVEpisode',
                                        'episodeNumber': '1',
                                        'name': 'Episode 1'
                                      },
                                      'name': seasonData.original_title,
                                      'numberOfEpisodes': seasonData.episodes.length,
                                      'aggregateRating': {
                                       '@type': 'AggregateRating',
                                       'ratingValue': this.tvshowData.rating
                                      }
                                    }
                      ];
                     let script;
                     script = document.createElement('script');
                     script.id = 'schema';
                     script.type = 'application/ld+json';
                     script.innerHTML = JSON.stringify(json_ld);
                     if (document.getElementById('seasondetailsMarkup')) {
                     document.getElementById('seasondetailsMarkup').appendChild(script);
                   }


}

  public setEpisodeList(): any {
  	this.episodeList = [];
  	this.totalPages  = [];
  	this.load_count  = [];
  	for (let i = 0; i < this.seasons.length; i++) {
  		this.load_count.push(1);
  		this.totalPages.push(Math.ceil(this.seasons[i].total_episodes / this.tvshowData.limit));
  		if (this.seasons[i].total_episodes && this.seasons[i].episodes && this.seasons[i].episodes.length > 0) {
            if ((this.tvshowData.asset_subtype === 'original' || this.tvshowData.asset_subtype === 'tvshow') && this.tvshowData.business_type.indexOf('premium') !== -1 && this.tvshowData.seasons[i].sample_premiums && this.tvshowData.seasons[i].sample_premiums.length > 0) {
            	this.episodeList[i] = this.tvshowData.seasons[i].sample_premiums;
            	this.episodeList[i].concat(this.seasons[i].episodes);
  			} else {
	  			this.episodeList[i] = this.seasons[i].episodes;
  			}
  		} else {
  			this.episodeList[i] = [];
  		}
  	}
    $('#loaderPage').css('display', 'none');
  }

  private loadMore() {
  	if (!this.processPending) {
       if (this.load_count[this.selectedSeason] < this.totalPages[this.selectedSeason]) {
         this.load_count[this.selectedSeason] ++;
         $('.auto-loader').css('display', 'block');
         let dataObject1, onair;
         this.processPending = true;
         dataObject1 = new SeasonApi(this.http, null, null);
          onair = (this.sort_order === 'ASC') ? false : true;
             dataObject1.v1SeasonByIdGet(this.seasons[this.selectedSeason].id, 'episode', this.load_count[this.selectedSeason], null, null, null, onair, null, this.country_code).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
                this.apiRetryCount = 1;
                this.episodeList[this.selectedSeason] = this.episodeList[this.selectedSeason].concat(value.episode);
                this.processPending = false;
                 $('.auto-loader').css('display', 'none');
              },
             error =>   {
                this.processPending = false;
                if (error.status === 401 && this.apiRetryCount < apiRetry) {
                    this.apiRetryCount ++;
                    this.commonService.refreshToken().then(
                          () => {
                            this.loadMore();
                          },
                          () => {
                           $('.auto-loader').css('display', 'none');
                          },
                          );
                      } $('.auto-loader').css('display', 'none');
                    });
         }
  	}
  }

  public openSeason(orderid, index): any {
    if (orderid !== 1) {
        this.routerLink.navigate([this.urlcategory + '/' + this.name + '/' + this.id + '/' + 'season-' + this.tvshowData.seasons[index].orderid + '/episodes']);
    } else {
        this.routerLink.navigate([this.urlcategory + '/' + this.name + '/' + this.id + '/episodes']);
    }
  }

  private formatDate(val): any {
  let today, d, m, yyyy, dd, mm, dateFormat;
 today = new Date(val);
 d = today.getDate();
 m = today.getMonth() + 1;
 yyyy = today.getFullYear();
 dd = (d < 10) ? '0' + d : d;
 mm = (m < 10) ? '0' + m : m;
 dateFormat =  yyyy + '-' + mm + '-' + dd;
return dateFormat;
}

 public ngOnDestroy(): any {
   $('body').css('pointer-events', '');
   this.ngUnsubscribe.next();
   this.ngUnsubscribe.complete();
   this.linkservice.removeCanonicalLink();
   this.gtm.sendTvChannel('');
   this.metaService.updateTag({ property: 'og:image', content: 'https://www.zee5.com/assets/common/Splash.jpg', itemprop: 'image' });
   this.metaService.updateTag({ property: 'og:image:url', content: 'https://www.zee5.com/assets/common/Splash.jpg', itemprop: 'image' });
   this.metaService.updateTag({ property: 'og:image:type', content: 'image/png' });
   this.metaService.updateTag({ name: 'twitter:image', content: 'https://www.zee5.com/assets/common/Splash.jpg'});
   $('#breadcrumInit').css('top', '90px');
 }
}
