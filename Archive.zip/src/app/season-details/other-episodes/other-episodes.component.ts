
import { Component, OnInit , Input, ViewChild , HostListener, Output, ElementRef, EventEmitter} from '@angular/core';
import * as $ from 'jquery';
import {MdMenuTrigger} from '@angular/material';
import { Location , isPlatformBrowser} from '@angular/common';
import { Router } from '@angular/router';
import { HeaderservicesService } from '../../services/headerservices.service';
import { UserProfileService } from '../../services/user-profile.service';
import {FavoritesApi, WatchlistApi } from '../../../data/user/api/api';
// import {FavoritesApi, RemindersApi, UserApi, WatchHistoryApi, WatchlistApi } from '../../../data/user/api/api';
import { Http} from '@angular/http';
// import * as api from '../../../data/catalog/api/api';
import { environment } from '../../../environments/environment';
import { SettingsService } from '../../services/settings.service';
import { VideoService } from '../../services/video.service';
import { GoogleAnalyticsService } from '../../services/google-analytics.service';
import 'rxjs/add/operator/timeout';
import { SubscriptionService } from '../../services/subscription.service';
import { CommonService } from '../../services/common.service';
import {  Inject, PLATFORM_ID } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { VideoAnalyticsService } from './../../services/video-analytics.service';


declare const qg;

@Component({
  selector: 'app-other-episodes',
  templateUrl: './other-episodes.component.html',
  styleUrls: ['./other-episodes.component.less']
})
export class OtherEpisodesComponent implements OnInit {
  private readText: any = 'DETAILS.READ_MORE';
  private textLimit: any = 200;
  @Input() public episodeInfo: any;
  @Input() private episodeData: Array<any>;
  @Input() private allChannel: any;
  // @Input() private storedData: any;
  // @Input() private storedWatchData: any;
  @Input() private dataFromParent: any;
  @Input() private xIndex: any = 'NA';
  @ViewChild(MdMenuTrigger) public trigger: MdMenuTrigger;
  @Output()
  public change: EventEmitter<any> = new EventEmitter<any>();
  @Output()
  public popupevent: EventEmitter<any> = new EventEmitter<any>();
  private episodeDetails: any;
  private starContainer: string[];
  private show_description: boolean;
  private menuOpen: any;
  private watched: any;
  private favorite: any;
  private duration: any;
  private index: number;
  private read: string;
  private showReadMore: boolean;
  private showdata: boolean;
  private image_url: string;
  private indexOfitem: any;
  private showShare: boolean;
  private modalVideoPopup: boolean;
  private data: any;
  private loginToken: any;
  private contentUrl: any;
private purchasedAssetType;
private showSubPopUp;
private showSubPopUpSettings;
 // for error handling
 private episodeTitle: string;
 private episodeDescription: string;
 private episodeNumber: any;
 private episodeDate: any;
 private shareUrl: string;

 private episodeUniqueData: any;
 private tvshowid: string;
 private basepath: any;
 private showDiv: boolean;
 private assetbasepath: any;
 private premium: any;
private showPremium = true;
private window: any;
public zeeOriginalShow = false;
public thumbnailClickEvent: any;
public userToken: any;
public threeDotClickEvent: any;
public configValue: any;


  constructor(private commonService: CommonService, @Inject(PLATFORM_ID) private platformId: Object, private subscription: SubscriptionService, private videoService: VideoService, private gtm: GoogleAnalyticsService, private settingsService: SettingsService, private http: Http, private userProfileService: UserProfileService, private location: Location, private router: Router, private headerservicesService: HeaderservicesService, private videoAnalyticsService: VideoAnalyticsService,  private translate: TranslateService) {
   this.userProfileService.favourite.subscribe(value => {
    this.favorite = this.userProfileService.inList('favorite', this.episodeInfo.id);
     });
   this.userProfileService.watchlater.subscribe(value => {
                  this.watched = this.userProfileService.inList('watchList', this.episodeInfo.id);
    });

  }

  public ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.window = window;
    }
    this.showPremium = true;
         this.menuOpen = false;
        this.episodeInfo.indexofText = 200;
        this.showdata = false;
         this.loginToken = localStorage.getItem ( 'token' );
        this.episodeInfo.readText = 'DETAILS.READ_MORE';
        this.watched = false;
        this.favorite = false;
        this.assetbasepath = environment.assetsBasePath;
       this.basepath = this.settingsService.getbasePath();
        this.showDiv = (window.innerWidth > 770) ? true : false;
        let currentCountry, plans;
        currentCountry = this.settingsService.getCountryValueNew();
        plans = this.subscription.checkPlanApiSuccess(false);
        this.userToken = localStorage.getItem('token');
        this.configValue = this.settingsService.getCompleteConfig();


    if (plans.indexOf('6') >= 0) {
      plans.push('1');
    }
    if (currentCountry && currentCountry[0] && currentCountry[0].menu_options.premium_tag === 'no' && plans && plans.length > 0 && plans.indexOf(this.episodeInfo.asset_type.toString()) >= 0) {
      this.showPremium = false;
    }
    if (this.episodeInfo.business_type === undefined) {
      this.episodeInfo.business_type = this.dataFromParent.business_type;
    }
         if (this.episodeInfo.business_type.indexOf('premium') !== -1) {
             this.premium = ((this.dataFromParent.assetType === 'Original'  || this.dataFromParent.assetType === 'Show') && this.episodeInfo.asset_subtype === 'sample_premium') ? false : true;
         } else {
           this.premium = false;
         }
         let starImg, base;
           starImg = this.assetbasepath + 'assets/common/star_filled_icon.png';
      this.episodeInfo.starContainer =
      [starImg, starImg, starImg, starImg, starImg
       ];

     this.episodeInfo.show_description = false;
     if (this.episodeInfo.rating) {
        for (let i = 0; i < this.episodeInfo.starContainer.length; i++ ) {
          this.episodeInfo.starContainer[i] = ( i < this.episodeInfo.rating ) ? this.assetbasepath + 'assets/common/star_filled_icon.png' : this.assetbasepath + 'assets/common/star_empty_icon.png';
        }
      }

      // error handeling
      this.episodeTitle = (this.episodeInfo.title && this.episodeInfo.title != null) ? this.episodeInfo.title : '';
      this.episodeDescription = (this.episodeInfo.description && this.episodeInfo.description != null && this.episodeInfo.description.length > 0) ? this.episodeInfo.description : '';
       // api not intergrated
       this.episodeNumber = (this.episodeInfo.index && this.episodeInfo.index != null) ? this.episodeInfo.index : '';
       if ( this.episodeInfo.release_date != null ) {
          this.episodeDate = this.episodeInfo.release_date;
       }
       let loginToken, paramsvalue, scope;
      loginToken = localStorage.getItem ( 'token' );
      paramsvalue = 'bearer ' + loginToken;
      if ( loginToken != null) {
      this.loadFavWatchData();
    	}
    scope = this;
        $(window).scroll(function() {
          if ( scope.menuOpen === true && (navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i) || window.innerWidth < 769)) {
           scope.trigger.closeMenu();
          scope.menuOpen = false;
        }
        });
        $( window ).on( 'orientationchange', function( event ) {
      if (scope.menuOpen === true && (navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i) || window.innerWidth < 769)) {
        scope.trigger.closeMenu();
        scope.menuOpen = false;
      }
    });


      this.duration =  (this.episodeInfo.duration && this.episodeInfo.duration != null ) ? this.updateTime(this.episodeInfo.duration) : '';

        this.showReadMore = (this.episodeInfo.description && this.episodeInfo.description != null && this.episodeInfo.description.toString().length >   this.episodeInfo.indexofText )  ? true : false;
        base = (this.dataFromParent.assetType === 'Original')  ? 'zee5originals/details/' : 'tvshows/details/';

        // image construction
        this.image_url = (this.episodeInfo.list_image && this.episodeInfo.list_image != null ) ? this.commonService.getEpisodeUrl(this.episodeInfo.release_date, this.dataFromParent.originalShowName, this.episodeInfo, '270x152/') : this.assetbasepath + 'assets/default/tvshow.png';
         this.shareUrl = base + this.commonService.convertToLowercase(this.dataFromParent.showName) + '/' + this.dataFromParent.showId + '/' + this.commonService.convertToLowercase(this.episodeInfo.title) + '/' + this.episodeInfo.id;
       this.contentUrl = environment.shareUrl + this.shareUrl.split(' ').join('');
      }


private loadFavWatchData() {
   // if (this.storedData == null ) {
   // this.storedData = this.userProfileService.getFavoriteData();
   // }
   // if ( this.storedWatchData == null) {
   // this.storedWatchData = this.userProfileService.getWatchData();
   // }
   //   for ( let index = 0; index < this.storedData.length; index++) {
   //      if ( this.storedData[index].id === this.episodeInfo.id) {
   //        this.favorite = true;
   //      }
   //    }
   //    for ( let index1 = 0; index1 < this.storedWatchData.length; index1++ ) {
   //      if ( this.storedWatchData[index1].id === this.episodeInfo.id) {
   //        this.watched = true;
   //      }
   //    }
    this.favorite = this.userProfileService.inList('favorite', this.episodeInfo.id);
    this.watched = this.userProfileService.inList('watchList', this.episodeInfo.id);
  }


  private toggle_description() {
    this.episodeInfo.show_description = (this.episodeInfo.show_description) ? false : true;
  }

  private watchNow (event: any): void {
         let token, bearer, ctaString;
        ctaString = this.watched ? 'remove from watchlist' : 'add to watchlist';
        token = localStorage.getItem('token');
        bearer = 'bearer ' + token;
           let config;
          config = {
            apiKey: bearer,
            username: ' ',
            password: ' ',
            accessToken: ' ',
            withCredentials: false
          };
         if ( this.loginToken != null ) {
          event.stopPropagation();
          event.preventDefault();
           event.target.src = this.assetbasepath + 'assets/common/loaderWhite.svg';
           let watchListRequest, requestWatch;
                       watchListRequest = new  WatchlistApi(this.http, null, config);
          if (this.watched === true ) {
            let gener = '';
            gener = ( this.episodeInfo.genre != null ) ? this.episodeInfo.genre.toString() : 'NA';
                     requestWatch = watchListRequest.v1WatchlistDelete(this.episodeInfo.id, this.episodeInfo.asset_type).timeout(environment.timeOut).subscribe(value => {
                      this.watched = false;
                      event.target.src = this.assetbasepath + 'assets/common/watch_later_icon_normal.png';
                      this.commonService.qgraphevent('TVshowssection_added_to_watch_later', {'program_name': this.episodeInfo.title , 'channel_name': this.dataFromParent.allChannel , 'genre': gener, 'time_spent': '', 'language': '', 'episode_number': this.episodeInfo.index, 'episode_name': this.episodeInfo.title, 'country': this.settingsService.getCountry()});
                      this.userProfileService.removeWatchData(this.episodeInfo);
                    },
                    err => {
                      this.watched = true;
                      event.target.src = this.assetbasepath + 'assets/common/watch_later_icon_selected.png';
                      this.gtm.sendErrorEvent('api', err);
                    });
          } else {
              let obj;
              obj = this.userProfileService.createObject(this.episodeInfo);
             requestWatch = watchListRequest.v1WatchlistPost(obj).timeout(environment.timeOut).subscribe(value => {
                      this.watched = true;
                      event.target.src = this.assetbasepath + 'assets/common/watch_later_icon_selected.png';
                      this.userProfileService.setWatchData(this.episodeInfo);
                    },
                    err => {
                      this.watched = false;
                      event.target.src = this.assetbasepath + 'assets/common/watch_later_icon_normal.png';
                      this.gtm.sendErrorEvent('api', err);
                    });
          }
      } else {
         // this.popupevent.emit();
          this.headerservicesService.signReminderChange(true);
      }
      this.gtm.logEvent(this.threeDotEvent(ctaString));
      }

      private addFavorite(event: any): void {
          let ctaString;
          ctaString = this.favorite ?  'remove from favourite' : 'add to favourite';
           let token, bearer;
           token = localStorage.getItem('token');
        bearer = 'bearer ' + token;
           let config;
          config = {
            apiKey: bearer,
            username: ' ',
            password: ' ',
            accessToken: ' ',
            withCredentials: false
          };

          let favoritesRequest, requestFav;
                            favoritesRequest = new  FavoritesApi(this.http, null, config);
         if ( this.loginToken != null ) {
          event.target.src = this.assetbasepath + 'assets/common/loaderWhite.svg';
          event.stopPropagation();
          if (this.favorite === true ) {
                  favoritesRequest.v1FavoritesDelete(this.episodeInfo.id, this.episodeInfo.asset_type).timeout(environment.timeOut).subscribe(value => {
                    this.favorite = false;
                    event.target.src = this.assetbasepath + 'assets/common/fav_icon_normal.png';
                    this.userProfileService.removeFavoriteData(this.episodeInfo);
                  },
                  err => {
                    this.favorite = true;
                    event.target.src = this.assetbasepath + 'assets/common/fav_icon_selected.png';
                    this.gtm.sendErrorEvent('api', err);
                  });
          } else {
                  let obj;
                  obj = this.userProfileService.createObject(this.episodeInfo);
                  requestFav = favoritesRequest.v1FavoritesPost(obj).timeout(environment.timeOut).subscribe(value => {
                    this.favorite = true;
                    event.target.src = this.assetbasepath + 'assets/common/fav_icon_selected.png';
                    this.userProfileService.setFavoriteData(this.episodeInfo);
                  },
                  err => {
                    this.favorite = false;
                    this.gtm.sendErrorEvent('api', err);
                  });
          }
        } else {
          // this.popupevent.emit();
          this.headerservicesService.signReminderChange(true);
        }
         this.gtm.logEvent(this.threeDotEvent(ctaString));

      }

  private showMenu_1(): void {
   let scope;
    scope = this;
    this.menuOpen = true;
    if (navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
      // todo
    } else {
      if (window.innerWidth > 769) {

        $('.cdk-overlay-backdrop').css('pointer-events', 'none');
        $(document).mouseup(function(e) {
          let container;
          container = $('.mat-menu-content');
                // if the target of the click isn't the container nor a descendant of the container
                if (!container.is(e.target) && container.has(e.target).length === 0 && scope.menuOpen === true) {
                  scope.trigger.closeMenu();
                  scope.menuOpen = false;
                }
            });
      }
    }
   }

  private updateTime(s: number): any {
      let secs, mins, hrs, secs_new, mins_new, time , tokenValue, display;
        tokenValue = localStorage.getItem('token');
        if (tokenValue) {
            display = localStorage.getItem('UserDisplayLanguage');
          } else {
            display = localStorage.getItem('display_language');
          }
      if (s) {
        secs = s % 60;
        s = (s - secs) / 60;
        mins = s % 60;
        s = (s - mins) / 60;
        hrs = s % 60;
        if (mins < 10) {
          mins_new = '0' + mins;
        } else {
          mins_new = '' + mins;
        }
        if (secs < 10) {
          secs_new = '0' + secs;
        } else {
         secs_new = '' + secs;
        }
        if (display === 'ru') {
                time = (hrs ? hrs + 'ч' : '') + (mins ? (' ' + mins_new) + 'м' : '') + (secs ? (' ' + secs_new) + 'с' : '');
        } else {
                time = (hrs ? hrs + 'h' : '') + (mins ? (' ' + mins_new) + 'm' : '') + (secs ? (' ' + secs_new) + 's' : '');
        }
        return time;
      } else {
         time = '';
         return time;
      }
  }
     private toggleReadMore(): void {
       this.readText = (this.textLimit > 200) ? 'DETAILS.READ_MORE' :  'DETAILS.READ_LESS';
       this.textLimit = (this.textLimit > 200) ? 200 :  this.episodeInfo.description.toString().length;
      }

private playContent() {
      let base, tempTitle;
      this.commonService.updateCollectionId(null);
      this.commonService.setTalamoosData('', '', '');
      this.gtm.setContentClickDetails(this.xIndex, 0, '');
      // if (this.episodeInfo && this.episodeInfo.extended && this.episodeInfo.extended.seo_title) {
      //   tempTitle = (this.episodeInfo.extended.seo_title !== null || this.episodeInfo.extended.seo_title !== undefined || this.episodeInfo.extended.seo_title !== '') ? this.episodeInfo.extended.seo_title : this.episodeInfo.original_title;
      // } else {
      //   tempTitle = (this.episodeInfo.seo_title && (this.episodeInfo.seo_title !== null || this.episodeInfo.seo_title !== undefined || this.episodeInfo.seo_title !== '')) ? this.episodeInfo.seo_title : this.episodeInfo.original_title;
      // }
        tempTitle = this.episodeInfo.original_title;
      base = (this.dataFromParent.assetType === 'Original')  ? 'zee5originals/details/' : 'tvshows/details/';
      // this.gtm.GAsubCategory = 'seasons';
      this.router.navigate([base , this.commonService.convertToLowercase(this.dataFromParent.originalShowName) , this.dataFromParent.showId , this.commonService.convertToLowercase(tempTitle) , this.episodeInfo.id]);
}
    private startVideoEpisode() {
        this.playContent();
    }

    private closeShare(event: any): any {
        this.showShare = false;
      }

      private share(event: any): void {
        event.stopPropagation();
        this.showShare = true;
        this.gtm.logEvent(this.threeDotEvent('share'));
      }

      private stopEvent(event: any) {
        event.stopPropagation();
      }

       private onResize(event: any): void {
         this.showDiv = ( window.innerWidth > 770 ) ? true : false;
        }

   private imageError(event: any): void {
    if (event.srcElement) {
        event.srcElement.src = this.assetbasepath + 'assets/default/tvshow.png';
    } else {
        event.currentTarget.src = this.assetbasepath + 'assets/default/tvshow.png';
    }
  }

    public  clickGAEvents(eventname) {
       let availableChannelOriginal, langObj, userAccessType;
       availableChannelOriginal = (this.dataFromParent.allChannel && this.dataFromParent.allChannel !== (null && undefined) && this.dataFromParent.allChannel.length > 0) ? this.dataFromParent.allChannel.channels.map(function(elem) {return elem.original_title; }).join(', ') : 'NA';
       langObj = this.gtm.displayContentLan();
       userAccessType = this.commonService.getUserAccessType();
        this.zeeOriginalShow = (this.dataFromParent.asset_subtype === 'original') ? true : false;
         this.thumbnailClickEvent = {
            'event': eventname,
            'VideoName': this.episodeInfo.original_title ? this.episodeInfo.original_title : 'NA',
            'VideoCategory': this.episodeInfo.genres ? this.episodeInfo.genres.map(function(elem) {return elem.id; }).join(', ') : 'NA',
            'VideoSection': this.videoService.getVideoSection(this.episodeInfo.asset_type, this.dataFromParent.asset_subtype) || 'NA',
            'VideoSubTitle': this.episodeInfo.original_title || this.dataFromParent.original_title || 'NA',
            'TVChannels': availableChannelOriginal || 'NA' ,
            'VideoDuration': this.episodeInfo.duration || 0,
            'VideoStartTime': this.episodeInfo.start_time ? this.episodeInfo.start_time : 'NA',
            'Time_Slot': this.episodeInfo.time_slot || 'NA',
            'Episode_Number': this.zeeOriginalShow ? 'NA' : this.episodeInfo.index,
            'Tumbnail_Image': this.image_url,
            'Content_Specification': this.videoService.getContentSpec(this.episodeInfo.asset_subtype) || 'NA',
            'Content_Show': this.episodeInfo.original_title || this.dataFromParent.original_title || 'NA',
            'Content_Date': this.commonService.dateChange(this.episodeInfo.release_date) || 'NA',
            'PageName': this.gtm.getPageName(),
            'Previous_Screen': this.gtm.previousScreenName,
            'Vertical_Index': 0,
            'Horizontal_Index': this.xIndex || (this.xIndex !== 0 ? 'NA' : this.xIndex),
            'SubCategory': 'NA',
            'modelName': 'NA',
            'clickID' : 'NA',
            'origin': 'NA',
            'CarousalCategory': 'Non-Talamoos',
            'TopCategory' : this.videoAnalyticsService.getTopCategory(this.dataFromParent.asset_subtype),
            'Video_Language' : this.commonService.getVideoLanguages(this.episodeInfo) || 'NA',
            'Content_ID': this.episodeInfo.id || 'NA',
            'Show_ID': (this.episodeInfo.asset_type === 1 ? (this.episodeInfo.tvshow_details ? this.dataFromParent.id : '') : this.episodeInfo.id) || 'NA',
            'Season_ID': this.episodeInfo.season_details.id || 'NA',
            'ShowSubtype': this.episodeInfo.asset_type === 0 ? this.episodeInfo.asset_subtype : ((this.episodeInfo.asset_type === 1 && this.dataFromParent && this.dataFromParent.asset_subtype) ? this.dataFromParent.asset_subtype : 'NA'),
            'Content_Lang': langObj.contentLang,
            'Display_Lang': langObj.displayLang,
            'Business_Type': (this.episodeInfo.business_type && this.episodeInfo.business_type.indexOf('premium') !== -1) ? 'Premium' : 'Free' || 'NA',
            'User_Access_Type': userAccessType,
            'G_ID': this.gtm.fetchToken(),
            'Client_ID': this.gtm.fetchClientId(),
            'TimeHHMMSS': this.gtm.fetchCurrentTime(),
            'DateTimeStamp': this.gtm.fetchCurrentDate()
      };
      this.gtm.logEvent(this.thumbnailClickEvent);
    }

    public threeDotEvent(ctadetails): any {
        let langObj, availableChannelOriginal;
        langObj = this.gtm.displayContentLan();
        availableChannelOriginal = (this.dataFromParent.allChannel && this.dataFromParent.allChannel !== (null && undefined) && this.dataFromParent.allChannel.length > 0) ? this.dataFromParent.allChannel.channels.map(function(elem) {return elem.original_title; }).join(', ') : 'NA';
        return {
          'event': 'buttonClicks',
          'PageName': this.gtm.getPageName(),
          'cta': ctadetails,
          'UserType': this.userToken ? 'loggedin' : 'guest',
          'ContentLang': langObj.contentLang,
          'DisplayLang': langObj.displayLang,
          'NetworkType': '',
          'GoogleID': this.gtm.fetchToken(),
          'VideoName': this.episodeInfo.original_title ? this.episodeInfo.original_title : 'NA',
          'VideoCategory': this.dataFromParent.genres ? this.dataFromParent.genres.map(function(elem) {return elem.id; }).join(', ') : 'NA',
          'VideoSection': this.videoService.getVideoSection(this.episodeInfo.asset_type, this.dataFromParent.asset_subtype) || 'NA',
          'VideoSubTitle': this.episodeInfo.original_title || this.dataFromParent.original_title || 'NA',
          'TVChannels': availableChannelOriginal || 'NA',
          'VideoDuration': this.episodeInfo.duration || 0,
          'VideoStartTime': this.episodeInfo.start_time ? this.episodeInfo.start_time : 'NA',
          'Time_Slot': this.episodeInfo.time_slot || 'NA',
          'Episode_Number': this.zeeOriginalShow ? 'NA' : this.episodeInfo.index,
          'Tumbnail_Image': this.image_url,
          'Content_Specification': this.videoService.getContentSpec(this.episodeInfo.asset_subtype) || 'NA',
          'Content_Show': this.episodeInfo.original_title || this.dataFromParent.original_title || 'NA',
          'Content_Date': this.commonService.dateChange(this.episodeInfo.release_date) || 'NA',
          'Vertical_Index':   0 ,
          'Horizontal_Index': this.xIndex || (this.xIndex !== 0 ? 'NA' : this.xIndex),
          'SubCategory': 'NA',
          'modelName': 'NA',
          'clickID': 'NA',
          'Click_Metrics': '1',
          'Carousal_Name': 'NA'
        };
      }

  /* Function to translate day and month */
  public getDateTranslate(date) {
      let month, dateString;
      dateString = (new Date(date)).toString().toUpperCase();
      month = dateString.split(' ')[1]; // fetch month
      return this.translate.instant('TVGUIDE.' + month);
  }

}
