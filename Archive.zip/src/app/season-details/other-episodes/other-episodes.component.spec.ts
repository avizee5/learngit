import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtherEpisodesComponent } from './other-episodes.component';

describe('OtherEpisodesComponent', () => {
  let component: OtherEpisodesComponent;
  let fixture: ComponentFixture<OtherEpisodesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtherEpisodesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtherEpisodesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
