import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared.module';
import { SeasonDetailsComponent } from './season-details.component';
import { DataUnavailableModule } from '../data-unavailable/data-unavailable.module';
import { HomeGridModule } from '../home-grid/home-grid.module';
import { OtherEpisodesComponent } from './other-episodes/other-episodes.component';
import { OtherEpisodelistComponent } from './other-episodelist/other-episodelist.component';
import { ShareoptionsModule } from '../share-options/share-options.module';
import { MdMenuModule, MdButtonModule } from '@angular/material';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';

const routes: Routes = [
    {
        path: '',
        component: SeasonDetailsComponent,
    },
];
@NgModule({
  exports: [RouterModule],
  imports: [RouterModule.forChild(routes), CommonModule, SharedModule, HomeGridModule, DataUnavailableModule, ShareoptionsModule, MdMenuModule, MdButtonModule, InfiniteScrollModule],
  declarations: [SeasonDetailsComponent, OtherEpisodesComponent, OtherEpisodelistComponent]
})
export class SeasonDetailsModule { }
