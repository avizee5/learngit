import { Component, OnInit, ViewChild, ElementRef, HostListener, OnDestroy } from '@angular/core';              // importing explorecomponent to perform outside click function
import { HeaderservicesService } from '../services/headerservices.service';    // services for letiable update
import * as $ from 'jquery';
import { Subscription } from 'rxjs/Subscription';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { SettingsService } from '../services/settings.service';
import * as userApi from '../../data/user/api/api';
import { Http } from '@angular/http';
import { environment } from '../../environments/environment';
import { NetworkService } from '../services/network.service';
import { ActivatedRoute } from '@angular/router';
import { VideoService } from '../services/video.service';
import { FilterService } from '../services/filter.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { isPlatformBrowser } from '@angular/common';
import { Inject, PLATFORM_ID } from '@angular/core';
import { SubscriptionService } from '../services/subscription.service';
import { TranslateService } from '@ngx-translate/core';
import { RouteService } from '../services/route.service';
import {CommonService} from '../services/common.service';
 
@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.less']
})

export class HeaderComponent implements OnInit, OnDestroy {
    private languageView = false;
    public internationalFlag = false;
    public languageFlag = false;                                                                                                       // for signin component display none
    public register = true;                                                       // register/login init state
    private moreView = false;                                                      // initial moreview false state
    private searchView = false;                                                    // initial searchview false state
    private modelOpen = false;                                                     // to keep track of model open state in header, this letible is used
    private signinOpen: boolean;                                                   // track signinComponent
    private modalstatus = false;                                                   // for modelopen state when clicked outside
    public moreViewoutside = false;                                               // moreview clicked outside
    public signInFlag = false;
    public retrivedDrop = false;
    public searchFlag = false;
    public checkView: any;
    public tvguideImg: any;                                             // display button in view details of info card
    public showSignUpPromt: boolean;                                       // for displaying reminder pop up
    private timer: any;
    private scrolltimer: any;
    private timeinminute: number;
    private skipCount: number;
    private signup_times: number;
    public serachPng: any = environment.assetsBasePath + 'assets/common/search_icon.png';
    public morePng: any = environment.assetsBasePath + 'assets/common/more_icon.png';
    public downArrow: any = environment.assetsBasePath + 'assets/common/down_arrow.png';
    public upArrow: any = environment.assetsBasePath + 'assets/common/up_arrow.png';
    // logoPng: any = environment.assetsBasePath + 'assets/common/logonew50x50.png';
    public logoPng: any = environment.assetsBasePath + 'assets/common/ZEE5_Logo50x50.png';

    public userPng: any = environment.assetsBasePath + 'assets/common/user_icon.png';
    public hamburgerPng: any = environment.assetsBasePath + 'assets/common/hamburgerIcon.png';
    // zeePng: any = environment.assetsBasePath + 'assets/common/logo_tv_guide.png';
    public zeePng: any = environment.assetsBasePath + 'assets/common/ZEE5_Logo44x44.png';

    public mobileSearch: any = environment.assetsBasePath + 'assets/common/search-iconM.png';
    public languageSelection: any = environment.assetsBasePath + 'assets/common/change_language_icon.png';
    private profileDisplay = false;
    public profiledisplayOut = false;
    public routeCheck: any;
    public reminderText: string;                 // checking for popup
    public typeofpopup: string;
    public reminderText1: string;
    public typeofpopup1: string;
    public showSubsPromt: boolean;
    private configValue: any;
    private isVideoDisable = true;            // checking for video
    private localstorage: any;
    private window: any;
    private document: any;
    private navigator: any;
    public appLanguage: any;
    private configData: any;
    private countryListData: any;
    private countrycodeIndex: any;
    private countryList: any;
    public parentalFlag: any;
    public parentalType: any;
    public headerScroll: any;
    public headerScrollDisplay: boolean;
    private didScroll: any;                                   // check for scroll happens are not
    private lastScrollTop = 0;
    public requestData: any;                         // top value
    private delta = 5;
    private navbarHeight = 32;                              // scrollable header height
    public episodicPage = false;
    public currentTabHeader: any;
    public premium = 'MENU.PREMIUM';
    public sendValue = 'MENU.PREMIUM';
    public dialogSub = true;
    private clientID: any;
    private marketingValue: any;
    public weyyak = false;
    public weyyakUrl: any;
    public contentLangSignUp = false;
    public telcoPlanFlag = true;
    public mainmenudeatils = [];
    public startslice = 0;
    public endslice = 4;
    public hiddenTabs = [];
    public newsMenu;
    constructor(@Inject(PLATFORM_ID) private platformId: Object, private routeservice: RouteService, private translate: TranslateService, private sub: SubscriptionService, private gtm: GoogleAnalyticsService, private filterService: FilterService, private location: Location, private http: Http, public headerservicesService: HeaderservicesService, private route2: Router, private settingsService: SettingsService, private networkService: NetworkService, private route: ActivatedRoute, private videoService: VideoService, private commonService: CommonService) {
        let scope;
        scope = this;
        if (isPlatformBrowser(this.platformId)) {
            this.localstorage = localStorage;
            this.window = window;
            this.document = document;
            this.navigator = navigator;
        }
        if (this.localstorage.getItem('Z5') === null) {    // for app-language-slide component

            this.localstorage.setItem('Z5', 'false');
            this.appLanguage = true;
            this.timerBoarding();
        }
        this.headerservicesService.contentLanguageValue.subscribe(value => {
            this.contentLangSignUp = value.boolean;
        });
        this.headerservicesService.dialogValue.subscribe(value => {     // login view changes to reflect login/register icon
            this.dialogSub = false;
        });
        this.headerservicesService.menuOptionValue.subscribe(value => {     // login view changes to reflect login/register icon
            this.sendValue = value;
            if (value === false) {
                this.premium = 'MENU.EXCLUSIVE_CAPS';
                this.sendValue = 'MENU.EXCLUSIVE_CAPS';
            }
        });
        this.headerservicesService.weyyakValue.subscribe(value => {     // login view changes to reflect login/register icon
            this.weyyak = value.value;
            this.weyyakUrl = value.url;
        });
        this.headerservicesService.registerValue.subscribe(value => {     // login view changes to reflect login/register icon
            this.register = value;
        });
        this.headerservicesService.moreValue.subscribe(value => {      // when moreview is open and clicked outside update letible
            this.moreViewoutside = value;
        });
        this.headerservicesService.modelValue.subscribe(value => {       // when modelpopup open track of that
            this.modalstatus = value;
        });
        this.headerservicesService.viewValue.subscribe(value => {       // when view changes update view
            this.routeCheck = value;
            this.viewTrigger(value);
        });
        this.headerservicesService.profileDropValue.subscribe(value => {      // when profileView is open and clicked outside update letible
            this.profiledisplayOut = value;
        });
        this.headerservicesService.parentalValue.subscribe(value => {        // To differ pin popup r pasward
            this.parentalFlag = value.flag;
            this.parentalType = value.type;
            if (value.requestData) {
                this.requestData = value.requestData;
            }
        });
        this.headerservicesService.hamburgerValue.subscribe(value => {       // hamburger to close r open
            this.retrivedDrop = value;
        });
        this.headerservicesService.signinValue.subscribe(value => {          // signin
            this.signInFlag = value;
        });
        this.headerservicesService.internationalRegisterValue.subscribe(value => {          // signin
            this.internationalFlag = value;
        });
        this.headerservicesService.searchValue.subscribe(value => {         // search view
            this.searchFlag = value;
        });
        this.headerservicesService.languageValue.subscribe(value => {         // search view
            this.languageFlag = value;
        });
        this.headerservicesService.signInReminder.subscribe(value => {
            this.toggeleReminder(value);
        });
        this.headerservicesService.subscribeReminder.subscribe(value => {
            this.toggeleReminderSubs(value);
        });
        this.videoService.alertModalState.subscribe(value => {       // // checking for video model
            this.isVideoDisable = value;
        });
        this.headerservicesService.spotlightValue.subscribe(value => {  // when appLanguage slide control
            this.appLanguage = value;
        });
        this.headerservicesService.routeParamValue.subscribe(value => { // call the headerfunction when params changes
            scope.activeHeaderScroll();
        });
        this.headerservicesService.episodicPageSpace.subscribe(value => {     // scrollheader handling in episodic page
            this.episodicPage = value;
        });

        /*
        $(window).scroll(function(event) {   // for scroll function to start
          scope.didScroll = true;
          scope.headerScrollFunction()
        })      */
        $(this.window).scroll(function () {
            scope.check();
            scope.didScroll = true;
            scope.headerScrollFunction();
            // when scrooled down add background color
            if ($(this.window).scrollTop() === 0 && $('#networkPopup').css('display') === 'none') {
                if (scope.routeCheck === '/tvguide') {
                    $('#hideoutside').css('background-color', 'black');
                } else {
                    $('#hideoutside').css('background-color', '');
                }
            } else if ($(this.window).scrollTop() > 20 && $('#networkPopup').css('display') === 'none') {
                $('#hideoutside').css('background-color', 'black');

            }
            // if ($(this.window).scrollTop() <= 70) {
            //      $('#my-banner').show();
            //  }
            // Merging logic // fadeIn Fadeout for more model

            if ($(this.window).scrollTop() > 0) {
                if (scope.moreViewoutside === true) {
                    scope.headerservicesService.moreIcon(false);
                }
                if (scope.appLanguage === true) {
                    scope.headerservicesService.spotlightChange(false);
                    scope.headerservicesService.modelChange(false);
                }
                if (scope.profiledisplayOut === true) {
                    scope.headerservicesService.profileChange(false);
                }
            }
        });

        // check telco user for subscription
        this.sub.telcoUsersFlagSub.subscribe(value => {
            this.dialogSub = value ? false : true;
        });

        // check if telco user for my account
        this.sub.telcoUsersFlag.subscribe(value => {
            this.telcoPlanFlag = (value) ? true : false;
        });

        // check all access pack for subscription
        this.sub.storeAllAccessPack.subscribe(value => {
          this.dialogSub = value ? false : true;
        });
    }
    public ngOnDestroy() {
        if (this.timer) {
            clearInterval(this.timer);
        }
        if (this.scrolltimer) {
            clearInterval(this.scrolltimer);
        }
    }
    public ngOnInit() {
        // $('ul.navbar-nav li.nav-item').each(function (){
        //   if($(this).is(':hidden')){
        //     $('').append(this);
        //     console.log($(this));
        //   }
        // })
        this.gtm.storeWindowError();
        let scope;
        scope = this;
        if (isPlatformBrowser(this.platformId)) {
            this.localstorage = localStorage;
            this.window = window;
            this.document = document;
            this.navigator = navigator;
        }

	// if (this.localstorage.getItem('country_code') === 'IN') {
	//   originalMenu = 'MENU.ZEEORIGINALS'
	// }
	// else{originalMenu = 'MENU.ZEEORIGINALS_INT'}
    let germanLanguage = this.localstorage.getItem('token')? this.localstorage.getItem('UserDisplayLanguage'):this.localstorage.getItem('display_language') 
        if (this.localstorage.getItem('country_code') === 'DE' && germanLanguage === 'de') {
            this.newsMenu = 'MENU.NEWS_DE_CAPS';
        } else {
            this.newsMenu = 'NEWS_PAGE.NEWS';
        }
        this.headerservicesService.menuOptionValue.subscribe(value => {     // login view changes to reflect login/register icon
            this.sendValue = value;
            if ( value === false) {
                this.premium = 'MENU.EXCLUSIVE_CAPS';
                this.sendValue = 'MENU.EXCLUSIVE_CAPS';
            }
            this.mainmenudeatils = [
                {'id': 'home', 'name': 'MENU.DISCOVER_CAPS', 'order': '0'},
                {'id': 'premium', 'name': this.premium, 'order': '1'},
                {'id': 'tvshows', 'name': 'MENU.TVSHOWS_CAPS', 'order': '2'},
                {'id': 'movies', 'name': 'MENU.MOVIES_CAPS', 'order': '3'},
                // {'id': 'news', 'name': this.newsMenu, 'order': '4'},
                {'id': 'videos', 'name': 'MENU.VIDEOS_CAPS', 'order': '5'}
            ];
            this.dynamicCalculaton();
        });
        this.mainmenudeatils = [
            {'id': 'home', 'name': 'MENU.DISCOVER_CAPS', 'order': '0'},
            {'id': 'premium', 'name': this.premium, 'order': '1'},
            {'id': 'tvshows', 'name': 'MENU.TVSHOWS_CAPS', 'order': '2'},
            {'id': 'movies', 'name': 'MENU.MOVIES_CAPS', 'order': '3'},
            // {'id': 'news', 'name': this.newsMenu, 'order': '4'},
            {'id': 'videos', 'name': 'MENU.VIDEOS_CAPS', 'order': '5'}
        ];
        // this.mainmenudeatils = this.settingsService.getmainmenu();
        // this.mainmenuarray = this.mainmenudeatils ? this.mainmenudeatils: this.localstorage.getItem('mainmenu')
        // console.log(this.mainmenudeatils, 'this.mainmenu');

        this.activeHeaderScroll();
        this.configValue = environment.configFile;
        this.tvguideImg = environment.assetsBasePath + 'assets/common/tvguide.png';
        let token;
        token = this.localstorage.getItem('token');
        this.reminderText = 'LOGIN.LOGIN_INFO';
        this.typeofpopup = 'reminder';
        this.reminderText1 = 'SUSCRIPTION.SUBSCRIBE_INFO_PREMIUM';
        this.typeofpopup1 = 'subs';                                                          //
        if (token != null) {
            this.headerservicesService.addChanges(false);
        }
        $(this.document).mouseup(function (e) {
            this.container = $('#hideoutside');
            if (!this.container.is(e.target) && this.container.has(e.target).length === 0) {           // if clicked element is not your element and parents aren't your div
                if (scope.moreViewoutside === true) {
                    scope.headerservicesService.moreIcon(false);
                }
                if (scope.appLanguage === true) {
                    scope.headerservicesService.spotlightChange(false);
                    scope.headerservicesService.modelChange(false);
                }
                if (scope.profiledisplayOut === true) {
                    scope.headerservicesService.profileChange(false);
                }
            }
        });
        $(this.document).on('touchstart', function (e) {
            this.container = $('#hideoutside');
            if (!this.container.is(e.target) && this.container.has(e.target).length === 0) {           // if clicked element is not your element and parents aren't your div
                if (scope.moreViewoutside === true) {
                    scope.headerservicesService.moreIcon(false);
                }
                if (scope.appLanguage === true) {
                    scope.headerservicesService.spotlightChange(false);
                    scope.headerservicesService.modelChange(false);
                }
                if (scope.profiledisplayOut === true) {
                    scope.headerservicesService.profileChange(false);
                }
            }
        });
        if (window.innerWidth > 801) {
            setTimeout(() => {
                this.countryListData = this.settingsService.newCountryValue.subscribe(value => {
                    this.countryListData = value;
                    if (this.countryListData.length !== 0) {
                        this.countryList = this.countryListData;
                    }
                });
            }, 0);
        }
        this.skipCount = 0;

        // this.hiddenTabs.push({ 'id': 'livetv', 'name': 'GUIDED_TOUR.LIVE_TV', 'order': '6' });
  	    this.hiddenTabs.push({'id': 'zee5originals', 'name': 'MENU.ZEEORIGINALS',  'order': '7'});
        $(document).ready(function () {
            if (token) {
                $('#leftBarMaintab,#rightBarMaintab').addClass('lMenu');
            }
            scope.dynamicCalculaton();
        });
    }
    @HostListener('window:resize', ['$event'])           // display scrollable header only in mobile browser
    public activeHeaderScroll() {
        if (this.window.innerWidth < 769) {
            this.headerScroll = true;
            this.headerScrollDisplay = true;
        } else {
            this.headerScroll = false;
            this.headerScrollDisplay = false;
        }
        // alert('rezise')
        this.dynamicCalculaton();
    }
    private headerScrollFunction() {
        let scope;
        scope = this;


        if (scope.didScroll) {
            scope.hasScrolled();
            scope.didScroll = false;
        }
        /*
        this.scrolltimer = setInterval(function() {
            if (scope.didScroll) {
                scope.hasScrolled();
                scope.didScroll = false;
            }
        }, 250);
        */

// let originalMenu;
// if (this.localstorage.getItem('country_code') === 'IN') {
//   originalMenu = 'MENU.ZEEORIGINALS'
// }
// else{originalMenu = 'MENU.ZEEORIGINALS_INT'}
// this.headerservicesService.menuOptionValue.subscribe(value => {     // login view changes to reflect login/register icon
//   this.sendValue = value;
//   if ( value === false) { 
//       this.premium = 'MENU.EXCLUSIVE_CAPS';
//       this.sendValue = 'MENU.EXCLUSIVE_CAPS';
//     }
//     this.mainmenudeatils = [{'id':'premium','name':this.premium,'order':'1'},{'id':'tvshows','name':'MENU.TVSHOWS_CAPS','order':'2'},{'id':'movies','name':'MENU.MOVIES_CAPS','order':'3'},{'id':'news','name':this.newsMenu,'order':'4'},{'id':'videos','name':'MENU.VIDEOS_CAPS','order':'5'}]
//   });
//   this.mainmenudeatils = [{'id':'premium','name':this.premium,'order':'1'},{'id':'tvshows','name':'MENU.TVSHOWS_CAPS','order':'2'},{'id':'movies','name':'MENU.MOVIES_CAPS','order':'3'},{'id':'news','name':this.newsMenu,'order':'4'},{'id':'videos','name':'MENU.VIDEOS_CAPS','order':'5'}]
// this.mainmenudeatils = this.settingsService.getmainmenu();
// this.mainmenuarray = this.mainmenudeatils ? this.mainmenudeatils: this.localstorage.getItem('mainmenu')
    // console.log(this.mainmenudeatils, 'this.mainmenu');
    }
    private hasScrolled() {
        let st;
        st = ($(this.window).scrollTop());    // Make sure they scroll more than delta
        if (Math.abs(this.lastScrollTop - st) <= this.delta) {
            return;
        }
        if (st > this.lastScrollTop && st > this.navbarHeight) {    // Scroll Down
            this.headerScroll = false;
        } else {
            if (st + $(window).height() < $(document).height()) {     // Scroll Up
                this.headerScroll = true;
            }
        }
        this.lastScrollTop = st;
    }
    public tvguideSrc() {
        this.tvguideImg = environment.assetsBasePath + 'assets/common/tvguideSelect.png';
    }
    private timerBoarding = function () {
        const scope = this;
        this.timer = setInterval(function () {
            if (scope.appLanguage === true) {
                scope.headerservicesService.spotlightChange(false);
            }
        }, 5000);
    };
    public dynamicCalculaton(): any {
        let scope = this, token;
        token = this.localstorage.getItem('token');
        setTimeout(() => {
            let eachTab = 0, totaltab;
            $('.leftBar').children().each(function () {
                let $currentElement = $(this);
                // console.info($currentElement, $currentElement.attr('id'), $currentElement.outerWidth());
                // console.log(eachTab, 'totalTab', $('.leftBarMain').width());
                totaltab = $('#headerNavbar').width() - ($('#leftBarLogo').width() + $('#rightBarMaintab').width() + $('#rightBarSubMenu').width());
                // console.log(totaltab,'totalWidth');
                $('.leftBarMain').width(totaltab);
                $('.leftBarMain').attr('style', 'width:' + totaltab + 'px !important');
                eachTab = eachTab + $currentElement.outerWidth();
                totaltab = $('.leftBarMain').width() - 30;
                if (eachTab > totaltab) {
                    $(this).hide();
                    //  console.log($(this));
                    let tabs = {
                        id: $(this).attr('id'),
                        name: $(this).text()
                    }
                    //  console.log(tabs,'tab1')
                    //  if(!$.inArray(tabs,scope.hiddenTabs)){
                    //  }
                    let found = false;
                    scope.hiddenTabs.filter(function (tab) {
                        if (tab.id == tabs.id) {
                            found = true;
                        }
                    });
                    // console.log(scope.hiddenTabs,'scope.hiddenTabs');
                    if (found == false) {
                        scope.hiddenTabs.unshift(tabs);
                    }

                }
                else {
                    let res;
                    if ($(this).is(':hidden')) {
                        $(this).show();
                        let elem = $(this).attr('id');
                        res = scope.hiddenTabs.filter(function (tab) {
                            return tab.id !== elem;
                        });
                        scope.hiddenTabs = res;
                        //  console.log(scope.hiddenTabs,'scope.hiddenTabs');
                    }
                }
            });
            $('#leftBarMaintab').css('visibility', 'visible');
            // console.log(eachTab, 'totalTab', $('.leftBarMain').width(), scope.hiddenTabs);
        }, 1700)
    }

    public viewLanguage() {
        let network;
        network = this.networkService.getPopupStatus();
        if (network === true) {
            this.languageView = !this.languageFlag;
            this.headerservicesService.languageIcon(this.languageView);
            this.location.go('language');
            $('#body').addClass('scrolldisbale');
        }
    }
    public tvguidebutton() {
        this.headerservicesService.spotlightChange(false);
        this.headerservicesService.profileChange(false);
        this.headerservicesService.modelChange(false);
        this.headerservicesService.moreIcon(false);
    }

    public languageSelsection() {
        this.headerservicesService.profileChange(false);
        this.headerservicesService.modelChange(false);
        this.headerservicesService.moreIcon(false);
    }
    public login() {
        this.headerservicesService.spotlightChange(false);
        this.headerservicesService.profileChange(false);
        this.headerservicesService.moreIcon(false);   // on click make moreview false
    }
    public flagchange(eve) {                 // for user Icon to change track the login component
        this.headerservicesService.addChanges(eve);
    }
private viewTrigger(value) {
  // console.log(value, 'router url value viewtrigger', this.routeservice.getcurrentLanguage());                                                     // depending on view add class
  let langInUrl;
  langInUrl = this.routeservice.getcurrentLanguage();
  langInUrl = langInUrl + (langInUrl ? '/' : '');
  this.checkView = value;
  if (this.checkView.match(/livetv/g)) {
    this.currentTabHeader = 5;
    // this.currentTabHeader = 5;
    this.changeTvguide();
  } else if (this.checkView === '/' + langInUrl || this.checkView.match(/home/g)) {
    this.currentTabHeader = 0;
    this.changeTvguide();
  } else if (this.checkView.match(/tvshows/g)) {
    this.currentTabHeader = 2;
    // this.currentTabHeader = 1;
    this.changeTvguide();
  } else if (this.checkView.match(/movies/g)) {
    this.currentTabHeader = 3;
    // this.currentTabHeader = 2;
    this.changeTvguide();
  } else if (this.checkView.match(/premium/g)) {
    this.currentTabHeader = 1;
    // this.currentTabHeader = 0;
    this.changeTvguide();
  } else if (this.checkView.match(/zee5originals/g)) {
    this.currentTabHeader = 6;
    // this.currentTabHeader = 6;
    this.changeTvguide();
  } else if (this.checkView.match(/videos/g)) {
    this.currentTabHeader = 4;
    // this.currentTabHeader = 4;
    this.changeTvguide();
  } else if (this.checkView.match(/news/g)) {
    this.currentTabHeader = null;
    // this.currentTabHeader = 3;
    this.changeTvguide();
  } else if (this.checkView.match(/tvguide/g)) {
    this.currentTabHeader = 8;
    // this.currentTabHeader = 7;
    this.tvguideImg = environment.assetsBasePath + 'assets/common/tvguideSelect.png';
    $('#hideoutside').css('background-color', 'black');
  } else  if (this.checkView.match(/settings/g)) {
    this.currentTabHeader = null;
    this.changeTvguide();
  } else {
    this.changeTvguide();
    this.currentTabHeader = null;
  }
}
public navigationFunction(routeURl): any {
  // console.log('routeURl', routeURl);
  if (routeURl === 'tvshows' || routeURl === 'movies' || routeURl === 'videos' ) {
    this.filterService.deleteAll();
    this.filterService.setView(name);
  }
  this.headerservicesService.profileChange(false);
  this.headerservicesService.modelChange(false);
  this.headerservicesService.moreIcon(false);
  let url = '/' + routeURl;
  this.route2.navigate([url]);
}
public mainHeaderTab() {
    if (this.window.innerWidth <= 1010) {
      // alert('1')
      $('#leftBarMaintab').attr('style', 'width: unset !important');
      // $('#leftBarMaintab').css('width', 'unset !important');
      this.endslice = 2;
   } else if (this.window.innerWidth <=  1120) {
     this.endslice = 3;
   } else {
     this.endslice = 4;
   }
}
public compressview() {                                // for mobile view header dropdown open
 this.retrivedDrop = true;
 this.headerservicesService.hamburgerDrop(this.retrivedDrop);
 this.headerservicesService.modelChange(this.retrivedDrop);
 $('#body').addClass('scrolldisbale');
   let telcoCheckPlan;
  telcoCheckPlan = this.sub.getTelcoFlag();
  this.telcoPlanFlag = telcoCheckPlan ? true : false;
}
public changeTvguide() {
  this.tvguideImg = environment.assetsBasePath + 'assets/common/tvguide.png';                  // on select change tv guide asset
}
public zee5logo() {
  this.headerservicesService.modelChange(false);
  this.headerservicesService.moreIcon(false);                    // when clicked moreview closed
  this.headerservicesService.profileChange(false);
  this.headerservicesService.spotlightChange(false);
}
public routeClick(name) {
  if (name !== null) {
    this.filterService.deleteAll();
    this.filterService.setView(name);
  }
  this.headerservicesService.profileChange(false);
  this.headerservicesService.modelChange(false);
  this.headerservicesService.moreIcon(false);
}
public morebutton() {
  this.moreView = !this.moreViewoutside;
  this.headerservicesService.moreIcon(this.moreView);
  this.modelOpen = !this.modalstatus;                        // track of model popup in header
  this.headerservicesService.spotlightChange(false);
  this.headerservicesService.profileChange(false);
}
public userbutton() {
 let logintype;
 logintype =  this.localstorage.getItem('token');
  if (logintype === null) {
    this.window.location.reload(true);
  }
  this.profileDisplay = !this.profiledisplayOut;
  this.headerservicesService.profileChange(this.profileDisplay);
  this.headerservicesService.modelChange(false);
  this.headerservicesService.moreIcon(false);
  this.headerservicesService.spotlightChange(false);
  let telcoCheckPlan;
  telcoCheckPlan = this.sub.getTelcoFlag();
  this.telcoPlanFlag = telcoCheckPlan ? true : false;
  this.gtm.sendEventDetails({'event': 'buttonClicks', 'cta': 'user icon'});
  this.gtm.sendEventDetails({'event': 'userIconClick', 'UserMenu': 'user icon'});
}
public searchbutton() {
  this.headerservicesService.profileChange(false);
  this.headerservicesService.moreIcon(false);
  this.headerservicesService.spotlightChange(false);
}
public viewSearch() {
  let network;
  network = this.networkService.getPopupStatus() ;
    if (network === true) {
      this.gtm.comScoreFunction();
      this.headerservicesService.modelChange(true);            // track of modelpopu
      this.searchView = !this.searchFlag;
      this.gtm.refScreen(this.gtm.getPageName());
      this.clientID = this.gtm.fetchClientId();
      this.marketingValue = this.gtm.fetchMarketing();
      this.gtm.sendEventDetails({event: 'searchTabClick'});
      // this.gtm.logEvent(
      //   {'event': 'searchTabClick',
      //   'refScreen': this.gtm.getPageName(),
      //   'G_ID': this.gtm.fetchToken(),
      //   'Client_ID': this.clientID,
      //   'retargeting_remarketing' : this.marketingValue,
      //   'TimeHHMMSS': this.gtm.fetchCurrentTime(),
      //   'DateTimeStamp': this.gtm.fetchCurrentDate(),
      // });
      this.headerservicesService.searchIcon(this.searchView);
      this.location.go('search');
        // this.route2.navigate(['/search']);
    }
}

    /////////////////////////////////////// othercomponent///////////////////////////////////
    public registerCall() {
        let network;
        network = this.networkService.getPopupStatus();
        if (network === true) {
            this.gtm.comScoreFunction();
            this.headerservicesService.modelChange(true);                // track of model popup
            this.document.getElementById('body').classList.add('modal-open');
            // NationalFlag
            if (this.localstorage.getItem('country_code') === 'IN') {

                this.signinOpen = !this.signInFlag;
                this.headerservicesService.signinChange(this.signinOpen);

                if (this.countryListData && this.countryListData.length !== 0) {
                    if (this.countryListData[this.countrycodeIndex] && this.countryListData[this.countrycodeIndex].mobile_registration !== undefined) {
                        if (this.countryListData[this.countrycodeIndex].mobile_registration === 'true' || this.countryListData[this.countrycodeIndex].mobile_registration === true) {
                            this.route2.navigate(['register/mobile']);
                        } else if (this.countryListData[this.countrycodeIndex].mobile_registration === 'false') {
                            this.route2.navigate(['register/email']);
                        } else {
                            this.route2.navigate(['register/mobile']);
                        }
                    } else {
                        this.route2.navigate(['register/mobile']);
                    }
                } else if (this.configData) {
                    if (this.configData.mobile_registration) {
                        this.route2.navigate(['register/mobile']);
                    } else if (this.configData.mobile_registration === undefined) {
                        this.route2.navigate(['register/mobile']);
                    } else {
                        this.route2.navigate(['register/email']);
                    }
                } else {
                    this.route2.navigate(['register/mobile']);
                }
            } else {
                // InternationalFlag

                this.signinOpen = !this.internationalFlag;
                this.headerservicesService.internationalRegisterChange(this.signinOpen);

                this.route2.navigate(['register']);
            }
        }
    }
    public toggleSigin() {
        let network;
        network = this.networkService.getPopupStatus();
        if (network === true) {
            this.gtm.comScoreFunction();
            this.headerservicesService.modelChange(true);                // track of model popup
            this.document.getElementById('body').classList.add('modal-open');
            // NationalFlag
            if (this.localstorage.getItem('country_code') === 'IN') {

                this.signinOpen = !this.signInFlag;
                this.headerservicesService.signinChange(this.signinOpen);

                if (this.countryListData && this.countryListData.length !== 0) {
                    if (this.countryListData[this.countrycodeIndex] && this.countryListData[this.countrycodeIndex].mobile_registration !== undefined) {
                        if (this.countryListData[this.countrycodeIndex].mobile_registration === 'true' || this.countryListData[this.countrycodeIndex].mobile_registration === true) {
                            this.route2.navigate(['signin/mobile']);
                        } else if (this.countryListData[this.countrycodeIndex].mobile_registration === 'false') {
                            this.route2.navigate(['signin/email']);
                        } else {
                            this.route2.navigate(['signin/mobile']);
                        }
                    } else {
                        this.route2.navigate(['signin/mobile']);
                    }
                } else if (this.configData) {
                    if (this.configData.mobile_registration) {
                        this.route2.navigate(['signin/mobile']);
                    } else if (this.configData.mobile_registration === undefined) {
                        this.route2.navigate(['signin/mobile']);
                    } else {
                        this.route2.navigate(['signin/email']);
                    }
                } else {
                    this.route2.navigate(['signin/mobile']);
                }
            } else {
                // InterNationalFlag

                this.signinOpen = !this.internationalFlag;
                this.headerservicesService.internationalRegisterChange(this.signinOpen);
                this.routeservice.Signal('/signin');
                this.route2.navigate(['signin']);
            }
        }
    }
    public commonCalltologinpage(value): any {
        let network;
        network = this.networkService.getPopupStatus();
        if (network === true) {

            if (value === 'register') {
                this.registerCall();
            } else {
                this.toggleSigin();
            }
        }
    }
    // public IndialoginLandingPage(value): any {
    //   this.gtm.comScoreFunction();
    //      this.signinOpen = !this.signInFlag;
    //      this.headerservicesService.signinChange(this.signinOpen);
    //      this.headerservicesService.modelChange(true);                // track of model popup
    //      this.document.getElementById('body').classList.add('modal-open');
    //      if(value == 'login'){
    //       this.route2.navigate(['/signin']);   // route for commonlanding page in India
    //      }else{
    //       this.route2.navigate(['/register']);   // route for commonlanding page in India
    //      }
    // }
    ////////////////////////////////// singin popup/////////////
    public closeReminder = function (event) {
        this.showSignUpPromt = false;
    };
    public closeReminder1 = function (event) {
        this.showSubsPromt = false;
    };
    private toggeleReminder(value: boolean) {
        if (value === true) {
            this.showSignUpPromt = true;
        } else {
            this.showSignUpPromt = false;
        }
    }
    private toggeleReminderSubs(value: boolean) {
        if (value === true) {
            this.showSubsPromt = true;
        } else {
            this.showSubsPromt = false;
        }
    }
    private check() {
        if (window.pageYOffset === 0) {
            $('#my-banner').show();
        } else {
            $('#my-banner').hide(10);
        }
    }
    public sendHamburgerDetails(details) {
        let humbergerDetails;
        humbergerDetails = {
            'event': 'hamburgerMenu',
            'HamburgerMenu': details
        };
        this.gtm.sendEventDetails(humbergerDetails);
    }
    public sendMoremenuClickDetails(details) {
        let moremenuDetails;
        moremenuDetails = {
            'event': 'MoreMenuClick',
            'MoreMenu': details
        };
        this.gtm.sendEventDetails(moremenuDetails);
    }
  public sendHeaderTabDetails(details) {
    let headerDetails;
    headerDetails = {
      'event': 'pageComponentInteractions',
      'headerTab': this.commonService.convertToTitlecase((details === 'tvshows') ? 'shows' : details)
    };
    this.gtm.sendEventDetails(headerDetails);
  }
}

