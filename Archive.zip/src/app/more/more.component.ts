import { Component, OnInit, Input, Output, EventEmitter, } from '@angular/core';
import { HeaderservicesService } from '../services/headerservices.service';
import * as $ from 'jquery';
import { Subscription } from 'rxjs/Subscription';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { environment } from '../../environments/environment';
import { NetworkService } from '../services/network.service';
import { FilterService } from '../services/filter.service';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { Router } from '@angular/router';
import {UserApi} from 'data/user/api/api';
import { Http} from '@angular/http';
import { Subject } from 'rxjs/Subject';
import { CommonService } from '../services/common.service';
import { SettingsService } from './../services/settings.service';

@Component({
  selector: 'app-more',
  templateUrl: './more.component.html',
  styleUrls: ['./more.component.less']
})
export class MoreComponent implements OnInit {
private returnMore: boolean;
private token: string;
private moreView: any;
private localstorage: any;
private window: any;
public currentTabMore: any;
public appVersion: any;
public countyCode: any;
public assetbasepath: any;
public helpRoute: any;
public CompleteconfigValue: any;
public selectCountry: boolean = false;
public selectCountryPopup: boolean = false;
private ngUnsubscribe = new Subject<any>();
@Input() public weyyakUrl: any;
@Input() public logout: any;
@Input() public weyyak: any;
@Input() private routeValue: any;
@Input () public hiddenTabs: any;
public moreMenu = []
 constructor(@Inject(PLATFORM_ID) private platformId: Object, private filterService: FilterService, private networkService: NetworkService, private headerservicesService: HeaderservicesService, private gtm: GoogleAnalyticsService, private route2: Router, private http: Http, private settingsService: SettingsService,private commonService: CommonService) {
     this.headerservicesService.moreValue.subscribe(value => {
        this.returnMore = value;       // login view changes to reflect login/register icon
        this.moreView = value;
        if (this.moreView === false) {
           this.resetMore();
        }
    });
 }
  public ngOnInit() {
    this.CompleteconfigValue = this.settingsService.getCompleteConfig();
    this.gtm.storeWindowError();
    if (isPlatformBrowser(this.platformId)) {
      this.localstorage = localStorage;
      this.window = window;
    }
    // console.log('hiddenTabs',this.hiddenTabs);
    this.moreMenu = this.hiddenTabs;
  this.assetbasepath = environment.assetsBasePath;
  this.appVersion = this.window.appVersion;
  if (environment.countryCode) {
    this.countyCode = this.localstorage.getItem('country_code');
  }
    this.hextokenFunction();
    this.view();
    let scope;
    scope = this;
    this.window.onpopstate = function() {
      scope.headerservicesService.moreIcon(false);
      scope.headerservicesService.modelChange(false);
      if (localStorage.getItem('deviceAuthenticateCode')) {
        localStorage.removeItem('deviceAuthenticateCode');
      }
    };
    if(this.CompleteconfigValue && this.CompleteconfigValue.country_selection && this.CompleteconfigValue.country_selection_popup && environment.internationalBuild){
      this.selectCountry = true;
    }else{ this.selectCountry = false;}
  }
  public navigationFunction(routeURl): any {
    if (routeURl === 'tvshows' || routeURl === 'movies' || routeURl === 'videos' ) {
      this.filterService.deleteAll();
      this.filterService.setView(name);
    }
    this.headerservicesService.profileChange(false);
    this.headerservicesService.modelChange(false);
    this.headerservicesService.moreIcon(false);
    let url = '/' + routeURl;
    this.route2.navigate([url])
  }
  public hextokenFunction(): any {
    let ccode, language, userType, hextoken;
    ccode = this.localstorage.getItem('country_code');
    language = this.localstorage.getItem('token') ? this.localstorage.getItem('UserDisplayLanguage') : this.localstorage.getItem('display_language');
    userType = this.localstorage.getItem('token') ? 'loggedin' : 'guest';
    hextoken = this.localstorage.getItem('hextoken');
    this.helpRoute = environment.shareUrl + '/help?translation=' + language + '&country=' + ccode + '&hextoken=' + hextoken + '&platform=desktop_web' + '&user_type=' + userType + '&app_version=' + this.appVersion;
  }

  public goToHelp(): any {
    let ccode, language, userType, hextoken, userToken;
    ccode = this.localstorage.getItem('country_code');
    language = this.localstorage.getItem('token') ? this.localstorage.getItem('UserDisplayLanguage') : this.localstorage.getItem('display_language');
    userType = this.localstorage.getItem('token') ? 'loggedin' : 'guest';
    hextoken = this.localstorage.getItem('hextoken');
    // let url;
    // url = 'http://localhost:5000/help/?translation=' + language + '&country=' + ccode + '&hextoken=' + hextoken + '&platform=desktop_web' + '&user_type=' + userType + '&app_version=' + this.appVersion;

    if ((userType === 'loggedin') && ((hextoken == null) || (hextoken === 'null') || (hextoken === ''))) {
      userToken = this.localstorage.getItem('token');
      const params = 'bearer ' + userToken;
      this.window.scrollTo(0, 0);
      const config = {
        apiKey: params,
        username: ' ',
        password: ' ',
        accessToken: ' ',
        withCredentials: true
      };
       const userDetails = new UserApi(this.http, null, config);
       let dataHextoken;
       dataHextoken = {'identifier': 'web', 'partner': 'contactus'};
       userDetails.v1PostHextoken('contactus', dataHextoken).takeUntil(this.ngUnsubscribe).subscribe(hextoken_data => {
          hextoken = hextoken_data.json().token;
          window.open(environment.shareUrl + '/help?translation=' + language + '&country=' + ccode + '&hextoken=' + hextoken + '&platform=desktop_web' + '&user_type=' + userType + '&app_version=' + this.appVersion, '_blank');
       },
       err => {
          window.open(environment.shareUrl + '/help?translation=' + language + '&country=' + ccode + '&hextoken=' + hextoken + '&platform=desktop_web' + '&user_type=' + userType + '&app_version=' + this.appVersion, '_blank');
       });

    } else {
       window.open(environment.shareUrl + '/help?translation=' + language + '&country=' + ccode + '&hextoken=' + hextoken + '&platform=desktop_web' + '&user_type=' + userType + '&app_version=' + this.appVersion, '_blank');
    }
  }

  private view() {                                                     // depending on view add class
    if (this.routeValue.match(/settings/g)) {
       this.currentTabMore = 6;
    } else if (this.routeValue.match(/language/g)) {
       this.currentTabMore = 5;
    } else if (this.routeValue.match(/faq/g)) {
      this.currentTabMore = 8;
    } else if (this.routeValue.match(/aboutus/g)) {
      this.currentTabMore = 7;
    } else if (this.routeValue.match(/subscription/g)) {
       this.currentTabMore = 9;
    } else if (this.routeValue.match(/videos/g)) {
      this.currentTabMore = 'videos';
    } else if (this.routeValue.match(/movies/g)) {
       this.currentTabMore = 'movies';
    } else if (this.routeValue.match(/premium/g)) {
       this.currentTabMore = 'premium';
    } else if (this.routeValue.match(/livetv/g)) {
       this.currentTabMore ='livetv';
    } else if (this.routeValue.match(/tvshows/g)) {
       this.currentTabMore = 'tvshows';
    } else if (this.routeValue.match(/zee5originals/g)) {
       this.currentTabMore = 'zee5originals';
    } else if (this.routeValue.match(/news/g)) {
       this.currentTabMore = 'news';
    } else {
      this.currentTabMore = null;
    }
  }
  public closeView() {
    this.headerservicesService.moreIcon(false);
    this.headerservicesService.modelChange(false);
    this.view();
  }
  public SelectCountry(){
    this.settingsService.SelectCountryPopupValue.next(true);
  }
  private resetMore() {
  this.currentTabMore = null;
  }
  public setView(name): any {
    this.filterService.deleteAll();
    this.filterService.setView(name);
  }
  public sendTabDetails(details) {
    let tabDetails, menuDetails;
    tabDetails = (details === 'tvshows') ? 'shows' : ((details === 'zee5originals') ? 'zee5 originals' : (details === 'livetv') ? 'live tv' : details);
    // menuDetails = {
    //   'event': 'pageComponentInteractions',
    //   'headerTab': this.commonService.convertToTitlecase(tabDetails)
    // };
    menuDetails = {
      'event': 'MoreMenuClick',
      'MoreMenu': details
    };
    this.gtm.sendEventDetails(menuDetails);
  }
}
