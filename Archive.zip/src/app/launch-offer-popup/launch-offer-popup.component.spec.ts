import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LaunchOfferPopupComponent } from './launch-offer-popup.component';

describe('LaunchOfferPopupComponent', () => {
  let component: LaunchOfferPopupComponent;
  let fixture: ComponentFixture<LaunchOfferPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LaunchOfferPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LaunchOfferPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
