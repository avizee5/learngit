import { Component, OnInit, OnDestroy } from '@angular/core';
import { HeaderservicesService } from '../services/headerservices.service';
import {environment} from '../../environments/environment';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';

@Component({
	selector: 'app-launch-offer-popup',
	templateUrl: './launch-offer-popup.component.html',
	styleUrls: ['./launch-offer-popup.component.less']
})
export class LaunchOfferPopupComponent implements OnInit, OnDestroy {
public landscapeAd: any = environment.assetsBasePath + 'assets/common/landscape_free.jpg';
public portraitAd: any = environment.assetsBasePath + 'assets/common/portrait_free.jpg';
public closeIcon: any = environment.assetsBasePath + 'assets/player_icons/modal_close_icon.svg';
public document: any;
constructor(@Inject(PLATFORM_ID) private platformId: Object, private headerservicesService: HeaderservicesService) { }

public ngOnInit(): any {
	if (isPlatformBrowser(this.platformId)) {
      this.document = document;
    }

    if (navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i) || window.innerWidth <= 480) {
      this.document.getElementById('body').classList.add('modalOpen');
    } else {
      this.document.getElementById('body').classList.add('modal-open');
    }

}
	public closePopup(): any {
		this.headerservicesService.launchOfferChange(false);
	}
	public ngOnDestroy(): any {
	    if (navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i) || window.innerWidth <= 480) {
	      this.document.getElementById('body').classList.remove('modalOpen');
	    } else {
	      this.document.getElementById('body').classList.remove('modal-open');
	    }
  }
}
