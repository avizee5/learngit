import { Component, OnInit, OnDestroy} from '@angular/core';
import { environment } from '../../environments/environment';
import * as $ from 'jquery';
import * as subscritionplanApi from './../../data/subscription/api/api';
import { Http } from '@angular/http';
import { HeaderservicesService } from '../services/headerservices.service';

@Component({
  selector: 'app-dialog-pop-up',
  templateUrl: './dialog-pop-up.component.html',
  styleUrls: ['./dialog-pop-up.component.less']
})
export class DialogPopUpComponent implements OnInit, OnDestroy {
  private basepath: any;
  public close: any;
  public zee5logo: any;
  public displayDialog = false;
  public dialogDesc: any;
  constructor(private http: Http, private headerservicesService: HeaderservicesService) { }

  public ngOnInit() {
  	$('#body').addClass('scrolldisbale');
    this.basepath = environment.assetsBasePath;
  	this.close = this.basepath + 'assets/common/close_ic1.png';
  	this.zee5logo = this.basepath + 'assets/common/zee5_logo_popup.png';

    this.displayDialog = this.headerservicesService.getDialogCheckValueChange();
    let desp;
    desp = localStorage.getItem('promotionalDesc');
    if (desp && desp !== null && desp !== undefined && desp !== 'undefined') {
      this.dialogDesc = desp.subscription_plan.description;
    } else {
      this.dialogDesc = 'A limitless selection of entertainment is now FREE with Live TV + Catch up + VOD + Movies for you as you are amongst the lucky few DIALOG customers.';
    }
  }

  public closeContainer() {
    this.headerservicesService.DialogCheckValueChange(false);
  	$('#body').removeClass('scrolldisbale');
   localStorage.removeItem('dialogCheck');
    localStorage.removeItem('promotionalDesc');
    this.displayDialog = false;
  }

  public ngOnDestroy(): void {
    this.headerservicesService.DialogCheckValueChange(false);
    localStorage.removeItem('dialogCheck');
    $('#body').removeClass('scrolldisbale');
    localStorage.removeItem('promotionalDesc');
  }
}
