import { NgModule } from '@angular/core';
import {TranslateModule} from '@ngx-translate/core';
import {KeepHtmlModule} from './custom-filters/keep-html.module';

@NgModule({
 imports:      [TranslateModule, KeepHtmlModule],
 declarations: [],
 exports:      [TranslateModule, KeepHtmlModule]
})

export class SharedModule { }

// // import { CommonModule } from '@angular/common';
// import { NgModule } from '@angular/core';
// import {TranslateModule} from '@ngx-translate/core';


// @NgModule({
//  imports:      [ TranslateModule],
//  exports:      [TranslateModule]
// })

// export class SharedModule {}
