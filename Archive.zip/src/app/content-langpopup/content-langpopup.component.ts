import { Component, OnInit, OnDestroy, ViewEncapsulation, Input } from '@angular/core';
import {environment} from '../../environments/environment';
import { HeaderservicesService } from '../services/headerservices.service';
import { SettingsService } from '../services/settings.service';
import { TranslateService} from '@ngx-translate/core';
import { UserApiService } from '../services/user-api.service';
import { Router } from '@angular/router';
import { Subject } from 'rxjs/Subject';
import * as $ from 'jquery';
import { isPlatformBrowser } from '@angular/common';
import {  PLATFORM_ID } from '@angular/core';
import { NetworkService } from '../services/network.service';
import { Inject, Injectable, Optional } from '@angular/core';



@Component({
  selector: 'app-content-langpopup',
  templateUrl: './content-langpopup.component.html',
  styleUrls: ['./content-langpopup.component.less'],
  encapsulation: ViewEncapsulation.None,

})
export class ContentLangpopupComponent implements OnInit, OnDestroy {
public assetbasepath: any;
private ngUnsubscribe = new Subject<any>();
public contentText: any;
public noCondition: any;
public yesCondition: any;
private token: any;
public localStorage: any;
public document: any;
public defaultLanguages: Array<any> = [];
public content: any = [];
private contentObjectClose: any;
@Input() private languageSelected: any;
@Input() private contentID: any;
@Input() private contentView: any;

  constructor(@Inject(PLATFORM_ID) private platformId: Object, private networkService: NetworkService, private userapiService: UserApiService, private headerservicesService: HeaderservicesService, private settingsService: SettingsService, private router: Router, private translate: TranslateService) {
    if (isPlatformBrowser(this.platformId)) {
      this.localStorage = localStorage;
      this.document = document;
    }
  }

  public ngOnInit() {
    $('#body').addClass('scrolldisbale');
    this.assetbasepath = environment.assetsBasePath;
    this.token = this.localStorage.getItem('token');

    let calloutMessage, langCallout, calloutMessageMore;
    langCallout = this.settingsService.getcontentLanguageCallout();
    calloutMessage = langCallout && langCallout.message ? langCallout.message : 'LANG.LIKE_WATCH';
    calloutMessageMore = langCallout && langCallout.message_more ? langCallout.message_more : 'LANG.LIKE_WATCH_MORE';
    this.noCondition = langCallout && langCallout.no ? langCallout.no : 'LANG.MORE_LANGUAGES';
    this.yesCondition  = langCallout && langCallout.yes ? langCallout.yes : 'LANG.YES_WOULD';
    if (this.contentView === 'language') {
      this.translateString(calloutMessage);
    } else {
      this.translateString(calloutMessageMore);
    }
    this.contentObjectClose = {
      'boolean': false,
      'string': this.languageSelected,
      'id': this.contentID
    };
  }
  public translateString(text): any {
  	this.translate.get([text]).takeUntil(this.ngUnsubscribe).subscribe(value => {
        this.contentText = value[text];
        this.contentText = this.contentText.replace(/<.*?>>/gm, this.languageSelected);
        this.contentText = this.contentText.replace(/<.*?>/gm, this.languageSelected);
    });
  }
  public closeContainer(): any {
    this.contentObjectClose = {
      'boolean': false,
      'string': this.languageSelected,
      'id': this.contentID,
      'view': this.contentView,
      'status': 'close'
    };
	this.headerservicesService.contentLanguageChanges(this.contentObjectClose);
  }
  	public updateContentLang(): any {
	     let b, str, pushLang = [];
	     b = this.token ? this.localStorage.getItem('UserContentLanguage') : this.localStorage.getItem('ContentLang');
	     pushLang =  b.split(',');
         for ( let i = 0; i < pushLang.length; i++) {
            this.defaultLanguages.push(pushLang[i]);
          }
          this.defaultLanguages.push(this.contentID);
	     str = this.defaultLanguages.join();
	     let localStoragevalue;
       localStoragevalue = [];
	    localStoragevalue.push(str);
	     let network;
	     network = this.networkService.getPopupStatus();
	   		if (network === true) {
		      if ( this.token) {
		        this.setContent('content_language', str);
		        this.localStorage.setItem('UserContentLanguage', str);
		        this.callToastContent();
		      } else if (!this.token) {
		        this.localStorage.setItem( 'ContentLang', localStoragevalue);
		        this.callToastContent();
		      }
		    }
  }

  public setContent(key, n): any {       /*Setting in Service file*/
    this.userapiService.getParameter('put', key, n);
  }
  public callToastContent() {              /* Calling Toast for content language */
    this.contentObjectClose = {
      'boolean': false,
      'string': this.languageSelected,
      'id': this.contentID,
      'view': this.contentView,
      'status': 'toast'
    };
      let p, scope;
      scope = this;
      p = this.document.getElementById('Contentlang');
      p.className = 'show';
      setTimeout(function() {
       p.className = p.className.replace('show', '');
       scope.headerservicesService.contentLanguageChanges(scope.contentObjectClose);
  	}, 3000);
  }
  public languageScreen(): any {
     this.contentObjectClose = {
      'boolean': false,
      'string': this.languageSelected,
      'id': this.contentID,
      'view': this.contentView,
      'status': 'route'
    };
  // console.log('this.contentObjectClose',this.contentObjectClose)
  this.headerservicesService.contentLanguageChanges(this.contentObjectClose);
  this.headerservicesService.LanguageScreen(true);
  if (this.contentView === 'videoDestroy' || this.contentView === 'video') {
    this.localStorage.setItem( 'chooseLang', true);
  }
  this.router.navigate(['/language']);
  }
  public ngOnDestroy() {
    this.ngUnsubscribe.complete();
    this.ngUnsubscribe.next();
    $('#body').removeClass('scrolldisbale');
    $(function() {
      $('#textfield').focus();
    });
  }
}
