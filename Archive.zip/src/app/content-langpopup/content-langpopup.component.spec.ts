import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContentLangpopupComponent } from './content-langpopup.component';

describe('ContentLangpopupComponent', () => {
  let component: ContentLangpopupComponent;
  let fixture: ComponentFixture<ContentLangpopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContentLangpopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContentLangpopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
