import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { TwitterloginComponent } from './twitterlogin/twitterlogin.component';
import { AuthenticateDeviceComponent } from './authenticate-device/authenticate-device.component';

// import { AppResolverService } from './services/app-resolver-service';
const routes: Routes = [
{
	path: 'parentalcontrol',
	loadChildren: './parental-control/parental-control.module#ParentalControlModule'
},
{
	path: 'premium',
	component: HomeComponent
},
{
	path: 'news',
	component: HomeComponent
},
{
	path: 'aboutus',
	loadChildren: './about/about.module#AboutModule'
},
{
	path: 'catchUp',
    loadChildren: './catch-up/catch-up.module#CatchUpModule'
},
{
	path: 'myprofile',
    loadChildren: './profile-screen/profile-screen.module#ProfileScreenModule'
},
{
	path: 'myprofile/edit',
    loadChildren: './profile-screen/edit-profile/edit-profile.module#EditProfileModule'
},
{
	path: 'search/result',
	loadChildren: './search-results-screen/search-results-screen.module#SearchResultsScreenModule',
},
{
	path: 'zee5originals',
	loadChildren: './zee-originals-landing/zee-originals-landing.module#ZeeOriginalsLandingModule',
},
{
	path: 'zee5originals/all',
	loadChildren: './common-view-all/common-view-all.module#CommonViewAllModule',
},
{
	path: 'movies',
	loadChildren: './common-landing-screen/common-landing-screen.module#CommonLandingScreenModule',
},
{
	path: 'movies/all',
	loadChildren: './common-view-all/common-view-all.module#CommonViewAllModule',
},
{
	path: 'videos',
	loadChildren: './common-landing-screen/common-landing-screen.module#CommonLandingScreenModule',
},
{
	path: 'videos/all',
	loadChildren: './common-view-all/common-view-all.module#CommonViewAllModule',
},
{
	path: 'tvshows',
	loadChildren: './common-landing-screen/common-landing-screen.module#CommonLandingScreenModule',
},
{
	path: 'tvshows/all',
	loadChildren: './common-view-all/common-view-all.module#CommonViewAllModule',
},
{
	path: 'collections',
	loadChildren: './category-landing-screen/category-landing-screen.module#CategoryLandingScreenModule',
},
{
	path: 'livetv',
	loadChildren: './livetv/livetv.module#LivetvModule',
},
// {
// 	path: 'contactus',
// 	loadChildren: './contact/contact.module#ContactModule'
// },
{
	path: 'privacypolicy',
	loadChildren: './privacy-policy/privacy-policy.module#PrivacyPolicyModule'
},
{
    path: 'termsofuse',
    loadChildren: './terms/terms.module#TermsModule'
},
{
	path: 'cookiePolicy',
	loadChildren: './cookie-policy/cookie-policy.module#CookiePolicyModule'
},
{
	path: 'channels',
	loadChildren: './channel-list-screen/channel-list-screen.module#ChannelListScreenModule'
},
{
	path: 'channels/details',
	loadChildren: './channel-details/channel-details.module#ChannelDetailsModule'
},
{
	path: 'tvguide',
	loadChildren: './tvguide/tvguide.module#TvGuideModule'
},
{
	path: 'tvguide/:channelname/:channelid',
	redirectTo: '/tvguide',
},
{
	path: 'movies/details',
	loadChildren: './movies-consumption/movies-consumption.module#MovieConsumptionModule'
},
{
	path: 'videos/details',
	loadChildren: './movies-consumption/movies-consumption.module#MovieConsumptionModule'
},
{
	path: 'news/details',
	loadChildren: './movies-consumption/movies-consumption.module#MovieConsumptionModule'
},
{
	path: 'tvshows/details/:name/:id/latest',
	loadChildren: './episode-consumption/episode-consumption.module#EpisodeConsumptionModule',
},
{
	path: 'zee5originals/details/:name/:id/latest',
	loadChildren: './episode-consumption/episode-consumption.module#EpisodeConsumptionModule',
},
{
	path: 'tvshows/details/:name/:id/episodes',
	loadChildren: './season-details/season-details.module#SeasonDetailsModule'
},
{
	path: 'zee5originals/details/:name/:id/episodes',
	loadChildren: './season-details/season-details.module#SeasonDetailsModule'
},
{
	path: 'tvshows/details/:name/:id/:seasons/episodes',
	loadChildren: './season-details/season-details.module#SeasonDetailsModule'
},
{
	path: 'zee5originals/details/:name/:id/:seasons/episodes',
	loadChildren: './season-details/season-details.module#SeasonDetailsModule'
},
{
	path: 'tvshows/details/:name/:id',
	loadChildren: './episode-consumption/episode-consumption.module#EpisodeConsumptionModule',
},
{
	path: 'zee5originals/details/:name/:id',
	loadChildren: './episode-consumption/episode-consumption.module#EpisodeConsumptionModule',
},
{
	path: 'tvshows/details/:name/:id/:episodename/:episodeid',
	loadChildren: './episode-consumption/episode-consumption.module#EpisodeConsumptionModule',
},
{
	path: 'zee5originals/details/:name/:id/:episodename/:episodeid',
	loadChildren: './episode-consumption/episode-consumption.module#EpisodeConsumptionModule',
},
{
	path: 'settings',
	loadChildren: './settings/settings.module#SettingsModule'
},
{
	path: 'language',
	component: HomeComponent
},
{
	path: 'subscribe',
	redirectTo: 'myaccount/subscription'
	// loadChildren: './my-account/my-account.module#MyAccountModule'
},
{
	path: 'myaccount/:string',
	loadChildren: './my-account/my-account.module#MyAccountModule'
},
{
	path: 'myaccount',
	loadChildren: './my-account/my-account.module#MyAccountModule'
},
// {
//     path: 'faq',
//    loadChildren: './frequent-question/frequent-question.module#FrequentQuestionModule'
// },
{
	path: 'signin',
	component: HomeComponent
},
{
	path: 'signin/:id',
	component: HomeComponent
},
{
	path: 'register',
	component: HomeComponent
},
{
	path: 'register/:id',
	component: HomeComponent
},
{
	path: 'search',
	component: HomeComponent
},
{
	path: 'forgotpassword/:id',
	component: HomeComponent
},
{
	path: 'forgotpassword',
	component: HomeComponent
},
{
	path: 'subscription',
	loadChildren: './my-account/my-account.module#MyAccountModule'
},
{
	path: 'payments',
	loadChildren: './my-account/my-account.module#MyAccountModule'
},
{
	path: 'resetpassword',
	component: HomeComponent,
},
{
	path: 'verify',
	component: HomeComponent,
},
{
	path: 'paymentsuccess',
	loadChildren: './my-account/my-account.module#MyAccountModule'
},
{
	path: 'paymentfailure',
	loadChildren: './my-account/my-account.module#MyAccountModule'
},
{
	path: 'twitterLogin',
	component: TwitterloginComponent,
},
{
	path: 'paymentcancelled',
	loadChildren: './my-account/my-account.module#MyAccountModule'
},
{
	path: 'device',
	component: AuthenticateDeviceComponent,
},
{
	path: '',
	component: HomeComponent,
},
{
	path: 'pagenotfound',
    loadChildren: './custom-error-screen/custom-error-screen.module#CustomErrorScreenModule'
},
{
	path: 'home',
	redirectTo: '/',
},
{
	path: '**',
	redirectTo: '/pagenotfound',
},
];
@NgModule({
	imports: [ RouterModule.forRoot(routes) ],
	exports: [ RouterModule ]
})
export class AppRoutingModule { }
