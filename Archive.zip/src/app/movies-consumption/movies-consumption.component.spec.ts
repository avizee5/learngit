import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MoviesConsumptionComponent } from './movies-consumption.component';

describe('MoviesConsumptionComponent', () => {
  let component: MoviesConsumptionComponent;
  let fixture: ComponentFixture<MoviesConsumptionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MoviesConsumptionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MoviesConsumptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
