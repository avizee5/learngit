import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared.module';
import { MoviesConsumptionComponent } from './movies-consumption.component';
import { EmbedLinkPopupModule } from '../embed-link-popup/embed-link-popup.module';
import { DataUnavailableModule } from '../data-unavailable/data-unavailable.module';
import { CastscrollListModule } from '../castscroll-list/castscroll-list.module';
import { ScrollListModule } from '../scroll-list/scroll-list.module';
import { ReminderSignupModule } from '../reminder-signup/reminder-signup.module';
import { VideoModule } from '../video/video.module';
import { ScrollGridModule } from '../scroll-grid/scroll-grid.module';
import { ShareoptionsModule } from '../share-options/share-options.module';
import { NewsGridModule } from '../news-grid/news-grid.module';
import { PremiumTabModule } from '../premium-tab/premium-tab.module';

const routes: Routes = [
    {
        path: ':name/:id',
        component: MoviesConsumptionComponent
    }
];
@NgModule({
 exports: [RouterModule],
  imports: [RouterModule.forChild(routes), ShareoptionsModule, CommonModule, ScrollGridModule, VideoModule, SharedModule, EmbedLinkPopupModule, DataUnavailableModule, CastscrollListModule, ScrollListModule, ReminderSignupModule, NewsGridModule, PremiumTabModule],
  declarations: [MoviesConsumptionComponent]
})
export class MovieConsumptionModule {
}