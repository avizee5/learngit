import { Component, OnInit, HostListener, ViewChild, Output, EventEmitter, ElementRef, OnDestroy } from '@angular/core';
import * as $ from 'jquery';
import { HeaderservicesService} from '../services/headerservices.service';
import { Router } from '@angular/router';
// import { Http} from '@angular/http';
import { Headers, Http , RequestOptions, Response} from '@angular/http';
// import * as api from '../../data/catalog/api/api';
import {CollectionApi} from '../../data/gwapi_catalog/api/CollectionApi';
import {MovieApi} from '../../data/gwapi_catalog/api/api';
import { ActivatedRoute } from '@angular/router';
import { SettingsService } from '../services/settings.service';
import { Location } from '@angular/common';
import { VideoService } from '../services/video.service';
import { FilterService } from '../services/filter.service';
// import {CastscrollListComponent} from '../castscroll-list/castscroll-list.component';
import { UserProfileService } from '../services/user-profile.service';
import { WatchlistApi } from '../../data/user/api/api';
// import {FavoritesApi, RemindersApi, UserApi, WatchHistoryApi, WatchlistApi } from '../../data/user/api/api';
import { environment } from '../../environments/environment';
import { RouteService } from '../services/route.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { Meta } from '@angular/platform-browser';
import {  NetworkService  } from '../services/network.service';
import { SubscriptionService } from '../services/subscription.service';
import { VideoComponent } from '../video/video.component';
import { LinkService } from '../services/link.service';
import 'rxjs/add/operator/timeout';
import { SeoService } from '../services/seo.service';
import { Subject } from 'rxjs/Subject';
import { UserApiService } from '../services/user-api.service';
import {CommonService} from '../services/common.service';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { RequestMethod, RequestOptionsArgs } from '@angular/http';
import {TranslateService} from '@ngx-translate/core';
declare let googletag;
declare const FB;
declare const gapi;
declare const qg;
declare const adoric;
declare let adoricRecomendationContent;

@Component({
  selector: 'app-movies-consumption',
  templateUrl: './movies-consumption.component.html',
  styleUrls: ['./movies-consumption.component.less']
})
export class MoviesConsumptionComponent implements OnInit, OnDestroy {
 @ViewChild('add') public targetElement: ElementRef;
 private apiRetry = 2;
 private apiRetryCount = 1;
 public showEmbedIcon = false;
 public embedLink = false;
 public showAdult = false;
 private apiconfig: any;
 private apiconfigUser: any;
 // public adObject = { 'Mobile_0': '', 'Desktop_0': '', 'Mobile_1': '', 'Desktop_1': '', 'styleMobile0': '', 'styleDesktop0': '', 'styleMobile1': '', 'styleDesktop1': ''};
 public adObject: any;
 public videoAdData: any;
 public basepath: any;
 // public modalVideoPopup = false;
 // public modalVideoDetails: any;
 private index: number;
 public showdata: boolean;
 private read: string;
 // private favorite: any;
 private watched: any;
 private rated: any;
 private router: any;
 private router2: any;
// for api
  public movieData: any;
  private laguages: string;
  private subtitlesLang: string;
  private ratingString: string;
  // private ratingValue: any;
  private describtionString: string;
  private showReadMore: boolean;
  private movie_type: string;
  private actorsNames: Array<string>;
  private sub: any;
  private id: string;
  private languages_array: string[];
  private subtitle_array: string[];
  private time_string: string;
  private starContainer: string[];
  public showError: boolean;

  private name: any;
  private watch: any = null;
  public image_url: string;
  public image_url_mobile: string;
  public imageScr: string;

  public loginToken: any;
  // public storedData: any;
  // public storedWatchData: any;

  // for error handleing
  public movieTitle: string;
  private movieTitleEng: string;
  private movieGenre: any;
  private gAmovieGenre: any;
  private movieDescription: any;
  private movieReleaseDate: any;
  private movieDirector: any;

   // for sharing on social
  private shareURL: string;
  private options: any;
  private pageName: any;
  private showRelated: boolean;
  private corousalMatadata: any;
  private relatedMovies: any;
  private businessType: any;
  private avialableChannel: any;
  private purchasedAssetType: any;
  public videoFlag: any;
  private videochange: any;
  // private isStaticVdeoEnable: any = false;
  public data: any;
  private configValue: any;
  private showCast: boolean;
  private asset_subtype: any;
  private languageData: any;
  private showOtherCorousal: boolean;
  private asset_category: any;
  private urlcategory = 'movies/details/';
  private watchButtonString: string;
  private trailerVideoId: any;
  public onErrorBanner = environment.assetsBasePath + 'assets/default/banner.png';
  public onErrorBanner_mob = environment.assetsBasePath + 'assets/default/banner_mobile.png';
  public reminderText = 'LOGIN.LOGIN_REQUEST';
  public typeofpopup = 'reminder';
  private onErrorSrc: string;
  private googletagAvailable: any;
  private countryOfOrigin: any;
  public assetbasepath: any =  environment.assetsBasePath;
  private contentUrl: any;
  //  private months: any = ['Jan', 'Feb', 'Mar',
  // 'Apr', 'May', 'Jun', 'Jul',
  // 'Aug', 'Sep', 'Oct',
  // 'Nov', 'Dec'
  // ];
  public showSignUpPromt = false;
  private showSubPopUp: any;
  // showSubPopUpSettings: any;
  private displaylanguage: any;
  private fetchLabel: any;
  private regionalLang: any = [];
  private gAlanguage: any = [];
  private basepath1: any;
  private trailerflag = false;
  private trailerdata: any;
  private castVisibility: any;
  private ieBrowser: any;
  private configData: any;
  private assetType: any;
  private desktopTag: any;
  private mobileTag: any;
  private touchScreen = false;
  public touchScreenbelow = false;
  public trailerString: any;
  private addPaddingCast = false;
  private planCall: any;
  private subscriptionSuccess: any;
  public showTrailer = false;
  private premium = false;
  private subscriptionType = false;
   // public pageViewReminder: any;
   private age_rating_value: any;
   private parental_age: any = 2;
   private parental_object: any = {
     'U': 0, 'U/A': 1, 'A': 2
   };
   private RTRMBLOCK: any;
   private castQueueObject: any;
   private window: any;
   private navigator: any;
   private qgraph: any;
   private movieGenreArray = [];
   private playerHeight: any;
   public totalgridHeight: any;
  public gridHeight: any;
   public similarstring: any;
   public similarDataMobile: any;
   public similarData: any = [];
  private readText: any = 'DETAILS.READ_MORE';
  private textLimit = 200;
 public readMovieArrow: any;
public availableOnChannel: any;
  // public category: any;
  public languages: any;
 public orginalAssettype: any;
 public baseCategory: any;
 public showLogin = false;
 public showSubscribe = false;
 public parentalpin = false;
  private showShare = false;
   public liveChannels: any;
   public relatedNewsCarousels: any;
   public recommendedNewsCarousels: any;
   public moreinfoNewsCarousels: any;
   public ageRatingMovie: any;
   private noAd = true;
   public genreUpnext: any;
   public firstadcall: any = true;
   public imgSrc: any;
   public newsContentOwner: any;
   public nodata: any = false;
   public dots: any = '';
   public firsttray: any = [];
   public secondtray: any = [];
   public show_first_tray: any = false;
   public show_second_tray: any = false;
   public showGetPremium: any = false;
   public scrollGridHeightNoAd: any;
   public backgroundImage: any = false;
   public dataArray = [];
   public showscrollgrid = false;
   public movie_tags: any = [];
   public playbackVideoObj: any;
   public agetake = false;
   public valid_string: any;
   public newsYIndex: any;
   public localstorage: any;
   private countryCode: any;
   public corousalData: any;
   public talamoosEnable: any = false;
  //  public contentAgeRating: any;
  
  public talamoosImpression: any;
  
  private timer: any = [];

   @ViewChild( VideoComponent ) public videoComponenet: VideoComponent;
   private ngUnsubscribe = new Subject<any>();
   constructor(private seoService: SeoService,
     @Inject(PLATFORM_ID) private platformId: Object,
     private linkservice: LinkService,
     private subscription: SubscriptionService,
     private metaService: Meta,
     private networkService: NetworkService,
     private gtm: GoogleAnalyticsService,
     private routeservice: RouteService,
     private userProfileService: UserProfileService,
     private videoService: VideoService,
     private location: Location,
     private routeLink: Router,
     private route: ActivatedRoute,
     private headerservicesService: HeaderservicesService,
     private http: Http,
     private commonService: CommonService,
     private settingsService: SettingsService,
     private userapiService: UserApiService,
     private filterService: FilterService,
     private translate: TranslateService ) {
    if (isPlatformBrowser(this.platformId)) {
      this.window = window;
      this.navigator = navigator;
    }
     this.routeservice.setLoginRoute(window.location.pathname);
     this.router = routeLink;
     this.router2 = window.location.pathname;
     // this.routeservice.setRoute(this.router2);

     this.videoService.alertModalState.takeUntil(this.ngUnsubscribe).subscribe(value => {
       if (value) {
          this.videoFlag = false;
          this.backgroundImage = this.videoService.getImageUrl(this.data[0], false);
           // this.showPlayIcon(value);
       } else {
         this.backgroundImage = false;
       }
     });
     // Show login screen on Consuption page if "skip" or "close" on login-popup
    //  this.videoService.showLoginOnSkip.takeUntil(this.ngUnsubscribe).subscribe(value => {
    //    if(value){
    //     if(this.contentAgeRating === 'A'){
    //         this.showAdult = value;
    //       } else {this.showLogin = value;}        
    //    }
    //  });
    //  this.videoService.showSubOnSkip.takeUntil(this.ngUnsubscribe).subscribe(value => {
    //    if(value){
    //      this.showSubscribe = value;
    //    }
    //  });


    // Parental Control Success
    this.userapiService.enableVideoPlay.takeUntil(this.ngUnsubscribe).subscribe(value => {
      if (value === true ) {
        if (this.videoService.enableCastView) {
          this.data ? (this.backgroundImage = this.videoService.getImageUrl(this.data[0], false)) : (this.backgroundImage =  false);
          this.videoService.castQueueObject = this.castQueueObject;
          this.videoService.toggleQueueState(true);
          this.castQueueObject = null;
        } else {
        // } else if ( !this.isStaticVdeoEnable ) {
          // this.modalVideoPopup = true;
          this.playbackVideoObj = this.data;
          this.videoFlag = true;
          this.parentalpin = false;
          this.showLogin = false;
          this.showSubscribe = false;
        // } else {
        //   this.playbackVideoObj = this.data;
        //   this.videoFlag = true;
        //   this.parentalpin = false;
        //   this.showLogin = false;
        //   this.showSubscribe = false;
        }
      }
    });

    // this.headerservicesService.searchValue.takeUntil(this.ngUnsubscribe).subscribe(value => {
    //   this.showPlayIcon(value);
    // });

  //   this.headerservicesService.modelValue.takeUntil(this.ngUnsubscribe).subscribe(value => {
  //     this.showPlayIcon(value);
  //     // this.videochange = value;
  //     // if (this.videochange === true) {
  //     //   this.showPlayIcon(value);
  //     //     // this.videoFlag = false;
  //     // }
  // });

    this.videoService.alertCastState.takeUntil(this.ngUnsubscribe).subscribe( value1 => {
      this.castVisibility = value1;
    });

  // this.userProfileService.favourite.takeUntil(this.ngUnsubscribe).subscribe(value => {
  //   this.favorite =  this.userProfileService.inList('favorite', this.id);
  // });

  this.userProfileService.watchlater.takeUntil(this.ngUnsubscribe).subscribe(value => {
    this.watched = this.userProfileService.inList('watchList', this.id);
    this.iswatched();
  });

  // this.headerservicesService.signInReminder.takeUntil(this.ngUnsubscribe).subscribe(value => {
  //   this.pageViewReminder = value;
  //   });

  // check my plan flag
  this.subscription.planApiSuccess.takeUntil(this.ngUnsubscribe).subscribe(value => {
    this.planCall = value;
    if (this.planCall !== undefined && this.subscriptionSuccess === undefined) {
      this.ngOnInit();
    }
  });

  this.headerservicesService.blockeventsValue.subscribe(value => {
    this.qgraph = this.headerservicesService.getRemarketing();
  });
}


  public ngOnInit() {
    $('#loaderPage').css( 'display', 'block');
    this.localstorage = localStorage;
    this.loginToken = localStorage.getItem ('token');
    this.planCall = this.subscription.getPlanApiSucess();
    this.qgraph = this.headerservicesService.getRemarketing();
    if (this.loginToken && (this.planCall === undefined )) {
        return;
    }
    if (isPlatformBrowser(this.platformId)) {
      this.window = window;
    }
        let  browser1;
        browser1 = this.videoService.get_browser();
      if (browser1.name === 'Firefox') {
        $('#breadcrumInit').css('position', 'relative');
      }
    this.iswatched();
    this.firstadcall = true;
    this.countryCode = this.settingsService.getCountry();
    // Parental Control - removed for mygp
    // this.age_rating_value = this.userapiService.getAgeRating();
    // let scope;
    //  scope = this;
    // if (this.age_rating_value) {
    //   this.parental_age = this.parental_object[this.age_rating_value.age_rating];
    // } else {
    //   setTimeout(() => {
    //     scope.age_rating_value = scope.userapiService.getAgeRating();
    //     if (scope.age_rating_value) {
    //       this.parental_age = this.parental_object[this.age_rating_value.age_rating];
    //     } else {
    //       this.parental_age = 2;
    //     }
    //   }, 100);
    //   }
    this.subscriptionSuccess = true;
    this.configData = this.settingsService.getCompleteConfig();
    this.gtm.storeWindowError();
   if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i) || window.innerWidth <= 768) {
      this.touchScreen = true;
    }
    this.addPaddingCast = (this.window.innerWidth <= 991) ? true : false;
    this.touchScreenbelow = (this.window.innerWidth <= 480) ? true : false;
    this.trailerString =  (this.window.innerWidth <= 480) ? 'BREADCRUMB.TRAILER' : 'COMMON.WATCH_TRAILER';
    this.basepath = this.settingsService.getbasePath();
    this.basepath1 = this.settingsService.getbasePathNew();
    this.index = 800;
    this.showdata = false;
    this.read = ' . . .';
    this.showError = false;
    this.configValue = environment.configFile;
    this.showOtherCorousal = false;
    this.assetbasepath = environment.assetsBasePath;
    $('#loaderPage').css( 'display', 'block');
    this.watchButtonString = 'COMMON.WATCH_NOW';
    let browser;
     browser = this.videoService.get_browser();
     if (browser.name === 'IE') {
          this.ieBrowser = true;
        }
      this.videoFlag = false;
      this.corousalMatadata = [];
      this.relatedMovies = [];
      this.apiconfig = {
          apiKey: ' ',
          username: ' ',
          password: ' ',
          accessToken: ' ',
          withCredentials: false
        };
      let network, starImg, paramsvalue;

      network = this.networkService.getScreenStatus();
      // this.storedData = this.userProfileService.getFavoriteData();
      // this.storedWatchData = this.userProfileService.getWatchData();
      if (this.loginToken) {
        this.displaylanguage = localStorage.getItem('UserDisplayLanguage');
      } else {
        this.displaylanguage = localStorage.getItem('display_language');
      }
      this.fetchLabel = this.configData.languages_labels[this.displaylanguage];
      // window.scrollTo(0, 0);
      // $( "html,body" ).scrollTop(1);
      $(document).ready (() => {
        $( 'html,body' ).scrollTop(1);
      });
      starImg = this.assetbasepath + 'assets/common/star_filled_icon.png';
      this.starContainer = [
        starImg, starImg, starImg, starImg, starImg
      ];
      this.Resize();
      this.sub = this.route.params.takeUntil(this.ngUnsubscribe).subscribe(params => {
        $( '#featureouter' ).scrollTop(0);
        // $( '#scrollList' ).scrollTop(0);
        this.router2 = window.location.pathname;
        this.routeservice.setLoginRoute(window.location.pathname);
        // localStorage.setItem('previousRoute',this.router2)
        this.headerservicesService.viewChange(this.router2);
        // $( 'html,body' ).scrollTop(1);
        $(document).ready (() => {
          $( 'html,body' ).scrollTop(1);
        });
        this.parentalpin = false;
        this.showLogin = false;
        this.showSubscribe = false;
        this.trailerVideoId = undefined;
        this.trailerflag = false;
        /* commented for autoplay */
        // this.videoFlag = false;
        /* commented for autoplay */
        this.trailerdata = [];
        this.corousalMatadata = [];
        this.relatedMovies = [];
        this.firsttray = [];
        this.secondtray = [];
        // this.similarData = [];
        this.similarDataMobile = undefined;
        this.show_first_tray = false;
         this.show_second_tray = false;
        this.relatedNewsCarousels = undefined;
        this.recommendedNewsCarousels = undefined;
        this.moreinfoNewsCarousels = undefined;
        this.showGetPremium = false;
        this.noAd = true;
        this.videoAdData = undefined;
         this.backgroundImage = false;
        if (!this.firstadcall && googletag.destroySlots) {
          googletag.destroySlots();
          this.firstadcall = false;
        }
      this.regionalLang = [];
      this.gAlanguage = [];
      this.id = params['id'];
      this.name = params['name'] ;
      this.watch = params ['watch'];
       this.textLimit = 200;
         this.loadOnChange(true);
         this.showError = false;
         if ( this.loginToken != null ) {
          let subscription;
          this.userProfileService.httpgetFavoriteData();
          this.userProfileService.httpgetWatchData();
          // this.userProfileService.getFavoriteData();
          // this.userProfileService.getWatchData();
          this.setFavWatch();
              paramsvalue = 'bearer ' + this.loginToken;
      //      let  watchListRequest, favoritesRequest, subscription;
           this.apiconfigUser = {
            apiKey: paramsvalue,
            username: ' ',
            password: ' ',
            accessToken: ' ',
            withCredentials: false
          };
      //     watchListRequest = new  WatchlistApi(this.http, null, this.apiconfigUser);
      //     // favoritesRequest = new  FavoritesApi(this.http, null, this.apiconfigUser);
      //    watchListRequest.v1WatchlistGet().takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
      //    this.userProfileService.fullWatchData(value);
      //    favoritesRequest.v1FavoritesGet().takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value1 => {
      //    this.userProfileService.fullFavData(value1);
      //  },
      //   err => {
      //     this.userProfileService.fullFavData([]);
      //   });
      // },
      // err => {
      //   this.userProfileService.fullWatchData([]);
      //   favoritesRequest.v1FavoritesGet().takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
      //   this.userProfileService.fullFavData(value);
      //   }, err2 => {
      //     this.userProfileService.fullFavData([]);
      //   });

      // });
       subscription = this.subscription.checkPlanApiSuccess(true);   // access to movies(subscription type)
       for ( let i = 0; i <= subscription.length; i++) {
         if ( subscription[i] === '0') {
           this.subscriptionType = true;
         }
       }
      } else {
        // todo
      }

      });
         this.fontResize();

   }
private setFavWatch() {
    this.watched = this.userProfileService.inList('watchList', this.id);
    // this.favorite =  this.userProfileService.inList('favorite', this.episodeInfo.id);
    this.iswatched();
  }
   public iswatched(): any {
     if (this.watched) {
      this.imgSrc = this.assetbasepath + 'assets/common/watchLater_icon_selected.png';
    } else {
      this.imgSrc = this.assetbasepath + 'assets/common/watchLater_normal.png';
    }
   }
     private Resize(): void {
  let width, top;
          this.touchScreen = (this.window.innerWidth <= 768) ? true : false;
          this.addPaddingCast = (this.window.innerWidth <= 991) ? true : false;
          this.touchScreenbelow = (this.window.innerWidth <= 481) ? true : false;
          this.trailerString =  (this.window.innerWidth <= 480) ? 'BREADCRUMB.TRAILER' : 'COMMON.WATCH_TRAILER';
          this.headerservicesService.episodicPage(this.touchScreen);
           width = $('.bannerinner').width();
           this.playerHeight = width * 9 / 16 ;
          setTimeout(() => {
            $('#loaderPage').css('display', 'none');
            width = $('.bannerinner').width();
            this.playerHeight = width * 9 / 16 ;
            this.totalgridHeight = this.playerHeight + 32 + 15.609 + 0.797 + 29.500 + 46.797;
            this.scrollGridHeightNoAd = this.totalgridHeight - 43;
            this.gridHeight = this.noAd ? this.totalgridHeight : this.totalgridHeight - this.targetElement.nativeElement.offsetHeight -43;

            if (this.touchScreen) {
               $('.episode_details').css('paddingTop', this.playerHeight + 15);
            } else {
               $('.episode_details').css('paddingTop', '0px');
            }
             top = this.touchScreen ? ( this.playerHeight + 161 ) : 75;
            $('#breadcrumInit').css('top', top + 'px');
          }, 0);
  }
    private receiveData(value) {
          setTimeout(() => {
            this.Resize();
          }, 0);
  }

// @HostListener('window:popstate', ['$event'])
//   public onPopState(event) {
//    if ( this.modalVideoPopup === true ) {
//     this.closeVideo(true);
//    }

//   }

  private adApiCall(): void {
   let userType, adResponse, companionAdResponse, countyCode, countryValue, adApiTimeoutValue;
   userType = this.commonService.getUserType();
   countyCode = this.settingsService.getCountry();
   countryValue = this.settingsService.getCountryValueNew();
   if (countyCode !== 'IN') {
     adApiTimeoutValue = countryValue && countryValue[0] && countryValue[0].video_ads_api_timeout ? countryValue[0].video_ads_api_timeout : environment.adApiTimeOut;
   } else {
     adApiTimeoutValue = environment.adApiTimeOut;
   }

    this.videoService.getAdData(this.movieData.id, 'vod').takeUntil(this.ngUnsubscribe).timeout(adApiTimeoutValue).subscribe(value => {
      if (value && value._body) {
        try {
          adResponse = JSON.parse(value._body);
        } catch (error) {
          this.videoAdData = {};
        }
        if (adResponse && adResponse.companion_ads && adResponse.companion_ads[0] && adResponse.companion_ads[0][userType]) {
          companionAdResponse = adResponse.companion_ads[0][userType];
        }
        if (adResponse.video_ads && adResponse.video_ads[0]) {
          this.videoAdData = {
            'type': adResponse.video_ads[0].type,
            'intervals': adResponse.video_ads[0].intervals,
            'ads_visibility': adResponse.video_ads[0].ads_visibility
          };
        } else {
          this.videoAdData = {};
        }
        // if (companionAdResponse && companionAdResponse.ads_visibility && companionAdResponse.ad_data && companionAdResponse.ad_data.length > 0) {
        //   this.adCall(companionAdResponse.ad_data);
        // }
      } else {
        this.videoAdData = {};
      }
    }, err => {
      this.videoAdData = {};
      this.gtm.sendErrorEvent('api', err);
    });
 }

 private adCall(response: any): any {
  // let mobileAd1, mobileAd2, desktopAd1, desktopAd2;
  // mobileAd1 = false;
  // mobileAd2 = false;
  // desktopAd1 = false;
  // desktopAd2 = false;
    this.destroyAds();
    this.firstadcall = false;

    this.adObject = response;
    if (this.adObject.length === 1) {
      this.adObject.splice((this.addPaddingCast && this.countryCode === 'RU') ? 0 : 1, 0, {});
    }
    for (let i = 0; i < this.adObject.length; i++) {
      this.adObject[i].ad_style = this.commonService.getAdType(this.adObject[i].ad_type);
      this.googleAdCreation(this.adObject[i], (i === 0 && !this.addPaddingCast) ? 'square' : 'native')
    }
}

private destroyAds(): any {
  // this.googletagAvailable = this.localstorage.getItem('googletag')
  this.googletagAvailable = this.commonService.checkGoogleTag();
  if (this.googletagAvailable === 'true' && googletag.destroySlots) {
    googletag.destroySlots();
  }
  let adFoxtagAvailable;
  adFoxtagAvailable = this.commonService.checkAdFoxTag();
  if (adFoxtagAvailable === 'true' && this.window.Ya.adfoxCode.destroy) {
  // if (adFoxtagAvailable === 'true' && this.window.Ya && this.window.Ya.adfoxCode && this.window.Ya.adfoxCode.destroy) {
    this.window.Ya.adfoxCode.destroy();
  }
  // clear all timers in the array
  if (this.timer && this.timer.length) {
    for (let i = 0; i < this.timer.length; i++) {
      clearTimeout(this.timer[i]);
    }
  }
}

public googleAdCreation (nativeTag: any, type: any) {
  if (nativeTag && nativeTag && nativeTag.div_id) {
    switch (nativeTag.ad_provider) {
      case 'adfox':
        let adFoxtagAvailable;
        adFoxtagAvailable = this.commonService.checkAdFoxTag();
        if (adFoxtagAvailable === 'true' && nativeTag.owner_id && nativeTag.params) {
          this.adFoxCreation(nativeTag.div_id, nativeTag.owner_id, nativeTag.params , type);
        }
        break;
      default:
        this.googletagAvailable = this.commonService.checkGoogleTag();
        if (this.googletagAvailable === 'true' && nativeTag.ad_tag) {
          this.adCreation(nativeTag, type);
        }
        break;
    }
  }
}

public adFoxCreation(id: any, owner_id: any, params: any, adType: any) {
  let adFoxtagAvailable;
  adFoxtagAvailable = this.commonService.checkAdFoxTag();
  if (adFoxtagAvailable === 'true') {
    let scope;
    scope = this;
    this.timer.push(setTimeout(function() {
      this.window.Ya.adfoxCode.create({
        ownerId: owner_id,
        containerId: id,
        params: params,
        onLoad: function(data) { 
          // console.log(data, 'onLoad');
          scope.noAd = false;
        },
        // onRender: function(render) { console.log(render, 'onRender') },
        onError: function(error) {
          // console.log(error, 'onError');
          $('#' + id).hide();
          scope.noAd = true;
        },
        onStub: function(stub) {
          // console.log(stub, 'onstub');
          $('#' + id).hide();
          scope.noAd = true;
        }
      });
    }, 0));
  } else {
    $('#' + id).hide();
  }
}

public adCreation(nativeTag: any, adType: any) {
  this.googletagAvailable = this.commonService.checkGoogleTag();
  if (this.googletagAvailable === 'true') {
    let scope;
    scope = this;
    this.timer.push(setTimeout(function() {
      if (googletag.apiReady) {
        googletag = googletag || {};
        googletag.cmd = googletag.cmd || [];
        googletag.cmd.push(function() {
          googletag.pubads().enableSingleRequest();
          googletag.pubads().addEventListener('slotRenderEnded', function(event) {
              if (event.slot === scope.adSlot && (!event.isEmpty)) {
                scope.noAd = false;
              } else if (event.slot === scope.adSlot && (event.isEmpty)) {
                scope.noAd = true;
                // ad slot is not empty
              }
          });
          if (adType === 'square') {
            scope.adSlot = scope.commonService.defineAdSlot(nativeTag);
          } else {
            scope.commonService.defineAdSlot(nativeTag);
          }
          googletag.enableServices();
        });
        googletag.cmd.push(function() { googletag.display(nativeTag.div_id); });
      }
    }, 0));
  }
}

 private ageratefunction(): any {
       let localcountyCode, configCountries;
          localcountyCode = this.settingsService.getCountry();
        
          configCountries = this.configData && this.configData.AgeDisplay && this.configData.AgeDisplay.countries ? this.configData.AgeDisplay.countries : [];
      for (let i = 0; i < configCountries.length; i++) {
        let enableflag;
       if (this.configData.AgeDisplay && this.configData.AgeDisplay.enable !== null && this.configData.AgeDisplay.enable !== undefined ) {
          enableflag = this.configData.AgeDisplay.enable;
           if (enableflag) {
                if (localcountyCode === configCountries[i] || configCountries.length === 0 ) {
                  this.agetake = enableflag;
                   break;
                 } else {
                  this.agetake = false;
                 }
           } else {
              if (localcountyCode === configCountries[i] || configCountries.length === 0) {
                this.agetake = enableflag;
                 break;
               } else {
                this.agetake = enableflag;
               }
           }
         } else {
            this.agetake = false;
         }
       }
      
}

 private loadOnChange(startvideo: any) {
    this.showError = false;
     let  dataObject, scope, country_code, tags, category, movieTitle, breadCrumbArray, ageRate, countryCode,agerateValue ,userType;
      countryCode = this.settingsService.getCountry();
      dataObject = new MovieApi(this.http, null, this.apiconfig);
      scope = this;
       this.corousalMatadata = [];
        this.showCast = false;
       // for description
       country_code = this.settingsService.getCountry();
       userType = this.commonService.getUserType();
        dataObject.v1MovieByIdGet(this.id, null, country_code, null, null, null, userType).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
        // scope.favorite = false;
        scope.watched = false;
        this.apiRetryCount = 1;
           if ( value != null ) {
              // if(value.age_rating){
              //   this.contentAgeRating = value.age_rating;
              // }
               value.video = value.video_details ? value.video_details : {};
               this.movieData = value;
               //this.adoric_event(this.movieData);
               tags = (this.movieData.tags !== null && this.movieData.tags !== undefined) ? this.movieData.tags : [];
               category = this.commonService.getSubcategory (this.movieData.tags, 0, this.movieData.asset_subtype, this.movieData.genres, this.movieData.content_owner );
               this.newsContentOwner = this.commonService.getSubcategory (this.movieData.tags, 0, this.movieData.asset_subtype, this.movieData.genres, this.movieData.content_owner );
               this.asset_category = category.join(', ');
             this.availableOnChannel = (this.movieData.channels && this.movieData.channels !== (null && undefined) && this.movieData.channels.length > 0) ? this.movieData.channels.map(function(elem) {return elem.title; }).join(', ') : '';
            ageRate = this.movieData && this.movieData.age_rating ? this.movieData.age_rating : '';
            let ageratingList, countryList;
            countryList = this.settingsService.getCountryValueNew();
            ageratingList = countryList[0].age_rating; // age rating number json
            let validText;
             if (ageratingList && ageratingList[ageRate]) {
                if ( ageratingList[ageRate] === '0' ) {
                  this.valid_string =  this.translate.instant('MESSAGES.FOR_ALL');
                } else {
                this.translate.get(['MESSAGES.AGE_RATING']).subscribe( value => {
                validText = value['MESSAGES.AGE_RATING'];
                this.valid_string = validText.replace(/<age>/g, +  ageratingList[ageRate]);
               });
             } 
            } else {
                 this.valid_string =  ageRate;
             }
           this.ageratefunction();
          
            if (this.agetake) {
               this.ageRatingMovie = this.valid_string;
            } else {
              this.ageRatingMovie = ageRate;
            }
              if ( value.asset_subtype != null) {
                this.asset_subtype = value.asset_subtype;
                this.orginalAssettype = value.asset_subtype;

                if (this.asset_subtype === 'movie') {
                  this.urlcategory =  'movies/details/';
                } else if (this.asset_subtype === 'video' && this.movieData.genres.findIndex(i => i.id === 'News') !== -1) {
                  this.urlcategory =  'news/details/';
                } else {
                  this.urlcategory =  'videos/details/';
                }
                // this.urlcategory = (this.asset_subtype === 'movie' ) ?  'movies/details' : 'videos/details';
              }
              // this.showEmbedIcon = this.settingsService.embedLinkVisibility();
              // if (!this.movieData.business_type || this.movieData.business_type.indexOf('premium') === -1) {
              //   this.showEmbedIcon = this.settingsService.embedLinkVisibility();
              // }
              this.embedLinkVisibility();
                breadCrumbArray = [{'label': 'BREADCRUMB.HOME', 'url': '/', 'enable': true},
               {'label': (this.urlcategory === 'movies/details/' ) ? 'BREADCRUMB.MOVIES' : (this.urlcategory === 'news/details/' ) ? 'NEWS_PAGE.NEWS' : 'BREADCRUMB.VIDEOS', 'url': (this.urlcategory === 'movies/details/' ) ?  '/movies' : (this.urlcategory === 'news/details/' ) ? '/news' : '/videos' , 'enable': true},
               // {'label': (this.asset_subtype === 'movie' ) ? 'BREADCRUMB.MOVIES' : 'BREADCRUMB.VIDEOS', 'url': (this.asset_subtype === 'movie' ) ?  '/movies' : '/videos' , 'enable': true},
               {'label': (this.urlcategory === 'news/details/' ) ? (this.movieData.content_owner || this.movieData.title) : this.movieData.title, 'url': this.urlcategory + this.commonService.convertToLowercase(this.movieData.original_title) + '/' + this.movieData.id, 'enable': false}];
              this.headerservicesService.breadCrump(breadCrumbArray);
              let tempTitle;
              // this.movieData.original_title = (this.movieData.original_title  !== (null && undefined)) ? this.movieData.original_title  : 'title';
              // if (this.movieData && this.movieData.extended && this.movieData.extended.seo_title) {
              //     tempTitle = (this.movieData.extended.seo_title !== null || this.movieData.extended.seo_title !== undefined || this.movieData.extended.seo_title !== '') ? this.movieData.extended.seo_title : this.movieData.original_title;
              //   } else {
              //     tempTitle = (this.movieData.seo_title && (this.movieData.seo_title !== null || this.movieData.seo_title !== undefined || this.movieData.seo_title !== '')) ? this.movieData.seo_title : this.movieData.original_title;
              // }
              tempTitle = this.movieData.original_title;
              movieTitle = this.commonService.convertToLowercase(tempTitle);
                  if (window.location.pathname.indexOf(this.urlcategory) < 0 || movieTitle !== this.name) {
                      if (window.location.search.length > 0) {
                        // todo
                      } else {
                         // startvideo = false;
                        this.location.replaceState(this.urlcategory  + movieTitle + '/' + this.movieData.id);
                      }
                }
             this.countryOfOrigin = (value.countries && value.countries != null && value.countries.length > -1) ? value.countries.join(', ') : '';
             this.movieData.title = (this.movieData.title  !== (null && undefined)) ? this.movieData.title  : '';
            this.movieTitleEng = this.movieData.original_title;
            this.movieTitle = this.movieData.title;
            // this.movieData.languages.push('ms');
            // this.movieData.tags = ['music', 'audio_mm', 'audio_en', 'audio_pa', 'audio_ta'];
            // (this.movieData.tags &&  this.movieData.tags.length > 0) ? this.audiotagsFromTags(this.movieData.tags) : this.movie_tags = [];
            if ( value.video != null ) {
             if ( this.movieData.languages != null ) {
               if (this.movieData.languages.length !== 0 ) {
                  // if (this.movieData.languages.includes('ms') && this.movie_tags.length > 0) { // Malaya audio tag replacement
                  //   let langArray = [];
                  //     for (let i of this.movieData.languages) {
                  //       if (i !== 'ms') {
                  //         langArray.push(i);
                  //       }
                  //       this.finalLangArrayFormed(langArray);
                  //   }
                  // }
                  // else {
                    this.languages_array = value.languages;
                    this.fetchlanguages(1);
                  // }
               }
              } else {
                this.laguages = '';
              }

              if ( this.movieData.video.subtitles != null ) {
                this.subtitle_array = value.video.subtitles;
                this.fetchlanguages(2);
              } else {
                this.subtitlesLang = '';
              }
           } else {
             this.laguages = '';
             this.subtitlesLang = '';
           }

            //  if ( value.rating != null) {
            //   // this.ratingValue = value.rating;
            //   // this.calculateStars( this.ratingValue);
            //   // this.ratingString = this.ratingValue;
            //   this.ratingString = value.rating.toString();
            // } else {
            //    this.ratingString = '';
            //    // this.ratingValue  = false;
            //    // this.calculateStars(this.ratingValue);

            // }
            // this.movieDescription = (value.description != null) ? (value.description.length > 0) ? value.description : 'MESSAGES.NO_DATA' : 'MESSAGES.NO_DATA';
          let country_code = this.settingsService.getCountry();
          if (country_code !== 'IN') {
            this.movieDescription = (value.description) && (value.description.length > 0) ? value.description : 'NA';
          } else {
            if ( value.extended && value.extended.digital_long_description_web)  {
              this.movieDescription = (value.extended.digital_long_description_web.length > 0) ? value.extended.digital_long_description_web : 'NA';
            } else {
              this.movieDescription = (value.description) && (value.description.length > 0) ? value.description : 'NA';
            }
          }
             this.checkDesLen();
           if (!value.release_date || value.release_date !== null  || value.release_date !== undefined) {
             this.movieReleaseDate = value.release_date;
           } else {
             this.movieReleaseDate = '';
           }
            this.businessType = ( value.business_type && value.business_type !== null ) ? value.business_type : 'NA';
            this.premium =  (this.businessType.indexOf('premium') !== -1) ? true : false;
            this.headerservicesService.premium = (this.businessType.indexOf('premium') !== -1) ? true : false;
            if ( value.directors != null && value.directors.length > 0) {
              this.movieDirector = (value.directors.length > 1) ? value.directors.join(', ') : value.directors;
            } else {
              this.movieDirector = '';
            }
            this.movie_type = null;
            if (value.actors && value.actors[0] != null) {
                this.showCast = true;
               this.actorsNames = value.actors;
             } else {
              this.actorsNames = [];
                this.showCast = false;
             }
           if ( value.duration != null) {
              let time;
              time = this.updateTime(value.duration);
              this.time_string = (time !== '') ? (time) : '';
            }
            // this.storedData = this.userProfileService.getFavoriteData();
            // this.storedWatchData = this.userProfileService.getWatchData();
             if ( this.movie_type == null ) {
               this.movie_type = 'Movie';
             }
             // if ( this.ratingString.length < 2) {
             //   this.ratingString = this.ratingString + '.0';
             // }
            // if ( value.description != null ) {
            //   this.describtionString = value.description;
            //    this.showReadMore = ( this.describtionString.toString().length > this.index) ? true : false;
            // } else {
            //   this.showReadMore = false;
            // }
            if ( value.extended && value.extended.digital_long_description_web ) {
                this.describtionString = value.extended.digital_long_description_web;
                this.showReadMore = ( this.describtionString.toString().length > this.index) ? true : false;
            }  else if ( value.description ) {
                this.describtionString = value.description;
                this.showReadMore = ( this.describtionString.toString().length > this.index) ? true : false;
            } else {
              this.showReadMore = false;
            }
            if (this.urlcategory === 'news/details/') {
              this.relatedNews(value, 'related');
              this.relatedNews(value, 'recommended');
              this.moreInfo(value);
              // this.newsChannels();
            } else {
             this.relatedVideos(value);
             this.similarDataFunction();
            }
            let  genresdata, premium, activePlan;
            genresdata = (value.genres && value.genres !== (null && undefined) && value.genres.length > 0) ? value.genres.map(function(elem) {return elem.id; }).join(', ') : ' ';
            this.movieGenre = (value.genres && value.genres !== (null && undefined) && value.genres.length > 0) ? value.genres.map(function(elem) {return elem.value; }).join(', ') : 'NA';
            this.movieGenreArray = (value.genres && value.genres !== (null && undefined) && value.genres.length > 0) ? value.genres.map(function(elem) {return elem.value; }) : [];
              this.gAmovieGenre = genresdata;
              // this.category = this.filterService.getIds(value.genres);
              this.languages = this.filterService.getSelectedLanguage();

               premium = (this.businessType.indexOf('premium') !== -1) ? true : false;
               if (this.loginToken) {
                               activePlan = this.subscription.checkPlanApiSuccess(false);
               } else {
                 activePlan = [];
               }
               activePlan = (activePlan === undefined || activePlan.length <= 0) ? false : true;
              this.image_url = ( value.list_image != null ) ? this.basepath1 + this.id + '/list/' + '1920x770/' + value.list_image + '?imwidth=1920&impolicy=akamai_vidz1_zee5_com-IPM' : this.onErrorBanner;
                this.image_url_mobile = ( value.list_image != null ) ? this.basepath1 + this.id + '/list/' + '1440x810/' + value.list_image + '?imwidth=1440&impolicy=akamai_vidz1_zee5_com-IPM' : this.onErrorBanner_mob;
              this.onChangeSize();
              // this.metaService.updateTag({ property: 'og:title', content: value.title });
             // this.metaService.updateTag({ property: 'og:image', content: this.image_url, itemprop: 'image' });
              // this.metaService.updateTag({ property: 'og:description', content: value.description});
         this.metaService.updateTag({ property: 'og:image', content: this.image_url, itemprop: 'image' });
         this.metaService.updateTag({ property: 'og:image:url', content: this.image_url, itemprop: 'image' });
         this.metaService.updateTag({ property: 'og:image:type', content: 'image/png' });
         this.metaService.updateTag({ name: 'twitter:image', content: this.image_url});

              (function(d, s, id) {
               let js, fjs;
               fjs = d.getElementsByTagName(s)[0];
               if (d.getElementById(id)) {return; }
               js = d.createElement(s); js.id = id;
               js.src = '//connect.facebook.net/en_US/sdk.js';
               fjs.parentNode.insertBefore(js, fjs);
             }(document, 'script', 'facebook-jssdk'));

                this.fontResize();
                 scope.watched = scope.userProfileService.inList('watchList', value.id);
                 // scope.favorite = scope.userProfileService.inList('favorite', value.id);
                 $('#loaderPage').css('display', 'none');
                 let h, top;
                   h =  $('.banner_block').height();
                   top = (window.innerWidth <= 768) ? (window.innerWidth <= 480)  ? (h + 50) : (h + 100) : (h + 5);
                  $('#breadcrumInit').css('top', top + 'px');
                let movie_title, urlstring2 , tempURL;
                // if (this.movieData && this.movieData.extended && this.movieData.extended.seo_title) {
                //   tempTitle = (this.movieData.extended.seo_title !== null || this.movieData.extended.seo_title !== undefined || this.movieData.extended.seo_title !== '') ? this.movieData.extended.seo_title : this.movieData.original_title;
                // } else {
                //   tempTitle = (this.movieData.seo_title && (this.movieData.seo_title !== null || this.movieData.seo_title !== undefined || this.movieData.seo_title !== '')) ? this.movieData.seo_title : this.movieData.original_title;
                // }
                tempTitle = this.movieData.original_title;
                movie_title = this.commonService.convertToLowercase(tempTitle);
                tempURL =  this.urlcategory + movie_title + '/' + this.movieData.id;
                urlstring2 = tempURL.split(' ').join('');
                this.shareURL =  urlstring2;
                movie_title = this.commonService.convertToLowercase(this.movieData.original_title);
                this.linkservice.removeampLink();
                this.linkservice.addTag({ rel: 'amphtml', href: window.location.origin + '/amp/' + this.routeservice.getBaseLocation() + this.urlcategory + movie_title + '/' + this.movieData.id} );
                this.linkservice.addTag({ rel: 'canonical', href: window.location.origin + '/' + this.routeservice.getBaseLocation() + this.urlcategory + movie_title + '/' + this.movieData.id} );
                this.contentUrl = this.shareURL;
                this.schema();
                this.orginalAssettype = value.asset_subtype;
                this.assetType = (value.asset_subtype === 'movie') ? 'Movie' : 'Video';
                 if (this.urlcategory === 'videos/details/') {
                    // this.seoService.moviePages(this.commonService.convertToLowercase(tempTitle), value.video.audiotracks[0], this.gAmovieGenre, 'Video');
                    this.seoService.moviePages(tempTitle, value.video.audiotracks[0], this.gAmovieGenre, 'Video');

                 } else if (this.urlcategory === 'news/details/') {
                    // this.seoService.newsPages(this.commonService.convertToLowercase(tempTitle), 'News');
                    this.seoService.newsPages(tempTitle, 'News');

                 } else {
                  // this.actorsNames.join(),this.movieDirector
                  let metaActors;
                  metaActors = [];
                    for ( let i = 0 ; i < this.actorsNames.length; i++) {
                      metaActors.push(this.actorsNames[i].split(':')[0]);
                    }

                   let seoObj;
                   seoObj = {
                     extented_seo_title: (this.movieData.extended ? this.movieData.extended.seo_title : null) || null,
                     seo_title: this.movieData.seo_title || null,
                     title: this.movieData.title || this.movieData.original_title,
                     keywords: (this.movieData.extended ? this.movieData.extended.digital_keywords : null) || null,
                     description: (this.movieData.extended ? this.movieData.extended.seo_description : null) || null,
                   };
                   if (this.movieData.business_type.indexOf('premium') < 0) {
                    this.seoService.movieFree(seoObj, tempTitle, this.gAmovieGenre, metaActors.join(), this.movieDirector, 'movieFree');
                   } else {
                    this.seoService.movieFree(seoObj, tempTitle, this.gAmovieGenre, metaActors.join(), this.movieDirector, 'moviePremium');
                   }
                 }
                 this.adApiCall();
                 if (startvideo === true) {
                   this.startVideo('event');
                 }
                 this.ShowwtachNow(); // function to update watch trailler or watch now
                 this.pageName = this.gAlanguage + '|' + this.assetType + '|' + this.gAmovieGenre + '|' + 'NA' + '|' + this.movieTitleEng;
                 this.gtm.sendPageName(this.pageName);
                 this.gtm.sendEvent();
                 this.RTRMBLOCK = this.headerservicesService.getRemarketing();
                 if (this.RTRMBLOCK !== true) {
                 this.gtm.ZeoTapingEvents(this.movieTitle, this.laguages, this.movieGenre, this.assetType, 'Na');
                 }
              } else {
                this.showError = true;
                $('#loaderPage').css('display', 'none');
              }
       },
       err => {
         this.showErroronError(err);
         this.headerservicesService.breadCrump('');
                  });
       // window.scrollTo(0, 0);
          // $( "html,body" ).scrollTop(-70);


 }

  private embedLinkVisibility(): void {
    // this.showEmbedIcon = this.settingsService.embedLinkVisibility() && (this.countryCode === 'IN' || this.movieData.business_type.indexOf('premium') === -1);
    this.showEmbedIcon = this.settingsService.embedLinkVisibility(this.movieData.business_type);
  }

 private similarDataFunction(): any {
   let dataObject1, country_code , page , pageSize, userType;
   page = 1;
   pageSize = 25;
   this.baseCategory = (this.movieData.asset_subtype === 'movie') ? 'movies/details/' : 'videos/details/';
    this.genreUpnext = this.movieData.genres ? this.movieData.genres.map(function(elem) {return elem.id; }).sort().join(',') : '';
    this.genreUpnext = this.genreUpnext  ? this.genreUpnext  : undefined;
    this.languages = this.filterService.getSelectedLanguage();
    country_code = this.settingsService.getCountry();
    dataObject1 = new MovieApi(this.http, null, this.apiconfig);
    country_code = this.settingsService.getCountry();
    userType = this.commonService.getUserType();
    dataObject1.v1similarGet(this.orginalAssettype, 'releasedate', 'desc', page, pageSize , this.genreUpnext, 'v1', null, this.languages, country_code, null, this.movieData.id, null, userType).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe( similarvalue => {
      this.similarstring = similarvalue.title;
      let similar, orginalSimilarTilte;
      orginalSimilarTilte = similarvalue && similarvalue.original_title ? similarvalue.original_title : this.similarstring;
      similar = similarvalue.items && similarvalue.items.length > 0 ? similarvalue.items : [];
       if (similar.length > 0) {
        this.nodata = false;
          this.similarData.content =  similar.slice(0, 20);
          this.similarData.id = this.movieData.id;
       } else {
        this.nodata = true;
       }

       if (this.movieData.asset_subtype === 'movie') {
      this.similarDataMobile = {'title': this.similarstring , 'original_title' : orginalSimilarTilte, 'id' : this.movieData.id, 'type' : 'movies', 'content':  this.commonService.restrictLength(similar) , 'assetSubType': this.movieData.asset_subtype, 'category' : this.similarstring , 'link': 'movies'};

    } else {
      this.similarDataMobile = {'title': this.similarstring , 'original_title' : orginalSimilarTilte, 'id' : this.movieData.id, 'type' : 'videos', 'content':  this.commonService.restrictLength(similar) , 'assetSubType': this.movieData.asset_subtype, 'category' : this.similarstring , 'link': 'movies'};

      // this.similarDataMobile = { 'original_length': similar.length, 'title': this.similarstring , 'original_title' : orginalSimilarTilte, 'id' : this.movieData.id, 'type' : 'movies', 'content':  this.commonService.restrictLength(similar) , 'assetSubType': this.movieData.asset_subtype, 'category' : this.similarstring , 'link': 'movies'};
    }
      this.talamoosImpression = true;
    }, error => {
      this.talamoosImpression = true;
      this.nodata = true;
      this.gtm.sendErrorEvent('api', error);
    });
 }

 private checkDesLen(): void {
    let len;
        len = this.movieDescription ? this.movieDescription.length : 0;
        this.dots = (this.movieDescription === 'NA' || len < 200 ) ? '' : '...';
        if (len < 200) {
          this.readText = '';
        } else {
          this.readText = 'DETAILS.READ_MORE';
          this.dots = '...';
        // this.toggleReadMore();
        }
 }
  private toggleReadMore(): void {
       this.readText = (this.textLimit > 200) ? 'DETAILS.READ_MORE' :  'DETAILS.READ_LESS';
       this.textLimit = (this.textLimit > 200) ? 200 : (this.movieDescription ? this.movieDescription.toString().length : 'NA');
       this.readMovieArrow = (this.textLimit > 200) ? true :  false;
       this.dots = (this.readText === 'DETAILS.READ_MORE') ? '...' : '';
     }
  private relatedVideos(value): void {
    let individual_node, temp_first_array, temp_second_array, movies, movies1, multiple_related_nodes;
    this.corousalMatadata = [];
    this.firsttray = [];
    this.secondtray = [];
    this.corousalData = [];
    this.show_first_tray = false;
    this.show_second_tray = false;
    temp_first_array = [];
    temp_second_array = [];
    movies = [];
    movies1 = [];
    multiple_related_nodes = false;
    // carousals with multiple related nodes (related_movies_ss and related_videos_ss)
    if (this.movieData.asset_subtype === 'movie') {
      if (this.movieData && this.movieData.related_movies_ss && this.movieData.related_movies_ss.items && this.movieData.related_movies_ss.items.length > 0) {
        movies = { 'title': this.movieData.related_movies_ss.title, 'original_title': this.movieData.related_movies_ss.original_title, 'type': 'movies', 'content': this.movieData.related_movies_ss.items, 'trailer': true};
        multiple_related_nodes = true;
      }
    } else {
      if (this.movieData && this.movieData.related_videos_ss && this.movieData.related_videos_ss.items && this.movieData.related_videos_ss.items.length > 0) {
        movies = { 'title': this.movieData.related_videos_ss.title, 'original_title': this.movieData.related_videos_ss.original_title, 'type': 'videos', 'content': this.movieData.related_videos_ss.items, 'trailer': true};
        multiple_related_nodes = true;
      }
    }

    // separate related into related movies and related videos
    for (individual_node of value.related) {
      if (this.movieData.asset_subtype === 'movie') {
        if (individual_node.asset_subtype === 'movie') {
          temp_first_array.push(individual_node);
        } else {
            if (individual_node.asset_subtype === 'trailer') {
              this.trailerVideoId = individual_node.id;
              this.trailerflag = true;
              this.trailerdata = individual_node;
            }
          temp_second_array.push(individual_node);
        }
      } else {
        if (individual_node.asset_subtype === 'movie') {
          temp_second_array.push(individual_node);
        } else {
            if (individual_node.asset_subtype === 'trailer') {
              this.trailerVideoId = individual_node.id;
              this.trailerflag = true;
              this.trailerdata = individual_node;
            }
          temp_first_array.push(individual_node);
        }
      }
    }
    // first tray - fallback, if no data in multiple related nodes
    if (!multiple_related_nodes && temp_first_array.length > 0) {
      this.show_first_tray = true;
      if (temp_first_array[0].asset_subtype === 'movie') {
        movies = { 'title': 'TVGUIDE.RELATED_MOVIES', 'original_title': 'Related Movies' , 'type': 'movies', 'parentType': 'trailer', 'content': temp_first_array};
      } else {
        movies = { 'title': 'SUSCRIPTION.RELATED_VIDEOS', 'original_title': 'Related Videos' , 'type': 'videos', 'parentType': 'trailer', 'content': temp_first_array};
      }
    }
    // second tray
    if (temp_second_array.length > 0) {
      if (temp_second_array[0].asset_subtype === 'movie') {
        movies1 = { 'title': 'TVGUIDE.RELATED_MOVIES', 'original_title': 'Related Movies' , 'type': 'movies', 'parentType': 'trailer', 'content': temp_second_array};
      } else {
        movies1 = { 'title': 'SUSCRIPTION.RELATED_VIDEOS', 'original_title': 'Related Videos' , 'type': 'videos', 'parentType': 'trailer', 'content': temp_second_array};
      }
      this.secondtray = movies1;
      this.show_second_tray = true;
    }

    // talamoos
    let x, userType, country_code;
    x = new CollectionApi(this.http, null, this.apiconfig);
    userType = this.commonService.getUserType();
    country_code = this.settingsService.getCountry();
    let countrylist;
    countrylist = this.settingsService.getCountryValueNew();
    if (countrylist && countrylist.length > 0 && countrylist[0].recommendations && countrylist[0].recommendations === true) {
      x.v1RecommendationByAssetIdGet(this.id, null, null, null, country_code, null, null, null, userType, null).takeUntil(this.ngUnsubscribe).subscribe( rValue => {
      let recoArray;
      recoArray = [];
        if (rValue.buckets && rValue.buckets.length > 0 ) {
          this.talamoosEnable = true;
          this.adoric_event(rValue);
          for (let i = 0 ; i < rValue.buckets.length; i++) {
            let singleton;
            if (rValue.buckets[i].items && rValue.buckets[i].items.length > 0 && rValue.buckets[i].items[0].asset_subtype === 'movie') {
              singleton = { 'title': rValue.buckets[i].title, 'original_title': rValue.buckets[i].original_title , 'type': 'movies', 'parentType': 'trailer', 'content': rValue.buckets[i].items, 'modelname': rValue.buckets[i].modelName};
              recoArray.push(singleton);
            } else {
              singleton = { 'title': rValue.buckets[i].title, 'original_title': rValue.buckets[i].original_title , 'type': 'videos', 'parentType': 'trailer', 'content': rValue.buckets[i].items, 'modelname': rValue.buckets[i].modelName};
              recoArray.push(singleton);
            }
          }
          this.show_first_tray = true;
        }
        this.firsttray = recoArray;
        this.createRelatedCarousals();
      }, err => {
        this.corousalData = [movies];
        this.createRelatedCarousals();
      });
    } else {
      this.corousalData = [movies];
      this.createRelatedCarousals();
      this.adoric_event(this.movieData);
    }
  }
  // function to add multiple related carousals
  public createRelatedCarousals() {
    let data;
    if (this.movieData && this.movieData.related_collections_ss && this.movieData.related_collections_ss.items && this.movieData.related_collections_ss.items.length > 0) {
      data = { 'title': this.movieData.related_collections_ss.title, 'original_title': this.movieData.related_collections_ss.original_title, 'type': 'tvshows', 'content': this.movieData.related_collections_ss.items, 'trailer': true};
      this.corousalData.push(data);
    }
    if (this.movieData && this.movieData.related_tvshows_ss && this.movieData.related_tvshows_ss.items && this.movieData.related_tvshows_ss.items.length > 0) {
      data = { 'title': this.movieData.related_tvshows_ss.title, 'original_title': this.movieData.related_tvshows_ss.original_title, 'type': 'tvshows', 'content': this.movieData.related_tvshows_ss.items, 'trailer': true};
      this.corousalData.push(data);
    }
    if (this.secondtray  && this.secondtray.type === 'movies') {
      if (this.movieData && this.movieData.related_movies_ss && this.movieData.related_movies_ss.items && this.movieData.related_movies_ss.items.length > 0) {
        data = { 'title': this.movieData.related_movies_ss.title, 'original_title': this.movieData.related_movies_ss.original_title, 'type': 'movies', 'content': this.movieData.related_movies_ss.items, 'trailer': true};
        this.corousalData.push(data);
      } else {
        if (this.show_second_tray) {
          this.corousalData.push(this.secondtray);
        }
      }
    } else {
      if (this.movieData && this.movieData.related_videos_ss && this.movieData.related_videos_ss.items && this.movieData.related_videos_ss.items.length > 0) {
        data = { 'title': this.movieData.related_videos_ss.title, 'original_title': this.movieData.related_videos_ss.original_title, 'type': 'videos', 'content': this.movieData.related_videos_ss.items, 'trailer': true};
        this.corousalData.push(data);
      } else {
        if (this.show_second_tray && this.secondtray  && this.secondtray.type === 'videos') {
          this.corousalData.push(this.secondtray);
        }
      }
    }
    if (this.movieData && this.movieData.related_channels_ss && this.movieData.related_channels_ss.items && this.movieData.related_channels_ss.items.length > 0) {
      data = { 'title': this.movieData.related_channels_ss.title, 'original_title': this.movieData.related_channels_ss.original_title, 'type': 'channels', 'content': this.movieData.related_channels_ss.items, 'trailer': true, 'original_length': this.movieData.related_channels_ss.items.length};
      this.corousalData.push(data);
    }
  }
 public relatedNews(newsData, type) {
    let x, pageNo, itemLimit, genre, content_owner, userType;
    x = new CollectionApi(this.http, null, this.apiconfig);
    pageNo = 1;
    itemLimit = 25;
    genre = newsData.genres ? newsData.genres.map(function(elem) {return elem.id; }).sort().join(',') : '';
    genre = genre ? genre : undefined;
    content_owner = newsData.content_owner ? newsData.content_owner : undefined;
    userType = this.commonService.getUserType();
    let country_code, countrylist;
    country_code = this.settingsService.getCountry();
    countrylist = this.settingsService.getCountryValueNew();
    if (countrylist && countrylist.length > 0 && countrylist[0].recommendations && countrylist[0].recommendations == true) {
      if (type === 'related') {
      x.v1RecommendationByAssetIdGet(newsData.id, null, null, null, country_code, null, null, null, null, userType).takeUntil(this.ngUnsubscribe).subscribe(Rvalue => {
        if (Rvalue && Rvalue.buckets && Rvalue.buckets.length > 0) {
          let relatednews = Rvalue.buckets[0];
          let  list = {'title': relatednews.title , 'original_title': relatednews.original_title, 'id': relatednews.id, 'type': 'videos', 'parentType': type, 'link': 'videos', 'content': relatednews.items, 'original_length': 1,next_url: Math.ceil(relatednews.total / itemLimit),'modelname': relatednews.modelName, 'api_details': {'genre': genre, 'content_owner': content_owner, 'news_id': this.movieData.id}};
          this[type + 'NewsCarousels'] = list;
          if (Rvalue.buckets.length > 1) {
            this.dataArray = [];
            this.showscrollgrid = true;
            for (let i = 1; i < Rvalue.buckets.length; i++) {
                let list1 = {'title': Rvalue.buckets[i].title , 'original_title': Rvalue.buckets[i].original_title, 'id': Rvalue.buckets[i].id, 'type': 'videos', 'parentType': type, 'link': 'videos', 'content': Rvalue.buckets[i].items, 'original_length': 1,next_url: Math.ceil(Rvalue.buckets[i].total / itemLimit),'modelname': Rvalue.buckets[i].modelName, 'api_details': {'genre': genre, 'content_owner': content_owner, 'news_id': this.movieData.id}};
                this.dataArray.push(list1);
            }
          }
          let similar = relatednews.items && relatednews.items.length > 0 ? relatednews.items : [];
          this.similarData =  similar.slice(0, 20);
          this.similarData.content =  similar.slice(0, 20);
          this.similarData.id = relatednews.id;
          this.similarData.modelName = relatednews.modelName;
          this.nodata = false;
          this.similarstring = relatednews.title;
          this.similarDataMobile = this.relatedNewsCarousels;
          // if (!this.addPaddingCast && this.similarData && this.similarData.content && this.similarData.content.length > 0) {
            this.gtm.talamoosGA(0, relatednews.original_title);
          // }
          this.getnewsYIndex();
        } else {
     x.v1DetailNewsCollectionByIdGet('related', newsData.id, pageNo, null, itemLimit, genre, content_owner, null, null, null, null, userType).timeout(environment.timeOut).takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.apiRetryCount = 1;
      let list, relatednews, similar;
       value.buckets = this.commonService.removeWebView(value.buckets);
      if (value.buckets && value.buckets[0] && value.buckets[0].items && value.buckets[0].items.length) {
        relatednews = value.buckets[0];
        similar = relatednews.items && relatednews.items.length > 0 ? relatednews.items : [];
        if (similar.length > 0) {
          let title, original_title, temp_title = relatednews.title ? relatednews.title : null;
          switch (temp_title) {
                  case 'webisodes' :
                  case 'Webisodes':
                  temp_title = ( newsData.extended && newsData.extended.production_design && (newsData.extended.production_design !== null || newsData.extended.production_design !== ''))
                  ? newsData.extended.production_design : temp_title;
                  break;
                  case 'clip' :
                  case 'Clip':
                  temp_title = ( newsData.extended && newsData.extended.set_decoration && (newsData.extended.set_decoration !== null || newsData.extended.set_decoration !== ''))
                   ? newsData.extended.set_decoration : temp_title;
                  break;
                  case 'previews' :
                  case 'Previews':
                  temp_title = ( newsData.extended && newsData.extended.production_company && (newsData.extended.production_company !== null || newsData.extended.production_company !== ''))
                   ? newsData.extended.production_company : temp_title;
                  break;
                  case 'performances' :
                  case 'Performances':
                  temp_title = ( newsData.extended && newsData.extended.sponsor && (newsData.extended.sponsor !== null || newsData.extended.sponsor !== ''))
                   ? newsData.extended.sponsor : temp_title;
                  break;
               }

            // this.similarData =  similar.slice(0, 20);
            this.similarData.content =  similar.slice(0, 20);
            this.similarData.id = relatednews.id;
            this.nodata = false;

            title = (temp_title && temp_title !== null) ? temp_title : 'NEWS_PAGE.RELATED_NEWS';
            original_title = relatednews.original_title ? relatednews.original_title : 'Related News';
            this.similarstring = title;
          list = {'title': title , 'original_title': original_title, 'id': relatednews.id, 'type': 'videos', 'parentType': type, 'link': 'videos', 'content': relatednews.items, 'original_length': 1, next_url: Math.ceil(relatednews.total / itemLimit), 'api_details': {'genre': genre, 'content_owner': content_owner, 'news_id': this.movieData.id}};
        }
        this[type + 'NewsCarousels'] = list;
        this.similarDataMobile = this.relatedNewsCarousels;
        this.getnewsYIndex();
      }
    },
    err => {
      this.gtm.sendErrorEvent('api', err);
      if (err.status === 401 && this.apiRetryCount < this.apiRetry) {
        this.apiRetryCount ++;
        this.commonService.refreshToken().then(
          () => {
            this.relatedNews(newsData, type);
          },
          () => { // nothing
          },
          );
      }
    }
    );
        }
        }, err => {
 x.v1DetailNewsCollectionByIdGet('related', newsData.id, pageNo, null, itemLimit, genre, content_owner, null, null, null, null, userType).timeout(environment.timeOut).takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.apiRetryCount = 1;
      let list, relatednews, similar;
       value.buckets = this.commonService.removeWebView(value.buckets);
      if (value.buckets && value.buckets[0] && value.buckets[0].items && value.buckets[0].items.length) {
        relatednews = value.buckets[0];
        similar = relatednews.items && relatednews.items.length > 0 ? relatednews.items : [];
        if (similar.length > 0) {
          let title, original_title, temp_title = relatednews.title ? relatednews.title : null;
          switch (temp_title) {
                  case 'webisodes' :
                  case 'Webisodes':
                  temp_title = ( newsData.extended && newsData.extended.production_design && (newsData.extended.production_design !== null || newsData.extended.production_design !== ''))
                  ? newsData.extended.production_design : temp_title;
                  break;
                  case 'clip' :
                  case 'Clip':
                  temp_title = ( newsData.extended && newsData.extended.set_decoration && (newsData.extended.set_decoration !== null || newsData.extended.set_decoration !== ''))
                   ? newsData.extended.set_decoration : temp_title;
                  break;
                  case 'previews' :
                  case 'Previews':
                  temp_title = ( newsData.extended && newsData.extended.production_company && (newsData.extended.production_company !== null || newsData.extended.production_company !== ''))
                   ? newsData.extended.production_company : temp_title;
                  break;
                  case 'performances' :
                  case 'Performances':
                  temp_title = ( newsData.extended && newsData.extended.sponsor && (newsData.extended.sponsor !== null || newsData.extended.sponsor !== ''))
                   ? newsData.extended.sponsor : temp_title;
                  break;
               }

            // this.similarData =  similar.slice(0, 20);
            this.similarData.content =  similar.slice(0, 20);
            this.similarData.id = relatednews.id;
            this.nodata = false;

            title = (temp_title && temp_title !== null) ? temp_title : 'NEWS_PAGE.RELATED_NEWS';
            original_title = relatednews.original_title ? relatednews.original_title : 'Related News';
            this.similarstring = title;
          list = {'title': title , 'original_title': original_title, 'id': relatednews.id, 'type': 'videos', 'parentType': type, 'link': 'videos', 'content': relatednews.items, 'original_length': 1, next_url: Math.ceil(relatednews.total / itemLimit), 'api_details': {'genre': genre, 'content_owner': content_owner, 'news_id': this.movieData.id}};
        }
        this[type + 'NewsCarousels'] = list;
        this.similarDataMobile = this.relatedNewsCarousels;
        this.getnewsYIndex();
      }
    },
    err => {
      this.gtm.sendErrorEvent('api', err);
      if (err.status === 401 && this.apiRetryCount < this.apiRetry) {
        this.apiRetryCount ++;
        this.commonService.refreshToken().then(
          () => {
            this.relatedNews(newsData, type);
          },
          () => { // nothing
          },
          );
      }
    }
    );

        })
    } else {
          x.v1DetailNewsCollectionByIdGet(type, newsData.id, pageNo, null, itemLimit, genre, content_owner, null, null, null, null, userType).timeout(environment.timeOut).takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.apiRetryCount = 1;
      let list, relatednews, similar;
       value.buckets = this.commonService.removeWebView(value.buckets);
      if (value.buckets && value.buckets[0] && value.buckets[0].items && value.buckets[0].items.length) {
        relatednews = value.buckets[0];
        similar = relatednews.items && relatednews.items.length > 0 ? relatednews.items : [];
        if (similar.length > 0) {
          let title, original_title, temp_title = relatednews.title ? relatednews.title : null;
          switch (temp_title) {
                  case 'webisodes' :
                  case 'Webisodes':
                  temp_title = ( newsData.extended && newsData.extended.production_design && (newsData.extended.production_design !== null || newsData.extended.production_design !== ''))
                  ? newsData.extended.production_design : temp_title;
                  break;
                  case 'clip' :
                  case 'Clip':
                  temp_title = ( newsData.extended && newsData.extended.set_decoration && (newsData.extended.set_decoration !== null || newsData.extended.set_decoration !== ''))
                   ? newsData.extended.set_decoration : temp_title;
                  break;
                  case 'previews' :
                  case 'Previews':
                  temp_title = ( newsData.extended && newsData.extended.production_company && (newsData.extended.production_company !== null || newsData.extended.production_company !== ''))
                   ? newsData.extended.production_company : temp_title;
                  break;
                  case 'performances' :
                  case 'Performances':
                  temp_title = ( newsData.extended && newsData.extended.sponsor && (newsData.extended.sponsor !== null || newsData.extended.sponsor !== ''))
                   ? newsData.extended.sponsor : temp_title;
                  break;
               }
            title = (temp_title && temp_title !== null) ? temp_title : 'NEWS_PAGE.RECOMMENDED';
            original_title = relatednews.original_title ? relatednews.original_title : 'Recommended';
          list = {'title': title , 'original_title': original_title, 'id': relatednews.id, 'type': 'videos', 'parentType': type, 'link': 'videos', 'content': relatednews.items, 'original_length': 1, next_url: Math.ceil(relatednews.total / itemLimit), 'api_details': {'genre': genre, 'content_owner': content_owner, 'news_id': this.movieData.id}};
        }
        this[type + 'NewsCarousels'] = list;
        this.similarDataMobile = this.relatedNewsCarousels;
        this.getnewsYIndex();
      }
    },
    err => {
      this.gtm.sendErrorEvent('api', err);
      if (err.status === 401 && this.apiRetryCount < this.apiRetry) {
        this.apiRetryCount ++;
        this.commonService.refreshToken().then(() => {
            this.relatedNews(newsData, type);
          },() => { // nothing
          },);}
    });
    }
    } else {
          x.v1DetailNewsCollectionByIdGet(type, newsData.id, pageNo, null, itemLimit, genre, content_owner, null, null, null, null, userType).timeout(environment.timeOut).takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.apiRetryCount = 1;
      let list, relatednews, similar;
       value.buckets = this.commonService.removeWebView(value.buckets);
      if (value.buckets && value.buckets[0] && value.buckets[0].items && value.buckets[0].items.length) {
        relatednews = value.buckets[0];
        similar = relatednews.items && relatednews.items.length > 0 ? relatednews.items : [];
        if (similar.length > 0) {
          let title, original_title, temp_title = relatednews.title ? relatednews.title : null;
          switch (temp_title) {
                  case 'webisodes' :
                  case 'Webisodes':
                  temp_title = ( newsData.extended && newsData.extended.production_design && (newsData.extended.production_design !== null || newsData.extended.production_design !== ''))
                  ? newsData.extended.production_design : temp_title;
                  break;
                  case 'clip' :
                  case 'Clip':
                  temp_title = ( newsData.extended && newsData.extended.set_decoration && (newsData.extended.set_decoration !== null || newsData.extended.set_decoration !== ''))
                   ? newsData.extended.set_decoration : temp_title;
                  break;
                  case 'previews' :
                  case 'Previews':
                  temp_title = ( newsData.extended && newsData.extended.production_company && (newsData.extended.production_company !== null || newsData.extended.production_company !== ''))
                   ? newsData.extended.production_company : temp_title;
                  break;
                  case 'performances' :
                  case 'Performances':
                  temp_title = ( newsData.extended && newsData.extended.sponsor && (newsData.extended.sponsor !== null || newsData.extended.sponsor !== ''))
                   ? newsData.extended.sponsor : temp_title;
                  break;
               }
          if (type === 'related') {
            // this.similarData =  similar.slice(0, 20);
            this.similarData.content =  similar.slice(0, 20);
            this.similarData.id = relatednews.id;
            this.nodata = false;

            title = (temp_title && temp_title !== null) ? temp_title : 'NEWS_PAGE.RELATED_NEWS';
            original_title = relatednews.original_title ? relatednews.original_title : 'Related News';
            this.similarstring = title;
          } else {
            title = (temp_title && temp_title !== null) ? temp_title : 'NEWS_PAGE.RECOMMENDED';
            original_title = relatednews.original_title ? relatednews.original_title : 'Recommended';
          }
          list = {'title': title , 'original_title': original_title, 'id': relatednews.id, 'type': 'videos', 'parentType': type, 'link': 'videos', 'content': relatednews.items, 'original_length': 1, next_url: Math.ceil(relatednews.total / itemLimit), 'api_details': {'genre': genre, 'content_owner': content_owner, 'news_id': this.movieData.id}};
        }
        this[type + 'NewsCarousels'] = list;
        this.similarDataMobile = this.relatedNewsCarousels;
        this.getnewsYIndex();
      }
    },
    err => {
      this.gtm.sendErrorEvent('api', err);
      if (err.status === 401 && this.apiRetryCount < this.apiRetry) {
        this.apiRetryCount ++;
        this.commonService.refreshToken().then(
          () => {
            this.relatedNews(newsData, type);
          },
          () => { // nothing
          },
          );
      }
    }
    );
    }
 }
 public moreInfo(newsData) {
    let x, pageNo, itemLimit, genre, content_owner, channel_name, userType;
    x = new CollectionApi(this.http, null, this.apiconfig);
    pageNo = 1;
    itemLimit = 25;
    genre = undefined;
    content_owner = newsData.content_owner ? newsData.content_owner : undefined;
    // channel_name = content_owner ? content_owner : 'NEWS_PAGE.NEWS';
    channel_name = content_owner ? content_owner : undefined;
    userType = this.commonService.getUserType();
    x.v1ChannelNewsCollectionByIdGet('news', newsData.id, pageNo, null, itemLimit, null, content_owner, null, null, null, null, userType).timeout(environment.timeOut).takeUntil(this.ngUnsubscribe).subscribe(value => {
    // x.v1ChannelNewsCollectionByIdGet('news', null, pageNo, null, itemLimit, null, content_owner).timeout(environment.timeOut).takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.apiRetryCount = 1;
      let list, relatednews, similar;
      value.buckets = this.commonService.removeWebView(value.buckets);
      if (value.buckets && value.buckets[0] && value.buckets[0].items && value.buckets[0].items.length) {
        relatednews = value.buckets[0];
        similar = relatednews.items && relatednews.items.length > 0 ? relatednews.items : [];
        if (similar.length > 0) {
          let title, original_title;
          title = channel_name ? 'MENU.MORE_FROM' : relatednews.title;
          original_title = channel_name ? 'More From' : relatednews.original_title;
          if (!title) {
            title = 'MENU.MORE_FROM';
            original_title = 'More From News';
            channel_name = 'NEWS_PAGE.NEWS';
          }
          list = {'title': title , 'original_title': original_title, 'id': relatednews.id, 'type': 'videos', 'parentType': 'moreinfo', 'link': 'videos', 'content': relatednews.items, 'original_length': 1, 'channel_name': channel_name, next_url: Math.ceil(relatednews.total / itemLimit), 'api_details': {'genre': genre, 'content_owner': content_owner, 'news_id': this.movieData.id}};
        }
        this.moreinfoNewsCarousels = list;
        this.getnewsYIndex();
      }
    },
    err => {
      this.gtm.sendErrorEvent('api', err);
      if (err.status === 401 && this.apiRetryCount < this.apiRetry) {
        this.apiRetryCount ++;
        this.commonService.refreshToken().then(
          () => {
            this.moreInfo(newsData);
          },
          () => {
            // nothing
          },
          );
      }
    }
    );
 }

  public getnewsYIndex(): any {
    let index;
    index = -1;
    this.newsYIndex = [-1, -1, -1];
    /* up-next, related shows, banners, similar channels, related channels, more news*/
    if (this.relatedNewsCarousels && this.relatedNewsCarousels.content && this.relatedNewsCarousels.content.length > 0) {
      this.newsYIndex[0] = ++index;
    }
    if (this.recommendedNewsCarousels && this.recommendedNewsCarousels.content && this.recommendedNewsCarousels.content.length > 0) {
      this.newsYIndex[1] = ++index;
    }
    if (this.moreinfoNewsCarousels && this.moreinfoNewsCarousels.content && this.moreinfoNewsCarousels.content.length > 0) {
      this.newsYIndex[2] = ++index;
    }
  }
  private schema(): void {
    let base;
     base = (this.urlcategory === 'movies/details/' ) ?  'movies' : (this.urlcategory === 'news/details/' ) ?  'news' : 'videos';
      const json_ld = {
                        '@context': 'http://schema.org',
                        '@type': 'Movie',
                        'name': this.movieData.original_title,
                        'dateCreated': this.commonService.dateChange(this.movieReleaseDate),
                        'director':  this.movieDirector,
                        'actors':  this.actorsNames,
                        'image': this.image_url,
                        'countryOfOrigin': this.countryOfOrigin,
                        'duration':  this.time_string,
                        'musicBy': 'MUSIC',
                        'subtitleLanguage': this.subtitlesLang,
                        'trailer': {
                        '@type': 'VideoObject',
                        'name': this.movieData.original_title,
                        'description': this.describtionString,
                        'thumbnailUrl': this.image_url,
                        'uploadDate': this.movieReleaseDate,
                        'aggregateRating':
                            {'@type': 'AggregateRating',
                             'ratingValue': this.movieData.rating ? this.movieData.rating.toFixed(1).toString() : '',
                             // 'ratingValue': this.ratingString,
                            }
                        }
                      };
                         let script;

                         script = document.createElement('script');
                         script.id = 'schema';
                         script.type = 'application/ld+json';
                         script.innerHTML = JSON.stringify(json_ld);
                         if (document.getElementById('moviedetailsMarkup')) {
                         document.getElementById('moviedetailsMarkup').appendChild(script);
                       }
                          const json_ld2 = {
                          '@context': 'http://schema.org',
                          '@type': 'BreadcrumbList',
                          'itemListElement': [{
                            '@type': 'ListItem',
                            'position': 1,
                            'item': {
                              '@id': environment.shareUrl + this.routeservice.getBaseLocation() + base,
                              'name': 'Movies',
                            }
                          }, {
                            '@type': 'ListItem',
                            'position': 2,
                            'item': {
                              '@id': this.contentUrl,
                              'name': this.movieData.original_title,
                            }
                          }]
                        };
                        // var script;
                         script = document.createElement('script');
                         script.id = 'schema';
                         script.type = 'application/ld+json';
                         script.innerHTML = JSON.stringify(json_ld2);
                         if (document.getElementById('breadcrumpMarkup')) {
                         document.getElementById('breadcrumpMarkup').appendChild(script);
                       }
  }
  private ShowwtachNow() {     // to display watch trailler r watch now
    if (this.premium === true) {
      if (this.loginToken !== null && this.subscriptionType === true) {
        // todo
      } else {
        if (this.trailerflag === true) {
          this.showTrailer = true;
        }
      }
    }
  }

 private showErroronError(error) {
    this.gtm.sendErrorEvent('api', error);
     if (error.status === 401 && this.apiRetryCount < this.apiRetry) {
      this.apiRetryCount ++;
      this.commonService.refreshToken().then(
        () => {
          this.loadOnChange(true);
        },
        () => {
          this.showError = true;
          $('#loaderPage').css('display', 'none');
        },
        );
    } else if (error.status === 404) {
      this.router.navigate(['/pagenotfound']);
    } else {
      this.showError = true;
      $('#loaderPage').css('display', 'none');
    }
 }

  private checkParental (age_rating: any) {
    if (age_rating === 'U') {
      return 1;
    } else if (age_rating === 'U/A') {
      return 2;
    } else if (age_rating === 'A') {
      return 2;
    } else {
      return 2;
    }
  }

    public startVideo = function(event) {
      if (event !== 'event') {
        this.gtm.GAsubCategory = 'NA';
        this.gtm.clearContentClickDetails();
      }
       let network, value, videoObj;
       network = this.networkService.getPopupStatus();

        if (network) {
            let prevDataTitle;
            prevDataTitle =  (this.data && this.data[0]) ? this.data[0].title_en : undefined;
             value = this.movieData;
              value.original_title = (value.original_title  !== (null && undefined)) ? value.original_title  : 'title';
              videoObj = this.DataCreation(value, false);
              this.data = videoObj;
              // this.playbackVideoObj = videoObj;
              this.businessType = ( value.business_type && value.business_type != null ) ? value.business_type : 'NA';
               if ( this.loginToken == null) {
                    if ( this.businessType.indexOf('premium') !== -1 || this.businessType.indexOf('premium_downloadable') !== -1 ) {
                      this.showGetPremium = true;
                      if(localStorage.getItem("trailLogin")){
                        localStorage.removeItem("trailLogin");
                      }
                      if (this.trailerVideoId &&  this.trailerVideoId !== null  )  {
                        // this.headerservicesService.trailer = true;
                        this.startTrailer();
                      } else {
                        // this.setParentId();
                        this.headerservicesService.signReminderChange(true);
                        this.showLogin = true;
                        this.showAdult = false;
                        this.videoFlag = false;
                      }
                      return;
                    }
                } else {
                  this.purchasedAssetType = this.subscription.checkPlanApiSuccess(true);
                  this.showSubPopUp = this.subscription.getPlanApiSucess();
                  this.asset_subtype = ( value.asset_type != null) ? value.asset_type : null;
                  if ( this.businessType.indexOf('premium') !== -1 || this.businessType.indexOf('premium_downloadable') !== -1 ) {
                    let val1;
                    val1 = ( value.asset_type != null) ? this.asset_subtype.toString() : '';
                    if ( this.purchasedAssetType.indexOf(val1) < 0 ) {
                      this.showGetPremium = true;
                      if (this.showSubPopUp !== undefined) {
                        if (this.trailerVideoId && this.trailerVideoId !== null && ( !localStorage.getItem("trailLogin") || localStorage.getItem("trailLogin") != 'true'))  {
                          // this.headerservicesService.trailer = true;
                          this.startTrailer();
                        } else {
                          // this.setParentId();
                          if(localStorage.getItem("trailLogin")){
                            localStorage.removeItem("trailLogin");
                          }
                          this.headerservicesService.subscribeReminderChange(true);
                          this.videoFlag = false;
                          this.showSubscribe = true;
                        }
                      }
                      return;
                    } else if (this.purchasedAssetType.indexOf(val1) !== -1 && !this.subscription.checkAssetLang('0', value.audio_languages)) {
                      this.showGetPremium = true;
                      if (this.showSubPopUp !== undefined) {
                          // alert('show upgrade popup');
                        // this.setParentId();
                        // this.headerservicesService.callUpgradePopup(true);
                         this.headerservicesService.subscribeReminderChange(true);

                        this.showSubscribe = true;
                        this.videoFlag = false;
                      }
                      return;
                    }
                  }
                }

                let val;
                val = ( value.asset_type !== null) ? this.asset_subtype.toString() : '';
                if ((value.asset_subtype === 'trailer' || value.asset_subtype === 'promo' || value.asset_subtype === 'clip' || value.asset_subtype === 'teaser' || value.asset_subtype === 'music' || value.asset_subtype === 'preview' || value.asset_subtype === 'recap') && (!this.loginToken || (this.purchasedAssetType.indexOf(val) === -1) || (this.purchasedAssetType.indexOf(val) !== -1 && !this.subscription.checkAssetLang('0', value.audio_languages))))  {
                // if (value.asset_subtype === 'trailer' || value.asset_subtype === 'promo' || value.asset_subtype === 'clip' || value.asset_subtype === 'teaser' || value.asset_subtype === 'music' || value.asset_subtype === 'preview' || value.asset_subtype === 'recap') {
                  if (!value.related || value.related.length === 0) {
                    this.showGetPremium = true;
                  } else if (value.related && value.related.length > 0 && value.related[0].asset_type === 0 && value.related[0].business_type.indexOf('premium') !== -1) {
                    this.showGetPremium = true;
                  } else {
                    this.showGetPremium = false;
                  }
                }

                  if ( this.videoService.enableCastView ) {
		    // this.data = this.playbackVideoObj;
                    this.data ? (this.backgroundImage = this.videoService.getImageUrl(this.data[0], false)) : (this.backgroundImage =  false);
                    this.playbackVideoObj = this.data;
                    this.castQueueObject = this.data;
                    if (this.checkParental(this.castQueueObject[0].age_rating) > this.parental_age) {
                      this.headerservicesService.parentalChange({'flag': true, 'type': 'pin' });
                      this.parentalpin = true;
                      this.videoFlag = false;
                    } else {
                       this.showAdult = this.loginToken ? false : (this.castQueueObject[0].age_rating === 'A' ? true : false);
                          if (!this.showAdult) {
                          this.videoService.castQueueObject = this.castQueueObject;
                          this.videoService.toggleQueueState(true);
                          } else {
                            // this.callToast();
                            this.videoFlag = false;
                          }
                    }
                    // return;
                  } else {
                  // if ( !this.isStaticVdeoEnable ) {
                    // this.modalVideoDetails = this.data;
                    if (this.checkParental(this.data[0].age_rating) > this.parental_age) {
                      this.headerservicesService.parentalChange({'flag': true, 'type': 'pin' });
                      this.parentalpin = true;
                      this.videoFlag = false;
                    } else {
                      this.showAdult = this.loginToken ? false : (this.data[0].age_rating === 'A' ? true : false);
                        if (!this.showAdult) {
                          this.playbackVideoObj = this.data;
                          this.videoFlag = true;
                        } else {
                          // this.callToast();
                          this.videoFlag = false;
                        }
                    }
                  // } else {
                  //   if (this.checkParental(this.data[0].age_rating) > this.parental_age) {
                  //     this.headerservicesService.parentalChange({'flag': true, 'type': 'pin' });
                  //     this.parentalpin = true;
                  //     this.videoFlag = false;
                  //   } else {
                  //     this.showAdult = this.loginToken ? false : (this.data[0].age_rating === 'A' ? true : false);
                  //     if (!this.showAdult) {
                  //       this.playbackVideoObj = this.data;
                  //       this.videoFlag = true;
                  //     } else {
                  //       this.callToast();
                  //     }
                  //   }
                  }
          }

    };

    // public closeVideo = function (event) {
    //   // this.modalVideoPopup = false;
    //   this.videoFlag = false;
    //   // document.getElementById('body').classList.remove('modal-open');
    //   };
    private closeShare(event: any): any {
        this.showShare = false;
    }
   private openShare(event: any): void {
         event.stopPropagation();
        this.showShare = true;
    }
    private watchNow = function (event: any) {
           let network, watchListRequest;
          network = this.networkService.getPopupStatus();
        if ( network ) {
          watchListRequest = new  WatchlistApi(this.http, null, this.apiconfigUser);

         if ( this.loginToken != null ) {
            event.stopPropagation();
            event.preventDefault();
            this.imgSrc = this.assetbasepath + 'assets/common/loaderWhite.svg';
            if ( this.watched === true ) {
              let requestWatch, country_code;
              requestWatch = watchListRequest.v1WatchlistDelete(this.movieData.id, this.movieData.asset_type).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
                    this.watched = false;
                    this.imgSrc = this.assetbasepath + 'assets/common/watchLater_normal.png';
                    this.userProfileService.removeWatchData(this.movieData);
                      country_code = this.settingsService.getCountry();
                    if ( this.asset_subtype === 'movie' ) {
                      this.qgraphevent('moviessection_played', {'movie_name': this.movieTitle, 'language': this.laguages, 'genre': this.movieGenre, 'time_spent': '', 'country' : country_code, 'state': localStorage.getItem('state_code')});
                    } else {
                      this.qgraphevent('videosection_added_to_watch_later', {'video_name': this.movieTitle , 'language': this.laguages, 'genre': this.movieGenre , 'time_spent': '' , 'country' : country_code, 'state': localStorage.getItem('state_code') });
                    }
                 },
                  err => {
                    this.imgSrc = this.assetbasepath + 'assets/common/watchLater_icon_selected.png';
                  });
            } else {
              let  requestWatch1;
              let obj;
              obj = this.userProfileService.createObject(this.movieData);
              requestWatch1 = watchListRequest.v1WatchlistPost(obj).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
                    this.watched = true;
                    this.imgSrc = this.assetbasepath + 'assets/common/watchLater_icon_selected.png';
                    this.userProfileService.setWatchData(this.movieData);

                  },
                  err => {
                    this.imgSrc = this.assetbasepath + 'assets/common/watchLater_normal.png';

                  });
            }
          }  else {
                this.watchorfavElse();
          }
        }

  };

 private watchorfavElse(): void {

             if ( this.videoFlag === true ) {
                this.pauseTopopUp();
              } else {
               // if (this.trailerVideoId &&  this.trailerVideoId !== null  )  {
               //   this.headerservicesService.trailer = true;
               // }
              this.headerservicesService.signReminderChange(true);
              this.showLogin = false;
            }
 }
 @HostListener('window:resize', ['$event'])
  public fontReScale(event) {
   this.fontResize();
    this.Resize();
   let h, top;
           h =  $('.banner_block').height();
           top = (window.innerWidth <= 768) ? (window.innerWidth <= 480)  ? (h + 50) : (h + 100) : (h + 5);
           $('#breadcrumInit').css('top', top + 'px');
  }

   private fontResize(): void {
      $(document).ready(function() {
         let titleFontSize;
        titleFontSize = parseInt( $('#btncaption_block').height(), 10) + 'px';
        $('.btncaption').css('font-size', titleFontSize);

      });
  }

  // private calculateStars(rating: any) {
  //   for (let i = 0; i < this.starContainer.length; i++ ) {
  //     this.starContainer[i] = (i < rating ) ? this.assetbasepath + 'assets/common/star_filled_icon.png' : this.assetbasepath + 'assets/common/star_empty_icon.png';
  //   }
  // }

   private fetchlanguages(switch_str: number): any {
      if ( this.languageData == null ) {
          this.languageData = this.settingsService.getCompleteConfig();
      }
        let value_string, regionalLang, gAlanguage;
       value_string = [];
       this.regionalLang = [];
       switch (switch_str) {
                  case 1:
                   let j;
                   for ( j = 0; j < this.languages_array.length; j++ ) {
                     regionalLang = this.fetchLabel[this.languages_array[j]];
                     gAlanguage = this.configData.languages_labels['en'][this.languages_array[j]];
                     regionalLang = (regionalLang !== undefined) ? regionalLang : this.languages_array[j];
                     gAlanguage = (gAlanguage !== undefined) ? gAlanguage : this.languages_array[j];
                     this.regionalLang.push(regionalLang);
                     this.gAlanguage.push(gAlanguage);
                   }
                  if ( this.regionalLang.length > 1 ) {
                    this.laguages = this.regionalLang.join(', ');
                  } else {
                    if ( this.regionalLang[0] !== '' ) {
                        this.laguages = this.regionalLang[0];
                      } else {
                        this.laguages = '';
                      }
                  }
                  break;

                 case 2:
                 let subtitlesLanguages, k;
                 subtitlesLanguages = [];
                  for ( k = 0; k < this.subtitle_array.length; k++ ) {
                    let i;
                      for ( i of  this.languageData.languages) {
                           if ( i.id === this.subtitle_array[k]) {
                             subtitlesLanguages[k] = i.name;
                           }
                      }
                    }
                  if ( subtitlesLanguages.length > 1 ) {
                  this.subtitlesLang = subtitlesLanguages.join(', ');
                  } else {
                     if ( subtitlesLanguages[0] !== '') {
                      this.subtitlesLang = subtitlesLanguages[0];
                    }
                  }

                  break;
                default:
                  break;
              }

   }

  private updateTime(s: number): any {
    let secs, mins, hrs, secs_new, mins_new, time;
      if (s) {
        secs = s % 60;
        s = (s - secs) / 60;
        mins = s % 60;
        s = (s - mins) / 60;
        hrs = s % 60;
        if (mins < 10) {
          mins_new = '0' + mins;
        } else {
          mins_new = '' + mins;
        }
        if (secs < 10) {
          secs_new = '0' + secs;
        } else {
         secs_new = '' + secs;
        }
        if (this.displaylanguage === 'ru') {
           time = (hrs ? hrs + 'ч' : '') + (mins ? (' ' + mins_new) + 'м' : '') + (secs ? (' ' + secs_new) + 'с' : '');
        } else {
            time = (hrs ? hrs + 'h' : '') + (mins ? (' ' + mins_new) + 'm' : '') + (secs ? (' ' + secs_new) + 's' : '');
        }
        return time;
      } else {
         time = '';
         return time;
      }
  }

  public onChangeSize(): void {
     this.imageScr =  (window.innerWidth < 480) ? this.image_url_mobile : this.image_url;
     this.onErrorSrc = (window.innerWidth < 480) ? this.onErrorBanner_mob : this.onErrorBanner;
     // if (navigator.userAgent.match(/mobile/i) && !navigator.userAgent.match(/iPad/i)) {
     //    this.isStaticVdeoEnable = true;
     //    // this.imageScr =  (window.innerWidth < 480) ? this.image_url_mobile : this.image_url;
     //    // this.onErrorSrc = (window.innerWidth < 480) ? this.onErrorBanner_mob : this.onErrorBanner;
     //  } else {
     //    this.isStaticVdeoEnable = false;
     //   // this.imageScr = this.image_url;
     //   // this.onErrorSrc = this.onErrorBanner;
     // }
  }


  private pauseTopopUp() {
     this.videoComponenet.pauseVideo();
    this.showSignUpPromt = true;
  }

  private closeReminder = function(event) {
     this.showSignUpPromt = false;
  };

  public ngOnDestroy () {
    this.subscription.setParentId(null, null);
    this.gtm.GAsubCategory = 'NA';
    this.headerservicesService.premium = false;
  this.ngUnsubscribe.next();
  this.ngUnsubscribe.complete();
    this.linkservice.removeCanonicalLink();
    this.linkservice.removeampLink();
      this.metaService.updateTag({ property: 'og:image', content: 'https://www.zee5.com/assets/common/Splash.jpg', itemprop: 'image' });
   this.metaService.updateTag({ property: 'og:image:url', content: 'https://www.zee5.com/assets/common/Splash.jpg', itemprop: 'image' });
   this.metaService.updateTag({ property: 'og:image:type', content: 'image/png' });
   this.metaService.updateTag({ name: 'twitter:image', content: 'https://www.zee5.com/assets/common/Splash.jpg'});
  //   this.googletagAvailable = this.commonService.checkGoogleTag();
  // if (this.googletagAvailable === 'true' && googletag.destroySlots) {
  //   googletag.destroySlots();
  // }
  this.destroyAds();
  if (this.sub) {
      this.sub.unsubscribe();
  }
    $('#breadcrumInit').css('top', '90px');
    $('#breadcrumInit').css('position', 'absolute');

}

 public imageError(event: any): void {
    if (event.srcElement) {
      event.srcElement.src = this.onErrorSrc;
      // event.srcElement.src = (window.innerWidth < 480) ? this.assetbasepath + 'assets/default/banner_mobile.png' :  this.assetbasepath + 'assets/default/banner.png';
    } else {
      event.currentTarget.src = this.onErrorSrc;
      // event.currentTarget.src = (window.innerWidth < 480) ? this.assetbasepath + 'assets/default/banner_mobile.png' :  this.assetbasepath + 'assets/default/banner.png';
    }
  }
  public setParentId(): any {
    if (this.data && this.data[0]) {
      this.subscription.setParentId(this.data[0].id, this.movieData.id);
    } else {
      this.subscription.setParentId(this.movieData.id, this.movieData.id);
    }
    // this.subscription.setParentId(this.data[0].id, this.movieData.id);
    // if (this.movieData.id === this.data[0].id) {
    //   this.subscription.setParentId(this.movieData.id);
    // }
  }
  public updateRoute(): any {
    // localStorage.setItem('postSubscriptionRoute', this.movieData.id);
    if(this.localstorage.getItem('country_code') !== 'IN'){
      this.localstorage.setItem("trailLogin", true)
    }
  }
  private DataCreation(value, trailer): any {
    let movie_title, obj, category, videodata;
    videodata = [];
          if ( value.asset_subtype != null ) {
               category = value.asset_subtype;
               category =  ( category === 'movie' ) ? 'movie' : 'video';
              } else {
               category = 'category';
              }
             this.seoService.blueKaifunction(
               value.original_title,
               category,
               value.asset_type,
               value.asset_subtype,
               value.genres.map(function(elem) {return elem.id; }).join(', '),
               value.video.audiotracks);
     movie_title = this.commonService.convertToLowercase(value.original_title);
      obj = {
                      id: value.id,
                      age_rating: value.age_rating,
                      duration: value.duration,
                      subtitles: value.video.subtitles,
                      audio_languages: value.video.audiotracks,
                      stream_url: value.video.url,
                      drm: value.video.is_drm,
                      drm_keyid: value.video.drm_key_id,
                      type: 'vod',
                      title: value.title ,
                      title_en: value.original_title,
                      season_no: '',
                      episode_no: '' ,
                      episode_name: '',
                      channel_name: '',
                      channel_id: '',
                      category: category ,
                      content_type: value.asset_subtype,
                      genre: value.genres.map(function(elem) {return elem.id; }).join(', '),
                      sub_genre: '' ,
                      catch_up: 'N' ,
                      series_id: '' ,
                      rating: value.rating,
                      release_date: trailer ? '' : this.commonService.dateChange(value.release_date),
                      business_type: value.business_type,
                      parent_business_type: trailer ? this.movieData.business_type : ((value.related && value.related.length > 0) ? value.related[0].business_type : 'premium'),
                      parent_id: this.movieData.id,
                      description: value.description,
                      image: value.list_image,
                      // newly added paramter
                      stream_url_dash: value.video.url,
                      stream_url_hls: value.video.hls_url,
                      asset_type: value.asset_type,
                      share_url : this.urlcategory + movie_title + '/' + value.id ,
                      sub_category: '',
		                  skip_available: value.skip_available,
                      vtt_thumbnail: value.video_details.vtt_thumbnail_url,
                      endCreditsStart: value. end_credits_marker,
                      start_time: value.start_time,
                      actors: value.actors
                     };
                   // if (!trailer) {
                   //    obj.favorite = this.favorite,
                   //    obj.watchLater = this.watched;
                   //   }
                     videodata.push(obj);
                     return videodata;
  }

  private routeTrailer(): any {
      // this.router.navigate(['/pagenotfound']);
      this.commonService.updateCollectionId(null);
      this.commonService.setTalamoosData('', '', '');
      this.gtm.clearContentClickDetails();

		// if (this.countryCode === 'IN') {
      this.router.navigate(['/videos/details/' + this.commonService.convertToLowercase(this.trailerdata.original_title) + '/' + this.trailerdata.id]);
		// } else {
		// 	let link;
		// 	link = environment.shareUrl + 'videos/details/' + this.commonService.convertToLowercase(this.trailerdata.original_title) + '/' + this.trailerdata.id;
		// 	window.open(link, '_blank');
		// }
  }
  private startTrailer(): any {
    this.commonService.setTalamoosData('', '', '');
    this.gtm.clearContentClickDetails();

   let  dataObject, country_code, movie_title, userType;
      dataObject = new MovieApi(this.http, null, this.apiconfig);
     country_code = this.settingsService.getCountry();
     userType = this.commonService.getUserType();
      if (this.trailerVideoId &&  this.trailerVideoId !== null  )  {
        dataObject.v1MovieByIdGet(this.trailerVideoId, null, country_code, null, null, null, userType).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
               value.video = value.video_details ? value.video_details : [];
               this.apiRetryCount = 1;
          // this.seoService.movietrailerupdate(value.original_title, value.video.audiotracks[0]);
              movie_title = this.commonService.convertToLowercase(value.original_title);
              let videoObj;
               videoObj = this.DataCreation(value, true);
              this.data = videoObj;
                      if (this.videoService.enableCastView) {
                        this.data ? (this.backgroundImage = this.videoService.getImageUrl(this.data[0], false)) : (this.backgroundImage =  false);
                        this.castQueueObject = this.data;
                        if (this.checkParental(this.castQueueObject[0].age_rating) > this.parental_age) {
                          this.parentalpin = true;
                          this.videoFlag = false;
                          this.headerservicesService.parentalChange({'flag': true, 'type': 'pin' });
                          this.parentalpin = true;
                          this.videoFlag = false;
                        } else {
                           this.showAdult = this.loginToken ? false : (this.castQueueObject[0].age_rating === 'A' ? true : false);
                          if (!this.showAdult) {
                          this.videoService.castQueueObject = this.castQueueObject;
                          this.videoService.toggleQueueState(true);
                          } else {
                            // this.callToast();
                            this.videoFlag = false;
                          }
                        }
                        return;
                    }
                    // if ( !this.isStaticVdeoEnable ) {
                      // this.modalVideoDetails = this.data;
                      if (this.checkParental(this.data[0].age_rating) > this.parental_age) {
                        this.headerservicesService.parentalChange({'flag': true, 'type': 'pin' });
                        this.parentalpin = true;
                          this.videoFlag = false;
                      } else {
                        this.showAdult = this.loginToken ? false : (this.data[0].age_rating === 'A' ? true : false);
                        if (!this.showAdult) {
                          // this.modalVideoPopup = true;
                          // this.data = this.playbackVideoObj;
                          this.playbackVideoObj = this.data;
                          this.videoFlag = true;
                          // document.getElementById('body').classList.add('modal-open');
                        } else {
                          // this.callToast();
                          this.videoFlag = false;
                        }
                      }
                    // } else {
                    //   this.showAdult = this.loginToken ? false : (this.data[0].age_rating === 'A' ? true : false);
                    //   if (!this.showAdult) {
                    //       this.playbackVideoObj = this.data;
                    //       this.videoFlag = true;
                    //   } else {
                    //     this.callToast();
                    //   }
                    // }
            }, error => {
                if (error.status === 401 && this.apiRetryCount < this.apiRetry) {
                    this.apiRetryCount ++;
                    this.commonService.refreshToken().then(
                      () => {
                        this.startTrailer();
                      });
                  }
            });
        }
      }
  // private callToast() {
  //   // let p;
  //   // p = document.getElementById('snackbar_adult');
  //   // p.className = 'show';
  //   // setTimeout(function() { p.className = p.className.replace('show', ''); }, 3000);
  // }
  private closeEmbed(event): any {
    this.embedLink = false;
  }
  private openEmbed(event): any {
    this.embedLink = true;
  }

  private goToParental() {
      this.headerservicesService.parentalChange({'flag': true, 'type': 'pin' });
      this.parentalpin = true;
      this.videoFlag = false;
}

  private qgraphevent(eventname, object) {
    if (this.window.qg) {
      // if (this.qgraph) {
      //   delete object.country;
      //   delete object.state;
      //   qg('event', eventname, object);
      // } else {
        qg('event', eventname, object);
      // }
    }
  }

    private showPlayIcon(value): void {
    if (value) {
      if (this.videoFlag) {
        this.videoComponenet.pauseVideo();
      }
      // this.videoFlag = false;
      // $('#playImage').show();
      // $('#noAccess').css('display', 'none');
      // $('#noAccessSubs').css('display', 'none');
    } else {
      if (this.videoFlag) {
        this.videoComponenet.playVideo();
      }
    }
  }


  private adoric_event(moviedata) {
    let adoric_array;
    adoric_array = [];
    if (moviedata.related) {
      for (let i = 0; i < moviedata.related.length; i++) {
        let json_object_adoric;
        json_object_adoric = {};
        if (moviedata.related[i].title) {
          json_object_adoric['title'] = moviedata.related[i].title;
        }
        if (moviedata.related[i].slug) {
          json_object_adoric['slug'] = moviedata.related[i].slug;
        }
        if (moviedata.related[i].description) {
          json_object_adoric['slug'] = moviedata.related[i].description;
        }
        if (moviedata.related[i].id) {
          json_object_adoric['contentId'] = moviedata.related[i].id;
        }
        if (moviedata.related[i].image.list) {
          json_object_adoric['img1'] = this.basepath1 + moviedata.related[i].id + '/list/' + '1920x770/' + moviedata.related[i].image.list + '.jpg' + '?imwidth=1920&impolicy=akamai_vidz1_zee5_com-IPM';
          json_object_adoric['img2'] = this.basepath1 + moviedata.related[i].id + '/list/' + '270x152/' + moviedata.related[i].image.list + '.jpg' + '?imwidth=270&impolicy=akamai_vidz1_zee5_com-IPM';
          // json_object_adoric['img3'] = moviedata.related[i].image_url;
        }
        if (moviedata.related[i].image.cover) {
          json_object_adoric['img3'] = this.basepath1 + moviedata.related[i].id + '/cover/' + '270x405/' + moviedata.related[i].image.cover + '.jpg' + '?imwidth=270&impolicy=akamai_vidz1_zee5_com-IPM';
        }
        adoric_array.push(json_object_adoric);

      }
      // if(environment.adoric) {
        this.window.adoricRecomendationContent = adoric_array;
      // }
    } else if (moviedata.buckets && moviedata.buckets.length > 0 && moviedata.buckets[0].modelName) {
      for (let i = 0; i < moviedata.buckets[0].items.length; i++) {
        let json_object_adoric;
        json_object_adoric = {};
        if (moviedata.buckets[0].items[i].title) {
          json_object_adoric['title'] = moviedata.buckets[0].items[i].title;
        }
        if (moviedata.buckets[0].items[i].slug) {
          json_object_adoric['slug'] = moviedata.buckets[0].items[i].slug;
        }
        if (moviedata.buckets[0].items[i].description) {
          json_object_adoric['description'] = moviedata.buckets[0].items[i].description;
        }
        if (moviedata.buckets[0].items[i].id) {
          json_object_adoric['contentId'] = moviedata.buckets[0].items[i].id;
        }
        if (moviedata.buckets[0].items[i].image.list) {
          json_object_adoric['img1'] = this.basepath1 + moviedata.buckets[0].items[i].id + '/list/' + '1920x770/' + moviedata.buckets[0].items[i].image.list + '.jpg' + '?imwidth=1920&impolicy=akamai_vidz1_zee5_com-IPM';
          json_object_adoric['img2'] = this.basepath1 + moviedata.buckets[0].items[i].id + '/list/' + '270x152/' + moviedata.buckets[0].items[i].image.list + '.jpg' + '?imwidth=270&impolicy=akamai_vidz1_zee5_com-IPM';
          // json_object_adoric['img3'] = moviedata.buckets[0].items[i].image_url;
        }
        if (moviedata.buckets[0].items[i].image.cover) {
          json_object_adoric['img3'] = this.basepath1 + moviedata.buckets[0].items[i].id + '/cover/' + '270x405/' + moviedata.buckets[0].items[i].image.cover + '.jpg' + '?imwidth=270&impolicy=akamai_vidz1_zee5_com-IPM';
        }
        adoric_array.push(json_object_adoric);

      }
      // if(environment.adoric) {
        this.window.adoricRecomendationContent = adoric_array;
      // }
    }

  }
   /* Function to translate day and month */
  public getDateTranslate(date) {
      let month, dateString;
      dateString = (new Date(date)).toString().toUpperCase();
      month = dateString.split(' ')[1]; // fetch month
      return this.translate.instant('TVGUIDE.' + month);
  }

  // public finalLangArrayFormed(langArray) {  // Malaya audio tag replacement
  //     let concatedArray = [];
  //     (this.movie_tags.length > 0) ? (concatedArray = langArray.concat(this.movie_tags)) : false;
  //     let descriptiveLangArray = [];
  //     for (let i of concatedArray) {
  //       if ((descriptiveLangArray.indexOf(this.fetchLabel[i]) === -1)) {
  //         this.fetchLabel[i] ? descriptiveLangArray.push(this.fetchLabel[i]) : false;
  //       }
  //     }
  //     this.laguages = this.convertArrayToString(descriptiveLangArray, ', ');
  // }
  private convertArrayToString(any_array: string[], prop) { // Malaya audio tag replacement: convert to strings
    let result = '';
    result = any_array.join(prop);
    return result;
  }
  // public audiotagsFromTags(tags) {  // Malaya audio tag replacement: push if languages are avaliable
  //   for (let i of tags) {
  //     if (i.includes('audio')) {
  //       this.movie_tags.push(i.split('_')[1]);
  //     }
  //   }
  // }
  public mygpSubscriptionroute(): any {
    this.headerservicesService.MygpSubscriptionroute();
  }
}

