import { Component, OnInit, Input, Output, EventEmitter, OnDestroy, HostListener, AfterViewInit, ViewChild , ElementRef} from '@angular/core';
import {environment} from '../../environments/environment';
import { SettingsService } from '../services/settings.service';
import * as $ from 'jquery';
import { VideoService } from '../services/video.service';
import {  NetworkService  } from '../services/network.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { HeaderservicesService } from '../services/headerservices.service';
import { LinkService } from '../services/link.service';
import { SeoService } from '../services/seo.service';
import { RouteService } from '../services/route.service';
import { Location } from '@angular/common';
import { Router , NavigationEnd , ActivatedRoute  } from '@angular/router';
import { PlatformLocation } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Http } from '@angular/http';
import * as userApi from '../../data/user/api/api';
import { ModalService } from '../services/modal.service';
import '../_directives/modal.less';
import { UseractionapiService } from '../services/useractionapi.service';
import {CommonService} from '../services/common.service';
import { UserApi } from '../../data/user/api/api';
import * as SettingsApi from '../../data/user/api/api';
declare const qg;
declare const FB: any;

@Component({
  selector: 'app-international',
  templateUrl: './international.component.html',
  styleUrls: ['./international.component.less']
})
export class InternationalComponent implements OnInit, OnDestroy, AfterViewInit {
private GOOGLE_CLIENT_ID = environment.GOOGLE_CLIENT_ID;
private source_dropdown: any;
private currentIndex: any = 0;
private previousIndex: any = 0;
private country_selected_index: any = 0;
public selected_country: any;
private country: any;
private countries: any;
private countryListNew: any;
private country_codeLength: number;
private country_code: any;
public phone_code: any;
private regex: any;
public loginthrough: any;
public assetbasepath: any;
private localstorage: any;
private window: any;
private document: any;
private navigator: any;
private configData: any;
private countrycode: any;
private countryList: any;
private countryListtotal: any;
private pageName: any;

private mobile_return = false;
private mobile_return_keypress = false;
private fireFoxdropReg = false;
private dropDownCheck = false;
private loginComponentFlag = false;
private registerMobileFlag = false;
private loginMobileFlag = false;
private registerEmailFlag = false;
private loginEmailFlag = false;
public callLoginComponentFlag = false;
public callRegisterComponentFlag = false;
public signinPage = true;
private register_mobile: any = false;
// private socialSectionFlag = false;
public profileFlag = false;
private code: any;
private forgotcode: any;
private previousUrl: any;
private qgraph: any;
private userapi: any;
public phone_min_len: number;
public phone_max_len: number;
private passwordCheck = false;
private place = false;
private source1 = this.assetbasepath + 'assets/sign_in/ic_eye_normal.png';
private source2 = this.assetbasepath + 'assets/sign_in/ic_eye.png';
private type: any;
public  mobileEmailValue: any;
private password_return_keypress = false;
private password_return = false;
private email_return_keypress = false;
private receivedValue: any;
private apiCall = false;
public  isnum: any;
public countryCodeInput: any;
private silentLoginToken: any;
private config: any;
private userId: any;
private tokenValue: any;
private clientID: any;
private marketingValue: any;
private timestampTime: any;
private timestampDateTime: any;
public error_message: any;
public internationalLoginComponent = false;
public internationallogin = false;
public closeTag: any;
private profileShow: any;
private token: string;
  public auth2: any;                                       // G+ sigin api call variable
  private token1: any;
  private saveToken: any;
  private fBToken: any;
  public errorMessage: any;
  private saveTokenFacebook: any;
  private profileActive: any;
  public registerPageFlag: any;
  private socialFlag = false;
  private googleAccessToken: any;
  private googleObj: any;
  private socialType: any;
  private gdprCountryChange = false;
  private loginPageFlag = false;
  private loginFrom: any;
  private sendToken: any;
  private gdprValue: any;
  public gdprFlag: any;
  private userSettings: any;
  private login_type: any;
  private promotional: any;
  private countryToken: any;
  private cookiesLocal: any;
  private marketingLocal: any;
  private responsevalue: any;
  public guest_token: any;
  private loginMethod: any;
  private registerTop: any;
  private acces: any;
  private version_number: any;
  private errors: any;
  private userData: any;
  private settingsResponse: any;
  private loged = false;
  public mobile: any = false;
  public internationalGdprFlag: any;
  private loginStateflag: any;
  public showFacebookIcon: any;
  public showTwitterIcon: any;
  public showGoogleIcon: any;
  private default_settings: any;
  public timeoutError = false;
  public queryparams: any;

  public msisdnData: any;
  public msisdnUser: any = false;

  private nowTV: any = false;
  // private nowTvDetails: any;
  private nowTVemail: any = '';
  public nowTvDomain: any;
  @ViewChild('triggerClick') public loaderPage: ElementRef;
  @Input() private signInComponent: boolean;
  @Input() private signinHide: any;
  @Input() private signinDetailsFlag: any;
  @Input() private profileActivationFlag: any;
  @Output() private change: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() public update = new EventEmitter<boolean>();     // to send data back to component
constructor(@Inject(PLATFORM_ID) private platformId: Object, private http: Http, location: PlatformLocation, private router: Router, private route: ActivatedRoute, private seoservice: SeoService, private routeservice: RouteService, private commonService: CommonService, private headerservicesService: HeaderservicesService, private linkservice: LinkService, private gtm: GoogleAnalyticsService, private to: Location, private networkService: NetworkService, private settingsService: SettingsService, private videoService: VideoService, private modalServices: ModalService, private userAction: UseractionapiService) {
    location.onPopState(() => {
      this.headerservicesService.signinChange(false);
      this.document.getElementById('body').classList.remove('modal-open');
      $('#body').removeClass('scrolldisbale');
  });
  if (isPlatformBrowser(this.platformId)) {
        this.localstorage = localStorage;
        this.window = window;
        this.document = document;
        this.navigator = navigator;
  }
    // this.headerservicesService.signinValue.subscribe(value => {
    //   this.signInComponentFlag = value;
    // });
    // this.headerservicesService.signinRightTopValue.subscribe(value => {
    //   this.signinRightTopFlag = value;
    // });
    // this.headerservicesService.signinValueLeft.subscribe(value => {
    //   this.signInLeftFlag = value;
    // });
    // this.headerservicesService.bgImageValue.subscribe(value => {
    //   this.bg_imageFlag = value;
    // });
    this.headerservicesService.registerMobileValue.subscribe(value => {
      this.registerMobileFlag = value;
    });
    // this.headerservicesService.signInDetailValue.subscribe(value => {
    //   this.signinDetailsFlag = value;
    // });
    // this.headerservicesService.loginHeadingValue.subscribe(value => {
    //   this.loginHeadingFlag = value;
    // });
    // this.headerservicesService.registerHeadingValue.subscribe(value => {
    //   this.registerHeadingFlag = value;
    // });
    this.headerservicesService.loginMobileValue.subscribe(value => {
      this.loginMobileFlag = value;
    });
    this.headerservicesService.loginEmailValue.subscribe(value => {
      this.loginEmailFlag = value;
    });
    this.profileFlag = this.headerservicesService.getProfileActivationChange();  // added newly for email verfication lonk
    this.headerservicesService.pofileActivationValue.subscribe(value => {  // profileactivation screen inside app value changes
    this.profileFlag = this.headerservicesService.getProfileActivationChange();
    });
    this.headerservicesService.blockeventsValue.subscribe(value => {
      this.qgraph = this.headerservicesService.getRemarketing();
    });
  }

  public ngAfterViewInit() {
    this.googleInit();
  }

  public ngOnInit() {
    this.nowTvDomain = this.commonService.getNowTvDomain();
    this.checkNowTV();
    this.queryparams = this.router.url.split('?')[1];
  	this.code = this.routeservice.getcode();
  	this.forgotcode = this.routeservice.getforgotcode();
  	this.assetbasepath = environment.assetsBasePath;
    this.source_dropdown = this.assetbasepath + 'assets/sign_in/arrowDropdown.png';
  	this.configData = this.settingsService.getCompleteConfig();
    this.countryListtotal = this.settingsService.getcountryApiList();
    this.countryList = this.settingsService.getCountryValueNew();

    this.previousUrl = this.routeservice.getLoginRoute();

    this.source1 = this.assetbasepath + 'assets/sign_in/ic_eye_normal.png';
    this.source2 = this.assetbasepath + 'assets/sign_in/ic_eye.png';
    this.closeTag = this.assetbasepath + 'assets/common/close_ic1.png';
    if (this.previousUrl === '/signin' || this.previousUrl === '/signin/email' || this.previousUrl === '/signin/mobile' || this.previousUrl === '/register' || this.previousUrl === '/register/email' || this.previousUrl === '/register/mobile' || this.previousUrl === '/forgotpassword/email' || this.previousUrl === '/forgotpassword/mobile') {
      this.routeservice.setLoginRoute('/'); // dont route if popup
      this.previousUrl = '/';
    }
    this.token = this.localstorage.getItem('token');
    if (this.token && (this.code || this.forgotcode)) {
      this.loginStateflag = true;
      this.routeservice.setloggedInstate(this.loginStateflag);
    } else if (this.token) {
      $('.SignIncomponent').css('display', 'none');
      $('#loaderPage').css('display', 'block');
      if (this.navigator.userAgent.match(/mozilla/i)) {
        setTimeout(() => {
          $('#body').removeClass('scrolldisbale');
          this.window.history.replaceState({}, '', '/');
          this.document.getElementById('body').classList.remove('modal-open');
          this.localstorage.removeItem('twitterToken');
        }, 10);
      } else {
        this.window.history.go(-2);
        this.document.getElementById('body').classList.remove('modal-open');
        this.localstorage.removeItem('twitterToken');
      }
    }
      $('#loaderPage').css('display', 'block');
    this.showCountry(); // for dropdown country list and check whether to show mobile Registration
    this.screenCheckFunction();
    let countryCodeValue;
    countryCodeValue = this.settingsService.getCountryValueNew();
    this.countryCodeInput = countryCodeValue[0] && countryCodeValue[0]['phone-code'] ? countryCodeValue[0]['phone-code'] : '';
       let scope;
	   scope = this;
	    $(this.document).mouseup(function(e) {
	      if (e.target.id !== 'infoInternationalRegister' && !$('#infoInternationalRegister').find(e.target).length) {
	        if (scope.dropDownCheck === true) {
	          scope.dropDownCheck = false;
	        }
	      }
	    });
	   $(this.document).on('touchstart' , function(e) {
	      if (e.target.id !== 'infoInternationalRegister' && !$('#infoInternationalRegister').find(e.target).length) {
	        if (scope.dropDownCheck === true) {
	          scope.dropDownCheck = false;
	        }
	      }
	    });

    this.gtm.storeWindowError();
    this.qgraph = this.headerservicesService.getRemarketing();
    this.previousUrl = this.routeservice.getLoginRoute();
    this.cookiesLocal = this.localstorage.getItem('cookies');
    this.marketingLocal = this.localstorage.getItem('marketing');
    this.guest_token = this.localstorage.getItem('guestToken');
    this.version_number = this.navigator.userAgent;  // gdpr additional field version number while post
    if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
      this.document.getElementById('body').classList.add('modal-open');
    }

    if (this.window.innerWidth <= 576) {
      this.mobile = true;
    } else {
      this.mobile = false;
    }
    this.userapi = new userApi.UserApi(this.http, null, null);
    this.countrycode = this.settingsService.getCountry();
    this.gtm.FacebookInitialization();
    this.onResize();
  }

  private checkNowTV(): any {
    if (this.commonService.nowtv && this.commonService.nowtv.isTrue) {
      this.nowTV = true;
      this.localstorage.setItem('nowTV', this.nowTV);
      let scope;
      scope = this;
      $(this.document).ready(function() {
        if (((scope.commonService.nowtv || {}).params || {}).email) {
          scope.setNowTvEmail(scope.commonService.nowtv.params.email);
        }
      });
    } else {
      this.nowTV = false;
      this.localstorage.removeItem('nowTV');
    }
  }

  private setNowTvEmail(email: any = ''): any {
    if (this.nowTVemail !== email) {
      this.nowTVemail = email;
      $('#mobileEmailValues').val(this.nowTVemail);
      this.mobileEmailValidation();
      this.mobileEmailValidationkeypress();
    }
  }

  private checkMsisdn(): any {
    let scope;
    scope = this;
    $(this.document).ready(function() {
      scope.msisdnData = scope.settingsService.getMsisdnData();
      if (scope.msisdnData && scope.msisdnData.user === 'new_user' && scope.msisdnData.msisdn) {
        if (scope.msisdnData.msisdn.indexOf(scope.countryList[0]['phone-code']) === 0) {
          scope.msisdnData.mobile = scope.msisdnData.msisdn.replace(scope.countryList[0]['phone-code'], '');
        }
        if (scope.msisdnData.mobile) {
          scope.msisdnUser = true;
          $('#mobileEmailValues').val(scope.msisdnData.mobile);
          scope.showPasswordField('hide');
          scope.mobileEmailValidation();
          scope.mobileEmailValidationkeypress();
        }
      }
    });
  }
  private showPasswordField(state): any {
    $('#register-password')[state]();
  }
  private checkRobiConditions(): any {
    return (this.msisdnUser && this.selected_country && (this.selected_country['phone-code'] + $('#mobileEmailValues').val()) === this.msisdnData.msisdn);
  }
  private checkRobiPasswordConditions(): any {
    if (this.checkRobiConditions()) {
      this.showPasswordField('hide');
    } else {
      this.showPasswordField('show');
    }
  }
  public onResize(): void {
    if (this.window.innerWidth <= 576) {
      this.mobile = true;
    } else {
      this.mobile = false;
    }
    this.showFacebookIcon = this.mobile ? this.assetbasepath + 'assets/social/Mobile_International_Facebook.png' : this.assetbasepath + 'assets/social/Desktop_International_Facebook.png';
    this.showTwitterIcon = this.mobile ? this.assetbasepath + 'assets/social/Mobile_International_Twitter.png' : this.assetbasepath + 'assets/social/Desktop_International_twitter.png';
    this.showGoogleIcon = this.mobile ? this.assetbasepath + 'assets/social/Mobile_International_Google.png' : this.assetbasepath + 'assets/social/Desktop_International_Google.png';
  }

@HostListener('window:resize', ['$event'])
   public onresize(event) {
     this.onResize();
  }
  private showCountry(): any {
    this.countryListNew = this.settingsService.getCountryValueNew();
	    if (this.countryListNew && this.countryListNew.length >= 1) {
        $('.auto-loader-country').css('display', 'none');
	     	this.country_code = '+' + this.countryListNew[0]['phone-code'] + ' - ';
         this.phone_code = this.countryListNew[0]['phone-code'];
         this.phone_min_len = this.countryListNew[0]['valid_mobile_digits'];
         this.phone_max_len = this.countryListNew[0]['valid_mobile_digits_max'];
	    	if (this.countryListNew[0] && this.countryListNew[0].mobile_registration) {
	            this.register_mobile = this.countryListNew[0].mobile_registration;
	            if (this.register_mobile === 'false') {
	                this.register_mobile = false;
	            } else if (this.register_mobile === 'true') {
                        this.register_mobile = !this.nowTV;
	                      // this.register_mobile = true;
	            }
	      } else if (this.configData) {
	            if (this.configData.mobile_registration) {
	                this.register_mobile = this.configData.mobile_registration;
	            } else if (this.configData.mobile_registration === false) {
	                  this.register_mobile = this.configData.mobile_registration;
	            } else {
                        this.register_mobile = !this.nowTV;
	                   // this.register_mobile = true;
	            }
	      }
		  }
    // country in drop down
    this.country = this.settingsService.getCountryValue();
    setTimeout(() => {
        if ( this.countryListtotal === undefined || this.countryListtotal.length === 0) {
          	this.settingsService.getCountryList().timeout(environment.timeOut).subscribe(value => {  // countrylilst api
              this.countries = value;
	            if (this.countries.length === 0) {
	              this.countries = this.settingsService.getcountryApiList();
	            } else {
		            this.settingsService.setCountryListValue(value);
		            let selected_country_apiFirst;
		            selected_country_apiFirst = this.settingsService.getCountry();
		            let country;
		            for (country in this.countries) {
		              if (this.countries[country].code === selected_country_apiFirst) {
		                this.currentIndex = country;
		                this.country_selected_index = country;
                    this.selected_country = this.countries[country];
		                if (this.countries[country].code === 'IN') {  // +91
		                    this.country_codeLength = 10;
		                } else {
		                  this.country_codeLength = 13;
		                }
		                break;
		              }
		            }
              }
              $('.auto-loader-country').css('display', 'none');
              this.checkRobiPasswordConditions();
          	}, error => {
	            if (this.configData) {
	               this.currentIndex = 0;
	               this.selected_country = {'name': this.country.country, 'code': this.country.country_code, 'phone-code': '-'};
	               this.countries = [{'name': this.country.country, 'code': this.country.country_code, 'phone-code': '-'}];
	               this.country_code = null;
	              if (this.country.country_code !== 'IN') {  // without +91
	                this.country_codeLength = 20;
	              } else {
	                this.country_codeLength = 12;
	              }
	            } else {
	              this.phone_code = this.configData.region.IN.India.code;
	              this.phone_code = this.configData.region.IN.India.code.replace('+', '');
	              this.selected_country = {'name': this.country.country, 'code': this.country.country_code, 'phone-code': this.phone_code};
	              this.countries = [{'name': this.country.country, 'code': this.country.country_code, 'phone-code': this.phone_code}];
	              this.country_code = this.configData.region.IN.India.code + '-';
	              this.register_mobile = this.configData.mobile_registration;
	            }
              this.checkRobiPasswordConditions();
          	});
        } else {
          this.countries = this.countryListtotal;
          let selected_country_api;
          selected_country_api = this.settingsService.getCountry();
          let country;
          for (country in this.countries) {
            if (this.countries[country].code === selected_country_api) {
                this.currentIndex = country;
                this.country_selected_index = country;
                this.selected_country = this.countries[country];
                if (this.countries[country].code === 'IN') {
                  this.country_codeLength = 10;
                } else {
                  this.country_codeLength = 13;
                }
                break;
            }
          }
          // $('#loaderPage').css('display', 'none');
          $('.auto-loader-country').css('display', 'none');
        }
    }, 0);
          // $('#loaderPage').css('display', 'none');

  }
  private screenCheckFunction(): any {
    this.countryList = this.settingsService.getccodeCountryValue();
    if (this.countryList && this.countryList[0]) {
        this.onCountryCcode();
    } else if (this.countryList) {
      let displang;
      displang = this.token ? this.localstorage.getItem('UserDisplayLanguage') : this.localstorage.getItem('display_language');
      if (displang === null || displang === 'null') {
        displang = 'en';
      }
      this.settingsService.setCountryListNew(environment.CountryListApi + displang).subscribe(valuecountry => {
        this.countryList = valuecountry;
        this.onCountryCcode();
      }, err => {
        this.timeoutError = true;
        $('#loaderPage').css('display', 'none');
      });
    } else {
      let ccode;
      ccode = this.settingsService.newCountryValue.subscribe(value => {
        if (value && value[0]) {
          this.countryList = value;
          this.onCountryCcode();
        } else {
          this.timeoutError = true;
          $('#loaderPage').css('display', 'none');
        }
        ccode.unsubscribe();
      });
    }
  }

private onCountryCcode(): any {
    // this.countryList = valuecountry;
    $('#loaderPage').css('display', 'none');
    this.countryCodeInput =  this.countryList[0] && this.countryList[0]['phone-code'] ?  this.countryList[0]['phone-code'] : '';
    if (this.countryList && this.countryList.length >= 1) {
      let value;
      value = this.routeservice.sendSignal();
      if (value === 'mobile') {
          this.calltologinpage();
      } else if (value === 'email') {
          this.calltologinpage();
      } else if (value === 'register') {
          this.toggleRegisterHeading();
      } else if (value === '/register/mobile') {
          if (this.countryList) {
            if (this.countryList[0] && this.countryList[0].mobile_registration === 'true') {
              this.toggleRegisterHeading();
            } else if (this.countryList[0] && this.countryList[0].mobile_registration === 'false') {
                  this.toggleRegisterHeading();
            } else if (this.configData) {
              if (this.configData.mobile_registration || this.configData.mobile_registration === undefined) {
                  this.toggleRegisterHeading();
              }
            }
          } else if (this.configData) {
              if (this.configData.mobile_registration || this.configData.mobile_registration === undefined) {
                  this.toggleRegisterHeading();
              } else {
                  setTimeout(() => {
                  $('#body').removeClass('scrolldisbale');
                  this.close();
                  }, 10);
              }
          }
      } else if (value === '/register/email') {
          this.toggleRegisterHeading();
      } else if (value === '/signin') {
         this.calltologinpage();
      } else if (value === '/signin/mobile') {
        if (this.countryList) {
          if (this.countryList[0] && this.countryList[0].mobile_registration === 'true') {
            this.calltologinpage();
          } else if (this.countryList[0] && this.countryList[0].mobile_registration === 'false') {
            this.calltologinpage();  // not off mobile registrtion
          } else if (this.configData) {
            if (this.configData.mobile_registration || this.configData.mobile_registration === undefined) {
                this.calltologinpage();
            }
          }
        } else if (this.configData) {
            if (this.configData.mobile_registration || this.configData.mobile_registration === undefined) {
                this.calltologinpage();
            } else {
                setTimeout(() => {
                $('#body').removeClass('scrolldisbale');
                this.close();
                }, 10);
            }
        }
      } else if (value === '/signin/email') {
          this.calltologinpage();
      } else if (value === '/verify?code=' + this.code) {
          this.toggleLoginHeading();
      } else if (value === '/forgotpassword' || value === '/forgotpassword/email' || value === '/forgotpassword/mobile') {
          this.settingsService.bluekaiPagename('forgotpassword');
          this.routeservice.forgotSignal('email');
          this.callLoginComponentFlag = true;
          this.callRegisterComponentFlag = false;
      } else if (value === '/resetpassword?code=' + this.forgotcode) {
          this.settingsService.bluekaiPagename('resetpassword');
          this.routeservice.forgotSignal(value);
          this.callLoginComponentFlag = true;
          this.callRegisterComponentFlag = false;
      } else {
          this.toggleLoginHeading();
        }
        if (this.countryList && this.countryList.length !== 0) {
          if (this.countryList[0] && this.countryList[0].mobile_registration) {
            if (this.countryList[0].mobile_registration === 'false') {
              this.register_mobile = false;
            } else if (this.countryList[0].mobile_registration === 'true') {
                        this.register_mobile = !this.nowTV;
              // this.register_mobile = true;
            }
          } else  {
                        this.register_mobile = !this.nowTV;
            // this.register_mobile = true;
          }
        } else if (this.configData) {
            if (this.configData.mobile_registration) {
             this.register_mobile = this.configData.mobile_registration;
            } else {
                        this.register_mobile = !this.nowTV;
             // this.register_mobile = true;
           }
        }
      } else {
          this.toggleLoginHeading();
      }
}
  private dropdown() {
    let browser;
    browser = this.videoService.get_browser();
   if (browser.name === 'Firefox') {
     this.fireFoxdropReg = true;
    }
     this.dropDownCheck = !this.dropDownCheck;
     if (this.dropDownCheck) {
         this.currentIndex = this.country_selected_index;
         let index, scope;
         index  = 'countryList' + this.currentIndex;
         scope = this;
         setTimeout(() => {
           document.getElementById(index).focus();
         }, 100);
       }
  }

  // @HostListener('window:keydown', ['$event'])
  private MobileEmailRestrictNumbers(e) {
  // Allow: backspace, delete, tab, escape, enter.
if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
   // Allow: Ctrl+A, Command+A
  (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
        // Allow: Ctrl+V, Command+V
  (e.keyCode === 86 && (e.ctrlKey === true || e.metaKey === true)) ||
         // Allow: home, end, left, right, down, up
  (e.keyCode >= 35 && e.keyCode <= 40)) {
             // let it happen, don't do anything
    return;
  }
// Ensure that it is a number and stop the keypress
  // if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
  //     e.preventDefault();
  // }
  // $('#mobileEmailValues').on('paste', function  (event) {
  //   setTimeout(function () {
  //     //     $('#mobileNumber').val($('#mobileNumber').val().replace(/[^0-9]/g, ''));
  //     // }, 1);
  //     $('#mobileEmailValues').val($('#mobileEmailValues').val().replace(/^\d{10}|\w+@\w+\.\w{2,3}$/, ''));
  //     }, 1);
  // });
  }
  private mobileEmailEnter() {
  // if (this.navigator.userAgent.match(/SM-T531/) && ( this.window.orientation === 0 ||  this.window.orientation === 180)) {
  //   $('.registerMobileContainer').css({'top': '-120px'});
  // }
  $('.mobileEmailForm').css({'border-color': '#6e6e6e'});
  $('.mobileEmailContainerForm').css({'border-color': '#6e6e6e'});
  $('.InvalidMobileEmail').css({'display': 'none'});
  }
  private mobileEmailValidation() {
  // if (this.navigator.userAgent.match(/SM-T531/) && ( this.window.orientation === 0 ||  this.window.orientation === 180)) {
  //     $('.registerMobileContainer').css({'top': 'auto'});
  // }
  this.mobileEmailValue = $('#mobileEmailValues').val().trim();
  this.isnum = /^\d+$/.test(this.mobileEmailValue);
  if (this.isnum === true) {
      if (this.phone_code === "971") {
          this.mobileEmailValue =  this.mobileEmailValue.replace(/^0+/, '');
          this.mobileEmailValue = this.mobileEmailValue.replace(/^971+/, '');
      }

      this.setNowTvEmail();
  }
  if (this.register_mobile) {
    let minMobileLength;
     minMobileLength = this.selected_country && this.selected_country.valid_mobile_digits ? this.selected_country.valid_mobile_digits : 5;
    let maxMobileLength;
    maxMobileLength = this.selected_country && this.selected_country.valid_mobile_digits_max ? this.selected_country.valid_mobile_digits_max : 20;
    let count1;
    count1 = $('#mobileEmailValues').val().length;
    if (count1 >= 0 ) {
      let scope;
      scope = this;
      $(this.document).ready(function() {
        let mobile_number;
        let re, emailTest;
        // re = /^([a-zA-Z0-9._]+)(@(?=.{1,}.[^.]*$)+)([A-Za-z0-9-]+)(.[A-Za-z0-9]+)*(.[A-Za-z]{1,})$/;
        // re = /^([a-zA-Z0-9]+)(([^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        // re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/; // to validate c.abcd@gags.co
        re = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?/; //to validate c.@asd.adf and caps
        mobile_number = $('#mobileEmailValues').val().trim();
        emailTest = (mobile_number.length > 0) ? re.test(mobile_number) : true;
        this.isnum = /^\d+$/.test(mobile_number);
        if (mobile_number.length === 0) {
          $('#RegisterMobileEmailEnterMsg').css({'display': 'block'});
          $('.mobileEmailContainerForm').css({'border-color': 'red'});
        }
        if (this.isnum === true) {
          if ((mobile_number.length > 0)  && (mobile_number.length < minMobileLength) || (mobile_number.length > maxMobileLength) && ( emailTest === false)) {
            $('.mobileContainerForm').css({'border-color': 'red'});
            $('#RegisterMobileEmailErrorMsg').css({'display': 'block'});
            scope.mobile_return = false;
        } else {
         // todo
       }
      } else {
        if ((mobile_number.length > 0) && ( emailTest === false)) {
          $('.mobileEmailContainerForm').css({'border-color': 'red'});
          $('#RegisterMobileEmailErrorMsg').css({'display': 'block'});
          scope.mobile_return = false;
          scope.mobile_return_keypress = false;
       } else {
         // todo
       }
      }

    });
  } else {
    this.mobile_return = true;
    $('.mobileEmailContainerForm').css({'border-color': '#6e6e6e'});
    $('#RegisterMobileEmailErrorMsg').css({'display': 'none'});
  }
  this.checkRobiPasswordConditions();
  return this.mobile_return;
  } else { // Email validation
    let email_count;
    email_count = $('#mobileEmailValues').val().length;
    if (email_count >= 0 ) {
      let scope;
      scope = this;
      $(this.document).ready(function() {
        let emailtext;
        let re, emailTest;
        // re = /^([a-zA-Z0-9]+)(([^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        // re = /^([a-zA-Z0-9._]+)(@(?=.{1,}.[^.]*$)+)([A-Za-z0-9-]+)(.[A-Za-z0-9]+)*(.[A-Za-z]{1,})$/;
        // re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/; // to validate c.abcd@gags.co
        re= /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?/; // to validate c.abcd@gags.co and caps
        emailtext = $('#mobileEmailValues').val().trim();
        emailTest = (emailtext.length > 0) ? re.test(emailtext) : true;
        if (emailtext.length === 0) {
          $('#RegisterEmailEnterMsg').css({'display': 'block'});
          $('.mobileEmailContainerForm').css({'border-color': 'red'});
          scope.setNowTvEmail();
        }
        if ((emailtext.length > 0) && ( emailTest === false)) {
          $('.mobileEmailContainerForm').css({'border-color': 'red'});
          $('#RegisterEmailErrorMsg').css({'display': 'block'});
          scope.mobile_return = false;
          scope.mobile_return_keypress = false;
          scope.setNowTvEmail();
        }
      });
    } else {
      this.mobile_return = true;
      $('.mobileEmailContainerForm').css({'border-color': '#6e6e6e'});
      $('#RegisterEmailErrorMsg').css({'display': 'none'});
    }
    this.checkRobiPasswordConditions();
    return this.mobile_return;
  }
  }

  private mobileEmailValidationkeypress() {
    if (this.register_mobile) {
      let minMobileLength, maxMobileLength, count1, scope;
      minMobileLength = this.selected_country && this.selected_country.valid_mobile_digits ? this.selected_country.valid_mobile_digits : 5;
      maxMobileLength = this.selected_country && this.selected_country.valid_mobile_digits_max ? this.selected_country.valid_mobile_digits_max : 20;
    scope = this;
    count1 = $('#mobileEmailValues').val().length;
    if (count1 > 0) {
      $(this.document).ready(function() {
        let mobile_number;
        let re, emailTest;
        // re = /^([a-zA-Z0-9]+)(([^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        // re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/; // to validate c.abcd@gags.co
        // re = /^([a-zA-Z0-9._]+)(@(?=.{1,}.[^.]*$)+)([A-Za-z0-9-]+)(.[A-Za-z0-9]+)*(.[A-Za-z]{1,})$/;
        re = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?/; // to validate c.abcd@gags.co and caps 
        mobile_number = $('#mobileEmailValues').val().trim();
        emailTest = (mobile_number.length > 0) ? re.test(mobile_number) : true;
        this.isnum = /^\d+$/.test(mobile_number);
        if (mobile_number.length <= 0) {
          scope.mobile_return_keypress = false;
        }
        if (this.isnum === true) {
          if ((mobile_number.length < minMobileLength) || (mobile_number.length > maxMobileLength) && ( emailTest === false)) {
            scope.mobile_return_keypress = false;
          } else {
            scope.mobile_return_keypress = true;
          }
        } else {
          if (emailTest === false) {
            scope.mobile_return_keypress = false;
          } else {
            scope.mobile_return_keypress = true;
          }
        }
      });
    } else if (count1 === 0) {
      this.mobile_return_keypress = false;
    }
    this.checkRobiPasswordConditions();
    return this.mobile_return_keypress;
    } else { // validation for only Email
      let emailCount;
      let scope;
      scope = this;
      emailCount = $('#mobileEmailValues').val().length;
      if (emailCount > 0) {
        let email, re, emailTest;
        // re = /^([a-zA-Z0-9._]+)(@(?=.{1,}.[^.]*$)+)([A-Za-z0-9-]+)(.[A-Za-z0-9]+)*(.[A-Za-z]{1,})$/;
        // re = /^([a-zA-Z0-9]+)(([^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        // re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/; // to validate c.abcd@gags.co
        re = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?/; // to validate c.abcd@gags.co and caps 
        email = $('#mobileEmailValues').val().trim();
        emailTest = (email.length > 0) ? re.test(email) : true;
        if (email.length <= 0) {
          scope.mobile_return_keypress = false;
        }
        if (emailTest === false) {
          scope.mobile_return_keypress = false;
        } else {
          scope.mobile_return_keypress = true;
        }

      } else {
        if (emailCount === 0) {
          this.mobile_return_keypress = false;
        }
      }
      this.checkRobiPasswordConditions();
      return this.mobile_return_keypress;
    }
  }
   private typechange() {  // visible r hide eye icon
    this.type = !this.type;
    // this.pwdValidationMobile();
  }
  private showPassword() {  // mobile passward placeholder
    if (this.navigator.userAgent.match(/SM-T531/) && ( this.window.orientation === 0 ||  this.window.orientation === 180)) {
      $('.registerMobileContainer').css({'top': '-120px'});
    }
    $('.InvalidPassword').css({'display': 'none'});
    $('.miniCharcter').css({'display' : 'none'});
    $('.passwordForm').css({'border-color': '#6e6e6e'});
    $('.miniCharcter').css({'color': '#6e6e6e'});
    this.passwordCheck = true;
    this.place = true;
  }
  private focusOutFunction() {
    if (this.navigator.userAgent.match(/SM-T531/) && ( this.window.orientation === 0 ||  this.window.orientation === 180)) {
      $('.registerMobileContainer').css({'top': 'auto'});
    }
    let count;
    count = $('#mypassword').val().length;
    if ( count < 1 ) {
      this.passwordCheck = false;
    }
    this.place = false;
  }
  private pwdValidationMobile(): any {
    let count1;
    count1 = $('#mypassword').val().length;
    if (count1 >= 0 ) {
      let scope;
      scope = this;
      $(this.document).ready(function() {
        let pw_text;
        pw_text = $('#mypassword').val();
         if (pw_text.length < 6) {
          $('.InvalidPassword').css({'display': 'none'});
          $('.passwordForm').css({'border-color': 'red'});
          $('.miniCharcter').css({'color': 'red'});
          $('#miniCharcter').css({'display': 'block'});
          scope.password_return = false;
         } else {
          scope.password_return = true;
         }
         return scope.password_return;
      });
    }
  }
  private pwdValidationEmail(): any {
    let count1;
    count1 = $('#mypassword').val().length;
    if (count1 >= 0) {
      let scope;
      scope = this;
      $(this.document).ready(function() {
        let pw_text;
        pw_text = $('#mypassword').val();
        if (pw_text.length < 6) {
          $('.InvalidPassword').css({'display': 'none'});
          $('.passwordForm').css({'border-color': 'red'});
          $('.miniCharcterEmail').css({'color': 'red'});
          scope.password_return = false;
         } else {
           scope.password_return = true;
         }
         return scope.password_return;
      });
    }
  }
  private pwdValidationKeypress(): any {
    let count1;
    count1 = $('#mypassword').val().length;
   if (count1 >= 0 ) {
     let scope;
     scope = this;
     $(this.document).ready(function() {
       let pw_text;
       pw_text = $('#mypassword').val();
        if (pw_text.length < 6) {
          scope.password_return_keypress = false;
        } else {
           scope.password_return_keypress = true;
        }
       return scope.password_return_keypress;
     });
   }
 }
  private pwdValidationMobileKeypress(): any {
    let count1;
    count1 = $('#mypassword').val().length;
   if (count1 >= 0 ) {
     let scope;
     scope = this;
     $(this.document).ready(function() {
       let pw_text;
       pw_text = $('#mypassword').val();
        if (pw_text.length < 6) {
          scope.password_return_keypress = false;
        } else {
           scope.password_return_keypress = true;
        }
        return scope.password_return_keypress;
     });
   }
 }
 private bridgeEnter(event) {
  if (event.keyCode === 13) {
    $('.registerSubmit').click();
    $('.continueButton').click();
  }
}
  // Enable And Disabling Register Button
  // CheckAllFieldsValidation(){

  //   if ( this.mobile_return_keypress === false || this.password_return_keypress === false || this.receivedValue.sendValues[0]['userValue'] === false || this.receivedValue.sendValues[1]['userValue'] === false || this.receivedValue.sendValues[2]['userValue'] === false) {
  //     $('.registerSubmit').css({'background-color': '#50012f', 'color': '#703055'});
  //     console.log(true);
  //     return 1;
  //   } else {
  //      $('.registerSubmit').css({'background-color': '#bf006b', 'color': '#eeeeee'});
  //     return 0;
  // }
  // }
    private checkLengthMobilekeypress() {
      if (this.checkRobiConditions() && this.mobile_return_keypress && this.receivedValue.sendFlag && this.receivedValue.sendCount) {
      // if (this.msisdnUser && $('#mobileEmailValues').val() === this.msisdnData.mobile && this.mobile_return_keypress && this.receivedValue.sendFlag && this.receivedValue.sendCount) {
        $('.registerSubmit').css({'background-color': '#bf006b', 'color': '#eeeeee'});
        return false;
      } else if (!(this.mobile_return_keypress && this.password_return_keypress && this.receivedValue.sendFlag && this.receivedValue.sendCount)) {
        $('.registerSubmit').css({'background-color': '#50012f', 'color': '#703055'});
        return true;
      } else {
        $('.registerSubmit').css({'background-color': '#bf006b', 'color': '#eeeeee'});
        return false;
      }
  }
  private checkLengthMobile() {
      if (this.checkRobiConditions() && this.mobile_return && this.receivedValue.sendFlag && this.receivedValue.sendCount) {
      // if (this.msisdnUser && $('#mobileEmailValues').val() === this.msisdnData.mobile && this.mobile_return && this.receivedValue.sendFlag && this.receivedValue.sendCount) {
        $('.registerSubmit').css({'background-color': '#bf006b', 'color': '#eeeeee'});
        return false;
      } else if (!(this.mobile_return && this.password_return && this.receivedValue.sendFlag && this.receivedValue.sendCount)) {
        $('.registerSubmit').css({'background-color': '#50012f', 'color': '#703055'});
        return true;
      } else {
        $('.registerSubmit').css({'background-color': '#bf006b', 'color': '#eeeeee'});
        return false;
     }
  }

  public callRegisterConfirmscreen(id: string) {
    let network;
    network = this.networkService.getPopupStatus();
    if (network === true) {
      this.modalServices.open(id);
    }
  }
  public closeModal(id: string) {
    this.modalServices.close(id);
  }
  private calltologinpage (html?: boolean): any {
    let network;
    if (!html) {
      html = false;
    }
    network = this.networkService.getPopupStatus();
    this.headerservicesService.internationalLoginPageChange(true);
    this.seoservice.constructHrefLang({id: 1, url: '/signin'});
        this.linkservice.addTag({ rel: 'canonical', href: window.location.origin + '/' + this.routeservice.getBaseLocation() + 'signin'} );
    if (network === true) {
      this.routeservice.Signal(null);
      // this.to.replaceState('signin');
      // if(this.queryparams && this.queryparams.length > 0) {
      //   this.to.replaceState('/signin?'+ this.queryparams)
      // } else {
      //   this.to.replaceState('signin')
      // }

      this.queryparams = window.location.href.split('?')[1];
      if (html) {
        this.to.replaceState('signin');
      } else if (this.queryparams && this.queryparams.length > 0 && html === false) {
        this.to.replaceState('signin?' + this.queryparams);
      }
      this.pageName = 'signin';   // send page name to gtm
      this.gtm.sendPageName(this.pageName);
      this.gtm.sendEvent();
      this.settingsService.bluekaiPagename('login');
      this.internationallogin = true;
      this.callLoginComponentFlag = true;
      this.callRegisterComponentFlag = false;
    }
  }
  // private callLoginscreen(value): any {
  //   let network;
  //   network = this.networkService.getPopupStatus();
  //   if (network === true) {
  //     if (value === 'email') {
  //       this.callLoginEmail();
  //     } else {
  //       this.callLoginMobile();
  //     }
  //   }
  // }
  // private callLoginEmail(): any {
  //   let network;
  //   network = this.networkService.getPopupStatus();
  //   this.seoservice.constructHrefLang({id: 1, url: '/signin/email'});
  //       this.linkservice.addTag({ rel: 'canonical', href: window.location.origin + '/' + this.routeservice.getBaseLocation() + 'signin/email'} );
  //   if (network === true) {
  //     this.routeservice.Signal(null);
  //     this.to.replaceState('signin/email');
  //      this.loginthrough = 'LOGIN.LOGIN_VIA_EMAIL';
  //     this.pageName = 'sign in/email';   // send page name to gtm
  //     this.gtm.sendPageName(this.pageName);
  //     this.gtm.sendEvent();
  //     this.settingsService.bluekaiPagename('login');
  //     this.internationalLoginComponent = true;
  //     this.internationallogin = true;
  //   }
  // }
  // private callLoginMobile(): any {
  //   let network;
  //   network = this.networkService.getPopupStatus();
  //   this.seoservice.constructHrefLang({id: 1, url: '/signin/mobile'});
  //       this.linkservice.addTag({ rel: 'canonical', href: window.location.origin + '/' + this.routeservice.getBaseLocation() + 'signin/mobile'} );
  //   if (network === true) {
  //     this.routeservice.Signal(null);
  //     this.to.replaceState('signin/mobile');
  //     this.loginthrough = 'LOGIN.LOGIN_VIA_MOBILE';
  //     this.pageName = 'sign in/mobile';
  //     this.gtm.sendPageName(this.pageName);
  //     this.gtm.sendEvent();
  //     this.settingsService.bluekaiPagename('login');
  //     this.internationalLoginComponent = true;
  //     this.internationallogin = true;
  //   }
  // }
  private toggleLoginHeading(): any {
    $('.auto-loader').css('display', 'none');
   let network;
   network = this.networkService.getPopupStatus();
   if (network === true) {
     // this.to.replaceState('signin');
     this.queryparams = window.location.href.split('?')[1];
       if (this.queryparams && this.queryparams.length > 0 ) {
        this.to.replaceState('signin?' + this.queryparams);
      } else {
         this.to.replaceState('signin');
      }
     this.seoservice.constructHrefLang({id: 1, url: '/signin'});
     this.linkservice.addTag({ rel: 'canonical', href: window.location.origin + '/' + this.routeservice.getBaseLocation() + 'signin'} );
     this.qgraphevent('signin_initiated', {'method': 'swtichtosignin', 'country' : this.countrycode });
     this.routeservice.Signal(null);
     this.internationallogin = true;
     this.callRegisterComponentFlag = false;
     this.callLoginComponentFlag = false;
     $('#body').addClass('scrolldisbale');
     this.routeservice.forgotSignal(null);
     this.pageName = 'sign in';
     this.gtm.sendPageName(this.pageName);
     this.gtm.sendEvent();
     this.settingsService.bluekaiPagename('login');

   }
 }
  private toggleRegisterHeading(): any {
  $('.auto-loader').css('display', 'none');
  let network;
  network = this.networkService.getPopupStatus();
  this.seoservice.constructHrefLang({id: 1, url: '/register'});
  this.linkservice.addTag({ rel: 'canonical', href: window.location.origin + '/' + this.routeservice.getBaseLocation() + 'register'} );
  if (network === true) {
    this.routeservice.Signal(null);
    // this.to.replaceState('register');
    this.queryparams = window.location.href.split('?')[1];
    if (this.queryparams && this.queryparams.length > 0) {
        this.to.replaceState('register?' + this.queryparams);
      } else {
        this.to.replaceState('register');
      }
    this.qgraphevent('signup_initiated', {'method': 'swtichtoSignup', 'country' : this.countrycode, 'state': this.localstorage.getItem('state_code') });
    this.callRegisterComponentFlag = true;
    this.checkMsisdn();
    this.callLoginComponentFlag = false;
    $('#body').addClass('scrolldisbale');
    this.pageName = 'register';
    this.gtm.sendPageName(this.pageName);
    this.gtm.sendEvent();
    this.settingsService.bluekaiPagename('register');

  }
  }
  // private callRegisterMobile(): any {
  //   let network;
  //   network = this.networkService.getPopupStatus();
  //   this.seoservice.constructHrefLang({id: 1, url: '/register/mobile'});
  //       this.linkservice.addTag({ rel: 'canonical', href: window.location.origin + '/' + this.routeservice.getBaseLocation() + 'register/mobile'} );
  //   if (network === true) {
  //     this.to.replaceState('register/mobile');
  //     this.registerMobileFlag = true;
  //     this.pageName = 'register/mobile';    // send page name to gtm
  //     this.gtm.sendPageName(this.pageName);
  //     this.gtm.sendEvent();
  //     this.settingsService.bluekaiPagename('register');

  //   }
  // }
  // private callRegisterEmail(): any {
  //   let network;
  //   network = this.networkService.getPopupStatus();
  //   this.seoservice.constructHrefLang({id: 1, url: '/register/email'});
  //       this.linkservice.addTag({ rel: 'canonical', href: window.location.origin + '/' + this.routeservice.getBaseLocation() + 'register/email'} );
  //   if (network === true) {
  //     this.to.replaceState('register/email');
  //     this.pageName = 'register/email';
  //     this.gtm.sendPageName(this.pageName);
  //     this.gtm.sendEvent();
  //     this.settingsService.bluekaiPagename('register');

  //   }
  // }
  // Sending Data to GDPR component
  private sendData(value) {
    this.receivedValue = value ;
    setTimeout(function () {
      $('.loaderImage').css('display', 'none');
    }, 500);
  }
  public close(): any {
     this.callRegisterComponentFlag = false;
     this.callLoginComponentFlag = false;
    $('#body').removeClass('scrolldisbale');
    this.headerservicesService.modelChange(false);
    this.headerservicesService.internationalRegisterChange(false);
    this.document.getElementById('body').classList.remove('modal-open');
    this.routeservice.Signal(null);
    this.previousUrl = this.localstorage.getItem('previousRoute');
    let postRoute;
    postRoute = this.localstorage.getItem('postSubscriptionRoute');
    if (this.previousUrl !== '/myaccount/subscription' && postRoute) {
      this.localstorage.removeItem('postSubscriptionRoute');
      this.commonService.getPostSubscriptionRoute(postRoute, '');
    } else if (this.localstorage.getItem('token') && this.localstorage.getItem('nowTV') && this.localstorage.getItem('nowTV') === 'true') {
        this.router.navigate(['/device']);
        this.localstorage.removeItem('nowTV');
    } else {
      if (this.previousUrl !== null) {
        if (this.previousUrl.match(/search\/result/g)) {
          let query;
          query = this.previousUrl.slice(17);
          query = decodeURIComponent(query);
          this.router.navigate(['/search/result'], { queryParams: { q: query} });
          this.to.go(this.previousUrl);
        } else if (this.previousUrl.match(/resetpassword/g)) {
          this.router.navigate(['/']);
          this.to.replaceState('/');
        } else {
          this.router.navigate([this.previousUrl]);
          this.to.replaceState(this.previousUrl);
        }
      } else {
        this.router.navigate(['/']);
        this.to.replaceState('/');
      }
    }
  }
  public callToRegisterPageAtRegister_fn(event: any): any {
    this.callLoginComponentFlag = false;
    this.callRegisterComponentFlag = true;
    this.checkMsisdn();
  }
  // Posting data for International Register
  public RegisterInternational(): any {
  this.mobile_return_keypress = false;
  // this.password_return_keypress = false;
    this.silentRegister();
    this.closeModal('register-confirmation-modal');
  }
  private disableBtn(): void {
    // $('#silentRegisterSubmit').prop('disabled', true);
    // $('#silentRegisterSubmit').removeClass('highlightBtn');
    // this.apiCall = false;
  }
  private enableBtn(): void {
    // $('#silentRegisterSubmit').prop('disabled', false);
    // $('#silentRegisterSubmit').addClass('highlightBtn');
    // this.apiCall = true;
  }
  private silentRegister() {
    let network;
    network = this.networkService.getPopupStatus();
    if (network === true) {
      let mobile_number;
      mobile_number = $('#mobileEmailValues').val().trim();
      this.isnum = /^\d+$/.test(mobile_number);
      this.qgraphevent('signup_initiated', {'method': 'email', 'country' : this.settingsService.getCountry(), 'state': this.localstorage.getItem('state_code')});
      let policyValues, country_code, country_Promotion, version_number;
      if (this.receivedValue.sendFlag && this.receivedValue.sendCount) {
        policyValues = [];
        for (let i = 0; i < 4; i++) {
          if (!(this.receivedValue.sendValues[i].status) || this.receivedValue.sendValues[i].status === undefined) {
           policyValues[i] = 'na';
          } else if (!(this.receivedValue.sendValues[i].userValue)) {
           policyValues[i] = 'no';
          } else if (this.receivedValue.sendValues[i].userValue === true) {
           policyValues[i] = 'yes';
          }
        }
        $('.auto-loader').css('display', 'block');
        this.disableBtn();
        this.apiCall = true;
        country_code = this.settingsService.getCountry();
        country_Promotion = this.settingsService.getCountryPromotionalValue();
        version_number = (this.navigator.userAgent).split(' ').join(';');  // gdpr additional field version number while post
        let postdata, mobileTest, registerMethod, mcheck, echeck;
        if (this.isnum === true) {
            let trimedPhonenumber = $('#mobileEmailValues').val().trim();
            if (this.phone_code === "971") {
                trimedPhonenumber =  trimedPhonenumber.replace(/^0+/, '')
                trimedPhonenumber = trimedPhonenumber.replace(/^971+/, '')
            }

          mcheck = $('#mobileEmailValues').val() ? trimedPhonenumber : trimedPhonenumber;
          mobileTest = this.country_code  ?  this.phone_code  + mcheck : trimedPhonenumber;
          registerMethod = {'type' : 'mobile', 'value' : mobileTest};
        } else {
          echeck = $('#mobileEmailValues').val() ? $('#mobileEmailValues').val().trim() : $('#mobileEmailValues').val();
          registerMethod = {'type' : 'email', 'value' : $('#mobileEmailValues').val().trim()};
        }
        postdata = {
          'password': $('#mypassword').val(),
          'fname': '',
          'lname': '',
          'additional': {
            'gdpr_policy': [{
              'country_code': country_code,
              'gdpr_fields':
              { 'policy': policyValues[0],
                'profiling': policyValues[1],
                'age': policyValues[2],
                 'subscription': policyValues[3]
               }
             }],
             'guest_token': this.localstorage.getItem('guestToken'),
             'sourceapp' : 'Web',
             'version_number' : version_number,
             'promotional': {
                'on': country_Promotion.on,
                'token': country_Promotion.token
              },
              'first_time_login': '1',
              'platform': 'Web',
              'version': this.window.appVersion
            }
          };
            postdata = $.extend({}, postdata, registerMethod);
            let recAdd, silentMethod;
            recAdd = this.checkUpdateCampaign(postdata);
            // recAdd = this.gtm.checkUpdateCampaign(postdata);
            if (this.isnum === true) {
              silentMethod = 'Mobile';
            } else {
              silentMethod = 'Email';
            }
            $('.auto-loader-country').css('display', 'block');
            if (this.msisdnUser && (this.selected_country['phone-code'] + $('#mobileEmailValues').val()) === this.msisdnData.msisdn) {
            // if (this.msisdnUser && this.msisdnData.mobile === $('#mobileEmailValues').val()) {
              recAdd['token'] = this.msisdnData.token;
              // recAdd['token'] = this.msisdnData.token;
              delete recAdd.password;
              let operator;
              operator = 'Robi';
              this.userAction.robiRegistration(JSON.stringify(recAdd)).subscribe(value => {
                $('body').css('pointer-events', 'none');
                this.silentLoginToken = JSON.parse(value._body).data.access_token;
                // this.silentLoginToken = JSON.parse(value._body).token;
                if (this.silentLoginToken) {
                  let params;
                  params = 'bearer ' + this.silentLoginToken;
                  this.config = {
                    apiKey: params,
                    username: '',
                    password: '',
                    accessToken: '',
                    withCredentials: false
                  };
                }
                this.updateLS(silentMethod, policyValues); // updating local storage
                if (this.isnum === false) {
                  if (this.window.qg) {
                    this.qgraphevent('signup_success', {'method': 'email', 'country' : this.settingsService.getCountry(), 'state': this.localstorage.getItem('state_code')});

                    if (this.qgraph !== true) {
                      qg('event', 'user_verification_status', {'verified': 'false',  'email': echeck, 'country' : this.settingsService.getCountry(), 'state': this.localstorage.getItem('state_code')});
                    }
                  }
                  this.GAUpdateCommon('RegisterSuccess', silentMethod, operator);
                } else {
                  $('.auto-loader').css('display', 'none');
                  this.enableBtn();
                  this.error_message = JSON.parse(value._body).message;
                  this.callToast();
                }
                // $('.auto-loader-country').css('display', 'none');
              }, err => {
                $('.auto-loader').css('display', 'none');
                this.enableBtn();
                this.qgraphevent('signup_failure', {'method': 'email', 'country' : this.settingsService.getCountry(), 'state': this.localstorage.getItem('state_code')});
                if (err.name === 'TimeoutError') {
                    this.error_message = 'MESSAGES.TRY_LATER';
                    this.callToast();
                } else {
                    this.error_message = JSON.parse(err._body).message;
                    this.callToast();
                }
                /* GA changes for Register Fail*/
                this.GAUpdateCommon('RegisterFailed', silentMethod, operator);
                /* GA changes for Register Fail*/
                this.gtm.sendErrorEvent('api', err);
                $('.auto-loader-country').css('display', 'none');
              });
            } else {
              let operator;
              operator = 'NA';
              this.userAction.subSilentLogin(JSON.stringify(recAdd)).subscribe(value => {
              $('body').css('pointer-events', 'none');

              this.silentLoginToken = JSON.parse(value._body).token;
                if (this.silentLoginToken) {
                  let params;
                  params = 'bearer ' + this.silentLoginToken;
                  this.config = {
                    apiKey: params,
                    username: '',
                    password: '',
                    accessToken: '',
                    withCredentials: false
                  };
                }
                this.updateLS(silentMethod, policyValues); // updating local storage
                if (this.isnum === false) {
                  if (this.window.qg) {
                    this.qgraphevent('signup_success', {'method': 'email', 'country' : this.settingsService.getCountry(), 'state': this.localstorage.getItem('state_code')});

                    if (this.qgraph !== true) {
                      qg('event', 'user_verification_status', {'verified': 'false',  'email': echeck, 'country' : this.settingsService.getCountry(), 'state': this.localstorage.getItem('state_code')});
                    }
                  }
                  this.GAUpdateCommon('RegisterSuccess', silentMethod, operator);
                } else {
                  $('.auto-loader').css('display', 'none');
                  this.enableBtn();
                  this.error_message = JSON.parse(value._body).message;
                  this.callToast();
                }
                // $('.auto-loader-country').css('display', 'none');
              }, err => {
                $('.auto-loader').css('display', 'none');
                this.enableBtn();
                this.qgraphevent('signup_failure', {'method': 'email', 'country' : this.settingsService.getCountry(), 'state': this.localstorage.getItem('state_code')});
                if (err.name === 'TimeoutError') {
                    this.error_message = 'MESSAGES.TRY_LATER';
                    this.callToast();
                } else {
                    this.error_message = JSON.parse(err._body).message;
                    this.callToast();
                }
                /* GA changes for Register Fail*/
                this.GAUpdateCommon('RegisterFailed', silentMethod, operator);
                /* GA changes for Register Fail*/
                this.gtm.sendErrorEvent('api', err);
                $('.auto-loader-country').css('display', 'none');
              });              
            }
          }
    }
  }
  private callToastRegister() {
    this.openSignin();
    let scope, p;
    scope = this;
    p = this.document.getElementById('snackbar');
    p.className = 'show';
    setTimeout(function() { p.className = p.className.replace('show', '');
      if (scope.localstorage.getItem('token') && scope.localstorage.getItem('nowTV') && scope.localstorage.getItem('nowTV') === 'true') {
        scope.localstorage.removeItem('nowTV');
        location.href = scope.window.location.origin + '/device';
      } else {
        location.href = scope.window.location.origin + scope.previousUrl;
      }
    }, 3000);
  }
  private callToast() {
    this.openSignin();

    let p;
    p = this.document.getElementById('snackbar');
    p.className = 'show';
    setTimeout(function() { p.className = p.className.replace('show', ''); }, 5000);
  }
  private GAUpdateCommon(gAevent, loginMethod, operator) {    ///  GA event = LoginSuccess/registerFailure  /// loginMethod = fb,g+,tw,mob,em
    this.tokenValue = this.gtm.fetchToken();
    this.timestampTime = this.gtm.fetchCurrentTime();
    this.timestampDateTime = this.gtm.fetchCurrentDate();
    this.clientID = this.gtm.fetchClientId();
    this.marketingValue = this.gtm.fetchMarketing();
    let sendData;
    sendData = {
        'event' : gAevent,
        'G_ID' : this.tokenValue,
        'Client_ID': this.clientID,
        'retargeting_remarketing' : this.marketingValue,
        'LoginMethod' : loginMethod,
        'operator' : operator || 'NA',
        'TimeHHMMSS': this.timestampTime,
        'DateTimeStamp': this.timestampDateTime
      };
      this.gtm.appendPara(gAevent, sendData);
  }
  private updateLS(silentMethod: any, policyValue: any): any {
    let userDetails;
    userDetails = new userApi.UserApi(this.http, null, this.config);
    userDetails.v1UserGet().timeout(environment.timeOut).subscribe(valueUser => {
      this.userId = valueUser.id;
      this.localstorage.setItem('ID', this.userId);
      this.updateSettingsLang(policyValue);
    }, err => {
        this.updateSettingsLang(policyValue);

    });
      this.localstorage.setItem('token', this.silentLoginToken);
      this.localstorage.setItem('login', silentMethod);
  }
  private updateSettingsLang(policyValue: any): any {
    let  countryCode;
    countryCode = this.localstorage.getItem('country_code');
    if ( this.localstorage.getItem('ContentLang').length === 0) {
            this.localstorage.setItem('ContentLang', 'en,hi');
          }
          let gdprValue;
                gdprValue = [{'country_code': countryCode,
                            'gdpr_fields': {
                              'policy': policyValue[0],
                              'profiling': policyValue[1],
                              'age': policyValue[2],
                              'subscription': policyValue[3]
                            }}];

          this.default_settings = [
            {key: 'display_language', value: this.localstorage.getItem('display_language') },
            {key: 'content_language', value: this.localstorage.getItem('ContentLang') },
            {key: 'streaming_quality', value: 'Auto' },
            {key: 'auto_play', value: 'true' },
            {key: 'download_quality', value: '0' },
            {key: 'recent_search', value: '' },
            {key: 'stream_over_wifi', value: 'false' },
            {key: 'download_over_wifi', value: 'false' },
            {key: 'gdpr_policy', value: JSON.stringify(gdprValue)}];
          for (let i = 0; i < 9 ; i++) {
            const defaultsettings = {
              'key': this.default_settings[i].key,
              'value': this.default_settings[i].value
            };
            let k;
            k = i;
            this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
            this.userSettings.v1SettingsPost(defaultsettings).subscribe(responsePost => {
              if ( k === (this.default_settings.length - 1)) {
                this.localstorage.setItem('googletag', 'false');
              }
              if (i === 8) {
                this.updateSettingsCookies();
              }
            }, err => {
               if (i === 8) {
                this.updateSettingsCookies();
              }
              });

}
  }

  private updateSettingsCookies(): any {
    // updating cookies
    let popupValue;
    this.cookiesLocal = this.localstorage.getItem('cookies');
    this.marketingLocal = this.localstorage.getItem('marketing');
    if (this.cookiesLocal === null || undefined) {
      this.cookiesLocal = 'na';
    }
    if (this.marketingLocal === null || undefined) {
      this.marketingLocal = 'na';
    }
    popupValue = [{'Cookies': this.cookiesLocal, 'RTRM': this.marketingLocal}];
    const cookies_settings = {
      'key': 'popups',
      'value': JSON.stringify(popupValue)
     };
    this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
    this.userSettings.v1SettingsPost(cookies_settings).subscribe(responsePost => {
      // todo
      this.RedirectTo();
    }, err => {
      this.RedirectTo();
    });
  }
private RedirectTo(): any {
this.error_message = 'LOGIN.REGISTER_SUCCESS';
this.callToastRegister();
setTimeout(() => {
   $('#body').removeClass('scrolldisbale');
    this.close();
}, 6000);
}
  private changeValue(event, index) {
    this.dropDownCheck = false;
    this.selected_country = event;
    if (this.country_code) {
     this.country_code = '+' + event['phone-code'] + ' - ';
    }
    this.currentIndex = index;
    this.country_selected_index = index;
    // $('#mobileEmailValues').val('');
    // $('.mobileEmailContainerForm').css({'border-color': '#6e6e6e'});
    // $('.InvalidMobileEmail').css({'display': 'none'});
    this.phone_code = event['phone-code'];
    this.mobileEmailValue = $('#mobileEmailValues').val();

      if (this.phone_code === "971") {
          this.mobileEmailValue =  this.mobileEmailValue.replace(/^0+/, '')
          this.mobileEmailValue = this.mobileEmailValue.replace(/^971+/, '')
      }
    this.mobileEmailValidationkeypress();
    // this.mobile_return = false;
    // this.mobile_return_keypress = false;
  }
  private qgraphevent(eventname, object) {
    if (this.window.qg) {
      // if (this.qgraph) {
      //   delete object.country;
      //   delete object.state;
      //   qg('event', eventname, object);
      // } else {
        qg('event', eventname, object);
      // }
    }
  }
////////////////////// login with social network ////////////////
  private twitterGm() {
    let network;
    network = this.networkService.getPopupStatus();
    if (network === true) {
        this.deleteCookie();
             let x;
             x = new Date();
             let y;
             y = x.getTime();
        //  $('#twitterlogin').attr('href', environment.twitterLogin + '&ver=' + y);
        location.href = environment.twitterLogin + '&ver=' + y;
        this.pageName = 'sign in/twitter';
        this.gtm.sendPageName(this.pageName);
        this.gtm.sendEvent();
        this.qgraphevent('signin_initiated', {'method': 'social_twitter', 'country' : this.countrycode});
        location.href = environment.twitterLogin + '&ver=' + y;
     }
  }
  private loaderalignmentFix(): any {
    $( '.outerContainerImage' ).scrollTop(0);
    $('#loaderPage').css('top', '0');
  }
private deleteCookie(): any {  // for twitter
  document.cookie = 'PHPSESSID' + '=; Path=/;Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
  this.localstorage.removeItem('twitterTime');
}
private twitterRegister() {
 let network;
 network = this.networkService.getPopupStatus();
 if (network === true) {
   this.deleteCookie();
    let x , y ;
     x = new Date();
     y = x.getTime();
    // $('#twitterRegister').attr('href', environment.twitterLogin + '&ver=' + y);
    location.href = environment.twitterLogin + '&ver=' + y;
             this.pageName = 'sign in/twitter';
             this.gtm.sendPageName(this.pageName);
             this.gtm.sendEvent();
             this.qgraphevent('signin_initiated', {'method': 'social_twitter', 'country' : this.countrycode, 'state': this.localstorage.getItem('state_code') });
	     location.href = environment.twitterLogin + '&ver=' + y;
 }
}
private googleGm() {
   let network;
   network = this.networkService.getPopupStatus();
   this.pageName = 'register/google';
   this.gtm.sendPageName(this.pageName);
   this.gtm.sendEvent();
   this.qgraphevent('signup_initiated', {'method': 'social_google', 'country' : this.countrycode, 'state': this.localstorage.getItem('state_code')});
}
private facebookGm() {
   this.pageName = 'register/facebook';
   this.gtm.sendPageName(this.pageName);
   this.gtm.sendEvent();
   this.qgraphevent('signup_initiated', {'method': 'social_fb', 'country' : this.countrycode, 'state': this.localstorage.getItem('state_code')});
}
private googleInit() {
  if ( this.window && this.window.gapi) {
    this.window.gapi.load('auth2', () => {
       let that;
       that = this;
      this.auth2 = this.window.gapi.auth2.init({
        client_id:   that.GOOGLE_CLIENT_ID,
        cookiepolicy: 'single_host_origin',
        scope: 'profile'
      });
      this.attachSignin(this.document.getElementById('go'));
    });
  }
}
private attachSignin(element) {
  this.auth2.attachClickHandler(element, {},
    (googleUser) => {
      let profile;
      profile = googleUser.getBasicProfile();
      this.acces = this.window.gapi.auth2.getAuthInstance().currentUser.get().getAuthResponse(true).access_token;
      this.googleloginApi(this.acces);
      }, error => {
      // console.log('error', error);
      });
}
  private GdprUpdate() {
    if (this.socialFlag === true) {
         $('#loaderPage').css('display', 'block');
      if (this.loginFrom === 'register') {
        if (this.socialType === 'google') {
          this.googleRegister();
        } else {
           this.facebookRegister();
        }
      } else if (this.loginFrom === 'login') {
         this.updateSettingApi(this.sendToken, this.socialType, this.loginFrom);
      }
    }
  }

  private googleloginApi(acces): any {
    this.loaderalignmentFix();
    if (acces) {
      this.removeSignin();
      this.userapi.v1UserLogingoogleGet(acces).timeout(environment.timeOut).subscribe(response => {
      this.loginMethod = 'login';
      this.saveToken = response.token;
      this.checkGdprNode(response.token, 'google');
      }, err => {
        if (err.name === 'TimeoutError') {
          this.error_message = 'MESSAGES.TRY_LATER';
          this.callToast();
        } else if (err.status === 404) {
          this.qgraphevent('signin_failure', {'method': 'social_google', 'country' : this.countrycode });
          this.GAUpdateCommon('LoginFailed', 'googleplus', '');
          this.gtm.sendErrorEvent('api', err);
          this.callRegisterComponentFlag = false;            // to cal GDPR screen                  this.gdprFlag = true;
          this.internationalGdprFlag = true;
          this.socialFlag = true;
          this.socialType = 'google';
          this.loginFrom = 'register';
          $('#loaderPage').css('display', 'block');
          this.triggerClick();
        } else {
          this.error_message = 'MESSAGES.TRY_LATER';
          this.callToast();
        }
      });
    }
  }
  private googleRegister(): any {
    this.createObject(this.acces);   // to create object with token and additional values
    if (this.googleObj) {
      this.userapi.v1UserRegistergooglePost(this.googleObj).timeout(environment.timeOut).subscribe(response => {
        this.loginMethod = 'register';
        this.saveToken = response.token;
        setTimeout(() => {
         this.updateSettingApi(this.saveToken, 'google', 'register');
         this.qgraphevent('signup_success', {'method': 'social_google', 'country' : this.countrycode});
        }, 0);
         this.GAUpdateCommon('RegisterSuccess', 'googleplus', '');
      }, error => {
        if (error.name === 'TimeoutError') {
          this.error_message = 'MESSAGES.TRY_LATER';
          this.callToast();
        } else if (error.status === 404) {
          this.error_message  = this.errors.message;
          setTimeout(() => {
            if (this.error_message) {
              this.callToast();
            }
          }, 3000);
        } else if (error.status === 400) {
          this.callRegisterComponentFlag = true;
          this.checkMsisdn();
          this.internationalGdprFlag = false;
          this.error_message = 'MESSAGES.TRY_LATER';
          this.callToast();
        } else {
          this.error_message = 'MESSAGES.TRY_LATER';
          this.callToast();
        }
        this.GAUpdateCommon('RegisterFailed', 'googleplus', '');
        this.qgraphevent('signup_failure', {'method': 'social_google', 'country' : this.countrycode});
        this.gtm.sendErrorEvent('api', error);
       });
    }
  }
///////////////////////////// facebookApi////////////////////
  private checkLoginState() {
    let network;
    network = this.networkService.getPopupStatus();
    if (network === true) {
       this.error_message = this.localstorage.getItem('header');
        if (this.error_message != null) {
            if (this.error_message === 'false') {
                this.error_message = 'TOAST_MESSAGES.TRACKING';
                this.callToast();
            }
        }
        FB.getLoginStatus(response => {
          this.statusChangeCallback(response);
        });
    }
  }
  private statusChangeCallback(response: any) {
      if (response.status === 'connected') {
          this.login();
      } else {
          this.login();
      }
  }
  private login() {
      FB.login(result => {
          this.loged = true;
          this.token1 = result;
          if (this.token1.authResponse != null) {
           this.fBToken = this.token1.authResponse.accessToken;
          }
          this.facebookloginApi(this.fBToken);
          this.me();
      }, { scope: 'public_profile,email' });
  }
  private me() {
      FB.api('/me?fields=id,name,first_name,email,gender,picture.width(150).height(150),age_range',
          function(result) {
              if (result && !result.error) {
                  this.user = result;
              } else {
                // todo
              }
          });
  }

  private facebookloginApi(FBTOKEN) {
    this.loaderalignmentFix();
    if (FBTOKEN) {
      this.removeSignin();
      this.userapi.v1UserLoginfacebookGet(FBTOKEN).timeout(environment.timeOut).subscribe(response => {
        this.loginMethod = 'login';
        this.saveTokenFacebook = response.token;
        this.checkGdprNode(this.saveTokenFacebook, 'facebook');    // check GDPR node
      }, error => {
          if (error.name === 'TimeoutError') {
            this.error_message = 'MESSAGES.TRY_LATER';
            this.callToast();
          } else if (error.status === 404) {
              this.qgraphevent('signin_failure', {'method': 'social_fb', 'country' : this.countrycode });
              this.GAUpdateCommon('LoginFailed', 'facebook', '');
              this.gtm.sendErrorEvent('api', error);
              this.callRegisterComponentFlag = false;        // for GDPR Screen
              this.internationalGdprFlag = true;
              this.triggerClick();
              this.socialFlag = true;
              this.socialType = 'facebook';
              this.loginFrom = 'register';
          } else {
             this.error_message = 'MESSAGES.TRY_LATER';
             this.callToast();
          }
      });
    }
  }
  private facebookRegister(): any {
   this.createObject(this.fBToken);   // create object with token and additional field
    if (this.googleObj) {
      this.userapi.v1UserRegisterfacebookPost(this.googleObj).timeout(environment.timeOut).subscribe(response => {
          this.loginMethod = 'register';
          this.saveTokenFacebook = response.token;

           setTimeout(() => {
           this.updateSettingApi(this.saveTokenFacebook, 'facebook', 'register');
             this.qgraphevent('signup_success', {'method': 'social_fb', 'country' : this.countrycode});
           }, 0);
           this.GAUpdateCommon('RegisterSuccess', 'facebook', '');
      }, errors => {
            // this.openSignin();
              if (errors.name === 'TimeoutError') {
                this.error_message = 'MESSAGES.TRY_LATER';
                this.callToast();
              } else if (errors.status === 404) {
                 this.error_message  = this.errors.message;
                 setTimeout(() => {
                    if (this.error_message) {
                       this.callToast();
                    }
                 }, 3000);
              } else if (errors.status === 400 || errors.status === 401) {
                  this.callRegisterComponentFlag = true;
                  this.checkMsisdn();
                  this.internationalGdprFlag = false;
                  this.error_message = 'MESSAGES.TRY_LATER';
                  this.callToast();
              } else {
                  this.error_message = 'MESSAGES.TRY_LATER';
                  this.callToast();
              }
            this.GAUpdateCommon('RegisterFailed', 'facebook', '');
            this.qgraphevent('signup_failure', {'method': 'social_fb', 'country' : this.countrycode});
                this.gtm.sendErrorEvent('api', errors);
          });
    }
  }
///////////////////////////// facebookApi////////////////////


////////////////////////////// twitterApi  common function call //////////////////////////
  private pass(): any {
    this.profileShow = {profile: this.profileActivationFlag};
    this.update.emit(this.profileShow);
    this.headerservicesService.ProfileActivationChange(true);
  }
  private removeSignin() {
   $('#loaderPage').css('display', 'block');
  }
  private openSignin() {
   $('#loaderPage').css('display', 'none');
  }

  private callReload() {
      $('#SignIncomponent').css('visibility', 'hidden');
      $('#loaderPage').css('display', 'block');
      this.localstorage.setItem('googletag', 'false');
      this.changeRoute();
  }
  private changeprofile(reg) {
     this.profileFlag = reg.p1;
     // this.signInComponentFlag = reg.p2;
  }
  private showScreen(token, method) {          // GDPR screen
    this.callRegisterComponentFlag = false;
    this.internationalGdprFlag = true;
    this.triggerClick();
    this.socialFlag = true;
    this.socialType = method;
    this.loginFrom = 'login';     // to differentate register r login
    this.sendToken = token;
  }
  private changeRoute(): any {
    let postRoute;
    this.previousUrl = this.localstorage.getItem('previousRoute');
    postRoute = this.localstorage.getItem('postSubscriptionRoute');
    if (this.previousUrl !== '/myaccount/subscription' && postRoute) {
      this.localstorage.removeItem('postSubscriptionRoute');
      this.commonService.getPostSubscriptionRoute(postRoute, 'login');
    }  else if (this.localstorage.getItem('token') && this.localstorage.getItem('nowTV') && this.localstorage.getItem('nowTV') === 'true') {
        this.router.navigate(['/device']);
        this.localstorage.removeItem('nowTV');
    } else {
      location.href = this.window.location.origin + this.previousUrl;
    }
  }
  private confirmationPage(type, token) {
    this.localstorage.setItem('googletag', 'false');
    this.callRegisterComponentFlag = false;
    this.headerservicesService.RegisterSuccessChange(true);
    this.profileFlag = true;
    this.profileActivationFlag = true;
    $('#body').addClass('scrolldisbale');
    this.internationalGdprFlag = false;
    $('#headerLogo').css('display', 'none');
    this.pass();
    $('#loaderPage').css('display', 'none');
  }
  private SettingapiFails() {
    $('#loaderPage').css('display', 'none');
    this.error_message  = 'MESSAGES.TRY_LATER';
    this.callToast();
    this.internationalGdprFlag = false;
    this.headerservicesService.registerMobilechange(false);
    this.headerservicesService.bgImageValueChange(true);
    this.headerservicesService.signinDetailsChange(true);
    this.headerservicesService.signinRightTopChange(true);
    this.headerservicesService.signinLeftChange(true);
    let scope;
    scope = this;
    setTimeout(function() { scope.callReload(); }, 2500);
  }
  private getSocialUserDetails(token, method): any {
    let userDetails;
     userDetails = new UserApi(this.http, null, this.config);
     userDetails.v1UserGet().timeout(environment.timeOut).subscribe(value => {
     this.userData = value;
     this.localstorage.setItem('ID', this.userData.id);
      if (value.additional.gdpr_policy) {
         for (let j = 0; j < value.additional.gdpr_policy.length; j++) {
           if (this.countrycode === value.additional.gdpr_policy[j].country_code) {
               let gdprValue;
               gdprValue = [{'country_code': this.countrycode,
                   'gdpr_fields': {
                         'policy': value.additional.gdpr_policy[j].gdpr_fields.policy,
                         'profiling': value.additional.gdpr_policy[j].gdpr_fields.profiling,
                         'age': value.additional.gdpr_policy[j].gdpr_fields.age,
                         'subscription': value.additional.gdpr_policy[j].gdpr_fields.subscription
                    }}];
               const gdpr_settings = {
                   'key': 'gdpr_policy',
                   'value': JSON.stringify(gdprValue)
               };
               this.userSettings.v1SettingsPost(gdpr_settings).subscribe(responsePost => {
                 this.updateGMID(token, method);
               }, err => {
                 this.SettingapiFails();
                 });
           } else {
               this.showScreen(token, method);
           }
         }
      } else if (value.additional.gdpr_policy === undefined) { // GDPR post request no node
        this.showScreen(token, method);
      }
     }, err => {
        this.gtm.sendErrorEvent('api', err);
        if (err.name === 'TimeoutError') {
          this.error_message = 'MESSAGES.TRY_LATER';
          this.callToast();
        } else {
          this.errors = err.json();
          this.error_message = this.errors.message;
          this.callToast();
        }
    });
  }
  private setFirstTimeloginSocial(first_time_value, token, method) {
    let first_time_settings;
    first_time_settings = {
      key: 'first_time_login',
      value: first_time_value
    };
    this.userSettings.v1SettingsPost(first_time_settings).subscribe(responsePost => {
      this.localstorage.setItem('login', method);
      this.localstorage.setItem('token', token);
      if (this.loginMethod === 'login') {
        this.callReload();
      } else {
        let userDetails;
        userDetails = new UserApi(this.http, null, this.config);
        userDetails.v1UserGet().timeout(environment.timeOut).subscribe(valueUser => {
            this.userId = valueUser.id;
          this.localstorage.setItem('ID', this.userId);
        });
        this.confirmationPage(method, token);
      }
    }, err => {
      this.errors = err.json();
      if (this.errors.message === 'Item already exists') {   // for already node there
       this.userSettings.v1SettingsPut(first_time_settings).subscribe(responsePost => {
       this.localstorage.setItem('login', method);
       this.localstorage.setItem('token', token);
       this.callReload();
      }, error => {
       this.localstorage.setItem('login', method);
       this.localstorage.setItem('token', token);
       this.callReload();
      });
      } else {
        this.localstorage.setItem('login', method);
       this.localstorage.setItem('token', token);
       this.callReload();
      }
    });
    this.checkSubSilentLogin();
  }

  private settingsFailsRegister(gdprsettings, type, token, method): any {
      this.userSettings.v1SettingsPost(gdprsettings).subscribe(responsePost => {
        if (type !== 'register') {    // login just reload with update GA and QG
           this.updateGMID(token, method);
        } else {                      // check for promotional
            let disp, valuecountryCode;
              disp = this.localstorage.getItem('display_language');
               valuecountryCode = this.settingsService.getCountryValueNew();
                if (valuecountryCode && valuecountryCode.length > 0) {
                   this.promotional = valuecountryCode[0].promotional;
                   this.countryToken = this.promotional.token;
                    if (this.promotional && this.promotional.on === '1') {
                       this.promotionalAPIcallSocial(token, method);
                    } else if (this.promotional && this.promotional.on === '0') {
                       this.setFirstTimeloginSocial('1', token, method);
                    }
                }
         }
      }, err => {
       this.SettingapiFails();
      });
  }
  private updatePromotionSocial(value, token, method) {
    this.userData = value;
    if (this.userData === undefined || this.userData.length === 0) {
      let userDetails;
      userDetails = new UserApi(this.http, null, this.config);
      userDetails.v1UserGet().timeout(environment.timeOut).subscribe(uservalue => {
        this.userData = uservalue;
        if ( this.settingsResponse.length > 0) {
          for (let i = 0; i < this.settingsResponse.length; i++) {
            if ( this.settingsResponse[i].key === 'first_time_login') {
              if (this.settingsResponse[i].value === '1') {
                 this.localstorage.setItem('login', method);
                 this.localstorage.setItem('token', token);
                this.callReload();
              } else if (this.settingsResponse[i].value === '0') {
                   let disp, valuecountryCode;
                  disp = this.localstorage.getItem('display_language');
                  valuecountryCode = this.settingsService.getCountryValueNew();
                  if (valuecountryCode && valuecountryCode.length > 0) {
                    this.promotional = valuecountryCode[0].promotional;
                    this.countryToken = this.promotional.token;
                    if (this.promotional && this.promotional.on === '1') {
                      this.promotionalAPIcallSocial(token, method);
                    } else if (this.promotional && this.promotional.on === '0') {
                        this.setFirstTimeloginSocial('1', token, method);
                    }
                  }
              }
            } else if (i === this.settingsResponse.length - 1) {
                if (this.userData.additional.first_time_login) {
                  if (this.userData.additional.promotional && this.userData.additional.promotional.on === '1') {
                    this.promotionalAPIcallSocial(token, method);
                  } else if (this.userData.additional.promotional && this.userData.additional.promotional.on === '0') {
                     this.setFirstTimeloginSocial('1', token, method);
                  } else {
                    this.setFirstTimeloginSocial('1', token, method);
                  }
                } else {
                      this.setFirstTimeloginSocial('1', token, method);
                    }
             }
          }
        }
      }, err => {
        this.openSignin();
        this.error_message = 'MESSAGES.TRY_LATER';
        this.callToast();
      });
    } else if (this.userData) {
      if ( this.settingsResponse.length > 0) {
        for (let i = 0; i < this.settingsResponse.length; i++) {
          if ( this.settingsResponse[i].key === 'first_time_login') {
                 this.localstorage.setItem('login', method);
                 this.localstorage.setItem('token', token);
                 this.callReload();
          } else if (i === this.settingsResponse.length - 1) {
                if (this.userData.additional.first_time_login) {
                  if (this.userData.additional.promotional && this.userData.additional.promotional.on === '1') {
                      this.promotionalAPIcallSocial(token, method);
                  } else if (this.userData.additional.promotional && this.userData.additional.promotional.on === '0') {
                    this.setFirstTimeloginSocial('1', token, method);
                  } else {
                    this.setFirstTimeloginSocial('1', token, method);
                  }
                } else {
                    this.setFirstTimeloginSocial('1', token, method);
                }
          }
        }
      } else if (this.userData.additional.first_time_login) {
        if (this.userData.additional.promotional && this.userData.additional.promotional.on === '1') {
          this.promotionalAPIcallSocial(token, method);
        } else if (this.userData.additional.promotional && this.userData.additional.promotional.on === '0') {
          this.setFirstTimeloginSocial('1', token, method);
        } else {
          this.setFirstTimeloginSocial('1', token, method);
        }
      } else {
        this.setFirstTimeloginSocial('1', token, method);
      }
    }
  }

  private updateGMID(userId, method) {
    this.CommonConfigCall(userId);
    let userDetails;
    userDetails = new userApi.UserApi(this.http, null, this.config);
    userDetails.v1UserGet().timeout(environment.timeOut).subscribe(value => {
      this.userId = value.id;
      this.localstorage.setItem('ID', this.userId);
      if (method === 'facebook') {
        this.qgraphevent('Signin_Success', {'method': 'social_fb', 'country' : this.countrycode});
        this.GAUpdateCommon('LoginSuccess', 'facebook', '');
      }
      if (method === 'google') {
        this.qgraphevent('Signin_Success', {'method': 'social_google', 'country' : this.countrycode});
        this.GAUpdateCommon('LoginSuccess', 'googleplus', '');
      }
      this.updatePromotionSocial(value, userId, method);
    }, err => {
        this.userId = 'NA';
        this.callReload();
        this.gtm.sendErrorEvent('api', err);
    });
  }

  private checkGdprNode(token, method): any {
    if (token) {
      this.CommonConfigCall(token);
      this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
          this.userSettings.v1SettingsGet().subscribe( response => {
         this.settingsResponse = response;
         this.cookieConcent(this.settingsResponse);
          let gdpr_Flag;
          if ( response.length > 0) {
            for (let i = 0; i < response.length; i++) {
              if ( response[i].key === 'gdpr_policy') {
                gdpr_Flag = true;
                 if (!(response[i].value[0] === '{')) {
                  this.gdprValue = JSON.parse(response[i].value);
                  let flagcheck = false;
                  for (let j = 0; j < this.gdprValue.length; j++) {
                   if (this.countrycode === this.gdprValue[j].country_code) {
                    flagcheck = true;
                    break;
                   } else if (j === this.gdprValue.length - 1) {   // no country code match so show GDPR screen with put request
                      flagcheck = false;
                    }
                   }
                   if (flagcheck) {
                     this.updateGMID(token, method);
                   } else {
                    this.gdprCountryChange = true;
                    this.showScreen(token, method);
                   }
                  } else {
                      this.userSettings.v1SettingsDelete('gdpr_policy', token).subscribe(responseput => {
                      this.showScreen(token, method);
                    });
                  }
              }
            }
            if (gdpr_Flag === undefined) {
              this.getSocialUserDetails(token, method);
            }
          } else {
            if (gdpr_Flag === undefined) {
              this.getSocialUserDetails(token, method);
            }
          }

        }, err => {
             this.openSignin();
            this.error_message = 'MESSAGES.TRY_LATER';
            this.callToast();
         });
    }
  }
  private updateSettingApi(token, method, type): any {
    if (token) {
      let params;
      params = 'bearer ' + token ;
      this.config = {
          apiKey: params,
          username: '',
          password: '',
          accessToken: '',
          withCredentials: false
      };
    }
    let policyValues;
    policyValues = [];
    for (let i = 0; i < 4; i++) {
        if (!(this.receivedValue.sendValues[i].status) || this.receivedValue.sendValues[i].status === undefined) {
            policyValues[i] = 'na';
        } else if (!(this.receivedValue.sendValues[i].userValue)) {
            policyValues[i] = 'no';
        } else if (this.receivedValue.sendValues[i].userValue === true) {
           policyValues[i] = 'yes';
        }
    }
    if (!this.gdprCountryChange) { // register
    let gdprValue, gdprsettings;
      gdprValue = [{
              'country_code': this.countrycode,
              'gdpr_fields': {
                  'policy': policyValues[0],
                  'profiling': policyValues[1],
                  'age': policyValues[2],
                  'subscription': policyValues[3]
                   }
              }];
    gdprsettings = {
              'key': 'gdpr_policy',
              'value': JSON.stringify(gdprValue)
           };
    this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
      this.userSettings.v1SettingsPost(gdprsettings).subscribe(responsePost => {
         if (type !== 'register') {
           this.updateGMID(token, method);
         } else {
          let disp, valuecountryCode;
            disp = this.localstorage.getItem('display_language');
              valuecountryCode = this.settingsService.getCountryValueNew();
             if (valuecountryCode && valuecountryCode.length > 0) {
                this.promotional = valuecountryCode[0].promotional;
                this.countryToken = this.promotional.token;
                if (this.promotional && this.promotional.on === '1') {
                  this.promotionalAPIcallSocial(token, method);
                } else if (this.promotional && this.promotional.on === '0') {
                  this.setFirstTimeloginSocial('1', token, method);
                }
              }
        }
      }, err => {
         // this.SettingapiFails();
          this.settingsFailsRegister(gdprsettings, type, token, method);
        });
    } else {      // login
         let gdprValue1, gdprsettings;
          gdprValue1 = {
                  'country_code': this.countrycode,
                  'gdpr_fields': {
                    'policy': policyValues[0],
                    'profiling': policyValues[1],
                    'age': policyValues[2],
                    'subscription': policyValues[3]
                  }
          };
          this.gdprValue.push(gdprValue1);
          gdprsettings = {
              'key': 'gdpr_policy',
              'value': JSON.stringify(this.gdprValue)
           };
          this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
          this.userSettings.v1SettingsPut(gdprsettings).subscribe(responsePost => {
          this.updateGMID(token, method);
        }, err => {
             this.openSignin();
             this.errorMessage = 'MESSAGES.TRY_LATER';
             this.callToast();
        });
    }
    if (type === 'register') {
     this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
      this.userSettings.v1SettingsGet().subscribe( response => {
        this.settingsResponse = response;
         this.cookieConcent(this.settingsResponse);
      }, err => {
           // todo
      });
    }
  }

  private createObject(accessToken): any {
    let policyValues, googleObjInt, country_Promotion;
    country_Promotion = this.settingsService.getCountryPromotionalValue();
    policyValues = [];
    for (let i = 0; i < 4; i++) {
        if (!(this.receivedValue.sendValues[i].status) || this.receivedValue.sendValues[i].status === undefined) {
            policyValues[i] = 'na';
        } else if (!(this.receivedValue.sendValues[i].userValue)) {
            policyValues[i] = 'no';
        } else if (this.receivedValue.sendValues[i].userValue === true) {
           policyValues[i] = 'yes';
        }
    }
    googleObjInt = {
       'token' : accessToken,
       'mac_address': '',
       'ip_address': '',
       'registration_country': '',
       'additional': {
          'gdpr_policy': [{
            'country_code': this.countrycode,
            'gdpr_fields': {
              'policy': policyValues[0],
              'profiling': policyValues[1],
              'age': policyValues[2],
              'subscription': policyValues[3]
            }
          }],
         'guest_token': this.guest_token,
         'sourceapp' : 'Web',
         'version_number' : this.version_number,
         'promotional': {
           'on': country_Promotion.on,
           'token': country_Promotion.token
          },
          'first_time_login': '1',
          'platform': 'Web',
          'version': this.window.appVersion
        }
      };
      this.googleObj = this.checkUpdateCampaign(googleObjInt);
      // this.googleObj = this.gtm.checkUpdateCampaign(googleObjInt);
  }

  private checkUpdateCampaign(googleObjInt): any {
    if (this.nowTV) {
      // let checkCamVal, appendData, sendData, sendAdd, addDetails, sendPost;
      let checkCamVal;
      checkCamVal = this.commonService.nowtv.nowTvDetails;
      // addDetails = googleObjInt.additional;
      if (checkCamVal !== undefined && checkCamVal !== null) {
        // appendData = {
        //   'campaign' : checkCamVal.campaignData
        // };
        // sendData = $.extend({}, addDetails, appendData);
        // sendAdd = {
        //   'additional' : sendData
        // };
        // sendPost = $.extend({}, googleObjInt, sendAdd);
        // sendPost = $.extend({}, googleObjInt, checkCamVal.campaignData);
        // return sendPost;
        googleObjInt.additional = {...googleObjInt.additional, ...checkCamVal.campaignData};
        return googleObjInt;
      } else {
        return googleObjInt;
      }
    } else {
      return this.gtm.checkUpdateCampaign(googleObjInt);
    }
  }

  private promotionalAPIcallSocial(token, method) {
    let promotionalData, language, tokenType;
    tokenType = this.localstorage.getItem('token');
      if (tokenType) {
        language = localStorage.getItem('UserDisplaylanguage');
      } else {
        language = localStorage.getItem('display_language');
      }
    promotionalData = {
      'createPromo' : { 'token' : this.countryToken},
      'translation' : language
    };
    this.userAction.postPromotionalData(promotionalData, token).subscribe(value => {
        let promoDesc;
        if (value && value.subscription_plan && value.subscription_plan.description) {
          promoDesc = value.json().subscription_plan.description;
        }
        localStorage.setItem('promotionalDesc', promoDesc);
        this.localstorage.setItem('dialogCheck', 'true');
        /*Set settings first-time-login = 1*/
        this.setFirstTimeloginSocial('1', token, method);
       }, err => {
          if (err.status === 404 || err.status === 400) {
            /*Set settings first-time-login = 1*/
          this.setFirstTimeloginSocial('1', token, method);
          } else {
            /*Set settings first-time-login = 0*/
          this.setFirstTimeloginSocial('0', token, method);
          }
      });
  }

  private checkSubSilentLogin(): any {
    let recVal, sendVal;
    recVal = this.localstorage.getItem('subSilentLogin');
    if (recVal) {
      sendVal = {
        'subValue' : true,
        'loginValue' : true
      };
      this.localstorage.setItem('subSilentLogin', JSON.stringify(sendVal));
    }
  }
  private CommonConfigCall(token) {
    let params;
         params = 'bearer ' + token ;
        this.config = {
           apiKey: params,
           username: '',
           password: '',
           accessToken: '',
           withCredentials: false
         };
 }
  private cookieConcent(settingValue) {
    if (this.cookiesLocal === null || undefined) {
      this.cookiesLocal = 'na';
    }
    if (this.marketingLocal === null || undefined) {
      this.marketingLocal = 'na';
    }
    let popup, popupValue, oldCookie, oldRTRM;
    if ( settingValue.length > 0) {
      for (let i = 0; i < settingValue.length; i++) {
        if ( settingValue[i].key === 'popups') {
          popup = true;
          this.responsevalue = JSON.parse(settingValue[i].value);
          oldCookie = this.responsevalue[0].Cookies;
           oldRTRM = this.responsevalue[0].RTRM;
           if (this.responsevalue[0].Cookies === 'na' && this.responsevalue[0].RTRM === 'na' ) {
            popupValue = [{'Cookies': this.cookiesLocal, 'RTRM': this.marketingLocal}];
            const cookies_settings = {
              'key': 'popups',
              'value': JSON.stringify(popupValue)
            };
            this.userSettings.v1SettingsPut(cookies_settings).subscribe(responseput => {
              // todo
            });
           } else if (this.responsevalue[0].RTRM === 'na' || this.responsevalue[0].Cookies === 'na') {
            if (this.responsevalue[0].RTRM === 'na') {
              popupValue = [{'Cookies': oldCookie, 'RTRM': this.marketingLocal}];
            }
            if (this.responsevalue[0].Cookies === 'na') {
              popupValue = [{'Cookies': this.cookiesLocal, 'RTRM': oldRTRM}];
            }
            const cookies_settings = {
            'key': 'popups',
            'value': JSON.stringify(popupValue)
            };
            this.userSettings.v1SettingsPut(cookies_settings).subscribe(responseput => {
              // todo
            });
          }

        }
      }
      if (popup === undefined) {
        let popupValue1;
        popupValue1 = [{'Cookies': this.cookiesLocal, 'RTRM': this.marketingLocal}];
        const cookies_settings = {
          'key': 'popups',
          'value': JSON.stringify(popupValue1)
        };
        this.userSettings.v1SettingsPost(cookies_settings).subscribe(responsePost => {
        // todo
        });
        // post
      }
    } else {
      let popupValue2;
        popupValue2 = [{'Cookies': this.cookiesLocal, 'RTRM': this.marketingLocal}];
        const cookies_settings = {
        'key': 'popups',
        'value': JSON.stringify(popupValue2)
        };
       this.userSettings.v1SettingsPost(cookies_settings).subscribe(responsePost => {
         // todo
       });
    }

  }
   private AcceptEnable() {
  if (!(this.receivedValue.sendFlag)) {
        $('.AcceptLogin').css({'background-color': '#50012f', 'color': '#703055'});
        return true;
      } else {
         $('.AcceptLogin').css({'background-color': '#bf006b', 'color': '#eeeeee'});
        return false;
    }
}
 ////////////////////// login with social network end////////////////
  public ngOnDestroy() {
    this.document.getElementById('body').classList.remove('modal-open');
  }
  private triggerClick() {
    let el: HTMLElement = this.loaderPage.nativeElement as HTMLElement;
    el.click();
}

}
