import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CookiesCheckPopupComponent } from './cookies-check-popup.component';

describe('CookiesCheckPopupComponent', () => {
  let component: CookiesCheckPopupComponent;
  let fixture: ComponentFixture<CookiesCheckPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CookiesCheckPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CookiesCheckPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
