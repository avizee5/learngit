import { Component, OnInit, OnDestroy } from '@angular/core';
import * as $ from 'jquery';
import { isPlatformBrowser } from '@angular/common';
import { Inject, PLATFORM_ID } from '@angular/core';
import { HeaderservicesService } from '../services/headerservices.service';
import { Subscription } from 'rxjs/Subscription';
import { Router , NavigationEnd , ActivatedRoute  } from '@angular/router';
import { TranslateService} from '@ngx-translate/core';
import { SettingsService } from '../services/settings.service';
import { Http } from '@angular/http';
import * as SettingsApi from '../../data/user/api/api';
import {environment} from '../../environments/environment';

@Component({
  selector: 'app-cookies-check-popup',
  templateUrl: './cookies-check-popup.component.html',
  styleUrls: ['./cookies-check-popup.component.less']
})
export class CookiesCheckPopupComponent implements OnInit, OnDestroy {
	private localStorage: any;
	public popUpVisible: any;
  public cookies: boolean;
  public block = true;
  public marketing = true;
  public cookieDisplay = true;
  private gdprShow: any;
  private line1: any;
  private getValue: any;
  private getValue1: any;
  private getValue2: any;
  private line2: any;
  private userToken: any;
  private countrycode: any;
  private cookiesLocal: any;
  private marketingLocal: any;
  private userSettings: any;
  private config: any;
  private responsevalue: any;
  public arrowImage_url: any;
  private assetbasepath: any;
  private language: any;
  public userDisplaylang: any;
  public guestDisplaylang: any;
  constructor(private translate: TranslateService, @Inject(PLATFORM_ID) private platformId: Object, private settingsService: SettingsService, private headerservicesService: HeaderservicesService, private router: Router, private http: Http) {
  	if (isPlatformBrowser(this.platformId)) {
      this.localStorage = localStorage;
    }
  }
  public ngOnInit() {
    $('#body').addClass('scrolldisbale');
    this.assetbasepath = environment.assetsBasePath;
    this.userToken = this.localStorage.getItem('token');
    this.countrycode = this.settingsService.getCountry();
    this.popUpVisible = this.headerservicesService.getCookiesCheckValueChange();
    this.cookies = this.headerservicesService.getCookieValueChange();
    this.marketing = this.headerservicesService.getMarketValue();
    this.cookieDisplay = this.headerservicesService.getCookiesDisplay();
    this.block = this.headerservicesService.getBlockValue();
    this.getValue = this.settingsService.getCountryValueNew();
    this.arrowImage_url = this.assetbasepath + 'assets/common/arrow-icon.png';
    this.userDisplaylang = this.localStorage.getItem('UserDisplayLanguage');
    this.guestDisplaylang = this.localStorage.getItem('display_language');
    if (this.getValue.length > 0) {
      if (this.getValue['0'].popups) {
        this.getValue1 = this.getValue['0'].popups.web_cookies.content;
        this.getValue2 =  this.getValue['0'].popups.web_remarketing.content;
      }
    }
    let scope;
    scope = this;
     $('.loaderImage').css('display', 'none');
      $(document).ready(function() {
       setTimeout(() => {
        if (scope.cookies === false) {
         scope.setString(scope.getValue2);
        } else {
           scope.setString(scope.getValue1);
        }
     }, 500);
   });
   this.cookiesUpdate();
  }

    private setString(value): void {
    this.language = this.userToken ? this.userDisplaylang : this.guestDisplaylang;
   
    if (this.language === null || this.language === 'null') {
      this.language = 'en';
    }
    if (this.language === 'en') {
      this.language = '';
    }
      if (this.cookies === false) {       // only for remarketing
        this.line2 = value;
        this.line2 = this.line2.replace('<p>', '');
        $('.remarketing').append('<div style="font-size:12px;margin-bottom: 30px;">' +  this.line2 + '</div>');
      } else {
      this.line1 = value;
      this.line1 = this.line1.replace('<p>', '');
      this.line1 = this.line1.replace('<br><br>', '');

      this.line1 =  this.line1.replace('<a href=\'##cookies##\'>', '<a style="color:#bf006b;font-size:12px;" href="' + this.language + '/cookiePolicy" target="_blank">');
      $('.cookie').append('<div style="font-size:12px;display:inherit;margin-bottom: 30px;">' +  this.line1 + '</div>');
      }
  }

private cookiesUpdate() {
  if (this.marketing === true) {   // if marketing not thr close popup without next screen
    this.cookies = false;
    setTimeout(() => {
      this.setString(this.getValue2);
    }, 1);
   this.MarketingUpdate()

  } else {
    this.popUpVisible = false;
    this.localStorage.setItem('cookies', true);
    this.headerservicesService.CookiesCheckValueChange(false); // to close popup
    this.gdprShow = this.localStorage.getItem('gdpr');         // to display gdpr screen after close
    if (this.gdprShow === 'true') {
       this.headerservicesService.cookiesScreen(true);
       this.localStorage.removeItem('gdpr');
     }
    $('#body').removeClass('scrolldisbale');
   this.updateSetting();
  }
  this.localStorage.setItem('cookies', true);
}
private MarketingUpdate() {
  this.gdprShow = this.localStorage.getItem('gdpr');
  this.popUpVisible = false;
  this.headerservicesService.CookiesCheckValueChange(false);
   if (this.gdprShow === 'true') {
     this.headerservicesService.cookiesScreen(true);
     this.localStorage.removeItem('gdpr');
   }
  this.localStorage.setItem('marketing', true);
  this.headerservicesService.RTRMTrack('true');
  $('#body').removeClass('scrolldisbale');
    this.updateSetting();
}
private dontAgree() {
  this.popUpVisible = false;
  this.headerservicesService.CookiesCheckValueChange(false);
  this.localStorage.setItem('marketing', false);
  this.headerservicesService.RTRMTrack('false');
  $('#body').removeClass('scrolldisbale');
  this.updateSetting();
}
private updateSetting() {
  this.cookiesLocal = this.localStorage.getItem('cookies');
  this.marketingLocal = this.localStorage.getItem('marketing');
  if (this.userToken !== null || undefined) {
    this.CommonConfigCall(this.userToken);
    this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
    this.userSettings.v1SettingsGet().subscribe( response => {
      let settingValue;
      settingValue = response;
      if (this.cookiesLocal === null || undefined) {
        this.cookiesLocal = 'na';
      }
      if (this.marketingLocal === null || undefined) {
        this.marketingLocal = 'na';
      }
      if ( settingValue.length > 0) {
        let popup, popupValue, oldCookie, oldRTRM;
        for (let i = 0; i < settingValue.length; i++) {
          if ( settingValue[i].key === 'popups') {
            popup = true;
            this.responsevalue = JSON.parse(settingValue[i].value);
             oldCookie = this.responsevalue[0].Cookies;
             oldRTRM = this.responsevalue[0].RTRM;
            if (this.responsevalue[0].Cookies === 'na' && this.responsevalue[0].RTRM === 'na' ) {
                popupValue = [{'Cookies': this.cookiesLocal, 'RTRM': this.marketingLocal}];
               const cookies_settings = {
               'key': 'popups',
               'value': JSON.stringify(popupValue)
               };
               this.userSettings.v1SettingsPut(cookies_settings).subscribe(responseput => {
                 // todo
               });
            } else if (this.responsevalue[0].RTRM === 'na' || this.responsevalue[0].Cookies === 'na') {
              if (this.responsevalue[0].RTRM === 'na') {
                 popupValue = [{'Cookies': oldCookie, 'RTRM': this.marketingLocal}];
              }
              if (this.responsevalue[0].Cookies === 'na') {
                 popupValue = [{'Cookies': this.cookiesLocal, 'RTRM': oldRTRM}];
              }
               const cookies_settings = {
               'key': 'popups',
               'value': JSON.stringify(popupValue)
               };
               this.userSettings.v1SettingsPut(cookies_settings).subscribe(responseput => {
                 // todo
               });
            }
          }
        }
        if (popup === undefined) {
           let popupValuePost: any;
           popupValuePost = [{'Cookies': this.cookiesLocal, 'RTRM': this.marketingLocal}];
           const cookies_settings = {
           'key': 'popups',
           'value': JSON.stringify(popupValuePost)
           };
          this.userSettings.v1SettingsPost(cookies_settings).subscribe(responsePost => {
            // todo
          });
          // post
        }
      } else {
           let popupValueSecond: any;
           popupValueSecond = [{'Cookies': this.cookiesLocal, 'RTRM': this.marketingLocal}];
           const cookies_settings = {
           'key': 'popups',
           'value': JSON.stringify(popupValueSecond)
           };
          this.userSettings.v1SettingsPost(cookies_settings).subscribe(responsePost => {
            // todo
          });
        }
    }, err => {
      // todo
    });
  }
}
private CommonConfigCall(token) {
   let params;
        params = 'bearer ' + token ;
       this.config = {
          apiKey: params,
          username: '',
          password: '',
          accessToken: '',
          withCredentials: false
        };
}
   public ngOnDestroy(): void {
    $('#body').removeClass('scrolldisbale');
  }
}
