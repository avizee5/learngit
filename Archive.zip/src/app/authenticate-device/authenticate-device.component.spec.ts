import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AuthenticateDeviceComponent } from './authenticate-device.component';

describe('AuthenticateDeviceComponent', () => {
  let component: AuthenticateDeviceComponent;
  let fixture: ComponentFixture<AuthenticateDeviceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AuthenticateDeviceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AuthenticateDeviceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
