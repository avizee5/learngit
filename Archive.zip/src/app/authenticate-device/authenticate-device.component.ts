import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import {CommonService} from '../services/common.service';
import { Subscription } from 'rxjs/Subscription';
import { Subject } from 'rxjs/Subject';
import { Router, ActivatedRoute } from '@angular/router';
import { RouteService } from '../services/route.service';
import { environment } from '../../environments/environment';
import { HeaderservicesService } from '../services/headerservices.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import 'rxjs/add/operator/timeout';
import 'rxjs/add/operator/takeUntil';

const navigationTimeout = 2000; // milliseconds

@Component({
  selector: 'app-authenticate-device',
  templateUrl: './authenticate-device.component.html',
  styleUrls: ['./authenticate-device.component.less']
})
export class AuthenticateDeviceComponent implements OnInit {
	 public path = environment.deviceAuthentication;
	 private ngUnsubscribe = new Subject<any>();
	 public result;
	 public loginToken: boolean;
	 public localstorage;
	 public window;
	 public document;
	 public navigator;
   public authFlag = false;
   public router2;
   public router;
   public routerservice;
   public mobileEnable = false;
   public errorMsg;
   public imagesrc;
   public assetbasepath;
   public toastMsg = false;
   public loader = false;
   public authenticationCode: any;
   public authCode: any = '';

  constructor(@Inject(PLATFORM_ID) private platformId: Object, private commService: CommonService, private router_link: Router, private routeservice: RouteService, private headerservicesService: HeaderservicesService, private gtm: GoogleAnalyticsService, private route: ActivatedRoute, private navigateToRoute: Router) {
  	if (isPlatformBrowser(this.platformId)) {
      this.localstorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
      this.router = router_link;
      this.router2 = this.window.location.pathname;
      this.routeservice.setRoute(this.navigateToRoute.url);
      this.headerservicesService.viewChange(this.navigateToRoute.url);
      this.routeservice.setLoginRoute(this.navigateToRoute.url);
      $('#loaderPage').css('display', 'none');
      this.headerservicesService.breadCrump('');
  }

   public ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.authenticationCode  = params['device_code'];
      this.authCode =  this.authenticationCode ?  this.authenticationCode : '';
      this.authenticationCode ?  (this.authFlag = true) : (this.authFlag = false);
    });
  	this.loginToken = this.localstorage.getItem('token') ? true : false;
    this.assetbasepath = environment.assetsBasePath;
    this.imagesrc = this.assetbasepath + 'assets/common/auth_device.png';
  	// todo
  }
  // public onResize(event: any): void {
  //   console.log(this.window.innerWidth);
  //   //this.navigator.userAgent.match(/mobile|iPhone|iPod|iPad/i)
  //   if (this.window.innerWidth < 480) {
  //     this.mobileEnable = true;
  //   } else {
  //     this.mobileEnable = false;
  //   }
  // }
   public authenticateDevice(value) {
    this.authFlag = false;
    this.closeToastmsg();
    this.loader = true;
    this.gtm.sendEventDetails({'event': 'userIconClick', 'UserMenu': 'authenticate'});
    // if (this.authFlag) {
      this.commService.authDevice(this.path, value).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(res => {
      const succesMsg = res;
      this.result = succesMsg.message;
      this.toastMsg = true;
      this.loader = false;
      this.authFlag = true;
      let windowLocation;
      windowLocation = window.location;
      if (windowLocation.origin === environment.nowTvbasePath && this.result.indexOf('added successfully') !== -1) {
      // if (windowLocation.origin === environment.nowTvbasePath && succesMsg.code === 2000) {
        setTimeout(() => {
          this.router.navigate(['/']);
        }, navigationTimeout)
      }
      // this.callToast();
      }, err => {
          const errormsg = JSON.parse(err._body);
          this.result = errormsg.message;
          this.toastMsg = true;
          this.loader = false;        
          this.authFlag = true;
          // this.callToast();
      });
      if (localStorage.getItem('deviceAuthenticateCode')) {
        localStorage.removeItem('deviceAuthenticateCode');
      }
    // }
  }
   public highLightBtn() {
    const count = $('#authInputfield')[0].value.length;
    if (count === 6) {
      this.authFlag = true;
      //$('#authButton').css({'background-color': '#bf006b', 'color': '#eee', 'cursor': 'pointer'});
      //return true;

    } else {
      this.authFlag = false;
     // $('#authButton').css({'background-color': '#50012f', 'color': '#bcbcbc', 'cursor': 'default'});
      //return false;
    }
  }
  //  public checkLength() {
  //   const count = $('#authInputfield')[0].value.length;
  //   if (count === 6) {
  //     this.authFlag = true;
  //     return false;
  //   } else {
  //     this.authFlag = false;
  //     return true;
  //   }
  // }
  public focusOut() {
    $('#body').addClass('scrolldisbale');
  }
   public loginPageFunction() {
    this.router.navigate(['/signin']);
  }

  public closeToastmsg(){
    this.toastMsg = false;
  }
  public changeCode(){
    this.closeToastmsg();
  }
  //  private callToast() {
  //   let p;
  //   p = document.getElementById('snackbar_adult1');
  //   p.className = 'show';
  //   setTimeout(function() { p.className = p.className.replace('show', ''); }, 3000);
  // }
}



