import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChannelListGridComponent } from './channel-list-grid.component';

describe('ChannelListGridComponent', () => {
  let component: ChannelListGridComponent;
  let fixture: ComponentFixture<ChannelListGridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChannelListGridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChannelListGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
