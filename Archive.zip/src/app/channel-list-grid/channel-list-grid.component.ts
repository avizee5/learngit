import { Component, OnInit, Input } from '@angular/core';
import * as $ from 'jquery';
import { WindowRefService } from '../services/window-ref.service';
import { SettingsService } from '../services/settings.service';
import {environment} from '../../environments/environment';
import { Router } from '@angular/router';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { CommonService } from '../services/common.service';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';

@Component({
  selector: 'app-channel-list-grid',
  templateUrl: './channel-list-grid.component.html',
  styleUrls: ['./channel-list-grid.component.less']
})
export class ChannelListGridComponent implements OnInit {
private windowref: any;
@Input() public show: any;
@Input() public xIndex: any = 'NA';
public channel: any;
public image_url: string;
private basepath: string;
private url: any;
public assetbasepath: any;
public errorImage: any;
private localstorage: any;
private window: any;
private document: any;
private navigator: any;
  constructor(@Inject(PLATFORM_ID) private platformId: Object, private commonService: CommonService, private settingsService: SettingsService, private gtm: GoogleAnalyticsService, private windowRef: WindowRefService, private router: Router) {
  if (isPlatformBrowser(this.platformId)) {
          this.localstorage = localStorage;
          this.window = window;
          this.document = document;
          this.navigator = navigator;
      }
  this.windowref = windowRef.nativeWindow;
  this.assetbasepath = environment.assetsBasePath;
  this.url = this.assetbasepath + 'assets/default/channel_logo.png';
  this.errorImage = this.assetbasepath + 'assets/default/channel_logo.png';
}

 public ngOnInit() {
  this.gtm.storeWindowError();
  this.show.original_title = this.show.original_title.toLowerCase().replace(/ /g, '-');
  this.show.original_title = this.show.original_title.toLowerCase().replace(/--/g, '-');
  this.show.original_title = this.show.original_title.toLowerCase().replace(/---/g, '-');
  this.window.scrollTo(0, 0);
  $(this.window).scrollTop(0);
  this.show.original_title = this.show.original_title.toLowerCase().replace(/&/g, 'and');
  if (this.show.list_image !== null && this.show.id !== null && this.show.list_image !== '') {
 	this.basepath = this.settingsService.getbasePath();
	this.image_url = this.basepath + this.show.id + '/list/' + '170x170/' + this.show.list_image;
	this.Resize(this.window.innerWidth);
	let urlform;
	urlform = this.basepath + this.show.id + '/list/' + '170x170/' + this.show.list_image;
	let img1;
	img1 = new Image();
  img1.src = this.url;
  let scope;
  scope = this;
  let img2;
  img2 = new Image();
  img2.src = this.image_url;
  img2.onload = function() {
    scope.url = urlform;
    $('.channelImage').css('background', 'white');
  };
}
}
 public onResize(event) {
      if (event.target.innerWidth <= 620 && event.target.innerWidth > 520) {
	$( '.channelImage').css({'width': '140px', 'height' : '140px'});
	} else if (event.target.innerWidth <= 1400 && event.target.innerWidth > 620) {
	$( '.channelImage').css({'width': '165px' , 'height' : '165px'});
	 } else if (event.target.innerWidth <= 1750 && event.target.innerWidth > 1401) {
	$( '.channelImage').css({'width': '135px' , 'height' : '135px'});
	} else if (event.target.innerWidth <= 520 && event.target.innerWidth > 481) {
	$( '.channelImage').css({'width': '125px', 'height' : '125px'});
	} else if (event.target.innerWidth <= 389 && event.target.innerWidth > 328) {
	$( '.channelImage').css({'width': '125px', 'height' : '125px'});
	} else if (event.target.innerWidth <= 480 && event.target.innerWidth > 390) {
	$( '.channelImage').css({'width': '165px', 'height' : '165px'});
	} else if (event.target.innerWidth <= 327 && event.target.innerWidth > 100) {
	$( '.channelImage').css({'width': '120px', 'height' : '120px'});
	} else if (event.target.innerWidth > 1751) {
	$( '.channelImage').css({'width': '165px' , 'height' : '165px'});
	}

}
public Resize(event) {
    if (event <= 620 && event > 520) {
	$( '.channelImage').css({'width': '140px', 'height' : '140px'});
	} else if (event <= 1300 && event > 620) {
	$( '.channelImage').css({'width': '165px', 'height' : '165px'});
	} else if (event <= 520 && event > 481) {
	$( '.channelImage').css({'width': '125px', 'height' : '125px'});
	} else if (event <= 327 && event > 100) {
	$( '.channelImage').css({'width': '120px', 'height' : '120px'});
	} else if (event <= 1750 && event > 1401) {
	$( '.channelImage').css({'width': '135px' , 'height' : '135px'});
	} else if (event > 1751) {
	$( '.channelImage').css({'width': '165px' , 'height' : '165px'});
	}
}

public callChannel(name, id): any {
	let gAtitle, yIndex;
	yIndex = 0;
	gAtitle = 'Channels';
	this.gtm.GAsubCategory = gAtitle;
	this.gtm.setContentClickDetails(this.xIndex, yIndex, gAtitle);
	this.commonService.updateCollectionId(null);
	this.commonService.setTalamoosData('', '', '');
	this.router.navigate(['/channels/details', name , id ]);
}

}


