import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { Http} from '@angular/http';
import {SearchApi} from '../../data/catalog/api/SearchApi';
import { Location } from '@angular/common';
import { VideoService } from '../services/video.service';
import * as $ from 'jquery';
import { RouteService } from '../services/route.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import {  NetworkService  } from '../services/network.service';
import { UserProfileService } from '../services/user-profile.service';
import { environment } from '../../environments/environment';
import { HeaderservicesService } from '../services/headerservices.service';
import {CommonService} from '../services/common.service';
import { Subject } from 'rxjs/Subject';
import { EpgService } from '../services/epg.service';
import {EpgApi} from '../../data/catalog/api/EpgApi';
import { SeoService } from '../services/seo.service';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { SettingsService } from '../services/settings.service';
import { FilterService } from '../services/filter.service';

@Component({
	selector: 'app-search-results-screen',
	templateUrl: './search-results-screen.component.html',
	styleUrls: ['./search-results-screen.component.less']
})
export class SearchResultsScreenComponent implements OnInit, OnDestroy {
	private searchResults: any;
	private totalResults = 0;
	private modalVideoPopup = false;
	private modalVideoDetails: any;
	private id: any;
	private name: any;
	private watch: any;
	private sub: any;
	private urlString: any;
	private data: any;
	private tvShowList: any = {content: [], 'total' : 0};
	private moviesList: any = {content: [], 'total':  0};
	private episodeList: any = {content: [], 'total': 0};
	private epgList: any;
	public dataAvailable: any = true;
	private query: any;
	private router2: any;
	private pageName: any;
	private pageNumber: any = 1;
	private pageSize: any = 24;
	private totalPages: any;
	private tvshowpagenumber: any = 1;
	private epgpagenumber: any = 1;
	private moviepagenumber: any = 1;
	private tvshowPages: any;
	private moviesPages: any;
	private episodePages: any;
    private epgPages: any;
	private epgPageSize: any = 100;
	private contentAvailable: any = true;
	private serverTime: any;
	private config: any;
	private epgContent: any;
	private currentTime: any;
	private count: any = 0;
	private localstorage: any;
	private window: any;
	private document: any;
	private navigator: any;
	private countryCode: any;
	private translation: any;
	private content: any;
	private assetList: any;
	private menuTabs: any;
	private previousTab: any = 0;
	private touchScreen: any;
	private processPending: any = false;
	private allShowList: any = {content: [], 'total': 0};
	private totalPagesArray: any = [0, 0, 0];
	private pageArray: any = [1, 1, 1];
	private typeArray: any = ['all', 'show_episode', 'movies'];
	private assetBasePath = environment.assetsBasePath;
	private convivaDataShow: any;
	private convivaData: any = {'content': []};
	private convivaPage: any = 1;
	private convivaTotalPages: any;
	private ngUnsubscribe = new Subject<any>();
	private desktop: any = true;
	private allEpisodeList: any;
	private initial_limit = 0;
	constructor (private filterService: FilterService, private settingsService: SettingsService, @Inject(PLATFORM_ID) private platformId: Object, private seoService: SeoService, private epgService: EpgService, private commonService: CommonService, private userProfileService: UserProfileService, private networkService: NetworkService, private gtm: GoogleAnalyticsService,
		private routeservice: RouteService , private videoService: VideoService, private location: Location, private route: ActivatedRoute ,  private router: Router,  private http: Http, private headerservicesService: HeaderservicesService) {
		if (isPlatformBrowser(this.platformId)) {
			this.localstorage = localStorage;
			this.window = window;
			this.document = document;
			this.navigator = navigator;
		}
		this.router2 = this.window.location.pathname;
		this.router2 =  this.router2.slice(3);
		this.routeservice.setRoute(this.router2);
		this.headerservicesService.viewChange(this.router2);
		this.routeservice.setLoginRoute(this.router.url);
	}

	public ngOnInit() {
		this.commonService.updateTime();
		if (isPlatformBrowser(this.platformId)) {
			this.localstorage = localStorage;
			this.window = window;
			this.document = document;
			this.navigator = navigator;
		}
		if (!this.translation) {
			this.translation = 'en';
		}
		$('#breadcrumInit').css('display', 'none');
		this.countryCode = this.settingsService.getCountry();
		this.window.scrollTo (0, 0);
		this.gtm.storeWindowError();
		this.seoService.updateStaticMeta({url: '/'});
		let network;
		network = this.networkService.getScreenStatus();
		if (network) {
			let token;
			token = this.localstorage.getItem('token');
			if (token) {
				this.userProfileService.httpgetFavoriteData();
				this.userProfileService.httpgetWatchData();
			}
			this.content = token ? this.localstorage.getItem('UserContentLanguage') : this.localstorage.getItem('ContentLang');

			this.pageName = 'search result';
			this.gtm.sendPageName(this.pageName);
			this.gtm.sendEvent();
			$('#loaderPage').css('display', 'block');
			this.config = {
				apiKey: ' ',
				username: ' ',
				password: ' ',
				accessToken: ' ',
				withCredentials: false
			};
	        	// this.menuTabs = [ true, false, false, false ];
			this.menuTabs = [ false, false, false];
			this.menuTabs[this.settingsService.gettabLink()] = true;
		        this.previousTab = this.settingsService.gettabLink();
			this.countryCode = this.settingsService.getCountry();
			this.sub = this.route.queryParams.subscribe(queryparams => {
		        this.routeservice.setLoginRoute(this.router.url);
				// this.menuTabs = [ true, false, false, false ];
				this.menuTabs = [ false, false, false];
			    this.menuTabs[this.settingsService.gettabLink()] = true;
				this.totalPagesArray = [0, 0, 0, 0];
				this.pageArray = [1, 1, 1];
				this.previousTab = this.settingsService.gettabLink();
				this.convivaDataShow = false;
				this.moviesList = {content: []};
				this.tvShowList = {content: []};
				this.allShowList = {content: []};
				this.allEpisodeList = {content: []};
				this.totalResults = 0;
				this.count = 0;
				this.epgList = {content: []};
				this.contentAvailable = true;
				this.dataAvailable = true;
				$('#loaderPage').css('display', 'block');
				this.query = queryparams['q'];

				// const json_ld = { '@context': 'http://schema.org', '@type': 'WebSite', 'url': environment.shareUrl, 'potentialAction': [{ '@type': 'SearchAction', 'target': environment.shareUrl + '/search?q=' + this.query,
				// 'query-input': this.query }, { '@type': 'SearchAction', 'target': 'android-app://com.example/https/query.example.com/search/?q=' + this.query, 'query-input': this.query }] };
				// let script;
				// script = this.document.createElement('script');
				// script.id = 'schema';
				// script.type = 'application/ld+json';
				// script.innerHTML = JSON.stringify(json_ld);
				// this.document.getElementById('showdetailsMarkup').appendChild(script);
				 let x;
				x = new SearchApi(this.http, null, this.config);
				let new_query;
				new_query = this.query.replace(/#/g, '');
			// x.v1SearchGet(undefined, undefined, this.pageNumber, this.pageSize, undefined, undefined, undefined, this.countryCode, undefined, undefined, this.query, '0,6' ).takeUntil(this.ngUnsubscribe).subscribe(value => {
				this.http.get(environment.searchbasepath + 'search?q=' + new_query + '&start=0&limit=' + this.pageSize + '&asset_type=0,6,1&country=' + this.countryCode + '&languages=' + this.content + '&translation=' + this.filterService.gettranslation()  + '&version=2').takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).takeUntil(this.ngUnsubscribe).subscribe(value => {
				// x.v1SearchGet(undefined, undefined, this.pageNumber, this.pageSize, undefined, undefined, undefined, this.countryCode, undefined, undefined, this.query, '0,6' ).takeUntil(this.ngUnsubscribe).subscribe(value => {
					// this.http.get(environment.searchbasepath + 'search?q=' + this.query + '&start=0&limit=' + this.pageSize + '&asset_type=0,6&country=' + this.countryCode + '&translation=' + this.filterService.gettranslation()).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).takeUntil(this.ngUnsubscribe).subscribe(value => {
						$('#loaderPage').css('display', 'none');
						this.data = value.json() || {};
						// this.initialiseEpisodes(this.data.episodes)
						this.initialiseMovies(this.data.movies);
						this.initialiseTvshows(this.data.show_episode);
						this.initialiseAll(this.data.all);

						if (!this.data.all) {
							this.convivaDataShow = true;
						}
						if ((!this.data.all) && this.convivaData.content.length === 0) {
					// Conviva insight API
					this.getConvivaPopular();

				}
				this.commonService.setSearchResults(this.gtm.searchMode, this.gtm.searchType, (this.data.all_total ? this.data.all_total : 0), this.query);
					let scope;
					scope = this;
					$(this.document).ready(function () {
						scope.highlight(scope.query, 100);
					});
			},
			err => {
				$('#loaderPage').css('display', 'none');
				this.dataAvailable = false;
				this.gtm.sendErrorEvent('api', err);
			}
			);
			});
			let scope1;
			scope1 = this;
			this.totalResults = 0;
		}
		if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
			this.touchScreen = true;
		}
		this.fontReScale();
	}
	  @HostListener('window:resize', ['$event'])
	  public fontReScale() {
	    if (this.window.innerWidth < 481) {
	      this.desktop = false;
	    } else {
	      this.desktop = true;
	    }
	  }
	@HostListener('window:scroll', ['$event']) public onScrollEvent($event) {
		let factor;
		if (this.touchScreen) {
			factor = 0.35;
		} else if (!this.touchScreen) {
			factor = 0.75;
		}
		if ($(this.window).scrollTop() >= ($(this.document).height() - $(this.window).height()) * factor) {
			if (this.convivaDataShow) {
				this.loadConviva();
			} else if (this.previousTab === 1) {
				this.load('1,6', this.previousTab);
				this.highlight(this.query);
			} else if (this.previousTab === 2) {
				this.load('0', this.previousTab);
				this.highlight(this.query);
			} else if (this.previousTab === 0) {
				this.load('0,6,1', this.previousTab);
				this.highlight(this.query);
			}
		}
	}
	private getConvivaPopular() {
		let url;
		url = 'https://gwapi.zee5.com/content/conviva-trending?languages=' + this.content + '&translation=' + this.filterService.gettranslation() + '&country=' + this.countryCode + '&page=' + this.convivaPage + '&limit=' + this.pageSize;
		this.http.get(url).map(response => response.json()).subscribe(value => {
			this.convivaData = { 'title': 'Popular', 'parentType': 'conviva',
			'content': value.docs   };
			if (value.numFound) {
				this.convivaTotalPages = Math.ceil((value.numFound) / (this.pageSize));
			} else {
				this.convivaTotalPages = 1;
			}
		},
		err => {
			this.convivaDataShow = false;
		});
	}
	private loadConviva() {
		if (this.networkService.getPopupStatus()) {
			if (this.processPending === false) {
				this.convivaPage++;
				if (this.convivaTotalPages >= this.convivaPage) {
					this.processPending = true;
					$('.auto-loader').css('display', 'block');
					let url;
					url = 'https://gwapi.zee5.com/content/conviva-trending?languages=' + this.content + '&translation=' + this.filterService.gettranslation() + '&country=' + this.countryCode + '&page=' + this.convivaPage + '&limit=' + this.pageSize;
					this.http.get(url).map(response => response.json()).subscribe(value => {
						this.processPending = false;
						this.convivaData.content.push.apply(this.convivaData.content , value.docs);
						$('.auto-loader').css('display', 'none');
						if (this.convivaTotalPages >= this.convivaPage ) {
							$('.load').hide();
						}
					},
					err => {
						this.processPending = false;
						this.gtm.sendErrorEvent('api', err);
					});
				} else {
					$('.load').hide();
				}

			}
		}
	}
	private load(asset_type: any, tab: any) {
		if (this.networkService.getPopupStatus()) {
			if (this.processPending === false) {
				this.pageArray[tab]++;
				if (this.totalPagesArray[tab] >= this.pageArray[tab]) {
					this.processPending = true;
					$('.auto-loader').css('display', 'block');
					let x;
					let new_query;
					new_query = this.query.replace(/#/g, '');
					x = new SearchApi(this.http, null, this.config);
					// x.v1SearchGet(undefined, undefined, this.page, this.pageSize, undefined, undefined, undefined, this.countryCode, undefined, undefined, this.query, this.assetType ).takeUntil(this.ngUnsubscribe).subscribe(value => {
						this.http.get(environment.searchbasepath + 'search?q=' + new_query + '&page=' + this.pageArray[tab] + '&start=0&limit=' + this.pageSize + '&asset_type=' + asset_type + '&country=' + this.countryCode + '&languages=' + this.content + '&translation=' + this.filterService.gettranslation()  + '&version=2').takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).takeUntil(this.ngUnsubscribe).subscribe(response => {
							let value;
							value = response.json() || {};
							this.data = value[this.typeArray[tab]];
							this.processPending = false;
							if (tab === 1) {
								this.tvShowList.content.push.apply(this.tvShowList.content , this.data);
							} else if (tab === 2) {
								this.moviesList.content.push.apply(this.moviesList.content , this.data);
							} else if (tab === 0) {
								this.allShowList.content.push.apply(this.allShowList.content , this.data);
							}
							$('.auto-loader').css('display', 'none');
							if (this.totalPagesArray[tab] >= this.pageArray[tab] ) {
								$('.load').hide();
							}
						   	this.gtm.sendEventDetails({'event': 'scrollTracking', 'ScrollCount': '1'});
						},
						err => {
							this.processPending = false;
							this.gtm.sendErrorEvent('api', err);
						});
					} else {
						$('.load').hide();
					}
				}
			}

			// this.highlight(this.query,100)
			}
		private openTabLink(tab: any) {
			this.menuTabs[this.previousTab] = false;
			this.menuTabs[tab] = true;
			this.previousTab = tab;
			if (tab === 1) {
				this.assetList = '6';
				this.sendSearchDetails({'event': 'tvShowsClicks'});
			}
			if (tab === 2) {
				this.assetList = '0';
				this.sendSearchDetails({'event': 'moviesClicks'});
			}
			if (tab === 0) {
				this.sendSearchDetails({'event': 'clickOnAll'});
			}
			this.highlight(this.query);
		}
		private initialiseAll(data: any) {
			if (data ) {
			this.allShowList = { 'category': 'search', 'title': 'MENU.TVSHOWS', 'query': this.query, 'parentType': 'search', 'type': 'tvshows', 'search_category': 'tvshows',
			'content': data, 'total': this.data.all_total, 'pages': this.tvshowPages, 'original_length': this.data.all_total};
			this.totalPagesArray[0] = Math.ceil((this.data.all_total) / (this.pageSize));
		}
		// this.highlight(this.query);
	}
	private initialiseTvshows(data: any): void {
		if (data) {
			this.tvShowList = { 'category': 'search', 'title': 'MENU.TVSHOWS', 'query': this.query, 'parentType': 'search', 'type': 'tvshows', 'search_category': 'tvshows',
			'content': data, 'total': this.data.show_episode_total, 'pages': this.tvshowPages, 'original_length': this.data.show_episode_total};
			this.updateTotal(this.data.show_episode_total);
			this.totalPagesArray[1] = Math.ceil((this.data.show_episode_total) / (this.pageSize));
		} else {
			this.updateTotal(0);
		}
		// this.highlight(this.query);
	}

	private initialiseEpisodes(data: any) {
		if (data) {
			this.allEpisodeList = { 'category': 'search', 'title': 'EPISODES', 'query': this.query, 'parentType': 'search', 'type': 'episodes', 'search_category': 'tvshows',
			'content': data, 'total': this.data.episodes_total, 'pages': this.episodePages, 'original_length': this.data.episodes_total};
			this.updateTotal(this.data.episodes_total);
			this.totalPagesArray[1] = Math.ceil((this.data.episodes_total) / (this.pageSize));
		} else {
			this.updateTotal(0);
		}
	}
	private initialiseMovies(data: any): void {
		if (data) {
			this.totalPagesArray[2] = Math.ceil(this.data.movies_total / this.pageSize);
			this.moviesList = { 'category': 'search', 'title': 'MENU.MOVIES', 'query': this.query, 'parentType': 'search', 'type': 'tvshows', 'search_category': 'movies',
			'content': data, 'total': this.data.movies_total, 'pages': this.moviesPages, 'original_length': this.data.movies_total };
			this.updateTotal(this.data.movies_total);
		} else {
			this.updateTotal(0);
		}
		// this.highlight(this.query);
	}
	private updateTotal(sum: number): void {
		this.count = this.count + 1;
		this.totalResults += sum;

		if (this.count === 3 && this.totalResults === 0) {
			this.contentAvailable = false;
		}
		this.totalPages = Math.ceil(this.totalResults / this.pageSize);
	}
		public ngOnDestroy () {
			this.ngUnsubscribe.next();
			this.ngUnsubscribe.complete();
			$('#breadcrumInit').css('display', '');
		}


	  private highlight = function (string1) {
	  	if (this.desktop) {
	  	  let x, y;
	  	  x = document.getElementsByClassName('label-show-title-search ');
	  	  y = document.getElementsByClassName('label-show-title-search-news ');
	      this.nexthighlight(x, string1);
	      this.nexthighlight(y, string1);
	      let next, next1;
	      next = document.getElementsByClassName('label-subTitle-search');
	      next1 = document.getElementsByClassName('label-subTitle-search-news');
	      this.nexthighlight(next, string1);
	      this.nexthighlight(next1, string1);
	  	} else {
	  		let x;
	  		x = document.getElementsByClassName('0');
	      this.nexthighlight(x, string1);
	      // var next = document.getElementsByClassName("show-name");
	      // this.nexthighlight(next,string);
	  	}
	  };

	  public font() {
	    if ( this.window.innerWidth < 480 ) {
	      $('.highlight').css({'font-family': 'Roboto', 'font-size': '16px', 'color': '#BF006B', 'font-weight': '400', 'letter-spacing': '0.02em'});
	    } else {
	      $('.highlight').css({'font-family': 'Roboto', 'font-size': '16px', 'color': '#BF006B', 'font-weight': '400', 'letter-spacing': '0.02em'});
	    }
	    // return true;

	    // $('.label-subTitle-search').css({'text-transform': 'capitalize'});
	  }
	  	public fonthtml() {
	    if ( this.window.innerWidth < 480 ) {
	      $('.highlight').css({'font-family': 'Roboto', 'font-size': '16px', 'color': '#BF006B', 'font-weight': '400', 'letter-spacing': '0.02em'});
	    } else {
	      $('.highlight').css({'font-family': 'Roboto', 'font-size': '16px', 'color': '#BF006B', 'font-weight': '400', 'letter-spacing': '0.02em'});
	    }
	    return true;

	    // $('.label-subTitle-search').css({'text-transform': 'capitalize'});
	  }

	  public nexthighlight(x, string2) {
	  // alert('nexthighlight')

	  // 		let upper_limit, pre_limit;
	  // 		if (this.desktop) {
	  // 			pre_limit = 0;
	  // 			upper_limit = x.length;
	  // 		} else {
	  // 			pre_limit = this.initial_limit;
	  // 			upper_limit = pre_limit + 100;
	  // 		}
	  // if (x.length > 0 && upper_limit <= x.length) {
       for (let i = 0 ; i < x.length; i++) {
          if (string2) {
          let array;
          array = string2.trim().replace(' ','|');
          let pattern;
          pattern = new RegExp(  array , 'gi');
          let new_text;
          new_text = x[i].innerText.replace(pattern,'<span class=\'highlight\'>$&</span>');
          x[i].innerHTML = new_text;

        //   }
        // }
      }
      this.font();
	 //this.initial_limit = this.initial_limit + limit;

	  }
	}
	  public sendSearchDetails(searchDetails) {
	  	this.gtm.sendEventDetails(searchDetails);
	  }
	}
