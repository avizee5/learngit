import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchResultsScreenComponent } from './search-results-screen.component';

describe('SearchResultsScreenComponent', () => {
  let component: SearchResultsScreenComponent;
  let fixture: ComponentFixture<SearchResultsScreenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchResultsScreenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchResultsScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
