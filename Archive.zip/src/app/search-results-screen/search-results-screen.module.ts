import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared.module';
import { SearchResultsScreenComponent } from './search-results-screen.component';
import { DataUnavailableModule } from '../data-unavailable/data-unavailable.module';
import { HomeGridModule } from '../home-grid/home-grid.module';
import { SearchResultMobileComponent } from './search-result-mobile/search-result-mobile.component';

const routes: Routes = [
    {
        path: '',
        component: SearchResultsScreenComponent,
    },
];
@NgModule({
  exports: [RouterModule],
  imports: [RouterModule.forChild(routes), CommonModule, SharedModule, HomeGridModule, DataUnavailableModule],
  declarations: [SearchResultsScreenComponent, SearchResultMobileComponent]
})
export class SearchResultsScreenModule { }
