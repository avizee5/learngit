import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EpisodeConsumptionComponent } from './episode-consumption.component';

describe('EpisodeConsumptionComponent', () => {
  let component: EpisodeConsumptionComponent;
  let fixture: ComponentFixture<EpisodeConsumptionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EpisodeConsumptionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EpisodeConsumptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
