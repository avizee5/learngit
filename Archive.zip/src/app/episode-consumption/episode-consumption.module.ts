import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared.module';
import { EpisodeConsumptionComponent } from './episode-consumption.component';
import { DataUnavailableModule } from '../data-unavailable/data-unavailable.module';
import { EmbedLinkPopupModule } from '../embed-link-popup/embed-link-popup.module';
import { ScrollGridModule } from '../scroll-grid/scroll-grid.module';
import { ShareoptionsModule } from '../share-options/share-options.module';
import { VideoModule } from '../video/video.module';
import { ScrollListModule } from '../scroll-list/scroll-list.module';
import { BeforetvpopupComponent } from './beforetvpopup/beforetvpopup.component';
import { CastscrollListModule } from '../castscroll-list/castscroll-list.module';
import { PremiumTabModule } from '../premium-tab/premium-tab.module';


const routes: Routes = [
    {
        path: '',
        component: EpisodeConsumptionComponent,
    },
];
@NgModule({
  exports: [RouterModule],
  imports: [RouterModule.forChild(routes), CommonModule, ScrollListModule, SharedModule, ShareoptionsModule, DataUnavailableModule, EmbedLinkPopupModule, ScrollGridModule, VideoModule, CastscrollListModule, PremiumTabModule],
  declarations: [EpisodeConsumptionComponent, BeforetvpopupComponent]
})
export class EpisodeConsumptionModule { }
