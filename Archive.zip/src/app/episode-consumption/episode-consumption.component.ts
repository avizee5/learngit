import { Component, OnInit, Inject, PLATFORM_ID, OnDestroy, HostListener, ViewChild, AfterViewChecked} from '@angular/core';
import * as $ from 'jquery';
import { HeaderservicesService } from '../services/headerservices.service';
import { EpisodeApi, SeasonApi, TvShowApi} from '../../data/gwapi_catalog/api/api';
import { ActivatedRoute } from '@angular/router';
import { SettingsService } from '../services/settings.service';
import { Http} from '@angular/http';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { environment } from '../../environments/environment';
import { Subject } from 'rxjs/Subject';
import {CommonService} from '../services/common.service';
import { SubscriptionService } from '../services/subscription.service';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { isPlatformBrowser } from '@angular/common';
import { VideoService } from '../services/video.service';
import { SeoService } from '../services/seo.service';
import { LinkService } from '../services/link.service';
import { Meta } from '@angular/platform-browser';
import { RouteService } from '../services/route.service';
import 'rxjs/add/operator/takeUntil';
import { WatchlistApi } from '../../data/user/api/api';
// import {FavoritesApi, RemindersApi, UserApi, WatchHistoryApi, WatchlistApi } from '../../data/user/api/api';
import { UserApiService } from '../services/user-api.service';
import {  NetworkService  } from '../services/network.service';
import {TranslateService} from '@ngx-translate/core';
import { UserProfileService } from '../services/user-profile.service';
import {CollectionApi} from '../../data/gwapi_catalog/api/CollectionApi';
declare let googletag;
declare const adoric;
declare let adoricRecomendationContent;
@Component({
  selector: 'app-episode-consumption',
  templateUrl: './episode-consumption.component.html',
  styleUrls: ['./episode-consumption.component.less']
})
export class EpisodeConsumptionComponent implements OnInit, OnDestroy {
 @ViewChild('add') public targetElement: any;
 private prev_next_data: any;
 private actualEpisodeInfo: any;
 private totalData: any = [];
 private apiRetry = 2;
 private apiRetryCount = 1;
 private ngUnsubscribe = new Subject<any>();
 public imageUrl: any;
 private gAChannelOriginal: any;
 public showAdult = false;
 public seasonAPI: any;
 private squareAd: any;
 private pauseVideo = false;
 public embedUrl: any;
 private prevBlock = false;
 private nextBlock = false;
 private lastEpisode = false;
 private noAd = true;
 private episodeId: any;
 private default: any = environment.assetsBasePath + 'assets/default/episode.jpg';
 private prevUrl: any = environment.assetsBasePath + 'assets/default/episode.jpg';
 private nextUrl: any = environment.assetsBasePath + 'assets/default/episode.jpg';
 private currentTab: any = 0;
 private business_type: any = 'free';
 private samplePremium = false;
 private waiting = 0;
 private emptyState = '';
 private firstcall = true;
 private sort_order: any = 'DESC';
 public adObject: any;
 // public adObject = { 'Mobile0': '', 'Desktop0': '', 'Mobile1': '', 'Desktop1': '', 'styleMobile0': '', 'styleDesktop0': '', 'styleMobile1': '', 'styleDesktop1': ''};
 public videoAdData: any;
 private samplePremiumData: Array<any> = [];
 private rating: Array<any> = [];
 private ratingArray: Array<any> = [1, 2, 3, 4, 5];
 private genresZeo: any;
 private episodeTitle: any = 'DETAILS.EPISODES_LATEST';
 private baseCategory: any;
 private episodeIndex: any;
  // private SimilarShows: any;
  public nextEpisodes: any;
  private nextPlaying = true;
  private subs: any;
  // private storedFavData: any;
  // private storedWatchData: any;
  private totalEpisodes: Array<any> = [];
  public category: any;
  public embedLink = false;
  private id: any;
  private name: any;
  private watch: any;
  private episodeName: any;
  private episodeID: any;
  private videoData: Array<any> = [];
  public error = false;
  public episodeInfo: any;
  public tvShowData: any;
  public showTitle: any;
  public video = false;
  private releaseDate: string;
  private episodeNo: string;
  public episodesData: any = [];
  public upnextData: any = [];
  public seasonData: any = [];
  private seasons_id: any;
  private indexLimit: any = 200;
  private configData: any;
  public parentControl: any;
  public zeeOriginalShow = false;
  public premiumShow = false;
  public setTrailer = false;
  public titleHeader: any;
  private monthNames = [
  'January', 'February', 'March',
  'April', 'May', 'June', 'July',
  'August', 'September', 'October',
  'November', 'December'
  ];
  private months: any = ['Jan', 'Feb', 'Mar',
  'Apr', 'May', 'Jun', 'Jul',
  'Aug', 'Sep', 'Oct',
  'Nov', 'Dec'
  ];
  private googletagAvailable: any;
  private configFile: any;
  private desktopTag: any;
  private mobileTag: any;
  private localstorage: any;
  private window: any;
  private document: any;
  private navigator: any;
  private availableChannelOriginal: any;
  private tvShowsGenreEng: any;
  private description: any;
  private textLimit = 200;
  private showReadMore: any;
  private readText: any = 'DETAILS.READ_MORE';
  private toggleReadmore = false;
  private assetSubtype: any;
  private assetbasepath: any =  environment.assetsBasePath;
  private pageName: any;
  private router: any;
  private router2: any;
  private basepath: any;
  private showLogin = false;
  private showSubscribe = false;
  private playcontent = false;
  private premium = false;
  private showSubPopUp: any;
  private showSubPopUpSettings: any;
  private purchasedAssetType: any;
  private loginToken: any;
  private subscription1 = false;
  public touchScreen = false;
  public touchScreenbelow = false;
  public trailerString: any;
  public showTrailerBottom = false;
  private regionalLang = [];
  private displaylanguage: any;
  private fetchLabel: any;
  private subscriptionSuccess: any;
  private configUser: any;
  private trailer: any;
  private trailer1: any;
  private trailerInfo: any;
  private trailerCheck: any;
  private trailerPlayed: any;
  private showepisodeTitle = false;
  private playerHeight: any;
  public totalHeight: any;
  public gridHeight: any;
  // private viewload = true;
  private countries: any;
  private selected_country: any;
  private age_rating_value: any;
  private parental_age: any = 2;
  private parental_object: any = {
    'U': 0, 'U/A': 1, 'A': 2
  };
   // private favorite = false;
  private watched = false;
  private showShare = false;
  private shareUrl: any;
  // private showAutoplayUI = true;
  private castQueueObject: any;
  private showEmbedIcon = false;
  private configusertoken: any;
  private tvShowDataLatest: any;
  private RTRMBLOCK: any;
  public showBeforeTV = false;

public image_url: any;
public image_url_mobile: any;
private imageBasepath: any;
public imageSrc: any;
private onErrorSrc: any;
private isStaticVdeoEnable: any;
public descriptionData: any;
public corousalData: any;
public seasonDataCarousal: any;
public tvshowdata: any;
public asset_subtype: any;
public asset_type: any;
public tvShowGenre = [];
private languages_array: string[];
public languages: any;
public showReleaseDate: any;
public subtitles_lang: any;
public availableOnChannel: any;
public availableOnChannelShows: any;
public ageRating: any;
public showDuration: any;
public showSeasons: any;
public showCast: boolean;
public showCastPage: boolean;
private actorsNames: Array<string>;
private showactorsNames: Array<string>;
private languageData: any;
private gAlanguage: any = [];
private languagesEng: string;
public read: any;
public number: any;
private hideScroll: boolean;
public seasonsList: any;
public selectedItem: any;
public season: any;
private onErrorBanner = environment.assetsBasePath + 'assets/default/banner.png';
private onErrorBanner_mob = environment.assetsBasePath + 'assets/default/banner.png';
public showTitleScreen: any;
public showDropdrown: any;
public readArrow: any;
public autoLoader = true;
public upNextTitle: any;
public upnextdataMobile: any;
public addPaddingCast: any;
public parentalpin = false;
public episodeReleaseDate: any;
public imgSrc: any;
public showPage: any = false;
public showTitleHeader: any = '';
public showDescription: any = '';
public showGenres = [];
public showageRating: any;
public episodesString: any;
public total_ep: any;
public trailerData: any;
public dots = '';
public episode_subtype: any;
private nodata = false;
public showGetPremium: any = false;
public noEpisodes: any = false;
public scrollGridHeightNoAd: any;
public backgroundImage: any = false;
public yIndex: any = 0;
public ageinNum: any;
public ageMap: any;
public valid_string: any;
public agetake = false;
public showRating: any;
public navigationUrl: string;
public tvshow_tags: any = [];
public countryCode: any;
public talamoosEnable: any = false;
// public contentAgeRating: any;

public talamoosImpression: any;

private timer: any = [];
constructor(private routerLink: Router,
  private linkservice: LinkService,
  private metaService: Meta,
  private userapiService: UserApiService,
  private userProfileService: UserProfileService,
  private commonService: CommonService,
  private subscription: SubscriptionService,
  private routeservice: RouteService,
  private headerservicesService: HeaderservicesService,
  private seoService: SeoService,
  private networkService: NetworkService,
  private location: Location,
  private videoService: VideoService,
  private routeLink: Router,
  @Inject(PLATFORM_ID) private platformId: Object,
  private settingsService: SettingsService,
  private gtm: GoogleAnalyticsService,
  private http: Http,
  private route: ActivatedRoute,
  private translate: TranslateService) {
    if (isPlatformBrowser(this.platformId)) {
      this.localstorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
    this.routeservice.setLoginRoute(window.location.pathname);
    this.router = routeLink;
    /*this.router2 = window.location.pathname;
    this.routeservice.setRoute(this.router2);
    this.headerservicesService.viewChange(this.router2);*/
    // this.userProfileService.favourite.subscribe(value => {
    // 	this.favorite = this.userProfileService.inList('favorite', this.episodeInfo.id);
    //  });
   	this.userProfileService.watchlater.subscribe(value => {
        this.watched = this.userProfileService.inList('watchList', this.actualEpisodeInfo.id);
         this.iswatched();

    });
    this.headerservicesService.subscribeReminder.takeUntil(this.ngUnsubscribe).subscribe(value => {
      if (this.trailerCheck && this.video) {
        return;
      }
      if ( value === false) {
        if ( this.premium) {
          $('#noAccessSubs').show();
          $('#noAccess').hide();
          $('#playImage').hide();
        } else {
          // if (this.checkParental(this.episodeInfo.age_rating) > this.parental_age) {
          //   this.headerservicesService.parentalChange({'flag': true, 'type': 'pin' })
          // } else {
          //   this.video = true
          // }
        }
      } else {
        // this.video = false
        $('#noAccess').hide();
        $('#noAccessSubs').hide();
      }
    });
    this.headerservicesService.signInReminder.takeUntil(this.ngUnsubscribe).subscribe(value => {
      if (this.trailerCheck && this.video) {
        return;
      }
      if ( value === false) {
        if ((this.tvShowData.business_type.indexOf('premium') === -1) && (this.actualEpisodeInfo.business_type.indexOf('premium') === -1)) {
          this.premium = false;
        }
        if ( this.premium) {
          $('#noAccess').show();
          $('#noAccessSubs').hide();
          $('#playImage').hide();
        } else {
          // if (this.checkParental(this.episodeInfo.age_rating) > this.parental_age) {
          //   this.headerservicesService.parentalChange({'flag': true, 'type': 'pin' })
          // } else {
          //   this.video = true
          // }
        }
      } else {
        // this.video = false
        $('#noAccess').hide();
        $('#noAccessSubs').hide();
      }
    });

    // this.headerservicesService.parentalValue.takeUntil(this.ngUnsubscribe).subscribe(value => {
    //   if (value.type === 'none' && this.video === false) {
    //       $('#parentControl').show();
    //       $('#noAccess').hide();
    //       $('#playImage').hide();
    //       if (value.four === 'press') {
    //         $('#parentControl').hide();
    //         $('#noAccess').hide();
    //         $('#playImage').hide();
    //       }
    //   } else {
    //       $('#parentControl').hide();
    //     $('#noAccess').hide();
    //     $('#playImage').hide();
    //   }
    // });

    // this.headerservicesService.searchValue.takeUntil(this.ngUnsubscribe).subscribe(value => {
    //   this.showPlayIcon(value);
    // });
    this.videoService.alertModalState.takeUntil(this.ngUnsubscribe).subscribe(value => {
      if (value) {
        // this.showPlayIcon(value);
        this.video = false;
        this.backgroundImage = this.videoService.getImageUrl(this.videoData[0], false);
      } else {
        this.backgroundImage = false;
      }
    });
    // Show login screen on Consuption page if "skip" or "close" on login-popup
    // this.videoService.showLoginOnSkip.takeUntil(this.ngUnsubscribe).subscribe(value => {
    //   if(value){
    //     if(this.contentAgeRating === 'A'){
    //       this.showAdult = value;
    //     } else {this.showLogin = value;}        
    //   }
    // });
    // this.videoService.showSubOnSkip.takeUntil(this.ngUnsubscribe).subscribe(value => {
    //   if(value){
    //     this.showSubscribe = value;
    //   }
    // });
    // this.videoService.nextepisode.takeUntil(this.ngUnsubscribe).subscribe(value => {
    //  this.gtm.GAsubCategory = 'NA';
    //  this.nextEpisode();
    // });
    this.headerservicesService.modelValue.takeUntil(this.ngUnsubscribe).subscribe(value => {
      if (value) {
        // this.showPlayIcon(value);
      } 
      else if(!value && !this.document.getElementById('playImage')){
        // this.showPlayIcon(value);
      }
      else if (!value && this.document.getElementById('playImage')) {
        if ((this.loginToken && this.subscription1) || (this.premium)) {
           let browser;
           browser = this.videoService.get_browser();
          if ((browser.name.match(/UCBrowser/i) || browser.name.match(/UBrowser/i)) && this.navigator.userAgent.match(/mobile|iPhone|iPod|iPad/i)) {
            if (this.checkParental(this.episodeInfo.age_rating) > this.parental_age) {
                this.headerservicesService.parentalChange({'flag': true, 'type': 'pin' });
            } else {
                this.video = this.loginToken ? true : (this.episodeInfo.age_rating === 'A') ? false : true;
                this.showAdult = !this.video;
            }
          } else {
              if (!this.trailerCheck) {
                  this.video = false;
               }
          }
        }
      }
    });

    // Parental Control Success
    this.userapiService.enableVideoPlay.takeUntil(this.ngUnsubscribe).subscribe(value => {
      if (value === true ) {
        if (this.videoService.enableCastView) {
          this.videoData ? (this.backgroundImage = this.videoService.getImageUrl(this.videoData[0], false)) : (this.backgroundImage =  false);
          this.videoService.castQueueObject = this.castQueueObject;
          this.videoService.toggleQueueState(true);
          this.castQueueObject = null;
        } else {
          this.video = true;
          this.parentalpin = false;
          if (this.showSubscribe) {
            this.showSubscribe = false;
          }
        }
      }
    });

    // check my plan flag
    this.subscription.planApiSuccess.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.showSubPopUp = value;
      if (this.showSubPopUp !== undefined && this.subscriptionSuccess === undefined) {
        this.ngOnInit();
      }
    });
    this.videoService.tvShowTrailer.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.trailerPlayed = value;
      if (value) {
        this.trailer = true;
        this.trailer1 = true;
        this.video = false;
        this.playcontent = false;
        this.trailerCheck = false;
        if (this.loginToken) {
         this.purchasedAssetType = this.subscription.checkPlanApiSuccess(true);
         let assetType;
         assetType = '6';
            this.showSubscribe = (this.purchasedAssetType.indexOf(assetType) > -1 ) ? false : true;
            this.showLogin = false;
        } else {
          this.showSubscribe = false;
          this.showLogin = true;
        }
          setTimeout(() => { this.startVideoLive();
          $('#playImage').hide(); }, 1);
      }
    });
  }

  public ngOnInit() {
    $('#loaderPage').css( 'display', 'block');
    this.loginToken = localStorage.getItem ( 'token' );
    this.showSubPopUp = this.subscription.getPlanApiSucess();
    this.imageBasepath = this.settingsService.getbasePathNew();
    this.countryCode = this.settingsService.getCountry();
    if (this.loginToken && (this.showSubPopUp === undefined )) {
      return;
    }
    this.iswatched();
    let  browser1;
    browser1 = this.videoService.get_browser();
      if (browser1.name === 'Firefox') {
        $('#breadcrumInit').css('position', 'relative');
      }
    this.subscriptionSuccess = true;
    this.showDropdrown = false;
    // Parental Control - removed for mygp
    // this.age_rating_value = this.userapiService.getAgeRating();
    let scope;
    scope = this;
    // if (this.age_rating_value) {
    //   this.parental_age = this.parental_object[this.age_rating_value.age_rating];
    // } else {
    //   setTimeout(() => {
    //     scope.age_rating_value = scope.userapiService.getAgeRating();
    //     if (scope.age_rating_value) {
    //       this.parental_age = this.parental_object[this.age_rating_value.age_rating];
    //     } else {
    //       this.parental_age = 2;
    //     }
    //   }, 100);
    // }
    this.firstcall = true;

    this.gtm.storeWindowError();
    if (isPlatformBrowser(this.platformId)) {
      this.localstorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
    this.touchScreen = (this.window.innerWidth <= 768) ? true : false;
    this.addPaddingCast = (this.window.innerWidth <= 991) ? true : false;
    this.showTrailerBottom = (this.window.innerWidth <= 767) ? true : false;
    this.touchScreenbelow = (this.window.innerWidth <= 481) ? true : false;
    this.trailerString =  (this.window.innerWidth <= 480) ? 'BREADCRUMB.TRAILER' : 'COMMON.WATCH_TRAILER';

    this.headerservicesService.episodicPage(this.touchScreen);
    this.configData = this.settingsService.getCompleteConfig();
      if (this.loginToken) {
        this.displaylanguage = localStorage.getItem('UserDisplayLanguage');
        this.userProfileService.httpgetFavoriteData();
        this.userProfileService.httpgetWatchData();
        let bearer;
        bearer = 'bearer ' + this.loginToken;
          this.configusertoken = {
            apiKey: bearer,
            username: ' ',
            password: ' ',
            accessToken: ' ',
            withCredentials: false
          };
      } else {
        this.displaylanguage = localStorage.getItem('display_language');
      }
    this.fetchLabel = this.configData.languages_labels[this.displaylanguage];
    // this.storedFavData = this.userProfileService.getFavoriteData();
    // this.storedWatchData = this.userProfileService.getWatchData();
    this.basepath = this.settingsService.getbasePath();
    let network;
    network = this.networkService.getScreenStatus();
    if (network) {
      $('#loaderPage').css('display', 'block');
      this.gtm.storeWindowError();
      this.assetbasepath = environment.assetsBasePath;
      this.subs = this.route.params.subscribe(params => {
        // $( '#scrollList' ).scrollTop(0);
        $( '#featureouter' ).scrollTop(0);
        if (this.episodeID !== params['episodeid']) {
          this.showGetPremium = false;
        }
        this.episodeID = params ['episodeid'];
        this.userapiService.enableVideo(false);
        /* commented for autoplay */
        // this.video = false;
        /* commented for autoplay */
        this.showAdult = false;
        this.showSubscribe = false;
        this.showLogin = false;
        this.parentalpin = false;
        this.prev_next_data = null;
        this.textLimit = 200;
        this.showPage = false;
        this.router2 = window.location.pathname;
        this.routeservice.setLoginRoute(window.location.pathname);
        this.headerservicesService.viewChange(this.router2);
          // if (this.viewload) {
          this.nextEpisodes = undefined;
          this.upnextdataMobile = undefined;
          this.corousalData = [];
          this.yIndex = 0;
          /* commented for autoplay */
          // this.video = false;
          // this.videoData = [];
          /* commented for autoplay */
          $(document).ready (() => {
            $( 'html,body' ).scrollTop(1);
          });
          this.videoAdData = undefined;
	  this.backgroundImage = false;
          this.commonService.qgraphevent('episodicPage_visited', {'country': this.settingsService.getCountry(), 'state': this.localstorage.getItem('state_code')});
            this.category = params['category'];
            this.id = params['id'];
            this.name = params['name'] ;
            this.watch = params ['watch'];
            this.episodeName = params ['episodename'];
            this.episodeID = params ['episodeid'];
            this.season = params['seasons'];

            this.resetVars();
            this.assetSubtype = (this.window.location.pathname.indexOf('zee5originals') > -1) ?  'zeeOriginals' : 'tvshows';
            if (this.episodeID ) {
              this.startVideo();
            } else if (this.id) {
              this.showPage = true;
              this.getEpisodeId();
            } else {
              this.showError();
            }
        // } else {
        //     this.viewload = true;
        //     this.setEpisodeData(false);
        // }
      });
    }
      scope = this;     // dropdownDiv outside
      $(document).mouseup(function(e) {
        if (e.target.id !== 'dropdowndiv' && !$('#dropdowndiv').find(e.target).length) {
             if ( scope.toggle_div === true ) {
             $('.dropdown-content').css('display', 'none');
             scope.toggle_div = false;
            }
         }
      });
      $(this.window).on('load', function() {
        if( $(".consButtonElement.trailerContainerShow").length && !$(".consButtonWrapper").hasClass("rightAlign")){
          $(".consButtonWrapper").addClass("rightAlign");
        }
      });
  }
  public ngAfterViewChecked()	{
    if( ( this.actualEpisodeInfo && this.actualEpisodeInfo.asset_subtype && this.actualEpisodeInfo.asset_subtype !== 'trailer' && this.trailer1 && (!this.showTrailerBottom || !this.showDropdrown)) || (this.showDropdrown) ){
      $(".consButtonWrapper").addClass("rightAlign");
    } else if (this.actualEpisodeInfo && this.actualEpisodeInfo.asset_subtype && this.actualEpisodeInfo.asset_subtype === 'trailer') {
      if ($('.consButtonWrapper').hasClass('rightAlign')) {
        $('.consButtonWrapper').removeClass('rightAlign');
      }
    }
  }

  private iswatched(): any {
    if (this.watched) {
      this.imgSrc = this.assetbasepath + 'assets/common/watchLater_icon_selected.png';
    } else {
      this.imgSrc = this.assetbasepath + 'assets/common/watchLater_normal.png';
    }
  }

  private toggelShowDiv(): void {
    let scope;
    scope = this;
    $(document).ready(function() {
      if (scope.toggle_div === true) {
         $('.dropdown-content').css('display', 'none');
         scope.toggle_div = false;
         scope.hideScroll = false;
      } else {
          $('.dropdown-content').css('display', 'block');
          scope.toggle_div = true;
      }
    });
  }
  private assignSeason(value, index, number1) {
    let base, show_title, tempTitle;
    this.selectedItem = value;
    base = (this.tvShowData.asset_subtype === 'Original') ? 'zee5originals/details/' : 'tvshows/details/';
    // if (this.tvShowData && this.tvShowData.extended && this.tvShowData.extended.seo_title) {
    //   tempTitle = (this.tvShowData.extended.seo_title !== null || this.tvShowData.extended.seo_title !== undefined || this.tvShowData.extended.seo_title !== '') ? this.tvShowData.extended.seo_title : this.tvShowData.original_title;
    // } else {
    //   tempTitle = (this.tvShowData.seo_title && (this.tvShowData.seo_title !== null || this.tvShowData.seo_title !== undefined || this.tvShowData.seo_title !== '')) ? this.tvShowData.seo_title : this.tvShowData.original_title;
    // }
    tempTitle = this.tvShowData.original_title;
    show_title = this.commonService.convertToLowercase(tempTitle);
    if (number1 === 1) {
      this.routerLink.navigate([base , show_title , this.tvShowData.id  , 'episodes']);
    } else {
      this.routerLink.navigate([base , show_title , this.tvShowData.id , 'season-' + number1 , 'episodes']);
    }
    this.hideScroll = false;
  }
  private extractSeason(iCalContent) {
    let rx;
    rx = /Season (.*)/g;
    let arr;
    arr = rx.exec(iCalContent);
    return arr[0];
  }
  private extractSeasonnumber(content) {
    let rx;
    rx = /season-(.*)/g;
    let arr;
    arr = rx.exec(content);
    return arr[1];
  }
  private extractSeasonnumberFromAPI(content) {
    let rx;
    rx = /Season (.*)/g;
    let arr;
    arr = rx.exec(content);
    return arr[1];
  }
   private hiddenelements(): void {
    this.hideScroll = true;
   }
  private receiveData(value) {
    setTimeout(() => {
      this.Resize();
    }, 0);
  }
  private embedLinkVisibility(): void {
    // this.showEmbedIcon = this.settingsService.embedLinkVisibility() && (this.countryCode === 'IN' || this.actualEpisodeInfo.business_type.indexOf('premium') === -1);
    this.showEmbedIcon = this.settingsService.embedLinkVisibility(this.actualEpisodeInfo.business_type);
  }
  private setImages(): void {
    this.setPreviousImage();
    this.setNextImage();
  }
  private setPreviousImage(): void {
    let  episodeInfo;
         if ((this.prev_next_data && this.prev_next_data.previousEpisode && this.prev_next_data.previousEpisode !== '')) {
             episodeInfo = this.prev_next_data.previousEpisode;
             this.prevBlock = true;
             if (episodeInfo.list_image) {
             this.prevUrl = this.commonService.getEpisodeUrl(episodeInfo.release_date, this.tvShowData.original_title, episodeInfo, '70x39/');
           }
          } else {
             this.prevBlock = false;
            this.prevUrl = this.default;
          }

  }
  private setNextImage(): void {
        let episodeInfo;
          if ((this.prev_next_data && this.prev_next_data.nextEpisode && this.prev_next_data.nextEpisode !== '')) {
             episodeInfo = this.prev_next_data.nextEpisode;
             this.nextBlock = true;
             if (episodeInfo.list_image) {
             this.nextUrl = this.commonService.getEpisodeUrl(episodeInfo.release_date, this.tvShowData.original_title, episodeInfo, '70x39/');
           }
          } else {
             this.nextBlock = false;
            this.nextUrl = this.default;
          }
  }
  // private setEpisodeData(eve): void {
  //     let data, date;
  //       this.episodeNo =  this.actualEpisodeInfo.index;
  //       this.showAdult = this.loginToken ? false : (this.actualEpisodeInfo.age_rating === 'A' ? true : false);
  //       if (!this.showAdult) {
  //             this.videoService.castQueueObject = this.castQueueObject;
  //             this.videoService.toggleQueueState(true);
  //       }
  //      this.episodeId = this.actualEpisodeInfo.id;
  //      this.videoData = [];
  //     // this.description = this.actualEpisodeInfo.description;
  //      if ( this.actualEpisodeInfo.extended && this.actualEpisodeInfo.extended.digital_long_description_web) {
  //       this.description = (this.actualEpisodeInfo.extended.digital_long_description_web.length > 0) ? this.actualEpisodeInfo.extended.digital_long_description_web : 'NA';
  //     } else {
  //       this.description = (this.actualEpisodeInfo.description) && (this.actualEpisodeInfo.description.length > 0) ? this.actualEpisodeInfo.description : 'NA';
  //     }
  //     this.showepisodeTitle = (this.actualEpisodeInfo.asset_subtype !== 'episode') ? true : false;
  //     // this.descriptionCheck();
  //     // this.toggleReadMore();
  //       this.titleHeader = this.actualEpisodeInfo.title;
  //       this.setTvshowdataHTML(this.actualEpisodeInfo);

  //     this.checkDesLen(this.actualEpisodeInfo.description);
  //          if (this.episodeInfo.release_date && this.episodeInfo.release_date !== null  && this.episodeInfo.release_date !== undefined) {
  //            this.episodeReleaseDate = this.episodeInfo.release_date;
  //          } else {
  //            this.episodeReleaseDate = '';
  //          }
  //     date = this.dateChange(this.episodeInfo.release_date, this.monthNames, false);
  //     this.releaseDate = (date !== '') ? '- ' + date  :  '';
  //     if ((this.tvShowData.asset_subtype === 'original' || this.tvShowData.asset_subtype === 'tvshow') && this.premiumShow && this.actualEpisodeInfo.business_type.indexOf('premium') !== -1) {
  //         this.premium = (this.actualEpisodeInfo.asset_subtype === 'sample_premium') ? false : true;
  //     } else {
  //       this.premium = false;
  //     }
  //      if (this.premium && (this.trailer) && (this.actualEpisodeInfo.asset_subtype !== 'sample_premium')) {
  //         this.showGetPremium = true;
  //         this.startTrailer();
  //      } else {
  //               // data = this.dataCreation(this.actualEpisodeInfo, this.tvShowData);
  //               // this.videoData.push(data);
  //               //  this.startVideoEpisode(false);
  //         if ((this.tvShowData.business_type.indexOf('premium') === -1) && (this.actualEpisodeInfo.business_type.indexOf('premium') !== -1)) {
  //                 this.premiumShow = false;
  //                 this.showbeforeTVpopup(this.tvShowData.business_type, this.actualEpisodeInfo.business_type);
  //               } else {
  //             data = this.dataCreation(this.actualEpisodeInfo, this.tvShowData);
  //               this.videoData.push(data);
  //                this.startVideoEpisode(false);

  //             }
  //      }
  //      this.prevNext();
  // }
  private resetVars(): void {
     this.trailer = false;
     this.trailer1 = false;
   this.trailerInfo = null;
   this.trailerCheck = false;
   this.trailerPlayed = false;
   this.totalEpisodes = [];
   this.noAd = true;
  }
  @HostListener('window:resize', ['$event'])
  public onResize(event) {
    this.Resize();
  }
  @HostListener('window:scroll', ['$event']) public onScrollEvent($event) {
    let scope;
    scope = this;
       if (this.hideScroll === true) {
       this.hideScroll = false;
       this.toggelShowDiv();
     }
   }
  private Resize(): void {
          let width, top;
          this.touchScreen = (this.window.innerWidth <= 768) ? true : false;
          this.addPaddingCast = (this.window.innerWidth <= 991) ? true : false;
          this.showTrailerBottom = (this.window.innerWidth <= 767) ? true : false;
          this.touchScreenbelow = (this.window.innerWidth <= 481) ? true : false;
          this.trailerString =  (this.window.innerWidth <= 480) ? 'BREADCRUMB.TRAILER' : 'COMMON.WATCH_TRAILER';
          this.headerservicesService.episodicPage(this.touchScreen);
          width = $('.bannerinner').width();
          this.playerHeight = width * 9 / 16 ;
          setTimeout(() => {
            $('#loaderPage').css('display', 'none');
            this.autoLoader = true;
    // $('#auto-loader-episode').css('display', 'block');
            width = $('.bannerinner').width();
            this.playerHeight = width * 9 / 16 ;
            this.totalHeight = this.playerHeight + (91.641 + 66.984);
            this.scrollGridHeightNoAd = this.totalHeight - 43;
            this.gridHeight = this.noAd ? this.totalHeight : this.totalHeight - this.targetElement.nativeElement.offsetHeight - 43;
            // console.log(this.gridHeight,'totalHeight1')
            // console.log(this.playerHeight, width)
            if (this.touchScreen) {
               $('.episode_details').css('paddingTop', this.playerHeight + 15);
            } else {
               $('.episode_details').css('paddingTop', '0px');
            }
             top = this.touchScreen ? ( this.playerHeight + 161 ) : 75;
            $('#breadcrumInit').css('top', top + 'px');
          }, 0);
          this.addPaddingCast = (this.window.innerWidth <= 991) ? true : false;

  }
  private showPlayIcon(value): void {
    if (value) {
      if (this.video) {
        this.pauseVideo = true;
        $('.playerInfoControls').css({'display': 'none'});
      }
    } else {
      if (this.video) {
        this.pauseVideo = false;
      }
    }
  }
  private viewAll(): void {
    let tempTitle;
    this.gtm.GAsubCategory = '';
    this.gtm.clearContentClickDetails();
    // if (this.tvShowData && this.tvShowData.extended && this.tvShowData.extended.seo_title) {
    //         tempTitle = (this.tvShowData.extended.seo_title !== null || this.tvShowData.extended.seo_title !== undefined || this.tvShowData.extended.seo_title !== '') ? this.tvShowData.extended.seo_title : this.tvShowData.original_title;
    //    } else {
    //         tempTitle = (this.tvShowData.seo_title && (this.tvShowData.seo_title !== null || this.tvShowData.seo_title !== undefined || this.tvShowData.seo_title !== '')) ? this.tvShowData.seo_title : this.tvShowData.original_title;
    // }
    tempTitle = this.tvShowData.original_title;
   if (this.episodeInfo.season_details.index !== 1) {
      this.routeLink.navigate([this.baseCategory , this.commonService.convertToLowercase(tempTitle) , this.tvShowData.id, 'season-' + this.episodeInfo.season_details.index, 'episodes']);
    } else {
      this.routeLink.navigate([this.baseCategory , this.commonService.convertToLowercase(tempTitle) , this.tvShowData.id, 'episodes']);
    }
  }
 private adApiCall(): void {
   let userType, adResponse, companionAdResponse, id, adApiTimeoutValue, countyCode, countryValue;
   // id = this.showPage ? this.id : this.episodeID;
   id = this.episodeID;
   countyCode = this.settingsService.getCountry();
   countryValue = this.settingsService.getCountryValueNew();
   if (countyCode !== 'IN') {
     adApiTimeoutValue = countryValue && countryValue[0] && countryValue[0].video_ads_api_timeout ? countryValue[0].video_ads_api_timeout : environment.adApiTimeOut;
   } else {
     adApiTimeoutValue = environment.adApiTimeOut;
   }
   userType = this.commonService.getUserType();
    this.videoService.getAdData(id, 'vod').takeUntil(this.ngUnsubscribe).timeout(adApiTimeoutValue).subscribe(value => {
      if (value && value._body) {
        try {
          adResponse = JSON.parse(value._body);
        } catch (error) {
          this.videoAdData = {};
        }
        if (adResponse && adResponse.companion_ads && adResponse.companion_ads[0] && adResponse.companion_ads[0][userType]) {
          companionAdResponse = adResponse.companion_ads[0][userType];
        }
        if (adResponse.video_ads && adResponse.video_ads[0]) {
          this.videoAdData = {
            'type': adResponse.video_ads[0].type,
            'intervals': adResponse.video_ads[0].intervals,
            'ads_visibility': adResponse.video_ads[0].ads_visibility
          };
        } else {
          this.videoAdData = {};
        }
        // if (companionAdResponse && companionAdResponse.ads_visibility && companionAdResponse.ad_data && companionAdResponse.ad_data.length > 0) {
        //   this.adCall(companionAdResponse.ad_data);
        // }
      } else {
        this.videoAdData = {};
      }
    }, err => {
      this.videoAdData = {};
      this.gtm.sendErrorEvent('api', err);
    });
 }

private adCall(response: any): any {
  // let  desktopAd1, desktopAd2, mobileAd1, mobileAd2;
  // mobileAd1 = false;
  // mobileAd2 = false;
  // desktopAd1 = false;
  // desktopAd2 = false;
    this.destroyAds();
    this.firstcall = false;

    this.adObject = response;
    if (this.adObject.length === 1) {
      this.adObject.splice((this.addPaddingCast && this.countryCode === 'RU') ? 0 : 1, 0, {});
    }
    for (let i = 0; i < this.adObject.length; i++) {
      this.adObject[i].ad_style = this.commonService.getAdType(this.adObject[i].ad_type);
      this.googleAdCreation(this.adObject[i], (i === 0 && !this.addPaddingCast) ? 'square' : 'native')
    }
}

private destroyAds(): any {
  // this.googletagAvailable = this.localstorage.getItem('googletag')
  this.googletagAvailable = this.commonService.checkGoogleTag();
  if (this.googletagAvailable === 'true' && googletag.destroySlots) {
    googletag.destroySlots();
  }
  let adFoxtagAvailable;
  adFoxtagAvailable = this.commonService.checkAdFoxTag();
  if (adFoxtagAvailable === 'true' && this.window.Ya.adfoxCode.destroy) {
  // if (adFoxtagAvailable === 'true' && this.window.Ya && this.window.Ya.adfoxCode && this.window.Ya.adfoxCode.destroy) {
    this.window.Ya.adfoxCode.destroy();
  }
  // clear all timers in the array
  if (this.timer && this.timer.length) {
    for (let i = 0; i < this.timer.length; i++) {
      clearTimeout(this.timer[i]);
    }
  }
}

public googleAdCreation (nativeTag: any, type: any) {
  if (nativeTag && nativeTag && nativeTag.div_id) {
    switch (nativeTag.ad_provider) {
      case 'adfox':
        let adFoxtagAvailable;
        adFoxtagAvailable = this.commonService.checkAdFoxTag();
        if (adFoxtagAvailable === 'true' && nativeTag.owner_id && nativeTag.params) {
          this.adFoxCreation(nativeTag.div_id, nativeTag.owner_id, nativeTag.params , type);
        }
        break;
      default:
        this.googletagAvailable = this.commonService.checkGoogleTag();
        if (this.googletagAvailable === 'true' && nativeTag.ad_tag) {
          this.adCreation(nativeTag, type);
        }
        break;
    }
  }
}

public adFoxCreation(id: any, owner_id: any, params: any, adType: any) {
  let adFoxtagAvailable;
  adFoxtagAvailable = this.commonService.checkAdFoxTag();
  if (adFoxtagAvailable === 'true') {
    let scope;
    scope = this;
    this.timer.push(setTimeout(function() {
      this.window.Ya.adfoxCode.create({
        ownerId: owner_id,
        containerId: id,
        params: params,
        onLoad: function(data) { 
          // console.log(data, 'onLoad');
          scope.noAd = false;
        },
        // onRender: function(render) { console.log(render, 'onRender') },
        onError: function(error) {
          // console.log(error, 'onError');
          $('#' + id).hide();
          scope.noAd = true;
        },
        onStub: function(stub) {
          // console.log(stub, 'onstub');
          $('#' + id).hide();
          scope.noAd = true;
        }
      });
    }, 0));
  } else {
    $('#' + id).hide();
  }
}

public adCreation(nativeTag: any, adType: any) {
  this.googletagAvailable = this.commonService.checkGoogleTag();
  if (this.googletagAvailable === 'true') {
    let scope;
    scope = this;
    this.timer.push(setTimeout(function() {
      if (googletag.apiReady) {
        googletag = googletag || {};
        googletag.cmd = googletag.cmd || [];
        googletag.cmd.push(function() {
          googletag.pubads().enableSingleRequest();
          googletag.pubads().addEventListener('slotRenderEnded', function(event) {
              if (event.slot === scope.adSlot && (!event.isEmpty)) {
                scope.noAd = false;
              } else if (event.slot === scope.adSlot && (event.isEmpty)) {
                scope.noAd = true;
                // ad slot is not empty
              }
          });
          if (adType === 'square') {
            scope.adSlot = scope.commonService.defineAdSlot(nativeTag);
          } else {
            scope.commonService.defineAdSlot(nativeTag);
          }
          googletag.enableServices();
        });
        googletag.cmd.push(function() { googletag.display(nativeTag.div_id); });
      }
    }, 0));
  }
}

  private setRating(): void {
    if (this.episodeInfo.rating) {
        for (let i = 0; i < this.episodeInfo.rating; i++) {
          this.rating.push(i);
        }
    }
  }
  private getRating(idx): any {
     let rating;
     rating = (this.rating.indexOf(idx) > -1) ? this.assetbasepath + 'assets/common/star_filled_icon.png' : this.assetbasepath + 'assets/common/star_empty_icon.png';
    return rating;
  }
  private getEpisodeId(): void {
    let dataObject, country_code, userType;
    dataObject = new TvShowApi(this.http, null, this.configUser);
    country_code = this.settingsService.getCountry();
    userType = this.commonService.getUserType();
    dataObject.v1TvshowByIdGet(this.id, null, country_code, null, null, userType).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
      // if (value && value.seasons && value.seasons[0] && value.seasons[0].episodes && value.seasons[0].episodes[0]) {
      //   this.setLatest(value, value.seasons[0].episodes[0].id, value.seasons[0].episodes[0]);
      // }  else if (value && value.seasons && value.seasons[0] && value.seasons[0].trailers && value.seasons[0].trailers[0]) {
      //     this.setLatest(value, value.seasons[0].trailers[0].id, value.seasons[0].trailers[0]);
      // } else if (value && value.seasons && value.seasons[0] && value.seasons[0].teasers && value.seasons[0].teasers[0]) {
      //     this.setLatest(value, value.seasons[0].teasers[0].id, value.seasons[0].teasers[0]);
      // } else if (value && value.seasons && value.seasons[0] && value.seasons[0].promos && value.seasons[0].promos[0]) {
      //     this.setLatest(value, value.seasons[0].promos[0].id, value.seasons[0].promos[0]);
      // } else if (value && value.seasons && value.seasons[0] && value.seasons[0].previews && value.seasons[0].previews[0]) {
      //     this.setLatest(value, value.seasons[0].previews[0].id, value.seasons[0].previews[0]);
      // } else {
      //   this.showError();
      // }
      if (value && value.seasons && value.seasons[0]) {
        if (value && value.seasons && value.seasons[0] && value.seasons[0].episodes && value.seasons[0].episodes[0]) {
          this.setLatest(value, value.seasons[0].episodes[0].id, value.seasons[0].episodes[0]);
        } else if (this.configData && this.configData.new_tvshows && this.configData.new_tvshows.length > 0) {
          let other_content, i;
          other_content = false;
          for (let j = 0; j < this.configData.new_tvshows.length; j++) {
            i = this.configData.new_tvshows[j];
            if (value.seasons[0][i] && value.seasons[0][i][0]) {
              other_content = true;
              this.setLatest(value, value.seasons[0][i][0].id, value.seasons[0][i][0]);
              break;
            }
            if ((j === (this.configData.new_tvshows.length - 1)) && !other_content) {
              this.showError();
            }
          }
        } else {
          this.showError();
        }
      } else {
        // if(value.age_rating){
        //   this.contentAgeRating = value.age_rating;
        // }
        this.showError();
      }
      }, error => {
        this.gtm.sendErrorEvent('api', error);
        if (error.status === 401 && this.apiRetryCount < this.apiRetry) {
          this.tokenApiCall('tvshows', false);
        } else if (error.status === 404) {
          this.routeLink.navigate(['/pagenotfound']);
        } else {
          this.showError();
        }
      });
  }
  private showError(): any {
    this.error = true;
    this.headerservicesService.breadCrump('');
    $('#loaderPage').css('display', 'none');
  }
  private setLatest(value, id, episodeData): void {
    this.tvShowDataLatest = value;
    this.adoric_event(this.tvShowDataLatest);
    this.episodeID = id;
    this.apiRetryCount = 1;
    // this.startVideo();
    this.setActualEpisodeInfo(episodeData);
  }
  private startVideo(): void {
    let dataObject1, country_code, userType;
    // let date, assetType, activePlan;
    this.configUser = {
      apiKey: '',
      username: ' ',
      password: ' ',
      accessToken: ' ',
      withCredentials: false
    };
    dataObject1 = new EpisodeApi(this.http, null, this.configUser);
    country_code = this.settingsService.getCountry();
    userType = this.commonService.getUserType();
    dataObject1.v1EpisodeByIdGet(this.episodeID, null, null, country_code, null, null, null, userType).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe( value1 => {
    this.setActualEpisodeInfo(value1);
    }, error => {
        this.gtm.sendErrorEvent('api', error);
        if (error.status === 401 && this.apiRetryCount < this.apiRetry) {
              this.tokenApiCall('startVideo', true);
        } else if (error.status === 404) {
          this.routeLink.navigate(['/pagenotfound']);
        } else {
          this.showError();
        }
    });
  }

  private setActualEpisodeInfo(value1): any {

    let date, assetType, activePlan;
      // console.log(value1,'episodeResponce')
      if (value1) {
        if (!value1.business_type) {
          value1.business_type = value1.tvshow_details.business_type;
        }
        this.titleHeader = value1.title;
        this.showTitleHeader = value1.tvshow_details.title;

           if (value1.release_date && value1.release_date !== null  && value1.release_date !== undefined) {
             this.episodeReleaseDate = value1.release_date;
           } else {
             this.episodeReleaseDate = '';
           }
      this.episodeInfo = value1;
      this.actualEpisodeInfo = this.episodeInfo;
      // this.contentAgeRating = this.actualEpisodeInfo.age_rating;
       this.showAdult = this.loginToken ? false : (this.episodeInfo.age_rating === 'A' ? true : false);
      this.episodeInfo.original_title  = (this.episodeInfo.original_title !== (null || undefined)) ? this.episodeInfo.original_title : 'title';
      this.episodeNo = value1.index;
      this.episodeId = value1.id;
        this.setTvshowdataHTML(value1);
      // this.description = this.episodeInfo.description;
      let country_code = this.settingsService.getCountry();
      if (country_code !== 'IN') {
          this.description = (this.episodeInfo.description) && (this.episodeInfo.description.length > 0) ? this.episodeInfo.description : 'NA';  
      } else {
        if ( this.episodeInfo.extended && this.episodeInfo.extended.digital_long_description_web) {
          this.description = (this.episodeInfo.extended.digital_long_description_web.length > 0) ? this.episodeInfo.extended.digital_long_description_web : 'NA';
        } else {
          this.description = (this.episodeInfo.description) && (this.episodeInfo.description.length > 0) ? this.episodeInfo.description : 'NA';
        }
      }
      this.checkDesLen(this.episodeInfo.description);
      if (this.episodeInfo.season != null) {
        this.seasons_id =  this.episodeInfo.season.id;
      }

      if (this.episodeInfo && this.episodeInfo.season_details && this.episodeInfo.season_details.title ) {
         this.selectedItem = this.episodeInfo.season_details.orderid;
      }
      this.setRating();
      // this.showAutoplayUI =  (this.episodeInfo.asset_subtype === 'episode' || this.episodeInfo.asset_subtype === 'sample_premium')  ? true : false;
      this.showepisodeTitle = (this.episodeInfo.asset_subtype !== 'episode') ? true : false;
      date = this.dateChange(this.episodeInfo.release_date, this.monthNames, false);
      this.releaseDate = (date !== '') ? '- ' + date  :   '';
      if (this.loginToken) {
                assetType = this.subscription.checkPlanApiSuccess(true);
                activePlan = this.subscription.checkPlanApiSuccess(false);
            } else {
              assetType = [], activePlan = [];
            }

           activePlan = (activePlan === undefined || activePlan.length <= 0) ? false : true;
           this.tvShowData = this.tvShowDataLatest || this.episodeInfo.tvshow_details;
           // this.tvShowData = this.episodeInfo.tvshow_details;
                          this.availableChannelOriginal = (this.tvShowData.channels && this.tvShowData.channels !== (null && undefined) && this.tvShowData.channels.length > 0) ? this.tvShowData.channels.map(function(elem) {return elem.original_title; }).join(', ') : ' ';
        this.zeeOriginalShow = (this.tvShowData.asset_subtype === 'original') ? true : false;
      this.showTitle = this.tvShowData.title;
      // console.log(this.showTitle,'this.showTitle')
           this.tvShowsGenreEng  = (this.tvShowData.genres && this.tvShowData.genres !== (null && undefined) && this.tvShowData.genres.length > 0) ? this.tvShowData.genres.map(function(elem) {return elem.id; }).join(',') : ' ';
            this.gAChannelOriginal = (this.tvShowData.channels && this.tvShowData.channels !== (null && undefined) && this.tvShowData.channels.length > 0) ? this.tvShowData.channels.map(function(elem) {return elem.original_title; }).join(',') : 'NA';
      this.assetSubtype = (this.tvShowData.asset_subtype === 'original') ? 'zeeOriginals' : 'tvshows';
      this.baseCategory = (this.tvShowData.asset_subtype === 'original') ? 'zee5originals/details/' : 'tvshows/details/';
      this.genresZeo = (this.tvShowData.genres && this.tvShowData.genres !== (null && undefined) && this.tvShowData.genres.length > 0) ? this.tvShowData.genres.map(function(elem) {return elem.value; }) : ' ';
          if (this.actualEpisodeInfo.business_type && this.actualEpisodeInfo.business_type.indexOf('premium') !== -1) {
                this.premium =  (this.actualEpisodeInfo.asset_subtype !== 'trailer') ? true : false;
                if (this.actualEpisodeInfo.asset_subtype === 'trailer') {
                  this.episodeInfo.business_type = 'advertisement_downloadable';
                  this.actualEpisodeInfo.business_type = 'advertisement_downloadable';
                }

                 this.premium = (this.actualEpisodeInfo.asset_subtype === 'sample_premium') ? false : this.premium;
                // this.premiumShow = true;
                this.noAd = true;
                if ((this.tvShowData.business_type.indexOf('premium') === -1)) {
                  this.premiumShow = false;
                  this.showbeforeTVpopup(this.tvShowData.business_type, this.actualEpisodeInfo.business_type);
                } else {
                this.premiumShow = true;
                  if ((assetType.indexOf('6') === -1) && this.actualEpisodeInfo.asset_subtype !== 'trailer') {
                      this.showGetPremium = true;
                      this.trailerApi(this.premium);
                  } else {
                    this.checkSubscription();
                  }
                 if (!this.firstcall && googletag.destroySlots) {
                  googletag.destroySlots();
                }

              }

            } else {
                this.premium = false;

              if (this.tvShowData.business_type.indexOf('premium') === -1) {
                this.premiumShow = false;
              } else {
                this.premiumShow = true;
              }
              // this.premiumShow = false;
              // this.embedLinkVisibility();
              this.checkSubscription();
              // if (!activePlan) {
              //   this.adCall();
              // } else {
              //                   this.noAd = true;
              // }
            }


            if (this.tvShowDataLatest) {
              this.tvShowData = this.tvShowDataLatest;
              this.settvshowData();
              // this.setTvshowdataHTML(this.tvShowData)
            } else {
              this.tvshows();
            }
            this.setData();
           // $('#auto-loader-episode').css('display', 'none');
     } else {
        this.showError();
     }
              this.embedLinkVisibility();
  }
  private checkSubscription(): void {
          this.hideLoader();
          this.startVideoEpisode(true);
  }
  private hideLoader(): void {
          this.Resize();
  }
  private tvshows(): void {
    let dataObject, country_code, id, userType;
    dataObject = new TvShowApi(this.http, null, this.configUser);
    country_code = this.settingsService.getCountry();
    id = this.episodeInfo.tvshow_details.id;
    userType = this.commonService.getUserType();
    dataObject.v1TvshowByIdGet(id, null, country_code, null, null, userType).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
      this.tvShowData = value;
      this.adoric_event(this.tvShowData);
      this.apiRetryCount = 1;
      this.settvshowData();
        }, error => {
          this.gtm.sendErrorEvent('api', error);
            if (error.status === 401 && this.apiRetryCount < this.apiRetry) {
              this.tokenApiCall('tvshows', false);
            } else if (error.status === 404) {
            this.routeLink.navigate(['/pagenotfound']);
          } else {
              this.tvShowData = this.episodeInfo.tvshow_details;
              this.settvshowData();
              // this.setTvshowdataHTML(this.tvShowData)
          }
        });
    this.showDetails(this.tvShowData);
  }
  private ageratefunction(): any {
       let localcountyCode, configCountries;
          localcountyCode = this.settingsService.getCountry();
          // console.log(localcountyCode);
          configCountries = this.configData && this.configData.AgeDisplay && this.configData.AgeDisplay.countries ? this.configData.AgeDisplay.countries : [];
      for (let i = 0; i < configCountries.length; i++) {
        let enableflag;
       if (this.configData.AgeDisplay && this.configData.AgeDisplay.enable !== null && this.configData.AgeDisplay.enable !== undefined ) {
          enableflag = this.configData.AgeDisplay.enable;
           if (enableflag) {
                if (localcountyCode === configCountries[i] || configCountries.length === 0 ) {
                  this.agetake = enableflag;
                   break;
                 } else {
                  this.agetake = false;
                 }
           } else {
              if (localcountyCode === configCountries[i] || configCountries.length === 0) {
                this.agetake = enableflag;
                 break;
               } else {
                this.agetake = enableflag;
               }
           }
         } else {
            this.agetake = false;
         }
       }
      
}
  private settvshowData(): void {
     let  tvshowTitle, episodeTitle, tempTitle, epiTitle;
     this.showTitle = this.tvShowData.title;
     if ( this.tvShowData.seasons != null ) {
            this.seasonsList = this.tvShowData.seasons;
      }
      if (this.seasonsList.length > 1) {
        this.showDropdrown = true;
      } else {
        this.showDropdrown = false;
      }
      this.showTitleHeader = this.tvShowData.title;
      let country_code = this.settingsService.getCountry();
      if (country_code !== 'IN') {
        this.showDescription = (this.tvShowData.description) && (this.tvShowData.description.length > 0) ? this.tvShowData.description : 'NA';
      } else {
      if ( this.tvShowData.extended && this.tvShowData.extended.digital_long_description_web) {
        this.showDescription =  (this.tvShowData.extended.digital_long_description_web.length > 0) ? this.tvShowData.extended.digital_long_description_web : 'NA';
      }  else {
        this.showDescription = (this.tvShowData.description) && (this.tvShowData.description.length > 0) ? this.tvShowData.description : 'NA';
      }
    }
      this.checkDesLen(this.showDescription);
      this.showGenres = (this.tvShowData.genres && this.tvShowData.genres !== (null && undefined) && this.tvShowData.genres.length > 0) ? this.tvShowData.genres.map(function(elem) {return elem.value; }) : [];
      this.showRating = this.tvShowData && this.tvShowData.age_rating ? this.tvShowData.age_rating : '';
      let ageratingList, countryList;
            countryList = this.settingsService.getCountryValueNew();
            ageratingList = countryList[0].age_rating; // age rating number json
            let validText;
             if (ageratingList && ageratingList[this.showRating]) {
                if ( ageratingList[this.showRating] === '0' ) {
                     this.valid_string = this.translate.instant('MESSAGES.FOR_ALL');
                } else {
                this.translate.get(['MESSAGES.AGE_RATING']).subscribe(value => {
                validText = value['MESSAGES.AGE_RATING'];
                this.valid_string = validText.replace(/<age>/g, +  ageratingList[this.showRating]);
                });
              }
            } else {
                 this.valid_string = this.showRating;
             }
           this.ageratefunction();
      if (this.agetake) {
             this.showageRating = this.valid_string;
      } else {
             this.showageRating =this.showRating;
      }
      this.availableOnChannelShows = (this.tvShowData.channels && this.tvShowData.channels !== (null && undefined) && this.tvShowData.channels.length > 0) ? this.tvShowData.channels.map(function(elem) {return elem.title; }).join(', ') : '';
      // console.log('availableOnChannelShows',this.availableOnChannelShows)
      if (this.tvShowData.seasons[this.actualEpisodeInfo.season.index - 1] && this.tvShowData.seasons[this.actualEpisodeInfo.season.index - 1].total_episodes) {
       this.total_ep = this.tvShowData.seasons[this.actualEpisodeInfo.season.index - 1].total_episodes;
       this.episodesString = this.tvShowData.seasons[this.actualEpisodeInfo.season.index - 1].total_episodes > 1 ? 'DETAILS.EPISODES' : 'DETAILS.EPISODE';
      }
        if (this.tvShowData.actors && this.tvShowData.actors[0] != null) {
            this.showCastPage = true;
            this.showactorsNames = this.tvShowData.actors;
        } else {
            this.showCastPage = false;
        }

      if (this.season) {
       let season_num;
       season_num = this.extractSeasonnumber(this.season);
       // if(season_num <= this.seasonsList.length){
       let flag = false;
        for (let i = 0 ; i < this.seasonsList.length; i++) {
         if (this.seasonsList[i].index === season_num) {
            this.selectedItem =  this.seasonsList[i].orderid;
            let season_number;
            season_number = this.extractSeason(this.selectedItem);
            // this.assignSeason(this.seasonsList[i].original_title, i, this.seasonsList[i].orderid);
            flag = true;
            break;
          } else {
            flag = false;
          }
        }
          if (!flag) {
            this.routerLink.navigate(['/pagenotfound']);
          }
      }
      /*else {
            for (let i = 0 ; i < this.seasonsList.length; i++) {
              if (this.seasonsList[i].index === 1) {
                  this.selectedItem =  this.seasonsList[i].title;
                  // this.assignSeason(this.seasonsList[i].original_title, i, this.seasonsList[i].orderid);
                  }
                }
      }
      */

     this.tvShowData.business_type  = (this.tvShowData.business_type !== (null || undefined)) ? this.tvShowData.business_type : 'free';
         // if (this.tvShowData && this.tvShowData.extended && this.tvShowData.extended.seo_title)  {
         //    tempTitle = (this.tvShowData.extended.seo_title !== null || this.tvShowData.extended.seo_title !== undefined || this.tvShowData.extended.seo_title !== '') ? this.tvShowData.extended.seo_title : this.tvShowData.original_title;
         // } else {
         //    tempTitle = (this.tvShowData.seo_title && (this.tvShowData.seo_title !== null || this.tvShowData.seo_title !== undefined || this.tvShowData.seo_title !== '')) ? this.tvShowData.seo_title : this.tvShowData.original_title;
         // }

         // if (this.actualEpisodeInfo && this.actualEpisodeInfo.extended && this.actualEpisodeInfo.extended.seo_title)  {
         //    epiTitle = (this.actualEpisodeInfo.extended.seo_title !== null || this.actualEpisodeInfo.extended.seo_title !== undefined || this.actualEpisodeInfo.extended.seo_title !== '') ? this.actualEpisodeInfo.extended.seo_title : this.actualEpisodeInfo.original_title;
         // }  else {
         //    epiTitle = (this.actualEpisodeInfo.seo_title && (this.actualEpisodeInfo.seo_title !== null || this.actualEpisodeInfo.seo_title !== undefined || this.actualEpisodeInfo.seo_title !== '')) ? this.actualEpisodeInfo.seo_title : this.actualEpisodeInfo.original_title;
         // }
        tempTitle = this.tvShowData.original_title;
        epiTitle = this.actualEpisodeInfo.original_title;
        tvshowTitle = this.commonService.convertToLowercase(tempTitle);
        episodeTitle = this.commonService.convertToLowercase(epiTitle);
              // if ((window.location.pathname.indexOf(this.baseCategory) < 0 || tvshowTitle !== this.name || this.tvShowData.id !== this.id || episodeTitle !== this.episodeName) && this.router2.substr(this.router2.lastIndexOf('/') + 1) !== 'latest') {
              //         if (window.location.search.length > 0) {
              //           // todo
              //         } else {
              //            this.location.replaceState(this.baseCategory + tvshowTitle + '/' + this.tvShowData.id + '/' + episodeTitle + '/' + this.episodeInfo.id);
              //         }
              //   }
                if ((window.location.pathname.indexOf(this.baseCategory) < 0 || tvshowTitle !== this.name || this.tvShowData.id !== this.id || episodeTitle !== this.episodeName)) {
                      if (window.location.search.length > 0) {
                        // todo
                      } else {
                        if (this.router2.substr(this.router2.lastIndexOf('/') + 1) === 'latest') {
                         this.location.replaceState(this.baseCategory + tvshowTitle + '/' + this.tvShowData.id + '/latest');
                        } else if (this.showPage) {
                         this.location.replaceState(this.baseCategory + tvshowTitle + '/' + this.tvShowData.id);
                        } else {
                         this.location.replaceState(this.baseCategory + tvshowTitle + '/' + this.tvShowData.id + '/' + episodeTitle + '/' + this.actualEpisodeInfo.id);
                        }
                      }
                }
            if (this.tvShowData.extended) {
              this.sort_order = ((this.tvShowData.extended.broadcast_state !== (null || undefined)) && this.tvShowData.extended.broadcast_state === 'ARCHIVE') ? 'ASC' : 'DESC';
              this.episodeTitle = (this.sort_order === 'ASC') ? 'DETAILS.EPISODES' : 'DETAILS.EPISODES_LATEST';
            }
          if (this.tvShowData.seasons && this.tvShowData.seasons !== null && this.tvShowData.seasons.length > 0) {
            if ((this.tvShowData.asset_subtype === 'original' || this.tvShowData.asset_subtype === 'tvshow') && this.premiumShow) {
                this.seasonApiConcat();
                this.premium = (this.actualEpisodeInfo.asset_subtype === 'sample_premium') ? false : this.premium;
            } else {
                         this.episodes(false);
           }
          } else {
            this.nextPlaying = false;
            this.episodes(false);
          }
        this.imageurlConstruction();

         // this.metaTagUpdate()
         // console.log(this.showTitle, 'this.showTitle',this.configData)
         this.loadMoreData(this.configData);
  }
  private loadMoreData(value: any) {
    let tvshowCorousalTags, tagName, data;
    tvshowCorousalTags = [];
    this.corousalData = [];
    if (this.seasonDataCarousal.length > 1) {
              tagName = 'DETAILS.SEASONS';
              data = { 'title': tagName , original_title: this.tvShowData.original_title, 'type': 'catchUp', 'content': this.seasonDataCarousal, 'more': true, 'original_length': 1, 'category': (this.seasonDataCarousal[0].asset_subtype), 'tvshow_type': this.tvShowData.asset_subtype};
              this.corousalData.push(data);
    }
    if (this.tvShowData && this.tvShowData.related && this.tvShowData.related.length > 0) {
      let userType, country_code, countrylist;
      userType = this.commonService.getUserType();
      country_code = this.settingsService.getCountry();
      countrylist = this.settingsService.getCountryValueNew();
      if (countrylist && countrylist.length > 0 && countrylist[0].recommendations && countrylist[0].recommendations === true) {
        // if(this.configData && this.configData.talamoos_allowed_countries && this.configData.talamoos_allowed_countries.indexOf(country_code) >= 0) {
        let x;
        x = new CollectionApi(this.http, null, this.configUser);
        x.v1RecommendationByAssetIdGet(this.episodeID, null, null, null, country_code, null, null, null, userType, null).takeUntil(this.ngUnsubscribe).subscribe(Rvalue => {
          if (Rvalue.buckets && Rvalue.buckets.length > 0 ) {
            this.talamoosEnable = true;
            this.adoric_event(Rvalue);
            for ( let i = 0; i < Rvalue.buckets.length; i++ ) {
              data = { 'title': Rvalue.buckets[i].title, 'original_title': Rvalue.buckets[i].original_title , 'type': 'tvshows', 'content': Rvalue.buckets[i].items, 'modelname': Rvalue.buckets[i].modelName};
              this.corousalData.push(data);
              }
            }
            this.createMoreCarousels(value);
            this.createRelatedCarousals();
        }, err => {
          this.createMoreCarousels(value);
          this.createRelatedCarousals();
        });
      } else {
        this.createMoreCarousels(value);
        this.createRelatedCarousals();
      }
    } else {
      this.createMoreCarousels(value);
      this.createRelatedCarousals();
    }
  }
  // function to create multiple related carousals.
  public createRelatedCarousals() {
    let data;
    if (!this.talamoosEnable) {
      if (this.actualEpisodeInfo && this.actualEpisodeInfo.related_tvshows_ss && this.actualEpisodeInfo.related_tvshows_ss.items && this.actualEpisodeInfo.related_tvshows_ss.items.length > 0) {
        data = { 'title': this.actualEpisodeInfo.related_tvshows_ss.title, 'original_title': this.actualEpisodeInfo.related_tvshows_ss.original_title, 'type': 'tvshows', 'content': this.actualEpisodeInfo.related_tvshows_ss.items};
        this.corousalData.push(data);
      } else {
        if (this.tvShowData && this.tvShowData.related && this.tvShowData.related.length > 0) {
          data = { 'title': 'SUSCRIPTION.RELATED_SHOWS', 'original_title': 'Related Shows', 'type': 'tvshows', 'content': this.tvShowData.related, 'trailer': true};
          this.corousalData.push(data);
        }
      }
    }
    if (this.actualEpisodeInfo && this.actualEpisodeInfo.related_collections_ss && this.actualEpisodeInfo.related_collections_ss.items && this.actualEpisodeInfo.related_collections_ss.items.length > 0) {
      data = { 'title': this.actualEpisodeInfo.related_collections_ss.title, 'original_title': this.actualEpisodeInfo.related_collections_ss.original_title, 'type': 'tvshows', 'content': this.actualEpisodeInfo.related_collections_ss.items};
      this.corousalData.push(data);
    }
    if (this.actualEpisodeInfo && this.actualEpisodeInfo.related_movies_ss && this.actualEpisodeInfo.related_movies_ss.items && this.actualEpisodeInfo.related_movies_ss.items.length > 0) {
      data = { 'title': this.actualEpisodeInfo.related_movies_ss.title, 'original_title': this.actualEpisodeInfo.related_movies_ss.original_title, 'type': 'movies', 'content': this.actualEpisodeInfo.related_movies_ss.items};
      this.corousalData.push(data);
    }
    if (this.actualEpisodeInfo && this.actualEpisodeInfo.related_videos_ss && this.actualEpisodeInfo.related_videos_ss.items && this.actualEpisodeInfo.related_videos_ss.items.length > 0) {
      data = { 'title': this.actualEpisodeInfo.related_videos_ss.title, 'original_title': this.actualEpisodeInfo.related_videos_ss.original_title, 'type': 'videos', 'content': this.actualEpisodeInfo.related_videos_ss.items};
      this.corousalData.push(data);
    }
    if (this.actualEpisodeInfo && this.actualEpisodeInfo.related_channels_ss && this.actualEpisodeInfo.related_channels_ss.items && this.actualEpisodeInfo.related_channels_ss.items.length > 0) {
      data = { 'title': this.actualEpisodeInfo.related_channels_ss.title, 'original_title': this.actualEpisodeInfo.related_channels_ss.original_title, 'type': 'channels', 'content': this.actualEpisodeInfo.related_channels_ss.items, 'original_length': this.actualEpisodeInfo.related_channels_ss.items.length};
      this.corousalData.push(data);
    }
  }

    public createMoreCarousels(value) {
      let tvshowCorousalTags, seasonIndex;
      // seasonIndex = this.seasonData.index - 1
      seasonIndex = this.seasonData.orderno;
      tvshowCorousalTags = value.region.IN.India.tvshow_carousels_more ? value.region.IN.India.tvshow_carousels_more : [];
      for (let i = 0; i < tvshowCorousalTags.length; i++) {
        // console.log('seasonDataCarousal',this.seasonDataCarousal,[tvshowCorousalTags[i]],'error',this.seasonDataCarousal[tvshowCorousalTags[i]])
        if (this.seasonDataCarousal[seasonIndex] && this.seasonDataCarousal[seasonIndex][tvshowCorousalTags[i]].length > 0) {
          let data1, tagData, tagName1;
          tagData = this.seasonDataCarousal[seasonIndex][tvshowCorousalTags[i]];
          switch (tvshowCorousalTags[i]) {
            case 'webisodes' :
            tagName1 = ( this.tvShowData && this.tvShowData.extended && this.tvShowData.extended.production_design && (this.tvShowData.extended.production_design !== null || this.tvShowData.extended.production_design !== ''))
             ? this.tvShowData.extended.production_design : value.carousels_labels_more[tvshowCorousalTags[i]][this.displaylanguage];
            break;
            case 'clips' :
            tagName1 = ( this.tvShowData && this.tvShowData.extended && this.tvShowData.extended.set_decoration && (this.tvShowData.extended.set_decoration !== null || this.tvShowData.extended.set_decoration !== ''))
             ? this.tvShowData.extended.set_decoration : value.carousels_labels_more[tvshowCorousalTags[i]][this.displaylanguage];
            break;
            case 'previews' :
            tagName1 = ( this.tvShowData && this.tvShowData.extended && this.tvShowData.extended.production_company && (this.tvShowData.extended.production_company !== null || this.tvShowData.extended.production_company !== ''))
             ? this.tvShowData.extended.production_company : value.carousels_labels_more[tvshowCorousalTags[i]][this.displaylanguage];
            break;
            case 'performances' :
            tagName1 = ( this.tvShowData && this.tvShowData.extended && this.tvShowData.extended.sponsor && (this.tvShowData.extended.sponsor !== null || this.tvShowData.extended.sponsor !== ''))
             ? this.tvShowData.extended.sponsor : value.carousels_labels_more[tvshowCorousalTags[i]][this.displaylanguage];
            break;
            default :
            tagName1 = value.carousels_labels_more[tvshowCorousalTags[i]][this.displaylanguage];
          }
          if (tagData[0].asset_subtype === 'trailer') {
            if (tagData.length > 1) {
              data1 = { 'title': tagName1 , original_title: this.tvShowData.original_title, 'type': 'catchUp', 'content': tagData, 'more': true, 'original_length': 1, 'category': (tagData[0].asset_subtype), 'tvshow_type': this.tvShowData.asset_subtype, next_url: this.seasonDataCarousal[seasonIndex]['next_' + tagData[0].asset_subtype + 's_api']};
            }
            this.trailer1 = true;
            this.trailerData = tagData;
          } else {
            data1 = { 'title': tagName1 , original_title: this.tvShowData.original_title, 'type': 'catchUp', 'content': tagData, 'more': true, 'original_length': 1, 'category': (tagData[0].asset_subtype), 'tvshow_type': this.tvShowData.asset_subtype, next_url: this.seasonDataCarousal[seasonIndex]['next_' + tagData[0].asset_subtype + 's_api']};
          }
          if (data1) {
            this.corousalData.push(data1);
          }
        }
      }
    }

     public imageurlConstruction(): any {
      this.image_url = ( this.episodeInfo.list_image != null ) ? this.imageBasepath + this.id + '/list/' + '1920x770/' + this.tvShowData .list_image  + '?imwidth=1920&impolicy=akamai_vidz1_zee5_com-IPM' : this.onErrorBanner;
        this.image_url_mobile =  ( this.episodeInfo.list_image != null ) ? this.imageBasepath + this.id + '/list/' + '1440x810/' + this.tvShowData .list_image  + '?imwidth=1440&impolicy=akamai_vidz1_zee5_com-IPM' : this.onErrorBanner_mob;
        this.onChangeSize();
    }
    private onChangeSize(): void {
      this.imageSrc = (window.innerWidth < 480) ? this.image_url_mobile : this.image_url;
      this.onErrorSrc = (window.innerWidth < 480) ? this.onErrorBanner_mob : this.onErrorBanner;
       if (navigator.userAgent.match(/mobile/i) && !navigator.userAgent.match(/iPad/i)) {
        this.isStaticVdeoEnable = true;
      } else {
        this.isStaticVdeoEnable = false;
      }
    }
  private tokenApiCall(name, status): void {
      this.apiRetryCount ++;
      this.commonService.refreshToken().then(
        () => {
          this[name]();
        },
        () => {
          if (status) {
            this.showError();
          }
          $('#loaderPage').css('display', 'none');
        },
        );
    }
      private imageError(event: any): void {
      if (event.srcElement) {
        event.srcElement.src = (this.isStaticVdeoEnable) ? this.assetbasepath + 'assets/default/banner_mobile.png' : this.assetbasepath + 'assets/default/banner.png';
      } else {
        event.currentTarget.src = (this.isStaticVdeoEnable) ? this.assetbasepath + 'assets/default/banner_mobile.png' : this.assetbasepath + 'assets/default/banner.png';
      }
    }
  private setData(): void {
      let breadCrumbArray, label;
       label = (this.actualEpisodeInfo.asset_subtype === 'trailer') ? 'BREADCRUMB.TRAILER' : (this.actualEpisodeInfo.asset_subtype === 'clip') ? this.actualEpisodeInfo.title : (this.actualEpisodeInfo.asset_subtype === 'webisode') ? 'BREADCRUMB.WEBISODE' : (this.actualEpisodeInfo.asset_subtype === 'preview') ? 'BREADCRUMB.PREVIEW' : 'BREADCRUMB.EPISODE';
       this.number = (this.actualEpisodeInfo.asset_subtype === 'trailer' || this.actualEpisodeInfo.asset_subtype === 'clip') ? null : ' ' + this.episodeNo;
      if (this.showPage) {
        breadCrumbArray = [{'label': 'BREADCRUMB.HOME', 'url': '/', 'enable': true},
          {'label': (this.tvShowData.asset_subtype === 'original' ) ? 'BREADCRUMB.ZEEORIGINALS' : 'BREADCRUMB.SHOWS', 'url': (this.tvShowData.asset_subtype === 'original' ) ?  '/zee5originals' : '/tvshows' , 'enable': true},
          {'label': this.tvShowData.title, 'url': this.baseCategory + this.commonService.convertToLowercase(this.tvShowData.original_title) + '/' + this.tvShowData.id, 'enable': true}];
          // [{'label': 'BREADCRUMB.HOME', 'url': '/', 'enable': true},
          // {'label': (this.episodeInfo.tvshow.asset_subtype === 'original' ) ? 'BREADCRUMB.ZEEORIGINALS' : 'BREADCRUMB.SHOWS', 'url': (this.episodeInfo.tvshow.asset_subtype === 'original' ) ?  '/zee5originals' : '/tvshows' , 'enable': true},
          // {'label': this.episodeInfo.tvshow.title, 'url': this.baseCategory + this.commonService.convertToLowercase(this.episodeInfo.tvshow.original_title) + '/' + this.episodeInfo.tvshow.id, 'enable': true}];
      } else {
        breadCrumbArray = [{'label': 'BREADCRUMB.HOME', 'url': '/', 'enable': true},
          {'label': (this.tvShowData.asset_subtype === 'original' ) ? 'BREADCRUMB.ZEEORIGINALS' : 'BREADCRUMB.SHOWS', 'url': (this.tvShowData.asset_subtype === 'original' ) ?  '/zee5originals' : '/tvshows' , 'enable': true},
          {'label': this.tvShowData.title, 'url': this.baseCategory + this.commonService.convertToLowercase(this.tvShowData.original_title) + '/' + this.tvShowData.id, 'enable': true},
          {'number': this.number, 'label': label, 'url': this.baseCategory + this.commonService.convertToLowercase(this.tvShowData.original_title) + '/' + this.tvShowData.id + '/' + this.commonService.convertToLowercase(this.actualEpisodeInfo.original_title) + '/' + this.actualEpisodeInfo.id, 'enable': false}];
      // [{'label': 'BREADCRUMB.HOME', 'url': '/', 'enable': true},
      //     {'label': (this.episodeInfo.tvshow.asset_subtype === 'original' ) ? 'BREADCRUMB.ZEEORIGINALS' : 'BREADCRUMB.SHOWS', 'url': (this.episodeInfo.tvshow.asset_subtype === 'original' ) ?  '/zee5originals' : '/tvshows' , 'enable': true},
      //     {'label': this.episodeInfo.tvshow.title, 'url': this.baseCategory + this.commonService.convertToLowercase(this.episodeInfo.tvshow.original_title) + '/' + this.episodeInfo.tvshow.id, 'enable': true},
      //     {'number': this.number, 'label': label, 'url': this.baseCategory + this.commonService.convertToLowercase(this.episodeInfo.tvshow.original_title) + '/' + this.episodeInfo.tvshow.id, 'enable': false}];
      }
      this.headerservicesService.breadCrump(breadCrumbArray);
  }
  private seasonApiConcat(): void {
    let  concat;
              this.samplePremiumData = this.tvShowData.seasons && this.tvShowData.seasons.length > 0 && this.tvShowData.seasons[0].sample_premiums ? this.tvShowData.seasons[0].sample_premiums : [];
               concat = (this.samplePremiumData.length > 0) ? true : false;
              this.episodes(concat);
  }
  private episodes(eve): void {
        let episodes, index;
        // index = this.episodeInfo.season.index - 1
        index = this.tvShowData.seasons.findIndex(season => season.orderid === this.episodeInfo.season.index);

        if (this.tvShowData.seasons[index] && this.tvShowData.seasons[index].episodes) {
          episodes = this.tvShowData.seasons && this.tvShowData.seasons.length > 0 && this.tvShowData.seasons[index].episodes ? this.tvShowData.seasons[index].episodes : this.tvShowData.episodes ? this.tvShowData.episodes : [];
        } else {
          index = 0;
          episodes = this.tvShowData.seasons && this.tvShowData.seasons.length > 0 && this.tvShowData.seasons[index].episodes ? this.tvShowData.seasons[index].episodes : this.tvShowData.episodes ? this.tvShowData.episodes : [];
        }
       if (episodes.length > 0) {
           this.episodesData = (eve) ? this.samplePremiumData.concat(episodes.slice(0, 20)) : episodes.slice(0, 20);
       }
      this.seasonData = this.tvShowData.season;
      this.seasonData.total = this.tvShowData.seasons && this.tvShowData.seasons[0] ? this.tvShowData.seasons[0].total_episodes : 0;
      this.seasonData.index = this.episodeInfo.season.index;
      this.seasonData.orderno = index;
      if (this.tvShowData.seasons[index] && this.tvShowData.seasons[index].total_episodes) {
       this.total_ep = this.tvShowData.seasons[index].total_episodes;
       this.episodesString = this.tvShowData.seasons[index].total_episodes > 1 ? 'DETAILS.EPISODES' : 'DETAILS.EPISODE';
      }
      this.seasonDataCarousal = this.tvShowData.seasons;
      // this.seasonDataCarousal = this.tvShowData.seasons[this.seasonData.index - 1];
      this.samplePremium = eve;
      this.setseasonsData();
      this.callallEpisodes();
  }
  private callallEpisodes(): void {
    this.prevNext();
  }
  private setseasonsData(): void {

              // this.nextPlaying = (this.episodesData.length > 0) ? true : false;
              if (this.tvShowData.seasons[this.seasonData.orderno].episodes && this.tvShowData.seasons[this.seasonData.orderno].episodes.length > 0) {
                this.noEpisodes = false;
                this.nextEpisodes = { 'original_length': this.episodesData.length, 'title': 'DETAILS.ALL_EPISODES', 'original_title' : 'All Episodes', 'id' : this.tvShowData.id, 'type' : 'catchUp',  'content':  this.commonService.restrictLength(this.tvShowData.seasons[this.seasonData.orderno].episodes) , 'business_type': this.episodeInfo.business_type, 'parentType': 'seasons', 'assetSubType': this.tvShowData.asset_subtype, 'category' : this.episodeTitle === 'DETAILS.EPISODES_LATEST' ? 'Latest Episodes' : 'Episodes', 'link': 'tvshows', 'orderid': this.seasonData.index};
              } else {
                this.noEpisodes = true;
                this.nextEpisodes = {'original_length': 1, 'title': 'DETAILS.ALL_EPISODES', 'original_title' : 'All Episodes', 'id' : this.tvShowData.id, 'type' : 'catchUp',  'content':  this.commonService.restrictLength([this.tvShowData]) , 'business_type': this.episodeInfo.business_type, 'parentType': 'seasons', 'assetSubType': this.tvShowData.asset_subtype, 'category' : this.episodeTitle === 'DETAILS.EPISODES_LATEST' ? 'Latest Episodes' : 'Episodes', 'link': 'tvshows', 'orderid': this.seasonData.index};
              }
              this.getYIndex();
              // this.nextEpisodes = { 'original_length': this.episodesData.length, 'title': 'DETAILS.ALL_EPISODES', 'original_title' : 'All Episodes', 'id' : this.tvShowData.id, 'type' : 'catchUp',  'content':  this.commonService.restrictLength(this.tvShowData.seasons[this.seasonData.orderno].episodes) , 'business_type': this.episodeInfo.business_type, 'parentType': 'seasons', 'assetSubType': this.tvShowData.asset_subtype, 'category' : this.episodeTitle === 'DETAILS.EPISODES_LATEST' ? 'Latest Episodes' : 'Episodes', 'link': 'tvshows', 'orderid': this.seasonData.index};
              this.RTRMBLOCK = this.headerservicesService.getRemarketing();
              if (this.RTRMBLOCK !== true) {
              this.gtm.ZeoTapingEvents(this.showTitle, this.regionalLang, this.genresZeo.join(','), this.tvShowData.asset_subtype, this.episodeNo);
              }
  }
  private trailerApi(playback): void {
              let trailerData;

              if (this.tvShowDataLatest) {
                trailerData = this.tvShowDataLatest.seasons ? this.tvShowDataLatest.seasons[0].trailers : [];
              } else {
                trailerData = this.episodeInfo.tvshow_details && this.episodeInfo.tvshow_details.trailers ? this.episodeInfo.tvshow_details.trailers : [];
              }
               if (trailerData && trailerData.length > 0 && trailerData[0].asset_subtype && trailerData[0].asset_subtype === 'trailer') {
                 this.trailer = true;
                 this.trailer1 = true;
                 this.trailerInfo = trailerData;
                 this.headerservicesService.trailer = true;
                  if (playback && (!localStorage.getItem("trailLogin") || (localStorage.getItem("trailLogin") != 'true' && this.loginToken == null) )) {
                   this.startTrailer();
                   this.hideLoader();
                   // this.checkSubscription();
                 } else {
                   this.checkSubscription();
                 }
                 if(localStorage.getItem("trailLogin")){
                  localStorage.removeItem("trailLogin");
                }
               } else {
                 this.trailerInfo = null;
                 this.trailer = false;
                 this.trailer1 = false;
                 this.headerservicesService.trailer = false;
                 this.checkSubscription();
               }

  }
  private prevNext(): void {
   this.upnextDetails();
  }
  private upnextDetails(): any {
    let dataObject1, country_code, upnextString, type, userType;
    country_code = this.settingsService.getCountry();
    upnextString = 'Up Next';
    // if (this.sort_order === 'ASC') {
    //   type = 'next';
    // } else {
    //   type = 'previous';
    // }
    type = 'next';
    dataObject1 = new EpisodeApi(this.http, null, this.configUser);
    userType = this.commonService.getUserType();
    dataObject1.v1UpNextEpisode(this.seasons_id, this.episodeID, null, country_code, type , 1, 25 , null, userType).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe( upnextvalue => {
      this.autoLoader = false;
      this.upNextTitle = upnextvalue.title ? upnextvalue.title : upnextString;
      let episodes, upnextOrginalTitle;
      upnextOrginalTitle = upnextvalue.original_title ? upnextvalue.original_title : this.upNextTitle;
      episodes = upnextvalue.items && upnextvalue.items.length > 0 ? upnextvalue.items : [];
       if (episodes.length > 0) {
          this.upnextData =  episodes.slice(0, 20);
          this.nodata =  false;
       } else {
          this.nodata = true;
       }
      this.nextPlaying = (episodes.length > 0) ? true : false;
      this.upnextdataMobile = { 'original_length': episodes.length, 'title': this.upNextTitle, 'original_title' : upnextOrginalTitle, 'id' : this.tvShowData.id, 'type' : 'catchUp',  'content':  this.commonService.restrictLength(episodes) , 'parentType': 'episodes', 'assetSubType': this.tvShowData.asset_subtype, 'category' : upnextString, 'link': 'tvshows'};
      this.talamoosImpression = true;
      this.getYIndex();
    // console.log(this.upnextdataMobile,'this.nextPlaying')
    }, error => {
      this.nodata = true;
      this.gtm.sendErrorEvent('api', error);
      this.talamoosImpression = true;
      this.getYIndex();
    });
  }
  public getYIndex(): any {
    this.yIndex = 0;
    if (this.upnextdataMobile && this.upnextdataMobile.content && this.upnextdataMobile.content.length > 0) {
      ++this.yIndex;
    }
    if (this.nextEpisodes && this.nextEpisodes.content && this.nextEpisodes.content.length > 0) {
      ++this.yIndex;
    }
  }
  private videoChange(eve): void {
      if (eve) {
        this.videoData = [];
        if (this.episodeInfo.video_details) {
            let data;
            data = this.dataCreation(this.episodeInfo, (this.tvShowData || this.episodeInfo.tvshow_details));
            // data = this.dataCreation(this.episodeInfo, this.episodeInfo.tvshow_details);
                      this.videoData.push(data);
        }
      }
        if (this.videoService.enableCastView && !this.showSubscribe && !this.showLogin) {
          this.videoData ? (this.backgroundImage = this.videoService.getImageUrl(this.videoData[0], false)) : (this.backgroundImage =  false);
            this.castQueueObject = this.videoData;
            if (this.checkParental(this.episodeInfo.age_rating) > this.parental_age) {
              this.headerservicesService.parentalChange({'flag': true, 'type': 'pin' });
              this.parentalpin = true;
              this.video = false;
              if (!this.loginToken) {
                this.showAdult = true;
              }
            } else {
                      this.showAdult = this.loginToken ? false : (this.episodeInfo.age_rating === 'A' ? true : false);
                      if (!this.showAdult) {
                            this.videoService.castQueueObject = this.castQueueObject;
                            this.videoService.toggleQueueState(true);
                      }
            }
            return;
        }
        if (this.playcontent || this.showBeforeTV) {
          this.videoError();
        } else {
          this.video = false;
          if ($('#playImage').css('display') === 'none') {
            $('#playImage').css('display', 'block');
          }
          $('#noAccess').css('display', 'none');
          $('#noAccessSubs').css('display', 'none');
        }
      }

      private videoError(): void {
        if (this.episodeInfo.video_details) {
          if (this.checkParental(this.episodeInfo.age_rating) > this.parental_age) {
            this.headerservicesService.parentalChange({'flag': true, 'type': 'pin' });
            this.parentalpin = true;
            this.video = false;
          } else {
            if (this.loginToken) {
              this.video = true;
              this.showAdult = false;
              $('#noAccessSubs').hide();
            } else {
              this.video = (this.episodeInfo.age_rating === 'A') ? false : true;
              this.showAdult = !this.video;
            }
          }
        } else {
          this.video = false;
          this.callToast();
        }
      }
      private checkParental (age_rating: any) {
        if (age_rating === 'U') {
          return 1;
        } else if (age_rating === 'U/A') {
          return 2;
        } else if (age_rating === 'A') {
          return 2;
        } else {
          return 2;
        }
      }

      private checkDesLen(redDes): void {
        let len;
        redDes = this.showPage ? this.showDescription : this.description;
        len = redDes ? redDes.length : 0;
        this.dots = (redDes === 'NA' || len < 200) ? '' : '...';
        if (len < 200) {
          this.readText = '';
        } else {
            this.showReadMore = true;
            this.readText = 'DETAILS.READ_MORE';
            this.dots = '...';
        }
      }

     private toggleReadMore(): void {
       let desc;
       desc = this.showPage ? this.showDescription : this.description;
       this.readText = (this.textLimit > 200) ? 'DETAILS.READ_MORE' :  'DETAILS.READ_LESS';
       this.textLimit = (this.textLimit > 200) ? 200 : (desc ? desc.toString().length : 'NA');
       this.readArrow = (this.textLimit > 200) ? true :  false;
       this.dots = (this.readText === 'DETAILS.READ_MORE') ? '...' : '';
     }
      private callToast() {
        let p;
        p = this.document.getElementById('snackbar');
        if (p) {
           p.className = 'show';
           setTimeout(function() { p.className = p.className.replace('show', ''); }, 3000);
        }
      }
      public setParentId(): any {
        if (this.videoData && this.videoData[0]) {
          this.subscription.setParentId(this.videoData[0].id, this.actualEpisodeInfo.id);
        } else {
          this.subscription.setParentId(this.actualEpisodeInfo.id, this.actualEpisodeInfo.id);
        }
      }
      public updateRoute(): any {
        // localStorage.setItem('postSubscriptionRoute', this.actualEpisodeInfo.id);
        if(this.localstorage.getItem('country_code') !== 'IN'){
          this.localstorage.setItem("trailLogin", true)
        }
      }
      private dataCreation(data, tvshowData): any {
        let base, videoData;
        base = (this.assetSubtype === 'zeeOriginals') ? 'zee5originals' : 'tvshows';
        this.seoService.blueKaifunction(
               data.original_title,
               tvshowData.asset_subtype,
               data.asset_type,
               data.asset_subtype,
               this.tvShowsGenreEng.replace(',', ', '),
               data.video_details.audiotracks);
        this.linkservice.removeampLink();
        this.linkservice.addTag({ rel: 'amphtml', href: window.location.origin + '/amp/' + this.routeservice.getBaseLocation()  +  base + '/details/' + this.commonService.convertToLowercase(tvshowData.original_title) + '/' + tvshowData.id + '/' + this.commonService.convertToLowercase(data.original_title) + '/' + data.id} );
        videoData = {
          id: data.id,
          duration: data.duration,
          subtitles: (data.video_details && data.video_details.subtitles !== (null || undefined)) ? data.video_details.subtitles : [],
          audio_languages: (data.video_details && data.video_details.audiotracks !== (null || undefined)) ? data.video_details.audiotracks : [],
          drm: (data.video_details && data.video_details.is_drm !== (null || undefined)) ? data.video_details.is_drm : false,
          drm_keyid: (data.video_details && data.video_details.drm_key_id !== (null || undefined)) ? data.video_details.drm_key_id : '',
          type: 'vod',
          title: tvshowData.title ,
          title_en: tvshowData.original_title,
          season_no: data.season.index,
          episode_no:  this.zeeOriginalShow ? 'NA' : data.index ,
          episode_name: data.title,
          episode_name_en: data.original_title,
          channel_name: this.availableChannelOriginal,
          category: tvshowData.asset_subtype ,
          content_type: data.asset_subtype,
          genre: this.tvShowsGenreEng.replace(',', ', '),
          sub_genre: '' ,
          catch_up: 'N' ,
          series_id: tvshowData.id ,
          season_id: this.seasons_id,
          rating: data.rating,
          release_date: this.dateChange(data.release_date, this.months, false),
          business_type: data.business_type ? data.business_type : tvshowData.business_type,
          parent_business_type: tvshowData.business_type,
          parent_id: this.actualEpisodeInfo.id,
          description: data.description,
          image : data.list_image,
          stream_url_dash:  (data.video_details && data.video_details.url !== (null || undefined)) ? data.video_details.url : '',
          stream_url_hls:  (data.video_details && data.video_details.hls_url !== (null || undefined)) ? data.video_details.hls_url : '',
          asset_type: data.asset_type,
          share_url : base + '/details/' + this.commonService.convertToLowercase(tvshowData.original_title) + '/' + tvshowData.id + '/' + this.commonService.convertToLowercase(data.original_title) + '/' + data.id,
          sub_category: '',
          broadcastState: (this.tvShowData.extended && this.tvShowData.extended.broadcast_state !== undefined) ? (this.tvShowData.extended.broadcast_state === 'ARCHIVE' ? 'ARCHIVE' : 'ON-AIR') : ((tvshowData.extended && tvshowData.extended.broadcast_state !== undefined) ? (tvshowData.extended.broadcast_state === 'ARCHIVE' ? 'ARCHIVE' : 'ON-AIR') : 'ON-AIR'),
          skip_available : data.skip_available,
          vtt_thumbnail: data.video_details.vtt_thumbnail_url,
          endCreditsStart: data. end_credits_marker,
          start_time: data.start_time,
          actors: tvshowData.actors

          // broadcastState: tvshowData.extended ? tvshowData.extended.broadcast_state : 'ON-AIR'
        };
        return videoData;
      }
      private dateChange(value, months, seo) {
        let date;
        let day, monthIndex, year, formedDate;
        if ( value ) {
          date = new Date(value);
          day = date.getDate();
          monthIndex = date.getMonth();
          year = date.getFullYear();
          formedDate = seo ? (this.monthNames[monthIndex] + ' ' + day  + ', ' + year) : (day + ' ' + months[monthIndex]  + ', ' + year);
          return formedDate;
        } else {
          return '';
        }
      }
      private metaTagUpdate(): void {
        this.seasonData.index = this.actualEpisodeInfo.season_details.index;
        let tracks, audiotracks, gALanguage, episodeId, trailerId, fetchEng, fetchLabel, lan, genre, obj;
        gALanguage = [];
    tracks = (this.actualEpisodeInfo.video_details && this.actualEpisodeInfo.video_details.audiotracks && this.actualEpisodeInfo.video_details.audiotracks !== (null && undefined) && this.actualEpisodeInfo.video_details.audiotracks.length > 0) ? this.actualEpisodeInfo.video_details.audiotracks[0] : 'NA';
    audiotracks = (this.actualEpisodeInfo.video_details && this.actualEpisodeInfo.video_details.audiotracks && this.actualEpisodeInfo.video_details.audiotracks !== (null && undefined) && this.actualEpisodeInfo.video_details.audiotracks.length > 0) ? this.actualEpisodeInfo.video_details.audiotracks : ' ';
            fetchLabel = this.configData.languages_labels[this.displaylanguage];
            fetchEng = this.configData.languages_labels['en'];
    this.regionalLang = (this.episodeInfo.video_details && this.episodeInfo.video_details.audiotracks && this.episodeInfo.video_details.audiotracks !== (null && undefined) && this.episodeInfo.video_details.audiotracks.length > 0) ? this.episodeInfo.video_details.audiotracks.map(function(elem) {return fetchLabel[elem]; }).join(', ') : ' ';
           gALanguage = (this.episodeInfo.video_details && this.episodeInfo.video_details.audiotracks && this.episodeInfo.video_details.audiotracks !== (null && undefined) && this.episodeInfo.video_details.audiotracks.length > 0) ? this.episodeInfo.video_details.audiotracks.map(function(elem) {return fetchLabel[elem]; }).join(', ') : 'NA';
            lan = gALanguage.length > 0 ? gALanguage : 'NA';
           genre = (this.tvShowsGenreEng && this.tvShowsGenreEng !== undefined && this.tvShowsGenreEng.length > 0) ? this.tvShowsGenreEng : 'NA';
          this.pageName = lan + '|' + 'Episode' + '|' + genre + '|' +  this.gAChannelOriginal  + '|' + this.episodeInfo.original_title;
          this.gtm.sendPageName(this.pageName);
          this.gtm.sendTvChannel(this.gAChannelOriginal);
          this.gtm.sendEvent();
           episodeId  = '0-1-tvshow_984782182-season_1914050019-episode_695834209';
           trailerId = '0-1-tvshow_984782182-season_1914050019-episode_822830491';
           obj = [];
           let tempTitle, episodeTitle;
           if (this.tvShowData && this.tvShowData.extended && this.tvShowData.extended.seo_title) {
              tempTitle = (this.tvShowData.extended.seo_title !== null || this.tvShowData.extended.seo_title !== undefined || this.tvShowData.extended.seo_title !== '') ? this.tvShowData.extended.seo_title : this.tvShowData.original_title;
            } else {
              tempTitle = (this.tvShowData.seo_title && (this.tvShowData.seo_title !== null || this.tvShowData.seo_title !== undefined || this.tvShowData.seo_title !== '')) ? this.tvShowData.seo_title : this.tvShowData.original_title;
            }

           if (this.actualEpisodeInfo && this.actualEpisodeInfo.extended && this.actualEpisodeInfo.extended.seo_title) {
              episodeTitle = (this.actualEpisodeInfo.extended.seo_title !== null || this.actualEpisodeInfo.extended.seo_title !== undefined || this.actualEpisodeInfo.extended.seo_title !== '') ? this.actualEpisodeInfo.extended.seo_title : this.actualEpisodeInfo.original_title;
            } else {
              episodeTitle = (this.actualEpisodeInfo.seo_title && (this.actualEpisodeInfo.seo_title !== null || this.actualEpisodeInfo.seo_title !== undefined || this.actualEpisodeInfo.seo_title !== '')) ? this.actualEpisodeInfo.seo_title : this.actualEpisodeInfo.original_title;
	    }

            if (this.actualEpisodeInfo && this.actualEpisodeInfo.extended && this.actualEpisodeInfo.extended.creative_title) {
              episodeTitle = (this.actualEpisodeInfo.extended.creative_title !== null || this.actualEpisodeInfo.extended.creative_title !== undefined || this.actualEpisodeInfo.extended.creative_title !== '') ? this.actualEpisodeInfo.extended.creative_title : episodeTitle;
            }
                  let seoObj, pageType;
                   pageType = this.showPage ? 'tvShowData' : 'actualEpisodeInfo';
                   seoObj = {
                     extented_seo_title: (this[pageType].extended ? this[pageType].extended.seo_title : null) || null,
                     seo_title: this[pageType].seo_title || null,
                     tvshow_title: this.tvShowData.title || this.tvShowData.original_title,
                     title:  this[pageType].title || this[pageType].original_title,
                     date: this[pageType].release_date ? this[pageType].release_date.split('T')[0] : '',
                     keywords: (this[pageType].extended ? this[pageType].extended.digital_keywords : null) || null,
                     description: (this[pageType].extended ? this[pageType].extended.seo_description : null) || null,
                   };
        if (this.assetSubtype === 'zeeOriginals') {
            if (trailerId === this.actualEpisodeInfo.id) {
              obj[0] = 'Official Trailer - Karenjit Kaur: The Untold Story of Sunny Leone - Season 1 (Hindi) ZEE5 Originals Series Online | {ZEE5} | (Drama)'; obj[1] = 'Watch the official trailer of Karenjit Kaur: The Untold Story of Sunny Leone - Season 1, a ZEE5 Original web series online in full HD anytime, anywhere only on ZEE5';
               this.seoService.update(obj[0], obj[1]);
            } else if (episodeId === this.actualEpisodeInfo.id) {
               obj[0] = ' Motion Poster - Karenjit Kaur: The Untold Story of Sunny Leone - Season 1 (Hindi) ZEE5 Originals Series Online | {ZEE5} | (Drama)'; obj[1] = ' Watch the official motion poster of Karenjit Kaur: The Untold Story of Sunny Leone - Season 1, a ZEE5 Original web series online in full HD anytime, anywhere only on ZEE5.';
               this.seoService.update(obj[0], obj[1]);
            } else {
            //  this.seoService.eachEpisodeOriginalPage(this.commonService.convertToLowercase(tempTitle),  tracks, this.tvShowsGenreEng, this.actualEpisodeInfo.index , this.seasonData.index, this.commonService.convertToLowercase(episodeTitle));
              if (this.showPage) {
                this.seoService.originalPage(seoObj, tempTitle, this.seasonData.index, tracks);
              } else {
                if (this.actualEpisodeInfo.asset_subtype === 'trailer') {
                  this.seoService.eachoriginalpagetrailer(tempTitle,  tracks, this.tvShowsGenreEng, this.actualEpisodeInfo.index , this.seasonData.index, episodeTitle);
                } else {
                  this.seoService.eachEpisodeOriginalPage(seoObj, tempTitle,  tracks, this.tvShowsGenreEng, this.actualEpisodeInfo.index , this.seasonData.index, episodeTitle);
                }
              }
            }
        }   else if (this.tvShowData && this.tvShowData.countries && this.tvShowData.countries[0] && this.tvShowData.countries[0] !== 'IN' && (this.tvShowData.countries[0].toLowerCase().indexOf('india') < 0)) {
            // this.seoService.eachinternationalpage(this.commonService.convertToLowercase(tempTitle),  tracks, this.tvShowsGenreEng, this.actualEpisodeInfo.index , this.seasonData.index, this.commonService.convertToLowercase(episodeTitle));
            if (this.actualEpisodeInfo.asset_subtype === 'trailer') {
              this.seoService.eachinternationalpagetrailer(tempTitle,  tracks, this.tvShowsGenreEng, this.actualEpisodeInfo.index , this.seasonData.index, episodeTitle);
            } else {
              this.seoService.eachinternationalpage(seoObj, tempTitle,  tracks, this.tvShowsGenreEng, this.actualEpisodeInfo.index , this.seasonData.index, episodeTitle);
            }

         } else {
            // this.seoService.eachEpisodeShowPage(this.commonService.convertToLowercase(tempTitle),  tracks, this.tvShowsGenreEng, this.actualEpisodeInfo.index, this.availableChannelOriginal, this.dateChange(this.actualEpisodeInfo.release_date, this.monthNames, true));
            if (this.showPage) {
              this.seoService.showPages(seoObj, tempTitle, this.availableChannelOriginal);
            } else {
            this.seoService.eachEpisodeShowPage(seoObj, tempTitle,  tracks, this.tvShowsGenreEng, this.actualEpisodeInfo.index, this.availableChannelOriginal, this.dateChange(this.actualEpisodeInfo.release_date, this.monthNames, true), episodeTitle);
          }
        }
         if (this.actualEpisodeInfo.list_image) {
             this.imageUrl = this.commonService.getEpisodeUrl(this.actualEpisodeInfo.release_date, this.tvShowData.original_title, this.actualEpisodeInfo, '270x152/');
             this.metaService.updateTag({ property: 'og:image', content: this.imageUrl, itemprop: 'image' });
             this.metaService.updateTag({ property: 'og:image:url', content: this.imageUrl, itemprop: 'image' });
             this.metaService.updateTag({ property: 'og:image:type', content: 'image/png' });
             this.metaService.updateTag({ name: 'twitter:image', content: this.imageUrl});
          } else {
            this.metaService.updateTag({ property: 'og:image', content: 'https://www.zee5.com/assets/common/Splash.jpg', itemprop: 'image' });
            this.metaService.updateTag({ property: 'og:image:url', content: 'https://www.zee5.com/assets/common/Splash.jpg', itemprop: 'image' });
            this.metaService.updateTag({ property: 'og:image:type', content: 'image/png' });
            this.metaService.updateTag({ name: 'twitter:image', content: 'https://www.zee5.com/assets/common/Splash.jpg'});
            this.imageUrl = this.default;
          }
        this.schemaUpdate();
      }
      private formatDate(val): any {
        let today, d, m, yyyy, dd, mm, dateFormat;
         today = new Date(val);
         d = today.getDate();
         m = today.getMonth() + 1;
         yyyy = today.getFullYear();
         dd = (d < 10) ? '0' + d : d;
         mm = (m < 10) ? '0' + m : m;
         dateFormat =  yyyy + '-' + mm + '-' + dd;
        return dateFormat;
  }
private schemaUpdate(): void {
  let actorDetails, directorDetails, json_ld, url, countryOfOrigin;
  actorDetails = []; directorDetails = [];
  json_ld = {};
  json_ld =  {

    '@context': 'http://schema.org',
    '@id': this.actualEpisodeInfo.id,
    '@type': 'TVEpisode',
    'name': this.actualEpisodeInfo.original_title,
    'episodeNumber': this.actualEpisodeInfo.index,

    'partOfSeries': {
      '@type': 'TVSeries',
      'name': this.tvShowData.original_title
    },
    'description': this.actualEpisodeInfo.description
  };
  if (this.seasonData) {
    if (this.seasonData.index && this.seasonData.index !== null) {
      json_ld['partOfSeason'] = {
        '@type': 'TVSeason',
        'seasonNumber': this.seasonData.index
      };
    }
  }
  if (this.actualEpisodeInfo.list_image && this.actualEpisodeInfo.list_image !== null && this.actualEpisodeInfo.list_image !== '' && this.actualEpisodeInfo.id !== null) {
     url = this.basepath +  this.actualEpisodeInfo.id + '/list/' + '270x152/' +  this.actualEpisodeInfo.list_image;
    json_ld['image'] = [url];
  }
  if (this.actualEpisodeInfo.release_date && this.actualEpisodeInfo.release_date !== null) {
    json_ld['releasedEvent'] =  {
      '@type': 'PublicationEvent',
      'startDate': this.formatDate(this.actualEpisodeInfo.release_date),
    };
    if (this.tvShowData.countries && this.tvShowData.countries != null) {
      if (this.tvShowData.countries.length > 0) {
        countryOfOrigin = this.tvShowData.countries.join(', ');
        json_ld['releasedEvent']['location'] =  {
          '@type': 'Country',
          'name': countryOfOrigin
        };
      }
    }
  }

  if (this.tvShowData.actors && this.tvShowData.actors.length > 0) {
    for (let i = 0; i < this.tvShowData.actors.length; i++) {
      actorDetails[i] = {
        '@type': 'Person', 'name': this.tvShowData.actors[i]
      };
    }
    json_ld['actor'] = actorDetails;
  }
  if (this.tvShowData.directors && this.tvShowData.directors.length > 0) {
    for (let j = 0; j < this.tvShowData.directors.length; j++) {
      directorDetails[j] = {
        '@type': 'Person', 'name': this.tvShowData.directors[j]
      };
    }
    json_ld['director'] = directorDetails;
  }
  // while (document.getElementById('episodedetailspageMarkup').hasChildNodes()) {
  //   document.getElementById('episodedetailspageMarkup').removeChild(document.getElementById('episodedetailspageMarkup').lastChild);
  // }
  let script;
  script = document.createElement('script');
  script.id = 'schema';
  script.type = 'application/ld+json';
  script.innerHTML = JSON.stringify(json_ld);
  if (document.getElementById('episodedetailspageMarkup')) {
    document.getElementById('episodedetailspageMarkup').appendChild(script);
  }
  this.loadSchemaPlay();
}
private loadSchemaPlay () {
  const json_ld = {
        '@context': 'http://schema.org',
        '@type': 'BreadcrumbList',
        'itemListElement': [{
          '@type': 'ListItem',
          'position': 1,
          'item': {
            '@id': environment.shareUrl + this.routeservice.getBaseLocation() + this.assetSubtype,
            'name': 'Tv Shows',
          }
        }, {
          '@type': 'ListItem',
          'position': 2,
          'item': {
            '@id': environment.shareUrl +  this.routeservice.getBaseLocation() + this.baseCategory +  this.commonService.convertToLowercase(this.tvShowData.original_title) + '/' + this.tvShowData.id ,
            'name': this.tvShowData.original_title,
          }
        }, {
          '@type': 'ListItem',
          'position': 3,
          'item': {
            '@id': environment.shareUrl +  this.routeservice.getBaseLocation() + this.baseCategory +  this.commonService.convertToLowercase(this.tvShowData.original_title) + '/' + this.tvShowData.id + '/' + this.commonService.convertToLowercase(this.actualEpisodeInfo.original_title) + '/' + this.actualEpisodeInfo.id,
            'name': this.actualEpisodeInfo.original_title,
          }
        }]
    };
     let script;
     script = document.createElement('script');
     script.id = 'schema';
     script.type = 'application/ld+json';
     script.innerHTML = JSON.stringify(json_ld);
     if (document.getElementById('breadcrumpMarkup')) {
     document.getElementById('breadcrumpMarkup').appendChild(script);
   }
}
private startTrailer() {
  this.commonService.setTalamoosData('', '', '');
  this.gtm.clearContentClickDetails();

 if (this.trailerInfo !== null) {
    this.episodeInfo = this.trailerInfo[0];
        this.metaTagUpdate();
    // this.episodeInfo.tvshow_details.business_type = 'advertisement_downloadable';
    this.episodeInfo.business_type = 'advertisement_downloadable';
    this.headerservicesService.premium = true;
    this.videoData = [];
    this.videoData.push(this.dataCreation(this.episodeInfo, this.tvShowData));
    if (this.videoService.enableCastView) {
      this.videoData ? (this.backgroundImage = this.videoService.getImageUrl(this.videoData[0], false)) : (this.backgroundImage =  false);
      this.castQueueObject = this.videoData;
      if (this.checkParental(this.episodeInfo.age_rating) > this.parental_age) {
        this.headerservicesService.parentalChange({'flag': true, 'type': 'pin' });
        this.parentalpin = true;
        this.video = false;
      } else {
        this.showAdult = this.loginToken ? false : (this.episodeInfo.age_rating === 'A' ? true : false);
        if (!this.showAdult) {
        this.videoService.castQueueObject = this.castQueueObject;
        this.videoService.toggleQueueState(true);
        }
      }
      return;
    }
    this.videoError();
    this.playcontent = true;
    this.trailerPlayed = false;
 }
//  this.setData();
}
public showWatchtrailer(): any {
  this.commonService.updateCollectionId(null);
  this.commonService.setTalamoosData('', '', '');
  this.gtm.clearContentClickDetails();
  let tempTitle;
    // if (this.tvShowData && this.tvShowData.extended && this.tvShowData.extended.seo_title) {
    //   tempTitle = (this.tvShowData.extended.seo_title !== null || this.tvShowData.extended.seo_title !== undefined || this.tvShowData.extended.seo_title !== '') ? this.tvShowData.extended.seo_title : this.tvShowData.original_title;
    // } else {
    //   tempTitle = (this.tvShowData.seo_title && (this.tvShowData.seo_title !== null || this.tvShowData.seo_title !== undefined || this.tvShowData.seo_title !== '')) ? this.tvShowData.seo_title : this.tvShowData.original_title;
    // }
    tempTitle = this.tvShowData.original_title;
    // if (this.countryCode === 'IN') {
      this.routeLink.navigate([ this.baseCategory , this.commonService.convertToLowercase(tempTitle) , this.tvShowData.id , this.commonService.convertToLowercase(this.trailerData[0].original_title) , this.trailerData[0].id]);
    // } else {
    //   let link;
    //   link = environment.shareUrl + this.baseCategory + this.commonService.convertToLowercase(tempTitle) + '/' + this.tvShowData.id + '/' + this.commonService.convertToLowercase(this.trailerData[0].original_title) + '/' + this.trailerData[0].id;
    //   window.open(link, '_blank');
    // }
}
private replayTrailer() {
  if (this.videoService.enableCastView) {
    this.videoData ? (this.backgroundImage = this.videoService.getImageUrl(this.videoData[0], false)) : (this.backgroundImage =  false);
    this.videoService.castQueueObject = this.videoData;
    this.videoService.toggleQueueState(true);
    return;
  }
  this.video = true;
  this.startVideoLive();
  this.playcontent = true;
  this.trailerPlayed = false;

}

private startVideoEpisode = function(eve) {
  this.subscription1 = false;
  let premium, base;
  this.headerservicesService.premium = this.premium;
  this.headerservicesService.trailer = this.trailer;
  premium = (this.actualEpisodeInfo.asset_subtype === 'trailer') ? false : this.premium;
              let assetType, activePlan;
            if (this.loginToken) {
                assetType = this.subscription.checkPlanApiSuccess(true);
                activePlan = this.subscription.checkPlanApiSuccess(false);
            } else {
              assetType = [], activePlan = [];
            }
            activePlan = (activePlan === undefined || activePlan.length <= 0) ? false : true;
            // if(!activePlan && !premium) {
              // this.adCall();
              // this.adApiCall();
            // }
  if (this.loginToken !== null || !premium ) {
    if (premium) {
      if (this.loginToken) {
        this.purchasedAssetType = this.subscription.checkPlanApiSuccess(true);
         let assetType1;
         assetType1 = '6';
         this.showSubPopUp = this.subscription.getPlanApiSucess();
         if ((this.tvShowData.business_type.indexOf('premium') === -1) && (this.actualEpisodeInfo.business_type.indexOf('premium') !== -1)) {
            // this.showBeforeTV = true;
            if (this.purchasedAssetType.length > 0) {
              if (!this.subscription.checkAssetLang('6', this.episodeInfo.audio_languages)) {
                this.setValues(false, false, true);
                this.showGetPremium = true;
                // this.headerservicesService.callUpgradePopup(true);
                this.headerservicesService.subscribeReminderChange(true);

              } else {
                 this.setValues(true, false, false);
                 this.videoChange(eve);
                // this.headerservicesService.subscribeReminderChange(true);
              }
            } else {
              this.setValues(false, false, true);
              this.showbeforeTVpopup(this.tvShowData.business_type, this.actualEpisodeInfo.business_type);
              // this.headerservicesService.subscribeReminderChange(true);
            }
         } else {
            if (this.purchasedAssetType.indexOf(assetType1) > -1 &&  this.subscription.checkAssetLang('6', this.episodeInfo.audio_languages)) {

          this.subscription1 = true;
          if (this.showSubPopUp !== undefined) {
            this.setValues(true, false, false);
            this.videoChange(eve);
          }
        } else if (this.showSubPopUp !== undefined) {

          if (this.tvShowData.business_type.indexOf('premium') !== -1) {
            this.setValues(false, false, true);
          if ((this.purchasedAssetType.indexOf(assetType1) > -1 &&  !this.subscription.checkAssetLang('6', this.episodeInfo.audio_languages))) {
                  this.showGetPremium = true;
              // this.headerservicesService.callUpgradePopup(true);
              this.headerservicesService.subscribeReminderChange(true);

            } else {
                  this.showGetPremium = true;
              // this.setParentId();
              this.headerservicesService.subscribeReminderChange(true);
            }
          } else {
            // this.headerservicesService.subscribeReminderChange(true);
                this.setValues(true, false, false);
            this.videoChange(eve);
          }
          // this.videoChange(eve);
        }
         }

      } else {

        this.setValues(false, true, false);
        if (this.tvShowData.business_type.indexOf('premium') === -1 && this.actualEpisodeInfo.business_type.indexOf('premium') !== -1) {
          this.showGetPremium = true;
          this.showbeforeTVpopup(this.tvShowData.business_type, this.actualEpisodeInfo.business_type);
        } else {
                  this.showGetPremium = true;
              // this.setParentId();
          this.headerservicesService.signReminderChange(true);
          this.videoChange(eve);
        }

        // this.videoChange(eve);
      }
    } else {
      if (this.loginToken) {
          this.purchasedAssetType = this.subscription.checkPlanApiSuccess(true);
         let assetType2;
         assetType2 = '6';
         this.showSubPopUp = this.subscription.getPlanApiSucess();
         if ((this.tvShowData.business_type.indexOf('premium') !== -1) || (this.actualEpisodeInfo.business_type.indexOf('premium') !== -1)) {
            // if(this.purchasedAssetType.length === 0) {
            if (!(this.purchasedAssetType.indexOf(assetType2) > -1 && this.subscription.checkAssetLang('6', this.episodeInfo.audio_languages))) {
              this.showGetPremium = true;
            }
          }
      } else {
        if (this.tvShowData.business_type.indexOf('premium') !== -1 || this.actualEpisodeInfo.business_type.indexOf('premium') !== -1) {
          this.showGetPremium = true;
        }
      }
          this.setValues(true, false, false);
          this.videoChange(eve);
    }

  }  else {
    // this.setValues(false, true, false);
      if (this.tvShowData.business_type.indexOf('premium') === -1 && this.actualEpisodeInfo.business_type.indexOf('premium') !== -1) {
        // this.showBeforeTV = true;
        // this.setValues(false, true, false);
        // this.videoChange(false);
        this.showbeforeTVpopup(this.tvShowData.business_type, this.actualEpisodeInfo.business_type);
    } else {
      if (this.tvShowData.business_type.indexOf('premium') !== -1) {
        this.setValues(false, true, false);
        this.videoChange(eve);
                  this.showGetPremium = true;
              // this.setParentId();
        this.headerservicesService.signReminderChange(true);
      }  else {
        this.setValues(true, false, false);
        this.videoChange(eve);
      }
      // this.videoChange(eve);
    }
    // this.headerservicesService.signReminderChange(true);
    // this.videoChange(eve);
  }
   base = (this.assetSubtype === 'zeeOriginals') ? 'zee5originals' : 'tvshows';
   let tempTitle, epititle;
   // if (this.episodeInfo.tvshow && this.episodeInfo.tvshow.extended && this.episodeInfo.tvshow.extended.seo_title) {
   //            epititle = (this.episodeInfo.tvshow.extended.seo_title !== null || this.episodeInfo.tvshow.extended.seo_title !== undefined || this.episodeInfo.tvshow.extended.seo_title !== '') ? this.episodeInfo.tvshow.extended.seo_title : this.episodeInfo.tvshow.original_title;
   //          } else {
   //            epititle = (this.episodeInfo.tvshow.seo_title && (this.episodeInfo.tvshow.seo_title !== null || this.episodeInfo.tvshow.seo_title !== undefined || this.episodeInfo.tvshow.seo_title !== '')) ? this.episodeInfo.tvshow.seo_title : this.episodeInfo.tvshow.original_title;
   //          }
   // if (this.episodeInfo && this.episodeInfo.extended && this.episodeInfo.extended.seo_title) {
   //            tempTitle = (this.episodeInfo.extended.seo_title !== null || this.episodeInfo.extended.seo_title !== undefined || this.episodeInfo.extended.seo_title !== '') ? this.episodeInfo.extended.seo_title : this.episodeInfo.original_title;
   //          } else {
   //            tempTitle = (this.episodeInfo.seo_title && (this.episodeInfo.seo_title !== null || this.episodeInfo.seo_title !== undefined || this.episodeInfo.seo_title !== '')) ? this.episodeInfo.seo_title : this.episodeInfo.original_title;
   //          }
    tempTitle = this.episodeInfo.original_title;
    epititle = this.episodeInfo.tvshow.original_title;
  this.shareUrl = base + '/details/' + this.commonService.convertToLowercase(epititle) + '/' + this.episodeInfo.tvshow.id + '/' + this.commonService.convertToLowercase(tempTitle) + '/' + this.episodeInfo.id;
      this.metaTagUpdate();
  this.setFavWatch();
             // this.setData();
};
private setValues(playcontent, showLogin, showSubscribe): void {
        this.playcontent = playcontent;
      this.showLogin = showLogin;
      this.showSubscribe = showSubscribe;
     // console.log(this.showSubscribe, 'this.showSubscribe')
}
private startVideoLive(): void {
  if (this.episodeInfo.video_details) {
    if (this.videoService.enableCastView && !this.showSubscribe && !this.showLogin) {
      this.videoData ? (this.backgroundImage = this.videoService.getImageUrl(this.videoData[0], false)) : (this.backgroundImage =  false);
      this.castQueueObject = this.videoData;
      if (this.checkParental(this.episodeInfo.age_rating) > this.parental_age) {
        this.headerservicesService.parentalChange({'flag': true, 'type': 'pin' });
        this.parentalpin = true;
        this.video = false;
      } else {
       this.showAdult = this.loginToken ? false : (this.episodeInfo.age_rating === 'A' ? true : false);
                      if (!this.showAdult) {
                            this.videoService.castQueueObject = this.castQueueObject;
                            this.videoService.toggleQueueState(true);
                      }
      }
      return;
    }
    if (this.playcontent || this.video) {
      this.gtm.GAsubCategory = '';
      this.gtm.clearContentClickDetails();
      if (this.checkParental(this.episodeInfo.age_rating) > this.parental_age) {
        this.headerservicesService.parentalChange({'flag': true, 'type': 'pin' });
        this.parentalpin = true;
        this.video = false;
      } else {
        this.video = this.loginToken ? true : (this.episodeInfo.age_rating === 'A') ? false : true;
        this.showAdult = !this.video;
      }
      this.playcontent = true;
      $('#noAccessSubs').css('display', 'none');
      $('#noAccess').css('display', 'none');
    } else  {
      this.video = false;
    }
    $('#playImage').hide();
    if (this.showLogin && !this.playcontent) {
      $('#noAccess').css('display', 'block');

    } else if (this.showSubscribe && !this.playcontent) {
      $('#noAccessSubs').css('display', 'block');
    } else {
      $('#noAccessSubs').css('display', 'none');
      $('#noAccess').css('display', 'none');
    }
  } else {
    this.callToast();
  }

}
 private closeShare(event: any): any {
        this.showShare = false;
      }
 private openShare(event: any): void {
         event.stopPropagation();
        this.showShare = true;
  }
private openTabLink(tab: any, tabname: any): void {
  let base, tempTitle;
  base = (this.assetSubtype === 'tvshows') ? 'tvshows' : 'zee5originals';
    // if (this.tvShowData && this.tvShowData.extended && this.tvShowData.extended.seo_title) {
    //     tempTitle = (this.tvShowData.extended.seo_title !== null || this.tvShowData.extended.seo_title !== undefined || this.tvShowData.extended.seo_title !== '') ? this.tvShowData.extended.seo_title : this.tvShowData.original_title;
    // } else {
    //      tempTitle = (this.tvShowData.seo_title && (this.tvShowData.seo_title !== null || this.tvShowData.seo_title !== undefined || this.tvShowData.seo_title !== '')) ? this.tvShowData.seo_title : this.tvShowData.original_title;
    // }
    tempTitle = this.tvShowData.original_title;
  switch (tab) {
    case 0:
      this.currentTab = 0;
      break;
      case 1:
            this.currentTab = 1;
      this.routeLink.navigate([ this.baseCategory ,  this.commonService.convertToLowercase(tempTitle), this.tvShowData.id]);
      break;
      case 2:
            this.currentTab = 2;
            this.viewAll();
      break;
      case 3:
            this.currentTab = 3;
      this.routeLink.navigate([ this.baseCategory ,  this.commonService.convertToLowercase(tempTitle), this.tvShowData.id ,  tabname]);
      break;
    }
  }
      // private addFavorite(event: any): void {
      //     let favoritesRequest, requestFav;
      //    if ( this.loginToken != null ) {
      //     event.target.src = this.assetbasepath + 'assets/common/loaderWhite.svg';
      //     event.stopPropagation();
      //     if (this.favorite === true ) {
      //             favoritesRequest = new  FavoritesApi(this.http, null, this.configusertoken);
      //             favoritesRequest.v1FavoritesDelete(this.episodeInfo.id, this.episodeInfo.asset_type).timeout(environment.timeOut).subscribe(value => {
      //               this.favorite = false;
      //               event.target.src = this.assetbasepath + 'assets/common/fav_icon_normal.png';
      //               this.userProfileService.removeFavoriteData(this.episodeInfo);
      //             },
      //             err => {
      //               this.favorite = true;
      //               event.target.src = this.assetbasepath + 'assets/common/fav_icon_selected.png';
      //               this.gtm.sendErrorEvent('api', err);
      //             });
      //     } else {
      //             let obj;
      //             obj = this.userProfileService.createObject(this.episodeInfo);
      //            favoritesRequest = new  FavoritesApi(this.http, null, this.configusertoken);
      //             requestFav = favoritesRequest.v1FavoritesPost(obj).timeout(environment.timeOut).subscribe(value => {
      //               this.favorite = true;
      //               event.target.src = this.assetbasepath + 'assets/common/fav_icon_selected.png';
      //               this.userProfileService.setFavoriteData(this.episodeInfo);
      //             },
      //             err => {
      //               this.favorite = false;
      //               event.target.src = this.assetbasepath + 'assets/common/fav_icon_normal.png';
      //               this.gtm.sendErrorEvent('api', err);
      //             });
      //     }
      //   } else {
      //   this.headerservicesService.signReminderChange(true);        }
      // }
  private watchNow (event: any): void {
         if ( this.loginToken != null ) {
          event.stopPropagation();
          event.preventDefault();
           let watchListRequest, requestWatch;
          this.imgSrc = this.assetbasepath + 'assets/common/loaderWhite.svg';
          if (this.watched === true ) {
            let gener = '';
            if ( this.episodeInfo.genre != null ) {
              gener = this.episodeInfo.genre.toString();
            } else {
              gener = 'NA';
            }
             watchListRequest = new  WatchlistApi(this.http, null, this.configusertoken);
                     requestWatch = watchListRequest.v1WatchlistDelete(this.episodeInfo.id, this.episodeInfo.asset_type).timeout(environment.timeOut).subscribe(value => {
                      this.watched = false;
                    this.imgSrc = this.assetbasepath + 'assets/common/watchLater_normal.png';
                    this.commonService.qgraphevent('TVshowssection_added_to_watch_later', {'program_name': this.episodeInfo.title , 'channel_name': this.availableChannelOriginal , 'genre': gener, 'time_spent': '', 'language': '', 'episode_number': this.episodeInfo.index, 'episode_name': this.episodeInfo.title, 'country': this.settingsService.getCountry(), 'state': this.localstorage.getItem('state_code')});
                      this.userProfileService.removeWatchData(this.episodeInfo);
                    },
                    err => {
                      // this.watched = false;
                   this.imgSrc = this.assetbasepath + 'assets/common/watchLater_icon_selected.png';
                      this.gtm.sendErrorEvent('api', err);
                    });
          } else {
            let obj;
            obj = this.userProfileService.createObject(this.episodeInfo);
            watchListRequest = new  WatchlistApi(this.http, null, this.configusertoken);
             requestWatch = watchListRequest.v1WatchlistPost(obj).timeout(environment.timeOut).subscribe(value => {
                      this.watched = true;
                   this.imgSrc = this.assetbasepath + 'assets/common/watchLater_icon_selected.png';
                      this.userProfileService.setWatchData(this.episodeInfo);
                    },
                    err => {
                      // this.watched = true;
                   this.imgSrc = this.assetbasepath + 'assets/common/watchLater_normal.png';
                      this.gtm.sendErrorEvent('api', err);
                    });
          }
      } else {
         this.headerservicesService.signReminderChange(true);
      }
      }
private setFavWatch() {
    this.watched = this.userProfileService.inList('watchList', this.episodeInfo.id);
    // this.favorite =  this.userProfileService.inList('favorite', this.episodeInfo.id);
  }
private goToParental() {
      this.headerservicesService.parentalChange({'flag': true, 'type': 'pin' });
}
 public closeEmbed(event): any {
    this.embedLink = false;
    this.pauseVideo = false;
  }
  private openEmbed(event): any {
    this.embedLink = true;
    this.pauseVideo = true;
  }
public ngOnDestroy() {
  this.subscription.setParentId(null, null);
  this.gtm.GAsubCategory = 'NA';
  this.linkservice.removeampLink();
  this.metaService.updateTag({ property: 'og:image', content: 'https://www.zee5.com/assets/common/Splash.jpg', itemprop: 'image' });
   this.metaService.updateTag({ property: 'og:image:url', content: 'https://www.zee5.com/assets/common/Splash.jpg', itemprop: 'image' });
   this.metaService.updateTag({ property: 'og:image:type', content: 'image/png' });
   this.metaService.updateTag({ name: 'twitter:image', content: 'https://www.zee5.com/assets/common/Splash.jpg'});
  this.headerservicesService.premium = false;
  this.destroyAds();
  if (isPlatformBrowser(this.platformId)) {
    // this.googletagAvailable = localStorage.getItem('googletag')
    // this.googletagAvailable = this.commonService.checkGoogleTag();
    // if (this.googletagAvailable === 'true' && googletag.destroySlots) {
    //   googletag.destroySlots();
    // }
    if (this.touchScreen) {
      $('.episode_details').css('paddingTop', '0px');
    }
    this.headerservicesService.episodicPage(false);
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
    if (this.subs) {
      this.subs.unsubscribe();
    }
    this.gtm.sendTvChannel('');
    this.videoService.instance = 0;
    $('#breadcrumInit').css('top', '90px');
    $('#breadcrumInit').css('position', 'absolute');

  }
}



  private showbeforeTVpopup(show, episode) {

    if ((show.indexOf('premium') === -1) && (episode.indexOf('premium') !== -1)) {
      this.hideLoader();
      if (this.loginToken) {
          this.purchasedAssetType = this.subscription.checkPlanApiSuccess(false);
          let assetType;
          assetType = '6';
          if (this.purchasedAssetType.length > 0) {
                if (!this.subscription.checkAssetLang('6', this.episodeInfo.audio_languages)) {
                  this.setValues(false, false, true);
                  this.showGetPremium = true;
                  // this.headerservicesService.callUpgradePopup(true);
                  this.headerservicesService.subscribeReminderChange(true);

                } else {
                   this.setValues(true, false, false);
                   this.videoChange(true);
                }
          } else {
            if (this.actualEpisodeInfo.asset_subtype.indexOf('episode') !== -1) {
                  this.headerservicesService.signReminderChange(false);
                  if (this.countryCode === 'IN') {
                    this.showBeforeTV = true;
                  } else {
                    this.headerservicesService.subscribeReminderChange(true);
                  }
                  this.showGetPremium = true;
                  if (this.loginToken) {
                    this.showSubscribe = true;
                  } else {
                    this.showLogin = true;
                  }
            } else {
              this.showGetPremium = true;
              // this.setParentId();
              this.headerservicesService.subscribeReminderChange(true);
            }
              this.setValues(false, false, true);
            }
      } else {
            if (this.actualEpisodeInfo.asset_subtype.indexOf('episode') !== -1) {
                      this.headerservicesService.signReminderChange(false);
                  if (this.countryCode === 'IN') {
                    this.showBeforeTV = true;
                  } else {
                    this.headerservicesService.signReminderChange(true);
                  }
                  this.showGetPremium = true;
                  if (this.loginToken) {
                    this.showSubscribe = true;
                  } else {
                    this.showLogin = true;
                  }
            } else {
              this.showGetPremium = true;
              this.headerservicesService.signReminderChange(true);
            }
        this.setValues(false, true, false);
    }
  } else {
    return;
  }



}

    public closeBeforeTV() {
          // console.log('close')
          if (this.loginToken) {
            this.setValues(false, false, true);
            // $('#noAccessSubs').show();
            // $('#noAccess').hide();
            // $('#playImage').hide();
          } else {
            this.setValues(false, true, false);
            // $('#noAccessSubs').hide();
            // $('#noAccess').show();
            // $('#playImage').hide();
          }
      this.showBeforeTV = false;
      this.playcontent = false;
    }

    public playFreeEpi() {
        this.showBeforeTV = false;
      if (this.tvShowData && this.tvShowData.seasons && this.tvShowData.seasons[0] && this.tvShowData.seasons[0].episodes && this.tvShowData.seasons[0].episodes[1]) {
        // if (this.prev_next_data && this.prev_next_data.previousEpisode && this.prev_next_data.previousEpisode.business_type && this.prev_next_data.previousEpisode.business_type.indexOf('premium') === -1) {
            this.playcontent = true;
            this.prevEpisode(this.tvShowData.seasons[0].episodes[1]);
        } else {
          this.openTabLink(2, 'episodes');
        }
    }
  private prevEpisode(prevEpisode): void {
    let tempTitle;
    // if (prevEpisode.extended && prevEpisode.extended.seo_title) {
    //   prevEpisode.original_title = (prevEpisode.extended.seo_title !== null || prevEpisode.extended.seo_title !== undefined || prevEpisode.extended.seo_title !== '') ? prevEpisode.extended.seo_title : (prevEpisode.original_title && (prevEpisode.original_title !== (null || undefined))) ? prevEpisode.original_title : 'title';
    // } else {
    //   prevEpisode.original_title = (prevEpisode.seo_title && (prevEpisode.seo_title !== null || prevEpisode.seo_title !== undefined || prevEpisode.seo_title !== '')) ? prevEpisode.seo_title : (prevEpisode.original_title && (prevEpisode.original_title !== (null || undefined))) ? prevEpisode.original_title : 'title';
    // }
    // if (this.tvShowData && this.tvShowData.extended && this.tvShowData.extended.seo_title) {
    //   tempTitle = (this.tvShowData.extended.seo_title !== null || this.tvShowData.extended.seo_title !== undefined || this.tvShowData.extended.seo_title !== '') ? this.tvShowData.extended.seo_title : this.tvShowData.original_title;
    // } else {
    //   tempTitle = (this.tvShowData.seo_title && (this.tvShowData.seo_title !== null || this.tvShowData.seo_title !== undefined || this.tvShowData.seo_title !== '')) ? this.tvShowData.seo_title : this.tvShowData.original_title;
    // }
    tempTitle = this.tvShowData.original_title;
    // if ((this.prev_next_data && this.prev_next_data.previousEpisode && this.prev_next_data.previousEpisode !== '')) {
      this.commonService.updateCollectionId(null);
      this.commonService.setTalamoosData('', '', '');
      this.gtm.clearContentClickDetails();

      this.routeLink.navigate([ this.baseCategory , this.commonService.convertToLowercase(tempTitle) , this.tvShowData.id , this.commonService.convertToLowercase(prevEpisode.original_title) , prevEpisode.id]);
  }
    public showDetails(data) {
      // console.log(data,'data show');
      this.showTitleScreen = data.title;

    }
    /////////////////////////////////////////////////////////// html//////////
     private setTvshowdataHTML(value): any {
      let countryCode;
        this.adApiCall(); // ad call for all contents

        this.tvshowdata = value;
        this.watched = this.userProfileService.inList('watchList', this.tvshowdata.id);
        this.iswatched();
        if ( this.tvshowdata.extended && this.tvshowdata.extended.digital_long_description_web ) {
          this.showReadMore = (this.tvshowdata.extended.digital_long_description_web && this.tvshowdata.extended.digital_long_description_web.toString().length > this.indexLimit )  ? true : false;
        } else {
          this.showReadMore = (this.tvshowdata.description && this.tvshowdata.description.toString().length > this.indexLimit )  ? true : false;
        }
      // this.showTitle = this.tvshowdata.title;
      this.asset_subtype = ( this.tvshowdata.asset_subtype != null ) ? this.tvshowdata.asset_subtype : 'NA';
      if (this.asset_subtype === 'episode' || this.asset_subtype === 'sample_premium') {
          if (this.displaylanguage === 'ru') {
            this.episode_subtype = this.episodeNo ? ('Серия ' + this.episodeNo) : '';
          } else {
          this.episode_subtype = this.episodeNo ? ('Ep ' + this.episodeNo) : '';
         }
      } else if (this.asset_subtype !== 'NA') {
        let carousel_list;
        carousel_list = this.configData.region.IN.India.tvshow_carousels;
        if (carousel_list && carousel_list.indexOf(this.asset_subtype) !== -1) {
          this.episode_subtype = this.configData.carousels_labels[this.asset_subtype][this.displaylanguage];
        } else {
          this.episode_subtype = this.asset_subtype;
        }
      } else {
          this.episode_subtype = '';
      }

            if ( this.tvshowdata.asset_subtype != null) {
               let tags, category;
               tags = (this.tvshowdata.tags !== null && this.tvshowdata.tags !== undefined) ? this.tvshowdata.tags : [];
               category = this.commonService.getSubcategory(this.tvshowdata.tags, 6, this.tvshowdata.asset_subtype, this.tvshowdata.genres, this.tvshowdata.content_owner);
               this.asset_type = category.join(', ');
            } else {
               this.asset_type = '';   // to remove NA
            }
          this.tvShowGenre = (this.tvshowdata.genres && this.tvshowdata.genres !== (null && undefined) && this.tvshowdata.genres.length > 0) ? this.tvshowdata.genres.map(function(elem) {return elem.value; }) : [];
          if (!this.tvshowdata.release_date || this.tvshowdata.release_date !== null  || this.tvshowdata.release_date !== undefined) {
             this.showReleaseDate = this.tvshowdata.release_date;
           } else {
             this.showReleaseDate = '';
           }
          // this.tvshowdata.tags = ['music', 'audio_mm','audio_en', 'audio_pa', 'audio_ta']; /* api */
          // this.tvshowdata.languages.push('ms');
          // (this.tvshowdata.tags &&  this.tvshowdata.tags.length > 0) ? this.audiotagsFromTags(this.tvshowdata.tags) : this.tvshow_tags = [];
	        if ( this.tvshowdata.languages != null ) {
	            if ( this.tvshowdata.languages.length !== 0) {
                // if (this.tvshowdata.languages.includes('ms') && this.tvshow_tags.length > 0) {
                //   let langArray = [];
                //    for (let i of this.tvshowdata.languages) {
                //      if (i !== 'ms') {
                //         langArray.push(i);
                //      }
                //    }
                //    this.finalLangArrayFormed(langArray);
                // }
                //  else {
                  this.languages_array =  this.tvshowdata.languages;
                  this.fetchlanguages(1);
                // }
               } else {
	                 this.languages = '';
	             }
	          } else {
	             this.languages = '';
	        }
	        if ( this.tvshowdata.subtitle_languages != null ) {
	            if ( this.tvshowdata.subtitle_languages.length !== 0 ) {
	             this.languages_array =  this.tvshowdata.subtitle_languages;
	             this.fetchlanguages(2);
	            } else {
	               this.subtitles_lang = '';
	            }
	        } else {
	            this.subtitles_lang = '';
	        }
      	this.availableOnChannel = (this.tvshowdata.channels && this.tvshowdata.channels !== (null && undefined) && this.tvshowdata.channels.length > 0) ? this.tvshowdata.channels.map(function(elem) {return elem.title; }).join(', ') : '';
  		countryCode = this.settingsService.getCountry();
      this.ageinNum = this.tvshowdata && this.tvshowdata.age_rating ? this.tvshowdata.age_rating : '';
       let ageratingList, countryList;
            countryList = this.settingsService.getCountryValueNew();
            ageratingList = countryList[0].age_rating; // age rating number json
            let validText;
             if (ageratingList && ageratingList[this.ageinNum]) {
                if( ageratingList[this.ageinNum] === '0' ) {
                       this.valid_string = this.translate.instant('MESSAGES.FOR_ALL');
                } else {
                  this.translate.get(['MESSAGES.AGE_RATING']).subscribe(value => {
                  validText = value['MESSAGES.AGE_RATING'];
                  this.valid_string = validText.replace(/<age>/g, +  ageratingList[this.ageinNum]);
                  });
                }
               } else {
                   this.valid_string = this.ageinNum;
               }
           this.ageratefunction();
      if (this.agetake) {
             this.ageRating = this.valid_string;
      } else {
             this.ageRating = this.ageinNum;
      }
      this.showDuration = this.updateTime(this.tvshowdata.duration);
  		this.showSeasons = this.tvshowdata.total_seasons;
  		if (this.tvshowdata.actors && this.tvshowdata.actors[0] != null) {
            this.showCast = true;
            this.actorsNames = this.tvshowdata.actors;
        } else {
            this.showCast = false;
        }
  	}
    public updateTime(s: number): any {
              // convert seconds to hrs and minutes
      let secs, mins, hrs, secs_new, mins_new, time;
      if (s) {
        secs = s % 60;
        s = (s - secs) / 60;
        mins = s % 60;
        s = (s - mins) / 60;
        hrs = s % 60;
        if (mins < 10) {
          mins_new = '0' + mins;
        } else {
          mins_new = '' + mins;
        }
        if (secs < 10) {
          secs_new = '0' + secs;
        } else {
         secs_new = '' + secs;
        }
          if (this.displaylanguage === 'ru') {
             time = (hrs ? hrs + 'ч' : '') + (mins ? (' ' + mins_new) + 'м' : '') + (secs ? (' ' + secs_new) + 'с' : '');
          } else {
          time = (hrs ? hrs + 'h' : '') + (mins ? (' ' + mins_new) + 'm' : '') + (secs ? (' ' + secs_new) + 's' : '');
          }
        return time;
      } else {
         time = '';
         return time;
      }
    }
  	   private fetchlanguages(switch_str: number): any {
       if (this.languageData == null) {
           this.languageData = this.settingsService.getCompleteConfig();
          this.assignLanguages(switch_str);
       } else {
          this.assignLanguages(switch_str);
       }
    }
    private assignLanguages(switch_str: number) {
       let value_string, regionalLang, gAlanguage;
       value_string = '';
       let j;
       this.regionalLang = [];
       this.gAlanguage = [];
       for ( j = 0; j < this.languages_array.length; j++ ) {
         regionalLang = this.fetchLabel[this.languages_array[j]];
         gAlanguage = this.configData.languages_labels['en'][this.languages_array[j]];
         regionalLang = (regionalLang !== undefined) ? regionalLang : this.languages_array[j];
         gAlanguage = (gAlanguage !== undefined) ? gAlanguage : this.languages_array[j];
         this.regionalLang.push(regionalLang);
         this.gAlanguage.push(gAlanguage);
        }
        	switch (switch_str) {
                case 1:
                    this.languages = this.convertArrayToString(this.regionalLang, ', ');
                    this.languagesEng = this.convertArrayToString(this.gAlanguage, ', ');
                  break;
                case 2:
                  this.subtitles_lang = this.convertArrayToString(this.regionalLang, ', ');
                  break;
                default:
                  // code...
                  break;
            }
    }
    private convertArrayToString(any_array: string[], prop) {
	    let result = '';
	    result = any_array.join(prop);
	    return result;
  	}


    private adoric_event(tvshowdata) {
    let adoric_array;
    adoric_array = [];
    if (tvshowdata.related) {
      for (let i = 0; i < tvshowdata.related.length; i++) {
        let json_object_adoric;
        json_object_adoric = {};
        if (tvshowdata.related[i].title) {
          json_object_adoric['title'] = tvshowdata.related[i].title;
        }
        if (tvshowdata.related[i].slug) {
          json_object_adoric['slug'] = tvshowdata.related[i].slug;
        }
        if (tvshowdata.related[i].description) {
          json_object_adoric['description'] = tvshowdata.related[i].description;
        }
        if (tvshowdata.related[i].id) {
          json_object_adoric['contentId'] = tvshowdata.related[i].id;
        }
        if (tvshowdata.related[i].list_image) {
          json_object_adoric['img1'] = this.imageBasepath + tvshowdata.related[i].id + '/list/' + '1920x770/' + tvshowdata.related[i].list_image  + '?imwidth=1920&impolicy=akamai_vidz1_zee5_com-IPM';
          json_object_adoric['img2'] = this.imageBasepath + tvshowdata.related[i].id + '/list/' + '270x152/' + tvshowdata.related[i].list_image  + '?imwidth=270&impolicy=akamai_vidz1_zee5_com-IPM';
        }

        adoric_array.push(json_object_adoric);

      }
     // console.log(adoric_array,"adoric array before event fire")
       // if(environment.adoric) {
        this.window.adoricRecomendationContent = adoric_array;
     //   console.log('adoricRecomendationContent', adoricRecomendationContent);
        // }
    } else if ( tvshowdata.buckets && tvshowdata.buckets.length > 0 && tvshowdata.buckets[0].modelName ) {
      for (let i = 0; i < tvshowdata.buckets[0].items.length; i++) {
        let json_object_adoric;
        json_object_adoric = {};

        if (tvshowdata.buckets[0].items[i].title) {
          json_object_adoric['title'] = tvshowdata.buckets[0].items[i].title;
        }
        if (tvshowdata.buckets[0].items[i].slug) {
          json_object_adoric['slug'] = tvshowdata.buckets[0].items[i].slug;
        }
        if (tvshowdata.buckets[0].items[i].description) {
          json_object_adoric['description'] = tvshowdata.buckets[0].items[i].description;
        }
        if (tvshowdata.buckets[0].items[i].id) {
          json_object_adoric['contentId'] = tvshowdata.buckets[0].items[i].id;
        }
        if (tvshowdata.buckets[0].items[i].list_image) {
          json_object_adoric['img1'] = this.imageBasepath + tvshowdata.buckets[0].items[i].id + '/list/' + '1920x770/' + tvshowdata.buckets[0].items[i].list_image  + '?imwidth=1920&impolicy=akamai_vidz1_zee5_com-IPM';
          json_object_adoric['img2'] = this.imageBasepath + tvshowdata.buckets[0].items[i].id + '/list/' + '270x152/' + tvshowdata.buckets[0].items[i].list_image  + '?imwidth=270&impolicy=akamai_vidz1_zee5_com-IPM';
        }

        adoric_array.push(json_object_adoric);

      }
     // console.log(adoric_array,"adoric array before event fire")
       // if(environment.adoric) {
        this.window.adoricRecomendationContent = adoric_array;
    }

  }
  /* Function to translate  month */
  private getDateTranslate(date, details) {
      let month, dateString;
      dateString = (new Date(date)).toString().toUpperCase();
      month = dateString.split(' ')[1]; // fetch month
      if (details === 'month') {
        return this.translate.instant('TVGUIDE.' + month); // translate month eg: Jan, Feb, Mar, ...
      }
  }
  public navigateTo(tvShowData) {
    this.navigationUrl = '';
    let base: any;
    base =  (this.assetSubtype === 'zeeOriginals') ? 'zee5originals' : 'tvshows';
    (tvShowData && tvShowData.title && tvShowData.id) ? this.navigationUrl = `/${base}/details/${this.commonService.convertToLowercase(tvShowData.title)}/${tvShowData.id}` : this.navigationUrl = this.router.url;
    this.router.navigate([this.navigationUrl]);
  }

  public mygpSubscriptionroute(): any {
    this.headerservicesService.MygpSubscriptionroute();
  }

//   public finalLangArrayFormed(langArray) {
//       let concatedArray = [];
//      (this.tvshow_tags.length > 0) ? (concatedArray = langArray.concat(this.tvshow_tags)) : false;
//      let descriptiveLangArray = [];
//      for (let i of concatedArray) {
//        if ((descriptiveLangArray.indexOf(this.fetchLabel[i]) === -1)){
//          this.fetchLabel[i] ? descriptiveLangArray.push(this.fetchLabel[i]) : false;
//       }
//      }
//      this.languages = this.convertArrayToString(descriptiveLangArray, ', ')
//  }
//  public audiotagsFromTags(tags) {
//   for (let i of tags) {
//     if (i.includes('audio')) {
//       this.tvshow_tags.push(i.split('_')[1]);
//     }
//   }
// }
}
