import { Component, OnInit , OnDestroy} from '@angular/core';
import { Router } from '@angular/router';
import { HeaderservicesService } from '../services/headerservices.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { RouteService } from '../services/route.service';
import {  NetworkService  } from '../services/network.service';
import { FooterService } from '../services/footerdata.service';
import * as $ from 'jquery';
import { LinkService } from '../services/link.service';
import { SettingsService } from './../services/settings.service';
import { environment } from 'environments/environment';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.less']
})
export class AboutComponent implements OnInit, OnDestroy {
  private router: any;
  private router2: any;
  private pageName: any;
  public country_code: any;
  private data: any;
  public contentValue: any;
  private aboutusBreadCrump: any;
  private translation: any;
  private about_src: any;

  constructor(private linkservice: LinkService, private networkService: NetworkService, private routeservice: RouteService, private gtm: GoogleAnalyticsService, private route: Router, private headerservicesService: HeaderservicesService, private footerservice: FooterService, private settingsService: SettingsService) {
    this.router = route;
    this.router2 = window.location.pathname;
    this.headerservicesService.viewChange(this.router2);
    this.routeservice.setRoute(this.router2);
    this.routeservice.setLoginRoute(window.location.pathname);
  }

  public ngOnInit() {
    $('body').addClass('about');
    this.gtm.storeWindowError();
    this.aboutusBreadCrump = [
        {
          'label': 'BREADCRUMB.HOME',
          'url': '/',
          'enable': true
        },
        {
          'label': 'BREADCRUMB.ABOUTUS',
          'url': '/aboutus',
          'enable': false
        }
      ];
      this.headerservicesService.breadCrump(this.aboutusBreadCrump);
      this.country_code = this.settingsService.getCountry();
      let token;
      token = localStorage.getItem('token');
      if (token) {
          this.translation = localStorage.getItem('UserDisplayLanguage');
      } else {
          this.translation = localStorage.getItem('display_language');
      }
      let network;
      this.linkservice.addTag({ rel: 'canonical', href: window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'privacypolicy'  } );
      network = this.networkService.getScreenStatus();
      this.pageName = 'privacy policy';
      this.gtm.sendPageName(this.pageName);
      this.gtm.sendEvent();
      window.scrollTo(0 , 0);
      // this.about_src = environment.shareUrl + 'zeeaction.php?ccode=' + this.country_code + '&text_type=aboutus_text' + '&translation=' + this.translation;
      this.about_src = environment.contactUs + 'policies.php?lang=' + this.translation + '&ccode=' + this.country_code + '&text_type=aboutus_text';
      this.footerservice.getFooterdata1(this.about_src).subscribe( value => {
        this.contentValue = JSON.parse(value._body);
        $('#loaderPage').css('display', 'none');
      });
    this.linkservice.addTag({rel: 'canonical', href: window.location.origin + '/' + this.routeservice.getBaseLocation() + 'aboutus'});
    window.scrollTo(0 , 0);
    this.pageName = 'about us';
    this.gtm.sendPageName(this.pageName);
    this.gtm.sendEvent();
  }

  public ngOnDestroy () {
    this.linkservice.removeCanonicalLink();
  }

}
