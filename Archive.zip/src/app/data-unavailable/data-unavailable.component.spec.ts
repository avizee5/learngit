import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataUnavailableComponent } from './data-unavailable.component';

describe('DataUnavailableComponent', () => {
  let component: DataUnavailableComponent;
  let fixture: ComponentFixture<DataUnavailableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataUnavailableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataUnavailableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
