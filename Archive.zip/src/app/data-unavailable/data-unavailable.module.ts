import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataUnavailableComponent } from './data-unavailable.component';
import { SharedModule } from '../shared.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule
  ],
  declarations: [DataUnavailableComponent],
  exports: [DataUnavailableComponent]
})
export class DataUnavailableModule { }
