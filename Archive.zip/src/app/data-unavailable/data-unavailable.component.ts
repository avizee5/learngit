import { Component, OnInit } from '@angular/core';
import {environment} from '../../environments/environment';

@Component({
  selector: 'app-data-unavailable',
  templateUrl: './data-unavailable.component.html',
  styleUrls: ['./data-unavailable.component.less']
})
export class DataUnavailableComponent implements OnInit {
  public assetBasePath = environment.assetsBasePath;
  constructor() {
  	// to do
  }

  public ngOnInit() {
  	// todo
  }

}
