import { Component, OnInit, Input, Output, EventEmitter, HostListener, ElementRef, ViewChild, OnChanges} from '@angular/core';
import {environment} from '../../environments/environment';
import { HeaderservicesService } from '../services/headerservices.service';    // services for variable update
import { SubscriptionService } from '../services/subscription.service';
import {CommonService} from '../services/common.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { RouteService } from '../services/route.service';
import * as $ from 'jquery';
@Component({
  selector: 'app-header-scroll',
  templateUrl: './header-scroll.component.html',
  styleUrls: ['./header-scroll.component.less']
})
export class HeaderScrollComponent implements OnInit, OnChanges {
public assetbasepath: any;
public currentTab: any;
public countyCode: any;
public displayLang: any;
private totalWidth: any;
private scrollWidth: any = 75;
private actualWidth: any;
private scrollableWidth: any;
private moveCount = 0;
private totalCount = 0;
public showArrow = true;
public leftArrow = false;
public rightArrow = true;
public searchHide = false;
public dialog = true;
public newsNavItem: any = 'NEWS_PAGE.NEWS';
public premiumTab: any;
@Input() private routeValue: any;
@Input() public menuOption: any;
@ViewChild('scrolldiv') private myScrollContainer: ElementRef;

  constructor(private sub: SubscriptionService, private routeservice: RouteService, private headerservicesService: HeaderservicesService, private gtm: GoogleAnalyticsService, private commonService: CommonService) {
  	this.headerservicesService.headerScrollValue.subscribe(value => {     // login view changes to reflect login/register icon
  		this.searchHide = value;
    });

    this.headerservicesService.dialogValue.subscribe(value => {     // login view changes to reflect login/register icon
  		this.dialog = false;
    });

    // check telco user for subscription
    this.sub.telcoUsersFlagSub.subscribe(value => {
      this.dialog = value ? false : true;
    });

    // check all access pack for subscription
    this.sub.storeAllAccessPack.subscribe(value => {
       this.dialog = value ? false : true;
    });

     // hide subscription button based on config
    this.sub.hideSubBtnConfig.subscribe(value => {
       this.dialog = value ? false : true;
    });
  }
  public ngOnInit() {
  	if (this.headerservicesService.getDialogValue()) {
		this.dialog = false;
	}
	this.displayLang = localStorage.getItem('display_language');
	this.countyCode = localStorage.getItem('country_code');
    let germanLanguage = localStorage.getItem('token') ? localStorage.getItem('UserDisplayLanguage') : localStorage.getItem('display_language'); 
		if (this.countyCode === 'DE' && germanLanguage  === 'de') {
			this.newsNavItem = 'MENU.NEWS_DE';
		} else {
			this.newsNavItem = 'NEWS_PAGE.NEWS';
		}
  	let telcoCheckSub, allAccessSub, configHideBtn;
  	telcoCheckSub = this.sub.getTelcoFlagSub();
  	allAccessSub = this.sub.getAllAccessPackVal();
  	configHideBtn = this.sub.getSubHideBtnConfig();
	this.dialog = (telcoCheckSub) ? false : true;
	this.dialog = (allAccessSub) ? false : true;
	if (localStorage.getItem('country_code') === 'IN') {
		this.dialog = (configHideBtn) ? false : true;
	}
  	this.assetbasepath = environment.assetsBasePath;
  	this.leftArrow = false;
  	this.viewFind();
  	let scope;
  	scope = this;
  	$( document ).ready(function() {
		setTimeout(() => {
  		scope.onresize(null);
  		}, 100);
	});
	if (this.menuOption === 'MENU.PREMIUM') {
		this.premiumTab = 'premium';
	} else {
		this.premiumTab = 'exclusive';
	}
  }
  public ngOnChanges() {
	this.viewFind();
  }
  public viewFind() {   
	  // console.log(this.routeValue, 'this.router Value')
	  let langInUrl;
	  langInUrl = this.routeservice.getcurrentLanguage();
	  langInUrl = langInUrl + (langInUrl ? '/' : '');                                                      // depending on view add class
		if (this.routeValue.match(/livetv/g)) {
			this.currentTab = 2;
		} else if (this.routeValue.match(/tvshows/g)) {
			this.currentTab = 1;
		} else if (this.routeValue.match(/movies/g)) {
			this.currentTab = 3;
		} else if (this.routeValue.match(/premium/g)) {
			this.currentTab = 4;
		} else if (this.routeValue.match(/zee5originals/g)) {
			this.currentTab = 0;
		} else if (this.routeValue.match(/videos/g)) {
			this.currentTab = 5;
		} else if (this.routeValue.match(/news/g)) {
			this.currentTab = 6;
		// }  else if (this.routeValue === '/' || this.routeValue.match(/home/g)) {
  	} else if (this.routeValue === '/' + langInUrl || this.routeValue.match(/home/g)) {
			this.currentTab = 7;
		} else {
			this.currentTab = null;
		}
  }
 @HostListener('window:resize', ['$event'])
	public onResize(event) {
	  this.onresize(event.target);
	}
private onresize(event) {
setTimeout(() => {
	this.actualWidth = ($('#scrollableArea').width());
	if ($('#scrollableArea') && $('#scrollableArea')['0']) {
	  	this.totalWidth =  $('#scrollableArea')['0'].scrollWidth;
	  	this.scrollableWidth = this.totalWidth - this.actualWidth ;
	  	this.showArrow = (this.scrollableWidth > 0.5) ? true : false;
	  	this.totalCount = Math.ceil(this.scrollableWidth / this.scrollWidth);
  	}
  }, 1 );
}
public scrollDiv(): void {
	if (this.myScrollContainer.nativeElement.scrollLeft === 0) {
		this.leftArrow = false;
		this.rightArrow = true;
	} else if (this.myScrollContainer.nativeElement.scrollLeft >= Math.round(this.scrollableWidth)) {
		this.rightArrow = false;
		this.leftArrow = true;
	} else {
		this.rightArrow = true;
		this.leftArrow = true;
	}
}
	private shiftPrevious() {
	 	$('#scrollableArea').animate({scrollLeft: '-=' + this.scrollWidth + 'px'});
	}
	private shiftNext() {
 		$('#scrollableArea').animate({scrollLeft: '+=' + this.scrollWidth + 'px'});
	}
	public sendHeaderTabDetails(details) {
	    let headerDetails;
	    headerDetails = {
	      'event': 'pageComponentInteractions',
	      'headerTab': this.commonService.convertToTitlecase(details)
	    };
	    this.gtm.sendEventDetails(headerDetails);
	}
	// public mygpSubscriptionroute(): any {
	//   this.headerservicesService.MygpSubscriptionroute();
	// }
}
