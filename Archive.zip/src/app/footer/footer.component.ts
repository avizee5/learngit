import { Component, OnInit, Input, HostListener } from '@angular/core';
import * as $ from 'jquery';
import { VideoService } from '../services/video.service';
import { environment } from '../../environments/environment';
import { SubscriptionService } from '../services/subscription.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { SettingsService } from '../services/settings.service';
import { HeaderservicesService } from '../services/headerservices.service';
import { Router } from '@angular/router';
import {UserApi} from 'data/user/api/api';
import { Http} from '@angular/http';
import { Subject } from 'rxjs/Subject';

@Component({
selector: 'app-footer',
templateUrl: './footer.component.html',
styleUrls: ['./footer.component.less']
})
export class FooterComponent implements OnInit {
	@Input() public tvguildefooter;
	public flag = true;
	public assetbasePath = environment.assetsBasePath;
	public gototopflag = false;
	public localstorage: any;
	public window: any;
	public navigator: any;
	public document: any;
	public imgSrcFb = environment.assetsBasePath + 'assets/social/social.svg#fb_icon-view';
	 public imgSrcIg = environment.assetsBasePath + 'assets/social/social.svg#insta_icon-view';
	// imgSrcIg = 'assets/social/insta_icon.svg';
	public imgSrcTw = environment.assetsBasePath + 'assets/social/social.svg#twitter_icon-view';
	public followFb: any;
	public followIg: any;
	public followTw: any;
	public downloadAndroid = environment.downloadAndroid;
	public downloadIos = environment.downloadIos;
	public assestMsg: any;
	public ieBrowser = false;
	public condition_show = true;
	public menu_options: any;
	public cookieOption = false;
	public configData: any;
	public countryList: any;
	public followFbEnable = true;
	public followGpEnable = true;
	public followIgEnable = true;
	public helpRoute: any;
	private ngUnsubscribe = new Subject<any>();
	public appVersion: any;
	constructor(private route: Router, @Inject(PLATFORM_ID) private platformId: Object, private settingsService: SettingsService, private headerservicesService: HeaderservicesService, private videoService: VideoService, private sub: SubscriptionService, private gtm: GoogleAnalyticsService, private http: Http) {
		this.headerservicesService.footerOptionValue.subscribe(value => {
			this.condition_show = value;
		});
		this.headerservicesService.cookieOptionValue.subscribe(value => {
			this.cookieOption = value;
		});
	}

	public ngOnInit() {
		if (isPlatformBrowser(this.platformId)) {
		   this.localstorage = localStorage;
		    this.window = window;
		    this.document = document;
		    this.navigator = navigator;
		}
		// this.SettingsService.getCountryListNew().subscribe(value => {
		// 	this.menu_options = value
		// 	console.log(this.menu_options,'this.menu_options')
		// 	if(this.menu_options[0].menu_options['app_download_links'] == 'yes') {
		// 		this.condition_show = true;
		// 	}
		// })
		this.hextokenFunction();
		this.cookieOption = this.headerservicesService.getfooterCookies();
		this.gtm.storeWindowError();
		this.assestMsg = 'TOAST_MESSAGES.TRY_LATER';
  		this.countryList = this.settingsService.getCountryValueNew();
  			let data;
  			data = this.countryList && this.countryList[0] && this.countryList[0].footer_options;
  			data && data.facebook && (data.facebook !== null || data.facebook !== undefined || data.facebook !== '') ? (this.followFb = data.facebook) : (this.followFbEnable = false);
  			data && data.twitter && (data.twitter !== null || data.twitter !== undefined || data.twitter !== '') ? (this.followTw = data.twitter ) : (this.followGpEnable = false);
  			data && data.instagram && (data.instagram !== null || data.instagram !== undefined || data.instagram !== '') ? (this.followIg = data.instagram) : (this.followIgEnable = false);
		let self;
		self = this;
		$(this.document).on( 'scroll', function() {
			let scroll;
			scroll = $(window).scrollTop();
			if (scroll === 0) {
				self.gototopflag = false;
			} else {
				self.gototopflag = true;
			}
		});
		$(this.document).ready(function() {
			self.videoService.castWindowWidth = $('#line').width();
		});
		let browser;
		 browser = this.videoService.get_browser();
		if (browser.name === 'IE') {
			this.ieBrowser = true;
		}
		this.sub.toastClass('assetType-failure');

		this.appVersion = this.window.appVersion;
	}

	@HostListener('window:resize', ['$event'])
	public fontReScale(event) {
		this.videoService.castWindowWidth = $('#line').width();
	}

  public hextokenFunction(): any {
    let ccode, language, userType, hextoken, appVersion;
    ccode = this.localstorage.getItem('country_code');
    language = this.localstorage.getItem('token') ? this.localstorage.getItem('UserDisplayLanguage') : this.localstorage.getItem('display_language');
    userType = this.localstorage.getItem('token') ? 'loggedin' : 'guest';
    hextoken = this.localstorage.getItem('hextoken');
    appVersion =  this.window.appVersion;
    this.helpRoute = environment.shareUrl + 'help?translation=' + language + '&country=' + ccode + '&hextoken=' + hextoken + '&platform=desktop_web' + '&user_type=' + userType + '&app_version=' + appVersion;
  }

  public goToHelp(): any {
    let ccode, language, userType, hextoken, userToken;
    ccode = this.localstorage.getItem('country_code');
    language = this.localstorage.getItem('token') ? this.localstorage.getItem('UserDisplayLanguage') : this.localstorage.getItem('display_language');
    userType = this.localstorage.getItem('token') ? 'loggedin' : 'guest';
    hextoken = this.localstorage.getItem('hextoken');
    // let url;
    // url = 'http://localhost:5000/help/?translation=' + language + '&country=' + ccode + '&hextoken=' + hextoken + '&platform=desktop_web' + '&user_type=' + userType + '&app_version=' + this.appVersion;
    if ((userType === 'loggedin') && ((hextoken == null) || (hextoken === 'null') || (hextoken === ''))) {
      userToken = this.localstorage.getItem('token');
      const params = 'bearer ' + userToken;
      this.window.scrollTo(0, 0);
      const config = {
        apiKey: params,
        username: ' ',
        password: ' ',
        accessToken: ' ',
        withCredentials: true
      };
       const userDetails = new UserApi(this.http, null, config);
       let dataHextoken;
       dataHextoken = {'identifier': 'web', 'partner': 'contactus'};
       userDetails.v1PostHextoken('contactus', dataHextoken).takeUntil(this.ngUnsubscribe).subscribe(hextoken_data => {
          hextoken = hextoken_data.json().token;
          window.open(environment.shareUrl + '/help?translation=' + language + '&country=' + ccode + '&hextoken=' + hextoken + '&platform=desktop_web' + '&user_type=' + userType + '&app_version=' + this.appVersion, '_blank');
       },
       err => {
        window.open(environment.shareUrl + '/help?translation=' + language + '&country=' + ccode + '&hextoken=' + hextoken + '&platform=desktop_web' + '&user_type=' + userType + '&app_version=' + this.appVersion, '_blank');
       });

    } else {
       window.open(environment.shareUrl + '/help?translation=' + language + '&country=' + ccode + '&hextoken=' + hextoken + '&platform=desktop_web' + '&user_type=' + userType + '&app_version=' + this.appVersion, '_blank');
    }
  }
	public onMouseOverFb(): void {
		// this.imgSrcFb = environment.assetsBasePath + 'assets/social/fb_icon_selected.svg';
		this.imgSrcFb = environment.assetsBasePath + 'assets/social/social.svg#fb_icon_selected-view';
	}

	public onMouseOutFb(): void {
		// this.imgSrcFb = environment.assetsBasePath + 'assets/social/fb_icon.svg';
		this.imgSrcFb = environment.assetsBasePath + 'assets/social/social.svg#fb_icon-view';
	}
	public onMouseOverGp(): void {
		// this.imgSrcGp = environment.assetsBasePath + 'assets/social/google_icon_selected.svg';
		// this.imgSrcIg = environment.assetsBasePath + 'assets/social/insta_icon_selected.svg';
		this.imgSrcIg = environment.assetsBasePath + 'assets/social/social.svg#insta_icon_selected-view';
	}

	public onMouseOutGp(): void {
		// this.imgSrcGp = environment.assetsBasePath + 'assets/social/google_icon.svg';
		// this.imgSrcIg = environment.assetsBasePath + 'assets/social/insta_icon.svg';
		this.imgSrcIg = environment.assetsBasePath + 'assets/social/social.svg#insta_icon-view';
	}
	public onMouseOverTw(): void {
		// this.imgSrcTw = environment.assetsBasePath + 'assets/social/twitter_icon_selected.svg';
		this.imgSrcTw = environment.assetsBasePath + 'assets/social/social.svg#twitter_icon_selected-view';
	}

	public onMouseOutTw(): void {
		// this.imgSrcTw = environment.assetsBasePath + 'assets/social/social.svg#twitter_icon_selected-view';
		this.imgSrcTw = environment.assetsBasePath + 'assets/social/social.svg#twitter_icon-view';
	}

	public check() {
		if (this.tvguildefooter) {
			return true;
		} else if (this.gototopflag) {
			return true;
		} else if (!this.gototopflag) {
			return false;
		} else {
			return false;
		}
	}
	public top() {
		this.sub.footerclick(true);
		$('html,body').animate({
        		scrollTop: 1},
        'slow');
        if (this.tvguildefooter) {
           $('#epgslot').animate({
            	scrollTop: 1
       		}, 'slow');
       }
       if ($('.subscriptionComponent')) {
       		 $('.subscriptionComponent').animate({
            	scrollTop: 1}, 'slow');
       }
	}
	public naviGate(path) {
      this.route.navigate([path]);
  }
  public sendBottomHeaderDetails(bottomdetails) {
  	let details;
  	details = {
  		'event': 'pageComponentInteractions',
  		'bottomHeader': bottomdetails
  	};
  	this.gtm.sendEventDetails(details);
  }
}
