import { Component, OnInit } from '@angular/core';
import { HeaderservicesService } from '../services/headerservices.service';

@Component({
  selector: 'app-language-slide',
  templateUrl: './language-slide.component.html',
  styleUrls: ['./language-slide.component.less']
})
export class LanguageSlideComponent implements OnInit {

  constructor(private headerservicesService: HeaderservicesService) { }

  public ngOnInit() {
  	// to do
 }
}
