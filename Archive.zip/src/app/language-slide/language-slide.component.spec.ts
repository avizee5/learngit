import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LanguageSlideComponent } from './language-slide.component';

describe('LanguageSlideComponent', () => {
  let component: LanguageSlideComponent;
  let fixture: ComponentFixture<LanguageSlideComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LanguageSlideComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LanguageSlideComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
