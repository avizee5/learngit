import { Component, AfterViewInit, OnInit, Input, Output, HostListener, EventEmitter, OnDestroy, AfterViewChecked, ViewChild, ElementRef} from '@angular/core';
import * as $ from 'jquery';
import { HeaderservicesService } from '../services/headerservices.service';
import {Subscription} from 'rxjs/Rx';
import {TimerObservable} from 'rxjs/observable/TimerObservable';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/observable/timer';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import * as userApi from '../../data/user/api/api';
import { Http } from '@angular/http';
import { Location } from '@angular/common';
import { UserApiService } from '../services/user-api.service';
import { RouteService } from '../services/route.service';
import { SettingsService } from '../services/settings.service';
import {environment} from '../../environments/environment';
declare const FB: any;
// declare const gapi: any;
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import {  NetworkService  } from '../services/network.service';
import 'rxjs/add/operator/timeout';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
declare const qg;
import * as SettingsApi from '../../data/user/api/api';
import * as subscritionplanApi from './../../data/subscription/api/api';
import { UseractionapiService } from '../services/useractionapi.service';
import { UserApi } from '../../data/user/api/api';
import { LinkService } from '../services/link.service';
import { SeoService } from '../services/seo.service';
import { VideoService } from '../services/video.service';
import {CommonService} from '../services/common.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.less']
})
export class RegisterComponent implements OnInit, OnDestroy, AfterViewInit  {

  private GOOGLE_CLIENT_ID = environment.GOOGLE_CLIENT_ID;
  private emailCheck = false;
  private emailplace = false;
  private place = false;
  private place1 = false;
  private passwordCheck = false;
  private passwordCheck1 = false;
  private type: boolean;
  private assetbasepath: any;
  private source1 = this.assetbasepath + 'assets/sign_in/ic_eye_normal.png';
  private source2 = this.assetbasepath + 'assets/sign_in/ic_eye.png';
  private icon_source1 = this.assetbasepath + 'assets/sign_in/mobile_icon.png';
  private icon_source2 = this.assetbasepath + 'assets/sign_in/mail_icon.png';
  private source_dropdown: any = this.assetbasepath + 'assets/sign_in/dropdwn_icn.png';
  private signinLeft: any;
  private signinTop: any;
  private bg_hide: any;
  private registerEmailclose: any;
  private registerMobileclose: any;
  private profileShow: any;
  private email_return = false;
  private password_return = false;
  private mobile_return = false;
  private dropDownCheck = false;
  private selected_country: any;
  private id: any;
  private country_code: any;
  private email_return_keypress = false;
  private password_return_keypress = false;
  private mobile_return_keypress = false;
  private country_codeLength: number;
  private countdown_time = '20:00';
  private otp_return = false;
  private otp_return_keypress = false;
  private otpPlace = false;
  private otpCheck = false;
  private interval: any;
  private timer2: string;
  private timer_return = true;
  private timer_return_keypress = true;
  private userapi: any;
  private entered_email: string;
  private entered_password: string;
  private changePassword: any = 'LOGIN.PASSWORD';
  private changeEmail: any = 'LOGIN.EMAIL_ID';
  private enter_otp: any = 'LOGIN.ENTER_OTP';
  private try_later: any = 'TOAST_MESSAGES.TRY_LATER';
  private errors: any;
  public error_message: any;
  private responseEmail: any;
  private token: string;
  private buttonChange = false;
  private user_data: any;
  private timer_true_change: any;
  private responseMobile: any;
  private confirmed_mobile = false;
  private pageName: any;
  private registerSuccess = false;
  private userId: any;
  public auth2: any;                                       // G+ sigin api call variable
  private token1: any;
  private loged = false;
  private user = { name: 'Hello' };
  private saveToken: any;
  private fBToken: any;
  public errorMessage: any;
  private saveTokenFacebook: any;
  private previousUrl: any;
  private profileActive: any;
  private countdown_time2 = '00:30';
  private timer_second: string;
  private second_interval: any;
  private tokenValue: any;
  private timestampTime: any;
  private timestampDateTime: any;
  private emailContainerFlag: any;
  public registerPageFlag: any;
  private icon: any;
  private regex: any;
  private phone_code: any;
  private currentIndex: any = 0;
  private previousIndex: any = 0;
  private countryList: any;
  private configdata: any;
  private country_selected_index: any = 0;
  private localstorage: any;
  private window: any;
  private document: any;
  private navigator: any;
  private country: any;
  private register_mobile: any = false;
  private configData: any;
  private countrycode: any;
  // private ConsentArray: any;
  // private RadioArray: any;
  private selectionTrack: Array<any> = [];
  private selectedButtonId: Array<any> = [];
  private controlRipple: any;
  private receivedValue: any;
  private loader = false;
  private loaderImage = environment.assetsBasePath + 'assets/common/loading.gif';
  private version_number: any;
  private socialFlag = false;
  private googleAccessToken: any;
  private googleObj: any;
  private socialType: any;
  private gdprCountryChange = false;
  private loginPageFlag = false;
  private loginFrom: any;
  private sendToken: any;
  private gdprValue: any;
  public gdprFlag: any;
  private config: any;
  private userSettings: any;
  private login_type: any;
  private default_settings: any;
  private promoApiCall: any;
  private userData: any;
  private settingsResponse: any;
  private displayDialog: any;
  private promotional: any;
  private countryToken: any;
  private cookiesLocal: any;
  private marketingLocal: any;
  private responsevalue: any;
  private countryListNew: any;
  private fireFoxdropReg = false;
  private clientID: any;
  private marketingValue: any;
  public guest_token: any;
  @ViewChild('triggerClickLogin') public loaderPage: ElementRef;
  @Input() private bg_imageFlag: boolean;
  @Input() private registerMobile: boolean;
  @Input() private registerEmail: boolean;
  @Input() private signInComponent: boolean;
  @Input() private signinRightTop: boolean;
  @Input() private signinLeftFlag: boolean;
  @Input() private signinHide: any;
  @Input() private signinDetailsFlag: any;
  @Input() private profileActivationFlag: any;
  @Input() public verification_email: any;
  @Input() public verification_mobile: boolean;
  @Input() private timer_true: boolean;
  @Input() private countryListCCode: any;
  private loginMethod: any;
  private registerTop: any;
  private countries: any;
  private acces: any;
  private qgraph: any;
  @Output() public update = new EventEmitter<boolean>();     // to send data back to component
  constructor(@Inject(PLATFORM_ID) private platformId: Object, private commonService: CommonService, private videoService: VideoService, private seoservice: SeoService, private linkservice: LinkService, private userAction: UseractionapiService, private networkService: NetworkService, private settingsService: SettingsService, private routeservice: RouteService, private to: Location , private headerservicesService: HeaderservicesService, private http: Http, private userapiService: UserApiService, private gtm: GoogleAnalyticsService) {
    if (isPlatformBrowser(this.platformId)) {
        this.localstorage = localStorage;
        this.window = window;
        this.document = document;
        this.navigator = navigator;
    }
    this.headerservicesService.buttonChangeValue.subscribe(value => {  // to personlize screen
     this.buttonChange = value;
    });
    this.headerservicesService.verificationEmailValue.subscribe(value => {  // to display continue page
      this.verification_email = value;
    });
    this.headerservicesService.verificationMobileValue.subscribe(value => {  // opt screen 2nd page
      this.verification_mobile = value;
    });
    this.headerservicesService.registerSuccessValue.subscribe(value => {    // for api success true
      this.registerSuccess = value;
    });
    this.headerservicesService.registerPageValue.subscribe(value => {  // entir regration page
      this.registerPageFlag = value;
    });
    this.assetbasepath = environment.assetsBasePath;
    this.source1 = this.assetbasepath + 'assets/sign_in/ic_eye_normal.png';
    this.source2 = this.assetbasepath + 'assets/sign_in/ic_eye.png';
    this.icon_source1 = this.assetbasepath + 'assets/sign_in/mobile_icon.png';
    this.icon_source2 = this.assetbasepath + 'assets/sign_in/mail_icon.png';
    this.source_dropdown = this.assetbasepath + 'assets/sign_in/dropdwn_icn.png';
    this.configData = this.settingsService.getCompleteConfig();
     $('#loaderPage').css('display', 'block');

    this.headerservicesService.blockeventsValue.subscribe(value => {
     this.qgraph = this.headerservicesService.getRemarketing();
    });
  }
  public ngAfterViewInit() {
    if (this.timer_true === true) {  // for mobile timer
      this.SecondTimer();
      this.setTimer();
    }
     this.googleInit();
  }
  public ngOnInit() {
    if (!this.verification_email && !this.verification_mobile) {
      this.emailContainerFlag = true;  // right side social
      this.registerPageFlag = true;
    } else {
      this.emailContainerFlag = false;
      this.registerPageFlag = false;
      this.headerservicesService.RegisterPageChange(false);
    }
    this.gtm.storeWindowError();
    this.qgraph = this.headerservicesService.getRemarketing();
    this.previousUrl = this.routeservice.getLoginRoute();
    this.cookiesLocal = this.localstorage.getItem('cookies');
    this.marketingLocal = this.localstorage.getItem('marketing');
    this.guest_token = this.localstorage.getItem('guestToken');
    this.version_number = this.navigator.userAgent;  // gdpr additional field version number while post
    if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
      this.document.getElementById('body').classList.add('modal-open');
    }
    if (this.registerMobile) {  // assest mobile
      this.icon = false;
     } else if (this.registerEmail) {  // assest mail
        this.icon = true;
     }
    this.userapi = new userApi.UserApi(this.http, null, null);
    this.countrycode = this.settingsService.getCountry();
    $(this.document).ready(function() {
      $('#mobileNumber').keydown(function (e) {
          // Allow: backspace, delete, tab, escape, enter.
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
               // Allow: Ctrl+A, Command+A
              (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
              // Allow: Ctrl+V, Command+V
              (e.keyCode === 86 && (e.ctrlKey === true || e.metaKey === true)) ||
               // Allow: home, end, left, right, down, up
              (e.keyCode >= 35 && e.keyCode <= 40)) {
                   // let it happen, don't do anything
                   return;
          }
          // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
              e.preventDefault();
        }
      }).on('paste', function (e) {
          setTimeout(function () {
                $('#mobileNumber').val($('#mobileNumber').val().replace(/[^0-9]/g, ''));  // mobile paste
            }, 5);
      });
    });
   let scope;
   scope = this;
    $(this.document).mouseup(function(e) {
      if (e.target.id !== 'info' && !$('#info').find(e.target).length) {
        if (scope.dropDownCheck === true) {
          scope.dropDownCheck = false;
        }
      }
    });
   $(this.document).on('touchstart' , function(e) {
      if (e.target.id !== 'info' && !$('#info').find(e.target).length) {
        if (scope.dropDownCheck === true) {
          scope.dropDownCheck = false;
        }
      }
    });
    this.entered_email = '';
    this.type = false;
    this.configdata = this.settingsService.getCompleteConfig();
    this.countryListNew = this.countryListCCode;
    if (this.countryListNew && this.countryListNew.length >= 1) {
     this.country_code = '+' + this.countryListNew[0]['phone-code'] + ' - ';
     this.phone_code = this.countryListNew[0]['phone-code'];
    if (this.countryListNew[0] && this.countryListNew[0].mobile_registration) {
                  this.register_mobile = this.countryListNew[0].mobile_registration;
                  if (this.register_mobile === 'false') {

                      this.register_mobile = false;
                  } else if (this.register_mobile === 'true') {
                      this.register_mobile = true;
                  }
                } else if (this.configdata) {
                  if (this.configdata.mobile_registration) {
                this.register_mobile = this.configdata.mobile_registration;
              } else if (this.configdata.mobile_registration === false) {
                  this.register_mobile = this.configdata.mobile_registration;
              } else {
                   this.register_mobile = true;
              }
                }
}
    this.country = this.settingsService.getCountryValue();
    setTimeout(() => {
      this.countryList = this.settingsService.getcountryApiList();
        if ( this.countryList === undefined || this.countryList.length === 0) {
          this.settingsService.getCountryList().timeout(environment.timeOut).subscribe(value => {  // countrylilst api
            this.countries = value;
            if (this.countries.length === 0) {
              this.countries = this.countryListNew[0];
            } else {
            this.settingsService.setCountryListValue(value);
            let selected_country_apiFirst;
            selected_country_apiFirst = this.settingsService.getCountry();
            let country;
            for (country in this.countries) {
              if (this.countries[country].code === selected_country_apiFirst) {
                this.currentIndex = country;
                this.country_selected_index = country;
                this.selected_country = this.countries[country];
                if (this.countries[country].code === 'IN') {  // +91
                    this.country_codeLength = 10;
                } else {
                  this.country_codeLength = 13;
                }
                  break;
              }
            }
            }
          }, error => {
            if (this.configdata) {
              this.currentIndex = 0;
              this.selected_country = {'name': this.country.country, 'code': this.country.country_code, 'phone-code': '-'};
              this.countries = [{'name': this.country.country, 'code': this.country.country_code, 'phone-code': '-'}];
              this.country_code = null;
              if (this.country.country_code !== 'IN') {  // without +91
                this.country_codeLength = 20;
              } else {
                this.country_codeLength = 12;
              }
            } else {
              this.phone_code = this.configdata.region.IN.India.code;
              this.phone_code = this.configdata.region.IN.India.code.replace('+', '');
              this.selected_country = {'name': this.country.country, 'code': this.country.country_code, 'phone-code': this.phone_code};
              this.countries = [{'name': this.country.country, 'code': this.country.country_code, 'phone-code': this.phone_code}];
              this.country_code = this.configdata.region.IN.India.code + '-';
              this.register_mobile = this.configdata.mobile_registration;
            }
          });
        } else {
          this.countries = this.countryList;
          let selected_country_api;
          selected_country_api = this.settingsService.getCountry();
          let country;
          for (country in this.countries) {
            if (this.countries[country].code === selected_country_api) {
                this.currentIndex = country;
                this.country_selected_index = country;
                this.selected_country = this.countries[country];
                if (this.countries[country].code === 'IN') {
                  this.country_codeLength = 10;
                } else {
                  this.country_codeLength = 13;
                }
                break;
            }
          }
          $('#loaderPage').css('display', 'none');
        }
    }, 0);
     this.gtm.FacebookInitialization();
  }
////////////////////// login with social network ////////////////
  private deleteCookie(): any {  // for twitter
    document.cookie = 'PHPSESSID' + '=; Path=/;Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
    this.localstorage.removeItem('twitterTime');
  }
  private twitterRegister() {
   let network;
   network = this.networkService.getPopupStatus();
   if (network === true) {
     this.deleteCookie();
      let x , y ;
       x = new Date();
       y = x.getTime();
      // $('#twitterRegister').attr('href', environment.twitterLogin + '&ver=' + y);
      location.href = environment.twitterLogin + '&ver=' + y;
               this.pageName = 'sign in/twitter';
               this.gtm.sendPageName(this.pageName);
               this.gtm.sendEvent();
               this.qgraphevent('signin_initiated', {'method': 'social_twitter', 'country' : this.countrycode, 'state': localStorage.getItem('state_code') });
   }
  }
  private googleGm() {
     let network;
     network = this.networkService.getPopupStatus();
     this.pageName = 'register/google';
     this.gtm.sendPageName(this.pageName);
     this.gtm.sendEvent();
     this.qgraphevent('signup_initiated', {'method': 'social_google', 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
  }
  private facebookGm() {
     this.pageName = 'register/facebook';
     this.gtm.sendPageName(this.pageName);
     this.gtm.sendEvent();
     this.qgraphevent('signup_initiated', {'method': 'social_fb', 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
  }
  private googleInit() {
    if ( this.window && this.window.gapi) {
      this.window.gapi.load('auth2', () => {
         let that;
         that = this;
        this.auth2 = this.window.gapi.auth2.init({
          client_id:   that.GOOGLE_CLIENT_ID,
          cookiepolicy: 'single_host_origin',
          scope: 'profile'
        });
        this.attachSignin(this.document.getElementById('go'));
      });
    }
  }
  private attachSignin(element) {
    this.auth2.attachClickHandler(element, {},
      (googleUser) => {
        let profile;
        profile = googleUser.getBasicProfile();
        this.acces = this.window.gapi.auth2.getAuthInstance().currentUser.get().getAuthResponse(true).access_token;
        this.googleloginApi(this.acces);
        }, error => {
        // console.log('error', error);
        });
  }
  private checkLoginState() {
   let network;
   network = this.networkService.getPopupStatus();
   if (network === true) {
     this.errorMessage = this.localstorage.getItem('header');
    if (this.errorMessage != null) {
          if (this.errorMessage === 'false') {
            this.errorMessage  = 'TOAST_MESSAGES.TRACKING';
                  this.callToastFacebook();
          }
    }
      FB.getLoginStatus(response => {
      this.statusChangeCallback(response);
      });
    }
  }
  private statusChangeCallback(response: any) {
      if (response.status === 'connected') {
          this.login();
      } else {
          this.login();
      }
  }
  private login() {
    FB.login(result => {
        this.loged = true;
        this.token1 = result;
        if (this.token1.authResponse != null) {
          this.fBToken = this.token1.authResponse.accessToken;
          this.facebookloginApi(this.fBToken);
        }
        this.me();
    }, { scope: 'public_profile,email' });
  }
  private me() {
     FB.api('/me?fields=id,name,first_name,email,gender,picture.width(150).height(150),age_range',
     function(result) {
        if (result && !result.error) {
          this.user = result;
        } else {
          // todo
        }
      });
  }
  private googleloginApi(acces): any {
    if (acces) {
      this.removeSignin();
      this.userapi.v1UserLogingoogleGet(acces).timeout(environment.timeOut).subscribe(response => {
      this.saveToken = response.token;
      this.loginMethod = 'login';
      this.checkGdprNode(this.saveToken, 'google');
      }, err => {
                  this.openSignin();
                  if (err.name === 'TimeoutError') {
                    this.errorMessage = 'MESSAGES.TRY_LATER';
                    this.callToastFacebook();
                  } else if (err.status === 404) {
                    this.qgraphevent('signin_failure', {'method': 'social_google', 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
                    this.GAUpdateCommon('LoginFailed', 'googleplus');
                    this.gtm.sendErrorEvent('api', err);
                    this.gdprFlag = true;
                    this.socialFlag = true;
                    this.socialType = 'google';
                    this.loginFrom = 'register';
                    this.registerPageFlag = false;
                    this.headerservicesService.registerMobilechange(false);
                    this.headerservicesService.bgImageValueChange(true);
                    this.headerservicesService.signinDetailsChange(false);
                    this.headerservicesService.signinRightTopChange(true);
                    this.headerservicesService.signinLeftChange(true);
                    this.simulateUserGesture();
                    this.triggerClick();
                    //  $('#loaderPage').css('display', 'block');
                  } else {
                    this.errorMessage = 'MESSAGES.TRY_LATER';
                    this.callToastFacebook();
                  }
      });
    }
  }
  private googleRegister(): any {
    this.createObject(this.acces);
    if (this.googleObj) {
       this.userapi.v1UserRegistergooglePost(this.googleObj).timeout(environment.timeOut).subscribe(response => {
         this.loginMethod = 'register';
         this.saveToken = response.token;
         // this.CommonConfigCall(this.saveToken);
          setTimeout(() => {
         this.updateSettingApi(this.saveToken, 'google', 'register');
         this.qgraphevent('signup_success', {'method': 'social_google', 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
       }, 0);
          this.GAUpdateCommon('RegisterSuccess', 'googleplus');
        }, error => {
               this.errors = error.json();
               this.openSignin();
               if (error.name === 'TimeoutError') {
               this.errorMessage = 'MESSAGES.TRY_LATER';
                 this.callToastFacebook();
               } else if (error.status === 404) {
                this.errorMessage = this.errors.message;
                setTimeout(() => {
                    if (this.errorMessage) {
                      this.callToastFacebook();
                    }
                }, 3000);
              } else if (error.status === 400) {
                  this.gdprFlag = false;
                  this.registerPageFlag = true;
                  this.errorMessage = 'MESSAGES.TRY_LATER';
                 this.callToastFacebook();
              } else {
                this.errorMessage = 'MESSAGES.TRY_LATER';
                 this.callToastFacebook();
              }
              this.GAUpdateCommon('RegisterFailed', 'googleplus');
              this.qgraphevent('signup_failure', {'method': 'social_google', 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
             this.gtm.sendErrorEvent('api', error);
       });
    }
  }
  private facebookloginApi(fBToken) {
   if (fBToken) {
     this.removeSignin();
     this.userapi.v1UserLoginfacebookGet(fBToken).timeout(environment.timeOut).subscribe(response => {
         this.loginMethod = 'login';
        this.checkGdprNode(response.token, 'facebook');
     }, error => {
          this.openSignin();
          if (error.name === 'TimeoutError') {
            this.errorMessage = 'MESSAGES.TRY_LATER';
            this.callToastFacebook();
          } else if (error.status === 404) {
              this.qgraphevent('signin_failure', {'method': 'social_fb', 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
              this.GAUpdateCommon('LoginFailed', 'facebook');
              this.gtm.sendErrorEvent('api', error);
              this.gdprFlag = true;
              this.socialFlag = true;
              this.socialType = 'facebook';
              this.loginFrom = 'register';
              this.registerPageFlag = false;
              this.headerservicesService.registerMobilechange(false);
              this.headerservicesService.bgImageValueChange(true);
              this.headerservicesService.signinDetailsChange(false);
              this.headerservicesService.signinRightTopChange(true);
              this.headerservicesService.signinLeftChange(true);
              this.simulateUserGesture();
              $('#loaderPage').css('display', 'block');
              this.triggerClick();
          } else {
            this.errorMessage = 'MESSAGES.TRY_LATER';
            this.callToastFacebook();
          }
     });
    }
  }
  private facebookRegister(): any {
  this.createObject(this.fBToken);
    if (this.googleObj) {
      this.userapi.v1UserRegisterfacebookPost(this.googleObj).timeout(environment.timeOut).subscribe(response => {
          this.loginMethod = 'register';
          this.saveTokenFacebook = response.token;
          // this.CommonConfigCall(this.saveTokenFacebook);
          setTimeout(() => {
          this.updateSettingApi(this.saveTokenFacebook, 'facebook', 'register');
            this.qgraphevent('signup_success', {'method': 'social_fb', 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
          }, 0);
          this.GAUpdateCommon('RegisterSuccess', 'facebook');
      }, errors => {
             this.errors = errors.json();
             this.openSignin();
             if (errors.name === 'TimeoutError') {
               this.errorMessage = 'MESSAGES.TRY_LATER';
               this.callToastFacebook();
              } else if (errors.status === 404) {
                this.errorMessage = this.errors.message;
                setTimeout(() => {
                    if (this.errorMessage) {
                      this.callToastFacebook();
                    }
                }, 3000);
              } else if (errors.status === 400 || errors.status === 401) {
              this.gdprFlag = false;
              this.registerPageFlag = true;
               this.errorMessage = 'MESSAGES.TRY_LATER';
               this.callToastFacebook();
              } else {
                this.errorMessage = 'MESSAGES.TRY_LATER';
               this.callToastFacebook();
              }
            this.GAUpdateCommon('RegisterFailed', 'facebook');
            this.qgraphevent('signup_failure', {'method': 'social_fb', 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
            this.gtm.sendErrorEvent('api', errors);
      });
    }
  }
  private createObject(accessToken): any {
    let policyValues, googleObjInt, country_Promotion;
    country_Promotion = this.settingsService.getCountryPromotionalValue();

    policyValues = [];
    for (let i = 0; i < 4; i++) {
        if (!(this.receivedValue.sendValues[i].status) || this.receivedValue.sendValues[i].status === undefined) {
            policyValues[i] = 'na';
        } else if (!(this.receivedValue.sendValues[i].userValue)) {
            policyValues[i] = 'no';
        } else if (this.receivedValue.sendValues[i].userValue === true) {
           policyValues[i] = 'yes';
        }
    }
    googleObjInt = {
       'token' : accessToken,
       'mac_address': '',
       'ip_address': '',
       'registration_country': '',
       'additional': {
          'gdpr_policy': [{
            'country_code': this.countrycode,
            'gdpr_fields': {
              'policy': policyValues[0],
              'profiling': policyValues[1],
              'age': policyValues[2],
              'subscription': policyValues[3]
            }
          }],
          'guest_token': this.guest_token,
          'sourceapp' : 'Web',
          'version_number' : this.version_number,
          'promotional': {
            'on': country_Promotion.on,
            'token': country_Promotion.token
          },
          'first_time_login': '1'
        }
      };
      this.googleObj = this.gtm.checkUpdateCampaign(googleObjInt);
  }
  private updateSettingApi(token, method, type): any {
    if (token) {
      // this.CommonConfigCall(token);
         let params;
        params = 'bearer ' + token ;
       this.config = {
          apiKey: params,
          username: '',
          password: '',
          accessToken: '',
          withCredentials: false
        };
    }
    let policyValues;
    policyValues = [];
    for (let i = 0; i < 4; i++) {
        if (!(this.receivedValue.sendValues[i].status) || this.receivedValue.sendValues[i].status === undefined) {
            policyValues[i] = 'na';
        } else if (!(this.receivedValue.sendValues[i].userValue)) {
            policyValues[i] = 'no';
        } else if (this.receivedValue.sendValues[i].userValue === true) {
           policyValues[i] = 'yes';
        }
    }
    if (!this.gdprCountryChange) {  // register
      let gdprValue, gdprsettings;
        gdprValue = [{
                'country_code': this.countrycode,
                'gdpr_fields': {
                    'policy': policyValues[0],
                    'profiling': policyValues[1],
                    'age': policyValues[2],
                    'subscription': policyValues[3]
                     }
                }];
        gdprsettings = {
                'key': 'gdpr_policy',
                'value': JSON.stringify(gdprValue)
             };
      this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
      this.userSettings.v1SettingsPost(gdprsettings).subscribe(responsePost => {
         if (type !== 'register') {
           this.updateGMID(token, method);
         } else {
            let disp, valuecountryCode;
            disp = this.localstorage.getItem('display_language');
               valuecountryCode = this.settingsService.getCountryValueNew();
              if (valuecountryCode && valuecountryCode.length > 0) {
                this.promotional = valuecountryCode[0].promotional;
                this.countryToken = this.promotional.token;
                if (this.promotional && this.promotional.on === '1') {
                  this.promotionalAPIcall(token, method);
                } else if (this.promotional && this.promotional.on === '0') {
                  this.setFirstTimeloginSocial('1', token, method);
                }
              }
          }
      }, err => {
         // this.SettingapiFails();
          this.settingsFailsRegister(gdprsettings, type, token, method);
        });
    } else {                    // login
           let gdprValue1, gdprsettings;
            gdprValue1 = {
                    'country_code': this.countrycode,
                    'gdpr_fields': {
                      'policy': policyValues[0],
                      'profiling': policyValues[1],
                      'age': policyValues[2],
                      'subscription': policyValues[3]
                    }
                };
              this.gdprValue.push(gdprValue1);
             gdprsettings = {
                'key': 'gdpr_policy',
                'value': JSON.stringify(this.gdprValue)
             };
            this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
            this.userSettings.v1SettingsPut(gdprsettings).subscribe(responsePost => {
            this.updateGMID(token, method);
          }, err => {
           this.openSignin();
           this.errorMessage = 'MESSAGES.TRY_LATER';
           this.callToastFacebook();
          });
    }
    if (type === 'register') {
     this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
      this.userSettings.v1SettingsGet().subscribe( response => {
        this.settingsResponse = response;
         this.cookieConcent(this.settingsResponse);
      }, err => {
        // todo
      });
    }
  }
  private checkGdprNode(token, method): any {
     if (token) {
          this.CommonConfigCall(token);
          this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
          this.userSettings.v1SettingsGet().subscribe( response => {
            this.settingsResponse = response;
            this.cookieConcent(this.settingsResponse);
            let gdpr_Flag;
            if ( response.length > 0) {
              for (let i = 0; i < response.length; i++) {
                if ( response[i].key === 'gdpr_policy') {
                  gdpr_Flag = true;
                  if (!(response[i].value[0] === '{')) {
                    this.gdprValue = JSON.parse(response[i].value);
                    let flagcheck = false;
                    for (let j = 0; j < this.gdprValue.length; j++) {
                    if (this.countrycode === this.gdprValue[j].country_code) {
                      flagcheck = true;
                      break;
                    } else if (j === this.gdprValue.length - 1) {   // no country code match so show GDPR screen with put request
                        flagcheck = false;
                      }
                    }
                    if (flagcheck) {
                      this.updateGMID(token, method);
                    } else {
                      this.gdprCountryChange = true;
                      this.showScreen(token, method);
                    }
                  } else {
                     this.userSettings.v1SettingsDelete('gdpr_policy', token).subscribe(responseput => {
                        this.showScreen(token, method);
                     });
                   }
                }
              }
              if (gdpr_Flag === undefined) {
                this.getSocialUserDetails(token, method);
              }
            } else {
              if (gdpr_Flag === undefined) {
                this.getSocialUserDetails(token, method);
              }
            }
          });
        }
  }
  private getSocialUserDetails(token, method): any {
     let userDetails;
      userDetails = new UserApi(this.http, null, this.config);
      userDetails.v1UserGet().timeout(environment.timeOut).subscribe(value => {
      this.userData = value;
      this.localstorage.setItem('ID', this.userData.id);
      if (value.additional.gdpr_policy) {
        for (let j = 0; j < value.additional.gdpr_policy.length; j++) {
          if (this.countrycode === value.additional.gdpr_policy[j].country_code) {
              let gdprValue;
              gdprValue = [{'country_code': this.countrycode,
                          'gdpr_fields': {
                            'policy': value.additional.gdpr_policy[j].gdpr_fields.policy,
                            'profiling': value.additional.gdpr_policy[j].gdpr_fields.profiling,
                            'age': value.additional.gdpr_policy[j].gdpr_fields.age,
                            'subscription': value.additional.gdpr_policy[j].gdpr_fields.subscription
                          }}];
              const gdpr_settings = {
                        'key': 'gdpr_policy',
                        'value': JSON.stringify(gdprValue)
                      };
              this.userSettings.v1SettingsPost(gdpr_settings).subscribe(responsePost => {
                this.updateGMID(token, method);
              }, err => {
                 this.SettingapiFails();
                });
            } else {
                this.showScreen(token, method);
              }
        }
      } else if (value.additional.gdpr_policy === undefined) { // GDPR post request no node
              this.showScreen(token, method);
        }
      }, err => {
                this.gtm.sendErrorEvent('api', err);
                if (err.name === 'TimeoutError') {
                  this.errorMessage = 'MESSAGES.TRY_LATER';
                  this.callToastFacebook();
                } else {
                  this.errors = err.json();
                  this.errorMessage = this.errors.message;
                  this.callToastFacebook();
                }
          });
  }
  private showScreen(token, method) {
  this.loginPageFlag = false;
  this.gdprFlag = true;
  this.socialFlag = true;
  this.socialType = method;
  this.loginFrom = 'login';   // to differentate register r login
  this.sendToken = token;
  this.triggerClick();
  this.headerservicesService.registerMobilechange(false);
  this.headerservicesService.bgImageValueChange(true);
  this.headerservicesService.signinDetailsChange(false);
  this.headerservicesService.signinRightTopChange(true);
  this.headerservicesService.signinLeftChange(true);
  this.simulateUserGesture();

  }
  private SettingapiFails() {
    $('#loaderPage').css('display', 'none');
    this.errorMessage = 'MESSAGES.TRY_LATER';
    this.callToastFacebook();
    this.gdprFlag = false;
    this.headerservicesService.registerMobilechange(false);
    this.headerservicesService.bgImageValueChange(true);
    this.headerservicesService.signinDetailsChange(true);
    this.headerservicesService.signinRightTopChange(true);
    this.headerservicesService.signinLeftChange(true);
    let scope;
    scope = this;
    setTimeout(function() { scope.callReload(); }, 2500);
  }
  private callReload() {
    $('#SignIncomponent').css('visibility', 'hidden');
    $('#loaderPage').css('display', 'block');
    this.localstorage.setItem('googletag', 'false');
    // if (!state) {
    //   location.href = this.window.location.origin + this.previousUrl;
    // } else {
      this.changeRoute();
    // }
  }
  private changeRoute(): any {
    let postRoute;
    postRoute = this.localstorage.getItem('postSubscriptionRoute');
    if (this.previousUrl !== '/myaccount/subscription' && postRoute) {
      this.localstorage.removeItem('postSubscriptionRoute');
      this.commonService.getPostSubscriptionRoute(postRoute, 'login');
    } else {
      location.href = this.window.location.origin + this.previousUrl;
    }
  }
  private callToastFacebook() {
      let p;
      p = this.document.getElementById('snackbarFacebook');
      p.className = 'show';
      setTimeout(function() { p.className = p.className.replace('show', ''); }, 5000);
  }
  private confirmationPage(type, token) {
    this.localstorage.setItem('login', type);
    this.localstorage.setItem('token',  token);
    this.localstorage.setItem('googletag', 'false');
     $('#loaderPage').css('display', 'none');
    this.headerservicesService.RegisterSuccessChange(true);
    this.headerservicesService.loginComponentChange(false);
    this.headerservicesService.loginMobileChange(false);
    this.headerservicesService.loginEmailChange(false);
    this.headerservicesService.registerMobilechange(false);
    this.profileActivationFlag = true;
    this.timer_true = false;
    this.otpCheck = false;
    this.otpPlace = false;
    this.verification_email = false;
    this.registerMobile = false;
    this.registerEmail = false;
    $('#body').addClass('scrolldisbale');
    this.otp_return_keypress = false;
    this.otp_return = false;
    this.registerTop = false;
    this.bg_imageFlag = false;
    this.gdprFlag = false;
    this.pass();
  }
  private triggerClick() {
    let el: HTMLElement = this.loaderPage.nativeElement as HTMLElement;
    el.click();
}
  private updateGMID(userId, method) {
    this.CommonConfigCall(userId);
      let userDetails;
      userDetails = new userApi.UserApi(this.http, null, this.config);
      userDetails.v1UserGet().timeout(environment.timeOut).subscribe(value => {
        this.userId = value.id;
        this.localstorage.setItem('ID', this.userId );
        if (method === 'facebook') {
          this.qgraphevent('Signin_Success', {'method': 'social_fb', 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
          this.GAUpdateCommon('LoginSuccess', 'facebook');
        }
        if (method === 'google') {
          this.qgraphevent('Signin_Success', {'method': 'social_google', 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
          this.GAUpdateCommon('LoginSuccess', 'googleplus');
        }
            this.updatePromotionSocial(value, userId, method);
      }, err => {
           this.userId = 'NA';
           this.callReload();
           this.gtm.sendErrorEvent('api', err);
        });
  }
  private removeSignin() {
    $('#loaderPage').css('display', 'block');
    // $('#ResponsiveTop').css('display', 'none');
    this.registerMobile = false;
    this.registerEmail = false;
    this.registerTop = false;
    this.registerPageFlag = false;
    this.headerservicesService.signinRightTopChange(false);
    this.headerservicesService.bgImageValueChange(false);
    this.headerservicesService.signinLeftChange(false);
  }
  private openSignin() {
    $('#loaderPage').css('display', 'none');
    $('#ResponsiveTop').css('display', 'block');
    this.registerMobile = true;
    this.registerEmail = false;
    this.registerTop = true;
    this.registerPageFlag = true;
    this.headerservicesService.signinRightTopChange(true);
    this.headerservicesService.bgImageValueChange(true);
    this.headerservicesService.signinLeftChange(true);
  }
  private AcceptEnable() {
    if (!(this.receivedValue.sendFlag)) {
          $('.AcceptRegister').css({'background-color': '#50012f', 'color': '#703055'});
          return true;
        } else {
           $('.AcceptRegister').css({'background-color': '#bf006b', 'color': '#eeeeee'});
          return false;
      }
  }
  private GdprUpdate() {
    if (this.socialFlag === true) {
         $('#loaderPage').css('display', 'block');
      if (this.loginFrom === 'register') {
        if (this.socialType === 'google') {
          this.googleRegister();
        } else {
           this.facebookRegister();
        }
      } else if (this.loginFrom === 'login') {
         this.updateSettingApi(this.sendToken, this.socialType, this.loginFrom);
      }
    }
  }
  private updatePromotionSocial(value, token, method) {
    this.userData = value;
    if (this.userData === undefined || this.userData.length === 0) {
        let userDetails;
        userDetails = new UserApi(this.http, null, this.config);
        userDetails.v1UserGet().timeout(environment.timeOut).subscribe(valueUser => {
        this.userData = valueUser;
        if ( this.settingsResponse.length > 0) {
          for (let i = 0; i < this.settingsResponse.length; i++) {
            if ( this.settingsResponse[i].key === 'first_time_login') {
              if (this.settingsResponse[i].value === '1') {
                 this.localstorage.setItem('login', method);
                 this.localstorage.setItem('token', token);
                this.callReload();
              } else if (this.settingsResponse[i].value === '0') {
                 let disp, valuecountryCode;
                disp = this.localstorage.getItem('display_language');
                valuecountryCode = this.settingsService.getCountryValueNew();
                if (valuecountryCode && valuecountryCode.length > 0) {
                    this.promotional = valuecountryCode[0].promotional;
                    this.countryToken = this.promotional.token;
                    if (this.promotional && this.promotional.on === '1') {
                      this.promotionalAPIcall(token, method);
                    } else if (this.promotional && this.promotional.on === '0') {
                        this.setFirstTimelogin('1');
                    }
                }
              }
            } else if (i === this.settingsResponse.length - 1) {
                   if (this.userData.additional.first_time_login) {
                     if (this.userData.additional.promotional && this.userData.additional.promotional.on === '1') {
                       this.promotionalAPIcall(token, method);
                       } else if (this.userData.additional.promotional && this.userData.additional.promotional.on === '0') {
                         this.setFirstTimeloginSocial('1', token, method);
                       } else {
                         this.setFirstTimeloginSocial('1', token, method);
                       }
                    } else {
                      this.setFirstTimeloginSocial('1', token, method);
                    }
                 }
              }
             }
          });
    } else if (this.userData) {
        if ( this.settingsResponse.length > 0) {
          for (let i = 0; i < this.settingsResponse.length; i++) {
            if ( this.settingsResponse[i].key === 'first_time_login') {
                 this.localstorage.setItem('login', method);
                 this.localstorage.setItem('token', token);
                 this.callReload();
            } else if (i === this.settingsResponse.length - 1) {
                if (this.userData.additional.first_time_login) {
                  if (this.userData.additional.promotional && this.userData.additional.promotional.on === '1') {
                      this.promotionalAPIcall(token, method);
                  } else if (this.userData.additional.promotional && this.userData.additional.promotional.on === '0') {
                    this.setFirstTimeloginSocial('1', token, method);
                  } else {
                    this.setFirstTimeloginSocial('1', token, method);
                  }
                } else {
                    this.setFirstTimeloginSocial('1', token, method);
                }
            }
          }
        } else if (this.userData.additional.first_time_login) {
              if (this.userData.additional.promotional && this.userData.additional.promotional.on === '1') {
                  this.promotionalAPIcall(token, method);
              } else if (this.userData.additional.promotional && this.userData.additional.promotional.on === '0') {
                  this.setFirstTimeloginSocial('1', token, method);
              } else {
                this.setFirstTimeloginSocial('1', token, method);
              }
        } else {
            this.setFirstTimeloginSocial('1', token, method);
          }
    }
  }
  private setFirstTimeloginSocial(first_time_value, token, method) {
    let first_time_settings;
    first_time_settings = {
      key: 'first_time_login',
      value: first_time_value
    };
    this.userSettings.v1SettingsPost(first_time_settings).subscribe(responsePost => {
                this.localstorage.setItem('login', method);
                this.localstorage.setItem('token', token);
                if (this.loginMethod === 'login') {
                  this.callReload();
                } else {
                  let userDetails;
                  userDetails = new UserApi(this.http, null, this.config);
                  userDetails.v1UserGet().timeout(environment.timeOut).subscribe(valueUser => {
                  this.userId = valueUser.id;
                  this.localstorage.setItem('ID', this.userId);
                 });
                  this.confirmationPage(method, token);
                }
    }, err => {
        this.errors = err.json();
      if (this.errors.message === 'Item already exists') {   // for already node there
        this.userSettings.v1SettingsPut(first_time_settings).subscribe(responsePost => {
       this.localstorage.setItem('login', method);
       this.localstorage.setItem('token', token);
       this.callReload();
      }, error => {
       this.localstorage.setItem('login', method);
       this.localstorage.setItem('token', token);
       this.callReload();
      });
      } else {
        this.localstorage.setItem('login', method);
       this.localstorage.setItem('token', token);
       this.callReload();
      }
    });
    this.checkSubSilentLogin();
  }
  private promotionalAPIcall(token, method) {
    let promotionalData, language, tokentype;
      tokentype = this.localstorage.getItem('token');
      if (tokentype) {
        language = localStorage.getItem('UserDisplayLanguage');
      } else {
        language = localStorage.getItem('display_language');
      }
      promotionalData = {
        'createPromo' : { 'token' : this.countryToken },
        'translation' : language
      };
      this.userAction.postPromotionalData(promotionalData, token).subscribe(value => {
        let promoDesc;
        if (value && value.subscription_plan && value.subscription_plan.description) {
          promoDesc = value.json().subscription_plan.description;
        }
        localStorage.setItem('promotionalDesc', promoDesc);
        /*Set settings first-time-login = 1*/
        this.setFirstTimeloginSocial('1', token, method);
         this.localstorage.setItem('dialogCheck', 'true');
       }, err => {
        if (err.status === 404 || err.status === 400) {
          /*Set settings first-time-login = 1*/
          this.setFirstTimeloginSocial('1', token, method);
        } else {
          /*Set settings first-time-login = 0*/
          this.setFirstTimeloginSocial('0', token, method);
        }
      });
  }
  private cookieConcent(settingValue) {
  if (this.cookiesLocal === null || undefined) {
    this.cookiesLocal = 'na';
  }
   if (this.marketingLocal === null || undefined) {
    this.marketingLocal = 'na';
  }
  let popup, popupValue, oldCookie, oldRTRM;
  if ( settingValue.length > 0) {
       for (let i = 0; i < settingValue.length; i++) {
      if ( settingValue[i].key === 'popups') {
        popup = true;
        this.responsevalue = JSON.parse(settingValue[i].value);
         oldCookie = this.responsevalue[0].Cookies;
         oldRTRM = this.responsevalue[0].RTRM;
        if (this.responsevalue[0].Cookies === 'na' && this.responsevalue[0].RTRM === 'na' ) {
            popupValue = [{'Cookies': this.cookiesLocal, 'RTRM': this.marketingLocal}];
           const cookies_settings = {
           'key': 'popups',
           'value': JSON.stringify(popupValue)
           };
           this.userSettings.v1SettingsPut(cookies_settings).subscribe(responseput => {
             // nothing
           });
        } else if (this.responsevalue[0].RTRM === 'na' || this.responsevalue[0].Cookies === 'na') {
          if (this.responsevalue[0].RTRM === 'na') {
             popupValue = [{'Cookies': oldCookie, 'RTRM': this.marketingLocal}];
          }
          if (this.responsevalue[0].Cookies === 'na') {
             popupValue = [{'Cookies': this.cookiesLocal, 'RTRM': oldRTRM}];
          }
           const cookies_settings = {
           'key': 'popups',
           'value': JSON.stringify(popupValue)
           };
           this.userSettings.v1SettingsPut(cookies_settings).subscribe(responseput => {
             // nothing
           });
        }
      }
    }
    if (popup === undefined) {
       let popupValue1;
       popupValue1 = [{'Cookies': this.cookiesLocal, 'RTRM': this.marketingLocal}];
       const cookies_settings = {
       'key': 'popups',
       'value': JSON.stringify(popupValue1)
       };
      this.userSettings.v1SettingsPost(cookies_settings).subscribe(responsePost => {
            // post
      });
    }
  } else {
     let popupValue2;
       popupValue2 = [{'Cookies': this.cookiesLocal, 'RTRM': this.marketingLocal}];
       const cookies_settings = {
       'key': 'popups',
       'value': JSON.stringify(popupValue2)
       };
      this.userSettings.v1SettingsPost(cookies_settings).subscribe(responsePost => {
        // todo
      });
  }
}
private settingsFailsRegister(gdprsettings, type, token, method): any {
  this.userSettings.v1SettingsPost(gdprsettings).subscribe(responsePost => {
     if (type !== 'register') {    // login just reload with update GA and QG
       this.updateGMID(token, method);
     } else {                      // check for promotional
        let disp, valuecountryCode;
          disp = this.localstorage.getItem('display_language');
           valuecountryCode = this.settingsService.getCountryValueNew();
            if (valuecountryCode && valuecountryCode.length > 0) {
               this.promotional = valuecountryCode[0].promotional;
               this.countryToken = this.promotional.token;
                if (this.promotional && this.promotional.on === '1') {
                   this.promotionalAPIcall(token, method);
                } else if (this.promotional && this.promotional.on === '0') {
                   this.setFirstTimeloginSocial('1', token, method);
                }
            }
     }
  }, err => {
     this.SettingapiFails();
  });
}
private simulateUserGesture() {
  $('#loaderPage').focus();
  $('#loaderPage').click();
  // console.log("Simulating spinner click event");
  setTimeout(() => {
    // nothing
  }, 0);
}
////////////////////// login with social network end////////////////
  private close(): any {  /*closing various flags*/
    this.registerEmail = false;
    this.registerMobile = false;
    this.signinDetailsFlag = true;
    this.verification_email = false;
    this.verification_mobile = false;
    this.headerservicesService.addChanges(false);
    this.headerservicesService.modelChange(false);
    if (this.signinHide) {
      this.signinHide.classList.remove('signinCalldisplay');
      this.signinHide.classList.add('signinCall');
    }
    this.headerservicesService.signinChange(false);
    this.document.getElementById('body').classList.remove('modal-open');
    $('#body').removeClass('scrolldisbale');
    this.to.replaceState(this.routeservice.previousRoute()); // previous route
  }
  private togglemail() {
    let network;
    network = this.networkService.getPopupStatus();
    this.seoservice.constructHrefLang({id: 1, url: '/register/email'});
          this.linkservice.addTag({ rel: 'canonical', href: window.location.origin + '/' + this.routeservice.getBaseLocation() + 'register/email'} );
    if (network === true) {
      if (this.registerMobile) {
        this.to.replaceState('register/email');
        this.registerEmail = true;
        this.registerMobile = false;
        this.passwordCheck1 = false;
        this.place1 = false;
        this.icon = true;
        this.emailCheck = false;
        this.emailplace = false;
        this.email_return = false;
        this.password_return = false;
        this.email_return_keypress = false;
        this.password_return_keypress = false;
        this.type = false;
        $('#body').addClass('scrolldisbale');
        this.pageName = 'register/email';
        this.gtm.sendPageName(this.pageName);
        this.gtm.sendEvent();
      } else {
        this.toggleMobile();
      }
    }
  }
  private toggleMobile() {
    let network;
    network  = this.networkService.getPopupStatus();
    this.seoservice.constructHrefLang({id: 1, url: '/register/mobile'});
          this.linkservice.addTag({ rel: 'canonical', href: window.location.origin + '/' + this.routeservice.getBaseLocation() + 'register/mobile'} );

    if (network === true) {
      this.to.replaceState('register/mobile');
      this.registerEmail = false;
      this.registerMobile = true;
      this.passwordCheck = false;
      this.place = false;
      this.icon = false;
      this.email_return = false;
      this.password_return = false;
      this.mobile_return = false;
      this.password_return_keypress = false;
      this.mobile_return_keypress = false;
      this.type = false;
      $('#body').addClass('scrolldisbale');
      this.pageName = 'register/mobile';
      this.gtm.sendPageName(this.pageName);
      this.gtm.sendEvent();
    }
  }
  private MobileRestrictNumbers(e) {
        // Allow: backspace, delete, tab, escape, enter.
   if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
       // Allow: Ctrl+A, Command+A
      (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
            // Allow: Ctrl+V, Command+V
      (e.keyCode === 86 && (e.ctrlKey === true || e.metaKey === true)) ||
             // Allow: home, end, left, right, down, up
      (e.keyCode >= 35 && e.keyCode <= 40)) {
                 // let it happen, don't do anything
        return;
      }
      // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
        $('#mobileNumber').on('paste', function  (event) {
          setTimeout(function () {
                $('#mobileNumber').val($('#mobileNumber').val().replace(/[^0-9]/g, ''));
            }, 1);
       });
  }
  private otpRestrict(e) {  // Allow: backspace, delete, tab, escape, enter.
    if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
    // Allow: Ctrl+A, Command+A
      (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
              // Allow: Ctrl+V, Command+V
      (e.keyCode === 86 && (e.ctrlKey === true || e.metaKey === true)) ||
               // Allow: home, end, left, right, down, up
      (e.keyCode >= 35 && e.keyCode <= 40)) {
        // let it happen, don't do anything
        return;
      }
      // Ensure that it is a number and stop the keypress
      if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
              e.preventDefault();
      }
  }
  private typechange() {  // visible r hide eye icon
    this.type = !this.type;
  }
  private showPassword() {  // mobile passward placeholder
    if (this.navigator.userAgent.match(/SM-T531/) && ( this.window.orientation === 0 ||  this.window.orientation === 180)) {
      $('.registerMobileContainer').css({'top': '-120px'});
    }
    $('.InvalidPassword').css({'display': 'none'});
    $('.passwordForm').css({'border-color': '#6e6e6e'});
    $('.miniCharcter').css({'color': '#6e6e6e'});
    this.passwordCheck = true;
    this.place = true;
  }
  private showPassword1() {  // email passward placeholder
    if (this.navigator.userAgent.match(/SM-T531/) && ( this.window.orientation === 0 ||  this.window.orientation === 180)) {
      $('.ResigterEmailContainer').css({'top': '-120px'});
    }
    $('.InvalidPassword').css({'display': 'none'});
    $('.passwordForm').css({'border-color': '#6e6e6e'});
    $('.miniCharcter').css({'color': '#6e6e6e'});
    $('.miniCharcterEmail').css({'color': '#6e6e6e'});
    this.passwordCheck1 = true;
    this.place1 = true;
  }
  private showEmail() { // email placeholder
    if (this.navigator.userAgent.match(/SM-T531/) && ( this.window.orientation === 0 ||  this.window.orientation === 180)) {
      $('.ResigterEmailContainer').css({'top': '-120px'});
    }
    $('.InvalidEmail').css({'display': 'none'});
    $('.emailEnter').css({'border-color': '#6e6e6e'});
    this.emailCheck = true;
    this.emailplace = true;
  }

  private verifyEmail() {
    if (this.localstorage.getItem('deviceAuthenticateCode')) {
      let currentState;
      currentState = 2;
      this.userAction.checkForDeviceAuthCode(currentState);
    }
    let network;
    network = this.networkService.getPopupStatus();
    if (network === true) {
      this.qgraphevent('signup_initiated', {'method': 'email', 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
      $('#body').addClass('scrolldisbale');
      let policyValues, country_code, country_Promotion;
      policyValues = [];
      for (let i = 0; i < 4; i++) {
        if (!(this.receivedValue.sendValues[i].status) || this.receivedValue.sendValues[i].status === undefined) {
         policyValues[i] = 'na';
        } else if (!(this.receivedValue.sendValues[i].userValue)) {
         policyValues[i] = 'no';
        } else if (this.receivedValue.sendValues[i].userValue === true) {
         policyValues[i] = 'yes';
        }
      }
      country_code = this.settingsService.getCountry();
      country_Promotion = this.settingsService.getCountryPromotionalValue();
      let postdata;
      postdata = {
        'email':  $('.emailInput').val(),
        'password': $('.passwordInput').val(),
        'first_name': '',
        'last_name': '',
        'mac_address': '',
        'additional': {
          'gdpr_policy': [{
           'country_code': country_code,
            'gdpr_fields': {
              'policy': policyValues[0],
              'profiling': policyValues[1],
              'age': policyValues[2],
              'subscription': policyValues[3]
            }
          }],
          'guest_token': this.guest_token,
          'sourceapp' : 'Web',
          'version_number' : this.version_number,
          'promotional': {
            'on': country_Promotion.on,
            'token': country_Promotion.token
          },
          'first_time_login': '1'
        }
      };
      let recAdd;
      recAdd = this.gtm.checkUpdateCampaign(postdata);
      let user_data;
      user_data = {
        'email':  $('.emailInput').val(),
        'password': $('.passwordInput').val()
      };
      let user_email;
      user_email = $('.emailInput').val();
      this.password_return_keypress = false;
      this.password_return = false;
      this.email_return = false;
      this.email_return_keypress = false;
      this.userapiService.setEmailid(user_data);
      $('#loaderPage').css('display', 'block');
      this.userapi.v1UserRegisteremailPost(recAdd).timeout(environment.timeOut).subscribe(response => {
        if (this.window.qg) {
          this.qgraphevent('signup_success', {'method': 'email', 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
          if (this.qgraph !== true) {
            qg('event', 'user_verification_status', {'verified': 'false',  'email': user_email, 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
          }
        }
        this.verification_email = true;
        this.registerEmail = false;
        this.registerPageFlag = false;
        this.emailContainerFlag = false;
        this.password_return_keypress = true;
        this.password_return = true;
        this.email_return = true;
        this.email_return_keypress = true;
        this.login_type = 'email';
        $('#loaderPage').css('display', 'none');
        this.GAUpdateCommon('ProfileVerification', 'Email');
        this.pageName = 'verification mail';
        this.gtm.sendPageName(this.pageName);
        this.gtm.sendEvent();
      }, err => {
        $('#loaderPage').css('display', 'none');
        this.qgraphevent('signup_failure', {'method': 'email', 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
        this.GAUpdateCommon('RegisterFailed', 'email');
        this.password_return_keypress = true;
        this.password_return = true;
        this.email_return = true;
        this.email_return_keypress = true;
        if (err.name === 'TimeoutError') {
            this.error_message = this.try_later;
            this.callToast();
        } else {
          this.errors = err.json();
          if (err.status === 400) {
            this.error_message = this.errors.message;
            this.callToast();
          }
        }
        this.gtm.sendErrorEvent('api', err);
      });
    }
  }
  private callToast() {
    let p;
    p = this.document.getElementById('snackbar');
    p.className = 'show';
    setTimeout(function() { p.className = p.className.replace('show', ''); }, 5000);
  }
  private verifyMobile() {
    if (this.localstorage.getItem('deviceAuthenticateCode')) {
      let currentState;
      currentState = 2;
      this.userAction.checkForDeviceAuthCode(currentState);
    }
    let network;
    network = this.networkService.getPopupStatus();
      if (network === true) {
        this.qgraphevent('signup_initiated', {'method': 'phone', 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
        $('#body').addClass('scrolldisbale');
        this.phone_code = this.phone_code.replace(/-/g, '');
         let policyValues, country_code, country_Promotion;
         policyValues = [];
          for (let i = 0; i < 4; i++) {
            if (!(this.receivedValue.sendValues[i].status) || this.receivedValue.sendValues[i].status === undefined) {
             policyValues[i] = 'na';
            } else if (!(this.receivedValue.sendValues[i].userValue)) {
             policyValues[i] = 'no';
            } else if (this.receivedValue.sendValues[i].userValue === true) {
             policyValues[i] = 'yes';
            }
          }
        country_code = this.settingsService.getCountry();
        country_Promotion = this.settingsService.getCountryPromotionalValue();
        let postdataMobile;
        postdataMobile = {
          'mobile': this.country_code ?  this.phone_code + $('.telNumber').val() : $('.telNumber').val(),
          'password': $('#mypassword').val(),
          'first_name': '',
          'last_name': '',
          'mac_address': '',
          'additional': {
            'gdpr_policy': [{
             'country_code': country_code,
              'gdpr_fields': {
                'policy': policyValues[0],
                'profiling': policyValues[1],
                'age': policyValues[2],
                'subscription': policyValues[3]
              }
            }],
            'guest_token': this.guest_token,
            'sourceapp' : 'Web',
            'version_number' : this.version_number,
            'promotional': {
              'on': country_Promotion.on,
              'token': country_Promotion.token
            },
            'first_time_login': '1'
          }
        };
      let recAdd;
      recAdd = this.gtm.checkUpdateCampaign(postdataMobile);
      let user_data;
      user_data = {
        'mobile': this.country_code ?  this.phone_code + $('.telNumber').val() : $('.telNumber').val(),
        'password': $('#mypassword').val()
      };
      let user_mobile;
      user_mobile = this.country_code ?  this.phone_code + $('.telNumber').val() : $('.telNumber').val();
      this.password_return_keypress = false;
      this.password_return = false;
      this.mobile_return = false;
      this.mobile_return_keypress = false;
      this.userapiService.setEmailid(user_data);
      $('#loaderPage').css('display', 'block');
      this.userapi.v2UserRegistermobilePost(recAdd).timeout(environment.timeOut).subscribe(response => {
        if (this.window.qg) {
          this.qgraphevent('signup_success', {'method': 'phone', 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
          if (this.qgraph !== true) {
            qg('event', 'user_verification_status', {'verified': 'false', 'mobile': user_mobile, 'country' : this.country_code, 'state': localStorage.getItem('state_code')});
          }
        }
        this.login_type = 'mobile';
        this.verification_mobile = true;
        this.registerMobile = false;
        this.registerEmail = false;
        this.registerPageFlag = false;
        this.emailContainerFlag = false;
        this.setTimer();
        this.SecondTimer();
        this.password_return_keypress = true;
        this.password_return = true;
        this.mobile_return = true;
        this.mobile_return_keypress = true;
        $('#loaderPage').css('display', 'none');
        this.GAUpdateCommon('ProfileVerification', 'Mobile');
        this.pageName = 'otp sent';
        this.gtm.sendPageName(this.pageName);
        this.gtm.sendEvent();
      }, err => {
          $('#loaderPage').css('display', 'none');
          this.qgraphevent('signup_failure', {'method': 'phone', 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
          this.GAUpdateCommon('RegisterFailed', 'mobile');
          this.password_return_keypress = true;
          this.password_return = true;
          this.mobile_return = true;
          this.mobile_return_keypress = true;
          if (err.name === 'TimeoutError') {
            this.error_message = this.try_later;
            this.callToast();
          } else {
            this.errors = err.json();
            if (err.status === 400) {
              this.error_message = this.errors.message;
              this.callToast();
            }
          }
          this.gtm.sendErrorEvent('api', err);
      });
    }
  }
  private setTimer() {
    let that;
    that = this;
    $('.countdown').text('20:00');
    that.timer2 = '20:00';
    that.interval = setInterval(function() {
      that.countdown_time = '';
      let timer, seconds, minutes;
      timer = that.timer2.split(':');
      minutes = parseInt(timer[0], 10);
      seconds = parseInt(timer[1], 10);
      --seconds;
      minutes = (seconds < 0) ? --minutes : minutes;
      if (minutes < 0) {
        minutes  = 0;
        seconds = 0;
        clearInterval(that.interval);
      }
      seconds = (seconds < 0) ? 59 : seconds;
      seconds = (seconds < 10) ? '0' + seconds : seconds;
      minutes = (minutes < 10) ? '0' + minutes : minutes;
      $('.countdown').text(minutes + ':' + seconds);
      that.timer2 = minutes + ':' + seconds;
    }, 1000);
  }
  private SecondTimer() {
    let that;
    that = this;
    $('.countdown_second').text('00:30');
    that.timer_second = '00:30';
    that.second_interval = setInterval(function() {
      that.countdown_time2 = '';
      let timer , seconds, minutes;
      timer = that.timer_second.split(':');     // by parsing integer, I avoid all extra string processing
      minutes = parseInt(timer[0], 10);
      seconds = parseInt(timer[1], 10);
      --seconds;
      minutes = (seconds < 0) ? --minutes : minutes;
      if (minutes < 0) {
        minutes  = 0;
        seconds = 0;
        that.timer_return = false;
        that.timer_return_keypress = false;
        clearInterval(that.second_interval);
        $('.resendOtpText').css({'color': '#bf006b', 'cursor': 'pointer'});
      }
      seconds = (seconds < 0) ? 59 : seconds;
      seconds = (seconds < 10) ?  '0' + seconds : seconds;
      minutes = (minutes < 10) ?  '0' + minutes : minutes;
      $('.countdown_second').text(minutes + ':' + seconds);
      that.timer_second = minutes + ':' + seconds;
    }, 1000);
  }
  private resendOtpcheck() {
    if (this.timer_return === false) {
        this.resendOtp();
        this.timer_return = true;
    }
  }
  private resendOtp() {
    $('.resendOtpText').css({'color': '#703055', 'cursor': 'not-allowed'});
    let network;
    network = this.networkService.getPopupStatus();
    if (network === true) {
      this.user_data = this.userapiService.getEmailid();
      clearInterval(this.interval);
      clearInterval(this.second_interval);
      let resendmobile;
      resendmobile = this.user_data.mobile;
      this.userapi.v2UserResendconfirmationmobilePost(resendmobile).timeout(environment.timeOut).subscribe(res => {
        this.setTimer();
        this.SecondTimer();
        this.otpCheck = false;
        this.otpPlace = false;
        $('.otpInput').val('');
        this.otp_return = false;
        this.otp_return_keypress = false;
        this.timer_return_keypress = true;
        this.error_message = res.message;
        this.callToast();
         $('.Invalidotp').css({'display': 'none'});
         $('.otpContainer').css({'border-color': '#6e6e6e'});
         this.timer_return = true;
       }, err => {
         if (err.name === 'TimeoutError') {
            this.error_message = this.try_later;
            this.callToast();
          } else {
          this.error_message = err.message;
          this.callToast();
          this.timer_return = true;
         }
       });
    }
  }
  private focusOutFunction() {
    if (this.navigator.userAgent.match(/SM-T531/) && ( this.window.orientation === 0 ||  this.window.orientation === 180)) {
      $('.registerMobileContainer').css({'top': 'auto'});
    }
    let count;
    count = $('#mypassword').val().length;
    if ( count < 1 ) {
      this.passwordCheck = false;
    }
    this.place = false;
  }
  private focusOutFunction1() {
    if (this.navigator.userAgent.match(/SM-T531/) && ( this.window.orientation === 0 ||  this.window.orientation === 180)) {
      $('.ResigterEmailContainer').css({'top': 'auto'});
    }
    let count1;
    count1 = $('#email').val().length;
    if ( count1 < 1 ) {
      this.emailCheck = false;
    }
    this.emailplace = false;
  }
  private focusOutFunction2() {
    if (this.navigator.userAgent.match(/SM-T531/) && ( this.window.orientation === 0 ||  this.window.orientation === 180)) {
      $('.ResigterEmailContainer').css({'top': 'auto'});
    }
    let count2;
    count2 = $('#mypassword1').val().length;
    if ( count2 < 1 ) {
      this.passwordCheck1 = false;
    }
    this.place1 = false;
  }
  private emailValidation(): void {
    let count1;
    count1 = $('#email').val().length;
    if (count1 >= 0) {
      let scope;
      scope = this;
      $(this.document).ready(function() {
        let email_text, re, emailTest;
        email_text = $('#email').val().trim();
        // re = /^([a-zA-Z0-9]+)(([^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;         /* let re = /^([a-zA-Z0-9._+-]+)(@[a-zA-Z0-9-.]+)(.[a-zA-Z]{2,4}){2,}$/;*/
        // re = /^([a-zA-Z0-9._]+)(@(?=.{1,}.[^.]*$)+)([A-Za-z0-9-]+)(.[A-Za-z0-9]+)*(.[A-Za-z]{1,})$/;
        // re = /^([a-zA-Z0-9]+)(([^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            re = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?/; // to validate c.@asd.adf and caps 
        emailTest = re.test(email_text);
        if (email_text.length === 0 ) {
          $('#RegisterEnterMsg').css({'display': 'block'});
          $('#RegisterErrMsg').css({'display': 'none'});
        } else {
          $('#RegisterEnterMsg').css({'display': 'none'});
          $('#RegisterErrMsg').css({'display': 'block'});
        }
        if (emailTest === false) {
            $('.emailEnter').css({'border-color': 'red'});
            scope.email_return = false;
        } else {
          scope.email_return = true;
          $('#RegisterErrMsg').css({'display': 'none'});
        }
        return scope.email_return;
      });
    }
  }
  private emailValidationkeypress() {
    let count1;
    count1 = $('#email').val().length;
    if (count1 >= 0 ) {
      let scope;
      scope = this;
      $(this.document).ready(function() {
          let email_text, emailTest, re;
          email_text = $('#email').val().trim();
          // re = /^([a-zA-Z0-9]+)(([^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;         /* let re = /^([a-zA-Z0-9._+-]+)(@[a-zA-Z0-9-.]+)(.[a-zA-Z]{2,4}){2,}$/;*/
          // re = /^([a-zA-Z0-9._]+)(@(?=.{1,}.[^.]*$)+)([A-Za-z0-9-]+)(.[A-Za-z0-9]+)*(.[A-Za-z]{1,})$/;
            // re = /^([a-zA-Z0-9]+)(([^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            re = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?/; // to validate c.@asd.adf and caps 
          emailTest = re.test(email_text);
          if (emailTest === false) {
            scope.email_return_keypress = false;
          } else {
            scope.email_return_keypress = true;
          }
            return scope.email_return_keypress;
        });
    }
  }
  private pwdValidationEmail(): any {
    let count1;
    count1 = $('#mypassword1').val().length;
    if (count1 >= 0) {
      let scope;
      scope = this;
      $(this.document).ready(function() {
        let pw_text;
        pw_text = $('#mypassword1').val();
        if (pw_text.length < 6) {
          $('.InvalidPassword').css({'display': 'none'});
          $('.passwordForm').css({'border-color': 'red'});
          $('.miniCharcterEmail').css({'color': 'red'});
          scope.password_return = false;
         } else {
           scope.password_return = true;
         }
         return scope.password_return;
      });
    }
  }
  private pwdValidationKeypress(): any {
     let count1;
     count1 = $('#mypassword1').val().length;
    if (count1 >= 0 ) {
      let scope;
      scope = this;
      $(this.document).ready(function() {
        let pw_text;
        pw_text = $('#mypassword1').val();
         if (pw_text.length < 6) {
           scope.password_return_keypress = false;
         } else {
            scope.password_return_keypress = true;
         }
        return scope.password_return_keypress;
      });
    }
  }
  private pwdValidationMobile(): any {
    let count1;
    count1 = $('#mypassword').val().length;
    if (count1 >= 0 ) {
      let scope;
      scope = this;
      $(this.document).ready(function() {
        let pw_text;
        pw_text = $('#mypassword').val();
         if (pw_text.length < 6) {
          $('.InvalidPassword').css({'display': 'none'});
          $('.passwordForm').css({'border-color': 'red'});
          $('.miniCharcter').css({'color': 'red'});
          scope.password_return = false;
         } else {
          scope.password_return = true;
         }
         return scope.password_return;
      });
    }
  }
  private pwdValidationMobileKeypress(): any {
     let count1;
     count1 = $('#mypassword').val().length;
    if (count1 >= 0 ) {
      let scope;
      scope = this;
      $(this.document).ready(function() {
        let pw_text;
        pw_text = $('#mypassword').val();
         if (pw_text.length < 6) {
           scope.password_return_keypress = false;
         } else {
            scope.password_return_keypress = true;
         }
         return scope.password_return_keypress;
      });
    }
  }
  private mobileEnter() {
    if (this.navigator.userAgent.match(/SM-T531/) && ( this.window.orientation === 0 ||  this.window.orientation === 180)) {
      $('.registerMobileContainer').css({'top': '-120px'});
    }
    $('.mobileContainerForm').css({'border-color': '#6e6e6e'});
    $('.InvalidMobile').css({'display': 'none'});
  }
  private mobileValidation() {
    if (this.navigator.userAgent.match(/SM-T531/) && ( this.window.orientation === 0 ||  this.window.orientation === 180)) {
        $('.registerMobileContainer').css({'top': 'auto'});
    }
    let minMobileLength = 10, maxMobileLength = 10;
    if (this.selected_country.code === 'IN') {
      if (this.country_code) {
        this.regex = /^\d{10}$/;
        minMobileLength = 10;
        maxMobileLength = 10;
      } else {
        this.regex = /^\d{12}$/;
        minMobileLength = 12;
        maxMobileLength = 12;
        this.country_codeLength = 12;
       }
    } else {
      if (this.country_code) {
        this.regex = /^\d{4,20}$/;
        minMobileLength = 4;
        maxMobileLength = 20;
      }
        this.regex = /^\d{4,20}$/;
        minMobileLength = 4;
        maxMobileLength = 20;
    }
    let count1;
    count1 = $('#mobileNumber').val().length;
    if (count1 >= 0 ) {
      let scope;
      scope = this;
      $(this.document).ready(function() {
        let mobile_number;
        mobile_number = $('#mobileNumber').val();
        if (mobile_number.length === 0) {
          $('#RegisterMobileEnterMsg').css({'display': 'block'});
          $('#RegisterMobileErrorMsg').css({'display': 'none'});
        } else {
            if (mobile_number[0] === '0' || (mobile_number.length < minMobileLength)) {
              $('#RegisterMobileEnterMsg').css({'display': 'none'});
              $('#RegisterMobileErrorMsg').css({'display': 'block'});
              $('.mobileContainerForm').css({'border-color': 'red'});
            }
        }
       if ((mobile_number.length < minMobileLength)) {
          $('.mobileContainerForm').css({'border-color': 'red'});
          scope.mobile_return = false;
       } else {
         // todo

       }
      });
    } else {
      this.mobile_return = true;
      $('.mobileContainerForm').css({'border-color': '#6e6e6e'});
      $('#RegisterMobileErrorMsg').css({'display': 'none'});
    }
    return this.mobile_return;
  }
  private mobileValidationkeypress() {
    let minMobileLength = 10;
    let maxMobileLength = 10;
    if (this.selected_country.code === 'IN') {
      if (this.country_code) {
        this.regex = /^\d{10}$/;
        minMobileLength = 10;
        maxMobileLength = 10;
      } else {
        this.regex = /^\d{12}$/;
        minMobileLength = 12;
        maxMobileLength = 12;
        this.country_codeLength = 12;
       }
    } else {
      if (this.country_code) {
        this.regex = /^\d{4,20}$/;
        minMobileLength = 4;
        maxMobileLength = 20;
      }
      this.regex = /^\d{4,20}$/;
      minMobileLength = 4;
      maxMobileLength = 20;
    }
    let count1;
    count1 = $('#mobileNumber').val().length;
    if (count1 >= 0) {
      let scope;
      scope = this;
      $(this.document).ready(function() {
       let mobile_number;
       mobile_number = $('#mobileNumber').val();
       if ((mobile_number.length < minMobileLength)) {
          scope.mobile_return_keypress = false;
       } else {
          if ($('#mobileNumber').val().match(this.regex)) {
           scope.mobile_return_keypress = true;
          } else {
            scope.mobile_return_keypress = false;
          }
       }
      });
    } else {
      this.mobile_return_keypress = true;
    }
    return this.mobile_return_keypress;
  }
  private toggleProfile() {  // email on click of continue slient login
    let network;
    network = this.networkService.getPopupStatus();
    if (network === true) {
      $('#loaderPage').css('display', 'block');
      this.user_data = this.userapiService.getEmailid();
      this.entered_email = this.user_data.email;
      this.entered_password = this.user_data.password;
      this.userapi.v1UserLoginemailGetWithHttpInfo(this.entered_email, this.entered_password).subscribe(response => {
        this.qgraphevent('Signin_Success', {'method': 'email', 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
        this.responseEmail = response.json();
        this.token = this.responseEmail.token;
        this.setgdprsettings(this.entered_email, 'Email');
      }, err => {
        this.qgraphevent('signin_failure', {'method': 'email', 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
        $('#loaderPage').css('display', 'none');
        this.errors = err.json();
        if (err.status === 401) {
          this.error_message = this.errors.message;
          if (this.error_message === 'The email address of the user is not confirmed.' ) {
            this.headerservicesService.ButtonChange(true);
            this.buttonChange = true;
            this.setDisplay(this.token);
            this.profileActivationFlag = true;
            this.verification_email = false;
            this.registerMobile = false;
            this.registerEmail = false;
            $('#body').addClass('scrolldisbale');
            clearInterval(this.interval);
            clearInterval(this.second_interval);
            this.registerTop = false;
            this.bg_imageFlag = false;
            this.verification_mobile = false;
            this.pass();
          }
         this.callToast();
        }
        this.gtm.sendErrorEvent('api', err);
      });
    }
  }
  private setgdprsettings(userData, userLoginType) {
    if (this.token) {
      this.CommonConfigCall(this.token);
      this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
        this.userSettings.v1SettingsGet().subscribe( response => {
          this.settingsResponse = response;
          this.cookieConcent(this.settingsResponse);
          let gdpr_Flag , firstTimeLoginNode;
          if ( response.length > 0) {
            for (let i = 0; i < response.length; i++) {
              if ( response[i].key === 'gdpr_policy') {
                gdpr_Flag = true;
              }
              if ( response[i].key === 'first_time_login') {
                  firstTimeLoginNode = true;
              }
            }
            if (gdpr_Flag === undefined) {
              this.getUserDetails();
            }
            if (firstTimeLoginNode === undefined) {
              setTimeout(() => {
                if (this.window.qg) {
                  if (this.qgraph !== true) {
                    if (userLoginType === 'Mobile') {
                    qg('event', 'user_verification_status', {'verified': 'true', 'mobile': userData, 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
                    } else if (userLoginType === 'Email') {
                    qg('event', 'user_verification_status', {'verified': 'true', 'email': userData, 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
                    }
                  }
                }
              },  3000);
            }
          } else {
            if (gdpr_Flag === undefined) {
              this.getUserDetails();
            }
          }
        });
    }
  }
  private pass(): any {
    this.profileShow = {profile: this.profileActivationFlag};
    this.update.emit(this.profileShow);
    this.headerservicesService.signinLeftChange(false);
    this.headerservicesService.ProfileActivationChange(true);
  }
  private getUserDetails() {
    let login_type_caps;
    if (this.login_type === 'mobile') {
      login_type_caps = 'Mobile';
    } else if (this.login_type === 'email') {
      login_type_caps = 'Email';
    }
    let userDetails;
    userDetails = new userApi.UserApi(this.http, null, this.config);
    userDetails.v1UserGet().timeout(environment.timeOut).subscribe(value => {
      this.userId = value.id;
      this.localstorage.setItem('ID', this.userId);
      if (value.additional.first_time_login) {
        if (value.additional.promotional && value.additional.promotional.on === '1') {
          let promotionalData;
          promotionalData = {
            'createPromo' : { 'token' : '' },
            'translation' :  localStorage.getItem('display_language')
          };
          this.userAction.postPromotionalData(promotionalData, this.token).subscribe(valuePromo => {
            let promoDesc;
            if (valuePromo && valuePromo.subscription_plan && valuePromo.subscription_plan.description) {
              promoDesc = valuePromo.json().subscription_plan.description;
            }
            localStorage.setItem('promotionalDesc', promoDesc);
            /*Set settings first-time-login = 1*/
            this.setFirstTimelogin('1');
            localStorage.setItem('dialogCheck', 'true');
          }, err => {
              if (err.status === 404 || err.status === 400) {
                this.setFirstTimelogin('1');
                /*Set settings first-time-login = 0*/
              } else {
                this.setFirstTimelogin('0');
              }
            });
        } else {
          this.setFirstTimelogin('1');
        }
        let gdprValue;
        if (value.additional.gdpr_policy) {
          for (let j = 0; j < value.additional.gdpr_policy.length; j++) {
            if (this.countrycode === value.additional.gdpr_policy[j].country_code) {
                gdprValue = [{'country_code': this.countrycode,
                            'gdpr_fields': {
                              'policy': value.additional.gdpr_policy[j].gdpr_fields.policy,
                              'profiling': value.additional.gdpr_policy[j].gdpr_fields.profiling,
                              'age': value.additional.gdpr_policy[j].gdpr_fields.age,
                              'subscription': value.additional.gdpr_policy[j].gdpr_fields.subscription
                            }}];
            }
          }
          if ( this.localstorage.getItem('ContentLang').length === 0) {
            this.localstorage.setItem('ContentLang', 'en,hi');
          }
          this.default_settings = [
            {key: 'display_language', value: this.localstorage.getItem('display_language') },
            {key: 'content_language', value: this.localstorage.getItem('ContentLang') },
            {key: 'streaming_quality', value: 'Auto' },
            {key: 'auto_play', value: 'true' },
            {key: 'download_quality', value: '0' },
            {key: 'recent_search', value: '' },
            {key: 'stream_over_wifi', value: 'false' },
            {key: 'download_over_wifi', value: 'false' },
            {key: 'gdpr_policy', value: JSON.stringify(gdprValue)}];
          for (let i = 0; i < 9 ; i++) {
            const defaultsettings = {
              'key': this.default_settings[i].key,
              'value': this.default_settings[i].value
            };
            let k;
            k = i;
            this.userSettings.v1SettingsPost(defaultsettings).subscribe(responsePost => {
              if ( k === (this.default_settings.length - 1)) {
                this.localstorage.setItem('login', login_type_caps);
                this.localstorage.setItem('googletag', 'false');
                this.headerservicesService.ButtonChange(false);
                this.buttonChange = false;
                this.setLocalStorage();
                this.setDisplay(this.token);
                this.profileActivationFlag = true;
                this.verification_email = false;
                this.registerMobile = false;
                this.registerEmail = false;
                $('#body').addClass('scrolldisbale');
                clearInterval(this.interval);
                clearInterval(this.second_interval);
                this.registerTop = false;
                this.bg_imageFlag = false;
                this.verification_mobile = false;
                this.pass();
                $('#loaderPage').css('display', 'none');
                this.GAUpdateCommon('LoginSuccess', this.login_type);
              }
            }, err => {
                  this.error_message = this.try_later;
                  this.callToast();
              });
          }
        }
      }
    }, err => {
        if (err.name === 'TimeoutError') {
          this.error_message = this.try_later;
          this.callToast();
        } else {
        this.errors = err.json();
        this.error_message = this.errors.message;
        this.callToast();
        }
        this.gtm.sendErrorEvent('api', err);
      });
  }
  private setFirstTimelogin(first_time_value) {
    let first_time_settings;
    first_time_settings = {
      key: 'first_time_login',
      value: first_time_value
    };
    this.userSettings.v1SettingsPost(first_time_settings).subscribe(responsePost => {
      // todo
    });
    this.checkSubSilentLogin();

  }
  private setDisplay(n): void {
    this.userapiService.gettoken(n);
  }
  private setLocalStorage() {
    let token;
    token = this.localstorage.getItem('token');
    if (token === null) {
      this.localstorage.setItem('token', this.token);
    }
  }
  private toggleProfileMobile() {  // opt page continue button silient login
    let network;
    network = this.networkService.getPopupStatus();
    if (network === true) {
      let code;
      code = $('.otpInput').val();
      $('#loaderPage').css('display', 'block');
      this.userapi.v1UserConfirmmobilePut(code).subscribe(res => {
        this.error_message = res.message;
        this.callToast();
        this.confirmed_mobile = true;
        clearInterval(this.interval);
        clearInterval(this.second_interval);
        if (this.confirmed_mobile === true) {
          this.user_data = this.userapiService.getEmailid();
          let x;
          x = this.user_data.mobile;
          let y;
          y = this.user_data.password;
          this.userapi.v1UserLoginmobileGetWithHttpInfo(x, y).timeout(environment.timeOut).subscribe(response => {
            this.qgraphevent('Signin_Success', {'method': 'phone', 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
            this.responseMobile = response.json();
            this.token = this.responseMobile.token;
            if (this.responseMobile.token === undefined ) {
              this.headerservicesService.ButtonChange(true);
              this.buttonChange = true;
            } else {
              this.headerservicesService.ButtonChange(false);
              this.buttonChange = false;
              this.setLocalStorage();
              this.localstorage.setItem('login', 'Mobile');
              $('#loaderPage').css('display', 'none');
             }
            this.setgdprsettings(this.user_data.mobile, 'Mobile');
            this.GAUpdateCommon('RegisterSuccess', 'mobile');
              this.pageName = 'register/Success';
              this.gtm.sendPageName(this.pageName);
              this.gtm.sendEvent();
          }, err => {
            this.qgraphevent('signin_failure', {'method': 'phone', 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
            $('#loaderPage').css('display', 'none');
            if (err.name === 'TimeoutError') {
              this.error_message = this.try_later;
              this.callToast();
            } else if (err.status === 401) {
              this.errors = err.json();
              this.error_message = this.errors.message;
              this.callToast();
            }
            this.gtm.sendErrorEvent('api', err);
          });
        }
      }, err => {
          $('#loaderPage').css('display', 'none');
          this.errors = err.json();
          if (err.status === 404 || 400) {
            this.error_message = this.errors.message;
            this.callToast();
          }
        this.gtm.sendErrorEvent('api', err);
      });
    }
  }
  private changeTimer() {
    this.timer_true_change =  {t1: this.timer_true};
    this.update.emit(this.timer_true_change);
  }
  private checkLength() {  // unable r disble accept button
    if (!(this.email_return && this.password_return && this.receivedValue.sendFlag && this.receivedValue.sendCount)) {
      $('.registerSubmit').css({'background-color': '#50012f', 'color': '#703055'});
      return true;
    } else {
      $('.registerSubmit').css({'background-color': '#bf006b', 'color': '#eeeeee'});
      return false;
    }
  }
  private checkLengthOnkeypress() {
    if (!(this.email_return_keypress && this.password_return_keypress && this.receivedValue.sendFlag && this.receivedValue.sendCount)) {
        $('.registerSubmit').css({'background-color': '#50012f', 'color': '#703055'});
        return true;
      } else {
         $('.registerSubmit').css({'background-color': '#bf006b', 'color': '#eeeeee'});
        return false;
    }
  }
  private checkLengthMobilekeypress() {
      let count1, count2;
      count1 = $('#mobileNumber').val().length;
      count2 = $('#mypassword').val().length;
      if (!(this.mobile_return_keypress && this.password_return_keypress && this.receivedValue.sendFlag && this.receivedValue.sendCount)) {
        $('.registerSubmit').css({'background-color': '#50012f', 'color': '#703055'});
        return true;
      } else {
        $('.registerSubmit').css({'background-color': '#bf006b', 'color': '#eeeeee'});
        return false;
      }
  }
  private checkLengthMobile() {
      let count1, count2;
      count1 = $('#mobileNumber').val().length;
      count2 = $('#mypassword').val().length;
     if (!(this.mobile_return && this.password_return && this.receivedValue.sendFlag && this.receivedValue.sendCount)) {
        $('.registerSubmit').css({'background-color': '#50012f', 'color': '#703055'});
        return true;
      } else {
        $('.registerSubmit').css({'background-color': '#bf006b', 'color': '#eeeeee'});
        return false;
     }
  }
  private dropdown() {
   let browser;
   browser = this.videoService.get_browser();
  if (browser.name === 'Firefox') {
    this.fireFoxdropReg = true;
   }
    this.dropDownCheck = !this.dropDownCheck;
    if (this.dropDownCheck) {
        this.currentIndex = this.country_selected_index;
        let index, scope;
        index  = 'countryList' + this.currentIndex;
        scope = this;
        setTimeout(() => {
          document.getElementById(index).focus();
        }, 100);
      }
  }
  private increment() {
    this.previousIndex = this.currentIndex;
    this.currentIndex ++;
    let index;
    index = 'countryList' + this.currentIndex;
    document.getElementById(index).focus();
  }
  private decrement() {
    this.previousIndex = this.currentIndex;
    if ((this.currentIndex - 1) >= 0) {
      this.currentIndex --;
      let index;
      index = 'countryList' + this.currentIndex;
      document.getElementById(index).focus();
    }
  }
  @HostListener('window:keydown', ['$event'])
  public keyEvent(event: KeyboardEvent) {
    if ( (this.dropDownCheck ) && event.keyCode === 40 ) {
      event.preventDefault();
      this.increment();
    }
    if ((this.dropDownCheck ) && event.keyCode === 38 ) {
      event.preventDefault();
      this.decrement();
    }
    if ((this.dropDownCheck ) && event.keyCode === 9 ) {
      this.dropdown();
    }
  }
  private changeValue(event, index) {
    this.dropDownCheck = false;
    this.selected_country = event;
    if (this.country_code) {
     this.country_code = '+' + event['phone-code'] + ' - ';
    }
    this.currentIndex = index;
    this.country_selected_index = index;
    $('#mobileNumber').val('');
    $('.registerSubmit').css({'background-color': '#50012f', 'color': '#703055'});
    $('.mobileContainerForm').css({'border-color': '#6e6e6e'});
    $('.InvalidMobile').css({'display': 'none'});
    this.phone_code = event['phone-code'];
    this.mobile_return = false;
    this.mobile_return_keypress = false;
    if (event['phone-code'].length > 5) {
        $('.code').css({'padding-right': '6px'});
        $('.code').css({'width': 'calc(23.71159%)'});
    } else if (event['phone-code'].length > 3) {
        $('.code').css({'padding-right': '6px'});
        $('.code').css({'width': 'calc(18.71159%)'});
    } else {
        $('.code').css({'padding-right': '0'});
        $('.code').css({'width': 'calc(16.71159%)'});
    }
    if (event.code === 'IN') {
      if (this.country_code) {
       this.country_codeLength = 10;
       this.regex = /^\d{10}$/;
       } else {
        this.country_codeLength = 12;
        this.regex = /^\d{12}$/;
       }
     } else {
      if (this.country_code) {
       this.country_codeLength = 13;
       this.regex = /^\d{4,13}$/;
      } else {
        this.country_codeLength = 20;
       this.regex = /^\d{4,20}$/;
      }
     }
  }
  private showOtp() {
    if (this.navigator.userAgent.match(/SM-T531/) && ( this.window.orientation === 0 ||  this.window.orientation === 180)) {
      $('.verificationContainerMobile').css({'top': '-120px'});
    }
    $('.Invalidotp').css({'display': 'none'});
    $('.otpContainer').css({'border-color': '#6e6e6e'});
    this.otpCheck = true;
    this.otpPlace = true;
  }
  private removeOtp() {
    if (this.navigator.userAgent.match(/SM-T531/) && ( this.window.orientation === 0 ||  this.window.orientation === 180)) {
      $('.verificationContainerMobile').css({'top': 'auto'});
    }
    let count1;
    count1 = $('#otpInput').val().length;
    if ( count1 < 1 ) {
      this.otpCheck = false;
    }
    this.otpPlace = false;
  }
  private otpValidation() {
   let count1;
   count1 = $('#otpInput').val().length;
    if (count1 >= 0) {
      let scope;
      scope = this;
      $(this.document).ready(function() {
        let pw_text;
        pw_text = $('#otpInput').val();
        if (pw_text.length === 0 ) {
          $('#RegisterOtpEnterMsg').css({'display': 'block'});
          $('#RegisterOtpErrorMsg').css({'display': 'none'});
        } else {
          $('#RegisterOtpEnterMsg').css({'display': 'none'});
          $('#RegisterOtpErrorMsg').css({'display': 'block'});
        }
        if (pw_text.length < 4) {
          $('.otpContainer').css({'border-color': 'red'});
          scope.otp_return = false;
        } else {
          scope.otp_return = true;
          $('#RegisterOtpErrorMsg').css({'display': 'none'});
        }
        return scope.otp_return;
      });
    }
  }
  private otpValidationkeypress() {
    let count1;
    count1 = $('#otpInput').val().length;
    if (count1 >= 0) {
      let scope;
      scope = this;
      $(this.document).ready(function() {
        let pw_text;
        pw_text = $('#otpInput').val();
        if (pw_text.length < 4) {
          scope.otp_return_keypress = false;
        } else {
          scope.otp_return_keypress = true;
        }
        return scope.otp_return_keypress;
        });
      }
  }
  private otpEnable() {
    if ((this.otp_return ) === false) {
      $('.continueButton').css({'background-color': '#50012f', 'color': '#703055'});
      return true;
    } else {
      $('.continueButton').css({'background-color': '#bf006b', 'color': '#eeeeee'});
      return false;
    }
  }
  private otpEnableKeypress() {
    if ((this.otp_return_keypress) === false) {
          $('.continueButton').css({'background-color': '#50012f', 'color': '#703055'});
          return true;
        } else {
           $('.continueButton').css({'background-color': '#bf006b', 'color': '#eeeeee'});
          return false;
      }
  }
  private resendEmailLink() {
    let network;
    network = this.networkService.getPopupStatus();
    if (network === true) {
     this.user_data = this.userapiService.getEmailid();
     let resendemail;
     resendemail = this.user_data.email;
      this.userapi.v1UserResendconfirmationemailPost(resendemail).subscribe(res => {
        this.error_message = res.message;
        this.callToast();
      });
   }
  }
  private sendData(value) {
    this.receivedValue = value ;
    setTimeout(function () {
      $('.loaderImage').css('display', 'none');
    }, 500);
  }
  private bridgeEnter(event) {
    if (event.keyCode === 13) {
      $('.registerSubmit').click();
      $('.continueButton').click();
    }
  }
  private CommonConfigCall(token) {
   let params;
        params = 'bearer ' + token ;
       this.config = {
          apiKey: params,
          username: '',
          password: '',
          accessToken: '',
          withCredentials: false
        };
  }
  private GAUpdateCommon(gAevent, loginMethod) {    ///  GA event = LoginSuccess/registerFailure  /// loginMethod = fb,g+,tw,mob,em
  this.tokenValue = this.gtm.fetchToken();
  this.timestampTime = this.gtm.fetchCurrentTime();
  this.timestampDateTime = this.gtm.fetchCurrentDate();
  this.clientID = this.gtm.fetchClientId();
  this.marketingValue = this.gtm.fetchMarketing();
  let sendData;
  sendData = {
        'event' : gAevent,
        'G_ID' : this.tokenValue,
        'Client_ID': this.clientID,
        'retargeting_remarketing' : this.marketingValue,
        'LoginMethod' : loginMethod,
        'operator': 'NA',
        'TimeHHMMSS': this.timestampTime,
        'DateTimeStamp': this.timestampDateTime
      };
  this.gtm.appendPara(gAevent, sendData);
}
  public ngOnDestroy() {
     clearInterval(this.interval);
     clearInterval(this.second_interval);
  }
    private qgraphevent(eventname, object) {
    if (this.window.qg) {
      // if (this.qgraph) {
      //   delete object.country;
      //   delete object.state;
      //   qg('event', eventname, object);
      // } else {
        qg('event', eventname, object);
      // }
    }
  }
  private checkSubSilentLogin(): any {
  let recVal, sendVal;
  recVal = this.localstorage.getItem('subSilentLogin');
  if (recVal) {
    sendVal = {
      'subValue' : true,
      'loginValue' : true
    };
    this.localstorage.setItem('subSilentLogin', JSON.stringify(sendVal));
  }
}
}

