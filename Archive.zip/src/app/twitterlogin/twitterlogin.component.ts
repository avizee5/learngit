import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import * as $ from 'jquery';
import { RouteService } from '../services/route.service';
import * as userApi from '../../data/user/api/api';
import { Http} from '@angular/http';
import {environment} from '../../environments/environment';
import { HeaderservicesService } from '../services/headerservices.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import 'rxjs/add/operator/timeout';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { UserProfileService } from '../services/user-profile.service';
import { UserApiService } from '../services/user-api.service';
import { Router , NavigationEnd , ActivatedRoute  } from '@angular/router';
import { SettingsService } from '../services/settings.service';
import * as SettingsApi from '../../data/user/api/api';
import { UserApi } from '../../data/user/api/api';
import { UseractionapiService } from '../services/useractionapi.service';
import {CommonService} from '../services/common.service';
import { Location } from '@angular/common';

declare const qg;
@Component({
  selector: 'app-twitterlogin',
  templateUrl: './twitterlogin.component.html',
  styleUrls: ['./twitterlogin.component.less']
})
export class TwitterloginComponent implements OnInit, OnDestroy {
private ngUnsubscribe = new Subject<any>();
private code: any;
private forgotcode: any;
private userapi: any;
private twitterToken: any;
private userId: any;
private config: any;
private tokenValue: any;
private localstorage: any;
private window: any;
private document: any;
private navigator: any;
private twitterTime: any;
private params: any = '';
private data: any ;
private previousUrl: any;
private countrycode: any;
public imgaShow = false;
private assetbasepath: any;
private type: any;
private errors: any;
private timestampTime: any;
private timestampDateTime: any;
public errorMessage: any;
public profileFlag: any = false;
public signInLeftFlag: any;
public signinHide: any;
public signInComponentFlag: any;
public signInFlag = false;
private receivedValue: any = undefined;
private loginFrom: any;
private twitterAccessToken: any;
private object: any;
private gdprCountryChange = false;
private userSettings: any;
private gdprValue: any;
private sendToken: any;
private removeClass = false;
private promotional: any;
private countryToken: any;
private userData: any;
private settingsResponse: any;
private loginMethod: any;
private cookiesLocal: any;
private marketingLocal: any;
private responsevalue: any;
private clientID: any;
private marketingValue: any;
private qgraph: any;
public guest_token: any;
private version_number: any;
public internationalGdprFlag = false;
public gdpr = true;
public queryparams: any;
constructor(private router: Router, private to: Location, private userProfileService: UserProfileService, private commonService: CommonService, private userapiService: UserApiService, @Inject(PLATFORM_ID) private platformId: Object, private settingsService: SettingsService, private route: ActivatedRoute, private routeservice: RouteService, private http: Http, private headerservicesService: HeaderservicesService, private gtm: GoogleAnalyticsService, private userAction: UseractionapiService) {
    this.headerservicesService.blockeventsValue.subscribe(value => {
     this.qgraph = this.headerservicesService.getRemarketing();
    });
}

  public ngOnInit() {
     $('#loaderPage').css('display', 'block');
    // $('.auto-loader-twitter').css('display', 'block');
    if (isPlatformBrowser(this.platformId)) {
        this.localstorage = localStorage;
        this.window = window;
        this.document = document;
        this.navigator = navigator;
    }
    this.qgraph = this.headerservicesService.getRemarketing();
    this.cookiesLocal = this.localstorage.getItem('cookies');
    this.marketingLocal = this.localstorage.getItem('marketing');
    this.guest_token = this.localstorage.getItem('guestToken');
    this.version_number = this.navigator.userAgent;  // gdpr additional field version number while post

    this.resizeScreen();
      this.assetbasepath = environment.assetsBasePath;
      this.previousUrl = this.localstorage.getItem('previousRoute');
      this.gtm.storeWindowError();
  	  $('#headerMenu').hide();
  	  $('.appFooter').hide();
      this.countrycode = this.settingsService.getCountry();
      this.userapi = new userApi.UserApi(this.http, null, null);
  	  this.route.queryParams.subscribe(queryparams => {
    	  let twitter;
        twitter = queryparams ['token'];
        let twitterSecret;
        twitterSecret = queryparams [ 'secret' ];
        this.twitterTime = queryparams['version'];
        this.localstorage.setItem('twitterTime', this.twitterTime );
        this.code = queryparams ['code'];
        this.forgotcode = queryparams ['code'];
        this.twitterAccessToken = (twitter + '|' + twitterSecret);
  	   });
       if (this.twitterAccessToken !== undefined) {
          this.twitterLoginApi(this.twitterAccessToken);
        }
     $('#loaderPage').css('display', 'none');
  }
  @HostListener('window:resize', ['$event'])
  public resizeScreen() {
    if (this.window.innerWidth < 801) {
      this.removeClass = true;
    } else {
      this.removeClass = false;
    }
  }
  private twitterLoginApi(twitterAccessToken) {
     $('#loaderPage').css('display', 'none');
    $('.auto-loader-twitter').css('display', 'block');
     this.userapi.v1UserLogintwitterGet(this.twitterAccessToken).timeout(environment.timeOut).subscribe(value => {
    $('.auto-loader-twitter').css('display', 'none');
     $('#loaderPage').css('display', 'none');
     this.twitterToken = value.token;
     this.loginMethod = 'login';
      this.type = this.localstorage.getItem('parental');
      if ( this.type === 'true') {
        $('#loaderPage').css('display', 'block');
        this.parentalRoute(this.twitterToken);
      } else {
         $('#loaderPage').css('display', 'block');
         this.checkGdprNode(this.twitterToken);
      }
     }, err => {
       this.errors = err || err.json();
       this.type = this.localstorage.getItem('parental');
        $('.auto-loader-twitter').css('display', 'none');
        $('#loaderPage').css('display', 'none');
        $('.blank').css('height', 0);
       if ( this.type === 'true') {                   // parental control check
            if (err.status === 404) {
              this.errors =  err.json();
              this.errorMessage = this.errors.message;
              this.ErrorTostMessage(this.errorMessage);
              this.localstorage.removeItem('parental');
            } else if (err.status === 400) {
              this.errorMessage = 'MESSAGES.TRY_LATER';
              this.ErrorTostMessage(this.errorMessage);
              this.localstorage.removeItem('parental');
            } else if (err.status === 0) {
              this.errorMessage = 'MESSAGES.TRY_LATER';
              this.ErrorTostMessage(this.errorMessage);
              this.localstorage.removeItem('parental');
            } else {
              this.errorMessage = 'MESSAGES.TRY_LATER';
              this.ErrorTostMessage(this.errorMessage);
              this.localstorage.removeItem('parental');
            }
        } else {
              this.tokenValue = this.gtm.fetchToken();
              this.clientID = this.gtm.fetchClientId();
              this.marketingValue = this.gtm.fetchMarketing();
                  this.gtm.logEvent({
                    'event' : 'LoginFailed',
                    'LoginMethod' : 'twitter',
                    'G_ID': this.tokenValue,
                    'Client_ID': this.clientID,
                    'retargeting_remarketing' : this.marketingValue,
                  });
              this.gtm.sendErrorEvent('api', err);
              this.qgraphevent('Signin_Failure', {'method': 'social_twitter', 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
            if (err.name === 'TimeoutError') {
              this.errorMessage = 'MESSAGES.TRY_LATER';
              this.ErrorTostMessage(this.errorMessage);
              this.localstorage.removeItem('parental');
              this.localstorage.removeItem('twitterTime');
            } else if (err.status === 400) {
             this.errorMessage = 'MESSAGES.TRY_LATER';
              this.ErrorTostMessage(this.errorMessage);
              this.localstorage.removeItem('parental');
              this.localstorage.removeItem('twitterTime');
            } else if (err.status === 0) {
              this.errorMessage = 'MESSAGES.TRY_LATER';
              this.ErrorTostMessage(this.errorMessage);
              this.localstorage.removeItem('twitterTime');
            } else if (err.status === 404) {  // GDPR screen
              this.errors =  err.json();
              $('#loaderPage').css('display', 'none');
              $('.blank').css('height', 0);
              this.loginFrom = 'register';
              if (this.localstorage.getItem('country_code') !== 'IN') {
              this.internationalGdprFlag = true;
              } else {
                this.signInFlag = true;
                this.headerservicesService.registerMobilechange(false);
                this.headerservicesService.bgImageValueChange(true);
                this.headerservicesService.signinDetailsChange(false);
                this.headerservicesService.signinRightTopChange(true);
                this.headerservicesService.signinLeftChange(true);
              }
            } else {
              this.errorMessage = 'MESSAGES.TRY_LATER';
              this.ErrorTostMessage(this.errorMessage);
              this.localstorage.removeItem('twitterTime');
            }
        }
     });

  }
  private twitterRegisterApi(twitterAccessToken): any {
    $('#loaderPage').css('display', 'block');
    this.createObject(twitterAccessToken);
    if (this.object) {
      this.userapi.v1UserRegistertwitterPost(this.object).timeout(environment.timeOut).subscribe(value => {
          $('#loaderPage').css('display', 'block');
          this.twitterToken = value.token;
           this.loginMethod = 'register';
        setTimeout(() => {
          $('#loaderPage').css('display', 'block');
          $('.blank').css('height', 0);
          this.updateSettingApi(this.twitterToken, 'register');
           this.localstorage.setItem('twitterType', 'register');
          this.localstorage.setItem('login', 'twitter');
         this.localstorage.setItem('token',  this.twitterToken);
         this.qgraphevent('signup_success', {'method': 'social_twitter', 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
        }, 0);
            this.tokenValue = this.gtm.fetchToken();
            this.timestampTime = this.gtm.fetchCurrentTime();
            this.timestampDateTime = this.gtm.fetchCurrentDate();
            this.clientID = this.gtm.fetchClientId();
            this.marketingValue = this.gtm.fetchMarketing();
            this.gtm.logEvent({
                    'event' : 'RegisterSuccess',
                    'LoginMethod' : 'twitter',
                    'G_ID': this.tokenValue,
                    'Client_ID': this.clientID,
                    'retargeting_remarketing' : this.marketingValue,
                    'TimeHHMMSS': this.timestampTime,
                     'DateTimeStamp': this.timestampDateTime
            });
      }, err => {
          this.errors = err || err.json();
          this.localstorage.removeItem('twitterType');
           if (err.name === 'TimeoutError') {
              this.errorMessage = 'MESSAGES.TRY_LATER';
              this.ErrorTostMessage(this.errorMessage);
              this.localstorage.removeItem('twitterTime');
            } else if (err.status === 0 || err.status === 400) {
              this.errorMessage = 'MESSAGES.TRY_LATER';
              this.ErrorTostMessage(this.errorMessage);
              this.localstorage.removeItem('twitterTime');
            } else {
              this.errorMessage = 'MESSAGES.TRY_LATER';
              this.ErrorTostMessage(this.errorMessage);
              this.localstorage.removeItem('twitterTime');
            }
            this.tokenValue = this.gtm.fetchToken();
            this.timestampTime = this.gtm.fetchCurrentTime();
            this.timestampDateTime = this.gtm.fetchCurrentDate();
            this.clientID = this.gtm.fetchClientId();
            this.marketingValue = this.gtm.fetchMarketing();
            this.gtm.logEvent({
              'event' : 'RegisterFailed',
              'LoginMethod' : 'twitter',
              'G_ID': this.tokenValue,
              'Client_ID': this.clientID,
              'retargeting_remarketing' : this.marketingValue,
              'TimeHHMMSS': this.timestampTime,
              'DateTimeStamp': this.timestampDateTime
            });
            this.qgraphevent('signup_failure', {'method': 'social_twitter', 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
            this.gtm.sendErrorEvent('api', err);
          $('#loaderPage').css('display', 'none');
      });
    }
  }
  private createObject(accessToken): any {
  let policyValues, objInt, country_Promotion;
  country_Promotion = this.settingsService.getCountryPromotionalValue();

  policyValues = [];
  for (let i = 0; i < 4; i++) {
      if (!(this.receivedValue.sendValues[i].status) || this.receivedValue.sendValues[i].status === undefined) {
          policyValues[i] = 'na';
      } else if (!(this.receivedValue.sendValues[i].userValue)) {
          policyValues[i] = 'no';
      } else if (this.receivedValue.sendValues[i].userValue === true) {
         policyValues[i] = 'yes';
      }
  }
  objInt = {
     'token' : accessToken,
     'mac_address': '',
     'ip_address': '',
     'registration_country': '',
     'additional': {
        'gdpr_policy': [{
          'country_code': this.countrycode,
          'gdpr_fields': {
            'policy': policyValues[0],
            'profiling': policyValues[1],
            'age': policyValues[2],
            'subscription': policyValues[3]
          }
        }],
           'guest_token': this.guest_token,
           'sourceapp' : 'Web',
           'version_number' : this.version_number,
           'promotional': {
             'on': country_Promotion.on,
             'token': country_Promotion.token
            },
            'first_time_login': '1'
      }
    };
    this.object = this.gtm.checkUpdateCampaign(objInt);
}
private updateSettingApi(token, type): any {
     $('#loaderPage').css('display', 'block');
  if (token) {
        let params;
        params = 'bearer ' + token ;
       this.config = {
          apiKey: params,
          username: '',
          password: '',
          accessToken: '',
          withCredentials: false
        };
  }
  let policyValues;
  policyValues = [];
  for (let i = 0; i < 4; i++) {
      if (!(this.receivedValue.sendValues[i].status) || this.receivedValue.sendValues[i].status === undefined) {
          policyValues[i] = 'na';
      } else if (!(this.receivedValue.sendValues[i].userValue)) {
          policyValues[i] = 'no';
      } else if (this.receivedValue.sendValues[i].userValue === true) {
         policyValues[i] = 'yes';
      }
  }
 if (!this.gdprCountryChange) {  // register
  let gdprValue, gdprsettings;
    gdprValue = [{
            'country_code': this.countrycode,
            'gdpr_fields': {
                'policy': policyValues[0],
                'profiling': policyValues[1],
                'age': policyValues[2],
                'subscription': policyValues[3]
                 }
            }];
  gdprsettings = {
            'key': 'gdpr_policy',
            'value': JSON.stringify(gdprValue)
         };
  this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
  this.userSettings.v1SettingsPost(gdprsettings).subscribe(responsePost => {
     if (type !== 'register') {
       this.updateGMID(token, 'twitter');
     } else {
          let disp, valuecountryCode;
          disp = this.localstorage.getItem('display_language');
               valuecountryCode = this.settingsService.getCountryValueNew();
                 if (valuecountryCode && valuecountryCode.length > 0) {
                  this.promotional = valuecountryCode[0].promotional;
                  this.countryToken = this.promotional.token;
                    if (this.promotional && this.promotional.on === '1') {
                            this.promotionalAPIcallSocial(token, 'twitter');
                          } else if (this.promotional && this.promotional.on === '0') {
                              this.setFirstTimeloginSocial('1', token, 'twitter');
                          }
                }
     }
  }, err => {
    this.settingsFailsRegister(gdprsettings, type, token, 'twitter');
    });
} else { // login
       let gdprValue1, gdprsettings;
        gdprValue1 = {
                'country_code': this.countrycode,
                'gdpr_fields': {
                  'policy': policyValues[0],
                  'profiling': policyValues[1],
                  'age': policyValues[2],
                  'subscription': policyValues[3]
                }
            };
            this.gdprValue.push(gdprValue1);
         gdprsettings = {
            'key': 'gdpr_policy',
            'value': JSON.stringify(this.gdprValue)
         };
        this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
        this.userSettings.v1SettingsPut(gdprsettings).subscribe(responsePost => {
          this.updateGMID(token, 'twitter');
        },
        err => {
          this.errorMessage = 'MESSAGES.TRY_LATER';
          this.ErrorTostMessage(this.errorMessage);
        });
    }
    if (type === 'register') {
     this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
      this.userSettings.v1SettingsGet().subscribe( response => {
        this.settingsResponse = response;
         this.cookieConcent(this.settingsResponse);
      }, err => {
        // todo
      });
    }
}
private checkGdprNode(token): any {
   if (token) {
        let params;
        params = 'bearer ' + token ;
       this.config = {
          apiKey: params,
          username: '',
          password: '',
          accessToken: '',
          withCredentials: false
        };
        this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
        this.userSettings.v1SettingsGet().subscribe( response => {
          this.settingsResponse = response;
          this.cookieConcent(this.settingsResponse);
          let gdpr_Flag;
          if ( response.length > 0) {
            for (let i = 0; i < response.length; i++) {
              if ( response[i].key === 'gdpr_policy') {
                gdpr_Flag = true;
                 if (!(response[i].value[0] === '{')) {
                   this.gdprValue = JSON.parse(response[i].value);
                   let flagcheck = false;
                    for (let j = 0; j < this.gdprValue.length; j++) {
                    if (this.countrycode === this.gdprValue[j].country_code) {
                      flagcheck = true;
                      break;
                    } else if (j === this.gdprValue.length - 1) {   // no country code match so show GDPR screen with put request
                        flagcheck = false;
                      }
                    }
                    if (flagcheck) {
                      this.updateGMID(token, 'twitter');
                    } else {
                      this.gdprCountryChange = true;
                      this.showScreen(token);
                    }
                 } else {
                     this.userSettings.v1SettingsDelete('gdpr_policy', token).subscribe(responseput => {
                       this.showScreen(token);
                     });
                  }
              }
            }
            if (gdpr_Flag === undefined) {
              this.getSocialUserDetails(token);
            }
          } else {
            if (gdpr_Flag === undefined) {
              this.getSocialUserDetails(token);
            }
          }
        }, err => {
          this.errorMessage = 'MESSAGES.TRY_LATER';
          this.ErrorTostMessage(this.errorMessage);
        });
      }
}
private getSocialUserDetails(token): any {
   let userDetails;
    userDetails = new UserApi(this.http, null, this.config);
    userDetails.v1UserGet().timeout(environment.timeOut).subscribe(value => {
    this.userData = value;
    this.localstorage.setItem('ID', this.userData.id);
    if (value.additional.gdpr_policy) {
      for (let j = 0; j < value.additional.gdpr_policy.length; j++) {
        if (this.countrycode === value.additional.gdpr_policy[j].country_code) {
           let gdprValue;
           gdprValue = [{'country_code': this.countrycode,
                    'gdpr_fields': {
                        'policy': value.additional.gdpr_policy[j].gdpr_fields.policy,
                        'profiling': value.additional.gdpr_policy[j].gdpr_fields.profiling,
                        'age': value.additional.gdpr_policy[j].gdpr_fields.age,
                        'subscription': value.additional.gdpr_policy[j].gdpr_fields.subscription
                     }}];
          const gdpr_settings = {
              'key': 'gdpr_policy',
              'value': JSON.stringify(gdprValue)
          };
          this.userSettings.v1SettingsPost(gdpr_settings).subscribe(responsePost => {
            this.updateGMID(token, 'twitter');
          }, err => {
              this.errorMessage = 'MESSAGES.TRY_LATER';
              this.ErrorTostMessage(this.errorMessage);
          });
        } else {
                 this.showScreen(token);
                }
      }
    } else if (value.additional.gdpr_policy === undefined) { // GDPR post request no node
         this.showScreen(token);
      }
    }, err => {
        $('#loaderPage').css('display', 'none');
        $('.blank').css('height', 0);
        this.gtm.sendErrorEvent('api', err);
        if (err.name === 'TimeoutError') {
          this.errorMessage = err.message;
          this.ErrorTostMessage(this.errorMessage);
        } else {
            this.errors = err.json();
            this.errorMessage = err.message;
            this.ErrorTostMessage(this.errorMessage);
        }
      });
}
private sendData(value) {
   this.receivedValue = value ;
}
private GdprUpdate() {
 $('#loaderPage').css('display', 'block');
 if (this.loginFrom === 'login') {
  this.updateSettingApi(this.sendToken, this.loginFrom);
  } else {
    this.twitterRegisterApi(this.twitterAccessToken);
  }
}
private showScreen(token) {
$('#loaderPage').css('display', 'none');
$('.blank').css('height', 0);
this.loginFrom = 'login';     // to differentate register r login
this.localstorage.setItem('twitterType', 'register');  // to call twitter logout

  if (this.localstorage.getItem('country_code') !== 'IN') {
    this.internationalGdprFlag = true;
  } else {
  this.signInFlag = true;
  this.sendToken = token;
  this.headerservicesService.registerMobilechange(false);
  this.headerservicesService.bgImageValueChange(true);
  this.headerservicesService.signinDetailsChange(false);
  this.headerservicesService.signinRightTopChange(true);
  this.headerservicesService.signinLeftChange(true);
  }
}
private AcceptEnable() {
  if (!(this.receivedValue.sendFlag)) {
        $('.Accept').css({'background-color': '#50012f', 'color': '#703055'});
        return true;
      } else {
         $('.Accept').css({'background-color': '#bf006b', 'color': '#eeeeee'});
        return false;
    }
}
private ErrorTostMessage(errorMessage): any {
$('#loaderPage').css('display', 'none');
$('.blank').css('height', 0);
  this.errorMessage = errorMessage;
  this.imgaShow = true;

 if (this.localstorage.getItem('country_code') !== 'IN') {
    this.internationalGdprFlag = false;
  } else {
  this.signInFlag = false;
  }

  $('#headerMenu').show();
  $('.appFooter').show();
  $('.blank').css({'height': '500px'});
  this.ToastApi();
}
private updateGMID(userId, method) {
  $('#loaderPage').css('display', 'block');
   this.localstorage.setItem('login', 'twitter');
   this.localstorage.setItem('token',  this.twitterToken);
   this.qgraphevent('Signin_Success', {'method': 'social_twitter', 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});

          let params;
          params = 'bearer ' + userId ;
         this.config = {
            apiKey: params,
            username: ' ',
            password: ' ',
            accessToken: ' ',
            withCredentials: false
          };
          let userDetails;
          userDetails = new userApi.UserApi(this.http, null, this.config);
          userDetails.v1UserGet().timeout(environment.timeOut).subscribe(value => {
            this.localstorage.setItem('googletag', 'false');
            this.userId = value.id;
            this.localstorage.setItem('ID', this.userId );
            this.tokenValue = this.gtm.fetchToken();
            this.clientID = this.gtm.fetchClientId();
            this.marketingValue = this.gtm.fetchMarketing();
               this.gtm.logEvent(
              {
                'event' : 'LoginSuccess',
                'LoginMethod' : 'twitter',
                'G_ID': this.tokenValue,
                'Client_ID': this.clientID,
                'retargeting_remarketing' : this.marketingValue
              });
             $('#loaderPage').css('display', 'none');
              $('.blank').css('height', 0);
               this.updatePromotionSocial(value, userId, method);
          }, err => {
          $('#loaderPage').css('display', 'none');
          $('.blank').css('height', 0);
            this.userId = 'NA';
             this.window.location.href = environment.twitterLogout + this.previousUrl + '&ver=' + this.twitterTime;
             this.gtm.sendErrorEvent('api', err);
          });
  }
  private parentalRoute(token) {
        if (token) {
        this.params = 'bearer ' + token;
        const config = {
          apiKey: this.params,
          username: ' ',
          password: ' ',
          accessToken: ' ',
          withCredentials: false
        };
        const userDetails = new userApi.UserApi(this.http, null, config);
        userDetails.v1UserGet().takeUntil(this.ngUnsubscribe).subscribe(value => {
          this.data = value;
          this.compareUserData(this.data);
        $('#loaderPage').css('display', 'none');
          $('.blank').css('height', 0);
        },
        err => {
          if (err.status !== 0) {
          this.localstorage.removeItem('token');
          this.localstorage.removeItem('login');
          this.window.location.reload(true);
          this.localstorage.removeItem('parental');
        }
        $('#loaderPage').css('display', 'none');
        $('.blank').css('height', 0);
        });
    }

  }
    private compareUserData(parentalData) {   // compare first login user and parental login user
     let orginalData;
     orginalData = this.userProfileService.getuserdata();
     if (orginalData.id === parentalData.id) {
      $('#headerMenu').show();
      $('.appFooter').show();
      this.localstorage.setItem('parentalControl', true);
      this.localstorage.removeItem('parental');
       $('#loaderPage').css('display', 'block');
       this.window.location.href = environment.twitterLogout + '/parentalcontrol' + '&ver=' + this.twitterTime;     // for routing to parentalControl if success and destroy session
     } else {
      $('#loaderPage').css('display', 'none');
      this.imgaShow = true;
      $('#headerMenu').show();
      $('.appFooter').show();
      $('.blank').css({'height': '500px'});
      this.callToast();
      this.localstorage.removeItem('parental');
    }
  }
    private callToast() {
    let p;
    p = this.document.getElementById('snackbar');
    p.className = 'show';
    let scope;
    scope = this;
    setTimeout(function() {
      p.className = p.className.replace('show', '');
      scope.window.location.href = environment.twitterLogout + scope.previousUrl + '&ver=' + scope.twitterTime;
      $('#loaderPage').css('display', 'block');
    }, 2000);
  }
private ToastApi() {
    let p;
    p = this.document.getElementById('snackbarTwitter');
    p.className = 'show';
    let scope;
    scope = this;
    setTimeout(function() {
      p.className = p.className.replace('show', '');
      scope.window.location.href = environment.twitterLogout + scope.previousUrl + '&ver=' + scope.twitterTime;
       $('#loaderPage').css('display', 'block');
    }, 2000);

  }
private confirmationPage() {
  if (this.localstorage.getItem('country_code') !== 'IN') {
      this.internationalGdprFlag = false;
  } else {
    this.signInFlag = false;
    this.signInLeftFlag = false;
    this.signinHide = false;
    this.signInComponentFlag = false;
    this.headerservicesService.loginComponentChange(false);
    this.headerservicesService.loginMobileChange(false);
    this.headerservicesService.loginEmailChange(false);
    this.headerservicesService.registerMobilechange(false);
  }
  this.headerservicesService.RegisterSuccessChange(true);
  this.profileFlag = true;
  this.localstorage.setItem('googletag', 'false');
  $('#loaderPage').css('display', 'none');
}
private updatePromotionSocial(value, token, method) {
  this.userData = value;
  if (this.userData === undefined || this.userData.length === 0) {
      let userDetails;
      userDetails = new UserApi(this.http, null, this.config);
      userDetails.v1UserGet().timeout(environment.timeOut).subscribe(valueuser => {
      this.userData = valueuser;
      if ( this.settingsResponse.length > 0) {
        for (let i = 0; i < this.settingsResponse.length; i++) {
          if ( this.settingsResponse[i].key === 'first_time_login') {
            if (this.settingsResponse[i].value === '1') {
               this.localstorage.setItem('login', method);
               this.localstorage.setItem('token', token);
               // this.window.location.href = environment.twitterLogout + this.previousUrl + '&ver=' + this.twitterTime;
              this.changeRoute();
            } else if (this.settingsResponse[i].value === '0') {
              let disp, valuecountryCode;
              disp = this.localstorage.getItem('display_language');
                 valuecountryCode = this.settingsService.getCountryValueNew();
                if (valuecountryCode && valuecountryCode.length > 0) {
                 this.promotional = value[0].promotional;
                 this.countryToken = this.promotional.token;
                if (this.promotional && this.promotional.on === '1') {
                  this.promotionalAPIcallSocial(token, method);
                } else if (this.promotional && this.promotional.on === '0') {
                    this.setFirstTimeloginSocial('1', token, method);
                }
          }
            }
          } else if (i === this.settingsResponse.length - 1) {
                 if (this.userData.additional.first_time_login) {
                   if (this.userData.additional.promotional && this.userData.additional.promotional.on === '1') {
                     this.promotionalAPIcallSocial(token, method);
                     } else if (this.userData.additional.promotional && this.userData.additional.promotional.on === '0') {
                       this.setFirstTimeloginSocial('1', token, method);
                     } else {
                       this.setFirstTimeloginSocial('1', token, method);
                     }
                  } else {
                    this.setFirstTimeloginSocial('1', token, method);
                  }
               }
            }
           }
        }, err => {
          this.errorMessage = err.message;
          this.ErrorTostMessage(this.errorMessage);
        });
  } else if (this.userData) {
      if ( this.settingsResponse.length > 0) {
        for (let i = 0; i < this.settingsResponse.length; i++) {
          if ( this.settingsResponse[i].key === 'first_time_login') {
               this.localstorage.setItem('login', method);
               this.localstorage.setItem('token', token);
               // this.window.location.href = environment.twitterLogout + this.previousUrl + '&ver=' + this.twitterTime;
              this.changeRoute();
          } else if (i === this.settingsResponse.length - 1) {
              if (this.userData.additional.first_time_login) {
                if (this.userData.additional.promotional && this.userData.additional.promotional.on === '1') {
                    this.promotionalAPIcallSocial(token, method);
                } else if (this.userData.additional.promotional && this.userData.additional.promotional.on === '0') {
                  this.setFirstTimeloginSocial('1', token, method);
                } else {
                  this.setFirstTimeloginSocial('1', token, method);
                }
              } else {
                  this.setFirstTimeloginSocial('1', token, method);
              }
          }
        }
      } else if (this.userData.additional.first_time_login) {
            if (this.userData.additional.promotional && this.userData.additional.promotional.on === '1') {
                this.promotionalAPIcallSocial(token, method);
            } else if (this.userData.additional.promotional && this.userData.additional.promotional.on === '0') {
                this.setFirstTimeloginSocial('1', token, method);
            } else {
              this.setFirstTimeloginSocial('1', token, method);
            }
      } else {
               this.setFirstTimeloginSocial('1', token, method);
          }
  }
}
private setFirstTimeloginSocial(first_time_value, token, method) {
  $('#loaderPage').css('display', 'block');
  let first_time_settings;
  first_time_settings = {
    key: 'first_time_login',
    value: first_time_value
  };
  this.userSettings.v1SettingsPost(first_time_settings).subscribe(responsePost => {
              this.localstorage.setItem('login', method);
              this.localstorage.setItem('token', token);
              if (this.loginMethod === 'login') {
              // this.window.location.href = environment.twitterLogout + this.previousUrl + '&ver=' + this.twitterTime;
                this.changeRoute();
              } else {
                 let userDetails;
                userDetails = new UserApi(this.http, null, this.config);
                userDetails.v1UserGet().timeout(environment.timeOut).subscribe(valueUser => {
                  this.userId = valueUser.id;
                  this.localstorage.setItem('ID', this.userId);
                 });
                this.confirmationPage();
              }
  }, err => {
    this.errors = err.json();
      if (this.errors.message === 'Item already exists') {   // for already node there
        this.userSettings.v1SettingsPut(first_time_settings).subscribe(responsePost => {
       this.localstorage.setItem('login', method);
       this.localstorage.setItem('token', token);
        // this.window.location.href = environment.twitterLogout + this.previousUrl + '&ver=' + this.twitterTime;
              this.changeRoute();
      }, error => {
       this.localstorage.setItem('login', method);
       this.localstorage.setItem('token', token);
        // this.window.location.href = environment.twitterLogout + this.previousUrl + '&ver=' + this.twitterTime;
              this.changeRoute();
      });
      } else {
        this.localstorage.setItem('login', method);
       this.localstorage.setItem('token', token);
        // this.window.location.href = environment.twitterLogout + this.previousUrl + '&ver=' + this.twitterTime;
              this.changeRoute();
      }
  });
    this.checkSubSilentLogin();
}
private promotionalAPIcallSocial(token, method) {
    let promotionalData, language, tokenType;
    tokenType = this.localstorage.getItem('token');
    if (tokenType) {
      language = localStorage.getItem('UserDisplayLanguage');
    } else {
      language = localStorage.getItem('display_language');
    }
    promotionalData = {
      'createPromo' : { 'token' : this.countryToken},
      'translation' : language
    };
    this.userAction.postPromotionalData(promotionalData, token).subscribe(value => {
      let promoDesc;
      if (value && value.subscription_plan && value.subscription_plan.description) {
        promoDesc = value.json().subscription_plan.description;
      }

      localStorage.setItem('promotionalDesc', promoDesc);
      this.localstorage.setItem('dialogCheck', 'true');
      /*Set settings first-time-login = 1*/
      this.setFirstTimeloginSocial('1', token, method);
     }, err => {
       if (err.status === 404 || err.status === 400) {
          /*Set settings first-time-login = 1*/
          this.setFirstTimeloginSocial('1', token, method);
        } else {
          /*Set settings first-time-login = 0*/
          this.setFirstTimeloginSocial('0', token, method);
        }
      });
}
  private cookieConcent(settingValue) {
    if (this.cookiesLocal === null || undefined) {
    this.cookiesLocal = 'na';
  }
   if (this.marketingLocal === null || undefined) {
    this.marketingLocal = 'na';
  }
  let popup, popupValue, oldCookie, oldRTRM;
  if ( settingValue.length > 0) {
    for (let i = 0; i < settingValue.length; i++) {
      if ( settingValue[i].key === 'popups') {
        popup = true;
        this.responsevalue = JSON.parse(settingValue[i].value);
         oldCookie = this.responsevalue[0].Cookies;
         oldRTRM = this.responsevalue[0].RTRM;
        if (this.responsevalue[0].Cookies === 'na' && this.responsevalue[0].RTRM === 'na' ) {
            popupValue = [{'Cookies': this.cookiesLocal, 'RTRM': this.marketingLocal}];
           const cookies_settings = {
           'key': 'popups',
           'value': JSON.stringify(popupValue)
           };
           this.userSettings.v1SettingsPut(cookies_settings).subscribe(responseput => {
             // todo
           });
        } else if (this.responsevalue[0].RTRM === 'na' || this.responsevalue[0].Cookies === 'na') {
          if (this.responsevalue[0].RTRM === 'na') {
             popupValue = [{'Cookies': oldCookie, 'RTRM': this.marketingLocal}];
          }
          if (this.responsevalue[0].Cookies === 'na') {
             popupValue = [{'Cookies': this.cookiesLocal, 'RTRM': oldRTRM}];
          }
           const cookies_settings = {
           'key': 'popups',
           'value': JSON.stringify(popupValue)
           };
           this.userSettings.v1SettingsPut(cookies_settings).subscribe(responseput => {
             // todio
           });
        }
      }
    }
    if (popup === undefined) {
       let popupValue1;
       popupValue1 = [{'Cookies': this.cookiesLocal, 'RTRM': this.marketingLocal}];
       const cookies_settings = {
       'key': 'popups',
       'value': JSON.stringify(popupValue1)
       };
      this.userSettings.v1SettingsPost(cookies_settings).subscribe(responsePost => {
        // todo
      });
      // post
    }
  } else {
    let popupValue2;
     popupValue2 = [{'Cookies': this.cookiesLocal, 'RTRM': this.marketingLocal}];
       const cookies_settings = {
       'key': 'popups',
       'value': JSON.stringify(popupValue2)
       };
      this.userSettings.v1SettingsPost(cookies_settings).subscribe(responsePost => {
        // todo
      });
      // post
  }
}
  private CommonConfigCall(token) {
   let params;
        params = 'bearer ' + token ;
       this.config = {
          apiKey: params,
          username: '',
          password: '',
          accessToken: '',
          withCredentials: false
        };
  }
  public changeprofile(reg) {
    this.profileFlag = reg.p1;
    this.signInComponentFlag = reg.p2;
  }
  private settingsFailsRegister(gdprsettings, type, token, method): any {
  this.userSettings.v1SettingsPost(gdprsettings).subscribe(responsePost => {
     if (type !== 'register') {    // login just reload with update GA and QG
       this.updateGMID(token, method);
     } else {                      // check for promotional
        let disp, valuecountryCode;
          disp = this.localstorage.getItem('display_language');
           valuecountryCode = this.settingsService.getCountryValueNew();
            if (valuecountryCode && valuecountryCode.length > 0) {
               this.promotional = valuecountryCode[0].promotional;
               this.countryToken = this.promotional.token;
                if (this.promotional && this.promotional.on === '1') {
                   this.promotionalAPIcallSocial(token, method);
                } else if (this.promotional && this.promotional.on === '0') {
                   this.setFirstTimeloginSocial('1', token, method);
                }
            }
     }
  }, err => {
    this.errorMessage = 'MESSAGES.TRY_LATER';
    this.ErrorTostMessage(this.errorMessage);
  });
}
  public ngOnDestroy() {
      $('#headerMenu').show();
      $('.appFooter').show();
      this.window.location.href = environment.twitterLogout + this.previousUrl + '&ver=' + this.twitterTime;
  }
    private qgraphevent(eventname, object) {
    if (this.window.qg) {
      // if (this.qgraph) {
      //   delete object.country;
      //   delete object.state;
      //   qg('event', eventname, object);
      // } else {
        qg('event', eventname, object);
      // }
    }
  }

  private checkSubSilentLogin(): any {
  let recVal, sendVal;
  recVal = this.localstorage.getItem('subSilentLogin');
  if (recVal) {
    sendVal = {
      'subValue' : true,
      'loginValue' : true
    };
    this.localstorage.setItem('subSilentLogin', JSON.stringify(sendVal));
  }
}
  private changeRoute(): any {
    let postRoute;
    postRoute = this.localstorage.getItem('postSubscriptionRoute');
    if (this.previousUrl !== '/myaccount/subscription' && postRoute) {
      this.localstorage.removeItem('postSubscriptionRoute');
      this.commonService.getPostSubscriptionRoute(postRoute, 'login');
    } else {
      this.window.location.href = environment.twitterLogout + this.previousUrl + '&ver=' + this.twitterTime;
    }
  }
  public close(): any {
      this.router.navigate(['/']);
      $('#body').removeClass('scrolldisbale');
      this.headerservicesService.modelChange(false);
      this.headerservicesService.internationalRegisterChange(false);
      this.document.getElementById('body').classList.remove('modal-open');
      this.routeservice.Signal(null);
      this.previousUrl = this.localstorage.getItem('previousRoute');
      if (this.previousUrl !== null) {
        if (this.previousUrl.match(/search\/result/g)) {
          let query;
          query = this.previousUrl.slice(17);
          query = decodeURIComponent(query);
          this.router.navigate(['/search/result'], { queryParams: { q: query} });
          this.to.go(this.previousUrl);
        } else if (this.previousUrl.match(/signin/g)) {
          this.router.navigate(['/']);
          this.to.replaceState('/');
        } else {
          this.router.navigate([this.previousUrl]);
          this.to.replaceState(this.previousUrl);
        }
      } else {
        this.router.navigate(['/']);
        this.to.replaceState('/');
      }
    }
    public gdprFromSignIn(event) {
      this.gdpr = event;
      this.queryparams = window.location.href.split('?')[1];
        this.to.replaceState('register');
    }
}
