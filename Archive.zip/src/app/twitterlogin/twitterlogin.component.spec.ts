import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TwitterloginComponent } from './twitterlogin.component';

describe('TwitterloginComponent', () => {
  let component: TwitterloginComponent;
  let fixture: ComponentFixture<TwitterloginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TwitterloginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TwitterloginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
