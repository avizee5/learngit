import { Component, OnInit, HostListener, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { Http } from '@angular/http';
import { Location } from '@angular/common';
import { HeaderservicesService } from '../services/headerservices.service';
import { SettingsService } from '../services/settings.service';
import { NetworkService } from '../services/network.service';
import { RouteService } from '../services/route.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { UserApiService } from '../services/user-api.service';
// import * as api from '../../data/catalog/api/api';
import { SearchApi } from '../../data/catalog/api/SearchApi';
import * as SettingsApi from '../../data/user/api/api';
import { CollectionApi } from '../../data/catalog/api/CollectionApi';
import { environment } from '../../environments/environment';
import 'rxjs/add/operator/timeout';
import * as $ from 'jquery';
import { SubscriptionService } from '../services/subscription.service';
import { Event, NavigationStart, NavigationError, NavigationEnd } from '@angular/router';
import { Subject } from 'rxjs/Subject';
import { CommonService } from '../services/common.service';
import { TranslateService } from '@ngx-translate/core';
import { UseractionapiService } from './../services/useractionapi.service';


/* Angular Universal */
import { isPlatformBrowser } from '@angular/common';
import { Inject, PLATFORM_ID } from '@angular/core';

declare let webkitSpeechRecognition;

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.less']
})
export class SearchComponent implements OnInit, OnDestroy {
  private sub: any; /*Route Params for deep linking*/
  private ngUnsubscribe = new Subject<any>();

  public assetbasepath = environment.assetsBasePath;  // Asset basepath variable
  private userToken: any; /*Login token*/
  private countryCode: any; /*Country Code */
  private configValue: any; /*Config file*/
  private language: any;
  private errorImage: any;
  private display: any;
  private content: any;

  public placeholder: any = 'SEARCH.SEARCH_INFO2';
  public speaker: any = 'SEARCH.SEARCH_INFO1';

  public speakerIcon: boolean;  /*Search Voice*/
  public voiceflag: any;

  private assetType: any;
  private localStoragevalue: any = [];
  private fromLocalStorage: any;

  private imageUrl: any;
  private imageUrlConst: any;
  private imageUrlNew: any;

  public suggestions: any = [];
  private audioLanguage: any = [];
  private audioLanguagePopular: any = [];
  private searches: any = [];
  public searchedStrings: any;
  public recentContent: any;
  private recentSearch: any;
  public searchQuery = '';
  private resultsNum: any;

  public newLaunchesGrid: any;
  private newLaunchesTitle: any;

  public recommendedValue: any;
  private recommendedTray: any;

  private userSettings: any; /*Settings API*/
  private default_settings: any;
  private config: any;

  private pageName: any; /*GA*/
  private tokenValue: any;
  private timestampTime: any;
  private timestampDateTime: any;

  private localStorage: any; /*Angular Universal Global variables*/
  private window: any;
  private document: any;
  private navigator: any;
  private searchResults: any;
  private currentCountry: any;
  private plans: any;
  private showPremium: any;
  private modifiedSearchQuery: any;
  private clientID: any;
  private marketingValue: any;
  public assetSubtype: any;
  public subtitle_main: any;
  public tagList: any;
  public isNewsPage: any;
  public isNewsPageCheck: any;
  public card_type: any;
  public version: any;
  public platform: any;
  private prevUrl: any;
  public currentTime;
  public progress = 0;
  public displaylanguage;
  public elapsedTime: any;

  constructor(@Inject(PLATFORM_ID) private platformId: Object,
    private networkService: NetworkService,
    private gtm: GoogleAnalyticsService,
    private route: ActivatedRoute,
    private to: Location,
    private userapiService: UserApiService,
    private routeservice: RouteService,
    private headerservicesService: HeaderservicesService,
    private settingsService: SettingsService,
    private router: Router,
    private subscriptionService: SubscriptionService,
    private http: Http,
    private commonService: CommonService,
    private translate: TranslateService,
    private useractionapiService: UseractionapiService) {
    this.configLanguage();
  }

  public ngOnInit() {
    this.commonService.updateTime();
    this.settingsService.bluekaiPagename('search');
    if (isPlatformBrowser(this.platformId)) {
      this.localStorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
    let token = localStorage.getItem('token');
    if (token) {
      this.displaylanguage = localStorage.getItem('UserDisplayLanguage');
    } else {
      this.displaylanguage = localStorage.getItem('display_language');
    }
    this.version = this.window.appVersion;
    this.platform = this.navigator.userAgent.match(/mobile|iPhone|iPod|iPad/i) ? 'Web Mobile' : 'Web Desktop';
    this.settingsService.settabLink(0);
    this.router.events.takeUntil(this.ngUnsubscribe).takeUntil(this.ngUnsubscribe).subscribe((event: any) => {
      if (event instanceof NavigationEnd) {

        if (!event.url.match(/search/gi)) {
          this.ClosingModal();
        }

      }
    });
    $('#my-banner').hide();
    $('#body').addClass('scrolldisbale');
    this.currentCountry = this.settingsService.getCountryValueNew();
    this.plans = this.subscriptionService.checkPlanApiSuccess(false);
    if (this.plans.indexOf('9') >= 0) {
      this.plans.push('10');
    }
    if (this.plans.indexOf('6') >= 0) {
      this.plans.push('1');
    }

    this.flagHide();
    this.font();
    this.voiceflag = false;

    this.errorImage = this.assetbasepath + 'assets/default/tvshow.png';
    this.countryCode = this.settingsService.getCountry();
    this.userToken = this.localStorage.getItem('token');
    this.imageUrl = this.settingsService.getbasePath();
    this.imageUrlNew = this.settingsService.getbasePathNew();
    this.display = this.userToken ? this.localStorage.getItem('UserDisplayLanguage') : this.localStorage.getItem('display_language');
    this.content = this.userToken ? this.localStorage.getItem('UserContentLanguage') : this.localStorage.getItem('ContentLang');

    /* Google Analytics */
    this.pageName = 'search';
    this.gtm.sendPageName(this.pageName);
    this.gtm.sendEvent();
    this.tokenValue = this.gtm.fetchToken();
    this.gtm.storeWindowError();
    let pointersCheck;
    pointersCheck = this.headerservicesService.getcontentLanguageChanges();
    if (pointersCheck === undefined || pointersCheck.boolean !== true) {
      $(function () {
        $('#textfield').focus();
      });
    }

    this.config = {
      apiKey: ' ',
      username: ' ',
      password: ' ',
      accessToken: ' ',
      withCredentials: false
    };

    this.assetType = {
      0: (this.suggestions.asset_subtype === 'video' ? 'MENU.VIDEOS' : 'MENU.MOVIES'),
      1: 'DETAILS.EPISODE',
      6: 'MENU.TVSHOWS',
      9: 'Channel'
    };

    this.recommendedTray = {
      'Premium': 'COMMON.PREMIUM',
      'TV Shows': 'MENU.TVSHOWS',
      'Movies': 'MENU.MOVIES',
      'Videos': 'MENU.VIDEOS',
      'LIVE TV': 'MENU.LIVE_CAPS',
      'ZEE5 Originals': 'MENU.ZEEORIGINALS'
    };

    this.getConvivaPopular();

    $('#fullContainer').show();
    $('#searchOverlay').hide();
    $('#noResults').hide();
    this.speakerIcon = true;

    if (!this.window.hasOwnProperty('webkitSpeechRecognition')) {
      this.speakerIcon = false;
    }

    let scope;
    scope = this;

    /*Deep linking between search & search results */
    this.window.onpopstate = function () {
      $('#fullContainer').show();
      $('#searchOverlay').hide();
      scope.headerservicesService.searchIcon(false);
      scope.headerservicesService.modelChange(false);
      $('#body').removeClass('scrolldisbale');
      let contentObject;
      contentObject = {
        'boolean': false,
        'string': '',
        'id': ''
      };
      scope.headerservicesService.contentLanguageChanges(contentObject);
    };

    let a;
    a = this.localStorage.getItem('Recent Searches');
    if (this.userToken) {
      let userBearer;
      userBearer = 'bearer ' + this.userToken;

      let config;
      config = {
        apiKey: userBearer,
        username: ' ',
        password: ' ',
        accessToken: ' ',
        withCredentials: false
      };
      this.userSettings = new SettingsApi.SettingsApi(this.http, null, config);
      this.userSettings.v1SettingsGet().timeout(environment.timeOut).subscribe(response => {
        if (response.length > 0) {
          for (let i = 0; i < response.length; i++) {
            if (response[i].key === 'recent_search') {
              this.recentSearch = true;
              if (response[i].value === '' || response[i].value === '-') {
                this.searchedStrings = [];
                this.recentContent = false;
              } else {
                this.fromLocalStorage = response[i].value;
                this.searchedStrings = [];
                this.searchedStrings = this.fromLocalStorage.split(',');
                this.recentContent = true;

                let l, m;
                for (l = 0; l < this.searchedStrings.length; l++) {
                  for (m = l + 1; m < this.searchedStrings.length; m++) {
                    if (this.searchedStrings[l] === this.searchedStrings[m]) {
                      this.searchedStrings.splice(m, 1);
                    }
                  }
                }
                if (this.searchedStrings.length > 7) {
                  this.searchedStrings.splice(7, (this.searchedStrings.length - 7));
                }
              }
            }
          }

          if (!this.recentSearch) {
            this.default_settings =
              [
                { key: 'recent_search', value: '' }
              ];

            for (let j = 0; j < this.default_settings.length; j++) {
              const defaultsettings = {
                'key': this.default_settings[j].key,
                'value': this.default_settings[j].value
              };

              this.userSettings.v1SettingsPost(defaultsettings).subscribe(responsePost => {
                // todo
              },
                err => {
                  // todo
                });
            }
          }
        }
      }, err => { this.gtm.sendErrorEvent('api', err); });
    } else {
      if (a === null) {
        this.searchedStrings = [];
        this.recentContent = false;
      } else {
        this.fromLocalStorage = this.localStorage.getItem('Recent Searches');
        this.searchedStrings = this.fromLocalStorage.split(',');
        this.recentContent = true;

        let e, f;
        for (e = 0; e < this.searchedStrings.length; e++) {
          for (f = e + 1; f < this.searchedStrings.length; f++) {
            if (this.searchedStrings[e] === this.searchedStrings[f]) {
              this.searchedStrings.splice(f, 1);
            }
          }
        }

        if (this.searchedStrings.length > 7) {
          this.searchedStrings.splice(7, (this.searchedStrings.length - 7));
        }
      }
    }
  } /*Ending ngOninit*/

  public subtitleConstruct(show) {
    // Subcategory Construction
    this.tagList = this.commonService.getSubcategory(show.tags, show.asset_type, show.asset_subtype, show.genre, show.content_owner);
    if (this.tagList.length <= 1) {
      return this.tagList.join(', ');

    } else {
      return this.tagList.join(', ');
    }
  }

  private getConvivaPopular() {
    this.audioLanguagePopular = [];

    let url;
    url = environment.convivaPopular + this.content + '&translation=' + this.display + '&country=' + this.countryCode + '&page=' + 1 + '&limit=' + 24;
    this.http.get(url).map(response => response.json()).subscribe(value => {
      this.newLaunchesGrid = value.docs;

      let audio, audioSplit;
      if (value && value.docs) {
        for (let j = 0; j < value.docs.length; j++) {
          audioSplit = [];
          if (value.docs[j].languages) {
            audio = value.docs[j].languages;
          } else {
            audio = [];
          }

          if (audio && audio.length > 0 && this.language[audio[0]]) {
            audioSplit.push(this.language[audio[0]].native);
          } else {
            audioSplit.push([]);
          }
          this.audioLanguagePopular.push(audioSplit.join(','));
        }
      }

    },
      err => {
        $('#loaderPage').css('display', 'none');
      });
  }
  private checkPremium(show: any) {
    let showPremium = true;
    if (this.currentCountry && this.currentCountry[0] && this.currentCountry[0].menu_options.premium_tag === 'no' && this.plans && this.plans.length > 0 && this.plans.indexOf(show.asset_type.toString()) >= 0) {
      showPremium = false;
    }
    return showPremium;
  }
  private getEpisodeUrl(date: any, tvshow_title: any, value: any) {
    let image_url;
    if (date && tvshow_title) {
      tvshow_title = tvshow_title.replace(/ /g, '_');
      let new_date, date_formatted, day, hrs, dayUpdate, month;
      new_date = new Date(date);
      day = new_date.getDate();
      hrs = new_date.getMonth() + 1;
      dayUpdate = day ? ((day < 10 ? '0' + day : day)) : '';
      month = hrs ? ((hrs < 10 ? '0' + hrs : hrs)) : '';
      date_formatted = dayUpdate.toString() + month.toString() + new_date.getFullYear().toString();
      let a, b, inRange;
      a = new Date(2015, 0, 15);
      b = new Date(2017, 9, 15);
      inRange = new_date >= a && new_date <= b;
      if (inRange) {
        image_url = 'https://akamaividz1.zee5.com/resources/episode-images/' + tvshow_title + '_Episode_' + date_formatted + '_574x358.jpg' + '?imwidth=270&impolicy=akamai_vidz1_zee5_com-IPM';
      } else {
        image_url = this.imageUrl + value.id + '/list/' + '270x152/' + value.list_image;
      }
    } else {
      image_url = this.imageUrl + value.id + '/list/' + '270x152/' + value.list_image;
    }
    return image_url;
  }

  /*Image URL Construction*/
  private imageUrlConstruction(value) {
    if (value && value.list_image) {
      if (value.asset_type === 1 && value.tvshow_details) {
        this.imageUrlConst = this.getEpisodeUrl(value.release_date, value.tvshow_details.title, value);
      } else if (value.asset_type === 0 || value.asset_type === 6) {
        this.imageUrlConst = this.imageUrlNew + value.id + '/list/' + '270x152/' + value.list_image + '?imwidth=270&impolicy=akamai_vidz1_zee5_com-IPM';
      } else {
        this.imageUrlConst = this.imageUrl + value.id + '/list/' + '270x152/' + value.list_image;
      }
      return this.imageUrlConst;
    }
  }

  /*Setting in Service file*/
  private setContent(key, n): any {
    this.userapiService.getParameter('put', key, n);
  }

  /*Routing from Recommended Tray to Landing screens*/
  private routeLandingScreens(url) {
    this.router.navigate([url]);
    this.ClosingModal();
  }

  private routeFunction(value, searchType, xIndex) {
    let yIndex;
    yIndex = 0;
    // if (value.extended && value.extended.seo_title) {
    //   value.title = value.extended.seo_title;
    // } else if (value.seo_title) {
    //   value.title = value.seo_title;
    // } else if (value.original_title) {
    //   value.title = value.original_title;
    // }
    value.title = value.original_title;
    // New gtm event
    if (searchType === 'popular') {
      // this.gtm.logEvent({'event': 'searchTermEnter',
      //   'refScreen': this.gtm.getPreviousPageName(),
      //   'search_mode': 'Text Search',
      //   'searchType': searchType ,
      //   'searchResult': this.searchResults,
      //   'SearchQuery': this.searchQuery,
      //   'G_ID': this.gtm.fetchToken(),
      //   'Client_ID': this.gtm.fetchClientId(),
      //   'retargeting_remarketing' : this.gtm.fetchMarketing(),
      //   'TimeHHMMSS': this.gtm.fetchCurrentTime(),
      //   'DateTimeStamp': this.gtm.fetchCurrentDate(),
      // });
      this.sendSearchDetails({ 'event': 'searchTermEnter', 'SearchQuery': this.searchQuery });
	let searchDetails;
          searchDetails = {
            'search_mode': 'Text Search',
            'searchType': searchType,
            'searchResult': this.searchResults ? this.searchResults : 0,
            'SearchQuery': this.searchQuery
          };
        this.sendInternalSearchTermDetails(searchDetails);
    }
    let clickContent;
    clickContent = this.imageUrlConstruction(value);
    this.sendSearchDetails({ 'event': 'searchResultClick', 'SearchQuery': this.searchQuery, 'Click_Content': clickContent ? clickContent : 'NA' });
    let routeUrl;
    this.prevUrl = this.localStorage.getItem('previousRoute');
    this.commonService.updateCollectionId(null);
    this.commonService.setTalamoosData('', '', '');
    this.gtm.GAsubCategory = '';
    this.gtm.setContentClickDetails(xIndex, yIndex, this.gtm.GAsubCategory);
    value.genres = value.genres ? value.genres : (value.genre ? value.genre : []);
    if (value.asset_type === 0) {
      if (value.asset_subtype === 'movie') {
        // this.router.navigate(['/movies/details', this.commonService.convertToLowercase(value.title), value.id ]);          
        routeUrl = ('/movies/details/' + this.commonService.convertToLowercase(value.title) + '/' + value.id);
      } else if (value.asset_subtype === 'video' && value.genres && value.genres.findIndex(i => i.id === 'News') !== -1) {
        // this.router.navigate(['/news/details', this.commonService.convertToLowercase(value.title), value.id ]);
        routeUrl = ('/news/details/' + this.commonService.convertToLowercase(value.title) + '/' + value.id);
      } else {
        //  this.router.navigate(['/videos/details', this.commonService.convertToLowercase(value.title), value.id ]);
        routeUrl = ('/videos/details/' + this.commonService.convertToLowercase(value.title) + '/' + value.id);
      }
    } else if (value.asset_type === 1 && value.tvshow_details) {
      // this.router.navigate(['/tvshows/details', this.commonService.convertToLowercase(value.tvshow_details.title), value.tvshow_details.id, this.commonService.convertToLowercase(value.title), value.id]);
      routeUrl = ('/tvshows/details/' + this.commonService.convertToLowercase(value.tvshow_details.title) + '/' + value.tvshow_details.id + '/' + this.commonService.convertToLowercase(value.title) + '/' + value.id);
    } else if (value.asset_type === 6) {
      // this.router.navigate([(value.asset_subtype === 'original' ? 'zee5originals' : 'tvshows') + '/details/' , this.commonService.convertToLowercase(value.title), value.id ]);
      if (value.asset_subtype === 'tvshow') {
        routeUrl = ('/tvshows/details/' + this.commonService.convertToLowercase(value.title) + '/' + value.id);
      } else if (value.asset_subtype === 'original') {
        routeUrl = ('/zee5originals/details/' + this.commonService.convertToLowercase(value.title) + '/' + value.id);
      }
    } else if (value.asset_type === 9) {
      // this.router.navigate(['/channels/details', this.commonService.convertToLowercase(value.title) , value.id ]);
      routeUrl = ('/channels/details/' + this.commonService.convertToLowercase(value.title) + '/' + value.id);
    } else if (value.asset_type === 10 && !value.channel_name) {
      // this.router.navigate(['/channels/details', this.commonService.convertToLowercase(value.title) , value.id ]);
      routeUrl = ('/channels/details/' + this.commonService.convertToLowercase(value.title) + '/' + value.id);
    } else if (value.asset_type === 10 && value.channel_name) {
      value.id =    value.channel_name.id;
      value.title =  value.channel_name.original_title;
      routeUrl = ('/channels/details/' + this.commonService.convertToLowercase(value.title) + '/' + value.id);
    }
    if (this.prevUrl === routeUrl) {
      this.to.go(routeUrl);
    } else {
      this.router.navigate([routeUrl]);
    }
    this.ClosingModal();
  }

  private routeSearch(query, type, route, searchType) {
    let query1;
    query1 = query.replace(/,/g, '');

    let network;
    network = this.networkService.getPopupStatus();
    if (network === true) {
      this.timestampTime = this.gtm.fetchCurrentTime();
      this.timestampDateTime = this.gtm.fetchCurrentDate();
      this.clientID = this.gtm.fetchClientId();
      this.marketingValue = this.gtm.fetchMarketing();
      // Previous gtm event
      this.gtm.logEvent(
        {
          'event': 'SiteSearch',
          'SearchQuery': query,
          'G_ID': this.tokenValue,
          'Client_ID': this.clientID,
          'retargeting_remarketing': this.marketingValue,
          'TimeHHMMSS': this.timestampTime,
          'DateTimeStamp': this.timestampDateTime,
          'search_mode': type
        });

      // New gtm event
      this.gtm.setSearchValues(type, searchType);
      // this.gtm.logEvent(
      //   {'event': 'searchTermEnter',
      //   'refScreen': this.gtm.getPreviousPageName(),
      //   'search_mode': type,
      //   'searchType': searchType ,
      //   'searchResult': this.searchResults,
      //   'SearchQuery': query,
      //   'G_ID': this.gtm.fetchToken(),
      //   'Client_ID': this.clientID,
      //   'retargeting_remarketing' : this.marketingValue,
      //   'TimeHHMMSS': this.gtm.fetchCurrentTime(),
      //   'DateTimeStamp': this.gtm.fetchCurrentDate(),
      // });
      this.sendSearchDetails({ 'event': 'searchTermEnter', 'SearchQuery': query });
   let searchDetails;
    searchDetails = {
      'search_mode': type,
      'searchType': searchType,
      'searchResult': this.searchResults ? this.searchResults : 0,
      'SearchQuery': query
    };
    this.sendInternalSearchTermDetails(searchDetails);
      $('#fullContainer').show();
      $('#searchOverlay').hide();

      this.headerservicesService.searchIcon(false);
      this.headerservicesService.modelChange(false);
      $('#body').removeClass('scrolldisbale');
      this.localStoragevalue = [];
      this.searches = [];

      if (this.recentSearch === true) {
        this.searches = this.searchedStrings;
        this.searches.unshift(query1);
      } else if (this.recentSearch === false || !this.userToken) {
        this.searches = this.searchedStrings;
        this.searches.unshift(query1);
      } else {
        this.searches = [];
      }

      let str, prevurl, queryStr;
      str = this.searches.join(',');

      this.localStoragevalue = [];
      this.localStoragevalue.push(str);
      prevurl = this.localStorage.getItem('previousRoute');
      queryStr = prevurl.split('=')[1];

      if (this.userToken) {
        this.setContent('recent_search', str);
      } else {
        this.localStorage.setItem('Recent Searches', str);
      }
      if (route === 'search') {
        if (queryStr === query1) {
          let routeUrl;
          routeUrl = '/search/result?' + 'q=' + query1;
          this.to.go(routeUrl);
        } else {
          this.router.navigate(['/search/result'], { queryParams: { q: query1 } });
        }
      }
    }
  }

  /**** Voice Search ****/
  public startDictation() {
    this.sendSearchDetails({ 'event': 'microphoneClicks' });
    let network, searchquery;
    network = this.networkService.getPopupStatus();
    const scope = this;
    scope.voiceflag = true;

    setTimeout(function () {
      $('#textfield').trigger('click');
    }, 2000);
    setTimeout(function () {
      scope.voiceflag = false;
      $(function () {
        $('#textfield').focus();
        if (searchquery.length !== 0) {
          scope.routeSearch(searchquery, 'Voice Search', 'search', 'manual');
        }
      });
    }, 7000);

    if (network === true) {
      if (scope.window.hasOwnProperty('webkitSpeechRecognition')) {
        if (isPlatformBrowser(this.platformId)) {
          searchquery = (<HTMLInputElement>document.getElementById('textfield')).value;
        }
        let x;
        // x = new api.SearchApi(this.http, null, null);
        x = new SearchApi(this.http, null, null);

        const recognition = new webkitSpeechRecognition();
        // recognition = new webkitSpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-US';
        recognition.start();
        recognition.onresult = function (e) {
          if (isPlatformBrowser(scope.platformId)) {
            (<HTMLInputElement>document.getElementById('textfield')).value = e.results[0][0].transcript;
            searchquery = (<HTMLInputElement>document.getElementById('textfield')).value;
          }
        };
      }
    }
  }

  /**** Typed Search ****/
  public openModalSearch(event): any {
    let scope;
    scope = this;
    let currentKey;
    currentKey = event.keyCode;
    let searchquery, searchQuerySpecialChar;
    searchquery = (<HTMLInputElement>this.document.getElementById('textfield')).value;
    this.searchQuery = searchquery;
    searchQuerySpecialChar = searchquery.replace(/#/g, '');

    let x;
    // x = new api.SearchApi(this.http, null, null);
    x = new SearchApi(this.http, null, null);

    if (searchquery.length === 0) {
      if (this.window.innerWidth < 600) {
        $('#recentSearch').show();
        $('#searchOverlay').hide();
        $('#noResults').hide();
      } else {
        $('#recentSearch').show();
        $('#searchOverlay').hide();
        $('#noResults').hide();
      }
    }

    if ((searchquery.length > 2)) {
      if ((currentKey !== 40 && currentKey !== 39 && currentKey !== 38 && currentKey !== 37)) {
        this.http.get(environment.searchbasepath + 'autoSuggest?q=' + searchQuerySpecialChar + '&start=1&limit=10&translation=' + this.display + '&country=' + this.countryCode + '&version=2&languages=' + this.content).subscribe(value => {
          if (value && value.json().numFound) {
            this.searchResults = value.json().numFound;
          } else {
            this.searchResults = 0;
          }
          this.suggestions = [];
          this.audioLanguage = [];
          if (value && value.json().docs && value.json().docs.length > 0) {
            this.suggestions = value.json().docs;
            let audio, audioSplit;
            for (let j = 0; j < this.suggestions.length; j++) {
              // if (this.suggestions.extended && this.suggestions.extended.seo_title) {
              //   this.suggestions.title = this.suggestions.extended.seo_title;
              // } else if (this.suggestions.seo_title) {
              //   this.suggestions.title = this.suggestions.seo_title;
              // } else if (this.suggestions.original_title) {
              //   this.suggestions.title = this.suggestions.original_title;
              // }
                this.suggestions.title = this.suggestions.original_title;
              if (this.suggestions[j].asset_type === 10 && this.suggestions[j].channel_name) {
                this.suggestions[j]['progress'] = this.getProgressValue(this.suggestions[j].start_time, this.suggestions[j].end_time, this.suggestions[j].duration);
                this.suggestions[j]['un_progress'] = (100 - this.progress);
                this.suggestions[j]['elapsedTime'] = this.updateLiveTime();

              }
              if (this.suggestions[j].asset_subtype === 'video' && this.suggestions[j].genre.findIndex(i => i.id === 'News') !== -1) {
                this.suggestions[j].isNewsPageCheck = true;
                // this.suggestions[j].genres_data = this.subtitleConstruct(this.suggestions[j]);
              }

              // to get asset_subtype
              this.suggestions[j].card_type = this.commonService.getDefaultSub(this.suggestions[j].asset_type, this.suggestions[j].asset_subtype);


              audioSplit = [];
              if (this.suggestions[j].languages) {
                audio = this.suggestions[j].languages;
              } else {
                audio = [];
              }

              if (audio && audio.length > 0 && this.language[audio[0]]) {
                audioSplit.push(this.language[audio[0]].name);
              } else {
                audioSplit.push([]);
              }
              this.audioLanguage.push(audioSplit.join(','));
            }
          }

          $(this.document).ready(function () {
            if (searchquery.length > 0) {
              // Calling the highlighting function
              $('#suggestionCategory div').removeClass('match').show().filter(function () {
                return $(this).text().toLowerCase().indexOf($('#textfield').val().toLowerCase()) !== -1;
              }).addClass('match').show();
              scope.highlight(searchquery);
              $('#suggestionCategory').show();
            } else {
              $('#suggestionCategory, #suggestionCategory div').removeClass('match').show();
            }
          });

          /* Checking if query result is empty */
          if (this.suggestions.length <= 0 && searchquery.length >= 3) {
            if (currentKey === 13) {
              this.routeSearch(searchquery, 'Text Search', 'search', 'manual');
            } else {
              $('#noResults').show();
              $('#recentSearch').hide();
              $('#searchOverlay').hide();
            }
          } else if (searchquery.length < 3 && currentKey === 13) {
            this.callToast();
          } else {   /* If query result not empty */
            if (currentKey >= 0 && searchquery.length >= 3) {
              /*13--enter;8--backspace;32--space;48--numbers;65--alphabets*/
              if (currentKey === 13) {
                this.routeSearch(searchquery, 'Text Search', 'search', 'manual');
              }
            }

            if (searchquery.length >= 3 && this.suggestions.length > 0) {
              $('#noResults').hide();
              $('#recentSearch').hide();
              $('#searchOverlay').show();

              if (this.window.innerWidth < 480) {
                this.document.getElementById('modal-background').style.background = '#170c1a';
                this.document.getElementById('modal-background').style.opacity = '1';
              }
            } else if (searchquery.length < 3 && searchquery.length >= 0) {
              if (this.window.innerWidth < 600) {
                $('#noResults').hide();
                $('#recentSearch').show();
                $('#searchOverlay').hide();
                this.document.getElementById('modal-background').style.background = '#060107';
                this.document.getElementById('modal-background').style.opacity = '0.95';
              } else {
                $('#noResults').hide();
                $('#recentSearch').show();
                $('#searchOverlay').hide();
              }
            }
          }
        });
      }
    } else {
      $('#noResults').hide();
      $('#recentSearch').show();
      $('#searchOverlay').hide();
    }
  }
  /* For header change in mobile devices */
  @HostListener('window:resize', ['$event'])
  public flagHide() {
    if (this.window.innerWidth < 769) {
      this.headerservicesService.headerScrollSearch(true);
    }
  }

  /* To render fonts for different resolutions for highlighting text */
  public font() {
    if (this.window.innerWidth < 480) {
      $('.highlight').css({ 'font-family': 'Roboto', 'font-size': '14px', 'color': '#BF006B', 'font-weight': '400', 'letter-spacing': '0.02em' });
    } else {
      $('.highlight').css({ 'font-family': 'Roboto', 'font-size': '14px', 'color': '#BF006B', 'font-weight': '400', 'letter-spacing': '0.02em' });
    }
    return true;
  }

  /* highlight matching text */
  private highlight = function (string1) {

    let x;
    x = document.getElementsByClassName('0');
    if (x.length > 0) {
      for (let i = 0; i < x.length; i++) {
        if (string1) {
          let array;
          array = string1.trim().replace(' ','|');
          let pattern;
          pattern = new RegExp(  array , 'gi');
          let new_text;
          new_text = x[i].innerHTML.replace(pattern,'<span class=\'highlight\'>$&</span>');
          x[i].innerHTML = new_text;

        }
      }
    }
  };

  /*Regex check for URL titles*/
  private regex(value: any): any {
    let show_title;
    if (value) {
      show_title = value.toLowerCase().replace(/ /g, '-');
      show_title = show_title.replace(/---/g, '-');
      show_title = show_title.replace(/,/g, '');
      // show_title = show_title.replace(/[()]/g, '')
      // show_title = show_title.replace(/[^\w\s]/gi, '')
      show_title = show_title.replace(/&/g, 'and');
      show_title = show_title.replace(/[??`~!@#$%^&*()|+\=?;:'?",.<>\{\}\[\]]/gi, '');
      show_title = show_title.replace(/[^\011\012\015\040-\177]/gi, '');
      // show_title = show_title.replace(/?/g, '');
      // show_title = show_title.replace(/?/g, '');
      // show_title = show_title.replace(/?/g, '');

      show_title = show_title.replace(/--/g, '-');
    } else {
      show_title = 'title';
    }
    return show_title;
  }

  /*Convert seconds to hrs and minutes */
  private updateTime(s: number): any {
    let secs, mins, hrs, hrsStr, mins_new, time;
    secs = s % 60;
    s = (s - secs) / 60;
    mins = s % 60;
    s = (s - mins) / 60;
    hrs = s % 60;
    hrsStr = hrs ? ((hrs < 10 ? '0' + hrs : hrs) + ':') : '';
    if (mins < 10) {
      mins_new = '0' + mins;
    } else {
      mins_new = '' + mins;
    }

    time = (hrs ? hrs + 'h' : '') + ' ' + (mins ? mins_new + 'm' : '') + ' ' + (secs ? secs + 's' : '');
    return time;
  }

  private configLanguage() {
    this.configValue = this.settingsService.getCompleteConfig();
    this.language = [];

    this.recommendedValue = this.configValue.recommended;

    let self;
    self = this;
    this.configValue.languages.forEach(function (obj) {
      let temp;
      temp = {
        'name': obj.name,
        'native': obj.native,
      };
      self.language[obj.id] = temp;
    });
    return this.language;
  }
  /*Calling Toast on invalid searchquery */
  private callToast() {
    let p;
    p = this.document.getElementById('snackbarInvalid');
    p.className = 'show';
    setTimeout(function () { p.className = p.className.replace('show', ''); }, 3000);
  }

  /**** Closing ModalPopUp + Deeplinking ****/
  public modalClose() {
    this.sendSearchDetails({ 'event': 'searchCrossClicks' });
    $('#fullContainer').show();
    $('#searchOverlay').hide();
    // this.window.scrollTo(0, 0);
    this.headerservicesService.searchIcon(false);
    this.headerservicesService.modelChange(false);
    $('#body').removeClass('scrolldisbale');
    // this.to.go('search')
    //his.window.history.go(-1);
    let prevs = this.localStorage.getItem('previousRoute');
    //this.router.navigate([prevs]);
    this.to.replaceState(prevs)
  }
  @HostListener('window:popstate', ['$event'])
  public onPopState(event) {
    this.modalClose();
  }
  private ClosingModal() {
    $('#fullContainer').show();
    $('#searchOverlay').hide();
    // this.window.scrollTo(0, 0);
    this.headerservicesService.searchIcon(false);
    this.headerservicesService.modelChange(false);
    $('#body').removeClass('scrolldisbale');
  }

  public ngOnDestroy(): void {
    this.headerservicesService.headerScrollSearch(false);
  }

  public openTabs(searchQuery, tab) {
    //   let query1;
    // query1 = searchQuery.replace(/,/g, '');
    this.settingsService.settabLink(tab);
    // this.router.navigate(['/search/result'], { queryParams: { q: query1} });
    this.routeSearch(searchQuery, 'Text Search', 'search', 'manual');
  }
  /* Function to translate day and month */
  private getDateTranslate(date) {
    let month, dateString;
    dateString = (new Date(date)).toString().toUpperCase();
    month = dateString.split(' ')[1]; // fetch month
    return this.translate.instant('TVGUIDE.' + dateString.split(' ')[1]) + ' ' + dateString.split(' ')[2] + ', ' + dateString.split(' ')[3]; // translate day eg: Mon, Tue, Wed, ...
  }
  public searchCaptureForContentEnrichment(show, index) {
    let sQ;
    sQ = this.searchQuery.replace(/#/g, '');
    if (sQ) {
      let userToken, data;
      userToken = this.localStorage.getItem('token') ? this.localStorage.getItem('token') : this.localStorage.getItem('guestToken');
      data = {
        'keyword': sQ,
        'action': index ? 'autosuggest' : 'search',
        'platform': this.platform,
        'version': this.version,
        'usertype': this.userToken ? 'registered' : 'guest',
        'Authorization': this.userToken ? ('bearer ' + userToken) : userToken
      };
      (index === 0 || index > 0) ? (data['rank'] = index) : false;
      show ? (data['clicked'] = show.original_title) : false;
      this.useractionapiService.searchCapture(data, userToken)
        .then(response => {
          //  do nothing
        })
        .catch(error => {
          //  do nothing
        });
    } else {
      // do nothing
    }
  }
  public sendSearchDetails(searchDetails) {
    this.gtm.sendEventDetails(searchDetails);
  }
  public getProgressValue(start_time, end_time, duration) {
    if (start_time && duration) {
      this.currentTime = this.commonService.getServertime() ? this.commonService.getServertime() : Date.parse(new Date().toISOString());
      // let  date = new Date(start_time);
      // date.setHours(date.getHours()-5);   /* subtracting 5 hour 30 minutes from start time */
      // date.setMinutes(date.getMinutes()-30);
      // date.toISOString()
      let startTime =  Date.parse(start_time);
      let elapsed = (this.currentTime - startTime);
      this.elapsedTime = elapsed;
      let elapsedTime;
      elapsedTime = (elapsed / 1000);
      if ( Math.floor((elapsedTime / (duration)) * 100) <= 100) {
        this.progress = Math.floor((elapsedTime / duration) * 100);
      }
      this.updateLiveTime();
      return this.progress;
    }
  }
  public updateLiveTime() {
      let s = this.elapsedTime ;
      let secs, mins, hrs, hrsStr, time;
      secs = (s / 1000) % 60;
      s = ((s / 1000) - secs) / 60;
      mins = s % 60;
      s = (s - mins) / 60;
      hrs = s % 60;
      secs = Math.floor(secs);
      hrsStr = hrs ? ((hrs < 10 ? '0' + hrs : hrs) + ':') : '';
      if (this.displaylanguage === 'ru') {
        time = (hrs ? hrs + 'ч' : '') + ' ' + (mins ? mins + 'м' : '') + ' ' + (secs ? secs + 'с' : '');
      } else {
        time = (hrs ? hrs + 'h' : '') + ' ' + (mins ? mins + 'm' : '') + ' ' + (secs ? secs + 's' : '');
      }
     return  time;
    }
    public sendInternalSearchTermDetails(details) {
    	let searchdetails;
    	searchdetails = {
      		'event': 'searchTerm',
      		'search_mode': details.search_mode,
      		'searchType': details.searchType,
      		'searchResult': details.searchResult,
      		'SearchQuery': details.SearchQuery,
      		'SearchTermtype': details.SearchQuery
    	};
    	this.gtm.sendEventDetails(searchdetails);
    }
  }

