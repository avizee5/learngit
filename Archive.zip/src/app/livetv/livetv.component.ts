import { Component, OnInit, ViewChild, HostListener, OnDestroy } from '@angular/core';
import { CarouselComponent } from '../carousel/carousel.component'; // import to control carousel in your views
import { FilterService } from '../services/filter.service';
import { SettingsService } from '../services/settings.service';
import { HeaderservicesService } from '../services/headerservices.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { EpgService } from '../services/epg.service';
import { RouteService } from '../services/route.service';
import { VideoService } from '../services/video.service';
import { NetworkService } from '../services/network.service';
import { LinkService } from '../services/link.service';
import { CommonService} from '../services/common.service';
import { SubscriptionService } from '../services/subscription.service';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { Headers, Http , RequestOptions, Response} from '@angular/http';
// import { Http} from '@angular/http';
// import * as api from '../../data/catalog/api/api';
import { ChannelApi, EpgApi } from '../../data/catalog/api/api';
import { environment } from '../../environments/environment';
import * as $ from 'jquery';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/timeout';
import 'rxjs/add/operator/takeUntil';
import { RequestMethod, RequestOptionsArgs } from '@angular/http';

/* Angular Universal */
import { isPlatformBrowser } from '@angular/common';
import { Inject, PLATFORM_ID } from '@angular/core';

// declare let googletag;
declare const qg;

@Component({
 selector: 'app-livetv',
 templateUrl: './livetv.component.html',
 styleUrls: ['./livetv.component.less']
})

export class LivetvComponent implements OnInit, OnDestroy {
  @ViewChild(CarouselComponent) public carousel_element: CarouselComponent;   // get carousel element reference
  private id: any ;  /*Route Params values for Deeplinking*/
  private name: any;
  private watch: any;
  private sub: any;
  private carousel: any; /*Depends on API*/
  private router: any; /*Header Services */
  private router2: any;
  private pageName: any;
  private selectedFilters: any;  /*Filter*/
  public filter_titles: any;
  public view: any = 'livetv';
  private destroyFilter: any;
  private categories: any;
  private languages: any;
  public filter: any;
  public filterbar: boolean;
  private filterEnable: any;
  public filterFlag: boolean;
  private channels: any = [];
  private completeChannels: any = [];
  private filterCheck: any = [];
  private businessTypes: any = [];
  // private Genres: any = [];
  private genres: any;
  private grid: any;
  private completeGrid: any = [];
  public category: any;
  public liveTvCategory: any = [];
  // private Genrelist: any;
  private completeGenre: any = [];
  private startTime: any;
  private currentTime: any;
  private elapsed: any;
  private progress: any;
  private autoloaderDisable: any;
  public DATA: any = true;
  private serverTime: any;
  private url: any;
  private desktopTag: any;
  private mobileTag: any;
  // private googletagAvailable: any;
  private timer: any = [];
  private divDesktop: any;
  private divMobile: any;
  private adSpacing: any = 2;
  private totalAds: any;
  private touchScreen: any;
  private countryCode: any;

  private localStorage: any;
  private window: any;
  private navigator: any;

  private tempData: any = [];
  private liveTvValue: any;
  private genresdata: any;
  private channelList: any;
  private completeChannelList: any;
  private businessTypesList: any;
  private completeBusinesstypesList: any;
  private genreObject: any;
  private premium = false;

  public contentUpdate: any = false;

  public version;
  public platform;


  private ngUnsubscribe = new Subject<any>();

  // Asset basepath letiable
  private assetbasepath = environment.assetsBasePath;

  constructor(private linkservice: LinkService, private commonService: CommonService, @Inject(PLATFORM_ID) private platformId: Object, private networkService: NetworkService, private gtm: GoogleAnalyticsService, private videoService: VideoService, private settingsService: SettingsService, private epgService: EpgService , private filterService: FilterService, private location: Location,
    private route: ActivatedRoute, private routerLink: Router, private headerservicesService: HeaderservicesService, private http: Http, private routeservice: RouteService, private subscriptionService: SubscriptionService, ) {
    if (isPlatformBrowser(this.platformId)) {
      this.localStorage = localStorage;
      this.window = window;
      this.navigator = navigator;
    }

    let url;
    url = environment.serverTimeUrl;
    this.epgService.getcurrentTime(url).takeUntil(this.ngUnsubscribe).subscribe( value => {
      this.serverTime = new Date(value.serverdate);
      this.currentTime = this.serverTime.getTime();
    },
    err => {
      this.serverTime = new Date();
      this.currentTime = this.serverTime.getTime();
    });

    this.router = routerLink;
    this.router2 = this.window.location.pathname;
    this.headerservicesService.viewChange(this.router2);
    this.routeservice.setRoute(this.router2);
    this.routeservice.setLoginRoute(this.window.location.pathname);  /*Return back to this page on login relaod */

    this.destroyFilter =  this.filterService.configObservable.subscribe(value => {
    this.selectedFilters = value;
    let network;
    network = this.networkService.getScreenStatus();
    if ( this.selectedFilters) {
      if (network === true) {
         $('#loaderPage').css('display', 'block');
      }
      this.autoloaderDisable = false;
      setTimeout(() => { this.update(); }, 1000);
    }
  });

    this.window = window;
        this.version = this.window.appVersion;
        this.navigator = navigator;
        this.platform = this.navigator.userAgent.match(/mobile|iPhone|iPod|iPad/i) ? 'Web Mobile' : 'Web Desktop';
 }

  public ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.localStorage = localStorage;
      this.window = window;
      this.navigator = navigator;
    }
    let breadCrumbArray;
    breadCrumbArray = [{'label': 'BREADCRUMB.HOME', 'url': '/', 'enable': true}, {'label': 'BREADCRUMB.LIVE', 'url': this.router2, 'enable': false}];
    this.headerservicesService.breadCrump(breadCrumbArray);
    this.countryCode = this.settingsService.getCountry();
    this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'livetv'  } );

    let config;
    config = this.settingsService.getCompleteConfig();
    // this.googletagAvailable = this.localStorage.getItem('googletag')
    // this.googletagAvailable = this.commonService.checkGoogleTag();

    // if (config && config.ads && config.ads.web) {
    //   this.desktopTag = config.ads.web.livetv.desktop;
    //   this.mobileTag =  config.ads.web.livetv.mobile;
    // }

    if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i) || this.window.innerWidth <= 768) {
      this.touchScreen = true;
    }
    this.commonService.qgraphevent('LIVETVsection_visited', {'country': this.countryCode, 'state': this.localStorage.getItem('state_code')});
    this.filterbar = false;
    this.filterFlag = false;

    let network;
    network = this.networkService.getScreenStatus();
    if (network === true) {
      $('#loaderPage').css('display', 'block');
    }

    /* Google Analytics */
     this.pageName = 'live tv';
     this.gtm.sendPageName(this.pageName);
     this.gtm.sendEvent();
     this.gtm.storeWindowError();
     this.settingsService.bluekaiPagename('liveTv');


     this.window.scrollTo( 0, 0 );

     /*Route Params*/
     this.sub = this.route.params.takeUntil(this.ngUnsubscribe).subscribe(params => {
     this.id = params['id'];
     this.name = params['name'];
     this.watch = params['watch'];
     });

    /* Filter Titles */
    this.filter_titles = [{'code': '2', 'name': 'DETAILS.GENRE'}, {'code': '1', 'name': 'COMMON.LANGUAGE'}];
  }

  public openfilterNav(): void {
    this.filterbar = true;  /*Filter Open*/
  }

  public closeFilter(event): any {
    this.filterbar = false; /*Filter Close*/
  }

  private getServerTime() {
    let url;
    url = environment.serverTimeUrl;
    this.epgService.getcurrentTime(url).takeUntil(this.ngUnsubscribe).subscribe( value => {
      this.serverTime = new Date(value.serverdate);
      this.currentTime = this.serverTime.getTime();
      this.update();
    },
    err => {
      this.serverTime = new Date();
      this.currentTime = this.serverTime.getTime();
      this.update();
    });
  }

  // private googleAdCreation (slotName: any, id: any) {
  //   let scope;
  //   scope = this;
  //   this.googletagAvailable = this.commonService.checkGoogleTag();
  //   if (!this.premium && this.googletagAvailable === 'true' && this.desktopTag && this.mobileTag && this.desktopTag[id] && this.mobileTag[id] && id < Object.keys(this.desktopTag).length) {
  //     this.timer.push(setTimeout(function() {
  //       googletag = googletag || {};
  //       googletag.cmd = googletag.cmd || [];
  //       if (googletag.apiReady) {
  //         if (!scope.touchScreen && scope.desktopTag[scope.commonService.returnAdIndex(id, scope.desktopTag)].div_id && scope.desktopTag[scope.commonService.returnAdIndex(id, scope.desktopTag)].ad_tag) {
  //           googletag.cmd.push(function() {
  //             googletag.defineSlot(scope.desktopTag[scope.commonService.returnAdIndex(id, scope.desktopTag)].ad_tag, [[970, 66], [970, 90], [728, 90]], scope.desktopTag[scope.commonService.returnAdIndex(id, scope.desktopTag)].div_id + id).setCollapseEmptyDiv(true).addService(googletag.pubads());
  //             googletag.enableServices();
  //           });
  //           googletag.cmd.push(function() {
  //             googletag.display(scope.desktopTag[scope.commonService.returnAdIndex(id, scope.desktopTag)].div_id + id);
  //           });
  //         } else {
  //           googletag.cmd.push(function() {
  //           googletag.defineSlot(scope.mobileTag[scope.commonService.returnAdIndex(id, scope.mobileTag)].ad_tag, [320, 50], scope.mobileTag[scope.commonService.returnAdIndex(id, scope.mobileTag)].div_id + id).setCollapseEmptyDiv(true).addService(googletag.pubads());
  //           googletag.pubads().enableSingleRequest();
  //           googletag.enableServices();
  //           });
  //           googletag.cmd.push(function() {
  //             googletag.display(scope.mobileTag[scope.commonService.returnAdIndex(id, scope.mobileTag)].div_id + id);
  //           });
  //         }
  //       }
  //     }, 1000));
  //   }
  // }

  public update(): void {
    // this.googletagAvailable = this.localStorage.getItem('googletag')
    // this.googletagAvailable = this.commonService.checkGoogleTag();
    // if (this.googletagAvailable === 'true' && googletag.destroySlots) {
    //   googletag.destroySlots();
    //   this.commonService.count = 0;
    // }
    this.liveTvCategory = [];
    this.categories = this.filterService.getSelectedGenre();
    this.languages = this.filterService.getSelectedLanguage();
    this.genres = this.filterService.getChannelsGenre();

    const languages = this.filterService.getSelectedLanguage();
    this.languages = languages.join();
    window.scrollTo(0, 0);

    if (this.genres.length === 0) {
        let z;
        // z = new api.ChannelApi(this.http, null, null);
        z = new ChannelApi(this.http, null, null);
        this.countryCode = this.settingsService.getCountry();
        z.v1ChannelByIdGet('genres', undefined, this.countryCode).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
         let data;
         data = value;
         if (data.genres) {
           this.genresdata = [];
           this.genresdata = this.filterService.getIds(data.genres);
           this.filterService.setChannelsGenre(data.genres);
           this.filterCall();
         }
      }, error => {
        this.DATA = false;
        this.autoloaderDisable = true;
        $('#loaderPage').css('display', 'none');
        this.gtm.sendErrorEvent('api', error);
      });
    }

    if ( this.genres.length > 0) {
      let genresComp;
      genresComp = [];
      for ( let index = 0; index < this.genres.length; index++) {
        genresComp.push(this.genres[index].id);
      }
      this.genresdata = [];
      this.genresdata = genresComp.join(',');
      this.filterCall();
    }
  }

  private filterCall() {
    if ( this.categories.length > 0) {
      this.genresdata = [];
      this.genresdata = this.categories.join(',');
    }
    this.fetchCall();
  }

  private fetchCall() {
    this.genreObject = {};
    let translation;
    translation = this.filterService.gettranslation();

    let x;
    // x = new api.EpgApi(this.http, null, null);
    x = new EpgApi(this.http, null, null);
    let basePath, country;
    basePath = environment.catalogbasepath;
    country = this.settingsService.getCountry();
     let headers;
        headers = new Headers(); // https://github.com/angular/angular/issues/6845
         headers.append('X-Z5-AppPlatform', this.platform);
        headers.append('X-Z5-Appversion', this.version);
         const requestOptions: RequestOptionsArgs = new RequestOptions({
        method: RequestMethod.Get,
        headers: headers
    });
    this.http.request(environment.catalogbasepath + '/v1/channel/bygenre?sort_by_field=channel_number&genres=' + this.genresdata + '&languages=' + this.languages + '&country=' + country + '&translation=' + translation, requestOptions).timeout(environment.timeOut).takeUntil(this.ngUnsubscribe).subscribe(value => {

    this.liveTvValue = value.json();
    this.filterFlag = true;

    this.completeChannelList = []; /* Complete Channel List*/
    this.completeBusinesstypesList = [];
    let order;
    order = []; /* Order of the Genres*/
    this.tempData = [];  /* Order of the Genres*/
    this.filterCheck = [];

    // this.totalAds = Math.floor((this.liveTvValue.items.length - 3) / this.adSpacing) + 2;
    // this.divDesktop = 'div-gpt-ad-1521551569137-';
    // this.divMobile = 'div-gpt-ad-1521551617284-';
    // if (this.subscriptionService.checkPlanApiSuccess(false) && this.subscriptionService.checkPlanApiSuccess(false).length > 0) {
    //   this.premium = true;
    // }

    // for (let index1 = 0; index1 < this.totalAds; index1++) {
    //   this.googleAdCreation('', index1);
    // }

    for (let i = 0 ; i < this.liveTvValue.items.length ; i++) {
      if ( this.liveTvValue.items[i].items.length > 0) {
        order.push(this.liveTvValue.items[i].title);
        if (this.liveTvValue.items[i].title) {
          this.filterCheck.push(this.liveTvValue.items[i].title);
        }

        let idValueDesktop = '';
        let idValueMobile = '';
        if ((i - 2) % this.adSpacing === 0) {
          idValueDesktop = 'div-gpt-ad-1521551569137-' + ((i - 2) / this.adSpacing);
          idValueMobile = 'div-gpt-ad-1521551617284-' + ((i - 2) / this.adSpacing);
        }

        if (this.liveTvValue.items[i].id) {
          this.liveTvCategory.push({'adDesktop': idValueDesktop, 'adMobile': idValueMobile, 'title': this.liveTvValue.items[i].title,  'original_title': this.liveTvValue.items[i].id, 'type': 'livetv', 'content': ''});
        } else {
          this.liveTvCategory.push({'adDesktop': idValueDesktop, 'adMobile': idValueMobile, 'title': this.liveTvValue.items[i].title,  'original_title': '', 'type': 'livetv', 'content': ''});
        }
        this.genreObject[this.liveTvValue.items[i].title] = i;

        this.channelList = [];
        this.businessTypesList = [];
        for (let j = 0; j < this.liveTvValue.items[i].items.length ; j++) {
          this.channelList.push(this.liveTvValue.items[i].items[j].id);
          this.businessTypesList.push(this.liveTvValue.items[i].items[j].business_type);
        }

        let channelComma, businesstypesComma;
        channelComma = this.channelList.join(',');
        businesstypesComma = this.businessTypesList.join(',');
        this.completeChannelList.push(channelComma);
        this.completeBusinesstypesList.push(businesstypesComma);
      }

    }

    if (this.filterCheck.length === 0) {
      this.DATA = false;
      this.autoloaderDisable = true;
      $('#loaderPage').css('display', 'none');
    }

    if ( this.completeChannelList.length > 0) {
      for (let k = 0; k < this.completeChannelList.length; k++) {
        if (this.completeChannelList[k].length > 0) {
          this.countryCode = this.settingsService.getCountry();
            x.v1EpgNowGet(this.completeChannelList[k], undefined, undefined, undefined, this.countryCode).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe( value1 => {
             this.genreObject[order[k]] = k;
             this.tempData.push(value1);
             this.fetchData(order[k], order[k] , value1, this.completeBusinesstypesList[k]);
              },
              err => {
              this.gtm.sendErrorEvent('api', err);
            });
      } else {
        this.tempData.push('');
      }
    }
   }
 },
  err => {
    this.DATA = false;
    $('#loaderPage').css('display', 'none');
    });
  }

  private fetchData(genreId, genreValue, value, businessTypes): any {
    this.filter = true;
    let busi_type;
    busi_type = businessTypes.split(',');
    this.completeGrid = [];
    this.grid = [];

    if ( value.items.length > 0) {
      for (let j = 0; j < value.items.length; j++) {
        if ( value.items[j].items.length > 0) {
          this.startTime = Date.parse(value.items[j].items[0].start_time);
          this.elapsed = (this.currentTime - this.startTime);
          let elapsedTime;
          elapsedTime = (this.elapsed / 1000);
            if ( Math.floor((elapsedTime / (value.items[j].items[0].duration)) * 100) <= 100) {
              this.progress = Math.floor((elapsedTime / value.items[j].items[0].duration) * 100);
            }
            this.grid = { 'channel': value.items[j].title, 'channel_name': value.items[j].title, 'channel_original_title': value.items[j].original_title , 'channel_id': value.items[j].id, 'list_image': value.items[j].items[0].list_image , 'original_title': value.items[j].items[0].original_title, 'title': value.items[j].items[0].title, 'id': value.items[j].items[0].id, 'business_type': busi_type[j] , 'elapsed': this.elapsed, 'duration': value.items[j].items[0].duration, 'genres': value.items[j].genres, 'progress': this.progress, 'asset_type': 10};
            this.completeGrid.push(this.grid);
          } else {
            this.grid = { 'channel': value.items[j].title, 'channel_name': value.items[j].title, 'channel_original_title': value.items[j].original_title , 'channel_id': value.items[j].id, 'list_image': '', 'genres': value.items[j].genres, 'asset_type': 10, 'business_type': busi_type[j]};
            this.completeGrid.push(this.grid);
          }

        let idValueDesktop = '';
        let idValueMobile = '';
        if ((j - 2) % this.adSpacing === 0) {
          idValueDesktop = 'div-gpt-ad-1510134559746-' + ((j - 2) / this.adSpacing);
          idValueMobile = 'div-gpt-ad-1510134692841-' + ((j - 2) / this.adSpacing);
        }
      }

      let x;
      x = this.liveTvCategory[this.genreObject[genreId]].content = this.completeGrid;

      if ( this.liveTvCategory.length > 0 ) {
        this.DATA = true;

        if ( this.liveTvCategory.length === this.tempData.length) {
          this.liveTvCategory[0].content =  this.liveTvCategory[0].content;
          // this.liveTvCategory[0].content =  this.commonService.filterListData(this.liveTvCategory[0].content);
          this.contentUpdate = !this.contentUpdate;

          let scope;
          scope = this;
          setTimeout(function() {
            scope.getServerTime();
          }, 300000);

          $('#loaderPage').css('display', 'none');
          this.autoloaderDisable = true;
        }
      } else {
        this.DATA = false;
        $('#loaderPage').css('display', 'none');
      }
    } else {
       this.DATA = false;
       $('#loaderPage').css('display', 'none');
    }
  }

  public ngOnDestroy() {
    this.linkservice.removeCanonicalLink();
    this.destroyFilter.unsubscribe();  /*Filter Unsubscribe */
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
    // this.googletagAvailable = this.localStorage.getItem('googletag')
    // this.googletagAvailable = this.commonService.checkGoogleTag();
    //   if (this.googletagAvailable === 'true' && googletag.destroySlots) {
    //     googletag.destroySlots();

    //     // clear all timers in the array
    //     for (let i = 0; i < this.timer.length; i++) {
    //       clearTimeout(this.timer[i]);
    //     }
    //   }
    //   this.commonService.count = 0;
    }
  }

