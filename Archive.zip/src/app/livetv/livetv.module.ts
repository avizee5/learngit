import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared.module';
import { LivetvComponent } from './livetv.component';
import { FilterModule } from '../filter/filter.module';
import { ScrollListModule } from '../scroll-list/scroll-list.module';
import { DataUnavailableModule } from '../data-unavailable/data-unavailable.module';

const routes: Routes = [
    {
        path: '',
        component: LivetvComponent
    }
];
@NgModule({
  exports: [RouterModule],
  imports: [RouterModule.forChild(routes), CommonModule, SharedModule, DataUnavailableModule, ScrollListModule, FilterModule],
  declarations: [LivetvComponent]
})
export class LivetvModule {
}

