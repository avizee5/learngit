import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { UserApiService } from '../services/user-api.service';
import { SettingsService } from '../services/settings.service';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { environment } from '../../environments/environment';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { FilterService } from '../services/filter.service';
import { EpgService } from '../services/epg.service';
import { SubscriptionService } from '../services/subscription.service';
import { UseractionapiService } from '../services/useractionapi.service';
import { Router } from '@angular/router';
import { HeaderservicesService } from '../services/headerservices.service';
import { RequestMethod, RequestOptionsArgs } from '@angular/http';
import {PlayerEnhancementApi} from '../../data/gwapi_catalog/api/PlayerEnhancementApi';
import { VideoAnalyticsService } from '../services/video-analytics.service';
import * as SettingsApi from '../../data/user/api/api';
import { UserApi } from '../../data/user/api/api';
import * as $ from 'jquery';

declare let googletag;
declare let adblock;
declare const qg;

@Injectable()
export class CommonService {
  public image_url: any;
  public basepath: any;
  public token: any;
  public genres: any;
  public config: any;
  public data: any;
  public subtitle: any;
  public months: any = ['Jan', 'Feb', 'Mar',
  'Apr', 'May', 'Jun', 'Jul',
  'Aug', 'Sep', 'Oct',
  'Nov', 'Dec'
  ];
  public categoryList: any;
  public plans: any;
  public premiumUser: any = false;
  public localstorage: any;
  public window: any;
  public document: any;
  public navigator: any;
  public countryCode: any;
  public tagLabels: any;
  public server_time: any;
  public carouselLabels: any;
  public count: any = 0;
  public mobile = false;
  public mobile1 = false;
  public serverUrl: any = environment.serverTimeUrl;
  public categoryArray: any = [];
  public display_lang: any = 'en';
  // public nativeAdTags: any;
  // public desktopTag: any;
  // public divId: any;
  public tagValue: any;
  public searchMode: any;
  public searchType: any;
  public searchTotal: any;
  public searchQuery: any;
  public cardType: any;
  public qgraph: any;
  public showVideo = new Subject<any>();
  public serverTime = new Subject<any>();
  public carouselDesktopTag: any;
  public isNewsPage: any = false;
      public sendLanguagesValue = new Subject<any>();
public returnsendLanguages: any = false;
  public adsData: any;
  public collectionID: any;
  public talamoosData: any;
  public notAvailable: any = 'NA';
  public videoDuration: any;
  public nowtv: any;
  public nowTvDomain: any;
  constructor(private videoAnalyticsService: VideoAnalyticsService, private headerservicesService: HeaderservicesService, private userAction: UseractionapiService, private router: Router, private subscriptionService: SubscriptionService , private epgService: EpgService, @Inject(PLATFORM_ID) private platformId: Object, private gtm: GoogleAnalyticsService, private userapiService: UserApiService, private settingsService: SettingsService, private filterService: FilterService, private http: Http) {
    if (isPlatformBrowser(this.platformId)) {
      this.localstorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
    this.talamoosData = {
      'modelName': this.notAvailable,
      'clickID': this.notAvailable,
      'origin': this.notAvailable,
      'CarousalCategory': 'Non-Talamoos'
    };
    this.updateConfigValue();
  }
  public setNowTvDetails(state: any = false, params, ) {
    this.nowtv = {};
    this.nowtv['isTrue'] = state;
    this.nowtv['params'] = params;
    if (state && params) {
      this.nowtv.nowTvDetails = {
        campaignData : {
          'devicename': params.GetFriendlyName || '',
          'identifier': params.ClintChannelID || '',
          'model': params.Model || '',
          'modelversion': params.Version || '',
          'modeldisplayname': params.GetModelDisplayName || '',
          'modeltype': params.GetModelType || '',
          'modelnumber': params.ModelNumber || '',
          'vendorname': params.VendorName || '',
          'platformname': params.PlatformName || '',
          'appversion': params.AppVersion || ''
        }
      };
    } else if (state) {
      this.nowtv.nowTvDetails = {
        campaignData : {
          'platformname': 'NowTV'
        }
      };
    } else {
      this.nowtv.nowTvDetails = {};
    }
    // console.log('commonService - nowtv', this.nowtv);
  }
  public setNowTvDomain(): any {
    let windowLocation;
    windowLocation = window.location;
    if (windowLocation.origin === environment.nowTvbasePath) {
      this.nowTvDomain = true;
    } else {
      this.nowTvDomain = false;
    }
  }
  public getNowTvDomain(): any {
      return this.nowTvDomain;
  }

  public sendLanguages(a: any): any {                                        // for loginregister and user icon chnages on value
    this.returnsendLanguages = a;
    this.sendLanguagesValue.next(this.returnsendLanguages);
    return this.returnsendLanguages;
  }
  public getLanguagesValue(): any {
    return this.returnsendLanguages;
  }
  public updateConfigValue() {
    this.config = this.settingsService.getCompleteConfig();
    this.categoryList = this.config ? this.config.tags : [];
    this.display_lang = this.filterService.gettranslation();
    this.tagLabels =  this.config ? this.config.tags_labels : {};
    this.carouselLabels = this.config ? this.config.carousels_labels : {};
    this.tagValue = this.config;
    if (this.categoryList) {
      for (let index = 0 ; index < this.categoryList.length; index++) {
        this.categoryArray.push(this.categoryList[index].tag_name.toLowerCase());
      }
    }
  }
  public convertToLowercase(value: any) {
    let show_title;
    if (value) {

      show_title = value.toLowerCase().replace(/ /g, '-');
      show_title = show_title.replace(/---/g, '-');
      show_title = show_title.replace(/,/g, '');
      // show_title = show_title.replace(/[()]/g, '')
      // show_title = show_title.replace(/[^\w\s]/gi, '')
      show_title = show_title.replace(/&/g, 'and');
      show_title = show_title.replace(/[��`~!@#$%^&*()|+\=?;:'�",.<>\{\}\[\]/]/gi, '');
      show_title = show_title.replace(/[^\011\012\015\040-\177]/gi, '');
      // show_title = show_title.replace(/�/g, '');
      // show_title = show_title.replace(/�/g, '');
      // show_title = show_title.replace(/�/g, '');

      show_title = show_title.replace(/--/g, '-');

      //  harlie�s-an
    } else {
      show_title = 'title';
    }
    return show_title;
  }
  public assignType (data: any) {
    if (data && data.tags && data.tags[0] === 'movies') {
      this.cardType = 'movies';
    } else if (data && data.tags &&  data.tags[0] === 'tvshows') {
      this.cardType = 'tvshows';

    } else if (data && data.tags &&  data.tags[0] === 'originals') {
      this.cardType = 'zee5originals';

    } else if (data && data.tags &&  data.tags[0] === 'videos') {
      this.cardType = 'videos';
    } else  {
      this.cardType = 'tvshows';
    }
    return this.cardType;
  }
  // public filterListData(data: any): any {
  //   this.tagValue = this.config ? this.config : this.settingsService.getCompleteConfig();
  //  this.desktopTag = undefined;
  //   this.divId = undefined;
  //   if (this.count === 0 && !this.premiumUser && this.tagValue) {
  //    this.plans = this.subscriptionService.checkPlanApiSuccess(false);
  //     if (this.plans && this.plans.length > 0) {
  //       this.premiumUser = true;
  //     } else {
  //       if (!this.mobile && (this.router.url.match(/tvshows/g)) && this.tagValue && this.tagValue.native_ads && this.tagValue.native_ads.web && this.tagValue.native_ads.web['desktop'] && this.tagValue.native_ads.web['desktop'].tvshows && this.tagValue.native_ads.web['desktop'].tvshows[0]) {
  //         this.desktopTag = this.tagValue.native_ads.web['desktop'].tvshows[0].ad_tag;
  //         this.divId = this.tagValue.native_ads.web['desktop'].tvshows[0].div_id;
  //       } else if (!this.mobile && (this.router.url.match(/movies/g)) && this.tagValue && this.tagValue.native_ads && this.tagValue.native_ads.web && this.tagValue.native_ads.web['desktop'] && this.tagValue.native_ads.web['desktop'].movies && this.tagValue.native_ads.web['desktop'].movies[0]) {
  //         this.desktopTag = this.tagValue.native_ads.web['desktop'].movies[0].ad_tag;
  //         this.divId = this.tagValue.native_ads.web['desktop'].movies[0].div_id;
  //       } else if (!this.mobile && (this.router.url.match(/videos/g)) &&  this.tagValue && this.tagValue.native_ads && this.tagValue.native_ads.web && this.tagValue.native_ads.web['desktop'] && this.tagValue.native_ads.web['desktop'].videos && this.tagValue.native_ads.web['desktop'].videos[0]) {
  //         this.desktopTag = this.tagValue.native_ads.web['desktop'].videos[0].ad_tag;
  //         this.divId = this.tagValue.native_ads.web['desktop'].videos[0].div_id;
  //       } else if (!this.mobile && (this.router.url.match(/news/g)) &&  this.tagValue && this.tagValue.native_ads && this.tagValue.native_ads.web && this.tagValue.native_ads.web['desktop'] && this.tagValue.native_ads.web['desktop'].news && this.tagValue.native_ads.web['desktop'].news[0]) {
  //         this.desktopTag = this.tagValue.native_ads.web['desktop'].news[0].ad_tag;
  //         this.divId = this.tagValue.native_ads.web['desktop'].news[0].div_id;
  //       } else if (!this.mobile && (this.router.url === '/') && this.tagValue && this.tagValue.native_ads && this.tagValue.native_ads.web && this.tagValue.native_ads.web['desktop'] && this.tagValue.native_ads.web['desktop'].home && this.tagValue.native_ads.web['desktop'].home[0]) {
  //         this.desktopTag = this.tagValue.native_ads.web['desktop'].home[0].ad_tag;
  //         this.divId = this.tagValue.native_ads.web['desktop'].home[0].div_id;
  //       } else if (!this.mobile && (this.router.url.match(/livetv/g)) && this.tagValue && this.tagValue.native_ads && this.tagValue.native_ads.web && this.tagValue.native_ads.web['desktop'] && this.tagValue.native_ads.web['desktop'].livetv && this.tagValue.native_ads.web['desktop'].livetv[0]) {
  //         this.desktopTag = this.tagValue.native_ads.web['desktop'].livetv[0].ad_tag;
  //         this.divId = this.tagValue.native_ads.web['desktop'].livetv[0].div_id;
  //       }
  //       if (this.desktopTag && this.divId) {
  //         data.splice(1 , 0, {'type': 'advertisement', 'tag': this.desktopTag , 'divId': this.divId});
  //       }
  //     }
  //   }
  //   this.count++;
  //   return data;
  // }
  public setSearchValues(search_mode: any, searchType: any) {
    this.searchMode = search_mode;
    this.searchType = searchType;
  }
  public setSearchResults(search_mode: any, searchType: any, searchTotal: any, query: any) {
    this.searchMode = search_mode ? search_mode : 'Text Search';
    this.searchType = searchType ? searchType : 'manual';
    this.searchTotal = searchTotal;
    this.searchQuery = query;
  }
  public sendSearchClickEvent (clickContent) {
    // this.gtm.logEvent({'event': 'searchResultClick',
    //   'refScreen': this.gtm.getPreviousPageName(),
    //   'search_mode': this.searchMode,
    //   'searchType': this.searchType,
    //   'searchResult': this.searchTotal,
    //   'SearchQuery': this.searchQuery,
    //   'G_ID': this.gtm.fetchToken(),
    //   'Client_ID': this.gtm.fetchClientId(),
    //   'retargeting_remarketing' : this.gtm.fetchMarketing(),
    //   'TimeHHMMSS': this.gtm.fetchCurrentTime(),
    //   'DateTimeStamp': this.gtm.fetchCurrentDate(),
    // });
    this.gtm.sendEventDetails({'event': 'searchResultClick', 'SearchQuery': this.searchQuery, 'Click_Content': clickContent ? clickContent : 'NA'});
  }
  // getSearchValue () {
  //   return {'search_mode': this.searchMode, 'search_type': this.searchType}
  // }
  public getDefaultSub(type: any, subtype: any) {
    let subtitle_main;
    if (type === 0) {
      subtitle_main = (subtype === 'movie' ? 'MENU.MOVIES' : (subtype === 'video' ? 'MENU.VIDEOS' : this.getCategoryConfig(subtype)));
    } else if (type === 6) {
      subtitle_main = (subtype === 'original' ? 'MENU.ORIGINALS' : 'MENU.TVSHOWS');
    } else if (type === 9) {
      subtitle_main = 'HOME.CHANNEL';
    } else if (type === 1) {
      subtitle_main = (subtype === 'episode' ? 'DETAILS.EPISODES' : this.getCategoryConfig(subtype));
    }  else {
      subtitle_main = '';
    }
    return subtitle_main;
  }

  public getCategoryConfig(subtype: any) {
    let output;
    if (this.carouselLabels[subtype]) {
      output = this.carouselLabels[subtype][this.display_lang];
    } else {
      output = subtype;
    }
    return output;
  }
  public getSubcategory(tags: any, type: any, subtype: any, genres: any, content_owner: any) {
    this.updateConfigValue();
    let index, tagList, tagsValue;
    tagList = [];
    // if (subtype === 'video' && genres && genres.findIndex(i => i.id === 'News') !== -1) {
    //   let tag;
    //   tag = content_owner || this.getDefaultSub(type, subtype) || null;
    //   tagList.push(tag);
    // } else {
      if (subtype === 'video' && genres && genres.findIndex(i => i.id === 'News') !== -1 && content_owner) {
        tagList.push(content_owner);
      } else if (tags && tags.length > 0 && this.categoryList) {
        for (index = 0; index < tags.length ; index++ ) {
          tagsValue = tags[index].toLowerCase();
          if (this.categoryArray.indexOf(tagsValue) !== -1) {
            tagList.push(this.tagLabels[this.categoryList[this.categoryArray.indexOf(tagsValue)].tag_id][this.display_lang]);
          }
          if (tagList.length === 1) {
            break;
          }
        }
      } else {
        tagList.push(this.getDefaultSub(type, subtype));
      }
    // }
    if (tagList.length === 0) {
      tagList.push(this.getDefaultSub(type, subtype));
    }
    return tagList;
  }
  public restrictLength(value) {
    let new_value = [];
    if ( value && value.length > 20) {
      new_value = value.slice(0, 20);
      return new_value;
    } else {
      return value;
    }
  }
  public getcarouselDesktopTag(): void {
    return this.carouselDesktopTag;
  }
  public setcarouselDesktopTag(value: any): void {
    this.carouselDesktopTag = value;
  }
  // Showing Live card elapsed time
  public updateLiveTime(s: number): any {
    /* Convert millisecs to hours+mins+secs */
    let secs, mins, hrs, hrsStr, time;
    secs = (s / 1000) % 60;
    s = ((s / 1000) - secs) / 60;
    mins = s % 60;
    s = (s - mins) / 60;
    hrs = s % 60;
    secs = Math.floor(secs);
    hrsStr = hrs ? ((hrs < 10 ? '0' + hrs : hrs) + ':') : '';
    time = (hrs ? hrs + 'h' : '') + ' ' + (mins ? mins + 'm' : '') + ' ' + (secs ? secs + 's' : '');
    return time;
  }
  //  displays toast message on no video available
  public videoError() {
    let p;
    p = document.getElementById('snackbar');
    p.className = 'show';
    setTimeout(function() { p.className = p.className.replace('show', ''); }, 3000);
  }
  public updateTimeGrid(s: number): any {
      // convert seconds to hrs and minutes
      let secs, mins, hrs, hrsStr, mins_new, time;
      secs = s % 60;
      s = (s - secs) / 60;
      mins = s % 60;
      s = (s - mins) / 60;
      hrs = s % 60;
      hrsStr = hrs ? ((hrs < 10 ? '0' + hrs : hrs) + ':') : '';
      if (mins < 10) {
        mins_new = '0' + mins;
      } else {
        mins_new = '' + mins;
      }

      time = (hrs ? hrs + 'h' : '') + ' ' + (mins ? mins_new + 'm' : '') + ' ' + (secs ? secs + 's' : '');
      return time;
    }
    public updateGMTime(UTC): any {
      let x, time;
      x = new Date(UTC);
      if ( x.getMinutes() < 9 ) {
        time = x.getHours() + ':' + '0' + x.getMinutes();
      } else {
        time = x.getHours() + ':' + x.getMinutes();
      }
      return time;
    }
    public dateChange(value) {
      if (value) {
        let date;
        let day, monthIndex, year;
        date = new Date(value);
        day = date.getDate();
        monthIndex = date.getMonth();
        year = date.getFullYear();
        return (day + ' ' + this.months[monthIndex]  + ', ' + year) ;
      } else {
        return '';
      }
    }
    public getServertime() {
      return this.server_time;
    }
    public setServertime(value: any) {
      this.server_time = value;
      this.serverTime.next(this.server_time.getTime());
    }
    public updateTime() {
      this.epgService.getcurrentTime(this.serverUrl).subscribe( value => {
        this.server_time = new Date(value.serverdate);
        this.serverTime.next(this.server_time.getTime());
      },
      err => {
        this.server_time = new Date();
        this.serverTime.next(this.server_time.getTime());
      });
    }
    public setMode(flag: any) {
      this.mobile1 = flag;
    }
    public getMode() {
      return this.mobile1;
    }

    public returnAdIndex(index: any, arrayList: any) {
      let length;
      length = Object.keys(arrayList).length;
      if (length <= 1) {
        return 0;
      } else if (length > 1) {
        if (index === 0) {
          return index;
        } else {
          return (index - (Math.floor((index - 1) / (length - 1)) * (length - 1)));
        }
      }
    }

    public getEpisodeUrl(date: any, tvshow_title: any, episodeInfo: any, dimension) {
      this.basepath = this.settingsService.getbasePath();
      if (date && tvshow_title) {
        tvshow_title = tvshow_title.replace(/ /g, '_');
        let new_date, date_formatted, day, hrs, dayUpdate, month;
        new_date = new Date(date);
        day = new_date.getDate();
        hrs = new_date.getMonth() + 1;
        dayUpdate = day ? ((day < 10 ? '0' + day : day)) : '';
        month = hrs ? ((hrs < 10 ? '0' + hrs : hrs)) : '';
        date_formatted = dayUpdate.toString() + month.toString() + new_date.getFullYear().toString();
        let a, b, inRange;
        a = new Date(2015, 0, 15);
        b = new Date(2017, 9, 15);
        inRange = new_date >= a && new_date <= b;
        if (inRange) {
          this.image_url =  'https://akamaividz1.zee5.com/resources/episode-images/' + tvshow_title + '_Episode_' + date_formatted + '_574x358.jpg' +  '?imwidth=270&impolicy=akamai_vidz1_zee5_com-IPM';
        } else {
          this.image_url = this.basepath + episodeInfo.id + '/list/' + dimension + episodeInfo.list_image;

        }
      } else {
        this.image_url = this.basepath + episodeInfo.id + '/list/' + dimension + episodeInfo.list_image;
      }
      return this.image_url;
    }
    public refreshToken (): Promise<any> {
      let promise, gwapi_token;
       promise = new Promise((resolve, reject) => {
        this.userAction.gettoken().subscribe(value => {
           gwapi_token = value.json();
          this.localstorage.setItem( 'xacesstoken', gwapi_token.token);
          resolve();
        },
        err => {
          reject();
        });
      });
      return promise;
    }

    public checkGoogleTag(): any {
      let googletagAvailable;
      if (this.window && this.window.googletag) {
        if (this.window.adblock === false) {
          localStorage.setItem('googletag', 'true');
          googletagAvailable = 'true';
        } else {
          localStorage.setItem('googletag', 'false');
          googletagAvailable = 'false';
        }
        return googletagAvailable;
      } else {
        localStorage.setItem('googletag', 'false');
        googletagAvailable = 'false';
        return googletagAvailable;
      }
    }

    public checkAdFoxTag(): any {
      let adFoxtagAvailable;
      if (this.window && this.window.Ya && this.window.Ya.adfoxCode) {
      // if (this.window && this.window.adfox_156456424988369489) {
        if (this.window.adblock === false) {
          adFoxtagAvailable = 'true';
        } else {
          adFoxtagAvailable = 'false';
        }
        return adFoxtagAvailable;
      } else {
        return adFoxtagAvailable;
      }
    }

    public nextData(url): Observable<any> {
      let token, headers;
      token = this.localstorage.getItem('xacesstoken');
      headers = new Headers();
      headers.append('X-ACCESS-TOKEN', token);
      const requestOptions: RequestOptionsArgs = new RequestOptions({
          method: RequestMethod.Get,
          headers: headers
      });
      return this.http.request(url, requestOptions)
      .map(this.extractData)
      .catch(this.handleErrorObservable);
    }
    private extractData(res: Response) {
      let body;
      body = res.json();
      return body || {};
    }
    private handleErrorObservable (error: Response | any) {
      return Observable.throw(error.message || error);
    }
    public qgraphevent(eventname, object) {
      // console.log(object, " " + eventname + " qgraph");
      this.qgraph =  this.headerservicesService.getRemarketing();
      if (this.window.qg) {
        // if (this.qgraph) {
        //   delete object.country;
        //   delete object.state;
        //   qg('event', eventname, object);
        // } else {
          qg('event', eventname, object);
        // }
      }
    }
    public authDevice(url?: string , code?: any): Observable<any> {
      const input = new FormData();
      let token, headers;

      token = 'bearer ' + this.localstorage.getItem('token');
      input.append('device_code', code);
      input.append('authorization', token);
      headers = new Headers();
      headers.append('Accept', 'application/json');
      // headers.append('Authorization', token);
      const requestOptions: RequestOptionsArgs = new RequestOptions({
          method: RequestMethod.Post,
          headers: headers
      });
      return this.http.post(url, input, requestOptions)
      .map((response: Response) => {
                if (response.status === 404) {
                    return undefined;
                } else {
                    return response.json() || {};
                }
        })
      .catch(this.handleErrorObservable);
      }

      public setNewsPage(value: boolean) {
        this.isNewsPage = value;

      }
      public getNewsPage() {
        return this.isNewsPage;
      }
      public getAdsApiData(url): Observable<any> {
        let item;
        item = url;
        return this.http.get(item)
        .map(this.extractData)
        .catch(this.handleErrorObservable);
      }
      public setAdsValue(value) {
        // this.adsData = value;
        this.adsData = {};
      }
      public getAdsValue() {
        return this.adsData;
      }
      public getAdType(adType): any {
        if (!adType) {
          return;
        } else if (adType === 'fluid') {
          return 'block';
        } else if (adType === 'fixed') {
          return 'table';
        } else {
          return;
        }
      }
      private defineAdSlot(response): void {
        let slot, notAvailable;
        notAvailable = 'NA';
        slot = googletag.defineSlot(response.ad_tag, response.ad_dimension, response.div_id);
        if (response.ad_targeting) {
          for (let i = 0; i < response.ad_targeting.length; ++i) {
            // if (Array.isArray(response.ad_targeting[i].value)) {
            //   response.ad_targeting[i].value = response.ad_targeting[i].value.join(',');
            // }
            slot.setTargeting(response.ad_targeting[i].key, (response.ad_targeting[i].value || notAvailable));
          }
        }
        return slot.setCollapseEmptyDiv(true).addService(googletag.pubads());
      }
      public getPostSubscriptionRoute(id, prevPage) {
      $('#loaderPage').css('display', 'block');
        if (prevPage === 'login') {
          this.localstorage.setItem('postSubscriptionRoute', id);
          let userBearer, config, userSettings;
          userBearer = 'bearer ' + this.localstorage.getItem('token');
          config = {
          apiKey: userBearer,
          username: ' ',
          password: ' ',
          accessToken: ' ',
          withCredentials: false
          };
          userSettings = new SettingsApi.SettingsApi(this.http, null, config);
          userSettings.v1SettingsGet().subscribe(response => {
            if ( response.length > 0) {
              for (let i = 0; i < response.length; i++) {
                if ( response[i].key === 'content_language') {
                  this.localstorage.setItem('UserContentLanguage', response[i].value);
                }
                if ( response[i].key === 'display_language') {
                  this.localstorage.setItem('UserDisplayLanguage', response[i].value);
                }
              }
            }
            this.subscriptionService.getServerTimeActive(true, false); // call my plan api
          });
        } else {
          this.playerRoute(id, prevPage);
        }
      }

      // public playerRoute(id, prevPage): any {
      //   let api, config, country_code, limit, page, userType, loginType, twitterTime, prevRoute;
      //   loginType = this.localstorage.getItem('login');
      //   config = {
      //     apiKey: ' ',
      //     username: ' ',
      //     password: ' ',
      //     accessToken: ' ',
      //     withCredentials: false
      //   };
      //   api = new PlayerEnhancementApi(this.http, null, config);
      //   country_code = this.localstorage.getItem('country_code');
      //   limit = 25;
      //   page = 1;
      //   // userType = this.videoAnalyticsService.getAccessType().toLowerCase();
      //   // userType = (userType === 'authenticated') ? 'registered' : userType;
      //   userType =  this.getUserType();
      //   prevRoute = (prevPage === 'subscribe') ? this.localstorage.getItem('subscriptionRoute') : (prevPage === 'popup') ? '' : this.localstorage.getItem('previousRoute');
      //   api.v1PlayerCollectionGet(id, null, null, country_code, userType, null, limit, null, null).timeout(environment.timeOut).subscribe(value => {
      //     if (value && value.items && value.items[0]) {
      //       this.commonRouteFunction(value.items[0], prevPage);
      //     } else {
      //       if (prevRoute === '') {
      //         // if (prevPage !== 'popup') {
      //         //   $('#loaderPage').css('display', 'block');
      //         // }
      //         $('#loaderPage').css('display', 'none');
      //         return;
      //       } else if ((prevPage === 'register' || prevPage === 'login') && loginType === 'twitter') {
      //         twitterTime = this.localstorage.getItem('twitterTime');
      //         this.window.location.href = environment.twitterLogout + prevRoute + '&ver=' + twitterTime;
      //       } else {
      //         this.window.location.href = this.window.location.origin + this.routeservice.getBaseLocation() + prevRoute;
      //       }
      //     }
      //   },
      //   err => {
      //       if (prevRoute === '') {
      //         // if (prevPage !== 'popup') {
      //         //   $('#loaderPage').css('display', 'block');
      //         // }
      //         $('#loaderPage').css('display', 'none');
      //         return;
      //       } else if ((prevPage === 'register' || prevPage === 'login') && loginType === 'twitter') {
      //         twitterTime = this.localstorage.getItem('twitterTime');
      //         this.window.location.href = environment.twitterLogout + prevRoute + '&ver=' + twitterTime;
      //       } else {
      //         this.window.location.href = this.window.location.origin + this.routeservice.getBaseLocation()  + prevRoute;
      //       }
      //   });
      // }

      public playerRoute(id, prevPage): any {
        let loginType, twitterTime, prevRoute;
        loginType = this.localstorage.getItem('login');
        prevRoute = (prevPage === 'subscribe') ? this.localstorage.getItem('subscriptionRoute') : (prevPage === 'popup') ? '' : this.localstorage.getItem('previousRoute');
        this.getAutoPlayData(id, null).timeout(environment.timeOut).subscribe(value => {
          if (value && value.items && value.items[0]) {
            this.commonRouteFunction(value.items[0], prevPage);
          } else {
            if (prevRoute === '') {
              $('#loaderPage').css('display', 'none');
              return;
            } else if ((prevPage === 'register' || prevPage === 'login') && loginType === 'twitter') {
              twitterTime = this.localstorage.getItem('twitterTime');
              this.window.location.href = environment.twitterLogout + this.getBaseLocation() + prevRoute + '&ver=' + twitterTime;
            } else {
              this.window.location.href = this.window.location.origin + this.getBaseLocation() + prevRoute;
            }
          }
        },
        err => {
            if (prevRoute === '') {
              $('#loaderPage').css('display', 'none');
              return;
            } else if ((prevPage === 'register' || prevPage === 'login') && loginType === 'twitter') {
              twitterTime = this.localstorage.getItem('twitterTime');
              this.window.location.href = environment.twitterLogout + this.getBaseLocation() + prevRoute + '&ver=' + twitterTime;
            } else {
              this.window.location.href = this.window.location.origin + this.getBaseLocation() + prevRoute;
            }
        });
      }

      public updateCollectionId(id): any {
        if (id && id.indexOf('0-8-') >= 0) {
          this.collectionID = id;
        } else {
          this.collectionID = null;
        }
      }

      public getCollectionId(): any {
        return this.collectionID;
      }

      public getAutoPlayData(id, collection_id): any {
        let api, config, country_code, limit, page, userType, content_id, parent_id;
        id = JSON.parse(id);
        content_id = id.id;
        parent_id = id.extra;
        config = {
          apiKey: ' ',
          username: ' ',
          password: ' ',
          accessToken: ' ',
          withCredentials: false
        };
        api = new PlayerEnhancementApi(this.http, null, config);
        country_code = this.localstorage.getItem('country_code');
        limit = 25;
        page = 1;
        userType =  this.getUserType();
        return api.v1PlayerCollectionGet(content_id, this.collectionID, null, country_code, userType, null, limit, null, parent_id);
        // return api.v1PlayerCollectionGet(id, collection_id, null, country_code, userType, null, limit, null, null);
      }

      public commonRouteFunction(value, prevPage) {
        let tempTitle, loginType, twitterTime, routeUrl, prevRoute;
        loginType = this.localstorage.getItem('login');
        // prevRoute = (prevPage === 'subscribe') ? this.localstorage.getItem('subscriptionRoute') : this.localstorage.getItem('previousRoute');
        prevRoute = (prevPage === 'subscribe') ? this.localstorage.getItem('subscriptionRoute') : (prevPage === 'popup') ? '' : this.localstorage.getItem('previousRoute');
        // if (value && value.extended && value.extended.seo_title) {
        //   tempTitle = (value.extended.seo_title !== null || value.extended.seo_title !== undefined || value.extended.seo_title !== '') ? value.extended.seo_title : value.original_title;
        // } else {
        //   tempTitle = (value.seo_title && (value.seo_title !== null || value.seo_title !== undefined || value.seo_title !== '')) ? value.seo_title : value.original_title;
        // }
        tempTitle = value.original_title;
        if (value.asset_type === 0 ) {
          if (value.asset_subtype === 'movie') {
            routeUrl = '/movies/details' + '/' + this.convertToLowercase(tempTitle) + '/' + value.id;
          } else if (value.asset_subtype === 'video' && value.genres.findIndex(i => i.id === 'News') !== -1) {
            routeUrl = '/news/details' + '/' + this.convertToLowercase(tempTitle) + '/' + value.id;
          } else {
            routeUrl = '/videos/details' + '/' + this.convertToLowercase(tempTitle) + '/' + value.id;
          }
        } else if (value.asset_type === 6 ) {
          routeUrl = '/' + (value.asset_subtype === 'original' ? 'zee5originals' : 'tvshows') + '/details' + '/' + this.convertToLowercase(tempTitle) + '/' + value.id;
        } else if (value.asset_type === 1) {
          routeUrl = '/' + (value.asset_subtype === 'original' ? 'zee5originals' : 'tvshows') + '/details' + '/' + this.convertToLowercase(value.tvshow_details.original_title)  + '/' + value.tvshow_details.id + '/' +  this.convertToLowercase(tempTitle) + '/' + value.id;
        } else {
          routeUrl = prevRoute;
        }
        if (routeUrl === '') {
          // if (prevPage !== 'popup') {
          //   $('#loaderPage').css('display', 'block');
          // }
          $('#loaderPage').css('display', 'none');
          return;
        } else if ((prevPage === 'register' || prevPage === 'login') && loginType === 'twitter') {
          twitterTime = this.localstorage.getItem('twitterTime');
          this.window.location.href = environment.twitterLogout + this.getBaseLocation() + routeUrl + '&ver=' + twitterTime;
        } else {
          this.window.location.href = this.window.location.origin + this.getBaseLocation() + routeUrl;
        }
      }

    public getBaseLocation(): any {
      let token;
      token = localStorage.getItem('token');
      if (token) {
      // searchItem = this.localStorage.getItem('UserDisplayLanguage')
      if (localStorage.getItem('UserDisplayLanguage') !== 'en') {
        return '/' + localStorage.getItem('UserDisplayLanguage');
      } else {
        return '';
      }

    } else {
        // searchItem = this.localStorage.getItem('display_language')
        if (localStorage.getItem('display_language') !== 'en') {
          return '/' + localStorage.getItem('display_language');
        } else {
          return '';
        }
      }
    }

      /*
        Function returns user type
      */
      public getUserType(): any {
        let token, subscription;
        token = this.localstorage.getItem('token');
        subscription = this.subscriptionService.getActiveAssestType();
        if (token) {
          if (subscription && subscription.length > 0) {
            return 'premium';
          } else {
            return 'register';
          }
        } else {
          return 'guest';
        }
      }


      public removeWebView(data) {
        let dub_data;
        dub_data = data;
        if (data) {
          for ( let i = 0; i < data.length; i++) {
            if (data[i] && data[i].items) {
                for ( let j = 0 ; j < data[i].items.length; j++) {
                  if (data[i].items[j] && data[i].items[j].tags && data[i].items[j].genres && data[i].items[j].genres[0] && data[i].items[j].genres[0].id === 'web_view' && data[i].items[j].tags.indexOf('no_web') >= 0) {
                    dub_data[i].items.splice(j, 1);
                  }
                  if (data[i].items[j] && data[i].items[j].genres && data[i].items[j].genres[0] && data[i].items[j].genres[0].id === 'sdk_userinfo' ) {
                    dub_data[i].items.splice(j, 1);
                  }
            }
         }
          }
        }
        // }
        return dub_data;
      }

      public removeWebViewItems(data) {
        let dub_data;
        dub_data = data;
        if (data) {
          for (let i = 0; i < data.length; i++) {
              if (data[i] && data[i].tags && data[i].genres && data[i].genres[0] && data[i].genres[0].id === 'web_view' && (data[i].tags.indexOf('no_web') >= 0)) {
                dub_data.splice(i, 1);
              }
              if (data[i] && data[i].genres && data[i].genres[0] && data[i].genres[0].id === 'sdk_userinfo' ) {
                dub_data.splice(i, 1);
              }
          }
        return dub_data;

        }
      }
  public changeContent(content): any {
    let tempTitle;
    // if (content.extended && content.extended.seo_title) {
    //   tempTitle = (content.extended.seo_title !== null || content.extended.seo_title !== undefined || content.extended.seo_title !== '') ? content.extended.seo_title : content.original_title;
    // } else {
    //   tempTitle = (content.seo_title && (content.seo_title !== null || content.seo_title !== undefined || content.seo_title !== '')) ? content.seo_title : content.original_title;
    // }
    tempTitle = content.original_title;
    if (content.asset_type === 0) {
      this.router.navigate([(content.asset_subtype === 'movie' ? 'movies' : ((content.asset_subtype === 'video' && content.genres.findIndex(i => i.id === 'News') !== -1) ? 'news' : 'videos')) + '/details/' , this.convertToLowercase(tempTitle) , content.id ]);
    } else if (content.asset_type === 6) {
      this.router.navigate([(content.asset_subtype === 'original' ? 'zee5originals' : 'tvshows') + '/details/' , this.convertToLowercase(tempTitle), content.id, 'latest'  ]);
    } else if (content.asset_type === 1 && content.tvshow_details ) {
      let tempTvTitle;
      // if (content.tvshow_details && content.tvshow_details.extended && content.tvshow_details.extended.seo_title) {
      //   tempTvTitle = (content.tvshow_details.extended.seo_title !== null || content.tvshow_details.extended.seo_title !== undefined || content.tvshow_details.extended.seo_title !== '') ? content.tvshow_details.extended.seo_title : content.tvshow_details.original_title;
      // } else {
      //   tempTvTitle =  (content.tvshow_details.seo_title && (content.tvshow_details.seo_title !== null || content.tvshow.seo_title !== undefined || content.tvshow_details.seo_title !== '')) ? content.tvshow_details.seo_title : content.tvshow_details.original_title;
      // }
      tempTvTitle = content.tvshow_details.original_title;
      this.router.navigate([(content.tvshow_details.asset_subtype === 'original' ? 'zee5originals' : 'tvshows') + '/details/' , this.convertToLowercase(tempTvTitle) , content.tvshow_details.id, this.convertToLowercase(tempTitle) , content.id ]);
    } else {
      this.videoError();
    }
  }

  public setTalamoosData(modelName: any, clickID: any, featureType: any): any {
    this.talamoosData = {
      'modelName': modelName || this.notAvailable,
      'clickID': clickID || this.notAvailable,
      'origin': featureType || this.notAvailable,
      'CarousalCategory': (modelName && modelName !== 'NA') ? 'Talamoos' : 'Non-Talamoos',
    };
  }

  public getTalamoosData(): any {
    return this.talamoosData;
  }

  public clearContentClickDetails(): any {
    return this.gtm.clearContentClickDetails();
  }

  public getContentClickDetails(): any {
    return this.gtm.getContentClickDetails();
  }

  public assetCheck(current, router, img, eventname, data) {
    let first, last, user_type, user_token, complete_share_url, temp_slug, talamoosData, clickDetails, contentSpec, tvChannels, videoSec;
// data is the value to check autoPlaycarousal condition
    let Channel_name;
    Channel_name = current.channel_name ? current.channel_name : '';
    if (current.asset_type === 101) {
      if (current.genres[0]) {
        if (current.genres[0].id === 'webview_sdkuserinfo') {
          let separator;
          separator = current.slug.indexOf('?') >= 0 ? true : false;
          // if(seperator) {
            first =  current.slug.split('?')[0];
            last = separator ? '&' + current.slug.split('?')[1] : '';
          // } else {
          // }
          if (localStorage.getItem('token')) {
            const userDetails = new UserApi(this.http, null, null);
            userDetails.v1PostHextoken('game', {'identifier': 'web', 'partner': 'game'}).subscribe(hextoken_data => {
              localStorage.setItem('hextoken_game', hextoken_data.json().token);
              user_token = localStorage.getItem('token') ? localStorage.getItem('hextoken_game') : localStorage.getItem('guestToken');
              user_type = this.getUserType();
              complete_share_url = first + '?token=' + user_token + '&user_type=' + user_type + last;
              temp_slug = complete_share_url;
              talamoosData = this.getTalamoosData();
              clickDetails = this.getContentClickDetails();
              contentSpec  = this.getContentSpec(current.asset_subtype);
              tvChannels = this.getChannels(Channel_name);
              videoSec = this.getVideoSection(current.asset_type, current.asset_subtype);
              this.switch(current, img, eventname, data, talamoosData, clickDetails, temp_slug, router, contentSpec, videoSec, tvChannels);
            }, err => {
              user_token = localStorage.getItem('token') ? localStorage.getItem('hextoken_game') : localStorage.getItem('guestToken');
               user_type = this.getUserType();
              complete_share_url = first + '?token=' + user_token + '&user_type=' + user_type + last;
              temp_slug = complete_share_url;
              talamoosData = this.getTalamoosData();
              clickDetails = this.getContentClickDetails();
              contentSpec  = this.getContentSpec(current.asset_subtype);
              tvChannels = this.getChannels(Channel_name);
              videoSec = this.getVideoSection(current.asset_type, current.asset_subtype);
              this.switch(current, img, eventname, data, talamoosData, clickDetails, temp_slug, router, contentSpec, videoSec, tvChannels);
            });
          } else {
            user_token = localStorage.getItem('token') ? localStorage.getItem('hextoken_game') : localStorage.getItem('guestToken');
               user_type = this.getUserType();
              complete_share_url = first + '?token=' + user_token + '&user_type=' + user_type + last;
              temp_slug = complete_share_url;
              talamoosData = this.getTalamoosData();
              clickDetails = this.getContentClickDetails();
              contentSpec  = this.getContentSpec(current.asset_subtype);
              tvChannels = this.getChannels(Channel_name);
              videoSec = this.getVideoSection(current.asset_type, current.asset_subtype);
              this.switch(current, img, eventname, data, talamoosData, clickDetails, temp_slug, router, contentSpec, videoSec, tvChannels);
          }
        } else {
          temp_slug = current.slug;
          talamoosData = this.getTalamoosData();
          clickDetails = this.getContentClickDetails();
          contentSpec  = this.getContentSpec(current.asset_subtype);
          tvChannels = this.getChannels(Channel_name);
          videoSec = this.getVideoSection(current.asset_type, current.asset_subtype);
          this.switch(current, img, eventname, data, talamoosData, clickDetails, temp_slug, router, contentSpec, videoSec, tvChannels);
        }
      }
    } else {
            talamoosData = this.getTalamoosData();
            clickDetails = this.getContentClickDetails();
            contentSpec  = this.getContentSpec(current.asset_subtype);
            tvChannels = this.getChannels(Channel_name);
            videoSec = this.getVideoSection(current.asset_type, current.asset_subtype);

            this.setGAdata(current, img, 'ExternalLink', eventname, data, clickDetails, talamoosData, contentSpec, videoSec, tvChannels);
     // this.commonService.videoError();
    }
  }

  public openAnotherTab(slug) {
    window.open(slug, '_blank');
  }

  public openinternalLink(slug, router) {
    slug = slug.replace('https://www.zee5.com', window.location.origin);
    slug = slug.replace('https://stage.zee5.com', window.location.origin);
    let santnitized_url;
    santnitized_url = this.santizeUrl(slug);
    router.navigate([santnitized_url]);
  }

  public santizeUrl(slug) {
    slug = slug.replace(window.location.origin, '');
    let arr;
    arr = ['en', 'kn', 'te', 'ta', 'mr', 'hr', 'hi', 'gu' , 'pa' , 'ml' , 'bn', 'th', 'id', 'ms', 'de', 'ru'];
    for ( let language = 0; language < arr.length; language++) {
      if (arr[language] === slug.split('/')[1] ) {
        slug = slug.replace(arr[language], '');
        break;
      }
    }
    return slug;
  }

        private sendGAData(eventName: any, videoName: any, videoSection: any, image: any, videoCategory: any, videoSubTitle: any, tvChannels: any, videoStartTime: any, timeSlot: any, episodeNumber: any, contentShow: any, contentDate: any, autoplay_carousal_data: any, talamoosData: any, clickDetails: any, contentSpec: any, videoSec: any ): void {
          let obj;
          obj = {
            'event': eventName,
            'VideoName': videoName,
            'VideoCategory': videoCategory,
            'VideoSection': videoSec ? videoSec : 'NA',
            'VideoSubTitle': videoSubTitle,
            'TVChannels': tvChannels ? tvChannels : 'NA' ,
            'VideoDuration': 0,
            'VideoStartTime': videoStartTime,
            'Time_Slot': timeSlot,
            'Episode_Number': episodeNumber,
            'Tumbnail_Image': image,
            'Content_Specification': contentSpec ? contentSpec : 'NA',
            'Content_Show': contentShow,
            'Content_Date': contentDate,
            'PageName': this.gtm.getPageName(),
            'Previous_Screen': this.gtm.previousScreenName
          };
          let finalObj;
          if (eventName === 'thumbnailImageClick') {
            obj = {...obj,
                'VideoDuration': this.videoDuration ? this.videoDuration : 0,
                'Click_Metrics': '1',
                'Carousal_Name': this.gtm.GAsubCategory ? this.gtm.GAsubCategory : 'NA'
            };
          }
          finalObj = {...obj, ...talamoosData};
          finalObj = {...finalObj, ...clickDetails};
          finalObj = autoplay_carousal_data ? {...finalObj, ...autoplay_carousal_data} : finalObj;
          if (eventName === 'carousalBannerClick') {
             delete finalObj.Horizontal_Index;
          }
          this.gtm.logEvent(finalObj);
      }

  // public setGAdata(current, img, type, eventname, gtm, data, talamoosData, clickDetails) {
  //   let videoname, img1;
  //   videoname = current.original_title ? current.original_title : 'NA';
  //   img1 = img ? img : 'NA';
  //   this.sendGAData(eventname, videoname, type, img1, gtm, data, talamoosData, clickDetails);
  // }
   public setGAdata(current, img, type, eventname, data, talamoosData, clickDetails, contentSpec, videoSec, tvChannels) {
        let videoname, img1, videoCategory, videoSubTitle, videoStartTime, timeSlot, episodeNumber, contentShow, contentDate;
        let genres;
        genres = [];
        if (current.genres) {
          for ( let index = 0; index < current.genres.length; index++) {
            genres.push(current.genres[index].value);
          }
        }
        videoname = current.original_title ? current.original_title : 'NA';
        img1 = img ? img : 'NA';
        videoCategory = (genres && genres.length > 0 ) ? genres.join(',') : 'NA';
        videoSubTitle = current.original_title ? current.original_title : 'NA';
        // tvChannels = current.getChannels(current.channel_name) || 'NA';
        videoStartTime = current.start_time ?  current.start_time : 'NA';
        timeSlot = current.time_slot ? current.time_slot : 'NA';
        episodeNumber = current.index ? current.index : 'NA';
        contentShow =  current.original_title || current.title || 'NA'; 
        contentDate =  this.dateChange(current.release_date) || 'NA';
        this.videoDuration = current.duration;
        this.sendGAData(eventname, videoname, type, img1, videoCategory, videoSubTitle, tvChannels, videoStartTime, timeSlot, episodeNumber, contentShow, contentDate, data, talamoosData, clickDetails, contentSpec, videoSec );
      }


   public getContentSpec(content): any {
    let capitalize;
    if (content) {
      capitalize = content[0].toUpperCase() + content.slice(1);
    } else {
      capitalize = 'NA';
    }
    return capitalize;
  }

    public getChannels(channel_name): any {
     if (!(Array.isArray(channel_name)) && typeof(channel_name) === 'object') {
       channel_name = channel_name.original_title;
     } else if ((Array.isArray(channel_name)) && channel_name.length > 0) {
       let allChannel_name;
       allChannel_name = [];
       for (let i of channel_name) {
         allChannel_name.push(i.original_title);
       }
       channel_name = allChannel_name.join(',');
     }
     let channels = channel_name ? channel_name.replace(', ', ',') : this.notAvailable;
     if (channels === 'N/A' || channels === ' ') {
         channels = 'NA';
     }
     return channels;
  }

    public getVideoSection(asset_type, category): any {
    let videoSection;
    if (asset_type === 6 || asset_type === 2 || asset_type === 1) {
      videoSection = 'Shows';
    } else if (asset_type === 0) {
      if (category === 'movie' || category === 'movies') {
        videoSection = 'Movies';
      } else if (category === 'video' || category === 'videos') {
        videoSection = 'Videos';
      }
    } else if (asset_type === 10 || asset_type === 9) {
      videoSection = 'Live TV';
    } else {
      videoSection = 'NA';
    }
    return videoSection;
  }

  public getVideoLanguages(data: any): any {
    let gaAudioLanguages, langArray;
    gaAudioLanguages = '';
    langArray = data ? data.audio_languages : [];
    // langArray = (data.languages && data.languages.length) ? data.languages : data.audio_languages;
    // if (!this.config && (!data.languages || (data.languages && !data.languages.length))) {
    if (!this.config || (this.config && (!langArray || (langArray && !langArray.length)))) {
      return gaAudioLanguages;
    }
    let language, counter;
    counter = 0;
    for (let i = 0; i < langArray.length; i++) {
      language = this.config.languages.findIndex(index => index.id === langArray[i]);
      if (language !== -1) {
        gaAudioLanguages += (i !== 0 ? ',' : '') + this.config.languages[language].name;
      } else {
        gaAudioLanguages += (i !== 0 ? ',' : '') + 'Audio Language ' + (++counter);
      }
    }
    return gaAudioLanguages;
  }
  public getUserAccessType(): any {
    let active, expired, userToken;
    userToken = this.localstorage.getItem('token');
    if (!userToken) {
      return 'Free';
    } else {
      active = this.subscriptionService.checkPlanApiSuccess(false);
      if (active && active.length > 0) {
        return 'Premium';
      } else {
        expired = this.subscriptionService.getAllHistoryPlan();
        return (expired && expired.length) > 0 ? 'Expired' : 'Free';
      }
    }
  }
  public convertToTitlecase(str) {
    let result, splitStr;
    splitStr = str.split(' ');
    for (let i = 0; i < splitStr.length; i++) {
      splitStr[i] = splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);
    }
    result = splitStr.join(' ');
    return result;
  }


  public switch(current, img, eventname, data, talamoosData, clickDetails, temp_slug, router, contentSpec, videoSec, tvChannels) {
      switch (current.genres[0].id) {
        case 'webview_sdkuserinfo' :
                this.setGAdata(current, img, 'WebView', eventname, data, talamoosData, clickDetails, contentSpec, videoSec, tvChannels);
          this.openAnotherTab(temp_slug);
          break;
        case 'web_view' :
                this.setGAdata(current, img, 'WebView', eventname, data, talamoosData, clickDetails, contentSpec, videoSec, tvChannels);
          this.openAnotherTab(temp_slug);
          break;
        case 'external_link' :
                this.setGAdata(current, img, 'ExternalLink', eventname, data, talamoosData, clickDetails, contentSpec, videoSec, tvChannels);
          this.openAnotherTab(temp_slug);
          break;
        case 'internal_link' :
                this.setGAdata(current, img, 'InternalLink', eventname, data, talamoosData, clickDetails, contentSpec, videoSec, tvChannels);
          this.openinternalLink(temp_slug, router);
          break;
        default:
          this.openinternalLink('pagenotfound', router);
          break;
      }
    }

}
