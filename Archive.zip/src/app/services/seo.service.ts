import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Http, Response } from '@angular/http';
import { Router, Event, NavigationStart, NavigationEnd, NavigationError } from '@angular/router';
import { Meta, Title} from '@angular/platform-browser';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { SettingsService } from './settings.service';
import { LinkService } from './link.service';
import * as $ from 'jquery';
import { environment } from '../../environments/environment';
import { isPlatformBrowser } from '@angular/common';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
declare const bk_addPageCtx: any;
declare const BKTAG: any;
@Injectable()

export class SeoService {
  public metaData: any;
  public language: any;
  public token: any;
  public displayLanguage: any;
  public staticURLs: any;
  public localstorage: any;
 public window: any;
 public document: any;
 public country_code = null;
 public configData: any;
 public checkBluekai: any;
 public StaticSeoMetaData: null;
 // should be updated when & if languages are updated in config.json
 public language_lables = {
                      'hi': 'Hindi',
                      'en': 'English',
                      'mr': 'Marathi',
                      'te': 'Telugu',
                      'kn': 'Kannada',
                      'ta': 'Tamil',
                      'ml': 'Malayalam',
                      'bn': 'Bengali',
                      'gu': 'Gujarati',
                      'pa': 'Punjabi',
                      'hr': 'Bhojpuri',
                      'or': 'Oriya',
                      'de': 'German',
                      'id': 'Indonesian',
                      'ms': 'Malay',
                      'ru': 'Russian',
                      'th': 'Thai'
                    };

public cat2_country_codes = {
  'ru': 'ru',
  'de': 'de',
  'ms': 'my',
  'th': 'th',
  'id': 'id'
};

public short_language = ['en', 'kn', 'te', 'ta', 'mr', 'hr', 'hi', 'gu' , 'pa' , 'ml' , 'bn', 'or', 'de', 'id', 'ms', 'th', 'ru' ];

private ruSeoString = {
  '/': {
    // 'title': 'Watch TV Serials, Original Shows, Movies, News & Live TV Online | {ZEE5}',
    'description': 'Более 100 000 часов телесериалов от компании ZEE. Фильмы, международный и оригинальный контент, музыка, новости онлайн на языке по вашему выбору. Смотрите более 90 телеканалов в прямом эфире онлайн, в любое время и в любом месте на ZEE5 – С ZEE5 развлечения оживают!'
  },
  '/premium': {
    // 'title': 'Watch Blockbuster Movies, Originals, International Shows, LiveTV Online | {ZEE5}',
    'description': 'Коллекция зарубежных и индийских фильмов, блокбастеров Болливуда в HD. Смотрите лучшие зарубежные сериалы, а также оригинальные сериалы производства ZEE5 Originals онлайн на языке по вашему выбору только на ZEE5. С ZEE5 развлечения оживают!'
  },
  '/tvshows': {
    // 'title': 'Watch Best TV Serials, Shows, Full Episodes & Spoilers Online | {ZEE5}',
    'description': 'Насладитесь лучшими телешоу, сериалами, онлайн-сериалами на английском, хинди и других языках Индии онлайн в HD. Смотрите эпизоды сериалов, видеоролики, промо и многое другое только на ZEE5.'
  },
  '/tvshows/all': {
    // 'title': 'All TV Shows List - TV Serials, Series of all Languages & Genres Online | {ZEE5}',
    'description': 'Познакомьтесь со списком всех сериалов и шоу онлайн. Просмотрите полную коллекцию популярных, новых и старых реалити-шоу, телешоу и сериалов на всех языках, всех жанров в HD в любое время и в любом месте только на {ZEE5}.'
  },
  '/movies': {
    // 'title': 'Movies - Watch Best Bollywood, Hollywood & Regional Movies Online | {ZEE5}',
    'description': 'Смотрите новые фильмы Болливуда онлайн в HD. Посмотрите нашу подборку: новые фильмы, фильмы 90-х, старые классические и самые популярные фильмы онлайн на разных языках только на ZEE5.'
  },
  '/movies/all': {
    // 'title': 'List of All Movies in All Languages & Genre | {ZEE5}',
    'description': 'Ознакомьтесь с полной коллекцией популярных блокбастеров Болливуда, а также других международных фильмов онлайн. Откройте для себя лучшие, новые и старые фильмы онлайн только на ZEE5.'
  },
  '/zee5originals': {
    // 'title': 'ZEE5 Originals - Watch Original Series, Movies & Short Films Online | {ZEE5}',
    'description': 'Насладитесь оригинальным контентом Zee5 Originals: шоу, сериалы, фильмы и короткометражные фильмы всех жанров в HD. Смотрите ZEE5 Originals на английском, хинди и других региональных вариантах языков Индии онлайн только на ZEE5.'
  },
  '/zee5originals/all': {
    // 'title': 'ZEE5 Originals List - All Original Series, Movies & Short Films Online | {ZEE5}',
    'description': 'Просмотрите всю нашу коллекцию всех оригинальных шоу, сериалов, фильмов и короткометражных фильмов всех жанров. Смотрите оригиналый контент ZEE5 Originals на английском, хинди и других региональных вариантах языков Индии только на ZEE5.'
  },
  '/channels': {
      // 'title': '90+ TV Channels with Live Streaming of Shows, News & Movies Online | {ZEE5}',
      'description': 'Просмотрите список, насчитывающий более чем 90 телеканалов, включая ZEE TV, JV.ru и другие каналы на русском, английском, хинди и других языках на ZEE5.'
  },
  '/livetv': {
    // 'title': 'Live Streaming of TV Shows, News, Movies & TV Channels Online in HD | {ZEE5}',
    'description': 'Насладитесь прямым эфиром более чем 90 каналов онлайн на ZEE5. Смотрите свои любимые телепередачи, новости, фильмы и развлекательные видеоролики на хинди, английском и других региональных вариантах языков Индии онлайн только на ZEE5.'
  },
  '/tvguide': {
    // 'title': 'TV Guide Listings - All Live TV Channels & Show Schedules | {ZEE5}',
    'description': 'Ознакомьтесь с нашей телепрограммой, чтобы быть в курсе полных расписаний и списков программ всех телеканалов, с возможностью выбрать день, время, язык и жанр, и смотрите онлайн на ZEE5.'
  },
  '/aboutus': {
    // 'title': 'About {ZEE5} – Learn More About {ZEE5}',
    'description': 'ZEE5 – одна из ведущих онлайн-платформ с доступом к более чем 90 телеканалам, а также более 100 000 часов контента на разных языках. Насладитесь контентом в HD качестве на ZEE5.'
  },
  '/faq': {
    // 'title': 'FAQ's - Frequently Asked Questions & Queries | {ZEE5}',
    'description': 'Посетите раздел FAQ - часто задаваемые вопросы, чтобы получить ответы на все ваши вопросы, связанные с ZEE5. '
  }
};

  constructor(private router: Router,
              @Inject(PLATFORM_ID) private platformId: Object,
              private titleService: Title,
              private metaService: Meta,
              private http: Http,
              private settingService: SettingsService,
              private linkservice: LinkService,
              private gtm: GoogleAnalyticsService) {
     if (isPlatformBrowser(this.platformId)) {
        this.localstorage = localStorage;
        this.window = window;
        this.document = document;
    }
    this.staticURLs = [ '/livetv', '/tvguide', '/language', '/settings', '/aboutus', '/faq', '/myaccount/subscription', '/contactus', '/privacypolicy', '/termsofuse', '/channels'];
    this.token = this.localstorage.getItem('token');
    if (this.token) {
      this.displayLanguage = this.localstorage.getItem('UserDisplayLanguage');
    } else {
      this.displayLanguage = this.localstorage.getItem('display_language');
    }
  }
public setCountryCode(code): any {
 this.country_code = code;
 this.updateStaticMeta({id: '1', url: this.router.url});
}
  public updateStaticMeta(event): any {
    // const alternate = document.querySelectorAll('link[rel=\'alternate\']')
    // for (let i = 0; i < alternate.length; i++) {
    //   this.linkservice.removeAlternate(alternate[i])
    // }
if (this.country_code !== null) {
    this.constructHrefLang(event);
    if (this.token) {
      this.displayLanguage = this.localstorage.getItem('UserDisplayLanguage');
    } else {
      this.displayLanguage = this.localstorage.getItem('display_language');
    }
    if ($.inArray( event.url, this.staticURLs ) >= 0) {
      this.gtm.comScoreFunction();
      if (!this.StaticSeoMetaData) {
        this.http.get(environment.shareUrl + 'assets/json/SEO_meta.json?ver=' + this.window.appVersion).subscribe(value1 => {
          this.metaData = value1.json();
          this.storeStaticSeoMetaData(this.metaData);
          this.updateMetaData(event);
          // this.metaService.updateTag({ property: 'og:type', content: ''})
          // this.metaService.removeTag('og:type');
           this.metaService.removeTag('property=\'og:type\'');
         this.metaService.updateTag({ property: 'og:url', content: this.window.location.href});
          this.metaService.updateTag({ property: 'twitter:URL', content: this.window.location.href});
          this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});
        this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});

        if (this.displayLanguage === 'ru') {
          this.titleService.setTitle(this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5'));
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'og:title', content: this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5') });

          let ruDescriptionTemplate;
          ruDescriptionTemplate = (this.ruSeoString[event.url] || {}).description || this.metaData[event.url].description
          this.metaService.updateTag({name: 'description', content : ruDescriptionTemplate.replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'og:description', content: ruDescriptionTemplate.replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'twitter:description', content: ruDescriptionTemplate.replace(/{ZEE5}/g, 'ZEE5')});
        } else if (this.displayLanguage === 'en') {
          this.titleService.setTitle(this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5'));
          this.metaService.updateTag({name: 'description', content : this.metaData[event.url].description.replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'og:title', content: this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'og:description', content: this.metaData[event.url].description.replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData[event.url].description.replace(/{ZEE5}/g, 'ZEE5')});
        } else {
          this.titleService.setTitle(this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]));
          this.metaService.updateTag({name: 'description', content : this.metaData[event.url].description.replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ property: 'og:title', content: this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ property: 'og:description', content: this.metaData[event.url].description.replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData[event.url].description.replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
        }
      });
      } else {
        this.metaData = this.StaticSeoMetaData;
        this.updateMetaData(event);
      }
    }
   }
  }


  private updateNotfromAPI(event) {
      this.gtm.comScoreFunction();
      if (!this.StaticSeoMetaData) {
        this.http.get(environment.shareUrl + 'assets/json/SEO_meta.json?ver=' + this.window.appVersion).subscribe(value1 => {
          this.metaData = value1.json();
          this.storeStaticSeoMetaData(this.metaData);
          // this.metaService.updateTag({ property: 'og:type', content: ''})
          // this.metaService.removeTag('og:type');
           this.metaService.removeTag('property=\'og:type\'');
         this.metaService.updateTag({ property: 'og:url', content: this.window.location.href});
          this.metaService.updateTag({ property: 'twitter:URL', content: this.window.location.href});
          this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});


         if (this.displayLanguage === 'ru') {
          this.titleService.setTitle(this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5'));
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'og:title', content: this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5') });

          let ruDescriptionTemplate;
          ruDescriptionTemplate = (this.ruSeoString[event.url] || {}).description || this.metaData[event.url].description
          this.metaService.updateTag({name: 'description', content : ruDescriptionTemplate.replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'og:description', content: ruDescriptionTemplate.replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'twitter:description', content: ruDescriptionTemplate.replace(/{ZEE5}/g, 'ZEE5')});
        } else if (this.displayLanguage === 'en') {
          this.titleService.setTitle(this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5'));
          this.metaService.updateTag({name: 'description', content : this.metaData[event.url].description.replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'og:title', content: this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'og:description', content: this.metaData[event.url].description.replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData[event.url].description.replace(/{ZEE5}/g, 'ZEE5')});
        } else {
          this.titleService.setTitle(this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]));
          this.metaService.updateTag({name: 'description', content : this.metaData[event.url].description.replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ property: 'og:title', content: this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ property: 'og:description', content: this.metaData[event.url].description.replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData[event.url].description.replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
        }
      });

  } else {
        this.metaData = this.StaticSeoMetaData;
        this.storeStaticSeoMetaData(this.metaData);
        // this.metaService.updateTag({ property: 'og:type', content: ''})
        // this.metaService.removeTag('og:type');
        this.metaService.removeTag('property=\'og:type\'');
        this.metaService.updateTag({ property: 'og:url', content: this.window.location.href});
        this.metaService.updateTag({ property: 'twitter:URL', content: this.window.location.href});
        this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});

        if (this.displayLanguage === 'ru') {
          this.titleService.setTitle(this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5'));
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'og:title', content: this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5') });

          let ruDescriptionTemplate;
          ruDescriptionTemplate = (this.ruSeoString[event.url] || {}).description || this.metaData[event.url].description
          this.metaService.updateTag({name: 'description', content : ruDescriptionTemplate.replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'og:description', content: ruDescriptionTemplate.replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'twitter:description', content: ruDescriptionTemplate.replace(/{ZEE5}/g, 'ZEE5')});
        } else if (this.displayLanguage === 'en') {
          this.titleService.setTitle(this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5'));
          this.metaService.updateTag({name: 'description', content : this.metaData[event.url].description.replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'og:title', content: this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'og:description', content: this.metaData[event.url].description.replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData[event.url].description.replace(/{ZEE5}/g, 'ZEE5')});
        } else {
          this.titleService.setTitle(this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]));
          this.metaService.updateTag({name: 'description', content : this.metaData[event.url].description.replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ property: 'og:title', content: this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ property: 'og:description', content: this.metaData[event.url].description.replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData[event.url].description.replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
        }
  }
}

  private extractData(res: Response) {
    let body;
    body = res.json();
    return body || {};
  }

  private handleErrorObservable (error: Response | any) {
    return Observable.throw(error.message || error);
  }


  public constructHrefLang(event) {
    const alternate = this.document.querySelectorAll('link[rel=\'alternate\']');
    for (let k = 0; k < alternate.length; k++) {
      this.linkservice.removeAlternate(alternate[k]);
    }
    let arr , searchItem, code;
    arr = this.short_language;
    if (this.token) {
      searchItem = this.localstorage.getItem('UserDisplayLanguage');
    } else {
      searchItem = this.localstorage.getItem('display_language');
    }

      let y;
      y = this.document.createElement('LINK');
      y.setAttribute('rel', 'alternate');
      y.setAttribute('href', this.window.location.origin + event.url);
      y.setAttribute('hreflang', 'x-default');
      this.document.head.appendChild(y);
   
    let intlanguages = environment.cat2_countries, x;
     for(let i = 0 ; i < arr.length; i++) {
         for (let m = 0; m < intlanguages.length; m++) {

                x = this.document.createElement('LINK');
                x.setAttribute('rel', 'alternate');
                if (arr[i] !== 'en') {
                  x.setAttribute('href', this.window.location.origin + '/' + arr[i] + event.url);
                } else {
                  x.setAttribute('href', this.window.location.origin + event.url);
                }
             if ( arr[i] === intlanguages[m] ) {
                code = arr[i] + '-' + this.cat2_country_codes[intlanguages[m]];
              break;
            } else {
                code =  arr[i] + '-' + 'in';
            }
          }
      x.setAttribute('hreflang', code);
      this.document.head.appendChild(x);
      }
    }
   public updateCategoryLanding(category_name, pageName): void {

     // if (pageName === 'tvshows' || pageName === 'movies' || pageName === 'videos' ) {
     let templateName;
     let categoryName;
     categoryName = category_name;
      switch (pageName) {
        case 'tvshows': templateName =  'showSubLanding';
        break;
        case  'movies': templateName = 'moviesSubLanding';
        break;
        case  'videos': templateName = 'videosSubLanding';
        break;
        default: templateName =  'showSubLanding';
  }
            if (this.token) {
      this.displayLanguage = this.localstorage.getItem('UserDisplayLanguage');
    } else {
      this.displayLanguage = this.localstorage.getItem('display_language');
    }
        this.http.get(environment.shareUrl + 'assets/json/SEO_meta.json?ver=' + this.window.appVersion).subscribe(value1 => {
          this.metaData = value1.json();
          this.metaService.removeTag('property=\'og:type\'');
          this.metaService.updateTag({ property: 'og:url', content: this.window.location.href});
          this.metaService.updateTag({ property: 'twitter:URL', content: this.window.location.href});
          this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});
        if (this.displayLanguage === 'en') {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template[templateName].title.replace(/Category Name/g, categoryName).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template[templateName].title.replace(/Category Name/g, categoryName).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template[templateName].description.replace(/Category Name/g, categoryName).replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template[templateName].description.replace(/Category Name/g, categoryName).replace(/{ZEE5}/g, 'ZEE5')});
          this.titleService.setTitle(this.metaData.template[templateName].title.replace(/Category Name/g, categoryName).replace(/{ZEE5}/g, 'ZEE5'));
          this.metaService.updateTag({name: 'description', content : this.metaData.template[templateName].description.replace(/Category Name/g, categoryName).replace(/{ZEE5}/g, 'ZEE5')});
        } else {
           this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template[templateName].title.replace(/Category Name/g, categoryName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
           this.metaService.updateTag({ property: 'og:title', content: this.metaData.template[templateName].title.replace(/Category Name/g, categoryName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
           this.metaService.updateTag({ property: 'og:description', content: this.metaData.template[templateName].description.replace(/Category Name/g, categoryName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
           this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template[templateName].description.replace(/Category Name/g, categoryName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
           this.titleService.setTitle(this.metaData.template[templateName].title.replace(/Category Name/g, categoryName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]));
           this.metaService.updateTag({name: 'description', content : this.metaData.template[templateName].description.replace(/Category Name/g, categoryName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
        }
      });
     // }
         this.gtm.comScoreFunction();

    }
    public catchupPage(name, language, genre) {
      let channelName;
      channelName = name;
     if (this.token) {
      this.displayLanguage = this.localstorage.getItem('UserDisplayLanguage');
    } else {
      this.displayLanguage = this.localstorage.getItem('display_language');
    }
        this.http.get(environment.shareUrl + 'assets/json/SEO_meta.json?ver=' + this.window.appVersion).subscribe(value1 => {
          this.metaData = value1.json();
          this.metaService.removeTag('property=\'og:type\'');
          this.metaService.updateTag({ property: 'og:url', content: this.window.location.href});
          this.metaService.updateTag({ property: 'twitter:URL', content: this.window.location.href});
           this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});
        if (this.displayLanguage === 'en') {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.catchupPage.title.replace(/Channel Name/g, channelName).replace(/Channel Language/g, this.language_lables[language]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.catchupPage.title.replace(/Channel Name/g, channelName).replace(/Channel Language/g, this.language_lables[language]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.catchupPage.description.replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.catchupPage.description.replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5')});
          this.titleService.setTitle(this.metaData.template.catchupPage.title.replace(/Channel Name/g, channelName).replace(/Channel Language/g, this.language_lables[language]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5'));
          this.metaService.updateTag({name: 'description', content : this.metaData.template.catchupPage.description.replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5')});
        } else {
           this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.catchupPage.title.replace(/Channel Name/g, channelName).replace(/Channel Language/g, this.language_lables[language]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
           this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.catchupPage.title.replace(/Channel Name/g, channelName).replace(/Channel Language/g, this.language_lables[language]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.catchupPage.description.replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.catchupPage.description.replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
         this.titleService.setTitle(this.metaData.template.catchupPage.title.replace(/Channel Name/g, channelName).replace(/Channel Language/g, this.language_lables[language]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]));
          this.metaService.updateTag({name: 'description', content : this.metaData.template.catchupPage.description.replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
        }
      });
          this.gtm.comScoreFunction();
    }
   public tvguidePage(name, genre, lang) {
     let language, channelName;
              language = lang;
             channelName = name;
    if (this.token) {
      this.displayLanguage = this.localstorage.getItem('UserDisplayLanguage');
    } else {
      this.displayLanguage = this.localstorage.getItem('display_language');
    }

        this.http.get (environment.shareUrl + 'assets/json/SEO_meta.json?ver=' + this.window.appVersion).subscribe(value1 => {
          this.metaData = value1.json();
           if (language === 'NA') {
            language = '';
          } else {
             language = '(' + language + ')';
        }
          this.metaService.updateTag({ property: 'og:type', content: 'video.episode'});
          this.metaService.updateTag({ property: 'og:url', content: this.window.location.href});
          this.metaService.updateTag({ property: 'twitter:URL', content: this.window.location.href});
           this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});
        if (this.displayLanguage === 'en') {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.tvguidePage.title.replace(/Channel Name/g, channelName).replace(/Genre/g, genre).replace(/Channel Language/g, language).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.tvguidePage.title.replace(/Channel Name/g, channelName).replace(/Genre/g, genre).replace(/Channel Language/g, language).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.tvguidePage.description.replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.tvguidePage.description.replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5')});
          this.titleService.setTitle(this.metaData.template.tvguidePage.title.replace(/Channel Name/g, channelName).replace(/Genre/g, genre).replace(/Channel Language/g, language).replace(/{ZEE5}/g, 'ZEE5'));
          this.metaService.updateTag({name: 'description', content : this.metaData.template.tvguidePage.description.replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5')});
        } else {
           this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.tvguidePage.title.replace(/Channel Name/g, channelName).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]).replace(/Channel Language/g, language)});
           this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.tvguidePage.title.replace(/Channel Name/g, channelName).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]).replace(/Channel Language/g, language)});
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.tvguidePage.description.replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.tvguidePage.description.replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
         this.titleService.setTitle(this.metaData.template.tvguidePage.title.replace(/Channel Name/g, channelName).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]).replace(/Channel Language/g, language));
          this.metaService.updateTag({name: 'description', content : this.metaData.template.tvguidePage.description.replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
        }
      });
          this.gtm.comScoreFunction();
    }
    public channelPage(name, language, genre) {
     let channelName;
     channelName = name;
   if (this.token) {
      this.displayLanguage = this.localstorage.getItem('UserDisplayLanguage');
    } else {
      this.displayLanguage = this.localstorage.getItem('display_language');
    }
        this.http.get(environment.shareUrl + 'assets/json/SEO_meta.json?ver=' + this.window.appVersion).subscribe(value1 => {
          this.metaData = value1.json();
          this.metaService.updateTag({ property: 'og:type', content: 'video.episode'});
          this.metaService.updateTag({ property: 'og:url', content: this.window.location.href});
          this.metaService.updateTag({ property: 'twitter:URL', content: this.window.location.href});
           this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});
        if (this.displayLanguage === 'en') {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.channelPage.title.replace(/Channel Name/g, channelName).replace(/Channel Language/g, language).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.channelPage.title.replace(/Channel Name/g, channelName).replace(/Channel Language/g, language).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.channelPage.description.replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.channelPage.description.replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5')});
          this.titleService.setTitle(this.metaData.template.channelPage.title.replace(/Channel Name/g, channelName).replace(/Channel Language/g, language).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5'));
          this.metaService.updateTag({name: 'description', content : this.metaData.template.channelPage.description.replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5')});
        } else {
           this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.channelPage.title.replace(/Channel Name/g, channelName).replace(/Channel Language/g, language).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
           this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.channelPage.title.replace(/Channel Name/g, channelName).replace(/Channel Language/g, language).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.channelPage.description.replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.channelPage.description.replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
         this.titleService.setTitle(this.metaData.template.channelPage.title.replace(/Channel Name/g, channelName).replace(/Channel Language/g, language).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]));
          this.metaService.updateTag({name: 'description', content : this.metaData.template.channelPage.description.replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
        }
      });
          this.gtm.comScoreFunction();
    }

    public showPages(seoObj, showName, name) {
    let channelName;
    channelName = name;
    if (this.token) {
      this.displayLanguage = this.localstorage.getItem('UserDisplayLanguage');
    } else {
      this.displayLanguage = this.localstorage.getItem('display_language');
    }


        this.http.get(environment.shareUrl + 'assets/json/SEO_meta.json?ver=' + this.window.appVersion).subscribe(value1 => {
          this.metaData = value1.json();
            if (channelName === 'N/A') {
              channelName = '';
            } else {
               channelName = '-' + channelName;
            }
          this.metaService.updateTag({ property: 'og:type', content: 'video.episode'});
          this.metaService.updateTag({ property: 'og:url', content: this.window.location.href});
          this.metaService.updateTag({ property: 'twitter:URL', content: this.window.location.href});
        // this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});
          this.metaService.updateTag({name: 'keywords', content: (seoObj.keywords ? seoObj.keywords : 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5')});

        // if (seoObj.extented_seo_title || seoObj.seo_title) {
        //   let titleContent;
        //   titleContent = seoObj.extented_seo_title || seoObj.seo_title;
        //     this.metaService.updateTag({ name: 'twitter:title', content: titleContent});
        //     this.metaService.updateTag({ property: 'og:title', content: titleContent});
        //     this.titleService.setTitle(titleContent);
        // } else 
        if (this.displayLanguage === 'ru') {
            this.metaService.updateTag({ name: 'twitter:title', content: seoObj.title});
            this.metaService.updateTag({ property: 'og:title', content: seoObj.title});
            this.titleService.setTitle(seoObj.title);
        } else if (this.displayLanguage === 'en') {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.showPages.title.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.showPages.title.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5') });
          this.titleService.setTitle(this.metaData.template.showPages.title.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5'));
        } else {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.showPages.title.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.showPages.title.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
         this.titleService.setTitle(this.metaData.template.showPages.title.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]));
        }

        // if (seoObj.description) {
        //     this.metaService.updateTag({ property: 'og:description', content : seoObj.description});
        //     this.metaService.updateTag({ property: 'twitter:description', content: seoObj.description});
        //     this.metaService.updateTag({name: 'description', content : seoObj.description});
        // } else 
        if (this.displayLanguage === 'ru') {
            let ruDescriptionTemplate;
            ruDescriptionTemplate = 'Наслаждайтесь последними эпизодами сериала {Show Name} онлайн. Смотрите эпизоды, клипы, промо и многое другое из сериала {Show Name} в HD только на ZEE5';
            // ruDescriptionTemplate = ' Наслаждайтесь последними эпизодами сериала Show Name онлайн. Смотрите эпизоды, клипы, промо и многое другое из сериала Show Name в HD только на {ZEE5}';
            this.metaService.updateTag({ property: 'og:description', content : ruDescriptionTemplate.replace(/{Show Name}/g, seoObj.title)});
            this.metaService.updateTag({ property: 'twitter:description', content: ruDescriptionTemplate.replace(/{Show Name}/g, seoObj.title)});
            this.metaService.updateTag({name: 'description', content : ruDescriptionTemplate.replace(/{Show Name}/g, seoObj.title)});
        } else if (this.displayLanguage === 'en') {
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.showPages.description.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.showPages.description.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({name: 'description', content : this.metaData.template.showPages.description.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5')});
        } else {
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.showPages.description.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.showPages.description.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({name: 'description', content : this.metaData.template.showPages.description.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
        }
    });
            this.gtm.comScoreFunction();
    }
    public originalPage(seoObj, showName, seasonindex, audioLanguage) {
      let seasonNo;
          if (this.token) {
      this.displayLanguage = this.localstorage.getItem('UserDisplayLanguage');
    } else {
      this.displayLanguage = this.localstorage.getItem('display_language');
    }

        this.http.get(environment.shareUrl + 'assets/json/SEO_meta.json?ver=' + this.window.appVersion).subscribe(value1 => {
          this.metaData = value1.json();
          if (seasonindex !== -1 || seasonindex !== undefined || seasonindex !== null) {
            seasonNo = 'Season' + ' ' + seasonindex;
          } else {
            seasonNo = '';
          }
          this.metaService.removeTag('property=\'og:type\'');
          this.metaService.updateTag({ property: 'og:url', content: this.window.location.href});
          this.metaService.updateTag({ property: 'twitter:URL', content: this.window.location.href});
          // this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});
          this.metaService.updateTag({name: 'keywords', content: (seoObj.keywords ? seoObj.keywords : 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5')});

        // if (seoObj.extented_seo_title || seoObj.seo_title) {
        //   let titleContent;
        //   titleContent = seoObj.extented_seo_title || seoObj.seo_title;
        //     this.metaService.updateTag({ name: 'twitter:title', content: titleContent});
        //     this.metaService.updateTag({ property: 'og:title', content: titleContent});
        //     this.titleService.setTitle(titleContent);
        // } else 
        if (this.displayLanguage === 'ru') {
            this.metaService.updateTag({ name: 'twitter:title', content: seoObj.title});
            this.metaService.updateTag({ property: 'og:title', content: seoObj.title});
            this.titleService.setTitle(seoObj.title);
        } else if (this.displayLanguage === 'en') {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.originalPage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.originalPage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/{ZEE5}/g, 'ZEE5') });
          this.titleService.setTitle(this.metaData.template.originalPage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/{ZEE5}/g, 'ZEE5'));
        } else {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.originalPage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.originalPage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
         this.titleService.setTitle(this.metaData.template.originalPage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]));
        }


        // if (seoObj.description) {
        //       this.metaService.updateTag({ property: 'og:description', content : seoObj.description});
        //       this.metaService.updateTag({ property: 'twitter:description', content: seoObj.description});
        //       this.metaService.updateTag({name: 'description', content : seoObj.description});
        // } else 
        if (this.displayLanguage === 'ru') {
          let ruDescriptionTemplate;
          ruDescriptionTemplate = 'Смотрите оригинальный сериал Zee5 Originals {OC Name} сезон {Season No}, онлайн в HD в любое время и в любом месте только на ZEE5.';
          // descriptionTemplate = 'Смотрите оригинальный сериал Zee5 Originals {OC Name} сезон {Season No}, онлайн в HD в любое время и в любом месте только на ZEE5.';
          this.metaService.updateTag({ property: 'og:description', content: ruDescriptionTemplate.replace(/{OC Name}/g, seoObj.title).replace(/{Season No}/g, (seasonindex || ''))});
          this.metaService.updateTag({ property: 'twitter:description', content: ruDescriptionTemplate.replace(/{OC Name}/g, seoObj.title).replace(/{Season No}/g, (seasonindex || ''))});
          this.metaService.updateTag({name: 'description', content : ruDescriptionTemplate.replace(/{OC Name}/g, seoObj.title).replace(/{Season No}/g, (seasonindex || ''))});
        } else if (this.displayLanguage === 'en') {
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.originalPage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.originalPage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({name: 'description', content : this.metaData.template.originalPage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5')});
        } else {
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.originalPage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.originalPage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({name: 'description', content : this.metaData.template.originalPage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
        }
    });
            this.gtm.comScoreFunction();
    }
    public moviePages(movieName, audioLanguage, genre, pageName) {
          if (this.token) {
      this.displayLanguage = this.localstorage.getItem('UserDisplayLanguage');
    } else {
      this.displayLanguage = this.localstorage.getItem('display_language');
    }
        this.http.get(environment.shareUrl + 'assets/json/SEO_meta.json?ver=' + this.window.appVersion).subscribe(value1 => {
          this.metaData = value1.json();
          this.metaService.updateTag({ property: 'og:type', content: 'video.movie'});
          this.metaService.updateTag({ property: 'og:url', content: this.window.location.href});
          this.metaService.updateTag({ property: 'twitter:URL', content: this.window.location.href});
       this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});
        if (this.displayLanguage === 'en') {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.moviePage.title.replace(/Movie Name/g, movieName).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/Movie/g, pageName).replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.moviePage.title.replace(/Movie Name/g, movieName).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/Movie/g, pageName).replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.moviePage.description.replace(/Movie Name/g, movieName).replace(/movie/g, pageName.toLowerCase()).replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.moviePage.description.replace(/Movie Name/g, movieName).replace(/movie/g, pageName.toLowerCase()).replace(/{ZEE5}/g, 'ZEE5')});
          this.titleService.setTitle(this.metaData.template.moviePage.title.replace(/Movie Name/g, movieName).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/Movie/g, pageName).replace(/{ZEE5}/g, 'ZEE5'));
          this.metaService.updateTag({name: 'description', content : this.metaData.template.moviePage.description.replace(/Movie Name/g, movieName).replace(/movie/g, pageName.toLowerCase()).replace(/{ZEE5}/g, 'ZEE5')});
        } else {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.moviePage.title.replace(/Movie Name/g, movieName).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]).replace(/Movie/g, pageName) });
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.moviePage.title.replace(/Movie Name/g, movieName).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]).replace(/Movie/g, pageName) });
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.moviePage.description.replace(/Movie Name/g, movieName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]).replace(/movie/g, pageName.toLowerCase())});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.moviePage.description.replace(/Movie Name/g, movieName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]).replace(/movie/g, pageName.toLowerCase())});
          this.titleService.setTitle(this.metaData.template.moviePage.title.replace(/Movie Name/g, movieName).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]).replace(/Movie/g, pageName));
          this.metaService.updateTag({name: 'description', content : this.metaData.template.moviePage.description.replace(/Movie Name/g, movieName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]).replace(/movie/g, pageName.toLowerCase())});
        }
      });
          this.gtm.comScoreFunction();
    }


    // public videosPage(movieName, audioLanguage, genre, pageName) {
    //       if (this.token) {
    //   this.displayLanguage = this.localstorage.getItem('UserDisplayLanguage');
    // } else {
    //   this.displayLanguage = this.localstorage.getItem('display_language');
    // }
    //     this.http.get(environment.shareUrl + 'assets/json/SEO_meta.json?ver=' + this.window.appVersion).subscribe(value1 => {
    //       this.metaData = value1.json();
    //       this.metaService.updateTag({ property: 'og:type', content: 'video.movie'});
    //       this.metaService.updateTag({ property: 'og:url', content: this.window.location.href});
    //       this.metaService.updateTag({ property: 'twitter:URL', content: this.window.location.href});
    //    this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});
    //     if (this.displayLanguage === 'en') {
    //       this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.videoPage.title.replace(/Movie Name/g, movieName).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/Movie/g, pageName).replace(/{ZEE5}/g, 'ZEE5')});
    //       this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.videoPage.title.replace(/Movie Name/g, movieName).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/Movie/g, pageName).replace(/{ZEE5}/g, 'ZEE5')});
    //       this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.videoPage.description.replace(/Movie Name/g, movieName).replace(/movie/g, pageName.toLowerCase()).replace(/{ZEE5}/g, 'ZEE5')});
    //       this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.videoPage.description.replace(/Movie Name/g, movieName).replace(/movie/g, pageName.toLowerCase()).replace(/{ZEE5}/g, 'ZEE5')});
    //       this.titleService.setTitle(this.metaData.template.videoPage.title.replace(/Movie Name/g, movieName).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/Movie/g, pageName).replace(/{ZEE5}/g, 'ZEE5'));
    //       this.metaService.updateTag({name: 'description', content : this.metaData.template.videoPage.description.replace(/Movie Name/g, movieName).replace(/movie/g, pageName.toLowerCase()).replace(/{ZEE5}/g, 'ZEE5')});
    //     } else {
    //       this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.videoPage.title.replace(/Movie Name/g, movieName).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]).replace(/Movie/g, pageName) });
    //       this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.videoPage.title.replace(/Movie Name/g, movieName).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]).replace(/Movie/g, pageName) });
    //       this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.videoPage.description.replace(/Movie Name/g, movieName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]).replace(/movie/g, pageName.toLowerCase())});
    //       this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.videoPage.description.replace(/Movie Name/g, movieName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]).replace(/movie/g, pageName.toLowerCase())});
    //       this.titleService.setTitle(this.metaData.template.videoPage.title.replace(/Movie Name/g, movieName).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]).replace(/Movie/g, pageName));
    //       this.metaService.updateTag({name: 'description', content : this.metaData.template.videoPage.description.replace(/Movie Name/g, movieName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]).replace(/movie/g, pageName.toLowerCase())});
    //     }
    //   });
    //       this.gtm.comScoreFunction();
    // }
    public newsPages(movieName, pageName) {
          if (this.token) {
      this.displayLanguage = this.localstorage.getItem('UserDisplayLanguage');
    } else {
      this.displayLanguage = this.localstorage.getItem('display_language');
    }
	this.http.get(environment.shareUrl + 'assets/json/SEO_meta.json?ver=' + this.window.appVersion).subscribe(value1 => {
          this.metaData = value1.json();
          this.metaService.updateTag({ property: 'og:type', content: 'video.movie'});
          this.metaService.updateTag({ property: 'og:url', content: this.window.location.href});
          this.metaService.updateTag({ property: 'twitter:URL', content: this.window.location.href});
       this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});
        if (this.displayLanguage === 'en') {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.newsPage.title.replace(/News Title/g, movieName).replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.newsPage.title.replace(/News Title/g, movieName).replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.newsPage.description.replace(/News Title/g, movieName).replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.newsPage.description.replace(/News Title/g, movieName).replace(/{ZEE5}/g, 'ZEE5')});
          this.titleService.setTitle(this.metaData.template.newsPage.title.replace(/News Title/g, movieName).replace(/{ZEE5}/g, 'ZEE5'));
          this.metaService.updateTag({name: 'description', content : this.metaData.template.newsPage.description.replace(/News Title/g, movieName).replace(/{ZEE5}/g, 'ZEE5')});
        } else {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.newsPage.title.replace(/News Title/g, movieName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.newsPage.title.replace(/News Title/g, movieName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.newsPage.description.replace(/News Title/g, movieName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.newsPage.description.replace(/News Title/g, movieName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
          this.titleService.setTitle(this.metaData.template.newsPage.title.replace(/News Title/g, movieName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]));
          this.metaService.updateTag({name: 'description', content : this.metaData.template.newsPage.description.replace(/News Title/g, movieName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
        }
      });
          this.gtm.comScoreFunction();
    }

    public movieFree(seoObj, movieName, genre, cast, director, moviecategory) {
      if (this.token) {
        this.displayLanguage = this.localstorage.getItem('UserDisplayLanguage');
      } else {
        this.displayLanguage = this.localstorage.getItem('display_language');
      }

      this.http.get(environment.shareUrl + 'assets/json/SEO_meta.json?ver=' + this.window.appVersion).subscribe(value1 => {
          this.metaData = value1.json();
          if (cast.length > 0) {
            cast = 'starring ' + cast;
          }

          if (director.length > 0) {
            director = 'directed by ' + director;
          }
          if (cast.length > 0 && director.length > 0) {
            cast = cast + ' and';
          }

          this.metaService.updateTag({ property: 'og:type', content: 'video.episode'});
          this.metaService.updateTag({ property: 'og:url', content: this.window.location.href});
          this.metaService.updateTag({ property: 'twitter:URL', content: this.window.location.href});
          // this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});
          this.metaService.updateTag({name: 'keywords', content: (seoObj.keywords ? seoObj.keywords : 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5')});

          // if (seoObj.extented_seo_title || seoObj.seo_title) {
          //   let titleContent;
          //   titleContent = seoObj.extented_seo_title || seoObj.seo_title;
          //     this.metaService.updateTag({ name: 'twitter:title', content: titleContent});
          //     this.metaService.updateTag({ property: 'og:title', content: titleContent});
          //     this.titleService.setTitle(titleContent);
          // } else 
          if (this.displayLanguage === 'ru') {
              this.metaService.updateTag({ name: 'twitter:title', content: seoObj.title});
              this.metaService.updateTag({ property: 'og:title', content: seoObj.title});
              this.titleService.setTitle(seoObj.title);
          } else if (this.displayLanguage === 'en') {
            // castNames director only on ZEE5.'
              this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template[moviecategory].title.replace(/Movie Name/g, movieName).replace(/Genre/g, genre).replace(/castNames/g, cast).replace(/director/g, director)});

              this.metaService.updateTag({ property: 'og:title', content: this.metaData.template[moviecategory].title.replace(/Movie Name/g, movieName).replace(/Genre/g, genre).replace(/castNames/g, cast).replace(/director/g, director)});

              this.titleService.setTitle(this.metaData.template[moviecategory].title.replace(/Movie Name/g, movieName).replace(/Genre/g, genre).replace(/castNames/g, cast).replace(/director/g, director).replace(/{ZEE5}/g, 'ZEE5'));

        } else {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template[moviecategory].title.replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});

          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template[moviecategory].title.replace(/Movie Name/g, movieName).replace(/Genre/g, genre).replace(/castNames/g, cast).replace(/director/g, director).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});

          this.titleService.setTitle(this.metaData.template[moviecategory].title.replace(/Movie Name/g, movieName).replace(/Genre/g, genre).replace(/castNames/g, cast).replace(/director/g, director).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]));

        }

          // if (seoObj.description) {
          //     this.metaService.updateTag({ property: 'og:description', content : seoObj.description});
          //     this.metaService.updateTag({ property: 'twitter:description', content: seoObj.description});
          //     this.metaService.updateTag({name: 'description', content : seoObj.description});
          // } else 
          if (this.displayLanguage === 'ru') {
              let ruDescriptionTemplate;
              ruDescriptionTemplate = 'Смотрите фильм {Movie Name} онлайн в HD только на ZEE5.';
              // ruDescriptionTemplate = 'Смотрите фильм {Movie Name} онлайн в HD.';
              this.metaService.updateTag({ property: 'og:description', content : ruDescriptionTemplate.replace(/{Movie Name}/g, seoObj.title)});
              this.metaService.updateTag({ property: 'twitter:description', content: ruDescriptionTemplate.replace(/{Movie Name}/g, seoObj.title)});
              this.metaService.updateTag({name: 'description', content : ruDescriptionTemplate.replace(/{Movie Name}/g, seoObj.title)});
          } else if (this.displayLanguage === 'en') {
            // castNames director only on ZEE5.'
              this.metaService.updateTag({ property: 'og:description', content : this.metaData.template[moviecategory].description.replace(/Movie Name/g, movieName).replace(/Genre/g, genre).replace(/castNames/g, cast).replace(/director/g, director).replace(/{ZEE5}/g, 'ZEE5')});

              this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template[moviecategory].description.replace(/Movie Name/g, movieName).replace(/Genre/g, genre).replace(/castNames/g, cast).replace(/director/g, director).replace(/{ZEE5}/g, 'ZEE5')});

              this.metaService.updateTag({name: 'description', content : this.metaData.template[moviecategory].description.replace(/Movie Name/g, movieName).replace(/Genre/g, genre).replace(/castNames/g, cast).replace(/director/g, director).replace(/{ZEE5}/g, 'ZEE5')});
        } else {
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template[moviecategory].description.replace(/Movie Name/g, movieName).replace(/Genre/g, genre).replace(/castNames/g, cast).replace(/director/g, director).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});

          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template[moviecategory].description.replace(/Movie Name/g, movieName).replace(/Genre/g, genre).replace(/castNames/g, cast).replace(/director/g, director).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});

          this.metaService.updateTag({name: 'description', content : this.metaData.template[moviecategory].description.replace(/Movie Name/g, movieName).replace(/Genre/g, genre).replace(/castNames/g, cast).replace(/director/g, director).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
        }
    });
      this.gtm.comScoreFunction();
    }

    public eachEpisodeShowPage(seoObj, showName, audioLanguage, genre, episodeNo, name, date, creativetitle) {
   //   console.log(showName, audioLanguage, genre, episodeNo, name, date, creativetitle,'actual')
      let channelName, audioLang;
       channelName = name;
       audioLang = audioLanguage;
      if (this.token) {
        this.displayLanguage = this.localstorage.getItem('UserDisplayLanguage');
      } else {
        this.displayLanguage = this.localstorage.getItem('display_language');
      }
        this.http.get(environment.shareUrl + 'assets/json/SEO_meta.json?ver=' + this.window.appVersion).subscribe(value1 => {
          this.metaData = value1.json();
          if (channelName === 'NA') {
            channelName = '';
          } else {
             channelName =  channelName;
          }
         if (audioLang === 'NA') {
            audioLang = '';
          } else {
             audioLang = '(' + this.language_lables[audioLang] + ')';
          }

          this.metaService.updateTag({ property: 'og:type', content: 'video.episode'});
          this.metaService.updateTag({ property: 'og:url', content: this.window.location.href});
          this.metaService.updateTag({ property: 'twitter:URL', content: this.window.location.href});
          // this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});
          this.metaService.updateTag({name: 'keywords', content: (seoObj.keywords ? seoObj.keywords : 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5')});
          // if (seoObj.extented_seo_title || seoObj.seo_title) {
          //   let titleContent;
          //   titleContent = seoObj.extented_seo_title || seoObj.seo_title;
          //     this.metaService.updateTag({ name: 'twitter:title', content: titleContent});
          //     this.metaService.updateTag({ property: 'og:title', content: titleContent});
          //     this.titleService.setTitle(titleContent);
          // } else 
          if (this.displayLanguage === 'ru') {
              this.metaService.updateTag({ name: 'twitter:title', content: seoObj.title});
              this.metaService.updateTag({ property: 'og:title', content: seoObj.title});
              this.titleService.setTitle(seoObj.title);
          } else if (this.displayLanguage === 'en') {
              this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.eachEpisodeShowPage.title.replace(/Show Name/g, showName).replace(/Date/g, date).replace(/Channel Name/g, channelName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5').replace(/creativetitle/g, creativetitle) });
              this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.eachEpisodeShowPage.title.replace(/Show Name/g, showName).replace(/Date/g, date).replace(/Channel Name/g, channelName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5').replace(/creativetitle/g, creativetitle) });
              this.titleService.setTitle(this.metaData.template.eachEpisodeShowPage.title.replace(/Show Name/g, showName).replace(/Date/g, date).replace(/Channel Name/g, channelName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5').replace(/creativetitle/g, creativetitle));
        } else {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.eachEpisodeShowPage.title.replace(/Show Name/g, showName).replace(/Date/g, date).replace(/Channel Name/g, channelName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]).replace(/creativetitle/g, creativetitle) });
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.eachEpisodeShowPage.title.replace(/Show Name/g, showName).replace(/Date/g, date).replace(/Channel Name/g, channelName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]).replace(/creativetitle/g, creativetitle) });
          this.titleService.setTitle(this.metaData.template.eachEpisodeShowPage.title.replace(/Show Name/g, showName).replace(/Date/g, date).replace(/Channel Name/g, channelName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]).replace(/creativetitle/g, creativetitle));
        }

          // if (seoObj.description) {
          //     this.metaService.updateTag({ property: 'og:description', content : seoObj.description});
          //     this.metaService.updateTag({ property: 'twitter:description', content: seoObj.description});
          //     this.metaService.updateTag({name: 'description', content : seoObj.description});
          // } else 
          if (this.displayLanguage === 'ru') {
              let ruDescriptionTemplate;
              ruDescriptionTemplate = 'Смотрите {Show Name}, {Date} онлайн в HD только на ZEE5.';
              // ruDescriptionTemplate = 'Смотрите Show Name канала Channel Name, Date  creativetitle онлайн в HD только на {ZEE5}.';
              this.metaService.updateTag({ property: 'og:description', content : ruDescriptionTemplate.replace(/{Show Name}/g, seoObj.title).replace(/{Date}/g, seoObj.date)});
              this.metaService.updateTag({ property: 'twitter:description', content: ruDescriptionTemplate.replace(/{Show Name}/g, seoObj.title).replace(/{Date}/g, seoObj.date)});
              this.metaService.updateTag({name: 'description', content : ruDescriptionTemplate.replace(/{Show Name}/g, seoObj.title).replace(/{Date}/g, seoObj.date)});
          } else if (this.displayLanguage === 'en') {
              this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.eachEpisodeShowPage.description.replace(/Episode No/g, episodeNo).replace(/Show Name/g, showName).replace(/Date/g, date).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5').replace(/creativetitle/g, creativetitle) });
              this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.eachEpisodeShowPage.description.replace(/Episode No/g, episodeNo).replace(/Show Name/g, showName).replace(/Date/g, date).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5').replace(/creativetitle/g, creativetitle) });
              this.metaService.updateTag({name: 'description', content : this.metaData.template.eachEpisodeShowPage.description.replace(/Episode No/g, episodeNo).replace(/Show Name/g, showName).replace(/Date/g, date).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5').replace(/creativetitle/g, creativetitle)});
        } else {
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.eachEpisodeShowPage.description.replace(/Episode No/g, episodeNo).replace(/Show Name/g, showName).replace(/Date/g, date).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]).replace(/creativetitle/g, creativetitle)});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.eachEpisodeShowPage.description.replace(/Episode No/g, episodeNo).replace(/Show Name/g, showName).replace(/Date/g, date).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]).replace(/creativetitle/g, creativetitle)});
          this.metaService.updateTag({name: 'description', content : this.metaData.template.eachEpisodeShowPage.description.replace(/Episode No/g, episodeNo).replace(/Show Name/g, showName).replace(/Date/g, date).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]).replace(/creativetitle/g, creativetitle)});
        }
    });
      this.gtm.comScoreFunction();
    }

    public eachEpisodeOriginalPage(seoObj, showName, audioLanguage, genre, episodeNo, seasonNo, episodeName) {
      let channelName, audioLang;
     channelName = name;
     audioLang = audioLanguage;
      if (this.token) {
        this.displayLanguage = this.localstorage.getItem('UserDisplayLanguage');
      } else {
        this.displayLanguage = this.localstorage.getItem('display_language');
      }
        this.http.get(environment.shareUrl + 'assets/json/SEO_meta.json?ver=' + this.window.appVersion).subscribe(value1 => {
          this.metaData = value1.json();
           if (audioLang === 'NA') {
            audioLang = '';
          } else {
             audioLang = '(' + this.language_lables[audioLang] + ')';
          }
          this.metaService.updateTag({ property: 'og:type', content: 'video.episode'});
          this.metaService.updateTag({ property: 'og:url', content: this.window.location.href});
          this.metaService.updateTag({ property: 'twitter:URL', content: this.window.location.href});
          // this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});
          this.metaService.updateTag({name: 'keywords', content: (seoObj.keywords ? seoObj.keywords : 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5')});

        // if (seoObj.extented_seo_title || seoObj.seo_title) {
        //     let titleContent;
        //     titleContent = seoObj.extented_seo_title || seoObj.seo_title;
        //       this.metaService.updateTag({ name: 'twitter:title', content: titleContent});
        //       this.metaService.updateTag({ property: 'og:title', content: titleContent});
        //       this.titleService.setTitle(titleContent);
        //   } else 
          if (this.displayLanguage === 'ru') {
              this.metaService.updateTag({ name: 'twitter:title', content: seoObj.title});
              this.metaService.updateTag({ property: 'og:title', content: seoObj.title});
              this.titleService.setTitle(seoObj.title);
          } else if (this.displayLanguage === 'en') {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.eachEpisodeOriginalPage.title.replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/EpisodeNo/g, episodeNo).replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.eachEpisodeOriginalPage.title.replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5')});
          this.titleService.setTitle(this.metaData.template.eachEpisodeOriginalPage.title.replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5'));
        } else {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.eachEpisodeOriginalPage.title.replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.eachEpisodeOriginalPage.title.replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
          this.titleService.setTitle(this.metaData.template.eachEpisodeOriginalPage.title.replace(/Season No/g, seasonNo).replace(/EpisodeNo/g, episodeNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]));
        }

        // if (seoObj.description) {
        //     this.metaService.updateTag({ property: 'og:description', content : seoObj.description});
        //     this.metaService.updateTag({ property: 'twitter:description', content: seoObj.description});
        //     this.metaService.updateTag({name: 'description', content : seoObj.description});
        // } else 
        if (this.displayLanguage === 'ru') {
            let ruDescriptionTemplate;
            ruDescriptionTemplate = 'Смотрите эпизод  {Episode Title} сериала ZEE5 Originals {OC Name} сезон {Season No}, онлайн в HD в любое время и в любом месте только на ZEE5';
            // ruDescriptionTemplate = 'Смотрите эпизод EpisodeNo - Episode Title сериала ZEE5 Originals OC Name сезон Season No, онлайн в HD в любое время и в любом месте только на {ZEE5}';
            this.metaService.updateTag({ property: 'og:description', content : ruDescriptionTemplate.replace(/{Season No}/g, seasonNo).replace(/{Episode Title}/g, seoObj.title).replace(/{OC Name}/g, seoObj.tvshow_title)});
            this.metaService.updateTag({ property: 'twitter:description', content: ruDescriptionTemplate.replace(/{Season No}/g, seasonNo).replace(/{Episode Title}/g, seoObj.title).replace(/{OC Name}/g, seoObj.tvshow_title)});
            this.metaService.updateTag({name: 'description', content : ruDescriptionTemplate.replace(/{Season No}/g, seasonNo).replace(/{Episode Title}/g, seoObj.title).replace(/{OC Name}/g, seoObj.tvshow_title)});
        } else if (this.displayLanguage === 'en') {
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.eachEpisodeOriginalPage.description.replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.eachEpisodeOriginalPage.description.replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({name: 'description', content : this.metaData.template.eachEpisodeOriginalPage.description.replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/{ZEE5}/g, 'ZEE5')});
        } else {
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.eachEpisodeOriginalPage.replace(/EpisodeNo/g, episodeNo).description.replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.eachEpisodeOriginalPage.replace(/EpisodeNo/g, episodeNo).description.replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({name: 'description', content : this.metaData.template.eachEpisodeOriginalPage.description.replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
        }
      });
        this.gtm.comScoreFunction();
    }


    public eachoriginalpagetrailer(showName, audioLanguage, genre, episodeNo, seasonNo, episodeName) {
      let channelName, audioLang;
     channelName = name;
     audioLang = audioLanguage;
      if (this.token) {
        this.displayLanguage = this.localstorage.getItem('UserDisplayLanguage');
      } else {
        this.displayLanguage = this.localstorage.getItem('display_language');
      }
        this.http.get(environment.shareUrl + 'assets/json/SEO_meta.json?ver=' + this.window.appVersion).subscribe(value1 => {
          this.metaData = value1.json();
           if (audioLang === 'NA') {
            audioLang = '';
          } else {
             audioLang = '(' + this.language_lables[audioLang] + ')';
          }
          this.metaService.updateTag({ property: 'og:type', content: 'video.episode'});
          this.metaService.updateTag({ property: 'og:url', content: this.window.location.href});
          this.metaService.updateTag({ property: 'twitter:URL', content: this.window.location.href});
          this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});
        if (this.displayLanguage === 'en') {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.eachOriginalTrailerPage.title.replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/EpisodeNo/g, episodeNo).replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.eachOriginalTrailerPage.title.replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.eachOriginalTrailerPage.description.replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.eachOriginalTrailerPage.description.replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/{ZEE5}/g, 'ZEE5')});
          this.titleService.setTitle(this.metaData.template.eachOriginalTrailerPage.title.replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5'));
          this.metaService.updateTag({name: 'description', content : this.metaData.template.eachOriginalTrailerPage.description.replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/{ZEE5}/g, 'ZEE5')});
        } else {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.eachOriginalTrailerPage.title.replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.eachOriginalTrailerPage.title.replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.eachOriginalTrailerPage.replace(/EpisodeNo/g, episodeNo).description.replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.eachOriginalTrailerPage.replace(/EpisodeNo/g, episodeNo).description.replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.titleService.setTitle(this.metaData.template.eachOriginalTrailerPage.title.replace(/Season No/g, seasonNo).replace(/EpisodeNo/g, episodeNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]));
          this.metaService.updateTag({name: 'description', content : this.metaData.template.eachOriginalTrailerPage.description.replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
        }
      });
        this.gtm.comScoreFunction();
    }



  //   public InternationalPage(showName, seasonindex, audioLanguage, genre) {
  //    // console.log('episodes alert',showName, seasonindex, audioLanguage, genre)

  //    let seasonNo;
  //         if (this.token) {
  //     this.displayLanguage = this.localstorage.getItem('UserDisplayLanguage');
  //   } else {
  //     this.displayLanguage = this.localstorage.getItem('display_language');
  //   }
  //       this.http.get(environment.shareUrl + 'assets/json/SEO_meta.json?ver=' + this.window.appVersion).subscribe(value1 => {
  //         this.metaData = value1.json();
  //         if (seasonindex !== -1 || seasonindex !== undefined || seasonindex !== null) {
  //           seasonNo = 'Season' + ' ' + seasonindex;
  //         } else {
  //           seasonNo = '';
  //         }
  //         this.metaService.removeTag('property=\'og:type\'');
  //         this.metaService.updateTag({ property: 'og:url', content: this.window.location.href});
  //         this.metaService.updateTag({ property: 'twitter:URL', content: this.window.location.href});
  //         this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});
  //       if (this.displayLanguage === 'en') {
  //         this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.internationaltvshows.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5') });
  //         this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.internationaltvshows.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5') });
  //         this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.internationaltvshows.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5') });
  //         this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.internationaltvshows.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5') });
  //         this.titleService.setTitle(this.metaData.template.internationaltvshows.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5'));
  //         this.metaService.updateTag({name: 'description', content : this.metaData.template.internationaltvshows.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5')});
  //       } else {
  //         this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.internationaltvshows.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
  //         this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.internationaltvshows.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
  //         this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.internationaltvshows.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
  //         this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.internationaltvshows.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
  //        this.titleService.setTitle(this.metaData.template.internationaltvshows.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]));
  //         this.metaService.updateTag({name: 'description', content : this.metaData.template.internationaltvshows.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
  //       }
  //   });
  //           this.gtm.comScoreFunction();
  // }



// season details
   public showPagesEpisode(showName, name, audioLanguage, genre) {
            let channelName;
    channelName = name;
    if (this.token) {
      this.displayLanguage = this.localstorage.getItem('UserDisplayLanguage');
    } else {
      this.displayLanguage = this.localstorage.getItem('display_language');
    }

        this.http.get(environment.shareUrl + 'assets/json/SEO_meta.json?ver=' + this.window.appVersion).subscribe(value1 => {
          this.metaData = value1.json();
            if (channelName === 'N/A') {
              channelName = '';
            } else {
               channelName = '-' + channelName;
            }
            this.metaService.removeTag('property=\'og:type\'');
          this.metaService.updateTag({ property: 'og:url', content: this.window.location.href});
          this.metaService.updateTag({ property: 'twitter:URL', content: this.window.location.href});
        this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});
        if (this.displayLanguage === 'en') {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.showEpisodesPage.title.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.showEpisodesPage.title.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.showEpisodesPage.description.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.showEpisodesPage.description.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5') });
          this.titleService.setTitle(this.metaData.template.showEpisodesPage.title.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5'));
          this.metaService.updateTag({name: 'description', content : this.metaData.template.showEpisodesPage.description.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5')});
        } else {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.showEpisodesPage.title.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.showEpisodesPage.title.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.showEpisodesPage.description.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.showEpisodesPage.description.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.titleService.setTitle(this.metaData.template.showEpisodesPage.title.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]));
          this.metaService.updateTag({name: 'description', content : this.metaData.template.showEpisodesPage.description.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
        }
      });
            this.gtm.comScoreFunction();
    }


    public showPagesMore(showName, name, audioLanguage, genre) {
              let channelName;
      channelName = name;
      if (this.token) {
        this.displayLanguage = this.localstorage.getItem('UserDisplayLanguage');
      } else {
        this.displayLanguage = this.localstorage.getItem('display_language');
      }
          this.http.get(environment.shareUrl + 'assets/json/SEO_meta.json?ver=' + this.window.appVersion).subscribe(value1 => {
            this.metaData = value1.json();
              if (channelName === 'N/A') {
                channelName = '';
              } else {
                 channelName = '-' + channelName;
              }
              this.metaService.removeTag('property=\'og:type\'');
            this.metaService.updateTag({ property: 'og:url', content: this.window.location.href});
            this.metaService.updateTag({ property: 'twitter:URL', content: this.window.location.href});
          this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});
          if (this.displayLanguage === 'en') {
            this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.showEpisodesMore.title.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5') });
            this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.showEpisodesMore.title.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5') });
            this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.showEpisodesMore.description.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5') });
            this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.showEpisodesMore.description.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5') });
            this.titleService.setTitle(this.metaData.template.showEpisodesMore.title.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5'));
            this.metaService.updateTag({name: 'description', content : this.metaData.template.showEpisodesMore.description.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5')});
          } else {
            this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.showEpisodesMore.title.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
            this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.showEpisodesMore.title.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
            this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.showEpisodesMore.description.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
            this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.showEpisodesMore.description.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
           this.titleService.setTitle(this.metaData.template.showEpisodesMore.title.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]));
            this.metaService.updateTag({name: 'description', content : this.metaData.template.showEpisodesMore.description.replace(/Show Name/g, showName).replace(/Channel Name/g, channelName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          }
        });
              this.gtm.comScoreFunction();
    }


// season details
    public originalsEpisodes(showName, seasonindex, audioLanguage, genre) {
     let seasonNo;
          if (this.token) {
      this.displayLanguage = this.localstorage.getItem('UserDisplayLanguage');
      } else {
        this.displayLanguage = this.localstorage.getItem('display_language');
      }

        this.http.get(environment.shareUrl + 'assets/json/SEO_meta.json?ver=' + this.window.appVersion).subscribe(value1 => {
          this.metaData = value1.json();
          if (seasonindex !== -1 || seasonindex !== undefined || seasonindex !== null) {
            seasonNo = 'Season' + ' ' + seasonindex;
          } else {
            seasonNo = '';
          }
          this.metaService.removeTag('property=\'og:type\'');
          this.metaService.updateTag({ property: 'og:url', content: this.window.location.href});
          this.metaService.updateTag({ property: 'twitter:URL', content: this.window.location.href});
          this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});
        if (this.displayLanguage === 'en') {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.originalsEpisodePage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.originalsEpisodePage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.originalsEpisodePage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.originalsEpisodePage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5') });
          this.titleService.setTitle(this.metaData.template.originalsEpisodePage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5'));
          this.metaService.updateTag({name: 'description', content : this.metaData.template.originalsEpisodePage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5')});
        } else {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.originalsEpisodePage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.originalsEpisodePage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.originalsEpisodePage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.originalsEpisodePage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
         this.titleService.setTitle(this.metaData.template.originalsEpisodePage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]));
          this.metaService.updateTag({name: 'description', content : this.metaData.template.originalsEpisodePage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
        }
      });
            this.gtm.comScoreFunction();
    }


  public originalsMore(showName, seasonindex, audioLanguage, genre) {
           // console.log('episodes alert',showName, seasonindex, audioLanguage, genre)
    let seasonNo;
    if (this.token) {
      this.displayLanguage = this.localstorage.getItem('UserDisplayLanguage');
    } else {
      this.displayLanguage = this.localstorage.getItem('display_language');
    }

    this.http.get(environment.shareUrl + 'assets/json/SEO_meta.json?ver=' + this.window.appVersion).subscribe(value1 => {
    this.metaData = value1.json();
    if (seasonindex !== -1 || seasonindex !== undefined || seasonindex !== null) {
      seasonNo = 'Season' + ' ' + seasonindex;
    } else {
      seasonNo = '';
    }
    this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});
      if (this.displayLanguage === 'en') {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.originalsMorePage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.originalsMorePage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.originalsMorePage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.originalsMorePage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5') });
          this.titleService.setTitle(this.metaData.template.originalsMorePage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5'));
          this.metaService.updateTag({name: 'description', content : this.metaData.template.originalsMorePage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5')});
    } else {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.originalsMorePage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.originalsMorePage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.originalsMorePage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.originalsMorePage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.titleService.setTitle(this.metaData.template.originalsMorePage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]));
          this.metaService.updateTag({name: 'description', content : this.metaData.template.originalsMorePage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
    }
    });
          this.gtm.comScoreFunction();
  }


// season details
    public internationalEpisodepage(showName, seasonindex, audioLanguage, genre) {
        let seasonNo;
        if (this.token) {
          this.displayLanguage = this.localstorage.getItem('UserDisplayLanguage');
        } else {
          this.displayLanguage = this.localstorage.getItem('display_language');
        }
        this.http.get(environment.shareUrl + 'assets/json/SEO_meta.json?ver=' + this.window.appVersion).subscribe(value1 => {
        this.metaData = value1.json();
        if (seasonindex !== -1 || seasonindex !== undefined || seasonindex !== null) {
          seasonNo = 'Season' + ' ' + seasonindex;
        } else {
          seasonNo = '';
        }
        this.metaService.removeTag('property=\'og:type\'');
        this.metaService.updateTag({ property: 'og:url', content: this.window.location.href});
        this.metaService.updateTag({ property: 'twitter:URL', content: this.window.location.href});
        this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});
        if (this.displayLanguage === 'en') {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.internationalEpisodepage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.internationalEpisodepage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.internationalEpisodepage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.internationalEpisodepage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5') });
          this.titleService.setTitle(this.metaData.template.internationalEpisodepage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5'));
          this.metaService.updateTag({name: 'description', content : this.metaData.template.internationalEpisodepage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5')});
        } else {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.internationalEpisodepage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.internationalEpisodepage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.internationalEpisodepage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.internationalEpisodepage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.titleService.setTitle(this.metaData.template.internationalEpisodepage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]));
          this.metaService.updateTag({name: 'description', content : this.metaData.template.internationalEpisodepage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
        }
      });
         this.gtm.comScoreFunction();
    }


  public internationalMorepage(showName, seasonindex, audioLanguage, genre) {
    let seasonNo;
    if (this.token) {
      this.displayLanguage = this.localstorage.getItem('UserDisplayLanguage');
    } else {
      this.displayLanguage = this.localstorage.getItem('display_language');
    }

    this.http.get(environment.shareUrl + 'assets/json/SEO_meta.json?ver=' + this.window.appVersion).subscribe(value1 => {
    this.metaData = value1.json();
    if (seasonindex !== -1 || seasonindex !== undefined || seasonindex !== null) {
      seasonNo = 'Season' + ' ' + seasonindex;
    } else {
      seasonNo = '';
    }
    this.metaService.removeTag('property=\'og:type\'');
    this.metaService.updateTag({ property: 'twitter:URL', content: this.window.location.href});
    this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});
      if (this.displayLanguage === 'en') {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.internationMorePage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.internationMorePage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.internationMorePage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5') });
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.internationMorePage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5') });
          this.titleService.setTitle(this.metaData.template.internationMorePage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5'));
          this.metaService.updateTag({name: 'description', content : this.metaData.template.internationMorePage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5')});
    } else {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.internationMorePage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.internationMorePage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.internationMorePage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.internationMorePage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
         this.titleService.setTitle(this.metaData.template.internationMorePage.title.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/Video Language/g, this.language_lables[audioLanguage]).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]));
          this.metaService.updateTag({name: 'description', content : this.metaData.template.internationMorePage.description.replace(/OC Name/g, showName).replace(/Season Season No/g, seasonNo).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
    }
    });
    this.gtm.comScoreFunction();
  }

    public eachinternationalpage(seoObj, showName, audioLanguage, genre, episodeNo, seasonNo, episodeName) {
   // console.log(episodeNo,'episode number')
      let channelName, audioLang;
     channelName = name;
     audioLang = audioLanguage;
      if (this.token) {
        this.displayLanguage = this.localstorage.getItem('UserDisplayLanguage');
      } else {
        this.displayLanguage = this.localstorage.getItem('display_language');
      }
        this.http.get(environment.shareUrl + 'assets/json/SEO_meta.json?ver=' + this.window.appVersion).subscribe(value1 => {
          this.metaData = value1.json();
           if (audioLang === 'NA') {
            audioLang = '';
          } else {
             audioLang = '(' + this.language_lables[audioLang] + ')';
          }

          this.metaService.updateTag({ property: 'og:type', content: 'video.episode'});
          this.metaService.updateTag({ property: 'og:url', content: this.window.location.href});
          this.metaService.updateTag({ property: 'twitter:URL', content: this.window.location.href});
            // this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});
          this.metaService.updateTag({name: 'keywords', content: (seoObj.keywords ? seoObj.keywords : 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5')});
        

        if (seoObj.extented_seo_title || seoObj.seo_title) {
          let titleContent;
          titleContent = seoObj.extented_seo_title || seoObj.seo_title;
            this.metaService.updateTag({ name: 'twitter:title', content: titleContent});
            this.metaService.updateTag({ property: 'og:title', content: titleContent});
            this.titleService.setTitle(titleContent);
        } else if (this.displayLanguage === 'ru') {
            this.metaService.updateTag({ name: 'twitter:title', content: seoObj.title});
            this.metaService.updateTag({ property: 'og:title', content: seoObj.title});
            this.titleService.setTitle(seoObj.title);
        } else if (this.displayLanguage === 'en') {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.eachInternationalShowPage.title.replace(/Show Title/g, showName).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/EpisodeNo/g, episodeNo).replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.eachInternationalShowPage.title.replace(/Show Title/g, showName).replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5')});
          this.titleService.setTitle(this.metaData.template.eachInternationalShowPage.title.replace(/EpisodeNo/g, episodeNo).replace(/Show Title/g, showName).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5'));
        } else {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.eachInternationalShowPage.title.replace(/Show Title/g, showName).replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.eachInternationalShowPage.title.replace(/Show Title/g, showName).replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
          this.titleService.setTitle(this.metaData.template.eachInternationalShowPage.title.replace(/Season No/g, seasonNo).replace(/Show Title/g, showName).replace(/EpisodeNo/g, episodeNo).replace(/Episode Title/g, episodeName).replace(/Episode Title/g, episodeName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]));
        }

        if (seoObj.description) {
            this.metaService.updateTag({ property: 'og:description', content : seoObj.description});
            this.metaService.updateTag({ property: 'twitter:description', content: seoObj.description});
            this.metaService.updateTag({name: 'description', content : seoObj.description});
        } else if (this.displayLanguage === 'ru') {
            let ruDescriptionTemplate;
            ruDescriptionTemplate = 'Смотрите сериал {Intl Show Name} сезон {Season No}, эпизод онлайн в full HD в любое время и в любом месте только на ZEE5 – С  ZEE5 сериал оживает.';
            this.metaService.updateTag({ property: 'og:description', content : ruDescriptionTemplate.replace(/{Intl Show Name}/g, showName).replace(/{Season No}/g, seasonNo)});
            this.metaService.updateTag({ property: 'twitter:description', content: ruDescriptionTemplate.replace(/{Intl Show Name}/g, showName).replace(/{Season No}/g, seasonNo)});
            this.metaService.updateTag({name: 'description', content : ruDescriptionTemplate.replace(/{Intl Show Name}/g, showName).replace(/{Season No}/g, seasonNo)});
        } else if (this.displayLanguage === 'en') {
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.eachInternationalShowPage.description.replace(/Show Title/g, showName).replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.eachInternationalShowPage.description.replace(/Show Title/g, showName).replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({name: 'description', content : this.metaData.template.eachInternationalShowPage.description.replace(/Show Title/g, showName).replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/{ZEE5}/g, 'ZEE5')});
        } else {
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.eachInternationalShowPage.replace(/Show Title/g, showName).replace(/EpisodeNo/g, episodeNo).description.replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.eachInternationalShowPage.replace(/Show Title/g, showName).replace(/EpisodeNo/g, episodeNo).description.replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({name: 'description', content : this.metaData.template.eachInternationalShowPage.description.replace(/Show Title/g, showName).replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
        }
      });
        this.gtm.comScoreFunction();
}


public eachinternationalpagetrailer(showName, audioLanguage, genre, episodeNo, seasonNo, episodeName) {
   // console.log(episodeNo,'episode number')
      let channelName, audioLang;
     channelName = name;
     audioLang = audioLanguage;
      if (this.token) {
        this.displayLanguage = this.localstorage.getItem('UserDisplayLanguage');
      } else {
        this.displayLanguage = this.localstorage.getItem('display_language');
      }
        this.http.get(environment.shareUrl + 'assets/json/SEO_meta.json?ver=' + this.window.appVersion).subscribe(value1 => {
          this.metaData = value1.json();
           if (audioLang === 'NA') {
            audioLang = '';
          } else {
             audioLang = '(' + this.language_lables[audioLang] + ')';
          }

          this.metaService.updateTag({ property: 'og:type', content: 'video.episode'});
          this.metaService.updateTag({ property: 'og:url', content: this.window.location.href});
          this.metaService.updateTag({ property: 'twitter:URL', content: this.window.location.href});
            this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});
        if (this.displayLanguage === 'en') {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.eachInternationalTrailerPage.title.replace(/Show Title/g, showName).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/EpisodeNo/g, episodeNo).replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.eachInternationalTrailerPage.title.replace(/Show Title/g, showName).replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.eachInternationalTrailerPage.description.replace(/Show Title/g, showName).replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/{ZEE5}/g, 'ZEE5')});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.eachInternationalTrailerPage.description.replace(/Show Title/g, showName).replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/{ZEE5}/g, 'ZEE5')});
          this.titleService.setTitle(this.metaData.template.eachInternationalTrailerPage.title.replace(/EpisodeNo/g, episodeNo).replace(/Show Title/g, showName).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5'));
          this.metaService.updateTag({name: 'description', content : this.metaData.template.eachInternationalTrailerPage.description.replace(/Show Title/g, showName).replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/{ZEE5}/g, 'ZEE5')});
        } else {
          this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.eachInternationalTrailerPage.title.replace(/Show Title/g, showName).replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
          this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.eachInternationalTrailerPage.title.replace(/Show Title/g, showName).replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
          this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.eachInternationalTrailerPage.replace(/Show Title/g, showName).replace(/EpisodeNo/g, episodeNo).description.replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.eachInternationalTrailerPage.replace(/Show Title/g, showName).replace(/EpisodeNo/g, episodeNo).description.replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
          this.titleService.setTitle(this.metaData.template.eachInternationalTrailerPage.title.replace(/Season No/g, seasonNo).replace(/Show Title/g, showName).replace(/EpisodeNo/g, episodeNo).replace(/Episode Title/g, episodeName).replace(/Episode Title/g, episodeName).replace(/Video Language/g, audioLang).replace(/Genre/g, genre).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]));
          this.metaService.updateTag({name: 'description', content : this.metaData.template.eachInternationalTrailerPage.description.replace(/Show Title/g, showName).replace(/EpisodeNo/g, episodeNo).replace(/Season No/g, seasonNo).replace(/Episode Title/g, episodeName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
        }
      });
        this.gtm.comScoreFunction();
}

// public movietrailerupdate(showName, audioLanguage) {
//   let channelName, audioLang;
//      channelName = name;
//      audioLang = audioLanguage;
//       if (this.token) {
//         this.displayLanguage = this.localstorage.getItem('UserDisplayLanguage');
//       } else {
//         this.displayLanguage = this.localstorage.getItem('display_language');
//       }
//         this.http.get(environment.shareUrl + 'assets/json/SEO_meta.json?ver=' + this.window.appVersion).subscribe(value1 => {
//           this.metaData = value1.json();
//            if (audioLang === 'NA') {
//             audioLang = '';
//           } else {
//              audioLang = '(' + this.language_lables[audioLang] + ')';
//           }
//             this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});
//         if (this.displayLanguage === 'en') {
//           this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.Movietrailer.title.replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/{ZEE5}/g, 'ZEE5')});
//           this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.Movietrailer.title.replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/{ZEE5}/g, 'ZEE5')});
//           this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.Movietrailer.description.replace(/OC Name/g, showName).replace(/{ZEE5}/g, 'ZEE5')});
//           this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.Movietrailer.description.replace(/OC Name/g, showName).replace(/{ZEE5}/g, 'ZEE5')});
//           this.titleService.setTitle(this.metaData.template.Movietrailer.title.replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/{ZEE5}/g, 'ZEE5'));
//           this.metaService.updateTag({name: 'description', content : this.metaData.template.Movietrailer.description.replace(/OC Name/g, showName).replace(/{ZEE5}/g, 'ZEE5')});
//         } else {
//           this.metaService.updateTag({ name: 'twitter:title', content: this.metaData.template.Movietrailer.title.replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
//           this.metaService.updateTag({ property: 'og:title', content: this.metaData.template.Movietrailer.title.replace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]) });
//           this.metaService.updateTag({ property: 'og:description', content: this.metaData.template.Movietrailer.replace(/OC Name/g, showName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
//           this.metaService.updateTag({ property: 'twitter:description', content: this.metaData.template.Movietrailer.replace(/OC Name/g, showName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
//           this.titleService.setTitle(this.metaData.template.Movietrailer.titlereplace(/OC Name/g, showName).replace(/Video Language/g, audioLang).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]));
//           this.metaService.updateTag({name: 'description', content : this.metaData.template.Movietrailer.description.replace(/OC Name/g, showName).replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
//         }
//     });
//         this.gtm.comScoreFunction();
// }
public update(title, description): void {
    let zee;
    zee = (this.displayLanguage === 'en') ? 'ZEE5' :  'ZEE5 in ' + this.language_lables[this.displayLanguage];
    this.metaService.updateTag({ name: 'twitter:title', content: title.replace(/{ZEE5}/g,   zee) });
    this.metaService.updateTag({ property: 'og:title', content: title.replace(/{ZEE5}/g,   zee) });
    this.metaService.updateTag({ property: 'og:description', content: description.replace(/{ZEE5}/g,   zee)});
    this.metaService.updateTag({ property: 'twitter:description', content: description.replace(/{ZEE5}/g,  zee)});
    this.titleService.setTitle(title.replace(/{ZEE5}/g,   zee));
    this.metaService.updateTag({name: 'description', content : description.replace(/{ZEE5}/g,  zee)});
}
  public blueKaifunction(title, category, asset_type, asset_subtype, genres, audiotracks): void {
    this.configData = this.settingService.getCompleteConfig();
    this.checkBluekai = (this.configData && this.configData.bluekaiEnable) ? this.configData.bluekaiEnable : false;
    if (this.checkBluekai === true) {
      let element;
      element = document.getElementById('blueKai');
      if (element) {
          element.parentNode.removeChild(element);
      }
      let site;
      site = environment.shareUrl;
      if (this.window.bk_addPageCtx && this.window.BKTAG) {
        bk_addPageCtx( 'site', site);
        bk_addPageCtx( 'title', title);
        bk_addPageCtx( 'category', category);
        bk_addPageCtx( 'tag', asset_type);
        bk_addPageCtx( 'tag', asset_subtype);
        bk_addPageCtx( 'tag', genres);
        bk_addPageCtx( 'tag', audiotracks);
        BKTAG.doTag(56784 , 1);
      }
      let scripts , s;
      scripts = document.getElementsByTagName( 'body')[0];
      s = document.createElement( 'script');
      s.async = true;
      s.src =  'https://tags.bkrtx.com/js/bk-coretag.js';
      s.setAttribute('id', 'blueKai');
      s.setAttribute('class', 'optanon-category-C0004');
      s.setAttribute('type', this.gtm.checkCookieCategoryStatus([4]));
      scripts.appendChild(s);
    }
  }


  public updatefromAPI(data, event) {
    // console.log(data, event, 'meta');
    if (data.meta_title && (data.meta_title !== null || data.meta_title !== '') && this.displayLanguage !== 'ru') {
        this.titleService.setTitle(data.meta_title);
        this.metaService.updateTag({ name: 'twitter:title', content: data.meta_title });
        this.metaService.updateTag({ property: 'og:title', content: data.meta_title  });

    } else {
        this.updateNotfromAPI(event);
    }

    if (data.meta_description && (data.meta_description !== null || data.meta_description !== '') && this.displayLanguage !== 'ru') {
      this.metaService.updateTag({name: 'description', content : data.meta_description });
      this.metaService.updateTag({ property: 'og:description', content: data.meta_description});
      this.metaService.updateTag({ property: 'twitter:description', content: data.meta_description});
    } else {
      this.updateNotfromAPI(event);
    }

    if (data.meta_keywords && (data.meta_keywords !== null || data.meta_keywords !== '') && this.displayLanguage !== 'ru') {
      this.metaService.updateTag({name: 'keywords', content : data.meta_keywords });
    } else {
      this.updateNotfromAPI(event);
    }

  }
  public storeStaticSeoMetaData(metaData) {
    this.StaticSeoMetaData = metaData;
  }
  public getStaticSeoMetaData() {
    if (this.StaticSeoMetaData) {
      return this.StaticSeoMetaData;
    }
    return null;
  }
  public updateMetaData(event) {
    this.metaService.removeTag('property=\'og:type\'');
    this.metaService.updateTag({ property: 'og:url', content: this.window.location.href});
    this.metaService.updateTag({ property: 'twitter:URL', content: this.window.location.href});
    this.metaService.updateTag({name: 'keywords', content: 'online tv streaming, online television, internet tv, watch tv on internet, ZEE5'});
    if (this.displayLanguage === 'ru') {
      this.titleService.setTitle(this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5'));
      this.metaService.updateTag({ name: 'twitter:title', content: this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5')});
      this.metaService.updateTag({ property: 'og:title', content: this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5') });

      let ruDescriptionTemplate;
      ruDescriptionTemplate = (this.ruSeoString[event.url] || {}).description || this.metaData[event.url].description
      this.metaService.updateTag({name: 'description', content : ruDescriptionTemplate.replace(/{ZEE5}/g, 'ZEE5')});
      this.metaService.updateTag({ property: 'og:description', content: ruDescriptionTemplate.replace(/{ZEE5}/g, 'ZEE5')});
      this.metaService.updateTag({ property: 'twitter:description', content: ruDescriptionTemplate.replace(/{ZEE5}/g, 'ZEE5')});
    } else if (this.displayLanguage === 'en') {
      this.titleService.setTitle(this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5'));
      this.metaService.updateTag({name: 'description', content : this.metaData[event.url].description.replace(/{ZEE5}/g, 'ZEE5')});
      this.metaService.updateTag({ name: 'twitter:title', content: this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5')});
      this.metaService.updateTag({ property: 'og:title', content: this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5') });
      this.metaService.updateTag({ property: 'og:description', content: this.metaData[event.url].description.replace(/{ZEE5}/g, 'ZEE5')});
      this.metaService.updateTag({ property: 'twitter:description', content: this.metaData[event.url].description.replace(/{ZEE5}/g, 'ZEE5')});
    } else {
      this.titleService.setTitle(this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage]));
      this.metaService.updateTag({name: 'description', content : this.metaData[event.url].description.replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
      this.metaService.updateTag({ name: 'twitter:title', content: this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
      this.metaService.updateTag({ property: 'og:title', content: this.metaData[event.url].title.replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
      this.metaService.updateTag({ property: 'og:description', content: this.metaData[event.url].description.replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
      this.metaService.updateTag({ property: 'twitter:description', content: this.metaData[event.url].description.replace(/{ZEE5}/g, 'ZEE5 in ' + this.language_lables[this.displayLanguage])});
    }
  }
}
