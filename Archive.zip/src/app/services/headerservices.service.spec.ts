import { TestBed, inject } from '@angular/core/testing';

import { HeaderservicesService } from './headerservices.service';

describe('HeaderservicesService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HeaderservicesService]
    });
  });

  it('should be created', inject([HeaderservicesService], (service: HeaderservicesService) => {
    expect(service).toBeTruthy();
  }));
});
