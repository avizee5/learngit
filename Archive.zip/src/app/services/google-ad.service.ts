import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { UserApiService } from '../services/user-api.service';
import { SettingsService } from '../services/settings.service';

@Injectable()
export class GoogleAdService {
  public carouselDesktopTag: any = '';
  public carouselMobileTag: any = '';

  constructor(private userapiService: UserApiService, private settingsService: SettingsService) { }

  public getcarouselDesktopTag(): void {
    return this.carouselDesktopTag;
  }
  public setcarouselDesktopTag(value: any): void {
    this.carouselDesktopTag = value;
  }
  public getcarouselMobileTag(): void {
    return this.carouselMobileTag;
  }
  public setcarouselMobileTag(value: any): void {
    this.carouselMobileTag = value;
  }
}
