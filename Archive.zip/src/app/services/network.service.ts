import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import * as $ from 'jquery';
import { isPlatformBrowser } from '@angular/common';


@Injectable()
export class NetworkService {
public isOnline: boolean;
public IE = false;
public window: any;
public document: any;
public navigator: any;
  constructor(@Inject(PLATFORM_ID) private platformId: Object) {
    this.isOnline = false;
    if (isPlatformBrowser(this.platformId)) {
    this.window = window;
    this.document = document;
    this.navigator = navigator;
    }
    if (navigator.userAgent.indexOf('Trident') !== -1 || (navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i))) {
    this.IE = true;
  }

  }

  public getScreenStatus(): any {
     this.unLockScroll();
     if (!navigator.onLine) {
            $('#loaderPage').css('display', 'none');
            $('#network').css('display', 'block');
            this.isOnline = false;
            return this.isOnline;
      } else {
            $('#network').css('display', 'none');
            this.isOnline = true;
            return this.isOnline;
      }
  }
  public getPopupStatus(): any {
      if (!navigator.onLine) {
            $('#networkPopup').css('display', 'block');
            this.isOnline = false;
            this.lockScroll();
            return this.isOnline;
      } else {
            $('#networkPopup').css('display', 'none');
            this.isOnline = true;
            this.unLockScroll();
            return this.isOnline;
      }
  }
  public lockScroll(): void {
      if (this.IE) {
        this.document.getElementById('body').classList.add('overlay-open');
  } else {
    let x, y;
    x = this.window.scrollX;
    y = this.window.scrollY;
    this.window.onscroll = function() {this.window.scrollTo(x, y); };
  }
  }
  public unLockScroll(): void {
     if (this.IE) {
        this.document.getElementById('body').classList.remove('overlay-open');
  } else {
        this.window.onscroll = function() {
          // todo
        };
  }
  }
}
