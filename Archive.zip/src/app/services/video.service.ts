import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { VideoAnalyticsService } from '../services/video-analytics.service';
import { SettingsService } from '../services/settings.service';
import { UserProfileService } from '../services/user-profile.service';
import * as $ from 'jquery';
import {environment} from '../../environments/environment';
import { DeviceApiService } from '../services/device-api.service';
import { SubscriptionService } from '../services/subscription.service';
import { CommonService } from '../services/common.service';

import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { RequestMethod, RequestOptionsArgs } from '@angular/http';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/timeoutWith';
const precisionTimeout = 400; // ms
const epgAssetType = 10;
const mygp_UTM_source = 'mygp';

// declare let window: any;
declare let opr: any;
declare let InstallTrigger: any;
declare let safari: any;
// declare let  ns_: any;
@Injectable()
export class VideoService {
  public subtitlesToggle: any = true;
  public autoPlay: any = true;
  public bitRate: any = 'Auto';
  public enableCastView: any = false;
  public alertCastState = new Subject<any>();
  public currentTime: any;
  public enableQueue: any = false;
  public alertQueueState = new Subject<any>();
  // public historyStatus: any = false;
  // public alertHistoryStatus = new Subject<any>();
  public modalStatus: any = false;
  public alertModalState = new Subject<any>();
  public trailerPlayed: any = false;
  public tvShowTrailer = new Subject<any>();
  public nextepisode = new Subject<any>();
  // public showLoginOnSkip = new Subject<boolean>();
  // public showSubOnSkip = new Subject<boolean>();
  public prevContent: any = '';
  public castWindowWidth: number;
  public videoObjectSelected: any;
  public videoItemforGA: any;
  public castQueueObject: any;
  public notAvailable: any = 'NA';
  public errorMessages: any = [
                     'PLAYER.BROWSER_UPGRADE' , // Please upgrade your browser
                     'PLAYER.PLAYBACK_ERROR', // Playback is not supported. Please use Chrome
                     'PLAYER.BROWSER_UPGRADE', // 'PLAYER.ERROR_MSG' // Sorry, Contents can be watched only on ZEE5 Apps or Desktop Web
                     'Playback is not supported' // Playback is not supported.
                    ];
  public errorMsg: any;
  public selectedQuality: any;
  public selectedAudio: any;
  public selectedSubtitle: any;
  public videoLanguageGA: any;
  public instance: any;
  // GAsubCategory: any = '';
  public navigator: any;
  public localStorage: any;
  public document: any;
  public window: any;
  public publisherName = '\"Zee5\"';

  public defaultImage = environment.assetsBasePath + 'assets/default/popular.png';
  public playerCalledOnLaunch: any = false;

  public testPage: any = false;

  constructor(@Inject(PLATFORM_ID) private platformId: Object, private sub: SubscriptionService, private commonService: CommonService, private deviceApi: DeviceApiService, private http: Http, private userProfileService: UserProfileService, private settingsService: SettingsService, private gtm: GoogleAnalyticsService, private videoAnalyticsService: VideoAnalyticsService) {
    if (isPlatformBrowser(this.platformId)) {
      this.navigator = navigator;
      this.localStorage = localStorage;
      this.document = document;
      this.window = window;
    }
    this.setTestPage();
  }

  public setTestPage(): any {
    if (this.testPage) {
      return;
    }
    let queryParams;
    queryParams = this.window.location.search;
    console.log(queryParams);
    if (queryParams) {
      this.testPage = queryParams.includes('testToken=1');
    }
    console.log('testpage', this.testPage);
  }

  public setPlayerLaunchStatus(val): any {
    this.playerCalledOnLaunch = val.id === 1 ? true : false;
  }
  public getPlayerLaunchStatus(): any {
    return this.playerCalledOnLaunch;
  }
  public autoPlayed(val): any {
    let content;
    content = this.prevContent;
    this.prevContent = val;
    return content;
  }
  public nextEpisode(val): any {
    let nextcontent;
    nextcontent = val;
    this.nextepisode.next(nextcontent);
    return nextcontent;
  }
  public getPrecisionTimeout(): any {
    let config;
    config = this.settingsService.getCompleteConfig();
    if (config && config.timeout && config.timeout.web && (config.timeout.web.precision !== undefined)) {
      return config.timeout.web.precision;
    } else {
      return precisionTimeout;
    }
  }
  public toggleCastState(toggleState: boolean): any {
    this.enableCastView = toggleState;
    this.alertCastState.next(this.enableCastView);
    return this.enableCastView;
  }
  public closeModalVideo(toggleState: boolean): any {
    this.modalStatus = toggleState;
    this.alertModalState.next(this.modalStatus);
    return this.modalStatus;
  }
  // public toggleHistoryStatus(toggleState: boolean): any {
  //   this.historyStatus = toggleState;
  //   this.alertHistoryStatus.next(this.historyStatus);
  //   return this.historyStatus;
  // }
  public toggleQueueState(toggleState: boolean): any {
    this.enableQueue = toggleState;
    this.alertQueueState.next(this.enableQueue);
    return this.enableQueue;
  }
  public trailerState(toggleState: boolean): any {
    this.trailerPlayed = toggleState;
    this.tvShowTrailer.next(this.trailerPlayed);
    return this.trailerPlayed;
  }
  // get conviva precision API
  public getAPI(drm, id): Observable<Array<string>> {
  // public getAPI(drm, id, asset_name): Observable<Array<string>> {
    let url, cdnData, baseUrl, userData,
    value = '';
    cdnData = this.settingsService.getCompleteConfig().cdn;
    baseUrl = this.settingsService.getCompleteConfig().default_urls.precision;
    for (let i = 0; i < cdnData.length; i++) {
      value += 'c3.r' + (i + 1) + '=' + cdnData[i].id + '&';
    }
    let token = this.localStorage.getItem('token');
    if (!token) {
      if (this.localStorage.getItem('guestToken') === null || this.localStorage.getItem('guestToken') === 'null') {
        this.settingsService.convivaGuestId('{"user":{"apikey":"6BAE650FFC9A3CAA61CE54D","aid":"91955485578"}}').subscribe( userToken => {
        this.localStorage.setItem('guestToken', JSON.parse(userToken._body).guest_user);
        token = JSON.parse(userToken._body).guest_user;
        // }, error => {
        });
      } else {
        token = this.localStorage.getItem('guestToken');
      }
    } else {
      userData = this.userProfileService.getuserdata();
      token = userData ? userData.id : 'NA';
    }
    let provider;
    if (drm) {
      provider = 'shaka';
    } else {
      provider = navigator.userAgent.match(/mobile/i) ? 'html5' : 'hlsjs';
    }
    url = baseUrl + '?c3.vr=2&c3.ck=' + environment.convivakey
    + '&c3.rt=p&c3.vp=s&c3.im=d&c3.um=i&' + value
    + 'c3.at=ON_DEMAND'
    + '&c3.ext.VI=' + token
    + '&c3.ext.DEVICE=Web&c3.ext.PROVIDER=' + provider;
    if (id) {
      url = url + '&c3.ext.contentID=' + id;
      // url = url + '&c3.ext.CONTENT_ID=' + id;
    }
    // if (asset_name) {
    //   url = url + '&c3.an=' + asset_name;
    // }
    return this.http.get(url)
    .map(this.extractData)
    .catch(this.handleErrorObservable);
  }
  // get video token
  public getToken(live, business_type, id: any = ''): Observable<any> {
    let url, token, headers, country;
    token = this.localStorage.getItem('token');
    country = this.settingsService.getCountry();
    headers = new Headers();
    if (this.testPage && live === 'fallback') {
      url = environment.fallbackVideoTokenNew;
      url = url  + '?platform_name=mobile_web&country=' + country + '&content_id=' + id;
    } else if (live === 'fallback') {
      url = environment.fallbackVideoToken;
    } else if (live === 'live') {
      url = environment.liveVideoToken;
      if (business_type.indexOf('premium') !== -1) {
        headers.append('Authorization', 'bearer ' + token);
        url = url  + '?deviceid=' + this.deviceApi.identifier;
      }
    } else if (live === 'vod') {
      url = environment.vodVideoToken;
    }
    const requestOptions: RequestOptionsArgs = new RequestOptions({
        method: RequestMethod.Get,
        headers: headers
    });
    return this.http.request(url, requestOptions)
    .map(this.extractData)
    .catch(this.handleErrorObservable);
  }
  public getAdData(id, type): Observable<any> {
   let adUrl, country, userType, deviceType, collectionId, token, headers, onetrustActiveGroups;
   headers = new Headers();
   headers.append('X-ACCESS-TOKEN', localStorage.getItem('xacesstoken'));
   token = this.localStorage.getItem('token');
   country = this.settingsService.getCountryValue();
   userType = this.commonService.getUserType();
   deviceType = this.window.innerWidth <= 991 ? 'mobile_web' : 'desktop_web';
   type = (type === 'live') ? '?channel_id=' : '?content_id=';
   onetrustActiveGroups =  window['OnetrustActiveGroups'] ? window['OnetrustActiveGroups'] : '';
   onetrustActiveGroups = onetrustActiveGroups.replace(/^,+|,+$/gm, '');
   collectionId = this.commonService.getCollectionId();
   adUrl = environment.detailsPageAdBasePath +
   type + id +
   '&platform_name=' + deviceType +
   '&user_type=' + userType +
   '&country=' + country.country_code +
   (country.state_code ? ('&state=' + country.state_code) : '') +
   // '&user_id=' + this.localStorage.getItem('token') ? this.localStorage.getItem('ID') : this.localStorage.getItem('guestToken') +
   '&app_version=' + this.window.appVersion +
   (collectionId ? ('&collection_id=' + collectionId) : '') +
   '&description_url=' + window.location.href;
    if (onetrustActiveGroups) {
      adUrl = adUrl + '&zgdpr=' + onetrustActiveGroups;
    }
    let euRegion, configValue;
    configValue = this.settingsService.getCompleteConfig();
    euRegion = configValue && configValue.google_consent_allowed_countries && configValue.google_consent_allowed_countries.indexOf(country.country_code) !== -1;
    if (!euRegion) {
      adUrl = adUrl + '&zcnstdt=-1';
    } else if (window['__cmp']) {
      let tcString;
      window['__cmp']( 'getConsentData', {}, function(e) {
        // console.log(e);
        tcString = e.consentData;
      });
      // console.log(tcString);
      adUrl = adUrl + '&zcnstdt=' + (tcString ? tcString : '0');
    } else {
      adUrl = adUrl + '&zcnstdt=0';
    }
    if (this.videoAnalyticsService.getRemarketingBlock()) {
      adUrl = adUrl + '&is_lat=1';
    } else if (this.videoAnalyticsService.getRemarketingBlock() === false) {
      adUrl = adUrl + '&is_lat=0';
    }
    adUrl = adUrl + '&utm_source=' + mygp_UTM_source;
    if (token) {
        // headers.append('user_id', this.localStorage.getItem('ID'));
        headers.append('Authorization', 'bearer ' + token);
    // } else {
    //     headers.append('guest_token', this.localStorage.getItem('guestToken'));
    }
    headers.append('X-Z5-Guest-Token', this.localStorage.getItem('guestToken'));
    headers.append('X-User-Type', this.commonService.getUserType());
    let platform;
    platform = this.navigator.userAgent.match(/mobile|iPhone|iPod|iPad/i) ? 'Web Mobile' : 'Web Desktop';
    headers.append('X-Z5-AppPlatform', platform);
    headers.append('X-Z5-Appversion', this.window.appVersion);
    const requestOptions: RequestOptionsArgs = new RequestOptions({
        method: RequestMethod.Get,
        headers: headers
    });
    return this.http.request(adUrl, requestOptions)
    // return this.http.get(adUrl)
    .map(this.extractData1)
    .catch(this.handleErrorObservable);
  }
  public getAdInfo(url): Observable<any> {
    return this.http.get(url)
    .map(this.extractData1)
    .catch(this.handleErrorObservable);
  }
  private extractData1(res: Response) {
    let body;
    body = res;
    return body || {};
  }
  private extractData(res: Response) {
    let body;
    body = res.json();
    return body || {};
  }
  private handleErrorObservable (error: Response | any) {
    return Observable.throw(error.message || error);
  }

  public comScoreFunction(): any {
    this.gtm.comScoreFunction();
  }
  // public comscoreVideoevents(videoObject, playerReady): any {
  //     let episode , title, season , episodeNo, genre, noData, label, releaseDate, episodeRnot, assetId, duration, stationTitle;
  //     noData = '\"*null\"/';
  //     episode = '\"' + videoObject.episode_name_en + '\"';
  //     title = '\"' + videoObject.title_en + '\"';
  //     season = '\"' + videoObject.season_no + '\"';
  //     episodeNo = '\"' + videoObject.episode_no + '\"';
  //     assetId = '\"' + videoObject.id + '\"';
  //     duration = videoObject.duration * 1000;
  //     duration = '\"' + duration + '\"';
  //     stationTitle = '\"' + videoObject.channel_name + '\"';
  //     if (videoObject.content_type === 'episode') {
  //        releaseDate = '\"' + videoObject.release_date + '\"';
  //     } else {
  //       releaseDate =  noData;
  //     }
  //     if (videoObject.content_type === 'video' || videoObject.content_type === 'movie' || videoObject.content_type === 'original' || videoObject.content_type === 'tvshow' || videoObject.content_type === 'episode') {
  //       episodeRnot = '\"' + '1' + '\"';
  //     } else {
  //       episodeRnot = '\"' + '0' + '\"';
  //     }
  //     genre = videoObject.genre.replace(', ', ',');
  //     genre = '\"' + genre + '\"';
  //                label = 'c3=' + this.publisherName + ',' +
  //                        'c4=\"*null\",' +
  //                        'c6=\"*null\",' +
  //                        'ns_st_st=' + stationTitle + ',' +
  //                        'ns_st_pu=\"*null\",' +
  //                        'ns_st_pr=' + title + ',' +
  //                        'ns_st_ep=' + episode + ',' +
  //                        'ns_st_sn=' + season   + ',' +
  //                        'ns_st_en=' + episodeNo + ',' +
  //                        'ns_st_ge=' +  genre + ',' +
  //                        'ns_st_ti=\"*null\"/' + ',' +
  //                        'ns_st_ia=\"0\"/' + ',' +
  //                        'ns_st_ce=' + episodeRnot + ',' +
  //                        'ns_st_ddt=\"*null\",' +
  //                        'ns_st_tdt=' + releaseDate + ',' +
  //                        'ns_st_ci=' + assetId + ',' +
  //                        'ns_st_cl=' + duration;
  //    if (this.window.ns_) {
  //      this.window.ns_.StreamingAnalytics.JWPlayer(playerReady, {
  //      publisherId: '9254297',
  //      labelmapping: label
  //    });
  //    }
  // }

  public getChannels(channel_name): any {
    let channels = channel_name ? channel_name.replace(', ', ',') : this.notAvailable;
    if (channels === 'N/A' || channels === ' ') {
      channels = this.notAvailable;
    }
    return channels;
  }

  public getContentSpec(content): any {
    let capitalize;
    if (content) {
      capitalize = content[0].toUpperCase() + content.slice(1);
    } else {
      capitalize = this.notAvailable;
    }
    return capitalize;
  }

  public getShowSubtype(asset_type, category, content_type): any {
    if (asset_type === 1) {
      return category;
    } else if (asset_type === 0) {
      return content_type;
    } else {
      return this.notAvailable;
    }
  }

  public getVideoSection(asset_type, category): any {
    let videoSection;
    if (asset_type === 6 || asset_type === 2 || asset_type === 1) {
      videoSection = 'Shows';
    } else if (asset_type === 0) {
      if (category === 'movie' || category === 'movies') {
        videoSection = 'Movies';
      } else if (category === 'video' || category === 'videos') {
        videoSection = 'Videos';
      }
    } else if (asset_type === 10 || asset_type === 9) {
      videoSection = 'Live TV';
    } else {
      videoSection = this.notAvailable;
    }
    return videoSection;
  }

  // public getTopCategory(category): any {
  //   let topCategory;
  //   if (category === 'tvshows' || category === 'tvshow') {
  //     topCategory = 'TV Show';
  //   } else if (category === 'movie' || category === 'movies') {
  //     topCategory = 'Movie';
  //   } else if (category === 'video' || category === 'videos') {
  //     topCategory = 'Video';
  //   } else if (category === 'original' || category === 'originals') {
  //     topCategory = 'Original';
  //   } else if (category === 'Live TV' || category === 'TV Guide') {
  //     topCategory = category;
  //   } else {
  //     topCategory = this.notAvailable; // category
  //   }
  //   return topCategory;
  // }

  public getQGsection(object): any {
    switch (object.category) {
      case 'tvshows': return 'tvshows';
      case 'movie': return 'Movies';
      case 'video': return 'videos';
      case 'original': return 'Originalcontent';
      // case 'original': return 'Movies';
      case 'Live TV': return 'livetv';
      case 'TV Guide':
        if (object.type === 'live') {
          return 'livetv';
        } else {
          return 'TV Guide';
        }
      default: return object.type;
    }
  }

  public getDisplayContentLang(): any {
    let langObj;
    langObj = this.gtm.displayContentLan();
    return {
      'Content_Lang': langObj.contentLang,
      'Display_Lang': langObj.displayLang,
     };
  }

  public googleAnalyticPost(event: any, subCategory: string, clickDetails: any): any {
    event = $.extend({}, event, this.getConstParams());
    if (event.event !== 'VideoReplay') {
      // let subCategoryParam;
      // subCategoryParam = {'SubCategory': subCategory || this.notAvailable};
      event = $.extend({}, event, clickDetails);
    }
    if (event.event === 'VideoClicks') {
      // $.extend({}, event, {'Previous_Screen': this.gtm.previousScreenName});
      event['Previous_Screen'] = this.gtm.previousScreenName;
    }
    if (event) {
      this.gtm.logEvent(event);
    }
  }

  public threeDotEvent(event: any, clickDetails: any): any {
    event = {...event, ...clickDetails,
      'pageName': this.gtm.getPageName(),
      'GoogleID': this.gtm.fetchToken()
    };
    if (event) {
      this.gtm.logEvent(event);
    }
  }

  public seekGoogleAnalyticPost(videoItemforGA, from, to, subCategory, clickDetails): any {
    let event, duration;
    duration = Math.round(to - from);
    event = {
      'event': 'VideoSeek',
      'VideoSeekFrom': Math.round(from),
      'VideoSeekto': Math.round(to),
      'SeekDuration': duration < 0 ? (duration * -1) : duration,
      // 'SubCategory': subCategory || this.notAvailable
    };
    videoItemforGA = $.extend({}, videoItemforGA, clickDetails);
    videoItemforGA = $.extend({}, videoItemforGA, this.getConstParams());
    videoItemforGA = $.extend({}, videoItemforGA, event);
    this.gtm.logEvent(videoItemforGA);
  }

  public getConstParams(): any {
    let  event;
    event = {
      'VideoStartTime': this.notAvailable, // 'pass the start time of the video',
      'G_ID': this.gtm.fetchToken(),
      'Client_ID': this.gtm.fetchClientId(),
      'TimeHHMMSS': this.gtm.fetchCurrentTime(),
      'DateTimeStamp': this.gtm.fetchCurrentDate(),
      'retargeting_remarketing' : this.gtm.fetchMarketing()
    };
    return event;
  }

  public getLang(languages): any {
    return this.gtm.fetchLangName(languages);
  }

  public getGAsubCategory(): any {
    return this.gtm.GAsubCategory;
  }

  public setContentClickDetails(xIndex, yIndex, carouselName): any {
    this.gtm.setContentClickDetails(xIndex, yIndex, carouselName);
  }

  public getContentClickDetails(): any {
    return this.gtm.getContentClickDetails();
  }

  public clearContentClickDetails(): any {
    return this.gtm.clearContentClickDetails();
  }

  public setGAsubCategory(category: any): any {
    this.gtm.GAsubCategory = category;
  }

  public apiErrorEvent(error): any {
    this.gtm.sendErrorEvent('api', error);
  }

  public storeWindowError(): any {
    this.gtm.storeWindowError();
  }

  public checkWindows(modalVideoDetails): any {

    let ua, win7orless, win8, win8point1, mobile, browser, iOSmobile, iOSversion, android, mac;
    ua = this.navigator.userAgent;
    win7orless = ua.match(/Windows NT 5.0|Windows NT 5.1|Windows NT 6.0|Windows NT 6.1|Windows NT 6.2/i) ? true : false;
    win8 = ua.match(/Windows NT 6.2/i) ? true  : false;
    win8point1 = ua.match(/Windows NT 6.3/i) ? true : false;
    mobile = ua.match(/mobile/i) ? true : false;
    android =  ua.match(/Android/i) ? true : false;
    browser = this.get_browser();
    iOSmobile = this.navigator.platform.match(/(iPhone|iPod|iPad)/i); // ios devices
    iOSversion = this.getiOSversion();
    mac = this.navigator.platform.match(/Mac/i) ? true : false;
    if (modalVideoDetails.type === 'live') {
    // if ((iOSmobile || android || browser.name.match(/firefox/i)) && modalVideoDetails.type === 'live') {
      modalVideoDetails.drm = false;
    }
    if ((modalVideoDetails.business_type === 'premium' || modalVideoDetails.business_type === 'premium_downloadable') && (browser.name.match(/UCBrowser/i) || browser.name.match(/UBrowser/i) || browser.name.match(/IE/i) || browser.name.match(/Edge/i) || browser.name.match(/EdgA/i))) {
    // if ((modalVideoDetails.business_type === 'premium' || modalVideoDetails.business_type === 'premium_downloadable') && (browser.name.match(/UCBrowser/i) || browser.name.match(/UBrowser/i)) && modalVideoDetails.type === 'vod') {
        this.errorMsg = mobile ? this.errorMessages[2] : this.errorMessages[1];
        return true;
    } else if (win7orless && browser.name.match(/IE/i) || win7orless && browser.name.match(/firefox/i) &&  browser.version <= 38 || win8 && browser.name.match(/IE/i) || modalVideoDetails.drm && browser.name.match(/UBrowser/i) || modalVideoDetails.drm && (browser.name.match(/UCBrowser/i) || browser.name.match(/IE/i))) {
      this.errorMsg = this.errorMessages[1];
      return true;
    } else if (android && browser.name.match(/firefox/i) && modalVideoDetails.drm) {
      this.errorMsg = this.errorMessages[2];
      return true;
    } else if (browser.name.match(/IE/i) && browser.version <= 10 || browser.name.match(/firefox/i) && browser.version <= 41 ) {
      this.errorMsg = this.errorMessages[0];
      return true;
    } else if (modalVideoDetails.drm) {
      if ((iOSmobile && !browser.name.match(/safari|netscape/i)) || browser.name.match(/MiuiBrowser|XiaoMi|SamsungBrowser/i)) {
      // if (iOSmobile || browser.name.match(/MiuiBrowser|XiaoMi|SamsungBrowser/i)) {
          this.errorMsg = this.errorMessages[2];
          return true;
      } else if (iOSmobile && browser.name.match(/safari|netscape/i)) { // iOS version 11.2
        if (iOSversion && iOSversion.length > 0 && iOSversion[0] >= 13) {
	// if (iOSversion && iOSversion.length > 0 && iOSversion[0] === 13) {
        // if (iOSversion && iOSversion.length > 0 && (iOSversion[0] > 11 || (iOSversion[0] === 11 && iOSversion[1] >= 2))) {
          return false;
        } else {
	  // this.errorMsg = this.errorMessages[2];
          this.errorMsg = (iOSversion && iOSversion.length > 0 && iOSversion[0] < 13) ? this.errorMessages[2] : this.errorMessages[3];
          return true;
        }
      } else if (browser.name.match(/chrome/i) && browser.version <= 58) {
        this.errorMsg = this.errorMessages[0];
        return true;
      } else if (browser.name.match(/firefox/i) && ((( win7orless && browser.version <= 48) || browser.version <= 46 ) || ( mac && browser.version <= 56))) {
        this.errorMsg = this.errorMessages[0];
        return true;
      } else if (browser.name.match(/opr/i) && (browser.version <= 46 || mobile )) {
        this.errorMsg = mobile ? this.errorMessages[2] : this.errorMessages[0];
        return true;
      // } else if (browser.name.match(/Edge/i) && browser.version <= 13 ) {
      //   this.errorMsg = this.errorMessages[0];
      //   return true;
      } else if (browser.name.match(/Edge/i) || browser.name.match(/EdgA/i)) {
        this.errorMsg = mobile ? this.errorMessages[2] : this.errorMessages[1];
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

    private getiOSversion(): any {
    if (/iP(hone|od|ad)/.test(navigator.platform)) {
      // supports iOS 2.0 and later: <https://bit.ly/TJjs1V>
      let appVer;
      appVer = (navigator.appVersion).match(/OS (\d+)_(\d+)_?(\d+)?/);
      return [parseInt(appVer[1], 10), parseInt(appVer[2], 10)];
    } else {
      return [];
    }
  }

  public get_browser(): any {
    let ua, tem, M;
    ua = this.navigator.userAgent;
    M = ua.match(/(opera|chrome|crios|safari|firefox|fxios|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
    if (/trident/i.test(M[1])) {
        tem =  /\brv[ :]+(\d+)/g.exec(ua) || [];
        return({name: 'IE', version: tem[1] || ''});
    }
    if (M[1] === 'Chrome' || M[1] === 'CriOS') {
        tem = ua.match(/\b(OPR|Edge|EdgA|UBrowser|UCBrowser|MiuiBrowser|XiaoMi|SamsungBrowser)\/(\d+)/);
        if (tem !== null) {
          return({name: tem[1], version: tem[2] || ''});
        }
    }
    M = M[2] ? [M[1], M[2]] : [this.navigator.appName, this.navigator.appVersion, '-?'];
    // if ((tem = ua.match(/version\/(\d+)/i)) != null) {
    //   M.splice(1, 1, tem[1]);
    // }
    return({name: M[0], version: M[1]});
  }

  // public inList(type, assetId): any {
  //   let storedData;
  //   if (type === 'favorite') {
  //     storedData = this.userProfileService.getFavoriteData();
  //   } else if (type === 'watchList') {
  //     storedData = this.userProfileService.getWatchData();
  //   }
  //   if (storedData) {
  //     for (let index = 0 ; index < storedData.length; index++) {
  //       if (storedData[index].id === assetId) {
  //         return true;
  //       }
  //     }
  //     return false;
  //   }
  // }

  public getImageUrl(object, cast): any {
    let width, height, background;
    width = cast ? 270 : 1242;
    height = cast ? 152 : 699;
    if (object.image) {
      if (object.asset_type === epgAssetType || object.asset_type === 9) {
        background = this.settingsService.getbasePath() + object.id + '/list/' + width + 'x' + height + '/' + object.image;
      } else if (object.asset_type === 1) {
        background = this.getEpisodeUrl(object, width, height);
      } else {
        background = this.settingsService.getbasePathNew() + object.id + '/list/' + width + 'x' + height + '/' + object.image + '?imwidth=1242&impolicy=akamai_vidz1_zee5_com-IPM';
      }
    } else {
      background = this.defaultImage;
    }
    return background;
  }

  public dateToNumString(date): any {
    let dateArray, day, month, year, months;
    months = ['Jan', 'Feb', 'Mar',
    'Apr', 'May', 'Jun', 'Jul',
    'Aug', 'Sep', 'Oct',
    'Nov', 'Dec'
    ];
    dateArray = date.split(' ');
    day = parseInt(dateArray[0], 10);
    month = dateArray[1].split(',');
    month = months.indexOf(month[0]);
    year = parseInt(dateArray[2], 10);
    date = new Date(year, month, day);
    return date;
  }

  public getEpisodeUrl(videoObject: any, width: any, height: any) {
    let date, image_url;
    image_url = this.settingsService.getbasePath() + videoObject.id + '/list/' + width + 'x' + height + '/' + videoObject.image;
    date = videoObject.release_date;
    if (date && videoObject.title_en) {
      date = this.dateToNumString(date);
      let a, b, inRange;
      a = new Date(2015, 0, 15);
      b = new Date(2017, 9, 15);
      inRange = date >= a && date <= b;
      if (inRange) {
        let dayUpdate, monthUpdate, tvshow_title, date_formatted, day, month;
        day = date.getDate();
        month = date.getMonth() + 1;
        dayUpdate = day ? ((day < 10 ? '0' + day : day)) : '';
        monthUpdate = month ? ((month < 10 ? '0' + month : month)) : '';
        date_formatted = dayUpdate.toString() + monthUpdate.toString() + date.getFullYear().toString();
        tvshow_title = videoObject.title_en.replace(/ /g, '_');
        image_url =  this.settingsService.getbasePathNew() + 'episode-images/' + tvshow_title + '_Episode_' + date_formatted + '_574x358.jpg' +  '?imwidth=' + width + '&impolicy=akamai_vidz1_zee5_com-IPM';
      }
    }
    return image_url;
  }

  public getEntitlementObject(videoObject): any {
    console.log("videoObject", videoObject)
    console.log("videoObject", videoObject.drm_keyid)
    let id, object, country, token,
    subIndex = 0,
    deviceId = null;
    token = this.localStorage.getItem('token');
    subIndex = this.getSpecificSubscription(videoObject.asset_type, videoObject.audio_languages);
    id = (videoObject.asset_type === epgAssetType || videoObject.asset_type === 9 || videoObject.type === 'live') ? videoObject.channel_id : videoObject.id;
    country = this.settingsService.getCountry();
    if (token && subIndex >= 0) {
      deviceId = this.deviceApi.identifier;
    }
    object = {
      'key_id': videoObject.drm_keyid,
      'asset_id': id,
      'token': token ? token : '',
      'persistent': false,
      'country': country, // string
      'device_id': deviceId, // device ID - 'browser',
      'entitlement_provider': 'internal',
      'request_type': 'Drm'
    };
    return object;
  }

  public getSpecificSubscription(asset_type, audLan): any {
    let activePlan;
    activePlan = this.sub.checkPlanApiSuccess(false);
    if (activePlan && activePlan.length > 0) {
      let subIndex, assetType;
      assetType = asset_type === 0 ? 0 : (asset_type === 1 ? 6 : 9);
      subIndex = activePlan.findIndex(e => e === assetType.toString());
      if (this.sub.checkAssetLang(asset_type.toString(), audLan)) {
        return subIndex;
      } else {
        return -1;
      }
    } else {
      return -1;
    }
  }

  public pageX(event): any {
    let pageX;
    if (event.type === 'touchmove') {
      pageX = event.touches[0].pageX;
    } else {
      pageX = event.pageX;
    }
    return pageX;
  }

}
