import { Injectable } from '@angular/core';
import { Headers, Http , RequestOptions, Response} from '@angular/http';
import { environment } from '../../environments/environment';


import 'rxjs/add/operator/toPromise';
import { Observable } from 'rxjs/Observable';

// Import RxJs required methods
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class FooterService {

  constructor(private http: Http) { }

	  public getFooterdata(path): Observable<any> {
      const url = environment.assetsBasePath + path;
      return this.http.get( url)
       .map(this.extractData)
       .catch(this.handleErrorObservable);
    }

    private extractData(res: Response) {
      const body = res.json();
      return body || {};

    }
    private handleErrorObservable (error: Response | any) {
      console.error(error.message || error);
      return Observable.throw(error.message || error);
    }

     public getFooterdata1(path): Observable<any> {
      const url = path;
      return this.http.get( url)
       .map(this.extractData1)
       .catch(this.handleErrorObservable1);
    }

        private extractData1(res: any) {
      const body = res;
      return body || {};

    }
    private handleErrorObservable1 (error:   any) {
      console.error(error.message || error);
      return Observable.throw(error.message || error);
    }

}
