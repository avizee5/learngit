import { Injectable } from '@angular/core';
declare const Conviva;
// declare const conviva;
import { UserApi } from '../../data/user/api/UserApi';
import { Http} from '@angular/http';
import { UserProfileService } from './user-profile.service';
import { SettingsService } from './settings.service';
import * as $ from 'jquery';
import { SubscriptionService } from '../services/subscription.service';
import {environment} from '../../environments/environment';
import { HeaderservicesService } from '../services/headerservices.service';

import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';

const episodeAssetType = 1;
const epgAssetType = 10;

@Injectable()
export class VideoAnalyticsService {
  public playerJWVendor: any = 'JW Player';
  public playerJWVersion: any = '8.17.4';
  public playerJWName: any = 'Z5 Web JWPlayer 8.17.4';
  public playerKalturaVendor: any = 'Kaltura Player';
  public playerKalturaVersion: any = '0.56.1';
  public playerKalturaName: any = 'Z5 Web Kaltura Player 0.56.1';
  public notAvailable: any = 'N/A';
  public window: any;
  public navigator: any;
  public localStorage: any;
  public loadConviva: any = false;
  public remarketingBlock: any;
  public playerInstance: any;

  private convivaVideoAnalytics: any;
  private iOSDevice: any = false;
  constructor(@Inject(PLATFORM_ID) private platformId: Object, private headerService: HeaderservicesService, private sub: SubscriptionService, private http: Http, private userProfileService: UserProfileService, private settingsService: SettingsService) {
    if (isPlatformBrowser(this.platformId)) {
      this.localStorage = localStorage;
      this.window = window;
      this.navigator = navigator;
    }
    this.checkConviva();
    this.headerService.blockeventsValue.subscribe(value => {
      this.remarketingBlock = value;
    });
    // this.iOSDevice = this.navigator.userAgent.match(/iPhone|iPad|iPod/i) ? 'JW' : 'Kaltura';
    // this.iOSDevice = this.navigator.platform.match(/(iPhone|iPod|iPad)/i) ? 'JW' : 'Kaltura';
    this.iOSDevice = 'Kaltura';
  }

  public getRemarketingBlock(): any {
    if (this.remarketingBlock !== undefined) {
      return this.remarketingBlock;
    } else {
      this.remarketingBlock = this.headerService.getRemarketing();
      return this.remarketingBlock;
    }
  }

  public checkConviva(): any {
    if (!this.loadConviva) {
      // if (this.window.conviva) {
      if (this.window.Conviva) {
        // conviva.integrate({key: environment.convivakey, enableAdBreaks: true, enableAdExperience: true});
        if (environment.envName !== 'production') {
          let settings;
          settings = {};
          settings[Conviva.Constants.GATEWAY_URL] = environment.convivaGatewayURL;
          // settings[Conviva.Constants.LOG_LEVEL] = Conviva.Constants.LogLevel.DEBUG;
          Conviva.Analytics.init(environment.convivakey, null, settings);
        } else {
          Conviva.Analytics.init(environment.convivakey, null);
        }
          // console.log('conviva -  key initialized', environment.convivaGatewayURL);
        this.loadConviva = true;
      }
      return this.loadConviva;
    } else {
      return this.loadConviva;
    }
  }
  /*
    Initialize Conviva library once player is ready
  */
  public init(): any {
      // console.log('conviva -  init');
    // if (this.checkConviva()) {
    //   conviva.setGatewayHost(environment.convivaGatewayURL);
    //   let appMetadata;
    //   appMetadata = {
    //     player_name: this.playerName,
    //   };
    //   conviva.updateAppMetadata(appMetadata);
    //   // if (!this.getRemarketingBlock()) {
    //     setTimeout(() => {this.updateUserMetaTags(false); }, 0);
    //   // }
    // }
    if (this.checkConviva()) {
      this.convivaVideoAnalytics = Conviva.Analytics.buildVideoAnalytics();
      // console.log('conviva -  init');
      // let playerInfo;
      // playerInfo = {};
      // playerInfo[Conviva.Constants.FRAMEWORK_NAME] = this.playerVendor;
      // playerInfo[Conviva.Constants.FRAMEWORK_VERSION] = this.playerVersion;
      // this.convivaVideoAnalytics.setPlayerInfo(playerInfo);
      this.updateUserMetaTags(false);
    }
  }
  /*
    Function to update user details to Conviva
  */
  public updateUserMetaTags(cast: boolean): any {
    let value, value1, age;
    value = this.getRemarketingBlock() ? undefined : this.userProfileService.getuserdata();
    if (!value) {
      /*Guest-user token */
      if (this.localStorage.getItem('guestToken') === null || this.localStorage.getItem('guestToken') === 'null') {
        this.settingsService.convivaGuestId('{"user":{"apikey":"6BAE650FFC9A3CAA61CE54D","aid":"91955485578"}}').subscribe( token => {
        this.localStorage.setItem('guestToken', JSON.parse(token._body).guest_user);
        value1 = this.userProfileService.getuserdata();
        if (value1 && value1.birthday) {
          age = new Date(value1.birthday);
          age.setTime(age.getTime() + 19800000);
          age = (new Date()).getFullYear() - age.getFullYear();
        }
        if (cast) {
          return {
            viewerId : JSON.parse(token._body).guest_user,
            viewerAge: age || this.notAvailable,
            viewerGender: (value1 ? value1.gender : '') || this.notAvailable
          };
        } else {
          this.convivaVideoAnalytics.setContentInfo({
          // conviva.updateAppMetadata({
            [Conviva.Constants.VIEWER_ID]: JSON.parse(token._body).guest_user,
            // viewer_id: JSON.parse(token._body).guest_user,
            viewerAge: (age || this.notAvailable).toString(),
            viewerGender: (value1 ? value1.gender : '') || this.notAvailable
          });
        }
        }, error => {
          if (cast) {
            return {viewerId : undefined};
          }
        });
      } else {
        value1 = this.userProfileService.getuserdata();
        if (value1 && value1.birthday) {
          age = new Date(value1.birthday);
          age.setTime(age.getTime() + 19800000);
          age = (new Date()).getFullYear() - age.getFullYear();
        }
        if (cast) {
          return {
            viewerId : this.localStorage.getItem('guestToken'),
            viewerAge: age || this.notAvailable,
            viewerGender: (value1 ? value1.gender : '') || this.notAvailable
          };
        } else {
          this.convivaVideoAnalytics.setContentInfo({
          // conviva.updateAppMetadata({
            [Conviva.Constants.VIEWER_ID]: this.localStorage.getItem('guestToken'),
            // viewer_id: this.localStorage.getItem('guestToken'),
            viewerAge: (age || this.notAvailable).toString(),
            viewerGender: (value1 ? value1.gender : '') || this.notAvailable
          });
        }
      }
      return;
    } else if (value.birthday) {
      age = new Date(value.birthday);
      age.setTime(age.getTime() + 19800000);
      age = (new Date()).getFullYear() - age.getFullYear();
    }
    if (cast) {
      return {
        viewerId: value.id || this.notAvailable,
        viewerAge: age || this.notAvailable,
        viewerGender: value.gender || this.notAvailable
      };
    } else {
      this.convivaVideoAnalytics.setContentInfo({
          // conviva.updateAppMetadata({
          [Conviva.Constants.VIEWER_ID]: value.id || this.notAvailable,
          // viewer_id: value.id || this.notAvailable,
          viewerAge: (age || this.notAvailable).toString(),
          viewerGender: value.gender || this.notAvailable
      });
    }
  }
  public setPlayer(videoElement): any {
    // console.log('conviva - setPlayer', videoElement);
    if (this.checkConviva() && this.convivaVideoAnalytics) {
      this.convivaVideoAnalytics.setPlayer(videoElement);
    }
  }
  /*
    Function to update player metadata to Conviva
  */
  public createAnalyticSession(player: any, videoObject: any, resourceUrl: any): any {
    if (!resourceUrl) {
      resourceUrl = 'NA';
    }
    if (this.checkConviva()) {
    // conviva.updatePlayerAssetMetadata(player, {
    let contentInfo;
    // contentInfo[Conviva.Constants.ENCODED_FRAMERATE] = 30;
    // contentInfo[Conviva.Constants.DURATION] = 60;
    // contentInfo[Conviva.Constants.DEFAULT_RESOURCE] = "LEVEL3";
    // contentInfo["key"] = "valueupdated";
    // contentInfo["newkey"] = "value";
    contentInfo = {
      [Conviva.Constants.ASSET_NAME]: this.getAssetName(videoObject),
      [Conviva.Constants.PLAYER_NAME]: this[`player${this.iOSDevice}Name`],
      [Conviva.Constants.STREAM_URL]: resourceUrl,
      [Conviva.Constants.IS_LIVE]: videoObject.type === 'live' ? Conviva.Constants.StreamType.LIVE : Conviva.Constants.StreamType.VOD,
      // asset_name: this.getAssetName(videoObject),
      // asset_source: resourceUrl,
      category: this.getTopCategory(videoObject.category),
      // category: videoObject.category,
      channel: this.getChannels(videoObject.channel_name) || this.notAvailable,
      catchUp : videoObject.catch_up,
      contentID: videoObject.id,
      contentType: videoObject.content_type || this.notAvailable,
      episodeName: videoObject.episode_name_en || this.notAvailable,
      episodeNumber: (videoObject.episode_no === 'NA' || !videoObject.episode_no) ? this.notAvailable : (videoObject.episode_no || '').toString() || this.notAvailable,
      genre: videoObject.genre || this.notAvailable,
      pubDate: videoObject.release_date || this.notAvailable,
      rating: (videoObject.rating || '').toString() || this.notAvailable,
      season: (videoObject.season_no || '').toString() || this.notAvailable,
      seriesID: videoObject.series_id || this.notAvailable,
      show: videoObject.title_en || this.notAvailable,
      connectionType: this.notAvailable,
      playerVendor: this[`player${this.iOSDevice}Vendor`],
      playerVersion: this[`player${this.iOSDevice}Version`],
      accessType: this.getAccessType(),
      viewingMode: this.getViewingMode(),
      clientID: this.notAvailable,
      appVersion: this.window.appVersion
    };
          // console.log('conviva -  createAnalyticSession', contentInfo);
    this.convivaVideoAnalytics.reportPlaybackRequested(contentInfo);
    }
  }

  public getCastConvivaObject(videoObject): any {
    let object, viewerDetails;
    viewerDetails = this.updateUserMetaTags(true);
    object = {
      assetName: this.getAssetName(videoObject),
      category: this.getTopCategory(videoObject.category),
      channel: this.getChannels(videoObject.channel_name),
      catchUp : videoObject.catch_up,
      contentID: videoObject.id,
      contentType: videoObject.content_type,
      episodeName: videoObject.episode_name_en || this.notAvailable,
      episodeNumber: (videoObject.episode_no === 'NA' || !videoObject.episode_no) ? this.notAvailable : videoObject.episode_no,
      genre: videoObject.genre,
      pubDate: videoObject.release_date || this.notAvailable,
      rating: videoObject.rating || this.notAvailable,
      season: videoObject.season_no,
      seriesID: videoObject.series_id,
      show: videoObject.title_en || this.notAvailable,
      connectionType: this.notAvailable,
      playerVendor: this[`player${this.iOSDevice}Vendor`],
      playerVersion: this[`player${this.iOSDevice}Version`],
      accessType: this.getAccessType(),
      clientID: this.notAvailable,
      viewerId : viewerDetails.viewerId,
      viewerAge : viewerDetails.viewerAge,
      viewerGender : viewerDetails.viewerGender,
      isLive: videoObject.type === 'live' ? true : false,
      playerName: 'Web'
    };
    return object;
  }

  public getViewingMode(): any {
    if ( navigator.userAgent.match(/mobile/i)) {
      return window.orientation === 0 ? 'Portrait' : 'Landscape';
    } else {
      return 'Landscape';
    }
  }
  /*
    Function returns access type of the program
  */
  public getAccessType(): any {
    let token, subscription;
    token = this.localStorage.getItem('token');
    subscription = this.sub.getActiveAssestType();
    if (token) {
      if (subscription && subscription.length > 0) {
        return 'Premium';
      } else {
        return 'Authenticated';
      }
    } else {
      return 'Guest';
    }
  }
  /*
    Function returns asset name of the program
  */
  public getAssetName(videoObject): any {
    let assetName;
    if (videoObject.type === 'live' || videoObject.asset_type === epgAssetType || videoObject.asset_type === 9) {
      assetName = '[' + videoObject.channel_id + '] ' + (videoObject.channel_name || this.notAvailable);
    } else if (videoObject.type === 'vod') {
      if (videoObject.asset_type === episodeAssetType) {
        assetName = '[' + videoObject.id + '] ' + (videoObject.title_en || this.notAvailable) + ' - ' + (videoObject.episode_name_en || this.notAvailable);
      } else  {
        assetName = '[' + videoObject.id + '] ' + (videoObject.title_en || this.notAvailable);
      }
    }
    return assetName;
  }
  /*
    Function returns id and asset name of the content
  */
  public getVrlAssetName(videoObject): any {
    let assetName;
    if (videoObject.type === 'live' || videoObject.asset_type === epgAssetType || videoObject.asset_type === 9) {
      if (videoObject.channel_name) {
        assetName = videoObject.channel_name;
      }
    } else if (videoObject.type === 'vod') {
      if (videoObject.asset_type === episodeAssetType) {
        if (videoObject.title_en && videoObject.episode_name_en) {
          assetName = videoObject.title_en + ' - ' + videoObject.episode_name_en;
        }
      } else  {
        if (videoObject.title_en) {
          assetName = videoObject.title_en;
        }
      }
    }
    return assetName;
  }
  public getTopCategory(category): any {
    let topCategory;
    if (category === 'tvshows' || category === 'tvshow') {
      topCategory = 'TV Show';
    } else if (category === 'movie' || category === 'movies') {
      topCategory = 'Movie';
    } else if (category === 'video' || category === 'videos') {
      topCategory = 'Video';
    } else if (category === 'original' || category === 'originals') {
      topCategory = 'Original';
    } else if (category === 'Live TV' || category === 'TV Guide') {
      topCategory = category;
    } else {
      topCategory = this.notAvailable; // category
    }
    return topCategory;
  }
  /*
    Function returns channel_name in a format required for conviva
  */
  public getChannels(channel_name): any {
    let channels = channel_name || this.notAvailable;
    if (channels === 'NA') {
      channels = this.notAvailable;
    }
    return channels;
  }
  /*
    Function to update player metadata to Conviva
  */
  public updateMetaTags(player, key, value): any {
          // console.log('conviva -  updateMetaTags', key, value);
    let tag;
    tag = {};
    tag[key] = value;
    if (tag && this.checkConviva() && this.convivaVideoAnalytics) {
      // conviva.updatePlayerAssetMetadata(player, tag);
      this.convivaVideoAnalytics.setContentInfo(tag);
    }
  }

  public reportPlaybackBitrate(event): any {
    // console.log('conviva - level - reportPlaybackMetric', event);
    let getbitrateVal = Number.isInteger(event) ? event : (((event || {}).payload || {}).selectedVideoTrack || {}).bandwidth;
    getbitrateVal /= Math.pow(1024, 1);
    if (this.checkConviva() && this.convivaVideoAnalytics && getbitrateVal) {
      this.convivaVideoAnalytics.reportPlaybackMetric(Conviva.Constants.Playback.BITRATE, getbitrateVal);
    }
  }

  public reportAdEvent(state): any {
    // console.log('conviva -  reportAdEvent', state);
    if (this.checkConviva() && this.convivaVideoAnalytics) {
      if (state === 'start') {
        this.convivaVideoAnalytics.reportAdBreakStarted(Conviva.Constants.AdType.CLIENT_SIDE, Conviva.Constants.AdPlayer.CONTENT);
        // let adBreak = {};
        // adBreak[Conviva.Constants.POD_POSITION] = this.podPosition;
        // adBreak[Conviva.Constants.POD_DURATION] = this.podDuration;
        // adBreak[Conviva.Constants.POD_INDEX] = this.podIndex;
        // convivaVideoAnalytics.reportAdBreakStarted(Conviva.Constants.AdType.CLIENT_SIDE, Conviva.Constants.AdPlayer.CONTENT, adBreak);
      } else {
        this.convivaVideoAnalytics.reportAdBreakEnded();
      }
    }
  }

  public reportErrorEvent(errorMessage): any {
    // console.log('conviva -  reportErrorEvent', errorMessage);
    if (this.checkConviva() && this.convivaVideoAnalytics) {
      this.convivaVideoAnalytics.reportPlaybackFailed(errorMessage);
      this.releaseSession();
    }
  }

  public clearAnalyticSession(): any {
    // console.log('conviva -  clearAnalyticSession');
    if (this.checkConviva() && this.convivaVideoAnalytics) {
      this.convivaVideoAnalytics.reportPlaybackEnded();
      this.releaseSession();
    }
  }

  public releaseSession(): any {
    // if (this.checkConviva() && this.convivaVideoAnalytics) {
      this.convivaVideoAnalytics.release();
      this.convivaVideoAnalytics = null;
    // }
    // Conviva.Analytics.release();
  }
  /*
    AdInsights and Player Insights
  */
  // public convivaAdMetadataUpdates(player, assetDeatails) {
  //   let playerInstance;
  //   playerInstance =  player;
  //   conviva.startMonitoring(playerInstance);
  //   playerInstance.on('playlistItem', onPlayerPlaylistItem);
  //   function onPlayerPlaylistItem() {
  //     let assetMetadata;
  //     assetMetadata = {
  //       asset_name: 'Sintel Trailer',
  //       asset_source: '/assets/sintel.mp4', // streamUrl
  //       asset_islive: false, // false for VOD
  //       asset_cdn:  'exampleCDN',
  //       asset_duration: 180,
  //       player_name: 'Test_Aplos_JWPlayer', // although you can update, we recommend to keep the same for new video asset
  //       viewer_id: '54321', // although you can update, we recommend to keep the same for new video asset
  //       my_player_name: 'Test Player',
  //       my_player_DRM: 'Yes',
  //       customTag1: 'value1',
  //       customTag2: 'value2'
  //       };
  //       conviva.updatePlayerAssetMetadata(playerInstance, assetDeatails); // update asset level metadata
  //   }
  //   playerInstance.on('error', onError);
  //   function onError() {
  //       conviva.reportPlayerError(playerInstance, 'error code', 'error message', false); // report a fatal error which stops the playback
  //   }
  // }

  // public convivaDefinedAdMetadata(player, convivaAdDefinedMetaData) {
  //   let adPlayer;
  //   adPlayer = player.plugins.googima;
  //   conviva.updatePlayerAssetMetadata(adPlayer, convivaAdDefinedMetaData);
  // }
  // public convivaAdMetaData(player, convivaAdMetaData) {
  //   conviva.updatePlayerAssetMetadata(player, convivaAdMetaData);
  // }
  // /* Funtion to update Events in Player insight Conviva */
  // public playerInsightsConviva(playerInstance, eventname, eventattributes) {
  //   if (this.checkConviva()) {
  //     // // console.log(eventname, eventattributes);
  //     if (playerInstance) {
  //       conviva.reportPlayerEvent(playerInstance, eventname, eventattributes);
  //     } else {
  //       conviva.reportAppEvent(eventname, eventattributes);
  //     }
  //   }
  // }
}
