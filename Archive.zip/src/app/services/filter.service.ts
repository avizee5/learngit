import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
// import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
// import * as api from '../../data/catalog/api/api';
// import * as $ from 'jquery';
// import { environment } from '../../environments/environment';
// import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { isPlatformBrowser } from '@angular/common';
import { SettingsService } from './settings.service';
import { HeaderservicesService } from './headerservices.service';
import { GoogleAnalyticsService } from './google-analytics.service';


// Import RxJs required methods
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
declare const qg;
import 'rxjs/add/operator/timeout';

@Injectable()
export class FilterService {
public selectedfilters: Array<any> = [];
public overlayopen: boolean;
public selectedSort: number;
public moviesGenre: Array<any> = [];
public videosGenre: Array<any> = [];
public tvshowsGenre: Array<any> = [];
public channelsGenre: Array<any> = [];
public viewName: any;
public allLanguages: Array<any> = [];
public allgenres: Array<any> = [];
public filterview: any;
public viewed = false;
public window: any;
public localstorage: any;
public qgraph: any;
 public configObservable = new Subject<any>();
 public configSortObservable = new Subject<any>();
 public configoverlayObservable = new Subject<any>();
 public networkStatus = new Subject<any>();
 public configlanObservable = new Subject<any>();
 public clickenable = new Subject<any>();
 public configcatObservable = new Subject<any>();
 public contentObservable = new Subject<any>();
 public configfooter = new Subject<any>();
 constructor(
   private headerservicesService: HeaderservicesService,
    private settingsService: SettingsService,
    private gtm: GoogleAnalyticsService,
     @Inject(PLATFORM_ID) private platformId: Object,
     // private gtm: GoogleAnalyticsService,
      // private http: Http
      ) {
 if (isPlatformBrowser(this.platformId)) {
   this.localstorage = localStorage;
   this.window = window;
   }
  this.headerservicesService.blockeventsValue.subscribe(value => {
     this.qgraph = this.headerservicesService.getRemarketing();
  });
 }
 public setQueueGraph(code): void {
  switch (code) {
     case 0: this.lan();
             this.gen();
             break;
     case 1: this.lan();
             break;
     case 3: this.gen();
              break;
     default:
     break;
  }
}
 public filterEnable(val) {
        this.clickenable.next(val);
 }
 public lan(): void {
  let lan;
  lan = this.getselected(1);
  this.qgraphevent('filtered_by_language', {'language': lan, 'country': this.settingsService.getCountry(), 'state': localStorage.getItem('state_code')});

 }
 public gen(): void {
   let gen;
   gen = this.getselected(3);
  this.qgraphevent('filtered_by_genre', {'genre': gen , 'country': this.settingsService.getCountry(), 'state': localStorage.getItem('state_code')});
  this.gtm.sendEventDetails({'event': 'genSelectedClick', 'buttonName': gen});
 }
  public qgraphevent(eventname, object) {
    if (this.window.qg) {
      this.qgraph = this.headerservicesService.getRemarketing();
      // if (this.qgraph) {
      //   delete object.country;
      //   qg('event', eventname, object);
      // } else {
        qg('event', eventname, object);
      // }
    }
  }
  public getselected(n): any {
    let selected;
    selected = this.getselectedFilters(n);
    if (n === 1) {
      selected = selected.map ( selectedItem => this.gtm.fetchLangName(selectedItem.id));
    } else {
      selected = selected.map ( selectedItem => selectedItem.id);
    }
    selected = selected.join();
    return selected;
  }
public setView(view): void {
    this.viewName = view;
}
public setLanguages(langList, view) {
  this.filterview = view;
  this.allLanguages = langList;
}
public getView(): any {
  return  this.viewName;
}
public content(n: number): any {
   this.contentObservable.next(n);
}
public showfooter(show): any {
   this.configfooter.next(show);
   return show;
}
public gettranslation(): any {
  let translation, token;
  translation = 'en';
  token = this.localstorage.getItem('token');
  if (token) {
      translation = (this.localstorage.getItem('UserDisplayLanguage') !== null && this.localstorage.getItem('UserDisplayLanguage') !== undefined) ? this.localstorage.getItem('UserDisplayLanguage') : 'en';
  } else {
      translation = (this.localstorage.getItem('display_language') !== null && this.localstorage.getItem('display_language') !== undefined) ? this.localstorage.getItem('display_language') : 'en';
  }
  return translation;
}
public setShowsGenre(arr): void {
   this.tvshowsGenre = arr;
}
public setMoviesGenre(arr): void {
  this.moviesGenre = arr;
}
public setChannelsGenre(arr): void {
  this.channelsGenre = arr;
}
public setVideosGenre(arr): void {
   this.videosGenre = arr;
}
public getShowsGenre(): any {
  return this.tvshowsGenre;
}
public getMoviesGenre(): any {
  return this.moviesGenre;
}
public getChannelsGenre(): any {
  return this.channelsGenre;
}
public getVideosGenre(): any {
  return this.videosGenre;
}
public addFilter(a: number, n: any, b: string): any {
  let check;
  check = this.selectedfilters.some(function(el) {
          return el.id === b;
          // return el.name === n;
  });
    if (!check) {
          this.selectedfilters.push({code: a, id: n, name: b});
          this.configObservable.next(this.selectedfilters);
          this.setQueueGraph(a);
          return this.selectedfilters;
    }
  }
 public getFilters(): any {
       return this.selectedfilters;
 }
 public Setcount(status): any {
     this.viewed = status;
 }
 public getcount(): any {
     return this.viewed;
 }
 public deleteAll(): any {
      this.selectedfilters = [];
      this.viewed = false;
 }
 public clearAll(): any {
      this.selectedfilters = [];
      this.configObservable.next(this.selectedfilters);
      this.setQueueGraph(0);
      return this.selectedfilters;
 }
 public deleteFilter(id: any): any {
 // public deleteFilter(i: number): any {
   let i;
   i = this.selectedfilters.findIndex(x => x.id === id);
   let code;
   code = this.selectedfilters[i].code;
   this.selectedfilters.splice(i, 1);
   this.configObservable.next(this.selectedfilters);
   this.setQueueGraph(code);
   return this.selectedfilters;
 }
 public togglelay(status: boolean): any {
   this.overlayopen = status;
   this.configoverlayObservable.next(this.overlayopen);
   return this.overlayopen;
 }
  // to update the view in filter
  public getSelectedLanguageView(): any {
    let selected, idarray;
    selected = this.getselectedFilters(1);
    idarray = this.getIds(selected);
    return idarray;
 }
  public getSelectedGenreView(): any {
    let selected, idarray;
    selected = this.getselectedFilters(3);
    idarray = this.getIds(selected);
    return idarray;
   }
 public getSelectedLanguage(): any {
   let selected, idarray;
   selected = this.getselectedFilters(1);
   idarray = this.getIds(selected);
    if (idarray.length === 0) {
         idarray = this.allLanguages;
         return idarray;
    } else {
        return idarray;
    }
 }
 public getSelectedGenre(): any {
   let selected, idarray, genre;
   selected = this.getselectedFilters(3);
   idarray = this.getIds(selected);
   genre = [];
    if (idarray.length === 0) {
       if (this.filterview === 'movies') {
             genre = this.moviesGenre;
             idarray = this.getIds(genre);
        } else if (this.filterview === 'tvshows' || this.filterview === 'zeeoriginals') {
             genre = this.tvshowsGenre;
             idarray = this.getIds(genre);
        } else if (this.filterview === 'videos') {
             genre = this.videosGenre;
             idarray = this.getIds(genre);
        } else {
             genre = this.channelsGenre;
             idarray = this.getIds(genre);
        }
        return idarray;
    }    else {
                return idarray;
    }
 }
 public getselectedFilters(n): any {
    return this.selectedfilters.filter(x => x.code === n);
 }
 public getIds(selected): any {
  let ids;
  ids = [];
   for (let i = 0; i < selected.length; i++) {
       ids.push(selected[i].id);
   }
   return ids;
 }
 public selectAll(list: any, action: any, code: number): void {
   for ( let i = 0; i <  list.length; i++) {
        let option;
        if (this.selectedfilters.findIndex(x => x.id === list[i].id) === -1 && action === 'add') {
        // if (this.selectedfilters.findIndex(x => x.name === list[i].value) === -1 && action === 'add') {
         option =  list[i];
         this.updateSelection(option, action, code);
       }
       if (this.selectedfilters.findIndex(x => x.id === list[i].id) > -1 && action === 'remove') {
       // if (this.selectedfilters.findIndex(x => x.name === list[i].value) > -1 && action === 'remove') {
         option =  list[i];
         this.updateSelection(option, action, code);

       }
    }
       this.configObservable.next(this.selectedfilters);
       this.setQueueGraph(code);
}

public updateSelection(option, action, code) {
  if (action === 'add') {
        this.addArrayFilter(option.value, option.id, code);
  } else if (action === 'remove') {
        this.removeArrayFilter(option.value, option.id, code);
        // this.removeArrayFilter(option.value);
  }
}
public addArrayFilter(b: string, n: any, a: number): void {
        this.selectedfilters.push({code: a, id: n, name: b});
}
public addarrayFilter (arr: any, status): void {
        this.selectedfilters = arr;
        this.configObservable.next(this.selectedfilters);
        if (status) {
          this.setQueueGraph(1);
        }
}
// public removeArrayFilter(selected: string) {
public removeArrayFilter(name: string, id: any, code: number) {
   let index;
   index = this.selectedfilters.findIndex(x => x.id === id);
   // index = this.selectedfilters.findIndex(x => x.name === selected);
   this.selectedfilters.splice(index, 1);
}
public setSort(n: number): any {
    this.selectedSort = n;
    this.configSortObservable.next(this.selectedSort);
    return this.selectedSort;
}
public getSort(): any {
   return this.selectedSort;
}
}
