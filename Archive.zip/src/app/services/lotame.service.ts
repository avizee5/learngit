import { Injectable } from '@angular/core';
declare const _cc13772;
import {environment} from '../../environments/environment';
import { CommonService } from '../services/common.service';
import { UserProfileService } from './user-profile.service';
import { SettingsService } from '../services/settings.service';

import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';

const unknown = 'Unknown';
const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const watchDurationRange = ['0%-25%', '25%-50%', '50%-75%', '75%-100%'];
const videoDurationRange = ['0-30mins', '31-59mins', '1-2hrs', '2hrs+'];
const epgAssetType = 10;

@Injectable()

export class LotameService {
private localStorage: any;
private window: any;

  constructor(@Inject(PLATFORM_ID) private platformId: Object, private settingsService: SettingsService, private userProfileService: UserProfileService, private commonService: CommonService) {
  	if (isPlatformBrowser(this.platformId)) {
      this.localStorage = localStorage;
      this.window = window;
    }
  }
  // constructor(@Inject(PLATFORM_ID) private platformId: Object, private headerService: HeaderservicesService, private sub: SubscriptionService, private http: Http, private userProfileService: UserProfileService, private settingsService: SettingsService) {}

  public getContentDetails(videoDetails, watchPercentage, selectedAudio): any {
  	let details, currentDate, userDetails, watchRange, dispLang, configData, genres;
  	// currentDate = Date.now();
  	currentDate = new Date();
    userDetails = this.userProfileService.getuserdata() || {};
    watchRange = Math.floor(watchPercentage / 25);
    dispLang = this.localStorage.getItem('token') ? this.localStorage.getItem('UserDisplayLanguage') : this.localStorage.getItem('display_language');
    configData = this.settingsService.getCompleteConfig();
    genres = videoDetails.genre ? videoDetails.genre.replace(', ', ',').split(',') : [];
  	details = {
			Day: days[currentDate.getDay()],
			Hour: currentDate.getHours() + 1,
			Date: currentDate.getDate(),
			Month: currentDate.getMonth() + 1,

			// ContentID: this.getContentId(videoDetails.id),
			ContentName: this.getTitle(videoDetails.asset_type, videoDetails.content_type, videoDetails.title_en, videoDetails.channel_name),
			Genre: genres,
			ContentLanguage: selectedAudio,
			Season: videoDetails.season_no,
			ContentDuration: videoDetails.asset_type !== epgAssetType ? this.getContentDurationRange(videoDetails.duration) : '',
			ContentType: videoDetails.asset_type === epgAssetType ? 'Live TV' : videoDetails.content_type,
			Cast: this.getCastDetails(videoDetails.actors),

			SubscriptionType: this.getUserType(),
			Age: this.getAgerange(userDetails) || unknown,
			Gender: (userDetails ? userDetails.gender : '') || unknown,

      QuartileViews: videoDetails.asset_type === epgAssetType ? '' : (watchRange < 4 ? watchDurationRange[watchRange] : watchDurationRange[3]),

			// City:[Value],
			State: this.localStorage.getItem('state_code'),
			Country: this.localStorage.getItem('country_code'),

			DisplayLanguage: (configData && dispLang) ? configData.languages_labels['en'][dispLang] || '' : '',

			// Device:[Value],
			// DeviceType:[Value],
			Operator:	'',
			// Platform:[Value],
  	};
  	// console.log(details);
  	this.sendDetails(details);
  }

  // private getContentId(id): any {
  //   if (id) {
  //     id = id.split('-');
  //     id.splice(0, 2);
  //     return id.join('-');
  //   } else {
  //     return;
  //   }
  // }
  private getTitle(asset_type, content_type, video_name, channel): any {
  	switch (asset_type) {
  		case 0:
  			if (content_type === 'video') {
  				return;
  			} else {
  				return video_name;
  			}
  		case 1: { // TV show name
  			return video_name;
  		}
  		case 10: {
  			return channel;
  		}
  		default:
  			return;
  	}
  }

  private getAgerange(value: any): any {
  	let age;
		if (value && value.birthday) {
      age = new Date(value.birthday);
      age.setTime(age.getTime() + 19800000);
      age = (new Date()).getFullYear() - age.getFullYear();
      age = age;
      // age = (age >= 65) ? '65+' : age.toString();
    }
    return age;
  }

  private getContentDurationRange(duration: any): any {
  	if (!duration) {
  		return;
  	}
  	duration = duration / 3600;
  	if (duration < 0.5) {
  		return videoDurationRange[0];
  	} else if (duration < 1) {
  		return videoDurationRange[1];
  	} else if (duration < 2) {
  		return videoDurationRange[2];
  	} else if (duration >= 2) {
  		return videoDurationRange[3];
  	} else {
  		return;
  	}
  }

  private getUserType(): any {
  	let userType;
  	userType = this.commonService.getUserType();
  	if (userType === 'register') {
  		return 'Registered';
  	} else {
  		return (userType[0].toUpperCase() + userType.substr(1));
  	}
  }

  private getCastDetails(actors): any {
  	let castArray;
  	castArray = [];
  	if (actors && actors.length > 0) {
  		castArray = actors.map((actor) => {
  			return actor.split(':')[0];
  		});
  		return castArray;
  	} else {
  		return castArray;
  	}
  }

  public sendDetails(details): any {
  	if (this.window._cc13772 && details && details !== {}) {
  		for (let key in details) {
			  let value;
			  value = details[key];
			  if (value && value !== ' ' && value !== 'NA') {
  			  if (key === 'Genre' || key === 'Cast') {
  			  	value.forEach((val) => {
              if (val && val !== ' ' && val !== 'NA') {
                // console.log(key + ':' + val);
                _cc13772.add('genp', key + ':' + val);
              }
  			  	});
  			  } else {
  			  	// console.log(key + ':' + value);
  			  	_cc13772.add('genp', key + ':' + value);
  			  }
        }
			}
			_cc13772.bcp();
  	}
  }
}
