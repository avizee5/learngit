import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { BehaviorSubject } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { environment } from '../../environments/environment';
import { URLSearchParams } from '@angular/http';
import { RequestMethod, RequestOptionsArgs } from '@angular/http';
import {  ResponseContentType } from '@angular/http';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import {Event, NavigationStart, NavigationEnd } from '@angular/router';
import { Router } from '@angular/router';
import { HeaderservicesService } from '../services/headerservices.service';
import * as $ from 'jquery';
declare let window;
declare const bk_addPageCtx: any;
declare const bk_doJSTag: any;

@Injectable()
export class SettingsService {
  public configValue = new Subject<any>();
  public returnConfigValue: boolean;
  public fullconfig: any;
  public quality: string;
  public countryCode: any;
  public country: any;
  public contentLang: any;
  public displayLang: any;
  public contentLangApiStatus: any;
  public guestUserToken = environment.guestUserToken;
  public carouselAdMobile: any;
  public carouselAdWeb: any;
  public countryList: any = [];
  public pageViewCounter: number;
  public pageViewBuffer: number;
  public videoViewCounter = 0;
  public browse_counter: any;
  public countryIndex: any;
  public countryValue: any;
  public countryData: any;
  public countryDataList: any;
  public settingsValue: any;
  public gdprStatus = false;
  public window: any;
  public searchVal = 0;
  public completeGetLang: any;
  public content_language_callout: any;
  public content_window: any;
  public gdprValue = new Subject<any>();
  public newCountryValue = new Subject<any>();
  public EditableData: any;
  public configdisplay: any = [];
  public contentLanId: any = [];
  public regionContentLan: any = [];
  public completedisplayLanId: any = [];
  public regionDisplayLan: any = [];
  public international_subscription: any;
  public languagepopup = new Subject<any>();
  public SelectCountryPopupValue = new BehaviorSubject<boolean>(false);
  public getCompleteConfigValues = new Subject<any>();
  public returnlanguagepopupvalue: any;
  public passcontentValue = new Subject<any>();
  public returncontent: boolean;
  public musicnodeValue = new Subject<any>();
  public returnmusicnode: boolean;
  public _pagename: any;
  public msisdnData: any;
  constructor(private http: Http, @Inject(PLATFORM_ID) private platformId: Object, private router: Router, private headerservicesService: HeaderservicesService) {
    this.router.events.filter(event => event instanceof NavigationEnd).subscribe((event: any) => {
       // console.log('route',event.url);
       if (event.url) {
           this.pageViewcheck();
           this.browse_away();
        }
  });

  if (isPlatformBrowser(this.platformId)) {
    this.window = window;
  }
    this.countryDataList = localStorage.getItem('ccode') ? JSON.parse(localStorage.getItem('ccode')) : null;

}
  public passcontentLang(a: any): any {                                         // for loginregister and user icon chnages on value
    this.returncontent = a;
    this.passcontentValue.next(this.returncontent);
    return this.returncontent;
  }
  public getpasscontentLang(): any{
    return this.returncontent;
  }
  public considerMusicnode(a:boolean): any{
    this.returnmusicnode = a;
    this.musicnodeValue.next(this.returnmusicnode);
    return this.returnmusicnode;
  }
  public getconsiderMusicnode():any{
    return this.returnmusicnode;
  }
 public configListen(a: boolean): any {                                         // for loginregister and user icon chnages on value
    this.returnConfigValue = a;
    this.configValue.next(this.returnConfigValue);
    return this.returnConfigValue;
  }

  public settabLink(value: any) {
    this.searchVal = value;
  }
   public gettabLink() {
    return this.searchVal;
  }


public gdprTraveller(status): any {
          this.gdprStatus = status;
          this.gdprValue.next(status);
          return status;
}
public getgdprTraveller(): any {
  return this.gdprStatus;
}
  public getBanner(id): Observable<any> {
    let url;
    url = environment.channelBannerApi + id;
        // url = '../assets/json/getbannerphp.json'
    return this.http.get( url)
    .map(this.extractData)
    .catch(this.handleErrorObservable);
  }
  public getLanguages(val): Observable<any> {
    let url;
    url = '../assets/json/config.json?ver=' + this.window.appVersion;
    this.fullconfig = val;
    // this.pageViewCounter = this.fullconfig.signup_events.page_views;
    // this.pageViewBuffer = this.fullconfig.signup_events.page_views;
    // this.videoViewCounter = this.fullconfig.signup_events.video_views;
    // console.log(this.pageViewCounter);
    return this.http.get( url)
    .map(this.extractData)
    .catch(this.handleErrorObservable);
  }
  public getCarouselAdPosition() {
    if (this.fullconfig && this.fullconfig.banner_ads && this.fullconfig.banner_ads.position) {
      return this.fullconfig.banner_ads.position;
    } else {
      return 4;
    }
  }
  public getCompleteConfig() {
    this.getCompleteConfigValues.next(this.fullconfig);
    return this.fullconfig;
  }

  public getbasePath(): any {
    return this.fullconfig.region.IN.India.image_url;
  }

  public getbasePathNew(): any {
    return this.fullconfig.region.IN.India.image_url_compressed;
  }

  public getConfig(item): Observable<any> {
    let url;
    url = item + '?ver=' + this.window.appVersion;
    return this.http.get( url)
    .map(this.extractData)
    .catch(this.handleErrorObservable);
  }

  // getAd(item): Observable<any> {
  //   let url
  //   url = item
  //   return this.http.get( url)
  //   .map(this.extractData)
  //   .catch(this.handleErrorObservable);
  // }

  /*From App component */
  public getCountryListValue(item): Observable<any> {
    let url;
    url = item;
    return this.http.get( url)
    .map(this.extractData)
    .catch(this.handleErrorObservable);
  }
  public setGAcounter(value) {
    this.browse_counter = value;
  }
  public browse_away() {
    if (this.browse_counter) {
      this.headerservicesService.signReminderChange(true);
      this.browse_counter = false;
    }
  }
  public setSignUpEvents(value: any): any {
    this.countryIndex = 0;
    if (value && value.length !== 0) {
       if (value[this.countryIndex] && value[this.countryIndex].signup_events) {
         if (value[this.countryIndex] && value[this.countryIndex].signup_events.page_views) {
          this.pageViewCounter = value[this.countryIndex].signup_events.page_views;
          this.pageViewBuffer = value[this.countryIndex].signup_events.page_views;
          } else {
            this.pageViewCounter = null;
            this.pageViewBuffer =  null;
          }
          if (value[this.countryIndex] && value[this.countryIndex].signup_events.video_views) {
          this.videoViewCounter = value[this.countryIndex].signup_events.video_views;
          } else {
            this.videoViewCounter = null;
          }
        } else {
          this.pageViewCounter = null;
          this.pageViewBuffer =  null;
          this.videoViewCounter = null;
        }
    } else if (this.fullconfig) {
         if (this.fullconfig.signup_events) {
        if (this.fullconfig.signup_events.page_views) {
          this.pageViewCounter = this.fullconfig.signup_events.page_views;
          this.pageViewBuffer = this.fullconfig.signup_events.page_views;
        } else {
            this.pageViewCounter = null;
            this.pageViewBuffer =  null;
          }
        if (this.fullconfig.signup_events.video_views) {
          this.videoViewCounter = this.fullconfig.signup_events.video_views;
         } else {
           this.videoViewCounter = null;
         }
    } else {

      this.pageViewCounter = null;
      this.pageViewBuffer =  null;
      this.videoViewCounter = null;
    }
  }  else {
      this.pageViewCounter = null;
      this.pageViewBuffer  = null;
      this.videoViewCounter = null;
    }
  }
  public setCountryListValue(value) {   /// on app load saving
    this.countryList = value;
  }
  public setVideoCounter(value) {
    this.videoViewCounter = value;
  }
  public getVideoCounter() {
    return this.videoViewCounter;
  }
  public getcountryApiList() {
    return this.countryList;
  }
  /******/

  // setAd(value) {
  //   this.carouselAdWeb = value.adtags;
  // }

  // returnAd() {
  //   return this.carouselAdWeb;
  // }
  // returnAdMobile() {
  //   return this.carouselAdMobile;
  // }

  public setCountry(countryCode) {
    this.countryCode = countryCode;
  }

  public setCountryValue(country) {
    this.country = country;
  }

  public getCountry() {
    return this.countryCode;
  }

  public getCountryValue() {
    return this.country;
  }
  public setContentLanguages(contentLang) {
    this.contentLang = contentLang;
     this.contentLanguageId(this.contentLang);
  }

   public setDisplayLanguages(displayLang) {
    this.displayLang = displayLang;
     this.displayLanguageId(this.displayLang);
  }

    public contentLanguageId(contentLang) {
    let configData;
    this.configdisplay = [];
    this.contentLanId = [];
    configData = this.getCompleteConfig();
      for (let i = 0; i < configData.languages.length; i++ ) {
       this.configdisplay.push(configData.languages[i].id);
      }
      for (let i = 0; i < contentLang.length; i++) {
        this.contentLanId.push(contentLang[i].l_code);

      }
      this.regionContentLan = [];
     for (let i = 0; i <  this.contentLanId.length; i++) {
        if (this.configdisplay.indexOf(this.contentLanId[i]) >= 0) {
          this.regionContentLan.push( this.contentLanId[i]);
        }
     }
    }

   public displayLanguageId(displayLang) {
    this.regionDisplayLan = [];
    this.completedisplayLanId = [];
    for (let i = 0; i < displayLang.length; i++) {
        this.completedisplayLanId.push(displayLang[i].l_code);
    }
    this.headerservicesService.storeDisplangcode(this.completedisplayLanId); // use it for first time browser lang comapred with api lang code
    for (let i = 0; i <  this.completedisplayLanId.length; i++) {
      if (this.configdisplay.indexOf(this.completedisplayLanId[i]) >= 0) {
        this.regionDisplayLan.push( this.completedisplayLanId[i]);
      }
   }

  }

   public getDisplayLanId() {
    return this.regionDisplayLan;
  }

    public getContentLanId() {
    return this.regionContentLan;
  }

  public getNonEditableLang(contentLang) {
    this.EditableData = [];
    for (let i = 0; i < contentLang.length; i++) {
      if (contentLang[i].is_editable === '0') {
       this.EditableData.push(contentLang[i].l_code);
      }
    }
    return this.EditableData;
  }
  public setCompleteGetLanguages(contentLang) {
    this.completeGetLang = contentLang;
    this.content_language_callout = this.completeGetLang && this.completeGetLang.content_language_callout ? this.completeGetLang.content_language_callout : {};
    this.content_window = this.completeGetLang && this.completeGetLang.content_window ? this.completeGetLang.content_window : {};
    this.international_subscription = this.completeGetLang && this.completeGetLang.international_subscription ? this.completeGetLang.international_subscription : {};
  }
   public getwebDesc() {
    return this.international_subscription;
  }
  public getcontentWindow() {
    return this.content_window;
  }
  public getcontentLanguageCallout() {
    return this.content_language_callout;
  }
  public getContentLanguages() {
    return this.contentLang;
  }

  public setApiStatus(status) {
    this.contentLangApiStatus = status;
  }

  public getApiStatus() {
    return this.contentLangApiStatus;
  }

  public pageViewcheck() {
    let token;
    token = localStorage.getItem('token');
     if (!token && this.pageViewCounter !== null) {
    --this.pageViewCounter;
   // console.log(this.pageViewCounter);
    if (this.pageViewCounter === 0) {
      this.pageViewCounter = this.pageViewBuffer;
      let scope;
      scope = this;
      $(document).ready(function() {
        scope.headerservicesService.signReminderChange(true);
      });
      $('#body').css('overflow', 'hidden');
      }
    }
  }
 public setCountryListNew(item): Observable<any> {
    let url;
    url = item + '&ccode=' + this.countryCode;
    this.countryData = this.http.get( url)
    .map(this.extractData)
    .catch(this.handleErrorObservable);
    return this.countryData;
  }

public getCountryListNew() {
  return this.countryData;
}
public setCountryValueNew(value) {
  if (value && value[0]) {
    localStorage.setItem('ccode', JSON.stringify(value));
  }
  this.countryDataList = value;
  this.newCountryValue.next(value);
}
public getccodeCountryValue(): any {
  return  this.countryDataList;
}
public getCountryValueNew() {
  if (this.countryDataList) {
    return  this.countryDataList;
  } else {
    let disp, userToken;
    userToken = localStorage.getItem('token');
    disp = userToken ? localStorage.getItem('UserDisplayLanguage') : localStorage.getItem('display_language');
    if (disp === null || disp === 'null') {
      disp = 'en';
    }
    this.setCountryListNew(environment.CountryListApi + disp).subscribe(value => {
      this.setCountryValueNew(value);
      return value;
    }, err => {
      let emptyObj;
      emptyObj = [];
      this.setCountryValueNew(emptyObj);
      return emptyObj;
    });
  }
}
public getCountryPromotionalValue() {
  if (this.countryDataList === undefined || this.countryDataList.length === 0) {
    let country_Data;
    country_Data = [{'promotional': {
      'on': '',
      'token': ''
    }}];
    return country_Data[0].promotional;
  } else {
    return this.countryDataList[0].promotional;
  }
}

   public getCountryList(): Observable<any> {
     if (isPlatformBrowser(this.platformId)) {
     let disp, token;
     token = localStorage.getItem('token');

     if (token) {
       disp = localStorage.getItem('UserDisplayLanguage');
     } else {
       disp = localStorage.getItem('display_language');
     }
    if (disp === null || disp === 'null') {
      disp = 'en';
    }
    let url;
    url = environment.CountryListApi + disp;
    return this.http.get( url)
    .map(this.extractData)
    .catch(this.handleErrorObservable);
  }
  }
  public getCountryIndex () {
    return this.countryIndex;
  }
  public setSettingsValue(value) {
    this.settingsValue = value;
  }
  public getSettingsValue() {
    return this.settingsValue;
  }
  public convivaGuestId(guestId: any): Observable<any> {
    const path =  this.guestUserToken;

    let queryParameters;
    queryParameters = new URLSearchParams();
    let consumes: string[];
    consumes = [];
    let produces: string[] ;
    produces = ['text/plain',
    'application/json',
    'text/json'
    ];

    const requestOptions: RequestOptionsArgs = new RequestOptions({
      method: RequestMethod.Post,
      body: guestId == null ? '' : guestId, // https://github.com/angular/angular/issues/10612
      search: queryParameters,
    });

    return this.http.request(path, requestOptions);
  }
  public embedLinkVisibility(business_type): any {
   let native_country, configData, showEmbedIcon;
   configData = this.getCompleteConfig();
    native_country = this.getCountry();
    if ((native_country === null || native_country === undefined) && localStorage.getItem('country_code') !== null) {
       native_country = localStorage.getItem('country_code');
    }
    if (configData && configData.embed_allowed_countries && (native_country !== null && native_country !== undefined)) {
      showEmbedIcon = configData.embed_allowed_countries.indexOf(native_country) > -1;
    } else {
      showEmbedIcon = false;
    }
    // showEmbedIcon = showEmbedIcon && (native_country === 'IN' || business_type.indexOf('premium') === -1);
    if (showEmbedIcon && business_type.indexOf('premium') > -1) {
      if (configData && configData.embed_premium_allowed_countries) {
        showEmbedIcon =  configData.embed_premium_allowed_countries.indexOf(native_country) > -1;
      } else {
        showEmbedIcon = false;
      }
    }
    return showEmbedIcon;
  }
  private extractData(res: Response) {
    let body;
    body = res.json();
    return body || {};
  }

  private handleErrorObservable (error: Response | any) {
    return Observable.throw(error.message || error);
  }
  public bluekaiPagename(name): void {
    let checkBluekaipage, configDataBluekai;
    configDataBluekai = this.getCompleteConfig();
    checkBluekaipage = (configDataBluekai && configDataBluekai.bluekaiEnable) ? configDataBluekai.bluekaiEnable : false;
    // console.log(checkBluekaipage, 'checkBluekaipage', configDataBluekai)
    if (checkBluekaipage === true) {
      let element;
      element = document.getElementById('blueKai');
      if (element) {
        element.parentNode.removeChild(element);
      }
      if (this.window.bk_addPageCtx && this.window.bk_doJSTag ) {
        bk_addPageCtx( 'page', name);
        bk_doJSTag(70425, 1);
      }

      let scripts , s;
      scripts = document.getElementsByTagName( 'body')[0];
      s = document.createElement( 'script');
      s.async = true;
      s.src =  'https://tags.bkrtx.com/js/bk-coretag.js';
      s.setAttribute('id', 'blueKai');
      s.setAttribute('class', 'optanon-category-C0004');
      s.setAttribute('type', this.checkCookieCategoryStatus([4]));
      scripts.appendChild(s);
    }
  }

  public checkCookieCategoryStatus(categoryIds: any = []): any {
    let status, acceptedCategories;
    status = false;
    acceptedCategories = window['OnetrustActiveGroups'];
    if (categoryIds && categoryIds.length > 0) {
      if (acceptedCategories) {status = categoryIds.every((id) => acceptedCategories.indexOf(',C000' + id + ',') !== -1); }
    }
    if (!acceptedCategories) {
      status = true;
    }
    return status ? 'text/javascript' : 'text/plain';
  }

  public callContentLangFunction(video_audio_languages, view): any {
      let  token, userContentLanguage, videoLang, pushLang = [], contentLanguages = [], contentObject;
      videoLang =  video_audio_languages;
      token = localStorage.getItem('token');
        if (token) {
          userContentLanguage = localStorage.getItem('UserContentLanguage');
        } else {
          userContentLanguage = localStorage.getItem('ContentLang');
        }
        pushLang = userContentLanguage.split(',');
          for ( let i = 0; i < pushLang.length; i++) {
            contentLanguages.push(pushLang[i]);
          }
        let languagelables , guestdisplayLanguage, userdisplayLanguage, displayLanguage, fullLang;
        languagelables = this.fullconfig.languages_labels;
        guestdisplayLanguage = localStorage.getItem('display_language');
        userdisplayLanguage = localStorage.getItem('UserDisplayLanguage');
        displayLanguage = token ? userdisplayLanguage : guestdisplayLanguage;
        fullLang = languagelables[displayLanguage][videoLang];
        let language_popup  = this.countryDataList && this.countryDataList[0].content_language_popup && this.countryDataList[0].content_language_popup.web_app ? this.countryDataList[0].content_language_popup.web_app.content_language_popup:undefined;
      if (language_popup !== undefined) {
        if (contentLanguages.indexOf(videoLang) < 0) {  // if videolang is not part of user content lang
          contentObject = {};
          let showpopup;
          if (view === 'language') {
            showpopup = true;
          } else {
            showpopup = this.getlanguagepopupValue();
          }
          contentObject = {
              'boolean': showpopup,
              'string': fullLang,
              'id': videoLang,
              'view': view
           };
          // this.Languagepopupvalue(false);
          this.headerservicesService.contentLanguageChanges(contentObject);
        } else {                                                 // if videolang is a part of user content lang
            contentObject = {
              'boolean': false,
              'string': fullLang,
              'id': videoLang,
              'view': view,
              'status': 'display'
           };
          this.headerservicesService.contentLanguageChanges(contentObject);
        }
      } else {                                                           // if no popup node from countrylist api
        if (contentLanguages.indexOf(videoLang) < 0) {
          contentObject = {};
          contentObject = {
              'boolean': true,
              'string': fullLang,
              'id': videoLang,
              'view': view
           };
          this.headerservicesService.contentLanguageChanges(contentObject);
        } else {
            contentObject = {
              'boolean': false,
              'string': fullLang,
              'id': videoLang,
              'view': view,
              'status': 'display'
           };
          this.headerservicesService.contentLanguageChanges(contentObject);
        }
      }
  }
  public Languagepopupvalue(a: any): any {                                         // for langscreen track
    this.returnlanguagepopupvalue = a;
    this.languagepopup.next(this.returnlanguagepopupvalue);
    return this.returnlanguagepopupvalue;
  }
  public getlanguagepopupValue(): any {
    // console.log('this.returnlanguagepopupvalue',this.returnlanguagepopupvalue)
    return this.returnlanguagepopupvalue;
  }

  public setpage(pagename) {
    this._pagename = pagename;
  }

  public getpage() {
    return this._pagename;
  }

  public setMsisdnData(): any {
    let robiData;
    robiData = localStorage.getItem('robiToken');
    this.msisdnData = this.parseJwt(robiData);
    if (this.msisdnData && this.msisdnData.code === '200' && this.msisdnData.token && this.msisdnData.userType !== undefined && this.msisdnData.msisdn) {
      this.msisdnData['user'] = this.msisdnData.userType === 1 ? 'existing_user' : 'new_user';
    } else {
      this.clearMsisdnData();
    }
    return this.msisdnData;
  }

  public clearMsisdnData(): any {
    localStorage.removeItem('robiToken');
    this.msisdnData = undefined;
  }

  private parseJwt(token): any {
    let jsonPayload;
    if (token) {
      // var base64Url = token.split('.')[1];
      // var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      // jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
      //     return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
      // }).join(''));
      jsonPayload = atob(token.split('.')[1]);
    }
    return jsonPayload ? JSON.parse(jsonPayload) : undefined;
  }

  public clearRobiToken(): any {
    this.clearMsisdnData();
    this.headerservicesService.robiuserChanges(false);
    localStorage.removeItem('HE_detect');
  }

  public getMsisdnData(): any {
    return this.msisdnData;
  }

}
