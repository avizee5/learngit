import { Injectable } from '@angular/core';
import { Headers, Http , RequestOptions, Response} from '@angular/http';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/toPromise';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Inject, Optional } from '@angular/core';
import { URLSearchParams } from '@angular/http';
import { RequestMethod, RequestOptionsArgs } from '@angular/http';
import {  ResponseContentType } from '@angular/http';
import { environment } from '../../environments/environment';

@Injectable()
export class UseractionapiService {
    public version: any;
    public window: any;
    public platform: any;
    public navigator: any;
	public defaultHeaders: Headers = new Headers();
  	constructor(private http: Http) {
        this.window = window;
        this.version = this.window.appVersion;
        this.navigator = navigator;
        this.platform = this.navigator.userAgent.match(/mobile|iPhone|iPod|iPad/i) ? 'Web Mobile' : 'Web Desktop';
  	}

  	public postConatctUsData(contactUsData: any): Observable<any> {
        const path =   environment.contactUs;
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        let token;
        token = localStorage.getItem('token');
        const consumes: string[] = [ ];
        const produces: string[] = [
        'text/plain',
        'application/json',
        'text/json'
        ];
        if (!token) {
            const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Post,
                body: contactUsData == null ? '' : contactUsData,
                search: queryParameters,
            });
            return this.http.request(path, requestOptions);

        } else {
            headers.append('Authorization', 'bearer ' + token);
            const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Post,
                headers: headers,
                body: contactUsData == null ? '' : contactUsData,
                search: queryParameters,
            });
            return this.http.request(path, requestOptions);
        }
    }
    public postBillDesk(billdeskdata: any, token): Observable<any> {
        const path =  environment.subscriptionbasepath + '/v1/billdesk/prepare';
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        headers.append('X-Z5-AppPlatform', this.platform);
        headers.append('X-Z5-Appversion', this.version);
        headers.append('Authorization', 'bearer ' + token);
        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
        ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
            method: RequestMethod.Post,
            headers: headers,
            body: billdeskdata == null ? '' : billdeskdata,
            search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }

    public postBilldeskData(contactUsData: any): Observable<any> {
        const path =   environment.postBillDesk;
        const queryParameters = new URLSearchParams();
        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
            ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Post,
                body: contactUsData == null ? '' : contactUsData,
                search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }

    public postBillDeskAutoRenew(user: any): Observable<any> {
        const path =  environment.billDeskAutoRenew;

        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
        ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
            method: RequestMethod.Post,
            headers: headers,
            body: user == null ? '' : user,
            search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }

    public postEntitlement(entitlementData: any): Observable<any> {
        const path =  environment.subscriptionbasepath + '/v1/entitlement';
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
         headers.append('X-Z5-AppPlatform', this.platform);
        headers.append('X-Z5-Appversion', this.version);
        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
        ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
            method: RequestMethod.Post,
            body: entitlementData == null ? '' : entitlementData, // https://github.com/angular/angular/issues/10612
            search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }
     public isEmptyObject(obj) {
          for (const key in obj) {
            return false;
          }
          return true;
    }
    public postEntitlementV3(entitlementData: any): Observable<any> {
        const path =  environment.subscriptionbasepath + '/v5/entitlement';
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
         headers.append('X-Z5-AppPlatform', this.platform);
        headers.append('X-Z5-Appversion', this.version);
        const requestOptions: RequestOptionsArgs = new RequestOptions({
            method: RequestMethod.Post,
            body: entitlementData == null ? '' : entitlementData, // https://github.com/angular/angular/issues/10612
            search: queryParameters,
        });
        return this.http.request(path, requestOptions)
        .map(this.extractData)
        .catch(this.handleErrorObservable);
    }

    public checkWatchHistory(): Observable<any> {
        const path =   environment.usernewbasepath + 'v2/watchhistory?country=' + localStorage.getItem('country_code') + '&translation=' + localStorage.getItem('UserDisplayLanguage');
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        let token, xacesstoken;
        token = localStorage.getItem('token');
        xacesstoken = localStorage.getItem('xacesstoken');
        const consumes: string[] = [ ];
        const produces: string[] = [
        'text/plain',
        'application/json',
        'text/json'
        ];
        headers.append('Authorization', 'bearer ' + token);
        headers.append('X-ACCESS-TOKEN', xacesstoken);
        const requestOptions: RequestOptionsArgs = new RequestOptions({
            method: RequestMethod.Get,
            headers: headers,
            // body: contactUsData == null ? '' : contactUsData,
            search: queryParameters,
        });
        return this.http.request(path, requestOptions)
        .map(this.extractData)
        .catch(this.handleErrorObservable);
    }

    public extractData(res: Response) {
        let body;
        body = res.json();
        return body || {};
    }
    public handleErrorObservable (error: Response | any) {
        return Observable.throw(error.message || error);
    }


    public postPaytmData(paytmData: any): Observable<any> {
        const path =  environment.postPaytm;
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
         headers.append('X-Z5-AppPlatform', this.platform);
        headers.append('X-Z5-Appversion', this.version);

        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
            ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Post,
                body: paytmData == null ? '' : paytmData,
                search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }

    public postAdyenData(adyenData: any, token, paymentProvider: any): Observable<any> {
       const path = environment.subscriptionbasepath + '/v1/${paymentProvider}/prepare'
                    .replace('${' + 'paymentProvider' + '}', String(paymentProvider));
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        headers.append('Authorization', 'bearer ' + token);

         headers.append('X-Z5-AppPlatform', this.platform);
        headers.append('X-Z5-Appversion', this.version);
        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
            ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Post,
                headers: headers,
                body: adyenData == null ? '' : adyenData,
                search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }

    public postPromotionalData(promotionalData: any, token: any): Observable<any> {
       const path = environment.subscriptionbasepath + '/v1/promotional';
        const queryParameters = new URLSearchParams();
        const headers = new Headers();

         headers.append('X-Z5-AppPlatform', this.platform);
        headers.append('X-Z5-Appversion', this.version);
        headers.append('Authorization', 'bearer ' + token);
        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
            ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Post,
                headers: headers,
                body: promotionalData == null ? '' : promotionalData,
                search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }


    public postCouponRedemptionData(coupon_code: any,  xaccess_token: any, id: any): Observable<any> {
     const path =   environment.getVerRed + '/paymentGateway/coupon/redemption';
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
         /*headers.append('X-Z5-AppPlatform', this.platform);
        headers.append('X-Z5-Appversion', this.version);*/
        let token;
        token = localStorage.getItem('token');
        const consumes: string[] = [ ];
        const produces: string[] = [
        'text/plain',
        'application/json',
        'text/json'
        ];

       if (coupon_code !== undefined) {
            coupon_code  = coupon_code;
            queryParameters.set('coupon_code', <any>coupon_code);
        }
        queryParameters.set('country_code', localStorage.getItem('country_code'));
        if (localStorage.getItem('token')) {
            queryParameters.set('translation', localStorage.getItem('UserDisplayLanguage'));
        } else {
            queryParameters.set('translation', localStorage.getItem('display_language'));
        }
         queryParameters.set('id', id);
            headers.append('AUTHORIZATION', 'bearer ' + token);
            headers.append('X-ACCESS-TOKEN', xaccess_token);
            const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Post,
                headers: headers,
                search: queryParameters,
            });
            return this.http.request(path, requestOptions);
    }


    public postVerificationData(coupon_code: any, xaccess_token: any): Observable<any> {
        const path =   environment.getVerRed + '/paymentGateway/coupon/verification';
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        let token;
        token = localStorage.getItem('token');
        const consumes: string[] = [ ];
        const produces: string[] = [
        'text/plain',
        'application/json',
        'text/json'
        ];

        if (coupon_code !== undefined) {
            coupon_code  = coupon_code;
            queryParameters.set('coupon_code', <any>coupon_code);
        }
        queryParameters.set('country_code', localStorage.getItem('country_code'));
        if (localStorage.getItem('token')) {
            queryParameters.set('translation', localStorage.getItem('UserDisplayLanguage'));
        } else {
            queryParameters.set('translation', localStorage.getItem('display_language'));
        }
            headers.append('AUTHORIZATION', 'bearer ' + token);
            headers.append('X-ACCESS-TOKEN', xaccess_token);
           /* headers.append('X-Z5-AppPlatform', this.platform);
            headers.append('X-Z5-Appversion', this.version);*/
            const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Get,
                headers: headers,
               // body: VerificationData == null ? '' : VerificationData,
                search: queryParameters,
            });
            return this.http.request(path, requestOptions);
    }



    public gettoken(): Observable<Response> {
        const path = environment.getAccessToken + '/token/platform_tokens.php?platform_name=web_app';
        let queryParameters, headers;
        queryParameters = new URLSearchParams();
        headers = new Headers(this.defaultHeaders.toJSON());
        headers.append('Authorization', 'bearer ' + localStorage.getItem('token')); // https://github.com/angular/angular/issues/6845
        // to determine the Content-Type header
        const consumes: string[] = [
        ];
        // to determine the Accept header
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
        ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
            method: RequestMethod.Get,
            headers: headers,
            search: queryParameters,
        });

        return this.http.request(path, requestOptions);
    }

    public postOrderData(translation): Observable<any> {
       const path = environment.getOrder + '/invoice/getuserorder.php';
        const queryParameters = new URLSearchParams();
        if (translation !== undefined) {
            queryParameters.set('translation', <any>translation);
        }
        const headers = new Headers();
        headers.append('Authorization', 'bearer ' + localStorage.getItem('token'));
       /* headers.append('X-Z5-AppPlatform', this.platform);
        headers.append('X-Z5-Appversion', this.version);*/

        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
            ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Get,
                headers: headers,
                body: '',
                search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }
    public postPayUData(payuData, userToken): Observable<any> {
      const path = environment.getVerRed + '/paymentGateway/payumoney';
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        headers.append('Authorization', 'bearer ' + userToken);
        headers.append('X-ACCESS-TOKEN', localStorage.getItem('xacesstoken'));
	    /*headers.append('X-Z5-AppPlatform', this.platform);
        headers.append('X-Z5-Appversion', this.version);*/
        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
            ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Post,
                headers: headers,
                body: payuData == null ? '' : payuData,
                search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }

   public payUDelete(payuDeleteData): Observable<any> {
      const path = environment.getVerRed + '/paymentGateway/cancelSubscription/' + payuDeleteData;
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        headers.append('Authorization', 'bearer ' + localStorage.getItem('token'));
        headers.append('X-ACCESS-TOKEN', localStorage.getItem('xacesstoken'));
        /*headers.append('X-Z5-AppPlatform', this.platform);
        headers.append('X-Z5-Appversion', this.version);*/
        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
            ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Delete,
                headers: headers,
                // body: payuDeleteData == null ? '' : payuDeleteData,
                search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }

    public subscriptionOffers(): Observable<any> {
      const path = environment.getSubOffer;
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        headers.append('Authorization', 'bearer ' + localStorage.getItem('token'));
        headers.append('X-ACCESS-TOKEN', localStorage.getItem('xacesstoken'));
        /*headers.append('X-Z5-AppPlatform', this.platform);
        headers.append('X-Z5-Appversion', this.version);*/
        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
            ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Get,
                headers: headers,
                // body: payuDeleteData == null ? '' : payuDeleteData,
                search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }

    public payUARStatus(payuARData): Observable<any> {
      const path = environment.payuARSatus +  '/' + payuARData;
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        headers.append('Authorization', 'bearer ' + localStorage.getItem('token'));
        headers.append('X-ACCESS-TOKEN', localStorage.getItem('xacesstoken'));
        /*headers.append('X-Z5-AppPlatform', this.platform);
        headers.append('X-Z5-Appversion', this.version);*/
        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
            ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Get,
                headers: headers,
                body: payuARData == null ? '' : payuARData,
                search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }

    public postMifeData(mifeData, userToken): Observable<any> {
        const path = environment.subscriptionbasepath + '/v1/mife/prepare';
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        headers.append('Authorization', 'bearer ' + userToken);
        /*headers.append('X-ACCESS-TOKEN', localStorage.getItem('xacesstoken'));*/
        /*headers.append('X-Z5-AppPlatform', this.platform);
        headers.append('X-Z5-Appversion', this.version);*/
        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
            ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Post,
                headers: headers,
                body: mifeData == null ? '' : mifeData,
                search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }

    public postUpgradeData(upgradeData): Observable<any> {
        const path = environment.upgradePack;
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        headers.append('Authorization', 'bearer ' + localStorage.getItem('token'));
        headers.append('X-ACCESS-TOKEN', localStorage.getItem('xacesstoken'));
        /*headers.append('X-Z5-AppPlatform', this.platform);
        headers.append('X-Z5-Appversion', this.version);*/
        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
            ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Post,
                headers: headers,
                body: upgradeData == null ? '' : upgradeData,
                search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }

    public purchaseUpgradePack(upgradePack, userToken): Observable<any> {
        const path = environment.upgradePurchase;
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        headers.append('Authorization', 'bearer ' + userToken);
        headers.append('X-ACCESS-TOKEN', localStorage.getItem('xacesstoken'));
        /*headers.append('X-Z5-AppPlatform', this.platform);
        headers.append('X-Z5-Appversion', this.version);*/
        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
            ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Post,
                headers: headers,
                body: upgradePack == null ? '' : upgradePack,
                search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }

     public paytmSendData(paytmData, userToken): Observable<any> {
     // const path = environment.payuARSatus +  '/' + payuARData;
     const path = environment.getVerRed +  '/paymentGateway/paytm';
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        headers.append('Authorization', 'bearer ' + userToken);
        headers.append('X-ACCESS-TOKEN', localStorage.getItem('xacesstoken'));
        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
            ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Post,
                headers: headers,
                body: paytmData == null ? '' : paytmData,
                search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }

    public    postNewPromoApi(promoData): Observable<any> {
        const path = environment.subscriptionbasepath + '/v2/promotion/' + promoData;
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        /*headers.append('X-Z5-AppPlatform', this.platform);
        headers.append('X-Z5-Appversion', this.version);*/
        queryParameters.set('country', localStorage.getItem('country_code'));
        if (localStorage.getItem('token')) {
            queryParameters.set('translation', localStorage.getItem('UserDisplayLanguage'));
        } else {
            queryParameters.set('translation', localStorage.getItem('display_language'));
        }
        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
            ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Get,
                headers: headers,
                body: promoData == null ? '' : promoData,
                search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }

    public subSilentLogin(loginData): Observable<any> {
     const path = environment.subSilentLogin;
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        /*headers.append('X-ACCESS-TOKEN', localStorage.getItem('xacesstoken'));
        headers.append('X-Z5-AppPlatform', this.platform);
        headers.append('X-Z5-Appversion', this.version);*/
        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
            ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Post,
                headers: headers,
                body: loginData == null ? '' : loginData,
                search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }

    public amazonSendData(amazonData, userToken): Observable<any> {
     const path = environment.getVerRed +  '/paymentGateway/amazonpay';
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        headers.append('Authorization', 'bearer ' + userToken);
        headers.append('X-ACCESS-TOKEN', localStorage.getItem('xacesstoken'));
        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
            ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Post,
                headers: headers,
                body: amazonData == null ? '' : amazonData,
                search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }

    public qwikcilverSendData(qwikcilverData, userToken): Observable<any> {
        const path = environment.getVerRed +  '/paymentGateway/qwikcilvergiftcard';
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        headers.append('Authorization', 'bearer ' + userToken);
        headers.append('X-ACCESS-TOKEN', localStorage.getItem('xacesstoken'));
        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
            ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Post,
                headers: headers,
                body: qwikcilverData == null ? '' : qwikcilverData,
                search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }

    public qwikcilverNavigate(qwikcilSendData, userToken): Observable<any> {
        const path = environment.getVerRed +  '/paymentGateway/pgResponse/qwikcilvergiftcard';
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        headers.append('Authorization', 'bearer ' + userToken);
        headers.append('X-ACCESS-TOKEN', localStorage.getItem('xacesstoken'));
        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
            ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Post,
                headers: headers,
                body: qwikcilSendData == null ? '' : qwikcilSendData,
                search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }

    /* prepare for mobile payments*/
    public sendMobileData(mobileSendData, userToken, provider): Observable<any> {
        const path = environment.getVerRed +  '/paymentGateway/' + provider + '/prepare';
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        headers.append('Authorization', 'bearer ' + userToken);
        headers.append('X-ACCESS-TOKEN', localStorage.getItem('xacesstoken'));
        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
            ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Post,
                headers: headers,
                body: mobileSendData == null ? '' : mobileSendData,
                search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }

    /* callback for mobile payments*/
    public sendOtpData(otpSendData, userToken, provider): Observable<any> {
        const path = environment.getVerRed +  '/paymentGateway/' + provider + '/callback';
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        headers.append('Authorization', 'bearer ' + userToken);
        headers.append('X-ACCESS-TOKEN', localStorage.getItem('xacesstoken'));
        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
            ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Post,
                headers: headers,
                body: otpSendData == null ? '' : otpSendData,
                search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }

    /* resend otp for mobile payments*/
    public reSendOtpData(otpResendData, userToken, provider): Observable<any> {
        const path = environment.getVerRed +  '/paymentGateway/' + provider + '/resendotp';
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        headers.append('Authorization', 'bearer ' + userToken);
        headers.append('X-ACCESS-TOKEN', localStorage.getItem('xacesstoken'));
        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
            ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Post,
                headers: headers,
                body: otpResendData == null ? '' : otpResendData,
                search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }

        /* payment history for secure payment*/
    public securePayHistory(id): Observable<any> {
        const path = environment.getVerRed +  '/paymentGateway/transaction/' + id + '/payments';
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        headers.append('Authorization', 'bearer ' + localStorage.getItem('token'));
        headers.append('X-ACCESS-TOKEN', localStorage.getItem('xacesstoken'));
        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
            ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Get,
                headers: headers,
                // body: securePayData == null ? '' : securePayData,
                search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }

    public talamoosClick(talamoosdata: any): Observable<any> {
        const path =  environment.talamoosclick;
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        // headers.append('X-Z5-AppPlatform', this.platform);
        // headers.append('X-Z5-Appversion', this.version);
        // headers.append('Authorization', 'bearer ' + token);

        if(localStorage.getItem('token')) {
         // headers.append('Authorization', localStorage.getItem('token'));
         headers.append('Authorization', localStorage.getItem('ID'));
        } else {
         headers.append('X-Z5-Guest-Token',localStorage.getItem('guestToken')); 
        }
        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
        ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
            method: RequestMethod.Post,
            headers: headers,
            body: talamoosdata == null ? '' : talamoosdata,
            search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }
    /* verify pending packs*/
    public verifyPendingPack(pendingPackData, userToken): Observable<any> {
        const path = environment.getVerRed +  '/paymentGateway/verifypaymentstatus?transaction_id=' + pendingPackData;
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        headers.append('Authorization', 'bearer ' + userToken);
        headers.append('X-ACCESS-TOKEN', localStorage.getItem('xacesstoken'));
        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
            ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Get,
                headers: headers,
                body: pendingPackData == null ? '' : pendingPackData,
                search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }

    /*list pending pack*/
     public listPendingPack(userToken): Observable<any> {
        const path = environment.getVerRed + '/paymentGateway/transaction?include_all=true';
        // const queryParameters = new URLSearchParams();
        // const headers = new Headers();
        // headers.append('Authorization', 'bearer ' + userToken);
        // headers.append('X-ACCESS-TOKEN', localStorage.getItem('xacesstoken'));

        // const path = 'https://securepaymentstag.zee5.com/paymentGateway/transaction?include_all=true';
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        headers.append('Authorization', 'bearer ' + userToken);
        // headers.append('Authorization', 'bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYmYiOjE1NTY4ODI2OTMsImV4cCI6MTU4ODQxODY5MywiaXNzIjoiaHR0cHM6Ly96NS1tcy11c2VyLWFjY2VwdGFuY2UuYXhwcm9kLm5ldCIsImF1ZCI6WyJodHRwczovL3o1LW1zLXVzZXItYWNjZXB0YW5jZS5heHByb2QubmV0L3Jlc291cmNlcyIsInN1YnNjcmlwdGlvbmFwaSIsInVzZXJhcGkiXSwiY2xpZW50X2lkIjoidG9rZW5fY2xpZW50Iiwic3ViIjoiNDBkMzNlZTItMzdkZC00ODBlLWIzZmMtNjVlNjg5Y2VkNDczIiwiYXV0aF90aW1lIjoxNTU2ODgyNjkzLCJpZHAiOiJsb2NhbCIsInVzZXJfaWQiOiI0MGQzM2VlMi0zN2RkLTQ4MGUtYjNmYy02NWU2ODljZWQ0NzMiLCJzeXN0ZW0iOiJaNSIsImFjdGl2YXRpb25fZGF0ZSI6IjIwMTgtMDctMjNUMTI6Mjc6MDkiLCJjcmVhdGVkX2RhdGUiOiIyMDE4LTA3LTE3VDA3OjEyOjU0IiwicmVnaXN0cmF0aW9uX2NvdW50cnkiOiJJTiIsInVzZXJfZW1haWwiOiJwYXJ0aG1haGVzaHdhcmkyN0BnbWFpbC5jb20iLCJ1c2VyX21vYmlsZV9ub3RfdmVyaWZpZWQiOiI5MTEyMTMxMjEyMTIiLCJzdWJzY3JpcHRpb25zIjoiW3tcImlkXCI6XCJkMzk3NzAwNy0wODQzLTRiZDktYmQyNi0yYzk0YzEwOGE3MTRcIixcInVzZXJfaWRcIjpcIjQwZDMzZWUyLTM3ZGQtNDgwZS1iM2ZjLTY1ZTY4OWNlZDQ3M1wiLFwiaWRlbnRpZmllclwiOlwiQ1JNXCIsXCJzdWJzY3JpcHRpb25fcGxhblwiOntcImlkXCI6XCIwLTExLTMyNlwiLFwiYXNzZXRfdHlwZVwiOjExLFwic3Vic2NyaXB0aW9uX3BsYW5fdHlwZVwiOlwiU1ZPRFwiLFwidGl0bGVcIjpcIkFtYXpvbiBQYXkgVGVzdCBQbGFuXCIsXCJvcmlnaW5hbF90aXRsZVwiOlwiQW1hem9uIFBheSBUZXN0IFBsYW5cIixcInN5c3RlbVwiOlwiWjVcIixcImRlc2NyaXB0aW9uXCI6XCJBbWF6b24gUGF5IFRlc3QgUGxhblwiLFwiYmlsbGluZ19jeWNsZV90eXBlXCI6XCJkYXlzXCIsXCJiaWxsaW5nX2ZyZXF1ZW5jeVwiOjMwLFwicHJpY2VcIjoxLjAsXCJjdXJyZW5jeVwiOlwiSU5SXCIsXCJjb3VudHJ5XCI6XCJJTlwiLFwiY291bnRyaWVzXCI6W1wiSU5cIl0sXCJzdGFydFwiOlwiMjAxOC0xMS0yOFQwMDowMDowMFpcIixcImVuZFwiOlwiMjAxOS0wNS0zMVQyMzo1OTo1OVpcIixcIm9ubHlfYXZhaWxhYmxlX3dpdGhfcHJvbW90aW9uXCI6ZmFsc2UsXCJyZWN1cnJpbmdcIjpmYWxzZSxcInBheW1lbnRfcHJvdmlkZXJzXCI6W3tcIm5hbWVcIjpcIlBheVRNXCJ9LHtcIm5hbWVcIjpcIkFtYXpvbnBheV9uZXdcIn0se1wibmFtZVwiOlwiUGF5VVwifV0sXCJwcm9tb3Rpb25zXCI6W10sXCJhc3NldF90eXBlc1wiOls2LDBdLFwiYXNzZXRfaWRzXCI6W10sXCJudW1iZXJfb2Zfc3VwcG9ydGVkX2RldmljZXNcIjo1LFwibW92aWVfYXVkaW9fbGFuZ3VhZ2VzXCI6W10sXCJ0dl9zaG93X2F1ZGlvX2xhbmd1YWdlc1wiOltdLFwiY2hhbm5lbF9hdWRpb19sYW5ndWFnZXNcIjpbXSxcInZhbGlkX2Zvcl9hbGxfY291bnRyaWVzXCI6dHJ1ZX0sXCJzdWJzY3JpcHRpb25fc3RhcnRcIjpcIjIwMTktMDQtMDlUMTY6MzA6NDQuNjFaXCIsXCJzdWJzY3JpcHRpb25fZW5kXCI6XCIyMDE5LTA1LTA5VDIzOjU5OjU5WlwiLFwic3RhdGVcIjpcImFjdGl2YXRlZFwiLFwicmVjdXJyaW5nX2VuYWJsZWRcIjpmYWxzZSxcInBheW1lbnRfcHJvdmlkZXJcIjpcImNybVwiLFwiZnJlZV90cmlhbFwiOm51bGwsXCJjcmVhdGVfZGF0ZVwiOlwiMjAxOS0wNC0wOVQxNjozMDo0NC42MVpcIixcImlwX2FkZHJlc3NcIjpcIjExNS4xMTMuODMuMjI3XCIsXCJjb3VudHJ5XCI6XCJJTlwiLFwicmVnaW9uXCI6XCJUZWxhbmdhbmFcIixcImFkZGl0aW9uYWxcIjp7XCJwYXltZW50bW9kZVwiOlwiQW1hem9uUGF5XCIsXCJ0cmFuc2FjdGlvbl9pZFwiOlwiMTI0ODhfNjlMajVBRFgzRmtpWWw0b1wiLFwiZGlzY291bnRfYW1vdW50XCI6XCIwLjAwMDBcIixcImZyZWVfdHJpYWxcIjpudWxsLFwicmVjdXJyaW5nX2VuYWJsZWRcIjpmYWxzZSxcIm9yaWdpbmFsX3VzZXJfYWdlbnRcIjpcIlBvc3RtYW5SdW50aW1lLzcuNi4xXCJ9LFwiYWxsb3dlZF9iaWxsaW5nX2N5Y2xlc1wiOjAsXCJ1c2VkX2JpbGxpbmdfY3ljbGVzXCI6MH1dIiwiY3VycmVudF9jb3VudHJ5IjoiSU4iLCJzY29wZSI6WyJzdWJzY3JpcHRpb25hcGkiLCJ1c2VyYXBpIl0sImFtciI6WyJkZWxlZ2F0aW9uIl19.G_fpwFT9kiYS0_VyFWnPBGCVpQCxmpj84N3tXoJgbFW_MMQ5Qmf_V9yAfTSSZZ0aojlgUiWTZxsUK3lBneyqzpYbbaZEjKUexFIhWwzgfo_YeJTj-wnt6MoBPV-GiKsOoXUOjVbOupNXC0C-1gwxDJxeJ5iM_xEizxlIM5IfIunQdnEkj-IXNcq1_cCQlt6hlzyDCFP1bMj5cc7p1zcI6ENFUeaPHdB6TJ97MG9AUudzfosQfYENUnnd3mPQhOaZGgPKCOsvK5tHGwxrNhfwTcHxlt1rBopP4oPxrl4TPuK7Jb-KfpDVHBGYWIRh_iKLc4zuTODvgDOMv1tN9HoAOg');
        headers.append('Accept', '/');
        // headers.append('Connection', 'keep-alive');
        // headers.append('Host', 'securepaymentstag.zee5.com');
        // headers.append('User-Agent', 'PostmanRuntime/7.11.0');
        headers.append('X-access-token', localStorage.getItem('xacesstoken'));
        // headers.append('accept-encoding', 'gzip, deflate');

        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
            ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Get,
                headers: headers,
               // body: pendingList == null ? '' : pendingList,
                search: queryParameters,
        });
        let resApi;
        resApi = this.http.request(path, requestOptions);
        return this.http.request(path, requestOptions);
    }

    public searchCapture(data: any, token: any) {
        const path = environment.contentEnrichmentBasePath;
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        // headers.append('Authorization', 'bearer ' + token);
        const requestOptions: RequestOptionsArgs = new RequestOptions({
            method: RequestMethod.Post,
            headers: headers,
            body: data == null ? '' : data
        });
        return this.http.request(path, requestOptions)
            .toPromise()
            .then(response => {
                return response;
            })
            .catch(error => {
                return error;
            });
    }
    public crossdevice(device_code: any, current_state: any) {
        const path = environment.crossDevice;
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        let input;
        input = JSON.stringify({'device_code': device_code, 'current_state': current_state});
        const requestOptions: RequestOptionsArgs = new RequestOptions({
            method: RequestMethod.Post,
            headers: headers,
            body: input ? input : ''
        });
    //     input = new FormData();
    //     Add your values in here
    //     input.append('device_code', device_code);
    //     input.append('current_state', current_state);
        return this.http.post(path, input).subscribe(res => {
            // console.log(res, '......................');
        },
        err => {
            // console.log(err, 'err.......................' );
        });
    }

    public checkForDeviceAuthCode(current_state) {
     let authCode;
     authCode = localStorage.getItem('deviceAuthenticateCode');
     this.crossdevice(authCode, current_state);
     if (current_state === 0) {
        localStorage.removeItem('deviceAuthenticateCode');
     }
    }

  public robiRegistration(regData): any {
    const path =  environment.headerenrichmenttelco + '/registerapi';
    const headers = new Headers();
    let accessToken;
    if (localStorage.getItem('xacesstoken') !== null) {
      accessToken = localStorage.getItem('xacesstoken');
    }
    headers.append('X-Access-Token', accessToken);
    // headers.append('Content-Type', 'application/x-www-form-urlencoded');
    headers.append('Content-Type', 'application/json');
    // const queryParameters = new URLSearchParams();
    const requestOptions: RequestOptionsArgs = new RequestOptions({
        method: RequestMethod.Post,
        headers: headers,
        body: regData == null ? '' : regData // , // https://github.com/angular/angular/issues/10612
        // search: queryParameters
    });
    return this.http.request(path, requestOptions);
    // .map(this.extractData)
    // .catch(this.handleErrorObservable);
  }

  public robiLogin(regData): any {
    const path =  environment.headerenrichmenttelco + '/loginApi';
    const headers = new Headers();
    let accessToken;
    if (localStorage.getItem('xacesstoken') !== null) {
      accessToken = localStorage.getItem('xacesstoken');
    }
    headers.append('X-Access-Token', accessToken);
    // headers.append('Content-Type', 'application/x-www-form-urlencoded');
    headers.append('Content-Type', 'application/json');
    const queryParameters = new URLSearchParams();
    regData = JSON.parse(regData);
    if (regData && regData.token) {
        queryParameters.set('token', <any>regData.token);
    }
    const requestOptions: RequestOptionsArgs = new RequestOptions({
        method: RequestMethod.Get,
        // method: RequestMethod.Post,
        headers: headers,
        // body: regData == null ? '' : regData // , // https://github.com/angular/angular/issues/10612
        search: queryParameters
    });
    return this.http.request(path, requestOptions);
    // .map(this.extractData)
    // .catch(this.handleErrorObservable);
  }

      /* prepare for mobile payments*/
    public msisdnSubscribe(data, userToken, provider): Observable<any> {
        const path = environment.headerenrichmenttelco + '/subscribeApi';
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        headers.append('Authorization', 'bearer ' + userToken);
        headers.append('X-Access-Token', localStorage.getItem('xacesstoken'));
        // headers.append('Content-Type', 'application/x-www-form-urlencoded');
        headers.append('Content-Type', 'application/json');
        const consumes: string[] = [
        ];
        const produces: string[] = [
            'text/plain',
            'application/json',
            'text/json'
            ];
        const requestOptions: RequestOptionsArgs = new RequestOptions({
                method: RequestMethod.Post,
                headers: headers,
                body: data == null ? '' : data,
                search: queryParameters,
        });
        return this.http.request(path, requestOptions);
    }

    public HE_redirect(): any {
        const path = environment.HE_detect_api;
        // const queryParameters = new URLSearchParams();
        const headers = new Headers();
        headers.append('x-access-token', localStorage.getItem('xacesstoken'));
        const requestOptions: RequestOptionsArgs = new RequestOptions({
            method: RequestMethod.Post,
            headers: headers,
        });
    //     input = new FormData();
    //     Add your values in here
    //     input.append('device_code', device_code);
    //     input.append('current_state', current_state);
        return this.http.request(path, requestOptions);
    }

    public getUserFromHexToken(hexToken): any {
        const path = environment.getDeviceUser;
        const queryParameters = new URLSearchParams();
        const headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        queryParameters.append('token', hexToken);
        const requestOptions: RequestOptionsArgs = new RequestOptions({
            method: RequestMethod.Post,
            headers: headers,
            body: queryParameters
        });
        return this.http.request(path, requestOptions)
        .map(this.extractData)
        .catch(this.handleErrorObservable);
    }

}
