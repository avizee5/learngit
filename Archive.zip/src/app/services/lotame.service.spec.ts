import { TestBed, inject } from '@angular/core/testing';

import { LotameService } from './lotame.service';

describe('LotameService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LotameService]
    });
  });

  it('should be created', inject([LotameService], (service: LotameService) => {
    expect(service).toBeTruthy();
  }));
});
