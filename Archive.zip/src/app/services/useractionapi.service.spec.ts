import { TestBed, inject } from '@angular/core/testing';

import { UseractionapiService } from './useractionapi.service';

describe('UseractionapiService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UseractionapiService]
    });
  });

  it('should be created', inject([UseractionapiService], (service: UseractionapiService) => {
    expect(service).toBeTruthy();
  }));
});
