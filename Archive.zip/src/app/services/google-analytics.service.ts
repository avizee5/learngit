import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { UserApiService } from '../services/user-api.service';
import { SettingsService } from '../services/settings.service';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { environment } from '../../environments/environment';
import { HeaderservicesService } from '../services/headerservices.service';
import * as $ from 'jquery';
declare let _comscore;
declare let ga: Function;
// declare const FB;
@Injectable()
export class GoogleAnalyticsService {

// send page name
public pageName = new Subject<any>();
public returnpageName: any;

// flag value for pages with tab
public gaFlag = new Subject<any>();
public returngaFlag: any;

// flag value for pages with tab
public gatvchannel = new Subject<any>();
public returngatvchannel: any;

public sendDetails: any;
public userType: any;
public contentLang: any;
public displayLang: any;
public getToken: any;
public fetchPageName: any;
public userToken: any;
public sendErrorDetails: any;
public sendPackImpression: any;
public sendForgotPassword: any;
public sendProductClickDetails: any;
public sendProductViewDetails: any;
public sendAutoRenewal: any;
public sendChangePasswordSuccess: any;
public sendTransactionfailure: any;
public sendAddToReminders: any;
public storeLang: any;
public contentLangName: any;
public displayLangName: any;
public sendLangName: Array<any> = [];
public tokenValue: any;
public user: any;
public sendToken: any;
public guestTokenValue: any;
public sendErrMsg: any;
public currentDate: any;
public currentTime: any;
public today: any;
public date: any;
public month: any;
public year: any;
public currentDateTime: any;
public timestampTime: any;
public timestampDateTime: any;
public localstorage: any;
public window: any;
public receivedtvchannel: any;
public sendtvchannel: any;
public searchMode: any;
public searchType: any;
public GAsubCategory: any = '';
public previousScreen: any = 'home';
public gaDisplayLang: any;
public gaContentLang: any;
public blockEvent: any;
public clientID: any;
public marketingValue: any;
public rvalue: any;

  public clickDetails: any;
  public notAvailable: any = 'NA';

  public commonDetails: any;
  public eventDetails: any;
  public previousScreenName: any;
  public previousScreenArray: any = [];
  public buttonClicksPageName: any;
  public buttonClicksPreviousScreen: any;
  constructor(private headerservicesService: HeaderservicesService, @Inject(PLATFORM_ID) private platformId: Object, private userapiService: UserApiService, private settingsService: SettingsService) {
    if (isPlatformBrowser(this.platformId)) {
        this.window = window;
        this.localstorage = localStorage;
    }

    this.headerservicesService.blockeventsValue.subscribe(value => {
      this.blockEvent = value;
    });
    this.headerservicesService.rTRMValue.subscribe(value => {
      this.rvalue = value;
    });

    this.clearContentClickDetails();
  }

  public setContentClickDetails(xIndex, yIndex, carouselName): any {
    this.clickDetails = {
      'Horizontal_Index': xIndex || (xIndex !== 0 ? this.notAvailable : xIndex),
      'Vertical_Index': yIndex || (yIndex !== 0 ? this.notAvailable : yIndex),
      'SubCategory': carouselName || this.notAvailable
    };
    // console.log(this.clickDetails, 'horizontal');
  }

  public getContentClickDetails(): any {
    return this.clickDetails;
  }

  public clearContentClickDetails(): any {
    this.clickDetails = {
      'Horizontal_Index': this.notAvailable,
      'Vertical_Index': this.notAvailable,
      'SubCategory': this.notAvailable
    };
  }

  public emitEvent(eventCategory: string, eventAction: string, eventLabel: string = null, eventValue: number) {
    ga('send', 'event', {
      eventCategory: eventCategory,
      eventLabel: eventLabel,
      eventAction: eventAction,
      eventValue: eventValue
      });
  }

  public logEvent(event: any) {
    if (event != null && this.window.dataLayer) {
      this.window.dataLayer.push(event);
    }
  }

  public fetchToken(): any {
    if (!this.blockEvent) {
      if (this.localstorage.getItem('token')) {
        this.user = this.localstorage.getItem('ID');
        if (this.user) {
          this.sendToken = this.user;
          return this.sendToken;
        } else {
          this.sendToken = 'NA';
          return this.sendToken;
        }
      } else {
        this.sendToken = this.localstorage.getItem('guestToken');
        return this.sendToken;
      }
    } else {
        this.sendToken = this.localstorage.getItem('guestToken');
        return this.sendToken;
    }
  }

  public fetchClientId(): any {
    let clientId;
    if (!this.blockEvent) {
      clientId = 'NA';
    } else {
      clientId = undefined;
    }
    return clientId;
  }

  public fetchMarketing(): any {
    let marketing, marketingSend;
    marketing = this.headerservicesService.getRemarketing();
       marketingSend = this.rvalue;
      if (marketing === null || marketing === undefined) {
        marketing = this.localstorage.getItem('BlockRTRM');
        if (marketing === null || marketing === undefined) {
          marketingSend = undefined;
        } else {
         marketingSend = this.rvalue;
       }
      } else {
        marketingSend = this.rvalue;
      }
      return marketingSend;

  }

  public setSearchValues(search_mode: any, searchType: any) {
    this.searchMode = search_mode;
    this.searchType = searchType;
  }
  // send pageName for all pages
  public sendPageName(a: any): any {
    this.returnpageName = a;
    this.pageName.next(this.returnpageName);
    return this.returnpageName;
  }

  public getPageName(): any {
    return this.returnpageName;
  }

  public refScreen(previousScreen) {
    this.previousScreen = previousScreen;
  }

  public getPreviousPageName() {
    return this.previousScreen;
  }

  // send tvchannel for pageName
  public sendTvChannel(a: any): any {
    this.returngatvchannel = a;
    this.gatvchannel.next(this.returngatvchannel);
    return this.returngatvchannel;
  }

  public getTvChannel(): any {
    return this.returngatvchannel;
  }


  // set GA Flag
  public setGaFlag(a: any): any {
    this.returngaFlag = a;
    this.gaFlag.next(this.returngaFlag);
    return this.returngaFlag;
  }

  // fetch lang name
  public fetchLangName(id: any): any {
    this.sendLangName = [];
    if (id) {
      this.storeLang = id.split(',');
    } else {
      this.storeLang = '';
    }
    let configFile , configLang;
    configFile = this.settingsService.getCompleteConfig();
    configLang = configFile.languages;
    for (let i = 0; i < configLang.length ; i++) {
      for (let j = 0; j < this.storeLang.length  ; j++) {
          if (configLang[i].id === this.storeLang[j]) {
            this.sendLangName.push(configLang[i].name);
          }
      }
    }
    return this.sendLangName.join();
  }

  // screen name sent from all pages
  public sendEvent() {
  // display/content language
    this.userToken = this.localstorage.getItem('token');
    if (this.userToken) {
      this.userType = 'loggedin';
      let settingValues;
      settingValues = this.userapiService.getSettings();
      setTimeout(() => {
        this.displayLang = settingValues[1].display_language;
        this.displayLangName = this.fetchLangName(this.displayLang);
        let c;
        c = settingValues[0].content_language;
        if (c) {
          this.contentLang = settingValues[0].content_language;
        }
          this.contentLangName = this.fetchLangName(this.contentLang);
      }, 300);
    } else {
      this.userType = 'guest';
      this.displayLang = this.localstorage.getItem('display_language');
      this.displayLangName = this.fetchLangName(this.displayLang);
      let b;
      b = this.localstorage.getItem('ContentLang');
      this.contentLang = this.localstorage.getItem('ContentLang');
      this.contentLangName = this.fetchLangName(this.contentLang);
    }
    // all details
    this.fetchPageName = this.getPageName();
    this.receivedtvchannel = this.getTvChannel();
    if ((this.receivedtvchannel !== undefined) && (this.receivedtvchannel !== '')) {
      this.sendtvchannel = this.receivedtvchannel;
    } else {
      this.sendtvchannel = 'NA';
    }
    this.tokenValue = this.fetchToken();
    this.timestampTime = this.fetchCurrentTime();
    this.timestampDateTime = this.fetchCurrentDate();
    this.clientID = this.fetchClientId();
    this.marketingValue = this.fetchMarketing();
    setTimeout(() => {
      this.sendDetails = {
        'event': 'PageView',
        'PageName': this.fetchPageName,
        'UserType': this.userType,
        'ContentLang': this.contentLangName,
        'DisplayLang': this.displayLangName,
        'NetworkType': '',
        'BitRate': '',
        'IPAddress': '',
        'GoogleID': '',
        'G_ID': this.tokenValue,
        'Client_ID': this.clientID,
        'retargeting_remarketing' : this.marketingValue,
        'TimeHHMMSS': this.timestampTime,
        'DateTimeStamp': this.timestampDateTime,
        'TVChannels': this.sendtvchannel,
        'userCountry': this.getCountryName(),
        'userCountryCode': this.localstorage.getItem('country_code'),
        'Previous_Screen': this.previousScreenName ? this.previousScreenName : 'NA'
      };
      this.logEvent(this.sendDetails);
    }, 305);
    let configFile;
    configFile = this.settingsService.getCompleteConfig();
    if (configFile && configFile.mfilter) {
      this.mfilteritFunction();  // Mfilterit Integration
    }
    this.previousScreenName = this.getPreviousScreen(this.fetchPageName);
  }

  // error event to be passed from all API errors
  public sendErrorEvent(type: any, errMsg: any) {
    let subCategory;
    subCategory = 'NA';
    this.tokenValue = this.fetchToken();
    if (type === 'api') {
      if (errMsg.name === 'TimeoutError') {
        this. sendErrMsg = errMsg.message || 'NA';
      } else {
        let status;
        status = errMsg.status;
        if (status !== 500 && status !== 404 && status !== 0) {
          try {
            this.sendErrMsg = JSON.parse(errMsg._body).message || 'NA';
          } catch (err) {
            this.sendErrMsg = 'NA';
          }
          // this.sendErrMsg =  JSON.parse(errMsg._body).message || 'NA';
        } else {
          this.sendErrMsg = errMsg.statusText || 'NA';
        }
      }
      if (this.GAsubCategory && this.getPageName().indexOf('|') !== -1) {
        subCategory = this.GAsubCategory;
      }
    } else {
      this. sendErrMsg = errMsg;
    }
    this.timestampTime = this.fetchCurrentTime();
    this.timestampDateTime = this.fetchCurrentDate();
    this.clientID = this.fetchClientId();
    this.marketingValue = this.fetchMarketing();
    this.sendErrorDetails = {
      'event': 'ErrorEvent',
      'ErrorType': type,
      'ErrorDescription': this.sendErrMsg,
      'ErrorTimings': '',
      'SubCategory': subCategory,
      'G_ID': this.tokenValue,
      'Client_ID': this.clientID,
      'retargeting_remarketing' : this.marketingValue,
      'TimeHHMMSS': this.timestampTime,
      'DateTimeStamp': this.timestampDateTime
    };
    this.logEvent(this.sendErrorDetails);
  }

  public sendProductViewDetailsEvent(event: any, name: any, id: any, price: any, position: any, currency: any, sendDurationView: any, transactionType: any, list: any, originalPrice: any) {
    this.tokenValue = this.fetchToken();
    let check;
    check  = 'check event';
    this.timestampTime = this.fetchCurrentTime();
    this.timestampDateTime = this.fetchCurrentDate();
     let packName, countryCode;
      countryCode = this.localstorage.getItem('country_code');
      packName = name + '|' + sendDurationView + '|' + countryCode + '|' + price;
      this.clientID = this.fetchClientId();
      this.marketingValue = this.fetchMarketing();
    this.sendProductViewDetails = {
       'event': event,
       'userCountry': this.getCountryName(),
       'Product Country' : this.getCountryName(),
       'Transaction Type': transactionType,
       'originalPrice': originalPrice,
       'ecommerce': {
         'currencyCode': currency,
         'G_ID': this.tokenValue,
         'Client_ID': this.clientID,
         'retargeting_remarketing' : this.marketingValue,
         'detail': {
           'actionField': {
            'dimension75': this.getCountryName(),
             'list': list
            },
           'products': [{
             'dimension75': this.getCountryName(),
             'name': packName,
             'id': id,
             'price': price,
             'brand': 'Zee5',
             'category': 'NA',
             'variant': sendDurationView.trim(),
             'position': position,
             'dimension35': sendDurationView.trim(),
             'dimension36': 'NA',
             'TimeHHMMSS': this.timestampTime,
             'DateTimeStamp': this.timestampDateTime
           }]
         }
       }
      };
     this.logEvent(this.sendProductViewDetails);
  }

  public sendAutoRenewalEvent(status: any, packName: any, packValidity: any, price: any) {
    this.tokenValue = this.fetchToken();
    this.timestampTime = this.fetchCurrentTime();
    this.timestampDateTime = this.fetchCurrentDate();
    let packNameSend, countryCode;
    countryCode = this.localstorage.getItem('country_code');
    packNameSend = packName + '|' + packValidity.trim() + '|' + countryCode + '|' + price;
    this.clientID = this.fetchClientId();
    this.marketingValue = this.fetchMarketing();
    this.sendAutoRenewal = {
      'event': 'AutoRenew',
      'AutoRenewStatus': status,
      'PackName': packNameSend,
      'PackValidity': packValidity.trim(),
      'NOSDevices': '',
      'G_ID': this.tokenValue,
      'Client_ID': this.clientID,
      'retargeting_remarketing' : this.marketingValue,
      'TimeHHMMSS': this.timestampTime,
      'DateTimeStamp': this.timestampDateTime
    };
    this.logEvent(this.sendAutoRenewal);
   }

  public storeWindowError(): any {
    let self;
    self = this;
    if (isPlatformBrowser(this.platformId)) {
      self.window = window;
    }
    self.window.onerror = function (errorMsg, url, lineNumber, column, errorObj) {
      self.sendErrorEvent('app', errorMsg);
    };
   }

   public fetchCurrentTime(): any {
     this.today = new Date();
     this.currentTime = this.today.toLocaleTimeString();
     return this.currentTime;
   }

   public fetchCurrentDate(): any {
     this.today = new Date();
     this.date = this.today.getDate();
     this.month = '0' + (this.today.getMonth() + 1).toString().substr(-2);
     this.year = this.today.getFullYear().toString().substr(-2);
     this.currentDate = this.date + '-' + this.month + '-' + this.year;
     let time;
     time = this.fetchCurrentTime();
     this.currentDateTime = this.currentDate + ' ' + time;
     return this.currentDateTime;
   }
  public mfilteritFunction(): any {
    this.window.customerID = 'NA';
    this.window.unique_ID = 'web.zeeEssel.cpv';
    this.window.campaign_ID = this.fetchPageName;
    let scope;
    scope = this;
    setTimeout(function() {
    let element;
    element = document.getElementById('mfilterit');
    if (element) {
        element.parentNode.removeChild(element);
    }
    (function() {
           let s, el;
           s = document.createElement('script'),
           el = document.getElementsByTagName('script')[0];
           s.async = true;
           s.src = 'https://fpv.mfilterit.com/fpv/visit_mf_script_zeeEssel.js';
                     s.setAttribute('id', 'mfilterit');
                     s.setAttribute('class', 'optanon-category-C0001');
                     s.setAttribute('type', scope.checkCookieCategoryStatus([1]));
                     el.parentNode.insertBefore(s, el);
                   })();
  }, 0);
  }
// comScore Tag
public comScoreFunction() {
//   let scope;
//   scope = this;
//  setTimeout(function() {
//     let element;
//     element = document.getElementById('comscore');
//     if (element) {
//         element.parentNode.removeChild(element);
//     }
//     _comscore = _comscore || [];
//     _comscore.push({ c1: '2', c2: '9254297' });
//     (function() {
//            let s, el;
//            s = document.createElement('script'),
//            el = document.getElementsByTagName('script')[0];
//            s.async = true;
//            s.src = (document.location.protocol === 'https:' ? 'https://sb' : 'http://b') + '.scorecardresearch.com/beacon.js';
//                 s.setAttribute('id', 'comscore');
//                 s.setAttribute('class', 'optanon-category-C0002');
//                 s.setAttribute('type', scope.checkCookieCategoryStatus([2]));
//                 el.parentNode.insertBefore(s, el);
//            })();
//   }, 0);
}
// zeo_mapping events
public ZeoTapingEvents(title, language, genre, type, episodenumber) {
 title = title.replace(/&/g, '%26');
 let scope;
 scope = this;
 setTimeout(function() {
    let element;
    element = document.getElementById('zeo_mapping');
    if (element) {
        element.parentNode.removeChild(element);
    }
    (function() {
           let s, el;
           s = document.createElement('script'),
           el = document.getElementsByTagName('script')[0];
           s.async = true;
          if (type === 'Movie' || type === 'Video') {
           s.src  = 'https://spl.zeotap.com/mapper.js?env=mWeb&zdid=372&zctry=India&eventType=map&zpb=' + title + '&zpbsub=' + language + '&zpbcat=' + genre + '&zpgty=' + type;
          }
          if (type === 'original' || type === 'tvshow' ) {
           s.src  = 'https://spl.zeotap.com/mapper.js?env=mWeb&zdid=372&zctry=India&eventType=map&zpb=' + title + '&zpbsub=' + language + '&zpg=' + episodenumber + '&zpbcat=' + genre + '&zpgty=' + type;
          }
           s.setAttribute('id', 'zeo_mapping');
           s.setAttribute('class', 'optanon-category-C0004');
           s.setAttribute('type', scope.checkCookieCategoryStatus([4]));
           el.parentNode.insertBefore(s, el);
    })();
  }, 0);
}

  public checkCookieCategoryStatus(categoryIds: any = []): any {
    let status, acceptedCategories;
    status = false;
    acceptedCategories = window['OnetrustActiveGroups'];
    // if (categoryId) {
    //   let acceptedCategories;
    //   acceptedCategories = window['OnetrustActiveGroups'];
    //   if (acceptedCategories) {
    //     status = (acceptedCategories.indexOf(',C000' + categoryId + ',') !== -1) ? true : false;
    //   }
    // } else
    if (categoryIds && categoryIds.length > 0) {
      if (acceptedCategories) {status = categoryIds.every((id) => acceptedCategories.indexOf(',C000' + id + ',') !== -1); }
    }
    if (!acceptedCategories) {
      status = true;
    }
    return status ? 'text/javascript' : 'text/plain';
  }

  public displayContentLan(): any {
     let displayLang, contentLang, langObj;
     displayLang = '';
     contentLang = '';
     displayLang = this.localstorage.getItem('token') ? this.localstorage.getItem('UserDisplayLanguage') : this.localstorage.getItem('display_language');
     contentLang = this.localstorage.getItem('token') ? this.localstorage.getItem('UserContentLanguage') : this.localstorage.getItem('ContentLang');
     this.gaContentLang = this.fetchLangName(contentLang);
     this.gaDisplayLang = this.fetchLangName(displayLang);
     langObj = {
       'displayLang' : this.gaDisplayLang,
       'contentLang' : this.gaContentLang
     };
     return langObj;

  }
  public FacebookInitialization(): any {
    if (this.window) {
      if (this.window.FB) {
      this.window.FB.init({
        appId: environment.fbappId,
        cookie: false,  // enable cookies to allow the server to access // the session
        xfbml: true,  // parse social plugins on this page
        version: 'v2.10' // use graph api version 2.5
    });
    }
  }

  }

    public getCountryName(): any {
    let countryValue, countryName;
    countryValue = this.settingsService.getCountryValue();
    countryName = countryValue && countryValue.country ?countryValue.country:'NA';
    return countryName;
  }

    // append campaign for register
    public checkUpdateCampaign(dataRec: any): any {
    let checkCamVal, appendData, sendData, sendAdd, addDetails, sendPost;
    checkCamVal = JSON.parse(this.localstorage.getItem('campaignDetails'));
    addDetails = dataRec.additional;
    if (checkCamVal !== undefined && checkCamVal !== null) {
      appendData = {
          'campaign' : checkCamVal.campaignData
        };
      sendData = $.extend({}, addDetails, appendData);
      sendAdd = {
        'additional' : sendData
      };
      sendPost = $.extend({}, dataRec, sendAdd);
      return sendPost;

    } else {
      sendAdd = dataRec;
      return sendAdd;

    }
  }

  /* Minutely GA events*/
  public minutelyGA(rurl): any {
    // console.log('minute_ly function call', rurl);
    // let rurl;
    // rurl = 'https://staging5.zee5.com/zee5originals/details/parchhayee-ghost-stories-by-ruskin-bond/0-6-1258';
   // rurl = 'https://staging5.zee5.com/tvshows/details/daayan/0-6-1202/daayan-episode-24-march-03-2019-full-episode/0-1-182762';

    let recPara, sendMinData, userType, displayLang, contentLang, videoName, videoSec, previous;
    recPara = [];
    recPara = rurl.split('/');


     // language code removal
      let y, x;
      y = this.localstorage.getItem('token');
      if (y) {
        x = this.localstorage.getItem('UserDisplayLanguage');
      } else {
        x = this.localstorage.getItem('display_language');
      }
      if (x === 'en' || x === null) {
        previous = recPara;
      } else if (recPara[3] === x) {
        recPara.splice(3, 1);
      }
      // language code removal


    // console.log(recPara.length, 'minute_ly array', recPara);
    videoName = (recPara.length > 7 ) ? (recPara[7]) : (recPara[5]);
    videoSec = recPara[3];
    // console.log('minute_ly videoName', videoName, 'videoSec', videoSec);
    this.tokenValue = this.fetchToken();
    this.timestampTime = this.fetchCurrentTime();
    this.timestampDateTime = this.fetchCurrentDate();
    this.userToken = this.localstorage.getItem('token');
    userType = (this.userToken) ? ('loggedin_user') : ('guest_user');
    this.fetchPageName = this.getPageName();
    // console.log('this.fetchPageName', this.fetchPageName);
    displayLang = this.userToken ? this.localstorage.getItem('UserDisplayLanguage') : this.localstorage.getItem('display_language');
    contentLang = this.userToken ? this.localstorage.getItem('UserContentLanguage') : this.localstorage.getItem('ContentLang');
    sendMinData = {
      'event': 'videoPreview',
      'VideoName': videoName,  // to be taken from url show name/ epiosode name
      'VideoCategory': videoSec,  // id form url (0-6-..,0-1-..,0-0-...) pass Movie/Video for 0, tvshow for 6, epsiode for 1
      'VideoSection': videoSec,  // from URL eg: tvshow/details etc
      'VideoSubTitle': 'NA',
      'Client_ID': 'NA',
      'GoogleID': this.tokenValue, // global var
      'TimeHHMMSS': this.timestampTime,
      'DateTimeStamp': this.timestampDateTime,
      'UserType': userType, // will send guest_user , loggedin_user
      'PageName': this.fetchPageName, // taken from videoSection
      'ContentLang': this.fetchLangName(contentLang), // will send
      'DisplayLang': this.fetchLangName(displayLang), // will send
      'NetworkType': 'NA', // NA
      'BitRate': 'NA', // NA
      'IPAddress':  'NA', // NA
      'TVChannels':  'NA', // NA
      'SubCategory':  'NA', // NA
      'carousIndex':  'NA', // NA
      'Time_Slot':  'NA', // NA
      'Content_Specification': videoSec, // taken form videoCategory
      'Content_Date':  'NA' // A
    };
    // console.log('sendMinData', sendMinData);
    this.logEvent(sendMinData);
  }

  /* Talamoos GA events*/
  public talamoosGA(yIndex, bucketTitle): any {
    let details, userType, displayLang, contentLang, previousScreenName;

    this.userToken = this.localstorage.getItem('token');
    userType = (this.userToken) ? ('loggedin') : ('guest');
    // userType = (this.userToken) ? ('loggedin_user') : ('guest_user');
    this.fetchPageName = this.getPageName();
    displayLang = this.userToken ? this.localstorage.getItem('UserDisplayLanguage') : this.localstorage.getItem('display_language');
    contentLang = this.userToken ? this.localstorage.getItem('UserContentLanguage') : this.localstorage.getItem('ContentLang');
    // if (this.eventDetails.event === 'hamburgerMenu') {
    //   if (this.eventDetails.HamburgerMenu === 'Hamburger Icon') {
        previousScreenName = this.previousScreenArray[0];
    //   }
    //   if (this.window.innerWidth <= 480 && this.eventDetails.HamburgerMenu !== 'Hamburger Icon') {
    //     previousScreenName = 'Hamburger menu';
    //   }
    // }

    details = {
      'event': 'talamoosImpression',
      'UserType': userType, // 'guest or loggedin',
      'ContentLang': this.fetchLangName(contentLang),
      'DisplayLang': this.fetchLangName(displayLang),
      'NetworkType': 'NA',
      'GoogleID': this.fetchToken(),
      // 'Content_Specification': 'NA',
      // 'Content_Show': 'NA',
      // 'Content_Date': 'NA',
      'PageName': this.fetchPageName,
      'Vertical_Index': yIndex,
      // 'TopCategory': 'NA',
      'SubCategory': bucketTitle,
      'Previous_Screen': previousScreenName ? previousScreenName : 'NA',
      'TimeHHMMSS': this.fetchCurrentTime(),
      'DateTimeStamp': this.fetchCurrentDate(),
      'Client_ID': 'NA'
    };
    // console.log('details', details);
    this.logEvent(details);
  }


  // get TargetAudienceValue
  public getTarAud(): any {
    let countryCode, tarAud;
    countryCode = this.localstorage.getItem('country_code');
    tarAud = (countryCode === 'IN') ? ('domestic') : ('international');
    return tarAud;
  }

  // send ga data for resendLink
  public sendResendLinkData(): any {
    let data, pageName, idValue, tarAud;
    pageName = this.getPageName();
    idValue = this.fetchToken();
    tarAud = this.getTarAud();
    this.timestampTime = this.fetchCurrentTime();
    this.timestampDateTime = this.fetchCurrentDate();
    this.userToken = this.localstorage.getItem('token');
    if (this.userToken) {
      this.userType = 'loggedin';
      let settingValues;
      settingValues = this.userapiService.getSettings();
      setTimeout(() => {
        this.displayLang = settingValues[1].display_language;
        this.displayLangName = this.fetchLangName(this.displayLang);
        let c;
        c = settingValues[0].content_language;
        if (c) {
          this.contentLang = settingValues[0].content_language;
        }
          this.contentLangName = this.fetchLangName(this.contentLang);
      }, 300);
    } else {
      this.userType = 'guest';
      this.displayLang = this.localstorage.getItem('display_language');
      this.displayLangName = this.fetchLangName(this.displayLang);
      let b;
      b = this.localstorage.getItem('ContentLang');
      this.contentLang = this.localstorage.getItem('ContentLang');
      this.contentLangName = this.fetchLangName(this.contentLang);
    }
    data = {
      'event': 'resendLink',
      'PageName': pageName,
      'UserType': this.userType,
      'ContentLang': this.contentLangName,
      'DisplayLang': this.displayLangName,
      'NetworkType': '',
      'axinomID': idValue,
      'refScreen':  pageName,
      'TimeStamp': this.timestampTime,
      'DateTimeStamp': this.timestampDateTime,
      'TargetAudience': tarAud
    };
    this.logEvent(data);

  }

  public myGPloginEvent(): any {
    let sendData;
    sendData = {
      'event' : 'LoginSuccess',
      'G_ID' : this.fetchToken(),
      'Client_ID': this.fetchClientId(),
      'retargeting_remarketing' : this.fetchMarketing(),
      'LoginMethod' : this.localstorage.getItem('login') || 'Mobile',
      'operator' : 'NA',
      'TimeHHMMSS': this.fetchCurrentTime(),
      'DateTimeStamp': this.fetchCurrentDate()
    };
    this.appendPara('LoginSuccess', sendData);
  }

  // append parameters for register/login
  public appendPara(value: any, recObj: any): any {
    let appendMethod, postdata, tarAud;
    tarAud = this.getTarAud();
    if (value.toLowerCase() === 'registersuccess') {
      // register event
      appendMethod = {
        'registerCount': 1,
        'targetAudience': tarAud
      };
    } else if (value.toLowerCase() === 'loginsuccess') {
      // login event
      appendMethod = {
        'loginCount': 1,
        'targetAudience': tarAud
      };
    }
    postdata = $.extend({}, recObj, appendMethod);
    this.logEvent(postdata);
  }
  // fetch previous screen name
  public getPreviousScreen(pageName) {
    this.previousScreenArray.push(pageName);
    if (this.previousScreenArray.length > 2) {
      this.previousScreenArray.shift();
    }
    return this.previousScreenArray[0];
  }
  /* Events to be added to GA (ZP11-1390)*/
  public sendEventDetails(details) {
    this.buttonClicksPageName = this.getPageName();
    this.buttonClicksPreviousScreen = this.previousScreenName;
    setTimeout(() => {
      this.eventDetails = details;
      this.sendEventsToBeAdded();
    }, 500);
  }
  public sendEventsToBeAdded() {
    this.userToken = this.localstorage.getItem('token');
    this.fetchPageName = (this.eventDetails.headerTab === 'Help') ? 'help' : this.getPageName();
    if (this.userToken) {
      this.userType = 'loggedin';
      let settingValues;
      settingValues = this.userapiService.getSettings();
      this.displayLang = settingValues[1].display_language;
      this.displayLangName = this.fetchLangName(this.displayLang);
      let c;
      c = settingValues[0].content_language;
      if (c) {
        this.contentLang = settingValues[0].content_language;
      }
      this.contentLangName = this.fetchLangName(this.contentLang);
    } else {
      this.userType = 'guest';
      this.displayLang = this.localstorage.getItem('display_language');
      this.displayLangName = this.fetchLangName(this.displayLang);
      this.contentLang = this.localstorage.getItem('ContentLang');
      this.contentLangName = this.fetchLangName(this.contentLang);
    }
    this.tokenValue = this.fetchToken();
    this.commonDetails = {
      'PageName': this.fetchPageName,
      'UserType': this.userType,
      'ContentLang': this.contentLangName,
      'DisplayLang': this.displayLangName,
      'NetworkType': '',
      'GoogleID': this.tokenValue,
      'Previous_Screen': this.previousScreenName ? this.previousScreenName : 'NA'
    };
    if (this.eventDetails.event === 'pageComponentInteractions' || this.eventDetails.event === 'buttonClicks' || this.eventDetails.event === 'doneButtonClick' || this.eventDetails.event === 'scrollTracking' || this.eventDetails.event === 'genSelectedClick' || this.eventDetails.event === 'sortOptionClick') {
      this.eventDetails = $.extend({}, this.eventDetails, this.commonDetails);
    }
    if ($.inArray(this.eventDetails.event, ['swipeClick', 'buttonClicks', 'doneButtonClick', 'searchCrossClicks', 'hamburgerMenu', 'searchResultClick', 'userIconClick', 'profileClicks', 'genSelectedClick', 'sortOptionClick', 'MoreMenuClick']) !== -1) {
      if (this.eventDetails.event === 'hamburgerMenu' && this.window.innerWidth <= 480 && this.eventDetails.HamburgerMenu !== 'Hamburger Icon') {
        this.buttonClicksPreviousScreen = this.buttonClicksPageName;
        this.buttonClicksPageName = 'Hamburger menu';
      }
      this.eventDetails = $.extend({}, this.eventDetails, {'PageName': this.buttonClicksPageName, 'Previous_Screen': this.buttonClicksPreviousScreen});
    }
    if (this.eventDetails.PopupType === 'subscription_card') {
      this.eventDetails = $.extend({}, this.eventDetails, {'UserType': this.userType});
    }
    if (this.eventDetails.event === 'searchTerm')  {
      this.eventDetails = $.extend({}, this.eventDetails, {'refScreen': this.previousScreenName});
    }
    if (this.eventDetails) {
      this.logEvent(this.eventDetails);
      this.eventDetails = null;
    }
  }
  /* Events to be added to GA (ZP11-1390)*/
}
