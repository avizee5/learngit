import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

// declare let jsInterface: any;
// declare let webkit: any;
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';

@Injectable()
export class HeaderservicesService {
public dispLangcode = [];
public contentLanguageValue = new Subject<any>();
public returnContentlanguage: any;

public languageScreen = new Subject<any>();
public returnlanguageScreen: any;

public weyyakValue = new Subject<any>();
public returnweyyak: boolean;

public launchOfferValue = new Subject<any>();
public returnlaunchOffer: any;

public registerValue = new Subject<any>();
public returnRegister: boolean;

public headerScrollValue = new Subject<any>();
public returnHeaderScroll: boolean;

public dialogValue = new Subject<any>();
public returnDialogUserCheck: any;

public moreValue = new Subject<any>();
public returnMore: boolean;

public searchValue = new Subject<any>();
public returnSearch: boolean;

public languageValue = new Subject<any>();
public returnLanguage: boolean;

public contentlanValue = new Subject<any>();
public returncontentLan: boolean;

public modelValue = new Subject<any>();
public returnModel: boolean;

public spotlightValue = new Subject<any>();
public returnspotlight: boolean;

public profileDropValue = new Subject<any>();
public returnprofileDrop: any;

public parentalValue = new Subject<any>();
public returnparental: any;

public routeParamValue = new Subject<any>();
public returnrouteParam: any;

public breadcrumpValue = new Subject<any>();
public returnbreadcrump: any;
public cookieOptionValue  = new Subject<any>();
public returnCookieoption: any;
// for signin pop up
public signinValue = new Subject<any>();
public internationalRegisterValue = new Subject<any>();
public returnSignin: boolean;
public returnInternationalRegister: boolean;
public signinValueLeft = new Subject<any>();
public returnsigninValueLeft: boolean;
public signinRightTopValue = new Subject<any>();
public returnsigninRightTopValue: boolean;
public bgImageValue = new Subject<any>();
public returnbgImageValue: boolean;
public registerMobileValue = new Subject<any>();
public returnRegisterMobileValue: boolean;
public signInDetailValue = new Subject<any>();
public returnsignInDetailValue: boolean;
public loginHeadingValue = new Subject<any>();
public returnloginHeadingValue: boolean;
public registerHeadingValue = new Subject<any>();
public returnregisterHeadingValue: boolean;
public loginMobileValue = new Subject<any>();
public returnloginMobileValue: boolean;
public loginEmailValue = new Subject<any>();
public returnloginEmailValue: boolean;
public loginComponentValue = new Subject<any>();
public returnloginComponentValue: boolean;
public pofileActivationValue = new Subject<any>();
public returnPofileActivationValue: boolean;
public buttonChangeValue = new Subject<any>();
public returnButtonChangeValue: boolean;
public verificationEmailValue = new Subject<any>();
public returnverificationEmailValue: boolean;
public verificationMobileValue = new Subject<any>();
public returnverificationMobileValue: boolean;
public forgotEmailValue = new Subject<any>();
public returnforgotEmailValue: boolean;
public forgotMobileValue = new Subject<any>();
public returnforgotMobileValue: boolean;
public registerSuccessValue = new Subject<any>();
public returnRegisterSuccessValue: boolean;
public loginPageValue = new Subject<any>();
public returnloginPageValue: boolean;
public internationalloginPageValue = new Subject<any>();
public returnInternationalloginValue: boolean;
public otherContainerFlagValue = new Subject<any>();
public returnOtherContainerFlagValue: boolean;
public iconFlagValue = new Subject<any>();
public returnIconFlagValue: boolean;
public registerPageValue = new Subject<any>();
public returnRegisterPageValue: boolean;
// public personalizeReloadValue = new Subject<any>();
// public returnPersonalizeReloadValue: boolean;

public cookiesCheckValue = new Subject<any>();
public returnCookiesCheckValue: boolean;
public dialogCheckValue = new Subject<any>();
public returnDialogCheckValue: boolean;
public menuOptionValue = new Subject<any>();
public returnMenuoption: boolean;
public footerOptionValue = new Subject<any>();
public returnFooteroption: boolean;

public rTRMValue = new Subject<any>();
public returnRTRM: any;

public rTRMCountryValue = new Subject<any>();
public returnRTRMCountry: any;
public blockeventsValue = new Subject<any>();
public returnBlockevents: any;
public blockEvents: any;
// for info pop up in subscription
public subInfoValue = new Subject<any>();
public returnsubInfo: boolean;

// for view details in info card, subscription
public subViewPackValue = new Subject<any>();
public returnsubViewPack: boolean;

// for close gaana pack in subscription
public closePackChangeValue = new Subject<any>();
public returnClosePackChange: boolean;

// for active subscription popup
public subscriptionChangeValue = new Subject<any>();
public returnsubscriptionChangeValue: boolean;

// for summary edit img in subscription
public subEditSummaryValue = new Subject<any>();
public returnsubEditSummary: boolean;

// for search result in subscription
public subPaymentValue = new Subject<any>();
public returnsubPaymentValue: boolean;

// for unsubscribe popup in subscription
public subUnsubscribeValue = new Subject<any>();
public returnsubUnsubscribeValue: boolean;

// for view details popup in info card
public infoView = new Subject<any>();
public returninfoView: any;

// store final amount
public amountPayable = new Subject<any>();
public returnamountPayable: any;


// to send details in info view of subscription
public popUpDetails = new Subject<any>();
public returnpopUpDetails: any;

// to show subscription plans in subscription
public displayPlan = new Subject<any>();
public returndisplayPlan: any;

// to show selected plan in subscription
public displaySelectedPlan = new Subject<any>();
public returndisplaySelectedPlan: any;
// public trailerPlay = new Subject<any>();
// returntrailerPlay: any;
public storeSelectedPack = new Subject<any>(); // to store value of selected card in subscription
public returnstoreSelectedPack: any = [{
 currency: 'initial',
 month: 'initial',
  monthName: 'initial',
  pack: 'initial',
  price: 'initial'
}];
public indexSelectedCard = new Subject<any>(); // to store index of selected card in subscription
public returnindexSelectedCard: any;
public signInReminder = new Subject<any>();
public returnSigninreminder: boolean;
public subscribeReminder = new Subject<any>();
public returnSubscribeReminder: boolean;
// public signInReminderFlag = new Subject<any>();
// returnSigninreminderFlag: boolean;
public viewValue = new Subject<any>();
public returnView: any;
public hamburgerValue = new Subject<any>();
public returnHamburger: boolean;
public dropValue = new Subject<any>();
public returnDrop: boolean;
public cookiesValue = new Subject<any>();
public returnCookies: boolean;
public marketingValue = new Subject<any>();
public returnMarketing: boolean;
public cookieDisplayValue = new Subject<any>();
public returnCookieDisplay: boolean;
public cookiescreenValue = new Subject<any>();
public returnCookiescreen: boolean;
public remarketingBlockValue = new Subject<any>();
public returnRemarketingBlock: boolean;
public premium = false;
public trailer = false;
public episodicPageSpace = new Subject<any>();
// login from subscription
public loginFromSub = new Subject<any>();
public returnloginFromSub: any;
  // upgrade card pop up
public upgradeCardPopup = new Subject<any>();
public returnupgradeCardPopup: any;
  // upgrade card pop up
public upgradeBtn = new Subject<any>();
public returnupgradeBtn: any;

public robiuserValue = new Subject<any>();
public returnRobiuser: any;

public window: any;

constructor(private http: Http, @Inject(PLATFORM_ID) private platformId: Object) {
  if (isPlatformBrowser(this.platformId)) {
    this.window = window;
  }
}
  public robiuserChanges(a: any): any {                                          // for loginregister and user icon chnages on value
    this.returnRobiuser = a;
    this.robiuserValue.next(this.returnRobiuser);
    return this.returnRobiuser;
  }
  public getrobiuserChanges(): any {
    return this.returnRobiuser;
  }
  public contentLanguageChanges(a: any): any {                                          // for loginregister and user icon chnages on value
    this.returnContentlanguage = a;
    this.contentLanguageValue.next(this.returnContentlanguage);
    return this.returnContentlanguage;
  }
  public getcontentLanguageChanges(): any {
    return this.returnContentlanguage;
  }
  public LanguageScreen(a: any): any {                                         // for langscreen track
    this.returnlanguageScreen = a;
    this.languageScreen.next(this.returnlanguageScreen);
    return this.returnlanguageScreen;
  }
  public getLanguageScreen(): any {
   return this.returnlanguageScreen;
  }
  public weyyakChanges(a: boolean): any {                                         // for loginregister and user icon chnages on value
    this.returnweyyak = a;
    this.weyyakValue.next(this.returnweyyak);
    return this.returnweyyak;
  }
    // upgrade card pop up
  public setUpgradeBtn(a: any): any {
    this.returnupgradeBtn = a;
    this.upgradeBtn.next(this.returnupgradeBtn);
    return this.returnupgradeBtn;
  }

  // upgrade card pop up
  public callUpgradePopup(a: any): any {
    this.returnupgradeCardPopup = a;
    this.upgradeCardPopup.next(this.returnupgradeCardPopup);
    return this.returnupgradeCardPopup;
  }

  // public callUpgradePopup(): any {
  //    return this.returnupgradeCardPopup;
  // }
  public launchOfferChange(a: any): any {
    this.returnlaunchOffer = a;
    this.launchOfferValue.next(this.returnlaunchOffer);
    return this.returnlaunchOffer;
  }
  public episodicPage(val): any {
   this.episodicPageSpace.next(val);
   return val;
  }
  public headerScrollSearch(a: boolean): any {                                         // for detecting search screen and hiding/showing icon
    this.returnHeaderScroll = a;
    this.headerScrollValue.next(this.returnHeaderScroll);
    return this.returnHeaderScroll;
  }
  public DialogUserCheck(a: boolean): any {                                         // for detecting search screen and hiding/showing icon
    this.returnDialogUserCheck = a;
    this.dialogValue.next(this.returnDialogUserCheck);
    return this.returnDialogUserCheck;
  }
  public getDialogValue() {
    return this.returnDialogUserCheck;
  }
  public addChanges(a: boolean): any {                                         // for loginregister and user icon chnages on value
    this.returnRegister = a;
    this.registerValue.next(this.returnRegister);
    return this.returnRegister;
  }
  public moreIcon(a: boolean): any {                                            // for more view to track
    this.returnMore = a;
    this.moreValue.next(this.returnMore);
    return this.returnMore;
  }
  public searchIcon(a: boolean): any {                                       // for search screeb track
    this.returnSearch = a;
    this.searchValue.next(this.returnSearch);
    return this.returnSearch;
  }

  public languageIcon(a: boolean): any {                                       // for search screeb track
    this.returnLanguage = a;
    this.languageValue.next(this.returnLanguage);
    return this.returnLanguage;
  }

  public contentLan(a: boolean): any {
    this.returncontentLan = a;
    this.contentlanValue.next(this.returncontentLan);
    return this.returncontentLan;
  }

  public modelChange(a: boolean): any {                                      // for track of all model popup
    this.returnModel = a;
    this.modelValue.next(this.returnModel);
    return this.returnModel;
  }
  public profileDrop(a: boolean): any {                                     // for profiledrop in profilescreen
   this.returnDrop = a;
   this.dropValue.next(this.returnDrop);
   return this.returnDrop;
  }
  public hamburgerDrop(a: boolean): any {                                // for hamburger menu
   this.returnHamburger = a;
   this.hamburgerValue.next(this.returnHamburger);
   return this.returnHamburger;
  }
  public viewChange(a: any): any {                                      // to track of view urls
    this.returnView = a;
    this.viewValue.next(this.returnView);
    return this.returnView;
  }
  public spotlightChange(a: boolean): any {                                    // for language slide
    this.returnspotlight = a;
    this.spotlightValue.next(this.returnspotlight);
    return this.returnspotlight;
  }
  public profileChange(a: any): any {                                    // for profile drop down track
    this.returnprofileDrop = a;
    this.profileDropValue.next(this.returnprofileDrop);
    return this.returnprofileDrop;
  }
  public parentalChange(a: any): any {                                    // for parental popup changes
    this.returnparental = a;
    this.parentalValue.next(this.returnparental);
    return this.returnparental;
   }
  public routeParamChange(a: any): any {                                    // routeparam i channeldetails
   this.returnrouteParam = a;
   this.routeParamValue.next(this.returnrouteParam);
   return this.returnrouteParam;
  }
  public menuOption(a: any): any {                                    // track of premium memu tab
    this.returnMenuoption = a;
    this.menuOptionValue.next(this.returnMenuoption);
    return this.returnMenuoption;
  }
  public footerOption(a: any): any {
    this.returnFooteroption = a;
    this.footerOptionValue.next(this.returnFooteroption);
    return this.returnFooteroption;
  }
  public breadCrump(a: any): void {
    this.returnbreadcrump = a;
    this.breadcrumpValue.next(a);
  }
  public RTRMTrack(a: any): void {        // guest/logined user RTRM value from settings/local
    this.returnRTRM = a;
    this.rTRMValue.next(this.returnRTRM);
    return this.returnRTRM;
  }
  public RTRMCountryTrack(a: any): void {  // RTRM true for country
    this.returnRTRMCountry = a;
    this.rTRMCountryValue.next(this.returnRTRMCountry);
    return this.returnRTRMCountry;
  }
  public calculateEvent(): void {
    if (this.returnRTRMCountry === true && this.returnRTRM === 'false') {
       this.blockEvents = true;        // block events
    } else if (this.returnRTRMCountry === true && this.returnRTRM === 'true') {
      this.blockEvents = false;        // dont block events
    }
    this.getBlockEvents(this.blockEvents);
  }
  public getBlockEvents (a): any {
    if (a !== undefined) {
    localStorage.setItem('BlockRTRM', a);
    } else {
    localStorage.removeItem('BlockRTRM');
    }
    this.returnBlockevents = a;
    this.blockeventsValue.next(this.returnBlockevents);
    return this.returnBlockevents;
  }
  public getRemarketing(): any {  // for video

     return this.returnBlockevents || JSON.parse(localStorage.getItem('BlockRTRM'));
  }
  public footerCookies(a): any {
    this.returnCookieoption = a;
    this.cookieOptionValue.next(this.returnCookieoption);
    return this.returnCookieoption;
  }
    public getfooterCookies(): any {
    return this.returnCookieoption;
  }
   // signin pop up
   public signinChange(a: boolean): any {
     // console.log('signinChange',a);
     this.returnSignin = a;
     this.signinValue.next(this.returnSignin);
     return this.returnSignin;
   }

   // international Register Pop up
   public internationalRegisterChange(a: boolean): any {
     this.returnInternationalRegister = a;
     this.internationalRegisterValue.next(this.returnInternationalRegister);
     return this.returnInternationalRegister;
   }
   public signinLeftChange(a: boolean): any {
    // console.log('signinLeftChange',a);
     this.returnsigninValueLeft = a;
     this.signinValueLeft.next(this.returnsigninValueLeft);
     return this.returnsigninValueLeft;
   }
   public signinRightTopChange(a: boolean): any {
     // console.log('signinRightTopValuechange',a);
     this.returnsigninRightTopValue = a;
     this.signinRightTopValue.next(this.returnsigninRightTopValue);
     return this.returnsigninRightTopValue;
   }
   public signinDetailsChange(a: boolean): any {
     // console.log('signindetailsChange',a);
     this.returnsignInDetailValue = a;
     this.signInDetailValue.next(this.returnsignInDetailValue);
     return this.returnsignInDetailValue;
   }
    public bgImageValueChange(a: boolean): any {
     // console.log('returnbgImageValueChange',a);
     this.returnbgImageValue = a;
     this.bgImageValue.next(this.returnbgImageValue);
     return this.returnbgImageValue;
   }
   public registerMobilechange(a: boolean): any {
     // console.log('registerInChange',a);
     this.returnRegisterMobileValue = a;
     this.registerMobileValue.next(this.returnRegisterMobileValue);
     return this.returnRegisterMobileValue;
   }
    public loginHeadingChange(a: boolean): any {
     // console.log('loginHeadingValue',a);
     this.returnloginHeadingValue = a;
     this.loginHeadingValue.next(this.returnloginHeadingValue);
     return this.returnloginHeadingValue;
   }
    public registerHeadingChange(a: boolean): any {
     // console.log('registerHeadingValue',a);
     this.returnregisterHeadingValue = a;
     this.registerHeadingValue.next(this.returnregisterHeadingValue);
     return this.returnregisterHeadingValue;
   }
    public loginMobileChange(a: boolean): any {
     // console.log('registerHeadingValue',a);
     this.returnloginMobileValue = a;
     this.loginMobileValue.next(this.returnloginMobileValue);
     return this.returnloginMobileValue;
   }
    public loginEmailChange(a: boolean): any {
     // console.log('registerHeadingValue',a);
     this.returnloginEmailValue = a;
     this.loginEmailValue.next(this.returnloginEmailValue);
     return this.returnloginEmailValue;
   }
    public loginComponentChange(a: boolean): any {
     // console.log('registerHeadingValue',a);/
     this.returnloginComponentValue = a;
     this.loginComponentValue.next(this.returnloginComponentValue);
     return this.returnloginComponentValue;
   }
    public ProfileActivationChange(a: boolean): any {
     this.returnPofileActivationValue = a;
     this.pofileActivationValue.next(this.returnPofileActivationValue);
     return this.returnPofileActivationValue;
   }
   public getProfileActivationChange(): any {
      return this.returnPofileActivationValue;
   }
   public ButtonChange(a: boolean): any {
     // console.log('ButtonChangeService',a);
     this.returnButtonChangeValue = a;
     this.buttonChangeValue.next(this.returnButtonChangeValue);
     return this.returnButtonChangeValue;
   }
   public getButtonChange(): any {
     // console.log(this.returnButtonChangeValue,"hhuihuihui")
     return this.returnButtonChangeValue;
   }
   public verificationEmailChange(a: boolean): any {
     // console.log('verifyEmailService',a);
     this.returnverificationEmailValue = a;
     this.verificationEmailValue.next(this.returnverificationEmailValue);
     return this.returnverificationEmailValue;
   }
   public verificationMobileChange(a: boolean): any {
     // console.log('verifyEmailService',a);
     this.returnverificationMobileValue = a;
     this.verificationMobileValue.next(this.returnverificationMobileValue);
     return this.returnverificationMobileValue;
   }
   public forgotEmailValueChange(a: boolean): any {
     // console.log('ForgotPasswordEmail',a);
     this.returnforgotEmailValue = a;
     this.forgotEmailValue.next(this.returnforgotEmailValue);
     return this.returnforgotEmailValue;
   }
   public forgotMobileValueChange(a: boolean): any {
     // console.log('ForgotPasswordEmail',a);
     this.returnforgotMobileValue = a;
     this.forgotMobileValue.next(this.returnforgotMobileValue);
     return this.returnforgotMobileValue;
   }
   public RegisterSuccessChange(a: boolean): any {
     // console.log('ForgotPasswordEmail',a);
     this.returnRegisterSuccessValue = a;
     this.registerSuccessValue.next(this.returnRegisterSuccessValue);
     return this.returnRegisterSuccessValue;
   }
    public LoginPageChange(a: boolean): any {
     this.returnloginPageValue = a;
     this.loginPageValue.next(this.returnloginPageValue);
     return this.returnloginPageValue;
   }
    public internationalLoginPageChange(a: boolean): any {
     this.returnInternationalloginValue = a;
     this.internationalloginPageValue.next(this.returnInternationalloginValue);
     return this.returnInternationalloginValue;
   }
   public getinternationalLogin(): any {
     return this.returnInternationalloginValue;
   }
   public OtherContanierFlagChange(a: boolean): any {
     this.returnOtherContainerFlagValue = a;
     this.otherContainerFlagValue.next(this.returnOtherContainerFlagValue);
     return this.returnOtherContainerFlagValue;
   }
   public IconFlagChange(a: boolean): any {
     this.returnIconFlagValue = a;
     this.iconFlagValue.next(this.returnIconFlagValue);
     return this.returnIconFlagValue;
   }
   public RegisterPageChange(a: boolean): any {
     this.returnRegisterPageValue = a;
     this.registerPageValue.next(this.returnRegisterPageValue);
     return this.returnRegisterPageValue;
   }
   public PersonalizeReloadChange(a: boolean): any {
     this.returnRegisterPageValue = a;
     this.registerPageValue.next(this.returnRegisterPageValue);
     return this.returnRegisterPageValue;
   }
   public CookiesCheckValueChange(a: boolean): any {  // to activity cookiesand remarketing popup
     this.returnCookiesCheckValue = a;
     this.cookiesCheckValue.next(this.returnCookiesCheckValue);
     return this.returnCookiesCheckValue;
   }

   public DialogCheckValueChange(a: boolean): any {
     this.returnDialogCheckValue = a;
     this.dialogCheckValue.next(this.returnDialogCheckValue);
     return this.returnDialogCheckValue;
   }
    public cookieValueChange(a: boolean): any {         // for cookies r remarketing
     this.returnCookies = a;
     this.cookiesValue.next(this.returnCookies);
     return this.returnCookies;
    }
    public marketingChange(a: boolean): any {         // for  remarketing false hide heading and arrow
     this.returnMarketing = a;
     this.marketingValue.next(this.returnMarketing);
     return this.returnMarketing;
    }
    public cookieDisplayChange(a: boolean): any {         // for  cookies false hide heading and arrow
     this.returnCookieDisplay = a;
     this.cookieDisplayValue.next(this.returnCookieDisplay);
     return this.returnCookieDisplay;
    }
    public cookiesScreen(a: boolean): any {
      this.returnCookiescreen = a;
     this.cookiescreenValue.next(this.returnCookiescreen);
     return this.returnCookiescreen;
    }
    public BlockScreen(a: boolean): any {
      this.returnRemarketingBlock = a;
     this.remarketingBlockValue.next(this.returnRemarketingBlock);
     return this.returnRemarketingBlock;
    }
    public getBlockValue() {
      return this.returnRemarketingBlock;
    }
    public getCookiesDisplay() {
      return this.returnCookieDisplay;
    }
    public getMarketValue() {
      return this.returnMarketing;
    }
    public getCookieValueChange() {
      return this.returnCookies;

    }
   public getCookiesCheckValueChange() {
     return this.returnCookiesCheckValue;
   }

   public getDialogCheckValueChange() {
     return this.returnDialogCheckValue;
   }
   public getRegisterSuccess() {
     return this.returnRegisterSuccessValue;
   }
   public getPersonalizeChange() {
     return this.returnRegisterPageValue;
   }
   public getProfileActivate() {
    return this.returnSignin;
   }

    // info popup in subscription
    public subInfoChange(a: boolean): any {
     this.returnsubInfo = a;
     this.subInfoValue.next(this.returnsubInfo);
     return this.returnsubInfo;
    }

    // view details popup in subscription
    public subViewPackChange(a: boolean): any {
     this.returnsubViewPack = a;
     this.subViewPackValue.next(this.returnsubViewPack);
     return this.returnsubViewPack;
    }

    // gaana subscription popup in subscription
    public subClosePackChange(a: boolean): any {
     this.returnClosePackChange = a;
     this.closePackChangeValue.next(this.returnClosePackChange);
     return this.returnClosePackChange;
    }

    public subscriptionPackChange(a: boolean): any {
      this.returnsubscriptionChangeValue = a;
      this.subscriptionChangeValue.next(this.returnsubscriptionChangeValue);
      return this.returnsubscriptionChangeValue;
    }

    // edit summary img in subscription
    public subEditSummaryChange(a: boolean): any {
     this.returnsubEditSummary = a;
     this.subEditSummaryValue.next(this.returnsubEditSummary);
     return this.returnsubEditSummary;
    }

    // get value of subEditSummaryChange
    public getEditSummary(): any {
     return this.returnsubEditSummary;
    }

    // search result in subscription
    public subDisplayPayment(a: boolean): any {
     this.returnsubPaymentValue = a;
     this.subPaymentValue.next(this.returnsubPaymentValue);
     return this.returnsubPaymentValue;
    }

    // get subDisplayPayment
    public getDisplayPayment(): any {
     return this.returnsubPaymentValue;
    }

   // unsubscribe popup in subscription
    public subUnsubscribePopup(a: boolean): any {
     this.returnsubUnsubscribeValue = a;
     this.subUnsubscribeValue.next(this.returnsubUnsubscribeValue);
     return this.returnsubUnsubscribeValue;
    }

    // view details pop up in info card
    public infoViewDetail(a: any): any {
     this.returninfoView = a;
     this.infoView.next(this.returninfoView);
     return this.returninfoView;
    }

    public getInfoViewDetail(): any {
      return this.returninfoView;
    }

    // send details to popup
    public sendPopUpDetail(a: any): any {
     this.returnpopUpDetails = a;
     this.popUpDetails.next(this.returnpopUpDetails);
     return this.returnpopUpDetails;
    }

    // get pop up details
    public getPopUpDetail() {
      return this.returnpopUpDetails;
    }

    // amount payable
    public sendAmountDetails(a: any): any {
     this.returnamountPayable = a;
     this.amountPayable.next(this.returnamountPayable);
     return this.returnamountPayable;
    }

    public getAmountDetails(): any {
     return this.returnamountPayable;
    }


    // display plan in subscription
    public showAvailablePlan(a: any): any {
     this.returndisplayPlan = a;
     this.displayPlan.next(this.returndisplayPlan);
     return this.returndisplayPlan;
    }

    // get value of showAvialablePlan
    public getDisplayPlan(): any {
     return this.returndisplayPlan;
    }

    // display selected plan details in step 2 of subscription
    public showSelectedPlan(a: any): any {
     this.returndisplaySelectedPlan = a;
     this.displaySelectedPlan.next(this.returndisplaySelectedPlan);
     return this.returndisplaySelectedPlan;
    }

    // get value of showSelectedPlan
    public getSelectedPlanSection(): any {
      return this.returndisplaySelectedPlan;
    }

    // store value of card selected to be displayed in step2 of subscription
    public storeSelectedPackDetails(a: any): any {
     this.returnstoreSelectedPack = a;
     this.storeSelectedPack.next(this.returnstoreSelectedPack);
     return this.returnstoreSelectedPack;
   }

    // get details of selected card
    public getSelectedPackDetails(): any {
     return this.returnstoreSelectedPack;
    }

    // store value of index of card selected   subscription
    public storeIndexSelectedCard(a: any): any {
     this.returnindexSelectedCard = a;
     this.indexSelectedCard.next(this.returnindexSelectedCard);
     return this.returnindexSelectedCard;
    }

    // get index of selected card
    public getIndexSelectedCard(): any {
     return this.returnindexSelectedCard;
    }
    // for trailer

   //  trailerCheckChange(a: boolean): any {
   //   this.returntrailerPlay = a;
   //   this.trailerPlay.next(this.returntrailerPlay);
   //   return this.returntrailerPlay;
   // }

   // for reminder
   public signReminderChange(a: boolean): any {
     this.returnSigninreminder = a;
     this.signInReminder.next(this.returnSigninreminder);
     return this.returnSigninreminder;
   }

   public getSigninreminder(): any {
     return this.returnSigninreminder;
   }

   //  signInReminderFlagSet(a: boolean): any {
   //   this.returnSigninreminderFlag = a;
   //   this.signInReminderFlag.next(this.returnSigninreminderFlag);
   //   return this.returnSigninreminderFlag;
   // }

    public subscribeReminderChange(a: boolean): any {
     this.returnSubscribeReminder = a;
     this.subscribeReminder.next(this.returnSubscribeReminder);
     return this.returnSubscribeReminder;
   }

   public getSubscribeReminder(): any {
     return this.returnSubscribeReminder;
   }

   // fetch value from sendAmountDetails function
   public getAmountPayable(): any {
     return this.returnamountPayable;
   }


  // login from subscription
  public storeNavigateLoginSub(a: any): any {
    this.returnloginFromSub = a;
    this.loginFromSub.next(this.returnloginFromSub);
    return this.returnloginFromSub;
  }
  public getloginFlag(): any {
    return this.returnloginFromSub;
  }
  public storeDisplangcode(valuecodes): any {
    this.dispLangcode = valuecodes ;
  }
  public getDisplayCodes(): any {
    return this.dispLangcode;
  }

  public popupsShown(): any {
    let popups, menus;
    popups = this.returnSubscribeReminder || this.returnSigninreminder || this.returnSearch || (this.returnContentlanguage ? this.returnContentlanguage.boolean : false) || this.returnCookieDisplay || (this.returnparental ? this.returnparental.flag : false);
    menus = this.returnMore || this.returnprofileDrop || this.returnModel;
    popups = (popups || menus) ? true : false;
    return  popups;
  }

  public MygpSubscriptionroute(): any {
    // alert('Route to MyGP subscription : ' + window.location.href);
    // if (this.window) {
    //   alert('jsInterface ' + this.window.jsInterface + '\nwebkit ' + this.window.webkit);
    // }
    if (this.window && this.window.jsInterface && this.window.jsInterface.onContentChange) {
      this.window.jsInterface.onContentChange(window.location.href, true);
    } else if (this.window && (((this.window.webkit || {}).messageHandlers || {}).onContentChange || {}).postMessage) {
      let routeObj;
      routeObj = { contentUrl: window.location.href,  isPremium: true};
      this.window.webkit.messageHandlers.onContentChange.postMessage(routeObj);
    }
  }

}
