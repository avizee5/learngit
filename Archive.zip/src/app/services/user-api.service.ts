import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import * as SettingsApi from '../../data/user/api/api';
import { isPlatformBrowser } from '@angular/common';

@Injectable()
export class UserApiService {
  public parameterValue = new Subject<any>();
  public enableVideoPlay = new Subject<any>();
    public saveToastMsg = new Subject<any>();
  public returnStoredParameter: any;
  public returnedStoredToken: any;
  public returnedEmail: any;
  public userToken: any;
  public updated_settings: any;
  public contentLanguages: any;
  public displayLanguage: any;
  public autoPlay: any;
  public downloadQuality: any;
  public streamingQuality: any;
  public googleIAP: any;
  public appleIAP: any;
  public completeSettings: any;
  public localStorage: any;
  public window: any;
  public age_rating: any;
  public pin: any;
  public gdprValue: any;
  public countryCode: any;
  public gdpr_travel =  false;

  constructor(@Inject(PLATFORM_ID) private platformId: Object, private http: Http ) {
    if (isPlatformBrowser(this.platformId)) {
      this.localStorage = localStorage;
      this.window = window;
    }
  }

  public getParameter(action: string, key: string, a: any): any {
    this.returnStoredParameter = a;
    this.parameterValue.next(this.returnStoredParameter);

    if ( key === 'content_language') {
      this.contentLanguages = a;
      this.updated_settings = [ {key: 'content_language', value: a} ];
    }

    if ( key === 'display_language') {
      this.displayLanguage = a;
      this.updated_settings = [ {key: 'display_language', value: a} ];
    }

    if ( key === 'recent_search') {
      this.updated_settings = [ {key: 'recent_search', value: a} ];
    }

    if ( key === 'auto_play') {
      this.autoPlay = a;
      this.updated_settings = [ {key: 'auto_play', value: a} ];
    }

    if ( key === 'streaming_quality') {
      this.streamingQuality = a;
      this.updated_settings = [ {key: 'streaming_quality', value: a} ];
    }

    if ( key === 'download_quality') {
      this.downloadQuality = a;
      this.updated_settings = [ {key: 'download_quality', value: a} ];
    }
/*
      if ( key === 'google_iap') {
       this.googleIAP = a;
       this.updated_settings = [ {key: 'google_iap', value: a} ];
      }

      if ( key === 'Apple_IAP') {
       this.appleIAP = a;
       this.updated_settings = [ {key: 'Apple_IAP', value: a} ];
     }*/


     this.userToken = this.localStorage.getItem('token');
     let userBearer;
     userBearer = 'bearer ' + this.userToken;
     if ( this.userToken && action === 'put') {
       let config;
       config = {
         apiKey: userBearer,
         username: '',
         password: '',
         accessToken: '',
         withCredentials: true
       };

       let updatedsettings;
       updatedsettings = {
         'key': this.updated_settings[0].key,
         'value': this.updated_settings[0].value
       };

       let y;
       y = this.localStorage.getItem('previousDisplayLanguage');
       let userDetails;
       userDetails = new SettingsApi.SettingsApi(this.http, null, config);
       userDetails.v1SettingsPut(updatedsettings).subscribe(value => {
         // if (updatedsettings.key === 'display_language') {
         //  let prev;
         //  prev = localStorage.getItem('previousRoute');
         // }


          // location.href = this.window.location.origin  + prev;

           // if (updatedsettings.value === 'en') {
           //   location.href = this.window.location.origin + this.window.location.pathname.replace(this.window.location.pathname.split('/')[1], '');
           // } else {

           //   if (y === 'en') {
           //     location.href = this.window.location.origin + this.window.location.pathname.replace(this.window.location.pathname.split('/')[1], updatedsettings.value) + this.window.location.pathname
           //   } else {
           //     location.href = this.window.location.origin  + this.window.location.pathname.replace(this.window.location.pathname.split('/')[1], updatedsettings.value)

           //   }
           // }
         // if(updatedsettings.key === 'content_language') {
         //    let prev;
         //    prev = localStorage.getItem('previousRoute');
         //    location.href = this.window.location.origin  + prev;
         // }
       },
       error => {
         // todo
       });
     }
   }
   public savetoast(msg): void {
          this.saveToastMsg.next(msg);
   }
   public getSettings(): any {
/*    if ( this.googleIAP === undefined) {
      this.googleIAP = ''
    }
    if ( this.appleIAP === undefined) {
      this.appleIAP = ''
    }*/
    this.completeSettings = [ {'content_language': this.contentLanguages},
    {'display_language': this.displayLanguage},
    {'streaming_quality': this.streamingQuality},
    {'download_quality': this.downloadQuality},
    {'auto_play': this.autoPlay}];

    return this.completeSettings;
  }

  public gettoken(a: any): any {
    this.returnedStoredToken = a;
    return this.returnedStoredToken;
  }

  public setEmailid(a: any): any {
    this.returnedEmail = a;
    return this.returnedEmail;
  }

  public getEmailid(): any {
    return this.returnedEmail;
  }

  public setAgeRating(a: any) {
    if (a) {
      this.age_rating = JSON.parse(a);
    }
  }

  public getAgeRating(): any {
    return this.age_rating;
  }

  public enableVideo(flag: any): any {
    this.enableVideoPlay.next(flag);

  }
  public checkGdprTravel(value, countrycode) {
    let login;
    this.gdprValue = value;
    this.countryCode = countrycode;
    for (let j = 0; j < this.gdprValue.length; j++) {
                  let k;
                  k = j;
         if (this.countryCode === this.gdprValue[j].country_code) {
          login = true;
          return false;
        } else if ((k === this.gdprValue.length - 1) && login === undefined) {
          return true;
        }
    }
  }
  private extractData(res: Response) {
    let body;
    body = res.json();
    return body || {};
  }

  private handleErrorObservable (error: Response | any) {
    return Observable.throw(error.message || error);
  }
}

