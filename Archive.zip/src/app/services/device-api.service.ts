// import { Injectable } from '@angular/core';

import { Injectable } from '@angular/core';
import { Headers, Http , RequestOptions, Response} from '@angular/http';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/toPromise';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Inject, Optional } from '@angular/core';
import { URLSearchParams } from '@angular/http';
import { RequestMethod, RequestOptionsArgs } from '@angular/http';
import {  ResponseContentType } from '@angular/http';
import { environment } from '../../environments/environment';

@Injectable()
export class DeviceApiService {
  public name: any = 'WebBrowser';
  public identifier: any = 'WebBrowser';
  constructor(private http: Http) { }
	public postDevice(token): Observable<any> {
		let deviceData;
		deviceData = {
	        'name': this.name,
	        'identifier': this.identifier,
		};
	    const path =  environment.subscriptionbasepath + '/v1/device';
	    const headers = new Headers();
	    headers.append('Authorization', 'bearer ' + token);
	    // const queryParameters = new URLSearchParams();
	    // const consumes: string[] = [
	    // ];
	    // const produces: string[] = [
	    //     'text/plain',
	    //     'application/json',
	    //     'text/json'
	    // ];
	    const requestOptions: RequestOptionsArgs = new RequestOptions({
	        method: RequestMethod.Post,
	        headers: headers,
	        body: deviceData == null ? '' : deviceData // https://github.com/angular/angular/issues/10612
	        // search: queryParameters,
	    });
	    return this.http.request(path, requestOptions)
	    .map(this.extractData)
		.catch(this.handleErrorObservable);
	}

	public getDevice(token): Observable<any> {
	    const path =  environment.subscriptionbasepath + '/v1/device';
	    // const queryParameters = new URLSearchParams();
	    const headers = new Headers();
	    headers.append('Authorization', 'bearer ' + token);
	    // const consumes: string[] = [
	    // ];
	    // const produces: string[] = [
	    //     'text/plain',
	    //     'application/json',
	    //     'text/json'
	    // ];
	    const requestOptions: RequestOptionsArgs = new RequestOptions({
	        method: RequestMethod.Get,
	        headers: headers
	        // body: deviceData == null ? '' : deviceData, // https://github.com/angular/angular/issues/10612
	        // search: queryParameters
	    });
	    return this.http.request(path, requestOptions)
	    .map(this.extractData)
		.catch(this.handleErrorObservable);
	}

	public putDevice(token): Observable<any> {
		let deviceData;
		deviceData = {
	        'name': this.name,
	        'idetifier': this.identifier,
		};
	    const path =  environment.subscriptionbasepath + '/v1/device';
	    const headers = new Headers();
	    headers.append('Authorization', 'bearer ' + token);
	    // const queryParameters = new URLSearchParams();
	    // const consumes: string[] = [
	    // ];
	    // const produces: string[] = [
	    //     'text/plain',
	    //     'application/json',
	    //     'text/json'
	    // ];
	    const requestOptions: RequestOptionsArgs = new RequestOptions({
	        method: RequestMethod.Put,
	        headers: headers,
	        body: deviceData == null ? '' : deviceData // https://github.com/angular/angular/issues/10612
	        // search: queryParameters,
	    });
	    return this.http.request(path, requestOptions)
	    .map(this.extractData)
		.catch(this.handleErrorObservable);
	}

	public deleteDevice(token): Observable<any> {
	    const path =  environment.subscriptionbasepath + '/v1/device';
	    const headers = new Headers();
	    headers.append('Authorization', 'bearer ' + token);
	    // const queryParameters = new URLSearchParams();
	    // const consumes: string[] = [
	    // ];
	    // const produces: string[] = [
	    //     'text/plain',
	    //     'application/json',
	    //     'text/json'
	    // ];
	    const produces: string[] = [
	        'text/plain',
	        'application/json',
	        'text/json'
	    ];
	    const requestOptions: RequestOptionsArgs = new RequestOptions({
	        method: RequestMethod.Delete,
	        headers: headers
	        // body: deviceData == null ? '' : deviceData, // https://github.com/angular/angular/issues/10612
	        // search: queryParameters,
	    });
	    return this.http.request(path, requestOptions)
	    .map(this.extractData)
		.catch(this.handleErrorObservable);
	}

  private extractData(res: Response) {
    let body;
    body = res.json();
    return body || {};
  }
  private handleErrorObservable (error: Response | any) {
    return Observable.throw(error.message || error);
  }
}
