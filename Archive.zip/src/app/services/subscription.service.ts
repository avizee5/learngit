import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../environments/environment';
import { EpgService } from '../services/epg.service';
import { UserApiService } from '../services/user-api.service';
import { TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/timeout';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { SettingsService } from '../services/settings.service';
import { HeaderservicesService } from '../services/headerservices.service';    // services for variable update
import { UseractionapiService } from '../services/useractionapi.service';
import { Router } from '@angular/router';

import 'rxjs/add/operator/filter';
declare const qg;
// Import RxJs required methods
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import * as subscriptionApi from '../../data/subscription/api/api';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import * as $ from 'jquery';
import * as SettingsApi from '../../data/user/api/api';

@Injectable()
export class SubscriptionService {
  public successCount;
  public failedCount = 0;
  public pendingCount = 0;
  public responseCount = 0;
  public failedPacksAfterVerify = [];
  public parent_route_id: any;
  public plan_type: any;
  public traveller = new Subject<any>();
  public display_language: any;
  public storeqgDisplayLang: any;
  public content_language: any;
  public storeqgContentLang: any;
  public qgDisplayLang: any;
  public qgContentLang: any;
  public configData: any;
  public paytmName: any;
  public paymentProvider: any;
  public userdata: any;
  public passActiveAssetType: any;
  public assestJoin: any;
  public assestSplit: any;
  public assetMatch: any;
  public planAssetType: Array<any> = []; // store data for selected card
  public tagBearer: any;
  public subscriptionApiCall: any;
  public responseActivePlan: any;
  public showMovie = false;
  public showZeeOriginal = false;
  public showEpisode = false;
  public showChannel = false;
  public endReceived: any;
  public today: any;
  public todayCompare: any;
  public diffEnd: any;
  public inActiveFlag: boolean;
  public storeActive: boolean;
  public totalUserPlan: Array<any> = [];
  public valueReceived: any;
  public yearName: any;
  public monthName: any;
  public dayName: any;
  public durationStatus: any;
  public receiveServerDate: any;
  public compareServerDate: any;
  public settingsDataReceived: any;
  public settingsDataReceivedGoogle: any;
  public settingsDataReceivedApple: any;
  public googleEndDate: any;
  public storeGooglePack: any = [];
  public user: any;
  public config: any;
  public userSettings: any;
  public settingsActivePlan: Array<any> = [];
  public settingsHistoryPlan: Array<any> = [];
  public storeActivePlan: Array<any> = [];
  public storeHistoryPlan: Array<any> = [];
  public payProvider: any;
  public totalDataActivePlan: Array<any> = [];
  public totalDataPlanHistory: Array<any> = [];
  public storeActiveOnly: Array<any> = [];
  public storeAllActivePlan: Array<any> = [];
  public planAllHistory: Array<any> = [];
  public planAllActive: Array<any> = [];
  public assetSend: Array<any> = [];
  public assetReceivedPlan: Array<any> = [];
  public reload = false;
  public click = new Subject<any>();
  public assetArray: Array<any> = [];
  public assetName: any;
  public tvshow: any;
  public movie: any;
  public livetv: any;
  public localstorage: any;
  public document: any;
  public displayLang: any;
  public packName: any;
  public activeCountry: Array<any> = [];
  public userCountry: any;
  public expiryDate: any;
  public receivedProvider: any;
  public activePlanRec: any;
  public planSucessToastFlag: any;
  public storePARpack: Array<any> = [];
  public localPARstorage: any;
  public parReceived: any;
  public parActivePack: any;
  public countryList: any;
  public exceptinalPaymentProvider: any;
  public settingsValRec: any;
  public setDate: any;
  public totalSettings: any;
  public window: any;
  public navigator: any;
  public configValue: any;
  public countryValue: any;
  public bgImgPath: any;
  public qgraph: any;
  public adyen_name: any;
  public dataValue: any;
  public nextPopup = new Subject<any>();
  public packList: any = [];
  public packArStatusData: Array<any> = [];
  public payuArIndex: Array<any> = [];
  public movieAssetType: Array<any> = []; // store data for selected card
  public channelAssetType: Array<any> = []; // store data for selected card
  public showAssetType: Array<any> = []; // store data for selected card
  public assetCollection: any;
  public regionalPack: Array<any> = [];
  public regionalPackLang: Array<any> = [];
  public ngUnsubscribe = new Subject<any>();
  public response: any;
  public subParameters: any = [];
  public adyenNameSub: any;
  public adyenFlagSub: any;
  public fortumoSub: any;
  public billdeskSub: any;
  public paytmSub: any;
  public adyenSub: any;
  public payuFlagSub: any;
  public mobiwikFlagSub: any;
  public phonepayFlagSub: any;
  public mifeFlagSub: any;
  public payProviderSub: any;
  public paymentProviderSub: any;
  public paytmNameSub: any;
  public adyenNameSendSub: any;
  public payuNameSub: any;
  public mobiwikNameSub: any;
  public phonepayNameSub: any;
  public mifeNameSub: any;
  public exceptionalPaymentProviderSub: any;
  public subscriptionDataSub: any = [];
  public showSub: Array<any> = [];
  public showSubValue = true;
  public finalDataSub: any = [];
  public countPlanSub = 0;
  public assetMatchFlag = false;
  public appendTxt: any;
  public appendTxtvalue: any;
  public regionalRecProv: any;
  public pendingPack: Array<any> = [];
  public storePendingPlan: Array<any> = [];
  public validPendingPlan: Array<any> = [];
  public packCreatedDate: any;
  public myplanCallMade: any;
  public travllerVal: any;
  public autoSelectpayment: boolean = false;

  // value of asset type
  public activeAssestType = new Subject<any>();
  public returnactiveAssestType: any;

  // store id to unsubcribe plan
  public unsubcribeId = new Subject<any>();
  public returnunsubcribeId: any;

  // store fortumo route flag
  public fortumoRouteFlag = new Subject<any>();
  public returnunfortumoRouteFlag: any;

  // flag value for payment fortumo successful
  public paySuccessFortumo = new Subject<any>();
  public returnunpaySuccessFortumo = false;

  // store subscription id generated from fortumo prepare API
  public fortumoSubscriptionID = new Subject<any>();
  public returnfortumoSubscriptionID: any;

  // store user promo code
  public userPromoCode = new Subject<any>();
  public returnuserPromoCode: any;

  // store active plans
  public userActivePlan = new Subject<any>();
  public returnuserActivePlan: any;

  // store active display flag
  public userActiveDisplayFlag = new Subject<any>();
  public returnuserActiveDisplayFlag: any;

  // store active display flag
  public userActiveErrorFlag = new Subject<any>();
  public returnuserActiveErrorFlag: any;

  // store subscription plan From API
  public subscriptionPlanAll = new Subject<any>();
  public returnsubscriptionPlanAll: any;

   // store active/history plan
  public userAllPlan = new Subject<any>();
  public returnuserAllPlan: any;


  // for unsubcribe display msg
  public unsubscribeDisplayMsg = new Subject<any>();
  public returnunsubscribeDisplayMsg: any;

  // for my plan comp
  public planCompFlag = new Subject<any>();
  public returnplanCompFlag: any;

  // for switch tab in my account
  public switchAccIndex = new Subject<any>();
  public returnswitchAccIndex: any;

  // for sub step 2 from renew
  public fromRenew = new Subject<any>();
  public returnfromRenew: any;

  // storing only active
  public storeOnlyActive = new Subject<any>();
  public returnstoreOnlyActive: any;

  // for returning to same page after subscribe pop up
  public redirectSubscribePopup = new Subject<any>();
  public returnredirectSubscribePopup: any;

    // for errResponse in my plan
  public errResponse = new Subject<any>();
  public returnerrResponse: any;

  // for displayHeading in my plan
  public displayHeading = new Subject<any>();
  public returndisplayHeading: any;

  // for activeDisplay in my plan
  public activeDisplay = new Subject<any>();
  public returnactiveDisplay: any;

  // for historyDisplay in my plan
  public historyDisplay = new Subject<any>();
  public returnhistoryDisplay: any;

  // for storeAllHistory in my plan
  public storeAllHistory = new Subject<any>();
  public returnstoreAllHistory: any;

    // for storeAllActive in my plan
  public storePlanActive = new Subject<any>();
  public returnstorePlanActive: any;

  // to check success of my plan api
  public planApiSuccess = new Subject<any>();
  public returnplanApiSuccess: any;

  // to store active country
  public subscribedCountry = new Subject<any>();
  public returnsubscribedCountry: any;


  // to store promo code value
  public storepromoprice = new Subject<any>();
  public returnstorepromoprice: any;

  // to store PayTM AR packs
  public storeActivePARPack = new Subject<any>();
  public returnstoreActivePARPack: any;

    // to store redem pack
  public storeRedemPack = new Subject<any>();
  public returnstoreRedemPack: any;
  public redirectPack = new Subject<any>();

  // store index of pack closed
  public indexPackClose = new Subject<any>();
  public returnindexPackClose: any;

  // proceed btn highlight
  public btnHighlight = new Subject<any>();
  public returnBtnHighlight: any;

  // show/hidebtn in view details
  public btnDetails = new Subject<any>();
  public returnbtnDetails: any;

  // selected card payment provider
  public selCardAllPayment = new Subject<any>();
  public returnselCardAllPayment: any;

  // sub bg img
  public subBgImg = new Subject<any>();
  public returnsubBgImg: any;

  // payment failed query parameters
  public payFailQuery = new Subject<any>();
  public returnpayFailQuery: any;

  // display offer details in info card
  public displayOfferDetails = new Subject<any>();
  public returndisplayOfferDetails: any;

  // display offer details in info card
  public displayOfferBanner = new Subject<any>();
  public returndisplayOfferBanner: any;

  // display same banner text in sub page
  public displaySameBannerText = new Subject<any>();
  public returndisplaySameBannerText: any;

  // append text for before tv
  public appendBeforeTvText = new Subject<any>();
  public returnappendBeforeTvText: any;

  // store active regional pack
  public activeRegionalPack = new Subject<any>();
  public returnactiveRegionalPack: any;

  // store active regional pack language
  public activeRegionalPackLang = new Subject<any>();
  public returnactiveRegionalPackLang: any;

  // selected upgrade pack
  public selectUpgradePack = new Subject<any>();
  public returnselectUpgradePack: any;

  // all upgrade pack
  public listUpgradePack = new Subject<any>();
  public returnlistUpgradePack: any;

  //  upgrade pack discount details
  public upgradeDiscount = new Subject<any>();
  public returnupgradeDiscount: any;

  // store if free trial pack exists
  public freePack = new Subject<any>();
  public returnFreePack: any;

  // store if free trial pack exists
  public freePackDetails = new Subject<any>();
  public returnFreePackDetails: any;

  // store if url data pack exists
  public urlDetails = new Subject<any>();
  public returnurlDetails: any;

  // store if url data pack exists
  public urlDetailsFlag = new Subject<any>();
  public returnurlDetailsFlag: any;
  // store index of free trial pack
  public indexFreePack = new Subject<any>();
  public returnindexFreePack: any;

  // store if user has pending packs
  public pendingPacks = new Subject<any>();
  public returnpendingPacks: any;

  // store pending verification status from subscription
  public subPendStatus = new Subject<any>();
  public returnsubPendStatus: any;

  // store telco users flag for my account
  public telcoUsersFlag = new Subject<any>();
  public returntelcoUsersFlag: any;

  // store telco users flag for subscription
  public telcoUsersFlagSub = new Subject<any>();
  public returntelcoUsersFlagSub: any;

  // store telco users name
  public telcoUsersName = new Subject<any>();
  public returntelcoUsersName: any;

  // renew status
  public renewStat = new Subject<any>();
  public returnrenewStat: any;

  // set pack from URL params
  public packDataSet = new Subject<any>();
  public noSetPackURLErr:  boolean = true;

  // store previous promo pack
  public storePrevPromoId = new Subject<any>();
  public returnPrevPromoId: any;

   // store previous promo pack
  public storeAllAccessPack = new Subject<any>();
  public returnAllAccessPack: any;

  // hide subscription btn from config
  public hideSubBtnConfig = new Subject<any>();
  public returnhideSubBtnConfig: any;

  constructor( private userAction: UseractionapiService, private headerservicesService: HeaderservicesService, private settingsService: SettingsService, @Inject(PLATFORM_ID) private platformId: Object, private translate: TranslateService, private userapiService: UserApiService, private epgService: EpgService, private http: Http , private gtm: GoogleAnalyticsService, private router: Router) {
  this.headerservicesService.blockeventsValue.subscribe(value => {
     this.qgraph = this.headerservicesService.getRemarketing();
    });
  }

  public setParentId(id: any, extra: any): any {
    if (id) {
      this.parent_route_id = JSON.stringify({'id': id, 'extra': (id === extra) ? null : extra});
    } else {
      this.parent_route_id = undefined;
    }
    // this.parent_route_id = id;
  }

  public getParentId(): any {
    return this.parent_route_id;
  }

  // universal
  public setUniversalValue(): any {
    if (isPlatformBrowser(this.platformId)) {
     this.localstorage = localStorage;
      this.document = document;
      this.window = window;
      this.navigator = navigator;
    }
  }
  // translation
  public gettranslation(): any {
  let translation, token;
  this.localstorage = localStorage;
  translation = 'en';
  token = this.localstorage.getItem('token');
  if (token) {
      translation = (this.localstorage.getItem('UserDisplayLanguage') !== null && this.localstorage.getItem('UserDisplayLanguage') !== undefined) ? this.localstorage.getItem('UserDisplayLanguage') : 'en';
  } else {
      translation = (this.localstorage.getItem('display_language') !== null && this.localstorage.getItem('display_language') !== undefined) ? this.localstorage.getItem('display_language') : 'en';
  }
  return translation;
}
  // redirect
  public redirectPage(): void {
      this.redirectPack.next(true);
  }
  // set GA Flag
  public setUserdata(data): void {
    this.userdata = data;
  }
  public footerclick(status): void {
    this.click.next(status);
  }
  public callQgraph(status, configData): void {
    this.configData = configData;
    this.reload = status;
  }
  public storeActiveAssestType(a: any): any {
    this.returnactiveAssestType = a;
    this.activeAssestType.next(this.returnactiveAssestType);
    return this.returnactiveAssestType;
  }

  // my plan component
  public storePlanCompFlag(a: any): any {
    this.returnplanCompFlag = a;
    this.planCompFlag.next(this.returnplanCompFlag);
    return this.returnplanCompFlag;
  }

  // switch in my account tab
  public storeSwitchAccIndex(a: any): any {
    this.returnswitchAccIndex = a;
    this.switchAccIndex.next(this.returnswitchAccIndex);
    return this.returnswitchAccIndex;
  }

  // switch sub step 2 from renew
  public storeRenewSub(a: any): any {
    this.returnfromRenew = a;
    this.fromRenew.next(this.returnfromRenew);
    return this.returnfromRenew;
  }

  public getRenew() {
    return this.returnfromRenew;
  }

  public getActiveAssestType(): any {
    if (this.returnactiveAssestType !== undefined) {
      this.assestJoin = this.returnactiveAssestType.join();
      if (this.assestJoin.length > 0) {
      this.assestSplit = this.assestJoin.split(',');
      // remove duplicates
      for (let a  = 0; a < this.assestSplit.length; a++) {
        for (let b = (a + 1); b < this.assestSplit.length; b++) {
          if (this.assestSplit[a] === this.assestSplit[b]) {
            this.assestSplit.splice(b, 1);
          }
        }
      }
    this.assetMatch = this.assestSplit;
    } else {
           this.assetMatch = [];
    }
   } else {
     this.assetMatch = [];
   }
   return this.assetMatch;
  }

    // store id to unsubcribe plan
    public storeUnsubcribeId(a: any): any {
     this.returnunsubcribeId = a;
     this.unsubcribeId.next(this.returnunsubcribeId);
     return this.returnunsubcribeId;
   }

    // get id of unsubcribe card
     public getUnsubcribeId(): any {
       return this.returnunsubcribeId;
     }

    // store fortumo route flag
    public storeFortumoRouteFlag(a: any): any {
     this.returnunfortumoRouteFlag = a;
     this.fortumoRouteFlag.next(this.returnunfortumoRouteFlag);
     return this.returnunfortumoRouteFlag;
   }

    // get value of fortumo route flag
    public getFortumoRouteFlag(): any {
     return this.returnunfortumoRouteFlag;
    }

    // flag for successful payment Fortumo
    public paymentSuccessFortumo(a: any): any {
     this.returnunpaySuccessFortumo = a;
     this.paySuccessFortumo.next(this.returnunpaySuccessFortumo);
     return this.returnunpaySuccessFortumo;
    }

    public getPaymentFlag(): any {
      return this.returnunpaySuccessFortumo;
    }

    // store subscription id generated from fortumo prepare API
    public storeFortumoSubId(a: any): any {
     this.returnfortumoSubscriptionID = a;
     this.fortumoSubscriptionID.next(this.returnfortumoSubscriptionID);
     return this.returnfortumoSubscriptionID;
    }

    public returnFortumoSubId(): any {
     return this.returnfortumoSubscriptionID;
    }

    // store user promo code
    public storeUserPromoCode(a: any): any {
     this.returnuserPromoCode = a;
     this.userPromoCode.next(this.returnuserPromoCode);
     return this.returnuserPromoCode;
    }

    public getUserPromoCode(): any {
     return this.returnuserPromoCode;
    }

    // store active plans for my plans in my account
    public storeActivePlans(a: any): any {
     this.returnuserActivePlan = a;
     this.userActivePlan.next(this.returnuserActivePlan);
     return this.returnuserActivePlan;
    }

    // return Active plans
    public getActivePlan(): any {
     return this.returnuserActivePlan;
     }

     // store active display flag for my plans in my account
    public storeActiveDisplayFlag(a: any): any {
     this.returnuserActiveDisplayFlag = a;
     this.userActiveDisplayFlag.next(this.returnuserActiveDisplayFlag);
     return this.returnuserActiveDisplayFlag;
    }

    public getActiveDisplayFlag(): any {
      return this.returnuserActiveDisplayFlag;
    }

    // store active error response falg for my plans in my account
    public storeErrorDisplayFlag(a: any): any {
     this.returnuserActiveErrorFlag = a;
     this.userActiveErrorFlag.next(this.returnuserActiveErrorFlag);
     return this.returnuserActiveErrorFlag;
    }

    public getErrorDisplayFlag(): any {
     return this.returnuserActiveErrorFlag;
    }

    // store subscription plan from API
    public storeAllSubscriptionPlan(a: any): any {
     this.returnsubscriptionPlanAll = a;
     this.subscriptionPlanAll.next(this.returnsubscriptionPlanAll);
     return this.returnsubscriptionPlanAll;
    }

    public getAllSubscriptionPlan(): any {
     return this.returnsubscriptionPlanAll;
    }

    // store active/history plan
    public storeAllUserPlan(a: any): any {
     this.returnuserAllPlan = a;
     this.userAllPlan.next(this.returnuserAllPlan);
     return this.returnuserAllPlan;
    }

    public getAllUserPlan(): any {
      let allPlan, allPlanSend;
      allPlan = this.returnuserAllPlan;
      if (allPlan) {
        allPlanSend = this.formatDuplicate(allPlan, 'id');
      }
     return allPlanSend;
    }

    // unsubscribe display msg
    public storeUnsubscribeDisplayMsg(a: any): any {
     this.returnunsubscribeDisplayMsg = a;
     this.unsubscribeDisplayMsg.next(this.returnunsubscribeDisplayMsg);
     return this.returnunsubscribeDisplayMsg;
    }

    // store only active plan
    public storeOnlyActivePLan(a: any): any {
     this.returnstoreOnlyActive = a;
     this.storeOnlyActive.next(this.returnstoreOnlyActive);
     return this.returnstoreOnlyActive;
    }

    public getOnlyActivePLan(): any {
     return this.returnstoreOnlyActive;
    }

    // store previous url for subscribe popup
    public storeRedirectSubscribe(a: any): any {
     this.returnredirectSubscribePopup = a;
     this.redirectSubscribePopup.next(this.returnredirectSubscribePopup);
     return this.returnredirectSubscribePopup;
    }

    public getRedirectSubscribe(): any {
      return this.returnredirectSubscribePopup;
    }

     // storeErrResponse in my plan
    public storeErrResponse(a: any): any {
      this.returnerrResponse = a;
      this.errResponse.next(this.returnerrResponse);
      return this.returnerrResponse;
    }

    // storeDisplayHeading in my plan
    public storeDisplayHeading(a: any): any {
      this.returndisplayHeading = a;
      this.displayHeading.next(this.returndisplayHeading);
      return this.returndisplayHeading;
    }

     // storeActiveDisplay in my plan
    public storeActiveDisplay(a: any): any {
      this.returnactiveDisplay = a;
      this.activeDisplay.next(this.returnactiveDisplay);
      return this.returnactiveDisplay;
    }

    public getActiveDisplay(): any {
      return this.returnactiveDisplay;
    }

    // storeHistoryDisplay in my plan
    public storeHistoryDisplay(a: any): any {
      this.returnhistoryDisplay = a;
      this.historyDisplay.next(this.returnhistoryDisplay);
      return this.returnhistoryDisplay;
    }

    // storeAllHistoryPlan in my plan
    public storeAllHistoryPlan(a: any): any {
      this.returnstoreAllHistory = a;
      this.storeAllHistory.next(this.returnstoreAllHistory);
      return this.returnstoreAllHistory;
    }

    // getAllHistoryPlan in my plan
    public getAllHistoryPlan(): any {
      let historyPlan, historyPlanSend;
      historyPlan = this.returnstoreAllHistory;
      if (historyPlan) {
        historyPlanSend = this.formatDuplicate(historyPlan, 'id');
      }
      return historyPlanSend;
    }

    // storeAllActivePlan in my plan
    public storePlanActiveAll(a: any): any {
      this.returnstorePlanActive = a;
      this.storePlanActive.next(this.returnstorePlanActive);
      return this.returnstorePlanActive;
    }

    // getAllHistoryPlan in my plan
    public getPlanActiveAll(): any {
      let activePlan, activePlanSend;
      activePlan = this.returnstorePlanActive;
      if (activePlan) {
        activePlanSend = this.formatDuplicate(activePlan, 'id');
      }
      return activePlanSend;
    }

    // store plan api success
    public storePlanApiSucess(a: any): any {
     this.returnplanApiSuccess = a;
     this.planApiSuccess.next(this.returnplanApiSuccess);
     return this.returnplanApiSuccess;
    }

    public getPlanApiSucess(): any {
     return this.returnplanApiSuccess;
    }

     // store active country
    public storeActiveCountry(a: any): any {
     this.returnsubscribedCountry = a;
     this.subscribedCountry.next(this.returnsubscribedCountry);
     return this.returnsubscribedCountry;
    }

    // get active country
    public getActiveCountry(): any {
      let subCountry;
      subCountry = this.returnsubscribedCountry;
     return subCountry;
    }


    // store promo code value
    public storePromoPrice(a: any): any {
     this.returnstorepromoprice = a;
     this.storepromoprice.next(this.returnstorepromoprice);
     return this.returnstorepromoprice;
    }

    public getPromoPrice(): any {
      return this.returnstorepromoprice;
    }

    // store par pack
    public storeActivePAR(a: any): any {
     this.returnstoreActivePARPack = a;
     this.storeActivePARPack.next(this.returnstoreActivePARPack);
     return this.returnstoreActivePARPack;
   }

    // get value of par pack
    public getActivePAR(): any {
     return this.returnstoreActivePARPack;
    }

    // store redem pack
    public storeRedemPackData(a: any): any {
     this.returnstoreRedemPack = a;
     this.storeRedemPack.next(this.returnstoreRedemPack);
     return this.returnstoreRedemPack;
    }

    public getRedemPackData(): any {
     return this.returnstoreRedemPack;
    }

    // store pack close index
    public storePackIndex(a: any): any {
    this.returnindexPackClose = a;
    this.indexPackClose.next(this.returnindexPackClose);
    return this.returnindexPackClose;
  }

  public getPackIndex(): any {
    return this.returnindexPackClose;
  }

     // highlight procced btn
    public storeBtnHighlight(a: any): any {
    this.returnBtnHighlight = a;
    this.btnHighlight.next(this.returnBtnHighlight);
    return this.returnBtnHighlight;
  }

    // show/hide btn in view details
    public storeBtnShowHide(a: any): any {
      this.returnbtnDetails = a;
      this.btnDetails.next(this.returnbtnDetails);
      return this.returnbtnDetails;
    }

    public getBtnShowHide(): any {
      return this.returnbtnDetails;
    }

     // selected Card payment provider
  public storeselCardPayProvider(a: any): any {
    this.returnselCardAllPayment = a;
    this.selCardAllPayment.next(this.returnselCardAllPayment);
    return this.returnselCardAllPayment;
  }

  public getselCardPayProvider() {
    return this.returnselCardAllPayment;
  }

  // sub bg img
  public storeSubBgImg(a: any): any {
    this.returnsubBgImg = a;
    this.subBgImg.next(this.returnsubBgImg);
    return this.returnsubBgImg;
  }

  // payment failure query parameter
  public storePayFailQuery(a: any): any {
    this.returnpayFailQuery = a;
    this.payFailQuery.next(this.returnpayFailQuery);
    return this.returnpayFailQuery;
  }

    public getPayFailQuery(): any {
      return this.returnpayFailQuery;
    }


  // display offer details in info card
  public storeOfferDetails(a: any): any {
    this.returndisplayOfferDetails = a;
    this.displayOfferDetails.next(this.returndisplayOfferDetails);
    return this.returndisplayOfferDetails;
  }

  public getOfferDetails() {
    return this.returndisplayOfferDetails;
  }

   // display offer banner in sub page
  public storeOfferBanner(a: any): any {
    this.returndisplayOfferBanner = a;
    this.displayOfferBanner.next(this.returndisplayOfferBanner);
    return this.returndisplayOfferBanner;
  }

  public getOfferBanner() {
    return this.returndisplayOfferBanner;
  }

  // display same text in offer banner
  public storeSameBannerText(a: any): any {
    this.returndisplaySameBannerText = a;
    this.displaySameBannerText.next(this.returndisplaySameBannerText);
    return this.returndisplaySameBannerText;
  }

  public getSameBannerText() {
    return this.returndisplaySameBannerText;
  }

  // append text for before tv
  public storeBeforeTvText(a: any): any {
    this.returnappendBeforeTvText = a;
    this.appendBeforeTvText.next(this.returnappendBeforeTvText);
    return this.returnappendBeforeTvText;
  }

  public getBeforeTvText() {
    return this.returnappendBeforeTvText;
  }

  // active regional pacl
  public storeActiveRegionalPack(a: any): any {
    this.returnactiveRegionalPack = a;
    this.activeRegionalPack.next(this.returnactiveRegionalPack);
    return this.returnactiveRegionalPack;
  }

  public getActiveRegionalPack() {
    let regionalPack;
    regionalPack = this.returnactiveRegionalPack;
    // entire subcription plan response is stored
    if (regionalPack) {
      regionalPack = regionalPack.filter((thing, index, self) =>
      index === self.findIndex((t) => (
        // buy subscription outer id
         t.id === thing.id
      ))
    );
    }


     if (regionalPack && regionalPack.length > 1) {
        regionalPack = regionalPack.filter((thing, index, self) =>
        index === self.findIndex((t) => (
        // buy subscription outer id
          new Date(t.subscripiton_end) > new Date(thing.subscripiton_end)
        ))
    );
     }
     return regionalPack;
  }

  // active regional pack language
  public storeActiveRegionalPackLang(a: any): any {
    this.returnactiveRegionalPackLang = a;
    this.activeRegionalPackLang.next(this.returnactiveRegionalPackLang);
    return this.returnactiveRegionalPackLang;
  }
  // selected upgrade pack
  public storeUpgradePackSelect(a: any): any {
    this.returnselectUpgradePack = a;
    this.selectUpgradePack.next(this.returnselectUpgradePack);
    return this.returnselectUpgradePack;
  }

  public getUpgradePackSelect(): any {
     return this.returnselectUpgradePack;
  }

  // store list of upgrade pack
  public storeListPackSelect(a: any): any {
    this.returnlistUpgradePack = a;
    this.listUpgradePack.next(this.returnlistUpgradePack);
    return this.returnlistUpgradePack;
  }

  public getListPackSelect(): any {
     return this.returnlistUpgradePack;
  }

  // store upgrade pack discount details
  public storeUpgradeDiscount(a: any): any {
    this.returnupgradeDiscount = a;
    this.upgradeDiscount.next(this.returnupgradeDiscount);
    return this.returnupgradeDiscount;
  }

  public getDiscountDetails(): any {
     return this.returnupgradeDiscount;
  }

  // whether free trial pack exists or not
  public storeFreePack(a: any): any {
    this.returnFreePack = a;
    this.freePack.next(this.returnFreePack);
    return this.returnFreePack;
  }

  public getFreePack(): any {
    return this.returnFreePack;
  }

  //  free trial pack id
  public storeFreePackDetails(a: any): any {
    this.returnFreePackDetails = a;
    this.freePackDetails.next(this.returnFreePackDetails);
    return this.returnFreePackDetails;
  }

  //  free trial pack id
  public getFreePackDetails(): any {
    return this.returnFreePackDetails;
  }

    //  url details
  public storeUrlDetails(a: any): any {
    this.returnurlDetails = a;
    this.urlDetails.next(this.returnurlDetails);
    return this.returnurlDetails;
  }

  //  url details
  public getUrlDetails(): any {
    return this.returnurlDetails;
  }

      //  url details
  public storeUrlDetailsFlag(a: any): any {
    this.returnurlDetailsFlag = a;
    this.urlDetailsFlag.next(this.returnurlDetailsFlag);
    return this.returnurlDetailsFlag;
  }

  //  url details
  public getUrlDetailsFlag(): any {
    return this.returnurlDetailsFlag;
  }

  // store index of free pack
  public storeIndexFreePack(a: any): any {
    this.returnindexFreePack  = a;
    this.indexFreePack.next(this.returnindexFreePack);
    return this.returnindexFreePack ;
  }


    // index of free pack
  public getIndexFreePack(): any {
    return this.returnindexFreePack;
  }


  //  pending pack details
  public storePendingPack(a: any): any {
    this.returnpendingPacks = a;
    this.pendingPacks.next(this.returnpendingPacks);
    return this.returnpendingPacks;
  }

  // pending pack details
  public getPendingPack(): any {
    return this.returnpendingPacks;
  }

  //  pending pack status from subscription
  public storeSubPendingStatus(a: any): any {
    this.returnsubPendStatus = a;
    this.subPendStatus.next(this.returnsubPendStatus);
    return this.returnsubPendStatus;
  }

  // pending pack status from subscription
  public getSubPendingStatus(): any {
    return this.returnsubPendStatus;
  }

   //  telco user flag for my account
  public storeTelcoFlag(a: any): any {
    this.returntelcoUsersFlag = a;
    this.telcoUsersFlag.next(this.returntelcoUsersFlag);
    return this.returntelcoUsersFlag;
  }

  // telco user flag for my account
  public getTelcoFlag(): any {
    return this.returntelcoUsersFlag;
  }

  //  telco user flag for sunscription
  public storeTelcoFlagSub(a: any): any {
    this.returntelcoUsersFlagSub = a;
    this.telcoUsersFlagSub.next(this.returntelcoUsersFlagSub);
    return this.returntelcoUsersFlagSub;
  }

  // telco user flag for my account
  public getTelcoFlagSub(): any {
    return this.returntelcoUsersFlagSub;
  }

  //  telco user name
  public storeTelcoName(a: any): any {
    this.returntelcoUsersName = a;
    this.telcoUsersName.next(this.returntelcoUsersName);
    return this.returntelcoUsersName;
  }

  // telco user name
  public getTelcoName(): any {
    return this.returntelcoUsersName;
  }

  // store plan api success
    public storeRenewStat(a: any): any {
     this.returnrenewStat = a;
     this.renewStat.next(this.returnrenewStat);
     return this.returnrenewStat;
  }

    public getRenewStat(): any {
     return this.returnrenewStat;
    }

  public storePromoPrevId(a: any): any {
    this.returnPrevPromoId = a;
    this.storePrevPromoId .next(this.returnPrevPromoId );
    return this.returnPrevPromoId;
  }

  public getPromoPrevId(): any {
    return this.returnPrevPromoId;
  }

  public storeAllAccessPackVal(a: any): any {
    this.returnAllAccessPack = a;
    this.storeAllAccessPack.next(this.returnAllAccessPack );
    return this.returnAllAccessPack;
  }

  public getAllAccessPackVal(): any {
    return this.returnAllAccessPack;
  }

  public storeSubHideBtnConfig(a: any): any {
    this.returnhideSubBtnConfig = a;
    this.hideSubBtnConfig.next(this.returnhideSubBtnConfig );
    return this.returnhideSubBtnConfig;
  }

  public getSubHideBtnConfig(): any {
    return this.returnhideSubBtnConfig;
  }

  public checkActiveAsset(asset): any {
    return (asset === 0 || asset === 6 || asset === 9);
  }

  public getAllAccessPack(): any {
    let activePlan, assetFlag, langFlag, sendFlag, allactivePlan, assetVal;
    assetFlag = false;
    langFlag = false;
    assetVal = false;
    allactivePlan = this.getPlanActiveAll();
    activePlan = [];
    for (let ccodecheck = 0; ccodecheck < allactivePlan.length; ccodecheck++) {
      let countryVal;
      countryVal = allactivePlan[ccodecheck].countries ? allactivePlan[ccodecheck].countries : allactivePlan[ccodecheck].country;
      if (countryVal.length === 1) {
        if (allactivePlan[ccodecheck].country === this.localstorage.getItem('country_code')) {
            activePlan.push(allactivePlan[ccodecheck]);
          }
      } else {
         for (let g = 0; g < countryVal.length; g++) {
           if (allactivePlan[ccodecheck].countries[g] === this.localstorage.getItem('country_code')) {
              activePlan.push(allactivePlan[ccodecheck]);
            }
         }
      }
      }
    if (activePlan && activePlan.length > 0 ) {
      let countLang, count;
      countLang = false;
      count = 0;
      for (let a = 0; a < activePlan.length; a++) {
        // check lang nodes
        if ((activePlan[a].channel_lang && activePlan[a].channel_lang.length === 0) && (activePlan[a].movie_lang && activePlan[a].movie_lang.length === 0) && (activePlan[a].tv_lang && activePlan[a].tv_lang.length === 0)) {
            countLang = true;
          }
          langFlag = (countLang) ? (true) : (false);
          if (langFlag) {
            // check asset types
            if (activePlan[a].planAssestType && activePlan[a].planAssestType !== '') {
              let activeAsset;
              activeAsset = activePlan[a].planAssestType;
              if (activeAsset.length === 3) {
                assetVal = activeAsset.every(this.checkActiveAsset);
                assetFlag = assetVal ? (true) : (false);
              } else {
                // length !== 3
                assetFlag = false;
              }
            } else {
              // invalid assest
              assetFlag = false;
            }
          } else {
              assetFlag = false;
          }
          if (assetFlag && langFlag) {
            break;
          }
      }
    } else {
      // no active pack
      assetFlag = false;
      langFlag = false;
    }
    sendFlag = (assetFlag && langFlag) ? true : false;
    if (sendFlag) {
      this.storeAllAccessPackVal(true);
    }
    // return sendFlag;
  }

  // hide sub pink btn from config
  public subBtnHideConfig(): any {
    // hide susbcription btn from config
    let configDetails, checkDetails, subConfigVal, subConfigShow, activePlan;
    activePlan = this.getPlanActiveAll();
    configDetails = this.settingsService.getCompleteConfig();
      checkDetails = (configDetails && configDetails.subscription_show_details) ?  configDetails.subscription_show_details : '';
      subConfigVal = checkDetails.config_check ? checkDetails.config_check : '';
        subConfigShow = checkDetails.hide_subscription ? checkDetails.hide_subscription : '';
    if ((activePlan && activePlan.length > 0) && (checkDetails) && (subConfigVal && subConfigShow)) {
          this.storeSubHideBtnConfig(true);
        } else {
          // config value unavailable
          this.storeSubHideBtnConfig(false);
        }
 }

  // check telco user from settings API
  public callTelcoUser(settingsValue): any {
      let settingValue;
      settingValue = settingsValue;
      if (settingValue && settingValue.length > 0) {
        let indexValue, appValue, accValGet, subValGet, accValSet, subValSet, telcoName, telcoMsg, getLangVal, configVal;
        indexValue = settingValue.findIndex( index => index.key === 'partner_app_config');
        if (indexValue !== -1) {
          appValue = settingValue[indexValue].value ? JSON.parse((settingValue[indexValue].value)) : '';
          if (appValue[0]) {
            accValGet = (appValue[0].my_active_plans) ? (appValue[0].my_active_plans.toLowerCase()) : '';
            subValGet = (appValue[0].buy_subscription) ? (appValue[0].buy_subscription.toLowerCase()) : '';
            telcoName = (appValue[0].partner_subscription_language_key) ? (appValue[0].partner_subscription_language_key) : '';
            accValSet = (accValGet.length > 0 && accValGet === 'false') ? true : false;
            subValSet = (subValGet.length > 0 && subValGet === 'false') ? true : false;
            this.storeTelcoFlag(accValSet); // store for my account
            this.storeTelcoFlagSub(subValSet); // store for subscription
            this.checkTelcoNav(); // navigation for telco
            getLangVal = this.settingsService.completeGetLang;
            if (getLangVal.app_in_app && getLangVal.app_in_app[telcoName]) {
              telcoMsg = getLangVal.app_in_app[telcoName];
            } else {
              configVal = this.settingsService.getCompleteConfig();
              telcoMsg = configVal.app_in_app.partner_subscription_partnerapp;
            }
            this.storeTelcoName(telcoMsg);
            }
        } else {
            this.storeTelcoFlag(false); // store for my account
            this.checkTelcoNav(); // navigation for telco

        }
      }
  }

  public checkTelcoNav(): any {
    let accCheck ;
    accCheck = this.getTelcoFlag();
    if (accCheck) {
      if ((this.router.url === '/myaccount/plans') || (this.router.url === '/myaccount/payments') || (this.router.url === '/myaccount')) {
        this.router.navigate(['/myaccount/subscription']);
      }
    }
  }

    public formatDuplicate(myArr, prop): any {
      return myArr.filter((obj, pos, arr) => {
        return arr.map(mapObj => mapObj[prop]).indexOf(obj[prop]) === pos;
    });
}

    // display asset types in pack details
    public storePackAsset(assetArrayRec: any): any {
      if (assetArrayRec) {
        this.assetArray = assetArrayRec.sort(function(a, b) {return a - b; });
        this.assetName = ' ';
        this.appendTxt = '';
        this.appendTxtvalue = '';
        this.translate.get(['MENU.TVSHOWS', 'MENU.MOVIES', 'GUIDED_TOUR.LIVE_TV']).subscribe(value => {
          this.tvshow = value['MENU.TVSHOWS'];
          this.movie = value['MENU.MOVIES'];
          this.livetv = value['GUIDED_TOUR.LIVE_TV'];
        });
        for ( let g = 0; g < this.assetArray.length ; g++) {
          switch (this.assetArray[g]) {
            case 0:
              this.assetName = this.assetName + this.movie + ' ' + '+' + ' ';
              continue;
              case 6:
              this.assetName = this.assetName + this.tvshow + ' ' + '+' + ' ';
              this.appendTxt = true;
              continue;
              case 9:
              this.assetName = this.assetName + this.livetv + ' ' + '+' + ' ';
              continue;
           }
        }
         this.assetName = this.assetName.substring(0, this.assetName.length - 2);
         this.appendTxtvalue = {
           'assetName' : this.assetName,
           'appendTxt' : this.appendTxt
         };
         return this.appendTxtvalue;
      } else {
        this.assetName = ' ';
        this.appendTxt = '';
         this.appendTxtvalue = {
           'assetName' : this.assetName,
           'appendTxt' : this.appendTxt
         };
        return this.appendTxtvalue;
      }
    }

    // check active/history for my plans
    public checkValidity(endDate: any): any {
      this.endReceived = new Date(endDate);
      this.diffEnd = Math.ceil((this.endReceived - this.todayCompare) / (1000 * 3600 * 24));
      if (this.diffEnd > 0) {
        this.inActiveFlag = true;
      } else {
        this.inActiveFlag = false;
      }
      return this.inActiveFlag;
    }

    public checkActiveHistory(value: any): any {
      this.valueReceived = value;
      for (let i = (this.valueReceived.length - 1); i >= 0 ; i--) {
        if (this.valueReceived[i] === undefined) {
            this.valueReceived.splice(i, 1);
          }
        }
      if ((this.valueReceived !== undefined) && (this.valueReceived !== []) && (this.valueReceived.length > 0)) {
        for (let k = 0; k < this.valueReceived.length ; k++) {
          this.totalUserPlan.push(this.valueReceived[k]);
        }
      }
    }

    public getServerTimeActive(paytmflag: any, guestFlag: any): void {
      if (this.myplanCallMade) {
        return;
      }
      this.myplanCallMade = true;
      let url;
      url = environment.serverTimeUrl;
      let time = null;
      this.setUniversalValue();
      this.user = this.localstorage.getItem('token');
      if (this.user) {
          this.tagBearer = 'bearer ' + this.user;
        }
      this.config = {
        apiKey: this.tagBearer,
        username: ' ',
        password: ' ',
        accessToken: ' ',
        withCredentials: false
      };
      this.epgService.getcurrentTime(url).timeout(environment.timeOut).subscribe(value => {
        time = value;
        if (time != null) {
            this.receiveServerDate = time.serverdate;
            this.compareServerDate = new Date(this.receiveServerDate);
            this.todayCompare = this.compareServerDate;
            this.checkCampaign(); // check if campaign stays for more than 30 days
            if (!guestFlag) {
              this.callUserSubscription(paytmflag);
            } else {
              this.myplanCallMade = false;
            }
        } else {
            this.today = new Date();
            this.todayCompare =  new Date(this.today);
            this.checkCampaign(); // check if campaign stays for more than 30 days
            if (!guestFlag) {
              this.callUserSubscription(paytmflag);
            } else {
              this.myplanCallMade = false;
            }
        }
      }, error => {
         this.today = new Date();
         this.todayCompare =  new Date(this.today);
         this.checkCampaign(); // check if campaign stays for more than 30 days
         if (!guestFlag) {
           this.callUserSubscription(paytmflag);
         } else {
              this.myplanCallMade = false;
            }
         this.gtm.sendErrorEvent('api', error);
      });
    }

    public checkCampaign(): any {
    let lsCam, startDate, todayDate, oneDay, diffDays, camData, camSource;
    lsCam = JSON.parse(this.localstorage.getItem('campaignDetails'));
    if (lsCam !== undefined && lsCam !== null) {
      // qgraph patner value
      camData = lsCam.campaignData;
      camSource = camData['utm_campaign'] ? camData['utm_campaign'] : '';
      if (camSource !== '') {
        // if source available, source parameter added
        this.qgrapheventAdd('source', { 'partner_name': camSource});
      }
    // check older campaign
        startDate = new Date(lsCam.startDate);
        todayDate = (this.today && this.today !== undefined && this.today !== null) ? new Date(this.today) : new Date();
        oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
        diffDays = Math.round(Math.abs((startDate.getTime() - todayDate.getTime()) / (oneDay)));
        if (diffDays > 30) {
          this.localstorage.removeItem('campaignDetails');
        }
      }
  }

       // USER Subscription API call
    public callUserSubscription(paytmflag: any): any {
    this.storeAllActivePlan = [];
    this.totalUserPlan = [];
    this.settingsActivePlan = [];
    this.settingsHistoryPlan = [];
    this.planAllActive = [];
    this.planAllHistory = [];
    this.activeCountry = [];
    this.storeActivePlan = [];
    this.storeHistoryPlan = [];
    this.totalDataActivePlan = [];
    this.totalDataPlanHistory = [];
    this.channelAssetType = [];
    this.movieAssetType = [];
    this.showAssetType = [];
    this.assetCollection = '';
    this.regionalPack = [];
    this.regionalPackLang = [];
    this.storePendingPlan = [];
    this.pendingPack = [];
    this.validPendingPlan = [];
    this.userCountry = this.settingsService.getCountry();
    this.subscriptionApiCall = new subscriptionApi.SubscriptionApi(this.http, null, this.config);
    this.user = this.localstorage.getItem('token');
    if (this.user) {
      // let settingValues;
      // settingValues = this.userapiService.getSettings();
      // this.displayLang = settingValues[1].display_language;
      this.displayLang = this.localstorage.getItem('UserDisplayLanguage');
    } else {
      this.displayLang = this.localstorage.getItem('display_language');
    }
    this.subscriptionApiCall.v1SubscriptionGet(this.displayLang).timeout(environment.timeOut).subscribe(value => {
      let response;
      response = value;
      this.responseActivePlan = response;
      if (this.responseActivePlan) {
       this.storeErrResponse(false);
        for (let j = (this.responseActivePlan.length - 1); j >= 0 ; j--) {
          if ((this.responseActivePlan[j].subscription_start === undefined) || (this.responseActivePlan[j].subscription_end === undefined)) {
            this.responseActivePlan.splice(j, 1);
          }
        }
        // to set active flag as true
        if ((this.responseActivePlan.length > 0)) {
          // set parameters to send to info card
            for (let i = 0; i < this.responseActivePlan.length; i++) {
             if ((this.responseActivePlan[i].subscription_plan !== undefined) && (this.responseActivePlan[i].subscription_start !== undefined)  && (this.responseActivePlan[i].subscription_end !== undefined)) {
              if (!this.responseActivePlan[i].subscription_plan.countries) {
                this.responseActivePlan[i].subscription_plan.countries = [this.responseActivePlan[i].subscription_plan.country];
              }
              // check if active/history
              this.storeActive = this.checkValidity(this.responseActivePlan[i].subscription_end);
              if (this.storeActive) {
                      this.receivedProvider = this.findPaymentProvider(this.responseActivePlan[i].payment_provider.toLowerCase(), this.responseActivePlan[i].additional);
                    this.exceptinalPaymentProvider = this.findExceptionalProvider(this.responseActivePlan[i].subscription_plan.payment_providers);
                    this.payProvider =   this.getFortumoID(this.responseActivePlan[i]);
                    let packAssetName;
                    packAssetName = this.storePackAsset(this.responseActivePlan[i].subscription_plan.asset_types);
                this.storeActivePlan[i] = this.setData('active', this.responseActivePlan[i], packAssetName);
                this.settingsActivePlan.push(this.storeActivePlan[i]);

                this.storeActiveOnly.push(this.storeActivePlan[i]);
                // store asset only if user and pack country matches
                if (this.responseActivePlan[i].subscription_plan.countries.indexOf(this.userCountry) !== -1) {
                // if (this.userCountry === this.responseActivePlan[i].subscription_plan.country) {
                  this.planAssetType.push(this.responseActivePlan[i].subscription_plan.asset_types);
                  // channel audio langugae
                if (this.responseActivePlan[i].subscription_plan.channel_audio_languages && this.responseActivePlan[i].subscription_plan.channel_audio_languages.length > 0) {
                  this.channelAssetType.push(this.responseActivePlan[i].subscription_plan.channel_audio_languages);
                  this.regionalPack.push(this.storeActivePlan[i]);
                  this.regionalPackLang.push(this.responseActivePlan[i].subscription_plan.channel_audio_languages[0]);
                } else {
                  this.channelAssetType.push('');
                }
                // movie audio language
                if (this.responseActivePlan[i].subscription_plan.movie_audio_languages && this.responseActivePlan[i].subscription_plan.movie_audio_languages.length > 0) {
                  this.movieAssetType.push(this.responseActivePlan[i].subscription_plan.movie_audio_languages);
                  this.regionalPack.push(this.storeActivePlan[i]);
                  this.regionalPackLang.push(this.responseActivePlan[i].subscription_plan.movie_audio_languages[0]);

                } else {
                   this.movieAssetType.push('');
                }
                // tv show audio language
                if (this.responseActivePlan[i].subscription_plan.tv_show_audio_languages && this.responseActivePlan[i].subscription_plan.tv_show_audio_languages.length > 0) {
                  this.showAssetType.push(this.responseActivePlan[i].subscription_plan.tv_show_audio_languages);
                  this.regionalPack.push(this.storeActivePlan[i]);
                  this.regionalPackLang.push(this.responseActivePlan[i].subscription_plan.tv_show_audio_languages[0]);
                } else {
                   this.showAssetType.push('');
                }
                }
                // if (this.responseActivePlan[i].subscription_plan.country) {
                //   this.activeCountry.push(this.responseActivePlan[i].subscription_plan.country);
                // }
                if (this.responseActivePlan[i].subscription_plan.countries) {
                  this.activeCountry = this.activeCountry.concat(this.responseActivePlan[i].subscription_plan.countries);
                }

                this.storeAllActivePlan.push(this.storeActivePlan[i]);
                this.totalUserPlan.push(this.storeActivePlan[i]);
                this.planAllActive.push(this.storeActivePlan[i]);
                this.storeActiveDisplay(true);
                 this.storeDisplayHeading(true);
              } else {
                  this.receivedProvider = this.findPaymentProvider(this.responseActivePlan[i].payment_provider.toLowerCase(), this.responseActivePlan[i].additional);
                  this.exceptinalPaymentProvider = this.findExceptionalProvider(this.responseActivePlan[i].subscription_plan.payment_providers);
                  this.payProvider = this.getFortumoID(this.responseActivePlan[i]);
                  let packAssetNameHistory;
                  packAssetNameHistory = this.storePackAsset(this.responseActivePlan[i].subscription_plan.asset_types);
                this.storeHistoryPlan[i] = this.setData('history', this.responseActivePlan[i], packAssetNameHistory);
                this.settingsHistoryPlan.push(this.storeHistoryPlan[i]);
                this.totalUserPlan.push(this.storeHistoryPlan[i]);
                this.storeHistoryDisplay(true);
                this.planAllHistory.push( this.storeHistoryPlan[i]);
                this.storeHistoryDisplay(true);
                this.storeDisplayHeading(true);
              }
            }
          }
          this.assetCollection = {
            '0': this.movieAssetType,
            '6': this.showAssetType,
            '9': this.channelAssetType
          };
            this.totalDataPlanHistory = this.settingsHistoryPlan;
            this.totalDataActivePlan = this.settingsActivePlan;
            this.storeActivePlans(this.totalDataActivePlan);
            this.storeActiveAssestType(this.planAssetType);
            this.storeAllUserPlan(this.totalUserPlan);
            this.activeCountry = this.activeCountry.filter((elem, pos, arr) => {
              return arr.indexOf(elem) === pos;
            });
            this.storeActiveCountry(this.activeCountry);
            this.setAssetLang();
            this.storeActiveRegionalPack(this.regionalPack);
            this.storeActiveRegionalPackLang(this.regionalPackLang);
        } else if (this.responseActivePlan.length === 0) {
          // value =0 and not undefined
             this.totalDataActivePlan = [];
             this.totalDataPlanHistory = [];
             this.storeActiveOnly = [];
             this.totalUserPlan = [];
             this.storeAllUserPlan(this.totalUserPlan);
             this.storeActiveOnly.push(this.storeActivePlan);
             this.storeErrResponse(false);
             this.storeActiveDisplay(false);
             this.storeDisplayHeading(false);
          this.storeActivePlans(this.totalDataActivePlan);
        } else {
          // parameter mis match
            this.storeErrResponse(true);
            this.storeDisplayHeading(false);
            this.storeActiveOnly = [];
            this.totalDataActivePlan = [];
            this.storeActiveOnly.push(this.storeActivePlan);
            this.totalUserPlan = [];
            this.storeAllUserPlan(this.totalUserPlan);
          this.storeActivePlans(this.totalDataActivePlan);
        }
      } else {
        // no response from API
    // no response from API
            this.storeErrResponse(true);
            this.storeDisplayHeading(false);
            this.storeActiveOnly = [];
            this.storeActiveOnly.push(this.storeActivePlan);
            this.totalUserPlan = [];
            this.storeAllUserPlan(this.totalUserPlan);
        }
      this.storeOnlyActivePLan(this.storeAllActivePlan);
      this.storeAllHistoryPlan(this.planAllHistory);
      this.storePlanActiveAll(this.planAllActive);
      this.setAutoRenewal('active');

      let active;
      active = this.getActiveCountry();
      if (active && active.length > 0 && this.paymentProvider === 'Dialog') {
        for (let q = 0; q < active.length; q++) {
          if (active[q].indexOf(this.userCountry) !== -1 && this.userCountry === 'LK') {
          // if (this.userCountry === active[q] && this.userCountry === 'LK') {
            this.headerservicesService.DialogUserCheck(this.paymentProvider);
          }
        }
      }
      this.storePlanApiSucess(true);
       this.callQgraphfunc();
      // paytm AR function call
      if (paytmflag) {
        this.paytmGetSettingsData();
      }
      }, err => {
        this.storePlanApiSucess(false);
            this.storeErrResponse(true);
            this.storeDisplayHeading(false);
            this.planAllActive = [];
            this.planAllHistory = [];
            this.storeAllHistoryPlan(this.planAllHistory);
            this.storePlanActiveAll(this.planAllActive);
            this.storeActiveOnly = [];
            this.storeActiveOnly.push(this.storeActivePlan);
            this.totalUserPlan = [];
            this.storeAllUserPlan(this.totalUserPlan);
            this.callQgraphfunc();
            this.gtm.sendErrorEvent('api', err);
            // paytm AR function call
            if (paytmflag) {
              this.paytmGetSettingsData();
            }
    });
  }

  public pendingPackDetails(): any {
    for (let w = 0; w < this.pendingPack.length; w++) {
      this.receivedProvider = this.findPaymentProvider(this.pendingPack[w].payment_provider.toLowerCase(), this.pendingPack[w].additional);
      this.exceptinalPaymentProvider = this.findExceptionalProvider(this.pendingPack[w].subscription_plan.payment_providers);
      this.payProvider = this.getFortumoID(this.pendingPack[w]);
      let packAssetNameHistory;
      packAssetNameHistory = this.storePackAsset(this.pendingPack[w].subscription_plan.asset_types);
      this.storePendingPlan[w] = this.setData('pending', this.pendingPack[w], packAssetNameHistory);
      // remove pack with invalid providers and no transaction id
      if (this.storePendingPlan[w] && this.storePendingPlan[w].additional_data && this.storePendingPlan[w].additional_data !== '' && this.storePendingPlan[w].additional_data.transaction_id && this.storePendingPlan[w].additional_data.transaction_id !== '') {
        this.validPendingPlan.push(this.storePendingPlan[w]);
      }
    }
     this.storePendingPack(this.validPendingPlan);

  }


  public callQgraphfunc(): void {
    this.setUniversalValue();
  if (this.reload) {
    let configFile, configLang;
    configFile = this.configData;
    configLang = configFile.languages;
    let pack, usertype, status, packName, expiry;
    packName = [];
    expiry = [];
    pack = this.getActivePlan();
    if (pack !== undefined && pack.length > 0) {
      for (let q = 0; q < pack.length; q++) {
       packName.push(pack[q].pack);
       expiry.push(pack[q].sub_end);
      }
        this.packName = packName.join(',');
        this.expiryDate = expiry.join(',');
        usertype = 'subscriber';
        status = 'active';
    } else {
         usertype = 'not_a_subscriber';
         status = 'inactive';
         this.packName = '';
         this.expiryDate = '';
     }
     this.display_language = this.localstorage.getItem('UserDisplayLanguage');
     this.content_language = this.localstorage.getItem('UserContentLanguage');
        this.qgDisplayLang = [];
        if ( this.display_language) {
              this.storeqgDisplayLang = this.display_language.split(',');
        } else {
        this.storeqgDisplayLang = '';
        }

        if ( this.storeqgDisplayLang.length > 0) {
          for (let k = 0; k < configLang.length ; k++) {
            for (let j = 0; j < this.storeqgDisplayLang.length  ; j++) {
              if ( configLang[k].id === this.storeqgDisplayLang[j]) {
                this.qgDisplayLang.push(configLang[k].name);
              }
          }
        }
        }
        this.qgContentLang = [];
        if (this.content_language) {
              this.storeqgContentLang = this.content_language.split(',');
        } else {
              this.storeqgContentLang = '';
        }
        if (this.storeqgContentLang.length > 0) {
          for (let k = 0; k < configLang.length ; k++) {
            for (let j = 0; j < this.storeqgContentLang.length  ; j++) {
                if ( configLang[k].id === this.storeqgContentLang[j]) {
                  this.qgContentLang.push(configLang[k].name);
                }
            }
          }
      }
      let state, country_config;
  country_config = this.settingsService.getCountryValue();
  state = country_config.state_code;
  usertype = this.getUserType('launch');
  this.updateQGraph(this.userdata, this.packName, usertype['userType'], status, this.expiryDate, state, usertype['paymentType']);
  this.callQgraph(false, this.configData);
}
  }
  public updateQGraph(data, pack, usertype, status, expiry, state, paymentType): void {
    this.qgraph = this.headerservicesService.getRemarketing();
      let age, ageValue;
      age = (data && data.birthday) ? new Date(data.birthday) : undefined;
      ageValue = age ? (new Date()).getFullYear() - age.getFullYear() : '';
            this.qgraphevent('identify', { 'email_id': ((data !== (null || undefined)) && data.email) ? data.email : '',
                           'phone': ((data !== (null || undefined)) && data.mobile) ? data.mobile : '',
                           'user_type': usertype,
                           'payment_type': paymentType,
                           'current_subscription_status': status,
                           'subscription_expiry_date': (expiry !== (null || undefined)) ? expiry : '',
                           'gender': ((data !== (null || undefined)) && data.gender) ? data.gender : '',
                           'age':  (ageValue !== (null || undefined)) ? ageValue : '',
                           'subscription_plan':  (pack !== (null || undefined)) ? pack : '',
                           'last_subscription_plan':  pack !== ((null || undefined)) ? pack : '',
                           'display_language': this.qgDisplayLang.join(),
                           'content_language': this.qgContentLang.join(),
                           'country': this.settingsService.getCountry(),
                           'state': state,
                           'user_id': this.localstorage.getItem('token') ? this.localstorage.getItem('ID'): this.localstorage.getItem('guestToken')
                         });

     }
  public qgraphevent(eventname, object) {
    if (this.window.qg) {
      if (this.qgraph) {
        delete object.email_id;
        delete object.phone;
        // delete object.gender;
        // delete object.age;
        // delete object.country;
        // delete object.state;
        object.user_id = this.localstorage.getItem('guestToken');
        qg(eventname, object);
      } else {
        qg(eventname, object);
      }
    }
  }

    public qgrapheventAdd(eventname, object) {
    if (this.window.qg) {
      // if (this.qgraph) {
      //   delete object.country;
      //   qg('event', eventname, object);
      // } else {
        qg('event', eventname, object);
      // }
    }
  }

  public displayDurationName(year: any, month: any, day: any) {
    if (year === undefined) {
        year = ' ';
    }
    if (month === undefined) {
        month = ' ';
    }
    if (day === undefined) {
        day = ' ';
    }
      if (year !== ' ') {
          (year > 1) ? (this.yearName = 'SUSCRIPTION.Years') : ((year === 1) ? (this.yearName = 'SUSCRIPTION.Year') : (this.yearName = ' '));
       if (month > 0) {
         (month === 1) ? (this.monthName = 'SUSCRIPTION.Month') : (this.monthName = 'SUSCRIPTION.Months');
       } else {
         this.monthName = ' ';
       }
      this.dayName = ' ';
      } else if (month !== ' ') {
        (month === 1) ? (this.monthName = 'SUSCRIPTION.Month') : ((month > 1) ? (this.monthName = 'SUSCRIPTION.Months') : (this.monthName = ' '));
       this.yearName = ' ';
       this.dayName = ' ';
     } else if (day !== ' ') {
       (day === 1) ? (this.dayName = 'SUSCRIPTION.Day') : ((day > 1) ? (this.dayName = 'SUSCRIPTION.Days') : ( this.dayName = ' '));
       this.monthName = ' ';
       this.yearName = ' ';
     }
     this.durationStatus = {
       yearName : this.yearName,
       monthName : this.monthName,
       dayName : this.dayName
     };

    return this.durationStatus;
    }

    public findPaymentProvider(apiPaymentProvider, additional): any {
      if (apiPaymentProvider.toLowerCase() === 'paytm') {
          this.paytmName = 'PayTM';
          this.paymentProvider = 'PayTM';
      } else if (apiPaymentProvider.toLowerCase() === 'billdesk') {
          this.paymentProvider = 'BillDesk';
      } else if (apiPaymentProvider.toLowerCase() === 'fortumo') {
          this.paymentProvider = 'Fortumo';
      } else if (apiPaymentProvider.toLowerCase().indexOf('adyen') >= 0) {
          this.paymentProvider = 'Adyen';
          this.adyen_name = 'Adyen';
      } else if (apiPaymentProvider.toLowerCase() === 'google') {
          this.paymentProvider = 'Google';
      } else if (apiPaymentProvider.toLowerCase() === 'apple') {
          this.paymentProvider = 'Apple';
      }  else if (apiPaymentProvider.toLowerCase() === 'dialog') {
          this.paymentProvider = 'Dialog';
      } else if (apiPaymentProvider.toLowerCase() === 'zee5') {
          this.paymentProvider = 'ZEE5';
      } else if (apiPaymentProvider.toLowerCase() === 'crm') {
          this.paymentProvider = (additional && additional.paymentmode) ? additional.paymentmode : '';
      } else {
          this.paymentProvider = apiPaymentProvider;
       }
       return this.paymentProvider;
    }

    public findExceptionalProvider(allPaymentProviders: any): any {
      let checkException;
      checkException = '';
      if (allPaymentProviders && allPaymentProviders.length > 0) {
        for (let l = 0; l < allPaymentProviders.length; l++) {
          if (allPaymentProviders[l].name.toLowerCase() === 'zee5') {
            checkException = false;
          } else {
          checkException = true;
          }
        }
        return checkException;
      } else {
        return true;
      }
    }

    public getFortumoID(provider): any {
      let fortumoID;
      for (let k = 0; k < provider.subscription_plan.payment_providers.length; k++) {
        if (provider.subscription_plan.payment_providers[k].name.toLowerCase() === 'fortumo')  {
          fortumoID = provider.subscription_plan.payment_providers[k].product_reference;
          return fortumoID;
        }
      }
    }

    public setAutoRenewal(plan_type): any {
      this.packArStatusData = [];
      this.payuArIndex = [];
      this.packList = [];
      this.plan_type = plan_type;
      this.packList = (plan_type === 'active') ? (this.getPlanActiveAll()) : this.getAllHistoryPlan();
       this.arStatusApi(0);
    }

    public arStatusApi(index: any): any {
      let payuStatus, payuId, payuArResponse, payuArStatus;
      if (index === 0) {
        this.payuArIndex = [];
        this.packArStatusData = [];
      }
       if (this.packList[index] && this.packList[index].additional_data && (this.packList[index].additional_data.transaction_id && this.packList[index].additional_data.transaction_id !== '')) {
        payuStatus = this.packList[index].additional_data.recurring_enabled;
          payuId = this.packList[index].additional_data.transaction_id;
           if (payuStatus) {
             this.payuArIndex.push(index) ;
            this.userAction.payUARStatus(payuId).timeout(environment.timeOut).subscribe(value => {
              index++;
              payuArResponse = JSON.parse(value._body);
              payuArStatus = payuArResponse.recurring_enabled;
              let valCheck;
              valCheck = {
                'value': payuArStatus ? payuArStatus : false,
                'transaction_id': payuId
              };
              this.packArStatusData.push(valCheck);
              if (index < this.packList.length) {
                this.arStatusApi(index);
              } else {
                this.finishArStatus();
              }
            },
            err => {
              index++;
              let valCheck;
              valCheck = {
                'value': false,
                'transaction_id': payuId
              };
              this.packArStatusData.push(valCheck);
              if (index < this.packList.length) {
                this.arStatusApi(index);
              } else {
                this.finishArStatus();
              }
            });
      } else {
        index++;
             let valCheck;
              valCheck = {
                'value': false,
                'transaction_id': ''
              };
              this.packArStatusData.push(valCheck);
              if (index < this.packList.length) {
                this.arStatusApi(index);
              } else {
                this.finishArStatus();
              }
      }
    } else {
        index++;
        let valCheck;
              valCheck = {
                'value': false,
                'transaction_id': ''
              };
              this.packArStatusData.push(valCheck);
        if (index < this.packList.length) {
          this.arStatusApi(index);
        } else {
          this.finishArStatus();
        }
    }
  }

  public finishArStatus(): any {
    for (let p = 0; p < this.packList.length; p++) {
      if ( this.packList[p] && this.packList[p].additional_data && (this.packList[p].additional_data.transaction_id && this.packList[p].additional_data.transaction_id !== '') && (this.packList[p].additional_data.transaction_id === this.packArStatusData[p].transaction_id) ) {
        this.packList[p].auto_renewal = this.packArStatusData[p].value;
      }
    }
    this.storeRenewStat(true);
    if (this.plan_type === 'active') {
      this.storePlanActiveAll(this.packList);
      this.packArStatusData = [];
      this.setAutoRenewal('history');
    } else {
      this.storeAllHistoryPlan(this.packList);
    }
    if (this.localstorage.getItem('country_code') !== 'IN') {
      this.getAllAccessPack();
    }
    if (this.localstorage.getItem('country_code') === 'IN' && this.activeCountry.indexOf('IN')!==-1) {
      this.subBtnHideConfig();
    }
      this.myplanCallMade = false;
  }


  public setData(status, response, asset): any {
    if (response.payment_provider.toLowerCase().indexOf('crm') !== -1) {
      this.exceptinalPaymentProvider = true;
    }



   this.dataValue = {
                pack : response.subscription_plan.original_title || '',
                price : response.subscription_plan.price !== undefined ? (response.subscription_plan.price === 0 ? '0' : response.subscription_plan.price) : '',
                auto_renewal : (response.additional && (((this.receivedProvider.toLowerCase() === 'warid') || (this.receivedProvider.toLowerCase() === 'telenor') || (this.receivedProvider.toLowerCase() === 'mobilink') || (this.receivedProvider.toLowerCase() === 'zong') || (this.receivedProvider.toLowerCase() === 'etisalat') || (this.receivedProvider.toLowerCase().indexOf('robi') >= 0) || (this.receivedProvider.toLowerCase() === 'qwikcilver') || (this.receivedProvider.toLowerCase() === 'amazonpay_new') || (this.receivedProvider.toLowerCase() === 'payu') || (this.receivedProvider.toLowerCase() === 'paytm') || (this.receivedProvider.toLowerCase() === 'rokuinapp')) && response.additional.recurring_enabled) ) ? response.additional.recurring_enabled :  response.recurring_enabled,
                description: asset,
                pack_id: response.subscription_plan.id || '',
                currency: response.subscription_plan.currency || '',
                planAssestType: response.subscription_plan.asset_types || '',
                sub_start: response.subscription_start,
                sub_end: response.subscription_end,
                id: response.id || '',
                paymentProvider: this.receivedProvider || '',
                status: (status === 'history') ? 'SUSCRIPTION.EXPIRED' : '',
                fortumo_serivce_id: this.payProvider,
                paytm_name: this.paytmName,
                billing_frequency: response.subscription_plan.billing_frequency || '',
                country: response.subscription_plan.country || '',
                countries: response.subscription_plan.countries ? response.subscription_plan.countries : '',
                device_number: response.subscription_plan.number_of_supported_devices >= 0 ? response.subscription_plan.number_of_supported_devices : -1,
                exceptionalProvider: this.exceptinalPaymentProvider,
                additional_data: (response.additional && ((this.receivedProvider.toLowerCase() === 'warid') || (this.receivedProvider.toLowerCase() === 'telenor') || (this.receivedProvider.toLowerCase() === 'mobilink') || (this.receivedProvider.toLowerCase() === 'zong') || (this.receivedProvider.toLowerCase() === 'etisalat') || (this.receivedProvider.toLowerCase().indexOf('robi') >= 0) || (this.receivedProvider.toLowerCase() === 'qwikcilver') || (this.receivedProvider.toLowerCase() === 'amazonpay_new') || (this.receivedProvider.toLowerCase() === 'payu') || (this.receivedProvider.toLowerCase() === 'paytm') || (this.receivedProvider.toLowerCase() === 'rokuinapp'))) ? response.additional : '',
                all_paymentProviders: response.subscription_plan.payment_providers || '',
                // free_trial_num : response.free_trial || -1,
                free_trial_num : ((response.payment_provider && response.payment_provider.toLowerCase() === 'crm' && response.additional) ? response.additional.free_trial : response.free_trial) || -1,
                pack_title: response.subscription_plan.title,
                tv_lang: response.subscription_plan.tv_show_audio_languages ? response.subscription_plan.tv_show_audio_languages : '',
                channel_lang: response.subscription_plan.channel_audio_languages ? response.subscription_plan.channel_audio_languages: '',
                movie_lang: response.subscription_plan.movie_audio_languages ? response.subscription_plan.movie_audio_languages : ''

              };
      return this.dataValue;
  }

   public removeSubLocal(): any {
     this.setUniversalValue();
     this.localstorage.removeItem('subCurr');
     this.localstorage.removeItem('subEnd');
     this.localstorage.removeItem('subId');
     this.localstorage.removeItem('subMode');
     this.localstorage.removeItem('subPack');
     this.localstorage.removeItem('subPrice');
     this.localstorage.removeItem('subPromo');
     this.localstorage.removeItem('subStart');
     this.localstorage.removeItem('subDuration');
     this.localstorage.removeItem('previousUrl');
     this.localstorage.removeItem('selectedCard');
     this.localstorage.removeItem('CouponType');
     this.localstorage.removeItem('subBillingInfo');
     this.localstorage.removeItem('options');
     this.localstorage.removeItem('userMode');
     this.localstorage.removeItem('freeTrial');
     this.localstorage.removeItem('silentLoginToken');
     this.localstorage.removeItem('subActPrice');
     this.localstorage.removeItem('proceedLog');
   }


  public checkPlanApiSuccess(showError: any): any {
    this.setUniversalValue();
    if (this.localstorage.getItem('token')) {
      let planSucess;
      planSucess = this.getPlanApiSucess();
      // plan API
      if (planSucess) {
        this.assetReceivedPlan = this.getActiveAssestType();
        return this.assetReceivedPlan;
      } else {
        if (showError) {
          this.getServerTimeActive(false, false);
        planSucess = this.getPlanApiSucess();
        if (planSucess) {
         this.assetReceivedPlan = this.getActiveAssestType();
          return this.assetReceivedPlan;
       } else {
          if (showError) {
            // this.showFooterToast();
            this.assetReceivedPlan = this.getActiveAssestType();
          } else {
            this.assetReceivedPlan = [];
          }
         return this.assetReceivedPlan;
         }
      } else {
      this.assetReceivedPlan = [];
      return this.assetReceivedPlan;
    }
        }
      } else {
      this.assetReceivedPlan = [];
      return this.assetReceivedPlan;
    }

  }


  public showFooterToast(): any {
    this.setUniversalValue();
    let planSucessToast;
    planSucessToast = this.getPlanApiSucess();
    if (!planSucessToast) {
      this.callToast('assetType-failure');
    }
  }

  public callToast(id) {
    let p;
    p = this.document.getElementById(id);
     this.toastShow(id);
    let scope;
    scope = this;
    setTimeout(function() {
    scope.toastClass(id);
    }, 3000);
  }

  public toastShow(id) {
     $('#' + id).css('visibility', 'visible');
     $('#' + id).css('-webkit-animation', 'fadein 0.5s, fadeout 0.5s 2.5s');
     $('#' + id).css('animation', 'fadein 0.5s, fadeout 0.5s 2.5s');
  }

  public toastClass(id) {
    this.setUniversalValue();
     /*if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i) || this.window.innerWidth <= 768) {
        $('#' + id).css('margin-left', '-40%');
    } else {
        $('#' + id).css('margin-left', '-125px');
    }*/
    /*margin: auto;*/
    /*$('#' + id).css('margin', 'auto');*/
    $('#' + id).css('visibility', 'hidden');
    $('#' + id).css('min-width', '300px');
    $('#' + id).css('background-color', '#6e6e6e');
    $('#' + id).css('color', '#eee');
    $('#' + id).css('text-align', 'center');
    $('#' + id).css('border-radius', '2px');
    $('#' + id).css('padding', '16px');
    $('#' + id).css('position', 'fixed');
    $('#' + id).css('z-index', '1');
    $('#' + id).css('left', '50%');
    $('#' + id).css('bottom', '30px');
    $('#' + id).css('font-size', '17px');
    $('#' + id).css('-webkit-animation', 'none');
    $('#' + id).css('animation', 'none');
    $('#' + id).css({'webkit-transform': 'translate(-50%,-50%)',
                     'moz-transform': 'translate(-50%,-50%)',
                      'ms-transform': 'translate(-50%,-50%)',
                      'transform': 'translate(-50%,-50%)'
                    });

  }


  public checkPARpack(): any {
    let serverDate, packDate, dateDiff, settingsPack, settingsPackDate;
    packDate = [];
    dateDiff = [];
    this.planSucessToastFlag = this.getPlanApiSucess();
    this.storePARpack = [];
    this.localPARstorage = [];
    this.parActivePack = [];

    // check if api call is finished
    if (this.planSucessToastFlag !== undefined) {
      this.activePlanRec = this.getPlanActiveAll();
      serverDate = new Date(this.receiveServerDate);
      if (this.activePlanRec.length > 0) {
      for (let i = 0; i < this.activePlanRec.length; i++) {
        // check for paytm AR pack
        if (((this.activePlanRec[i].paymentProvider && this.activePlanRec[i].paymentProvider.toLowerCase() === 'paytm')) && (this.activePlanRec[i].auto_renewal === true)) {
            packDate[i] = new Date(this.activePlanRec[i].sub_end);
            dateDiff[i] = (packDate[i] - serverDate) / (1000 * 3600 * 24);
            dateDiff[i] = parseInt(dateDiff[i], 10);
            // checking settings data
            settingsPack = this.settingsValRec;
            // check if pack exists in settings
            for (let l = 0; l < settingsPack.length; l++) {
              if (this.activePlanRec[i].pack_id === settingsPack[l].id) {
               settingsPackDate = this.settingsValRec.date.split(',');
              for (let k = 0; k < settingsPackDate.length; k++) {
                if (serverDate === settingsPackDate[k]) {
                this.setDate = true;
              } else {
                this.setDate = false;
              }
              }
            } else if (this.activePlanRec[i].pack_id === settingsPack[l].subscriptionid) {
            //  for (let k = 0; k < settingsPackDate.length; k++) {

              let serverDay, serverMonth, serverYear, settingsDay, settingsMonth, settingsYear;
              serverDay = new Date(serverDate).getDate()
              serverMonth = new Date(serverDate).getMonth()
              serverYear = new Date(serverDate).getFullYear()
              settingsDay = new Date(this.settingsValRec[l].consentdate).getDate()
              settingsMonth = new Date(this.settingsValRec[l].consentdate).getMonth()
              settingsYear = new Date(this.settingsValRec[l].consentdate).getFullYear()
                if ((serverDay === settingsDay) && (serverMonth = settingsMonth) && (serverYear === settingsYear)) {
                this.setDate = true;
                break;
              } else {
                this.setDate = false;
              }
            //  }
            } else {
              this.setDate = false;
            }
            }

            if (((dateDiff[i] === 5) || (dateDiff[i] === 3) || (dateDiff[i] === 1)) && (!this.setDate)) {
              this.storePARpack.push(this.activePlanRec[i]);
            }

      }
      }
     }
      this.storeActivePAR(this.storePARpack);
    } else {
      // todo
    }
  }
  public shownextpopup(indexValue): any {
    this.nextPopup.next(indexValue);
    return indexValue;
  }
  public paytm(status): any {
   this.travllerVal = status;
    this.traveller.next(status);

    return status;
  }

  public getpaytmpopup(): any {
    return this.travllerVal;
  }


    public gaPackDuration(billingInfo): any {
    let displayDayName, displayDay, displayMonth, displayDurationReceived, displayYear, displayMonthName, displayYearName, gaDuration;
    displayDayName = '';
    displayDay = '';
    displayMonth = '';
    displayDurationReceived = '';
    displayYear = '';
    displayMonthName = '';
    displayMonthName = '';
    displayYearName = '';

    if (billingInfo < 30 ) {
           ( billingInfo === 1) ? (displayDayName = 'Day', displayDurationReceived = {day: 1, month: ' ', year: ' '}) : (displayDayName = 'Days', displayDurationReceived = {day: billingInfo, month: ' ', year: ' '});
           displayDay = billingInfo;
          } else {
            displayMonth = Math.ceil((billingInfo) / 30);
(displayMonth === 1) ? (displayMonthName = 'Month', displayDurationReceived = {day: ' ', month: displayMonth, year: ' '})
 : ((displayMonth > 1) && (displayMonth < 12) ? (displayMonthName = 'Months', displayDurationReceived = {day: ' ', month: displayMonth, year: ' '})
  : ((displayMonth = 12) ? (displayMonth = ' ', displayYear  = 1, displayYearName = 'Year', displayDurationReceived = {day: ' ', month: ' ', year: 1 })
   : ( displayMonth = ' ', displayYear  = Math.ceil(displayMonth / 12), displayYearName = 'Years', displayDurationReceived = {day: ' ', month: ' ', year: displayYear })));
}

    gaDuration = (displayDurationReceived.day + ' ' + displayDayName + displayDurationReceived.month + ' ' + displayMonthName + displayDurationReceived.year + ' ' + displayYearName).trim();
    return gaDuration;

  }

   public paytmGetSettingsData(): any {
    let token;
    token = localStorage.getItem('token');
    if (token) {
         let settingValue;
         settingValue = this.getSettingsTotal();
        if (settingValue && settingValue.length > 0) {
          let indexValue;
          indexValue = settingValue.findIndex( index => index.key === 'paytmconsent_v2');
          if (indexValue !== -1) {
            this.settingsValRec = JSON.parse((settingValue[indexValue].value));
            this.checkPARpack();
          } else {
            this.settingsValRec = [];
            this.checkPARpack();
          }
        }
    }
  }
public storeSettings(value): any {
  this.totalSettings = value;
}
public getSettingsTotal(): any {
  return this.totalSettings;
}

public getBgImg(path: any): any {
  let basepath, url;
  this.configValue = this.settingsService.getCompleteConfig();
  this.countryValue = this.settingsService.getCountry();
  if (this.configValue && this.configValue.promotions && this.configValue.promotions.subscription_banner_img) {
    basepath = this.configValue.promotions.subscription_banner_img.basePath;
    if (this.configValue.promotions.subscription_banner_img[this.countryValue] && this.configValue.promotions.subscription_banner_img[this.countryValue].web) {
      if (path === 'mobile') {
        url = (this.configValue.promotions.subscription_banner_img[this.countryValue].web.img_url_mobile) ? (this.configValue.promotions.subscription_banner_img[this.countryValue].web.img_url_mobile) : '';
      } else if (path === 'desktop') {
        url = (this.configValue.promotions.subscription_banner_img[this.countryValue].web.img_url_desktop) ? (this.configValue.promotions.subscription_banner_img[this.countryValue].web.img_url_desktop) : '';
      }
      this.bgImgPath = (url !== '') ? (basepath + url) : '';
    } else {
      // country or web node unavailable
      if (path === 'mobile') {
        url = (this.configValue.promotions.subscription_banner_img.default.web.img_url_mobile) ? (this.configValue.promotions.subscription_banner_img.default.web.img_url_mobile) : '';
      } else if (path === 'desktop') {
        url = (this.configValue.promotions.subscription_banner_img.default.web.img_url_desktop) ? (this.configValue.promotions.subscription_banner_img.default.web.img_url_desktop) : '';
      }
        this.bgImgPath = (url !== '') ? (basepath + url) : '';
      }
  } else {
    // subscription_banner_img node unavailable
    this.bgImgPath = '';
  }
  return this.bgImgPath;
}


  public checkUserPlan(): any {
    let activePlan, historyPlan, showFreeLabels ;
    this.setUniversalValue();
    activePlan = this.getPlanActiveAll();
    historyPlan = this.getAllHistoryPlan();
      if (this.localstorage.getItem('token')) {
        if (activePlan && historyPlan && activePlan.length === 0 && historyPlan.length === 0) {
            showFreeLabels = true;
        } else {
            showFreeLabels = false;
        }
      } else {
          showFreeLabels = true;
      }
    return showFreeLabels;
  }

    public setCommaValues(recData: any): any {
      let dataJoin, dataSplit, sendData;
    if (recData !== undefined) {
      dataJoin = recData.join();
      if (dataJoin.length > 0) {
      dataSplit = dataJoin.split(',');
      // remove duplicates
      for (let a  = 0; a < dataSplit.length; a++) {
        for (let b = (a + 1); b < dataSplit.length; b++) {
          if (dataSplit[a] === dataSplit[b]) {
            dataSplit.splice(b, 1);
          }

        }
      }
    sendData = dataSplit;
    } else {
           sendData = [];
    }
   } else {
     sendData = [];
   }
   return sendData;
  }

  public setAssetLang (): any {
    let setChannel, setMovie, setShow;
    setChannel = [];
    setMovie = [];
    setShow = [];
    setChannel = this.setCommaValues(this.assetCollection[9]);
    setMovie = this.setCommaValues(this.assetCollection[0]);
    setShow = this.setCommaValues(this.assetCollection[6]);
    this.assetCollection = {
      '0' : setMovie,
      '6' : setShow,
      '9' : setChannel
    };
  }


  public checkAssetLang(asset: any, lang: any): any {
    let searchVal, sendFlagVal;
    searchVal = this.assetCollection[asset];
    if (searchVal && searchVal.length) {
      for (let s = 0; s < searchVal.length; s++) {
        if (searchVal[s] === '') {
          sendFlagVal = true;
          return sendFlagVal;
        } else {
        if (lang.indexOf(searchVal[s]) !== -1) {
          sendFlagVal = true;
          return sendFlagVal;
        } else if (s === searchVal.length - 1) {
          sendFlagVal = false;
          return sendFlagVal;
        }
        }
      }
    } else {
      sendFlagVal = true;
          return sendFlagVal;
    }
  }

  public subscripitonPlanListing(packValue: any) {
      this.subParameters = [];
            this.response = packValue;
            if (this.response) {
              if ( (this.response.length > 0)) {
                this.subParameters = [];
                for (let i = 0; i < this.response.length; i++) {
                  if ( (this.response[i].start !== undefined) && (this.response[i].end !== undefined) && (this.response[i].payment_providers !== undefined) && (this.response[i].billing_frequency !== undefined)) {
/*                  this.billdeskSub = false;
                  this.fortumoSub = false;
                  this.paytmSub = false;
                  this.adyenSub = false;
                  this.adyenFlagSub = false;
                  this.payuFlagSub = false;
                  this.mobiwikFlagSub = false;
                  this.phonepayFlagSub = false;
                  this.mifeFlagSub = false;
                  this.payProviderSub = '';
                  this.paymentProviderSub = '';
                  this.paytmNameSub = '';
                  this.adyenNameSendSub = '';
                  this.payuNameSub = '';
                  this.mobiwikNameSub = '';
                  this.phonepayNameSub = '';
                  this.mifeNameSub = '';
                  this.regionalRecProv = '';*/
                  this.fortumoSub = false;
                  this.payProviderSub = '';
                  if ((this.response[i].payment_providers.length > 0) && (this.response[i].billing_frequency > 0)) {
                     for (let k = 0; k < this.response[i].payment_providers.length; k++) {
                      if (this.response[i].payment_providers[k].name.toLowerCase() === 'fortumo' && !this.fortumoSub) {
                        this.payProviderSub = this.response[i].payment_providers[k].product_reference;
                         this.fortumoSub = true;
                      }
                    }
                     this.regionalRecProv = this.allPaymentProviders(this.response[i].payment_providers);
                    this.paymentProvider = this.regionalRecProv.payment_provider;
                    this.showSub[i] = this.checkValiditySubPlan(this.response[i].start, this.response[i].end);
                    if (((this.paymentProvider !== 'None')) && (this.showSub[i])) {
                      this.setDataSub(this.response, i, this.regionalRecProv);
                    } else {
                        this.subscriptionDataSub[i] = {};
                    }
                  } else {
                     this.subscriptionDataSub[i] = {};
                  }
                } else {
                  this.subscriptionDataSub[i] = {};
                }
              }
              // removing blanks
              for (let i = (this.subscriptionDataSub.length - 1); i >= 0 ; i--) {
                if (this.subscriptionDataSub[i].pack === undefined) {
                  this.subscriptionDataSub.splice(i, 1);
                }
              }
               this.showSubPack();
              }  else {
                  this.subParameters = [];
              }
            } else {
              this.subParameters = [];
            }
  }

    public checkValiditySubPlan(startDate: any, endDate: any): any {
      let startReceived, endReceived, diffEnd, diffStart;
    startReceived = new Date(startDate);
    endReceived = new Date(endDate);
    diffEnd = Math.ceil((endReceived - this.todayCompare) / (1000 * 3600 * 24));
    diffStart = Math.ceil((this.todayCompare - startReceived) / (1000 * 3600 * 24));
    if ((diffEnd > 0) && (diffStart > 0)) {
        this.showSubValue = true;
      } else {
        this.showSubValue = false;
      }
    return this.showSubValue;
  }

    public setDataSub(data: any, i: any, recVal: any) {
    this.countPlanSub++;
    let paymentProvider , payProvider , paytmProvider, adyenProvider, adyenSendName, payuProvider, phonePayProvider, mobiwikProvider, sendMifeProvider;
    paymentProvider = ((recVal.payment_provider.toLowerCase() === 'billdesk') ? recVal.payment_provider : null);
    payProvider = (this.fortumoSub ? this.payProvider : null);
    paytmProvider = ((recVal.paytm_name !== '') ? recVal.paytm_name : null);
    adyenProvider = ((recVal.adyen_name !== '') ? recVal.adyen_name : null);
    adyenSendName = ((recVal.adyenSendName !== '') ? recVal.adyenSendName : null);
    payuProvider = ((recVal.payu_Name !== '') ? recVal.payu_Name : null);
    phonePayProvider = ((recVal.phonepay_Name !== '') ? recVal.phonepay_Name : null);
    mobiwikProvider = ((recVal.mobiwik_Name !== '') ? recVal.mobiwik_Name : null);
    sendMifeProvider = ((recVal.mife_Providers !== '') ? recVal.mife_Providers : null);
    // send asset types
    let packAssetName;
    packAssetName = this.storePackAsset(this.response[i].asset_types);
    this.subscriptionDataSub[i] = {
      pack: data[i].title || '',
      price: data[i].price !== undefined ? (data[i].price === 0 ? '0' : data[i].price) : '',
      currency: data[i].currency || '',
      description: packAssetName,
      pack_id: data[i].id || '',
      fortumo_serivce_id: payProvider,
      start_date: data[i].start,
      end_date: data[i].end,
      payment_provider: paymentProvider ,
      billing_frequency: data[i].billing_frequency,
      paytm_name : paytmProvider,
      asset_types : data[i].asset_types || '',
      country: data[i].country || '',
      device_number: data[i].number_of_supported_devices >= 0 ? data[i].number_of_supported_devices : -1,
      adyen_name: adyenProvider,
      all_paymentProviders : data[i].payment_providers,
      adyenSendName : adyenSendName,
      promotions : data[i].promotions,
      auto_renewal : data[i].recurring,
      exceptionalPaymentProvider : this.exceptionalPaymentProviderSub,
      free_trial : data[i].free_trial,
      payu_Name : payuProvider,
      phonepay_Name : phonePayProvider,
      mobiwik_Name : mobiwikProvider,
      mife_Providers : sendMifeProvider,
      actual_price : data[i].actual_value,
      tv_lang: data[i].tv_show_audio_languages,
      channel_lang: data[i].channel_audio_languages,
      movie_lang: data[i].movie_audio_languages,
    };
  }

    public showSubPack(): any {
      let assetMatchVal, assetMatch1, assetMatch2, allFullAccessPack;
      assetMatchVal = false;
      assetMatch1 = false;
      assetMatch2 = false;
      allFullAccessPack = [];
      this.groupSubscriptionPlan(this.subscriptionDataSub);
      this.subParameters = this.finalDataSub;
      this.storeListPackSelect(this.subParameters);
  }



  public groupSubscriptionPlan(allPlans: any): any {
     let totalPlans;
     totalPlans = allPlans;
     this.finalDataSub = [];
       if (totalPlans.length === 1) {
        this.finalDataSub.push([totalPlans[0]]);
       } else {
         for (let i = 0 ; i <  totalPlans.length; i++) {
            for (let j = i ; j <  totalPlans.length; j++) {
            let now;
            now =  this.checkasset(totalPlans[i].asset_types, totalPlans[j].asset_types);
              if ((totalPlans[i].auto_renewal === !(totalPlans[j].auto_renewal)) && (totalPlans[i].price === totalPlans[j].price) && now && (totalPlans[i].billing_frequency === totalPlans[j].billing_frequency)) {
                let tempArr, tempArr1;
                tempArr = totalPlans[i];
                tempArr1 = totalPlans[j];
                let temp;
                temp = [];
               if (tempArr.auto_renewal === true) {
                  temp.push(tempArr);
                  temp.push(tempArr1);
               } else {
                 temp.push(tempArr1);
                 temp.push(tempArr);
               }
                this.finalDataSub.push(temp);
                // if (i > j) {
                  totalPlans.splice(j, 1);
                // }
                break;
              } else {
                if (j === totalPlans.length - 1) {
                  this.finalDataSub.push([totalPlans[i]]);
               }
              }
       }
      }
    }
  }

    public checkasset(a, b) {
    if (a.sort().join(',') === b.sort().join(',')) {
       return  true;
    } else {
      return false;
    }
  }

  public getCountryName(): any {
    let countryValue, countryName;
    countryValue = this.settingsService.getCountryValue();
    countryName = countryValue.country;
    return countryName;
  }

  public allPaymentProviders(allProviders): any {
    let billdesk, fortumo, paytm, adyen, adyenFlag, payuFlag, mobiwikFlag, phonepayFlag, mifeFlag, payProvider, paymentProvider, paytmName, adyenNameSend, payuName, mobiwikName, phonepayName, mifeName, exceptionalPaymentProvider, adyenName, sendPaymentProviders, sendPaymentProvider, sendPayProvider, paytmProvider, adyenProvider, adyenSendName, payuProvider, phonePayProvider, mobiwikProvider, sendMifeProvider, checkPara, amazonFlag, amazonName, sendAmazonName, qwikcilverFlag, qwikcilverName, sendQwikcilverName, robiName, robiFlag, sendRobiName, mobilePayments, sendMobilePayments, etisalatFlag, etisalatName, waridFlag, waridName, telenorFlag, telenorName, mobilinkFlag, mobilinkName, zongFlag, zongName;
    billdesk = false;
    fortumo = false;
    paytm = false;
    adyen = false;
    adyenFlag = false;
    payuFlag = false;
    mobiwikFlag = false;
    phonepayFlag = false;
    mifeFlag = false;
    amazonFlag = false;
    qwikcilverFlag = false;
    robiFlag = false;
    etisalatFlag = false;
    waridFlag = false;
    telenorFlag = false;
    mobilinkFlag = false;
    zongFlag = false;
    payProvider = '';
    paymentProvider = '';
    paytmName = '';
    adyenNameSend = '';
    payuName = '';
    mobiwikName = '';
    phonepayName = '';
    mifeName = '';
    amazonName = '';
    robiName = '';
    exceptionalPaymentProvider = '';
    sendPaymentProviders = [];
    adyenName = '';
    sendMobilePayments = '';
    mobilePayments = [];
    etisalatName = '';
    waridName = '';
    telenorName = '';
    mobilinkName = '';
    zongName = '';
      if ((allProviders.length > 0)) {
        for (let k = 0; k < allProviders.length; k++) {
          checkPara = (allProviders[k].name) ? (allProviders[k].name) : allProviders;
          if (checkPara.toLowerCase() === 'fortumo' && !fortumo) {
            /*payProvider = this.getFortumoID(this.responseActivePlan[i]);*/
            fortumo = true;
          } else if (checkPara.toLowerCase() === 'billdesk' && !billdesk) {
              paymentProvider = 'BillDesk';
              billdesk = true;
          } else if (checkPara.toLowerCase() === 'paytm' && !paytm) {
              paytmName = 'PayTM';
              paytm = true;
          } else if (checkPara.toLowerCase() === 'payu' && !payuFlag) {
              payuName = 'PayU';
              payuFlag = true;
          } else if (checkPara.toLowerCase().indexOf('adyen') >= 0 && !adyen) {
              adyenName = 'Adyen';
              adyen = true;
              adyenNameSend = checkPara;
          } else if (checkPara.toLowerCase() === 'phonepe' && !phonepayFlag) {
              phonepayName = 'PhonePay';
              phonepayFlag = true;
          } else if (checkPara.toLowerCase() === 'mobikwik' && !mobiwikFlag) {
              mobiwikName = 'Mobiwik';
              mobiwikFlag = true;
          }  else if (checkPara.toLowerCase() === 'amazonpay_new' && !amazonFlag) {
              amazonName = checkPara;
              amazonFlag = true;
          }  else if (checkPara.toLowerCase() === 'qwikcilver' && !qwikcilverFlag) {
              qwikcilverName = checkPara;
              qwikcilverFlag = true;
          }  else if (checkPara.toLowerCase().indexOf('robi') >= 0 && !robiFlag) {
              robiName = checkPara;
              robiFlag = true;
              mobilePayments.push(checkPara.toLowerCase());
          }  else if (checkPara.toLowerCase() === 'etisalat' && !etisalatFlag) {
              etisalatName = checkPara;
              etisalatFlag = true;
              mobilePayments.push(checkPara.toLowerCase());
          }  else if (checkPara.toLowerCase() === 'warid' && !waridFlag) {
              waridName = checkPara;
              waridFlag = true;
              mobilePayments.push(checkPara.toLowerCase());
          }  else if (checkPara.toLowerCase() === 'telenor' && !telenorFlag) {
              telenorName = checkPara;
              telenorFlag = true;
              mobilePayments.push(checkPara.toLowerCase());
          }  else if (checkPara.toLowerCase() === 'mobilink' && !mobilinkFlag) {
              mobilinkName = checkPara;
              mobilinkFlag = true;
              mobilePayments.push(checkPara.toLowerCase());
          }   else if (checkPara.toLowerCase() === 'zong' && !zongFlag) {
              zongName = checkPara;
              zongFlag = true;
              mobilePayments.push(checkPara.toLowerCase());
          } else if (checkPara.toLowerCase() === 'mife' && !mifeFlag) {
              mifeFlag = true;
              let mifeProvider, mifeOperators, mifeList, mifeOpr, mifeOprList, mifeOperatorList;
              mifeProvider = allProviders[k].product_reference;
              if (mifeProvider) {
                mifeOperators = mifeProvider.split('$$');
                mifeList = '';
                mifeOpr = '';
                mifeOprList = [];
                mifeOperatorList = [];
                if (mifeOperators) {
                  for (let g = 0; g < mifeOperators.length; g++) {
                    mifeOpr = mifeOperators[g].split('|');
                    mifeOprList = {
                      'apiData' : mifeOpr[0],
                      'displayData' : mifeOpr[1]
                    };
                       mifeOperatorList.push(mifeOprList);
                    }
                    mifeName = mifeOperatorList;
                 } else {
                    mifeName = [];
                }
              } else {
                 mifeOperatorList = [];
                   mifeOprList = {
                      'apiData' : checkPara,
                      'displayData' : checkPara
                    };
                       mifeOperatorList.push(mifeOprList);
                    mifeName = mifeOperatorList;
              }
          }  else if (!fortumo && !billdesk && !paytm && !payuFlag && !phonepayFlag && !mobiwikFlag && !mifeFlag && !adyen && !amazonFlag && !qwikcilverFlag && !robiFlag && !etisalatFlag && !waridFlag && !telenorFlag && !mobilinkFlag && !zongFlag && k === (allProviders.length - 1)) {
                        paymentProvider = 'None';
                      } else if (!billdesk) {
                        paymentProvider = 'Extra';
                      }
            if (!fortumo && !billdesk && !payuFlag && !paytm && adyen && !phonepayFlag && !mobiwikFlag  && !mifeFlag && !amazonFlag && !qwikcilverFlag && robiFlag && !etisalatFlag && !waridFlag && !telenorFlag && !mobilinkFlag && !zongFlag &&  k === (allProviders.length - 1) && checkPara.toLowerCase().indexOf('adyen') >= 0) {
              adyenFlag = true;
              adyenNameSend = checkPara;
             }
            exceptionalPaymentProvider = (checkPara.toLowerCase() === 'zee5') ? false : true;
        }}
      sendPaymentProvider = (paymentProvider);
      sendPayProvider = (fortumo ? payProvider : null);
      paytmProvider = (paytm ? paytmName : null);
      adyenProvider = (adyen ? adyenName : null);
      adyenSendName = (adyen ? adyenNameSend : null);
      payuProvider = (payuFlag ? payuName : null);
      phonePayProvider = (phonepayFlag ? phonepayName : null);
      mobiwikProvider = (mobiwikFlag ? mobiwikName : null);
      sendMifeProvider = (mifeName ? mifeName : null);
      sendAmazonName =  (amazonFlag ? amazonName : null);
      sendQwikcilverName = (qwikcilverFlag ? qwikcilverName : null);
      sendRobiName = (robiFlag ? robiName : null);
      sendMobilePayments = (mobilePayments ? mobilePayments : null);
       sendPaymentProviders = {
          fortumo_serivce_id: sendPayProvider,
          paytm_name : paytmProvider,
          adyen_name: adyenProvider,
          payment_provider: sendPaymentProvider ,
          exceptionalPaymentProvider : exceptionalPaymentProvider,
          payu_Name : payuProvider,
          phonepay_Name : phonePayProvider,
          mobiwik_Name : mobiwikProvider,
          mife_Providers : sendMifeProvider,
          adyenSendName : adyenSendName,
          amazonName : sendAmazonName,
          qwikcilverName : sendQwikcilverName,
          robiName: sendRobiName,
          mobilePaymentName: sendMobilePayments
       };
      return sendPaymentProviders;
  }
  public getActiveRegionalPackLang(): any {
    let sendData;
    this.setUniversalValue();
    if (this.localstorage.getItem('token')) {
      sendData = this.returnactiveRegionalPackLang && this.returnactiveRegionalPackLang[0] ? this.returnactiveRegionalPackLang[0] : '';
    } else {
       sendData = '';
    }
    return sendData;
  }
  public compareRegionalPack(): any {   // for RSVOD lang
    let userContentLanguage, pushLang, contentLanguages, data;
    contentLanguages = [];
    data = this.getActiveRegionalPackLang();
    if (this.localstorage.getItem('token')) {
      userContentLanguage = localStorage.getItem('UserContentLanguage');
    } else {
      userContentLanguage = localStorage.getItem('ContentLang');
    }
    pushLang = userContentLanguage.split(',');
    for ( let i = 0; i < pushLang.length; i++) {
      contentLanguages.push(pushLang[i]);
    }
    if (contentLanguages.indexOf(data) < 0) {
      this.updateContentLang(data);
    }
  }
  public updateContentLang(lang): any {  // if RSVOD lang not there update lang & for on first launch update displaylang not part of content lang
    // alert('updateContentLang')
    let b, str, pushLang = [], defaultLanguages;
    defaultLanguages = [];
    b = this.localstorage.getItem('token') ? this.localstorage.getItem('UserContentLanguage') : this.localstorage.getItem('ContentLang');
    pushLang =  b.split(',');
    for ( let i = 0; i < pushLang.length; i++) {
       defaultLanguages.push(pushLang[i]);
    }
    defaultLanguages.push(lang);
    str = defaultLanguages.join();
    let localStoragevalue;
    localStoragevalue = [];
    localStoragevalue.push(str);
    if (this.localstorage.getItem('token')) {
      this.userapiService.getParameter('put', 'content_language', str);
      this.localstorage.setItem('UserContentLanguage', str);
    } else if (!this.localstorage.getItem('token')) {
      this.localstorage.setItem( 'ContentLang', localStoragevalue);
    }
  }

    public firsttimeDisplayLang(): any {  // to store browser lang
    let langStored, langarr = [], displayLangstored, token;
    token = localStorage.getItem('token');
    langStored = this.navigator.language;
    langStored = langStored.slice(0, 2);
    langarr = this.headerservicesService.getDisplayCodes();
    if (langarr.indexOf(langStored) < 0) {
      // displayLangstored = 'en'; by default en bt now taking from api
    } else {
      displayLangstored = langStored;
      localStorage.setItem('display_language', displayLangstored);
      this.translate.use('z5-strings-' + displayLangstored);
      this.updateContentwithDisplay(displayLangstored);
    }
  }
  public updateContentwithDisplay(displayLangstored): any {  // to update browser lang to content lang
    let token, userContentLanguage, pushLang = [], contentLanguages;
    contentLanguages = [];
        token = localStorage.getItem('token');
        userContentLanguage = localStorage.getItem('ContentLang');
        pushLang = userContentLanguage.split(',');
        for ( let i = 0; i < pushLang.length; i++) {
          contentLanguages.push(pushLang[i]);
        }
        if (!token) {
          if (contentLanguages.indexOf(displayLangstored) < 0) {
            this.updateContentLang(displayLangstored);
          }
        }
  }

  /*change sec to hh:mm:ss format*/
    public updateTime(s): any {
    let secs, mins, hrs, time, hrsStr;
    secs = s % 60;
    s = (s - secs) / 60;
    mins = s % 60;
    s = (s - mins) / 60;
    hrs = s % 60;
    secs = Math.floor(secs);
    hrsStr = hrs ? ((hrs < 10 ? '0' + hrs : hrs) + ':') : '';
    time = hrsStr + (mins < 10 ? '0' + mins : mins) + ':' + (secs < 10 ? '0' + secs : secs);
    return time;
  }

  /* store payment providers*/
  public storeAllPaymentProvider(cardSelected: any): void {
  let paymentProviderData, sendPaymentData;
    sendPaymentData = [];
    for (let i = 0; i < cardSelected.length; i++ ) {
    paymentProviderData =  {
      'autorenewal': cardSelected[0][i].auto_renewal,
      'fortumo_service_id': cardSelected[0][i].fortumo_serivce_id,
      'paytmName': cardSelected[0][i].paytm_name,
      'adyenName': cardSelected[0][i].adyen_name,
      'paymentProvider': cardSelected[0][i].payment_provider,
      'subscription_id': cardSelected[0][i].pack_id,
      'payu_Name': cardSelected[0][i].payu_Name,
      'mobiwik_Name':  cardSelected[0][i].mobiwik_Name,
      'phonepay_Name':  cardSelected[0][i].phonepay_Name,
      'mife_Name': cardSelected[0][i].mife_Providers,
      'amazonName': cardSelected[0][i].amazonName,
      'qwikcilverName': cardSelected[0][i].qwikcilverName,
      'robiName': cardSelected[0][i].robiName,
      'mobilePaymentName': cardSelected[0][i].mobilePaymentName
    };
    sendPaymentData.push(paymentProviderData);
  }
  this.storeselCardPayProvider(sendPaymentData);
}

public storefailedcontent(pack) {
  let test, test2, test3;
  test = [];
  test2 = [];
  test3 = [];
  if (pack) {
    let paymentProviderData;
    paymentProviderData =  {
      'autorenewal': pack.auto_renewal,
      'fortumo_service_id': pack.fortumo_serivce_id,
      'paytmName': pack.paytm_name,
      'adyenName': pack.adyen_name,
      'paymentProvider': pack.payment_provider,
      'subscription_id': pack.pack_id,
      'payu_Name': pack.payu_Name,
      'mobiwik_Name':  pack.mobiwik_Name,
      'phonepay_Name':  pack.phonepay_Name,
      'mife_Name': pack.mife_Providers,
      'amazonName': pack.amazonName,
      'qwikcilverName': pack.qwikcilverName,
      'robiName': pack.robiName,
      'mobilePaymentName': pack.mobilePaymentName
    };

    let packAssetName;
    packAssetName = this.storePackAsset(pack.asset_types);
    let selectedCard;
    selectedCard = {
      'adyenName': pack.adyen_name,
      'all_paymentProviders': pack.all_paymentProviders,
      'amazonName': pack.amazonName,
      'asset_types': pack.asset_types,
      'auto_renewal': pack.auto_renewal,
      'billing_frequency': pack.billing_frequency,
      'channel_lang': [],
      'country': pack.country,
      'currency': pack.currency,
      'description': packAssetName,
      'device_number': pack.device_number,
      'duration': this.calculateduration(pack.billing_frequency),
      'end_date': pack.sub_end ? pack.sub_end : null,
      'fortumo_service_id': pack.fortumo_serivce_id,
      'mife_Name': pack.mife_Providers,
      'mobilePaymentName': pack.mobilePaymentName,
      'mobiwik_Name': pack.mobiwik_Name,
      'month': this.calculateduration(pack.billing_frequency),
      'movie_lang': [],
      'originalPrice': true,
      'pack': pack.pack,
      'payment_provider': pack.payment_provider,
      'paytmName': pack.paytm_name,
      'payu_Name': pack.payu_Name,
      'phonepay_Name': pack.phonepay_Name,
      'price': pack.price,
      'qwikcilverName': pack.qwikcilverName,
      'renew': pack.auto_renewal,
      'robiName': pack.robiName,
      'start_date': pack.sub_start ? pack.sub_start : null,
      'subscription_id': pack.pack_id,
      'tv_lang': []
    };

    test.push(paymentProviderData);
    test2.push(selectedCard);
    test3.push(test2);


    this.localstorage.setItem('selectedCard', JSON.stringify(test3));
    this.localstorage.setItem('options', JSON.stringify(test));
  }

}

public calculateduration(fre) {

  let displayDayName , displayMonth, displayYear , displayDay, displayDurationReceived = {}, displayMonthName, displayYearName;

  if (fre < 30 ) {
    ( fre === 1) ? (displayDayName = 'SUSCRIPTION.Day', displayDurationReceived = {day: 1, month: ' ', year: ' '}) : (displayDayName = 'SUSCRIPTION.Days', displayDurationReceived = {day: fre, month: ' ', year: ' '});
           displayDay = fre;
      } else {
            displayMonth = Math.ceil((fre) / 30);
(displayMonth === 1) ? (displayMonthName = 'SUSCRIPTION.Month', displayDurationReceived = {day: ' ', month: displayMonth, year: ' '})
 : ((displayMonth > 1) && (displayMonth < 12) ? (displayMonthName = 'SUSCRIPTION.Months', displayDurationReceived = {day: ' ', month: displayMonth, year: ' '})
  : ((displayMonth = 12) ? (displayMonth = ' ', displayYear  = 1, displayYearName = 'SUSCRIPTION.Year', displayDurationReceived = {day: ' ', month: ' ', year: 1 })
   : ( displayMonth = ' ', displayYear  = Math.ceil(displayMonth / 12), displayYearName = 'SUSCRIPTION.Years', displayDurationReceived = {day: ' ', month: ' ', year: displayYear })));
                }

                return displayDurationReceived;

}

public verifyPendingPack(sourceName: any): any {
  let pendingPacks, user, sendId, successPacksAfterVerify, pendingPacksAfterVerify;
  // let recentFailedPendingTransaction;
  this.successCount = 0, this.failedCount = 0, this.pendingCount = 0, this.responseCount = 0;
  successPacksAfterVerify = [];
  this.failedPacksAfterVerify = [];
  pendingPacksAfterVerify = [];
  pendingPacks = this.getPendingPack();
  sendId = '';
  user = this.localstorage.getItem('token');
  let n;
  n = 0;
  this.recursiveAPI(n, pendingPacks);
  $('.pending-loader').css('display', 'none');

  $('.pendingBtn').css('background', '#4a082a');
  $('.pendingBtn').attr('disabled', true);
  // $('.pendingBtn').disabled = true;
  // document.getElementById("Button").disabled = true;




  // while(n < pendingPacks.length) {
  //   debugger
  //   sendId = pendingPacks[n].additional_data.transaction_id;

  //   this.userAction.verifyPendingPack(sendId, user).timeout(environment.timeOut).subscribe(value => {
  //     let response,ax_reponse
  //     response = JSON.parse(value._body);
  //     responseCount++;
  //     if (response.code === 200 || response.code === '200') {
  //       this.router.navigate(['/paymentsuccess']);
  //       n= pendingPacks.length
  //     } else {
  //       if(response.code == 331 || response.code == '331') {
  //         failedPacksAfterVerify.push(pendingPacks[n])
  //         this.failedCount++;
  //       } else if(response.code == 300 || response.code == '300') {
  //         this.pendingCount++;
  //       }
  //       n++;
  //     }
  //   },err => {
  //     n++
  //   });
  // }
  // console.log(failedPacksAfterVerify,pendingCount,responseCount,'here')







   // var  successPacksAfterVerify = [], failedPacksAfterVerify = [], pendingPacksAfterVerify = [];
   // //let observables: Observable<Array<>;
   // for (let n = 0; n < pendingPacks.length; n++) {
   //  sendId = pendingPacks[n].additional_data.transaction_id;
   //  this.userAction.verifyPendingPack(sendId, user).timeout(environment.timeOut).subscribe(value => {
   //    let response, ax_reponse;
   //    response = JSON.parse(value._body);
   //    //if ((response.code === '200' || response.code === 200) && response.axinom_response) {
   //      if (response.code === 200 || response.code === '200') {
   //        this.successCount+=1;
   //      ax_reponse = response.axinom_response;
   //      // naviagte only for plans and subscription
   //      if((sourceName === 'plan') || (sourceName === 'subscription')){
   //        this.router.navigate(['/paymentsuccess']); // if success found, navigate to recipt;
   //        n = pendingPacks.length; // breaking out of loop
   //      }

   //    }
   //    failedCount+=1;
   //    //get FAILED pending trasactions
   //    if(response.code == 331 || response.code == '331'){

   //      if(this.failedCount > 2) {
   //          this.storefailedcontent(failedPacksAfterVerify[0])
   //          this.localstorage.setItem('onclickretryclose',true)
   //          window.location.href = '/paymentfailure'
   //      }
   //      failedPacksAfterVerify.push(pendingPacks[n]);
   //      //this.storefailedcontent(pendingPacks[n])
   //    }

   //    //get PENDING pending trasactions
   //    if(response.code == 300 || response.code == '300'){
   //      this.pendingCount+=1;
   //      if(this.pendingCount == pendingPacks.length -1  ) {
   //        // errTxt = 'MESSAGES.TRY_LATER'
   //        this.toastClass('snackbar-unsubscribe');

   //      }
   //      pendingPacksAfterVerify.push(pendingPacks[n]);

   //    }

   //    responseCount+=1;

   //    }, err => {

   //      responseCount+=1;
   //      let error, errTxt;
   //      error = JSON.parse(err._body);
   //      //console.log('error', error);
   //      errTxt = (error) ? (error.message) : ('MESSAGES.TRY_LATER');
   //      //console.log('api err', errTxt);
   //    });

      // no success, no faied, only pending status

      // console.log("responseCount "+ responseCount);
      // console.log("this.failedCount+=1; "+failedCount)
   // }

      // no success, with failed and pending status

}




  public recursiveAPI(n, pendingPacks) {
    let user;
    user = this.localstorage.getItem('token');
      if (n < pendingPacks.length) {
        let sendId;
        sendId = pendingPacks[n].additional_data.transaction_id;
        this.userAction.verifyPendingPack(sendId, user).timeout(environment.timeOut).subscribe(value => {
      let response;
      // let ax_reponse;
      response = JSON.parse(value._body);
      this.responseCount++;
      if (response.code === 200 || response.code === '200') {
        this.router.navigate(['/paymentsuccess']);
        n = pendingPacks.length;
      } else {
        if (response.code === 331 || response.code === '331') {
          this.failedPacksAfterVerify.push(pendingPacks[n]);
          this.failedCount++;
        } else if (response.code === 300 || response.code === '300') {
          this.pendingCount++;
        }
        n++;
        this.recursiveAPI(n, pendingPacks);

      }
    }, err => {
      n++;
      this.recursiveAPI(n, pendingPacks);
    });
      } else {
        if (this.failedPacksAfterVerify.length >= 1) {
          this.storefailedcontent(this.failedPacksAfterVerify[0]);
          this.localstorage.setItem('onclickretryclose', true);
          window.location.href = '/paymentfailure';
        }

        if (this.pendingCount === this.responseCount) {
          // show toast
          this.translate.get('MESSAGES.PENDING').subscribe(value => {

              $('#pending').html(value);
              this.callToast('pending');


          });
        }
      }
  }
    
  // get user type for qgraph
  public getUserType(page: any): any {
    let userType, recPayType, userPayDetails;
    if (page === 'launch') {
      userType = 'registered';
      if (!localStorage.getItem('token') && !localStorage.getItem('registered')) {
        userType = 'guest';
      } else {
        let allActive, countryActive, allHistory, countryHistory;
        countryActive = [];
        countryHistory = [];
        allActive = this.getPlanActiveAll();
        allHistory = this.getAllHistoryPlan();
        // prefernce given to active
        if (allActive && allActive.length > 0) {
          for (let g = 0; g < allActive.length; g++) {
            // check for countries node
            if (allActive[g].countries && allActive[g].countries.length > 0) {
              for (let h = 0; h < allActive[g].countries.length; h++) {
                if (allActive[g].countries[h].indexOf(this.userCountry) !== -1) {
                  countryActive.push(allActive[g]);
                }
              }
            } else if (allActive[g].country && allActive[g].country.length > 0) {
              // check for country node
              countryActive.push(allActive[g]);
            }
          }
        } else if (allHistory && allHistory.length > 0) {
          // history packs
          for (let g = 0; g < allHistory.length; g++) {
            // check for countries node
            if (allHistory[g].countries && allHistory[g].countries.length > 0) {
              for (let h = 0; h < allHistory[g].countries.length; h++) {
                if (allHistory[g].countries[h].indexOf(this.userCountry) !== -1) {
                  countryHistory.push(allHistory[g]);
                }
              }
            } else if (allHistory[g].country && allHistory[g].country.length > 0) {
              // check for country node
              countryHistory.push(allHistory[g]);
            }
          }

        }
        if (countryActive && countryActive.length > 0) {
          userType = 'subscribed';
          recPayType = this.getPaymentType('active', countryActive);
        } else if (countryHistory && countryHistory.length > 0) {
          userType = 'unsubscribed';
          recPayType = this.getPaymentType('history', countryHistory);
        }
      }
    } else if (page === 'unsubscribe') {
      userType = 'unsubscribed';
    }
    userPayDetails = {
      'userType': userType ? userType : "",
      'paymentType': recPayType ? recPayType : ""
    };
    return userPayDetails;
  }


  // get payment type for qgraph
  public getPaymentType(recType: any, packDetails: any): any {
    let paymentType;
    if (recType === 'active') {
      // condition for free_trial
      if (packDetails[0].free_trial_num && packDetails[0].free_trial_num !== -1 && packDetails[0].free_trial_num !== null) {
          paymentType = 'free_trial';
      } else if (packDetails[0].paymentProvider && packDetails[0].paymentProvider.toLowerCase() === 'prepaidcode') {
        // condition for prepaid
         paymentType = 'prepaid';
      } else if (packDetails[0]) {
          // condition for purchase
          paymentType = 'purchase';
      }
    } else if (recType === 'history') {
      // condition for free_trial_cancelled
      if (packDetails[0].free_trial_num && packDetails[0].free_trial_num !== -1 && packDetails[0].free_trial_num !== null) {
          paymentType = 'free_trial_cancelled';
      } else if (packDetails[0].paymentProvider && packDetails[0].paymentProvider.toLowerCase() === 'prepaidcode') {
        // condition for prepaid
         paymentType = 'prepaid_expired';
      } else if (packDetails[0]) {
          // condition for paid_subscription_cancelled
          paymentType = 'paid_subscription_cancelled';
      }
    }
    return  paymentType;
  }





  // check and verify pending payment at app launch

  public checkVerifyPending(): any {
    let pendingPack;
    pendingPack = this.getPendingPack();
   }
  // fetch list of pending pack
  public getPendingPackList(source: any): any {
    let active;
       active = this.getActiveCountry();

    this.today = new Date();
    this.todayCompare =  new Date(this.today);

    let user;
    user = this.localstorage.getItem('token');
     this.userAction.listPendingPack(user).timeout(environment.timeOut).subscribe(value => {

       let penList, diffEnd;
       penList = JSON.parse(value._body);
        for (let j = (penList.length - 1); j >= 0 ; j--) {

          this.packCreatedDate = new Date(penList[j].create_date);
          diffEnd = Math.ceil((this.todayCompare - this.packCreatedDate ) / (1000 * 3600));
          if ((penList[j].state.toLowerCase() === 'pending') && diffEnd < 72) { // check pending state // VENKATA add 72 hr condition and countries node condition
            if (penList[j].country === localStorage.getItem('country_code')) {
              this.pendingPack.push(penList[j]); // pending pack added to array
            }
          }

        }


       this.storePendingPack(this.pendingPack);
       this.pendingPackDetails(); // format API data into required format
       if (source === 'launch') {
         this.checkVerifyPending();
       }
     }, err => {
       let emptyPack;
       emptyPack = [];
       this.storePendingPack(emptyPack);
     });

  }

}
