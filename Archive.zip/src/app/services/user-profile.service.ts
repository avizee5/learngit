import { Injectable, OnInit } from '@angular/core';
import { Headers, Http , RequestOptions, Response} from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import * as $ from 'jquery';
import {FavoritesApi, RemindersApi, UserApi, WatchHistoryApi, WatchlistApi } from '../../data/user/api/api';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';


// Import RxJs required methods
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class UserProfileService {
  public profileFavData: any = [];
  public profileWatchData: any = [];
  public profileReminderData: any = [];
  public updatedData: any ;
  public body: any;
  public userdata: any;
  public loginType: any;
  public token: any;
  public configUser: any;
  public favouriteDataFetch: any = false;
  public watchDataFetch: any = false;
  public localstorage: any;
  public window: any;
  public document: any;
  public navigator: any;

  public configObservable = new Subject<any>();
  public configObservable1 = new Subject<any>();
  public configObservable2 = new Subject<any>();
  public favourite = new Subject<any>();
  public watchlater = new Subject<any>();
  constructor( @Inject(PLATFORM_ID) private platformId: Object, private http: Http, private gtm: GoogleAnalyticsService) {
    if (isPlatformBrowser(this.platformId)) {
   this.localstorage = localStorage;
    this.window = window;
    this.document = document;
    this.navigator = navigator;
}
  }
  public fullFavData(a: any) {
    this.profileFavData = a;
    this.favourite.next(this.profileFavData);
    // console.log('favorite full', a)
  }
  public fullWatchData(a: any) {
    this.profileWatchData = a;
    this.watchlater.next(this.profileFavData);
  }
  public fullReminderData(a: any) {
    this.profileReminderData = a;
    // console.log('full reminder data', this.profileReminderData);
  }
  public getWatchData() {
    return this.profileWatchData;
  }
  public getFavoriteData() {
    return this.profileFavData;
  }

  public httpgetWatchData() {

    this.token = this.localstorage.getItem('token');
    if (this.token && this.watchDataFetch === false) {
      let params;
      params = 'bearer ' + this.token;
      this.configUser = {
        apiKey: params,
        username: ' ',
        password: ' ',
        accessToken: ' ',
        withCredentials: false
      };
      let favoritesRequest;
      favoritesRequest = new  WatchlistApi(this.http, null, this.configUser);
      favoritesRequest.v1WatchlistGet().subscribe(value => {
        this.profileWatchData = value;
        this.watchDataFetch = true;
        this.fullWatchData(this.profileWatchData);
      },
      err => {
        this.gtm.sendErrorEvent('api', err);
      }
      );
    }
  }
  public httpgetFavoriteData() {
    this.token = this.localstorage.getItem('token');
    if (this.token && this.favouriteDataFetch === false) {
      let params;
      params = 'bearer ' + this.token;
      this.configUser = {
        apiKey: params,
        username: ' ',
        password: ' ',
        accessToken: ' ',
        withCredentials: false
      };
      let favoritesRequest;
      favoritesRequest = new  FavoritesApi(this.http, null, this.configUser);
      favoritesRequest.v1FavoritesGet().subscribe(value => {
        this.profileFavData = value;
        this.favouriteDataFetch = true;
        this.fullFavData(this.profileFavData);
      },
      err => {
        this.gtm.sendErrorEvent('api', err);
      }
      );
    }
  }
  public setFavoriteData(a: any): any {
    this.profileFavData.push(a);
    this.favourite.next(this.profileFavData);
  }
  public removeFavoriteData(a: any) {
    this.profileFavData = $.grep(this.profileFavData, function(e) {
      return e.id !== a.id;
    });
    this.favourite.next(this.profileFavData);
  }

  public setWatchData(a: any) {
    this.profileWatchData.push(a);
    this.watchlater.next(this.profileWatchData);
  }
  public removeWatchData(a: any) {
    this.profileWatchData = $.grep(this.profileWatchData, function(e) {
      return e.id !== a.id;
    });
    this.watchlater.next(this.profileWatchData);
  }


  public setReminderData(a: any) {
    let token, params, config;
    token = this.localstorage.getItem('token');
    this.loginType = this.localstorage.getItem('login');
    params = 'bearer ' + token;
    config = {
      apiKey: params,
      username: ' ',
      password: ' ',
      accessToken: ' ',
      withCredentials: false
    };
    let remindersRequest;
    remindersRequest = new  RemindersApi(this.http, null, config);
    remindersRequest.v1RemindersPost(a).subscribe(value => {
      // todo
    },
    err => {
      this.gtm.sendErrorEvent('api', err);
    });
    this.profileReminderData.push(a);

    this.configObservable2.next(this.profileReminderData);
    return this.profileReminderData;
  }
  public removeReminderData(a: any, b: any) {
    let token, params, config, remindersRequest;
    token = this.localstorage.getItem('token');
    params = 'bearer ' + token;
    config = {
      apiKey: params,
      username: ' ',
      password: ' ',
      accessToken: ' ',
      withCredentials: false
    };
    remindersRequest = new  RemindersApi(this.http, null, config);
    remindersRequest.v1RemindersDelete(a, b).subscribe(value => {
      // todo
    },
    err => {
      this.unsuccessfulDeleteToast();
      this.gtm.sendErrorEvent('api', err);

    });

    this.profileReminderData = $.grep(this.profileReminderData, function(e) {
      return e.id !== a;
    });
  }

  public getReminderData() {
    return this.profileReminderData;
  }

  public extractData(res: Response) {
    this.body = res.json();

    return this.body || {};
  }

  public handleErrorObservable (error: Response | any) {
    return Observable.throw(error.message || error);
  }

  public setUserdata(data) {

    this.userdata = data;
    return this.userdata;
  }
  public getSourceapp(): any {
    let sourceapp;
    sourceapp = this.userdata  && this.userdata.additional && this.userdata.additional.sourceapp ? this.userdata.additional.sourceapp : '';
    return sourceapp;
  }
  public getuserdata() {
    return this.userdata;
  }
   public isKeyInObject(obj, key) {
    let res;
    res = Object.keys(obj).some(v => v === key);
    return res;
}
  public createObject(show): any {
    let obj;
     obj = { id: show.id ? show.id : '',
            date: show.release_date ? show.release_date : '',
            asset_type: this.isKeyInObject(show, 'asset_type') ? show.asset_type : '',
            duration: this.isKeyInObject(show, 'duration') ? show.duration : ''
            };
    return obj;
  }
  public unsuccessfulDeleteToast() {
    let p;
    p = this.document.getElementById('snackbar');
    p.className = 'show';
    setTimeout(function() { p.className = p.className.replace('show', ''); }, 3000);
  }

  public inList(type, assetId): any {
    let storedData;
    if (type === 'favorite') {
      storedData = this.getFavoriteData();
    } else if (type === 'watchList') {
      storedData = this.getWatchData();
    }
    if (storedData) {
      for (let index = 0 ; index < storedData.length; index++) {
        if (storedData[index].id === assetId) {
          return true;
        }
      }
      return false;
    }
  }

}
