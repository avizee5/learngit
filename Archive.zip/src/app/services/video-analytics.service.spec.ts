import { TestBed, inject } from '@angular/core/testing';

import { VideoAnalyticsService } from './video-analytics.service';

describe('VideoAnalyticsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [VideoAnalyticsService]
    });
  });

  it('should be created', inject([VideoAnalyticsService], (service: VideoAnalyticsService) => {
    expect(service).toBeTruthy();
  }));
});
