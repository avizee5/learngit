import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { Headers, Http , RequestOptions, Response} from '@angular/http';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/toPromise';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { isPlatformBrowser } from '@angular/common';

@Injectable()
export class RouteService {
  public Eh: any;
  public meh: any = [];
  public signal: any = null;
  public forgot: any = null;
  public received_code: any = null;
  public forgot_code: any = null;
  public loggedin: boolean;
  public previous = '';
  public localStorage: any;
  public loginValue = new Subject<any>();
  public returnloginValue: any;
  constructor(@Inject(PLATFORM_ID) private platformId: Object, private http: Http) {
    if (isPlatformBrowser(this.platformId)) {
      this.localStorage = localStorage;
    }
  }
  // getRoute(): Observable<Array<string>> {
  //   const url = '../assets/json/CONFIG.json'
  //   return this.http.get( url)
  //   .map(this.extractData)
  //   .catch(this.handleErrorObservable);
  // }

  public previousRoute(): any {
    if (this.meh.length > 0) {
      return this.meh.pop();
    } else {
      return '/';
    }
  }

    public setRoute( whatIWant ): any {
      this.meh.push(whatIWant);
    }
    public setLoginRoute(event) {
      // this.previous = event;
      if (event !== '/forgotpassword' && event !== '/resetpassword' && event !== '/paymentfailure' && event !== '/paymentcancelled' && event !== '/paymentsuccess' && event !== '/verify' && event !== '/signin/mobile' && event.indexOf('/parentalcontrol') < 0) {
        let y, x;
        y = this.localStorage.getItem('token');
        if (y) {
          x = this.localStorage.getItem('UserDisplayLanguage');
        } else {
          x = this.localStorage.getItem('display_language');
        }
       let arr;
      arr = ['/kn/', '/te/', '/ta/', '/mr/', '/hr/', '/hi/', '/gu/' , '/pa/' , '/ml/' , '/bn/', '/th/', '/id/', '/ms/', '/de/', '/ru/'];
        // if (x === 'en' || x === null) {
        if ((x === 'en' && window.location.pathname.split('/')[1] !== 'en' ) || x === null) {
          for (let i = 0; i < arr.length; i++) {
            if (event.indexOf(arr[i]) > -1) {
              this.previous = event.slice(3);
              break;
            } else {
            this.previous = event;
            }
          }
        } else {        
          if (event.match(/search\/result/g)) {
          this.previous = event;
          } else {
            this.previous = event.slice(3);
          }
        }
        let prev;
        prev = this.localStorage.getItem('previousRoute');
        if (this.previous === '/myaccount/subscription' && prev !== '/myaccount/subscription') {
            prev = prev ? prev : '/';
            this.localStorage.setItem('subscriptionRoute', prev);
        }
        if (this.previous !== '/twitterLogin' && this.previous !== '/paymentsuccess' && this.previous !== '/myaccount/subscription' && !(this.previous.match('/signin|register/i'))) {
            this.localStorage.removeItem('postSubscriptionRoute');
        }
        this.localStorage.setItem('previousRoute', this.previous);
      }
    }
    public getLoginRoute() {
      return this.previous;
    }

    public Signal(forSignIn) {
    	this.signal = forSignIn;
    }

    public sendSignal(): any {
    	return this.signal;
    }

    public forgotSignal(signal): any {
      this.forgot = signal;
    }


    public sendforgotSignal() {
      return this.forgot;
    }

    public setcode(code) {
      this.received_code = code;

    }
    public getcode() {

      return this.received_code;
    }

    public setforgotcode(forgotcode) {
      this.forgot_code = forgotcode;
    }
    public setloggedInstate(flag) {
      this.loggedin = flag;
    }
    public getloggedInstate() {
      return this.loggedin;
    }


    public getforgotcode() {

      return this.forgot_code;
    }

    public sendforpopup() {
      const lastitem = this.meh[this.meh.length - 1];
      return lastitem;
    }
    private extractData(res: Response) {
      const body = res.json();
      return body || {};
    }
    private handleErrorObservable (error: Response | any) {
      console.error(error.message || error);
      return Observable.throw(error.message || error);
    }
    public getBaseLocation(): any {
      let token;
      token = this.localStorage.getItem('token');
      if (token) {
      // searchItem = this.localStorage.getItem('UserDisplayLanguage')
      if (this.localStorage.getItem('UserDisplayLanguage') !== 'en') {
        return '' + this.localStorage.getItem('UserDisplayLanguage') + '/';
      } else {
        return '';
      }

    } else {
        // searchItem = this.localStorage.getItem('display_language')
        if (this.localStorage.getItem('display_language') !== 'en') {
          return '' + this.localStorage.getItem('display_language') + '/';
        } else {
          return '';
        }
      }
    }
public getcurrentLanguage() {
            let token, translation;
      token = this.localStorage.getItem('token');
        if (token) {
           translation = this.localStorage.getItem('UserDisplayLanguage');
        } else {
            translation = this.localStorage.getItem('display_language');
        }
        if (translation === null || translation === 'null') {
          translation = 'en';
        }
        if (translation === 'en') {
          translation = '';
        }
        return translation;
}
public forappmodule() {
let botPattern, re, userAgent;
botPattern = '(googlebot\/|Googlebot-Mobile|Googlebot-Image|Google favicon|Mediapartners-Google\
              |bingbot|slurp|java|wget|curl|Commons-HttpClient|Python-urllib|libwww|httpunit|nutch\
              |phpcrawl|msnbot|jyxobot|FAST-WebCrawler|FAST Enterprise Crawler|biglotron|teoma|convera\
              |seekbot|gigablast|exabot|ngbot|ia_archiver|GingerCrawler|webmon |httrack|webcrawler\
              |grub.org|UsineNouvelleCrawler|antibot|netresearchserver|speedy|fluffy|bibnum.bnf\
              |findlink|msrbot|panscient|yacybot|AISearchBot|IOI|ips-agent|tagoobot|MJ12bot\
              |dotbot|woriobot|yanga|buzzbot|mlbot|yandexbot|purebot|Linguee Bot|Voyager\
              |CyberPatrol|voilabot|baiduspider|citeseerxbot|spbot|twengabot|postrank|turnitinbot\
              |scribdbot|page2rss|sitebot|linkdex|Adidxbot|blekkobot|ezooms|dotbot|Mail.RU_Bot|discobot\
              |heritrix|findthatfile|europarchive.org|NerdByNature.Bot|sistrix crawler|ahrefsbot\
              |Aboundex|domaincrawler|wbsearchbot|summify|ccbot|edisterbot|seznambot|ec2linkfinder\
              |gslfbot|aihitbot|intelium_bot|facebookexternalhit|yeti|RetrevoPageAnalyzer|lb-spider\
              |sogou|lssbot|careerbot|wotbox|wocbot|ichiro|DuckDuckBot|lssrocketcrawler|drupact\
              |webcompanycrawler|acoonbot|openindexspider|gnam gnam spider|web-archive-net.com.bot\
              |backlinkcrawler|coccoc|integromedb|content crawler spider|toplistbot|seokicks-robot\
              |it2media-domain-crawler|ip-web-crawler.com|siteexplorer.info|elisabot|proximic\
              |changedetection|blexbot|arabot|WeSEE:Search|niki-bot|CrystalSemanticsBot|rogerbot\
              |360Spider|psbot|InterfaxScanBot|Lipperhey SEO Service|CC Metadata Scaper|g00g1e.net\
              |GrapeshotCrawler|urlappendbot|brainobot|fr-crawler|binlar|SimpleCrawler|Livelapbot\
              |Twitterbot|cXensebot|smtbot|bnf.fr_bot|A6-Indexer|ADmantX|Facebot|Twitterbot|OrangeBot\
              |memorybot|AdvBot|MegaIndex|SemanticScholarBot|ltx71|nerdybot|xovibot|BUbiNG|Qwantify\
              |archive.org_bot|Applebot|TweetmemeBot|crawler4j|findxbot|SemrushBot|yoozBot|lipperhey\
              |y!j-asr|Domain Re-Animator Bot|AddThis)';
     re = new RegExp(botPattern, 'i');
     userAgent = navigator.userAgent;
    if (re.test(userAgent)) {
      // console.log('the user agent is a crawler!');
      let arr;
      localStorage.removeItem('display_language');
      arr = ['en', 'kn', 'te', 'ta', 'mr', 'hr', 'hi', 'gu' , 'pa' , 'ml' , 'bn', 'th', 'id', 'ms', 'de', 'ru'];
      for ( let language = 0; language < arr.length; language++) {
        if (arr[language] === window.location.pathname.split('/')[1] ) {

            return '/' + arr[language];
        }
      }
    } else {
           let token;
    token = localStorage.getItem('token');
   if (token) {
  // searchItem = localStorage.getItem('UserDisplayLanguage')
  if (localStorage.getItem('UserDisplayLanguage')) {
    if (localStorage.getItem('UserDisplayLanguage') !== 'en') {
      let arr = ['en', 'kn', 'te', 'ta', 'mr', 'hr', 'hi', 'gu' , 'pa' , 'ml' , 'bn', 'th', 'id', 'ms', 'de', 'ru'];

          let displaylan = localStorage.getItem('UserDisplayLanguage');
          if(arr.indexOf(window.location.pathname.split('/')[1]) >=0) {
           if(window.location.pathname.split('/')[1] && displaylan !== window.location.pathname.split('/')[1]) {
              
              if(window.location.href.split('?')[1] && window.location.href.split('?')[1].length > 0) {
              location.href = window.location.origin + window.location.pathname.replace(window.location.pathname.split('/')[1],displaylan)+ '?' +window.location.href.split('?')[1]; 
              } else {
              location.href = window.location.origin + window.location.pathname.replace(window.location.pathname.split('/')[1],displaylan)
              }
            }
          }
      return '/' + localStorage.getItem('UserDisplayLanguage');
    } else {
      return '/';
    }
  } else {
    return '/';
  }

} else {
  let arr;
    arr = ['en', 'kn', 'te', 'ta', 'mr', 'hr', 'hi', 'gu' , 'pa' , 'ml' , 'bn', 'th', 'th', 'id', 'ms', 'de', 'ru'];
        for ( let language = 0; language < arr.length; language++) {
          if (arr[language] === window.location.pathname.split('/')[1] ) {
            return '/' + arr[language];
          }
      }
        return '/';

}

    }


}


}

