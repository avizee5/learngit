import { Injectable } from '@angular/core';
import { Headers, Http , RequestOptions, Response} from '@angular/http';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/toPromise';
import { Observable } from 'rxjs/Observable';
// Import RxJs required methods
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { SettingsService } from './settings.service';
import { RequestMethod, RequestOptionsArgs } from '@angular/http';

@Injectable()
export class EpgService {
public scrollValue = new Subject <any>();
public modalData = new Subject<any>();
public reRun = new Subject<any>();
public reRunmove = new Subject<any>();
public livestatus = new Subject<any>();
public liveIndex = new Subject<any>();
public livecheck = new Subject<any>();
public slotopening = new Subject<any>();
public CHECK = new Subject<any>();
public loader = new Subject<any>();
public disableScroll = new Subject<any>();
public channelarray: Array<any> = [];
public currentTime: any;
public disableScrollValue = false;
public initial: any;
public start: any;
public live_index: number;
public programs: any;
public curr_index: number;
public prev_index: number;
public live = false;
public slot: Array<any> = [];
public end: any;
public premium = false;

 public version;
    public window: any;
    public platform;
    public navigator: any;
 constructor(private settingsService: SettingsService, private http: Http) {
  this.window = window;
        this.version = this.window.appVersion;
        this.navigator = navigator;
        this.platform = this.navigator.userAgent.match(/mobile|iPhone|iPod|iPad/i) ? 'Web Mobile' : 'Web Desktop';
      }
 public setBusinesstype(status): void {
   this.premium = status;
 }
  public getBusinesstype(): any {
   return this.premium;
 }
 public channelIds(channel): void {
   if (this.channelarray.indexOf(channel) === -1) {
     this.channelarray.push(channel);
   }
 }
 public getchannelIds(): any {
   return this.channelarray;
 }
 public clearchannels(): void {
    this.channelarray = [];
 }
  public getcurrentEpgData(url): Observable<any> {
     let headers;
        headers = new Headers(); // https://github.com/angular/angular/issues/6845
         headers.append('X-Z5-AppPlatform', this.platform);
        headers.append('X-Z5-Appversion', this.version);
         const requestOptions: RequestOptionsArgs = new RequestOptions({
        method: RequestMethod.Get,
        headers: headers
    });
     return this.http.request(url, requestOptions)
    .map(this.extractData)
    .catch(this.handleErrorObservable);
 }
  public getcurrentTime(url): Observable<any> {
     return this.http.get( url)
    .map(this.extractData)
    .catch(this.handleErrorObservable);
  }
  public loaded(data): any {
     let status;
     status = data;
     this.loader.next(data);
     return data;
  }
  public setScroll(a: boolean): any {
     this.scrollValue.next(a);
  }
  public setVideoData(value) {
    let index;
    index = value;
    this.modalData.next(value);
    return value;
  }
  public gonext(val): any {
    let nextcontent;
    nextcontent = val;
    this.reRun.next(nextcontent);
    return nextcontent;
  }
  public disableWindowScroll(val): any {
    let status;
    status = val;
    this.disableScrollValue = status;
    this.disableScroll.next(status);
    return status;
  }
  public getWindowScroll(): any {
    return this.disableScrollValue;
  }
  public gonextcontent(): any {
    let movenextcontent;
    movenextcontent = true;
    this.reRunmove.next(movenextcontent);
    return movenextcontent;
  }
  public liveStatus(status): void {
     this.live = status;
     this.livestatus.next(status);
  }
  public check(a, b, c, d, e, f, g, h): void {
    this.slot = [];
    let obj;
    obj = {event: b, ui: c, id: d, title: e, original_title: f, genres: g, languages: h};
    this.slot.push(obj);
    this.CHECK.next(this.slot);
  }
  public openslot(a, b): void {
    let arr, obj;
    arr = [];
    obj = {event: a, ui: b};
    arr.push(obj);
    this.slotopening.next(arr);
  }
  public nextdayLivecheck(status): any {
    this.livecheck.next(status);
    return status;
  }
  public getLiveIndex(arr, time): any {
    let rerundata, index, starttime, endtime,  currtime;
    rerundata = arr;
    this.programs = arr;
    for (let i = 0; i < rerundata.length; i++) {
     starttime = rerundata[i].start_time;
     endtime = rerundata[i].end_time;
     currtime = time;
       if (currtime === starttime || (currtime >= starttime && endtime > currtime)) {
           index = i;
        }
    }
  this.live_index = index;
  return index;
  }
  public getIndex(): any {
    return this.live_index;
  }
  public trackLiveIndex(flag, time): any {
    let previndex, testindex;
    previndex = this.getIndex();
    testindex = this.getLiveIndex(this.programs, time);
      if (testindex !== previndex) {
        this.curr_index = testindex;
        this.liveIndex.next(testindex);
       return flag;
      }
  }
  public filterdata(arr, initial, currtime, channelid) {
    this.currentTime = currtime;
    this.initial = initial;
    let format, filleddata;
       format = this.formatGenre( arr, 'start_time');
       filleddata = this.addfiller(format, channelid);
       return filleddata;
  }
  public formatGenre(myArr, prop): any {
     return myArr.filter((obj, pos, arr) => {
          return arr.map(mapObj => mapObj[prop]).indexOf(obj[prop]) === pos;
  });
  }
  public addfiller(arr, channelid): any {
     let newarray, currdate, end, duration, a;
     newarray = [];
     this.start = new Date(this.initial).toISOString();
     this.start =  this.start.replace(/\.[0-9]{2,3}/, '');
     currdate = new Date(this.initial).getDate();
     end = this.initial + 86400000;
     this.end = new Date(end).toISOString();
     this.end = this.end.replace(/\.[0-9]{2,3}/, '');
   /**********************************first**************************/
     if (arr[0].start_time === this.start && new Date(arr[0].start_time).getDate() === currdate) {
                 newarray.push(arr[0]);
     } else if (arr[0].start_time > this.start && new Date(arr[0].start_time).getDate() === currdate) {
         duration = (new Date(arr[0].start_time).getTime() - this.initial) / 1000;
         a = {id: 'filler', start_time: this.start, end_time: arr[0].start_time, duration: duration, asset_type: 10, title: 'Filler', channel: {id: channelid}};
         newarray.push(a);
         newarray.push(arr[0]);
     }
   /**********************************mid**************************/
    for (let i = 1; i < arr.length; i++) {
      if (arr[i].start_time === arr[i - 1].end_time && arr[i].start_time >= this.start && new Date(arr[i].start_time).getDate() === currdate) {
        newarray.push(arr[i]);
      } else if (arr[i].start_time > arr[i - 1].end_time && arr[i].start_time >= this.start && new Date(arr[i].start_time).getDate() === currdate) {
          duration = ((new Date(arr[i].start_time).getTime()) - (new Date(arr[i - 1].end_time).getTime())) / 1000;
          a = {id: 'filler', start_time: arr[i - 1].end_time, end_time: arr[i].start_time, duration: duration, asset_type: 10, title: 'Filler', channel: {id: channelid}};
          newarray.push(a);
          newarray.push(arr[i]);
      }
   }
   /**********************************last**************************/
    if (arr[arr.length - 1].end_time === this.end && arr[arr.length - 1].start_time >= this.start && new Date(arr[arr.length - 1].start_time).getDate() === currdate) {
      // to do
    } else if (arr[arr.length - 1].end_time < this.end && arr[arr.length - 1].start_time >= this.start && new Date(arr[arr.length - 1].start_time).getDate() === currdate) {
               duration = (end - new Date(arr[arr.length - 1].end_time).getTime()) / 1000;
               a = {id: 'filler', start_time: arr[arr.length - 1].end_time, end_time: this.end, duration: duration, asset_type: 10, title: 'Filler', channel: {id: channelid}};
               newarray.push(a);
    }
return newarray;
}

 public formatData(data, timeoffset, index, tr, pageSize) {
      let returnData, count, comma, timeOffset, country_code;
      country_code = this.settingsService.getCountry();
       returnData = '';
       count = 0;
       comma = encodeURIComponent(',');
      for (let i = 0; i < data.length; i++) {
          if (count === 0) {
              returnData += 'channels' + '=' + data[i];
          } else {
              returnData += comma + data[i];
          }
          count = count + 1;
      }
      timeOffset = encodeURIComponent(timeoffset);
      returnData += '&' + 'start' + '=' + index + '&' + 'end' + '=' + index + '&' + 'time_offset' + '=' + timeOffset +  '&' + 'page_size' + '=' + pageSize + '&' + 'translation' + '=' + tr + '&' + 'country' + '=' + country_code;
      return returnData;
  }
  private extractData(res: Response) {
    let body;
    body = res.json();
    return body || {};
  }
  private handleErrorObservable (error: Response | any) {
    return Observable.throw(error.message || error);
  }



}
