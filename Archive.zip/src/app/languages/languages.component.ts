import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { Location } from '@angular/common';
import { Http} from '@angular/http';
import { APP_BASE_HREF } from '@angular/common';
import { Inject, Injectable, Optional } from '@angular/core';
import { Subject } from 'rxjs/Subject';

import { SettingsService } from '../services/settings.service';
import { TranslateService} from '@ngx-translate/core';
import { HeaderservicesService } from '../services/headerservices.service';
import { UserApiService } from '../services/user-api.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { NetworkService } from '../services/network.service';
import { RouteService } from '../services/route.service';
import { FilterService } from '../services/filter.service';
import { LinkService } from '../services/link.service';

import * as api from '../../data/subscription/api/api';
import * as SettingsApi from '../../data/user/api/api';
import { environment} from '../../environments/environment';

import 'rxjs/add/operator/timeout';
import * as $ from 'jquery';

/* Angular Universal */
import { isPlatformBrowser } from '@angular/common';
import {  PLATFORM_ID } from '@angular/core';

declare const qg;

@Component({
  selector: 'app-languages',
  templateUrl: './languages.component.html',
  styleUrls: ['./languages.component.less']
})

export class LanguagesComponent implements OnInit, OnDestroy {
  public ngUnsubscribe = new Subject<any>();

  public assetbasepath = environment.assetsBasePath;  // Asset basepath letiable

  public router: any;
  public router2: any;
  public pageName: any;

  public rippleanimate: boolean;  /*For ripple effect */
  public controlRipple: any;

  public state: string;
  public country: string;
  public countryCode: any;
  public international: any;

	public menuTabs: any;
	public previousTab: any;

	public language: any;  /*JSON data handling */
	public errorMessage: any;

  public userToken: any;
  public userSettings: any;
  public contentLanguages: any;
  public update: any;
  public defaultLanguages: Array<any> = [];
	public selectedButton: Array<any> = [];
  public selectedButtonId: Array<any> = [];
	public selectionTrack: Array<any> = [];
  public selectedLanguage: any;
  public selectedLanguageId: any;
  public languageContent: any;
  public flag: any;
  public regionLanguage: any;
  public regioncontentLanguage: any;
  public nativeChange: any;
  public welcomeChange: any;
  public lang: any;

  public fromLocalStorage: any;
  public localStoragevalue: any = [];
  public correctDisplay: boolean;

  public content: any = [];
  public settingsSuccess: boolean;

  public countryValue: any;
  public completeValue: any;
  public completeContentValue: any;
  public completeDisplay: any;
  public completeContent: any;

  public displayBool: any;
  public contentBool: any;
  public default_settings: any;

  public localStorage: any;
  public window: any;
  public document: any;
  public navigator: any;
  public qgraph: any;
  public selectDisLang: Array<any> = []; // store selected display language
  public showApiTxt = true; // show txt in content language
  public contentLangClose: any;

  public contentLanFlag = false;
  public contentLanId: any;
  public usercontentLanArray: any;
  public guestContentLanArray: any = [];
  public contentLan: any;
  public saveDisplayonSave: any;
  public storedLang: any;
  public savedDisplayLang = false;
  public notEditableLang: any;
  public isIdMatch = false;
  public prevDisplayLang: any;
  public prevContentLang: any;

  constructor(private linkservice: LinkService, @Inject(PLATFORM_ID) private platformId: Object, @Inject(APP_BASE_HREF) private baseHref: string, private location: Location, private networkService: NetworkService, private routeservice: RouteService, private filterService: FilterService, private gtm: GoogleAnalyticsService, private userapiService: UserApiService, private settingsService: SettingsService, private routerLink: Router, private translate: TranslateService, private headerservicesService: HeaderservicesService, private http: Http) {
    if (isPlatformBrowser(this.platformId)) {
      this.localStorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
    // this.routeservice.setLoginRoute(this.window.location.pathname);  /*Return back to this page on login relaod */
    // this.router = routerLink;
    // this.router2 = this.window.location.pathname;
    // this.headerservicesService.viewChange(this.router2);
    if (this.headerservicesService.getPersonalizeChange() === true) {
      this.reloadScreen();
    }
    this.headerservicesService.contentLanguageValue.takeUntil(this.ngUnsubscribe).subscribe(value => {  // would u like watch more popup
      // console.log('value',value)
      this.contentLangClose = value;
      if (this.contentLangClose.boolean === false && this.contentLangClose.view === 'language' && (this.contentLangClose.status === 'toast' || this.contentLangClose.status === 'route' || this.contentLangClose.status === 'display' || this.contentLangClose.status === 'close') ) {
        this.saveLanguage(value.id, value.string);
      }
      if (this.contentLangClose.boolean === false &&  this.contentLangClose.view === 'video' && this.contentLangClose.status === 'route') {  // if popup in language screen thn click on choose lang open tab2
        this.openTab(1);
      }
      if (this.contentLangClose.boolean === false && (this.contentLangClose.view === 'videoDestroy' || this.contentLangClose.view === 'video') &&  this.contentLangClose.status === 'toast') {  // if popup in language screen thn click on yes i would open tab2 and update content lang
        this.updateSelectedDisplay(value.id);
        this.openTab(1);
      }
    });
    this.headerservicesService.blockeventsValue.subscribe(value => {
     this.qgraph = this.headerservicesService.getRemarketing();
    });

    this.headerservicesService.contentlanValue.subscribe(value => {         // search view
      this.contentLanFlag = value;
      if (this.contentLanFlag === false) {
        $('#languageModel').css('display', 'block');
      }
    });
  }

  public ngOnInit() {
    this.countryCode = this.settingsService.getCountry();
    if (this.countryCode === 'IN') {
      this.international = 'COMMON.SAVE';
    } else {
      this.international = 'COMMON.NEXT';

    }
    this.settingsService.bluekaiPagename('language');
    let network;
    network = this.networkService.getScreenStatus();
    this.qgraph = this.headerservicesService.getRemarketing();
    this.window.scrollTo( 0, 0 );
    let scope;
    scope = this;
    this.window.onpopstate = function() {
      let contentObject;
      contentObject = {
        'boolean': false,
        'string': '',
        'id': ''
      };
      scope.headerservicesService.contentLanguageChanges(contentObject);
      scope.closeLanguage('browserback');

    };
    $('#body').addClass('scrolldisbale');

    if ( network === true) {
      $('#loaderPage').css('display', 'block');
    }
    this.userToken = this.localStorage.getItem('token');
    this.saveDisplayonSave = this.localStorage.getItem('display_language');  // to store disp lang
    this.storedLang = this.localStorage.getItem('Langoption');            // to store disp as langoptions
    this.rippleanimate = false;
    this.settingsSuccess = false;
    this.menuTabs = [true, false];  // Tab States
    this.previousTab = 0; // previous tab selected

    this.filterService.setView('languages');
    this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'languages'  } );

    /*GA*/
    this.gtm.storeWindowError();
    this.pageName = 'language/display';
    this.gtm.sendPageName(this.pageName);
    this.gtm.sendEvent();

    this.fetchlanguages();
    setTimeout(() => {
    let paths, lan, displaylan;
    paths = location.pathname.split('/').splice(1, 1);
    lan = paths[0].length === 2 ? paths[0] : 'en';
    displaylan = this.userToken ? this.localStorage.getItem('UserDisplayLanguage') : this.localStorage.getItem('display_language');
    this.contentLan = this.userToken ? this.localStorage.getItem('UserContentLanguage') : this.localStorage.getItem('ContentLang');
    this.prevDisplayLang = displaylan;
    this.prevContentLang = this.contentLan;
    }, 1000);

    this.flagHide();
    /* LocalStorage Setup*/
    let z;
    z = this.localStorage.getItem('display_language');

    for ( let j = 0; j <= 20; j++) {
      this.selectionTrack[j] = false;
    }

    if ( this.userToken) {
      let userBearer;
      userBearer = 'bearer ' + this.userToken;

      let config;
      config = {
      apiKey: userBearer,
      username: ' ',
      password: ' ',
      accessToken: ' ',
      withCredentials: false
      };

    this.userSettings = new SettingsApi.SettingsApi(this.http, null, config);

      this.userSettings.v1SettingsGet().subscribe(response => {
        this.settingsSuccess = true;
        if ( response.length > 0) {
          for (let i = 0; i < response.length; i++) {
            if ( response[i].key === 'content_language') {
              this.contentBool = true;
              this.localStorage.setItem('UserContentLanguage', response[i].value);
              this.contentLanguages = response[i].value;
            }

            if ( response[i].key === 'display_language') {
              this.displayBool = true;
              this.localStorage.setItem('UserDisplayLanguage', response[i].value);
              this.selectedLanguageId = response[i].value;
              if (this.lang) {
                this.selectedLanguage = this.lang.languages_labels.en[this.selectedLanguageId];
                this.onClicked(this.selectedLanguage, this.selectedLanguageId,this.regionLanguage.indexOf(this.selectedLanguageId));
              }
              // console.log(this.regionLanguage, this.selectedLanguageId, this.lang, 'this.completeDisplay')
              // this.completeDisplay = valueLang.json().display
              this.isChecked(response[i].value);
              this.translate.use('z5-strings-' + response[i].value );
              this.selectedButton = [];
              this.selectedButtonId = [];
              this.selectedButtonId.push(response[i].value);
            }
          }

          /* Second check for settings key */
          if (!this.displayBool || !this.contentBool ) {
            if (!this.displayBool) {
              this.default_settings =
              [
              {key: 'display_language', value: 'en' }
              ];

              this.localStorage.setItem('UserDisplayLanguage', 'en');
              this.translate.use('z5-strings-en');
              this.translate.getTranslation('z5-strings-en').takeUntil(this.ngUnsubscribe).subscribe(value => {
              // todo
               }, err => {
                this.translate.use('z5-strings-en');
              });
            }

            if (!this.contentBool) {
              this.default_settings =
              [
              {key: 'content_language', value: localStorage.getItem('ContentLang') }
              ];

              this.localStorage.setItem('UserContentLanguage', localStorage.getItem('ContentLang'));
            }

            if (!this.contentBool && !this.displayBool) {
              this.default_settings =
              [
              {key: 'display_language', value: 'en' },
              {key: 'content_language', value: localStorage.getItem('ContentLang') }
              ];

              this.localStorage.setItem('UserDisplayLanguage', 'en');
              this.translate.use('z5-strings-en');
              this.translate.getTranslation('z5-strings-en').takeUntil(this.ngUnsubscribe).subscribe(value => {
              // todo
               }, err => {
                this.translate.use('z5-strings-en');
              });

              this.localStorage.setItem('UserContentLanguage', localStorage.getItem('ContentLang'));
            }

            for (let k = 0; k < this.default_settings.length ; k++) {

            const defaultsettings = {
              'key': this.default_settings[k].key,
              'value': this.default_settings[k].value
            };

            this.userSettings.v1SettingsPost(defaultsettings).takeUntil(this.ngUnsubscribe).subscribe(responsePost => {
               // todo
            },
            err => {
              // todo
            });
          }
         }
        } else {
          if (this.localStorage.getItem('display_language')) {
                let disp;
                disp = this.localStorage.getItem('display_language');
                this.translate.use('z5-strings-' + disp);
                this.contentLanguages = this.localStorage.getItem('ContentLang');
                this.selectedButtonId = [];
                this.selectedButtonId.push(disp);
                this.isChecked(disp);
           } else {
                this.translate.use('z5-strings-en');
                this.userapiService.getParameter('update', 'display_language', 'en');
                this.contentLanguages = this.localStorage.getItem('ContentLang');
                this.selectedButtonId = [];
                this.selectedButtonId.push('en');
                this.isChecked('en');
        }
        }
      }, err => {
         this.translate.use('z5-strings-en');
         this.selectedButtonId = [];
         this.selectedButtonId.push('en');
         this.isChecked('en');
         this.contentLanguages = this.localStorage.getItem('ContentLang');
         this.gtm.sendErrorEvent('api', err);
         });
    } else {
      if (z === null || z === 'null') {
        this.selectedLanguage = 'English';
        this.selectedLanguageId = 'en';
        // for (let l = 0; l < this.completeValue.length; l++) {
        //   if (this.completeValue[l].is_default === '1') {
        //     this.selectedLanguageId = this.completeValue[l].l_code;
        //   }
        // }
        this.onClicked(this.selectedLanguage, this.selectedLanguageId, '');
        this.translate.use('z5-strings-' + this.selectedLanguageId );
      } else {
        this.selectedLanguageId = z;
        this.localStorage.setItem( 'display_language', this.selectedLanguageId);
        this.onClicked('', this.selectedLanguageId, '');
        this.translate.use('z5-strings-' + this.selectedLanguageId );
      }
    }
  setTimeout(() => {
    let choose;
    choose = this.localStorage.getItem('chooseLang');  // to open contentTab if user clickon moreoptions from video popup
    if (choose) {
      this.localStorage.removeItem('chooseLang');
      this.openTab(1);
    }
  }, 0);
  }
public reloadScreen() {
  setTimeout(() => {
      this.window.location.reload();
  }, 0);
}
  /* For header change in mobile devices */
  @HostListener('window:resize', ['$event'])
  public flagHide() {
    if (this.window.innerWidth < 769) {
      this.headerservicesService.headerScrollSearch(true);
    }
  }

  public openTab(index: any): void {
    this.menuTabs[this.previousTab] = false;
    this.menuTabs[index] = true;
    this.previousTab = index;
    if ( index === 0) {
      this.pageName = 'language/display';
    }
    if ( index === 1) {
      this.pageName = 'language/content';
    }
    this.gtm.sendPageName(this.pageName);
    this.gtm.sendEvent();
  }

  public onClicked(option, id, i) {
   $('#rippleRadio' + i).removeClass('animate');
   clearTimeout(this.controlRipple);
   $('#rippleRadio' + i).addClass('animate');
   this.controlRipple = setTimeout(() => {
   $('#rippleRadio' + i).removeClass('animate');
    }, 300);
   this.selectedButton = [];
   this.selectedButtonId = [];
   this.selectedButton.push(option);
   this.selectedButtonId.push(id);
   this.selectedLanguage = this.selectedButton[0];
    // highlight selected radio option
   if (this.regionLanguage && this.regionLanguage.length > 0) {
      for ( let j = 0; j <= this.regionLanguage.length; j++) {
       if (j === i) {
        this.selectDisLang[j] = true;
       } else {
        this.selectDisLang[j] = false;
       }
      }
   }

  }

  public isChecked(id): boolean {
    return this.selectedButtonId.indexOf(id) > -1;
  }

  public setDisplay(n): void { /*Setting in Service file*/
    this.userapiService.getParameter('put', 'display_language', n);
  }

	public ChangeLanguage(id, name ) { /*Calling Translate Service*/
    this.selectedLanguageId = id;
  }

  public saveLanguage(id, lang) { /* Changing language on clicking Save */
    let network, language_qg;
    network = this.networkService.getPopupStatus();
    if ( network === true) {
      this.update = true;
      language_qg = this.lang.languages_labels.en[id];
      if ( this.userToken && this.settingsSuccess === true) {
        // this.callToastDisplay();
        if ( id !== undefined) {
          if (this.window.qg) {

            // if (!this.qgraph || this.qgraph === undefined) {
              qg('event', 'Display_language_chosen', {'language': language_qg, 'country': this.settingsService.getCountry(), 'state': this.localStorage.getItem('state_code')});
              qg('identify', {'display_language': language_qg, 'country': this.settingsService.getCountry(), 'state': this.localStorage.getItem('state_code')});
            // } else {
            //   qg('event', 'Display_language_chosen', {'language': language_qg});
            //   qg('identify', {'display_language': language_qg});
            // }
          }
          this.translate.use('z5-strings-' + id.toLowerCase());
          this.nativeChange = this.lang.languages_labels[id];
          if (this.contentLangClose.status === 'toast') {  // if user clicked to update disp to content update it
            this.updateSelectedDisplay(id);
          }
          this.openTab(1); // to move content lang tab
        }
      } else if (!this.userToken) {
        // this.callToastDisplay();

        if ( id !== undefined) {
          this.translate.use('z5-strings-' + id.toLowerCase());
          if (this.window.qg) {
            // if (!this.qgraph || this.qgraph === undefined) {
              qg('event', 'Display_language_chosen', {'language': language_qg, 'country': this.settingsService.getCountry(), 'state': this.localStorage.getItem('state_code')});
            // } else {
            //   qg('event', 'Display_language_chosen', {'language': language_qg});
            // }
          }
          this.nativeChange = this.lang.languages_labels[id];
          if (this.contentLangClose.status === 'toast') {   // if user clicked to update disp to content update it
            this.updateSelectedDisplay(id);
          }
          this.openTab(1); // to move content lang tab
        }
      } else if (this.userToken && this.settingsSuccess === false) {
        this.callErrorToast();
      }
    }
  }

  public updateSelectedDisplay(id): any {   // if user clicked to update disp to content update function
    let q, completeContentId, fromDisplayLang = [], a;
    completeContentId = [];
    // for (let i = 0; i < this.completeContent.length; i++) {
    //   completeContentId.push(this.completeContent[i].l_code);
    // }
    // q = completeContentId;
    q = this.regioncontentLanguage;
    a = id;
    fromDisplayLang = a.split(',');
    if (fromDisplayLang.length > 0 ) {
      for ( let k = 0; k < q.length; k++) {
        for ( let j = 0; j < fromDisplayLang.length; j++) {
          if ( fromDisplayLang[j] === this.regioncontentLanguage[k]) {
            this.languageContent = this.regioncontentLanguage[k];
            this.toggleCheckboxes('update', k, this.languageContent, this.welcomeChange[this.languageContent]);
          }
        }
      }
    }
  }
  public languageUpdation(value) { /* Updating language from Localstorage or Settings API*/
    let q, completeContentId;
    completeContentId = [];

    // for (let i = 0; i < this.completeContent.length; i++) {
    //   completeContentId.push(this.completeContent[i].l_code);
    // }
    // q = completeContentId;
    q = this.regioncontentLanguage;

    if ( this.userToken) {
      let a;
      a = this.localStorage.getItem('UserContentLanguage');
      this.fromLocalStorage = a.split(',');
    } else {
      let b;
      b = this.localStorage.getItem('ContentLang');
      this.fromLocalStorage = b.split(',');
    }

// debugger
    if (this.fromLocalStorage.length > 0 ) {
      for ( let k = 0; k < q.length; k++) {
        for ( let j = 0; j < this.fromLocalStorage.length; j++) {
          if ( this.fromLocalStorage[j] === this.regioncontentLanguage[k]) {
            this.languageContent = this.regioncontentLanguage[k];
            this.toggleCheckboxes('update', k, this.languageContent, this.welcomeChange[this.languageContent]);
          }
        }
      }
    }
  }

  public toggleCheckboxes(event, index, id, lang): any { /*Checkbox change asset and ripple*/
    // alert("click");
   let isIdMatch = false;
    this.defaultLanguages.push(id);  /*Adding Content language to array */
    this.content.push(lang);
    /* Removing a Content language if repeated */
    // this.selectionTrack[index] = !this.selectionTrack[index];
    if ( this.selectionTrack[index] === true) {
    if (this.notEditableLang.length !== 0) {
      for (let i = 0; i < this.notEditableLang.length; i++) {
        if (id === this.notEditableLang[i] ) {

          for ( let a = 0; a < this.defaultLanguages.length; a++) {
            for ( let b = a + 1; b < this.defaultLanguages.length; b++) {
               if ( this.defaultLanguages[a] === this.defaultLanguages[b]) {
              this.defaultLanguages.splice(b, 1);
              this.content.splice(b, 1);


        }
      }

    }
      isIdMatch = true;
      this.callDefaultContentLanguageToast();
  }

}
if (!isIdMatch) {
   this.removeDuplicateLang(index, this.defaultLanguages, this.content);
}

} else {
    // for ( let a = 0; a < this.defaultLanguages.length; a++) {
    //    for ( let b = a + 1; b < this.defaultLanguages.length; b++) {
    //      if ( this.defaultLanguages[a] === this.defaultLanguages[b]) {
    //           this.defaultLanguages.splice(a, 1);
    //           console.log(this.defaultLanguages, 'one')
    //           this.content.splice(a, 1);
    //           this.defaultLanguages.splice((b - 1), 1);
    //           console.log(this.defaultLanguages, 'two')
    //           this.content.splice((b - 1), 1);
    //      }
    //    }
    //   }
    // this.selectionTrack[index] = !this.selectionTrack[index];
   this.removeDuplicateLang(index, this.defaultLanguages, this.content);
}
} else {
  // for ( let a = 0; a < this.defaultLanguages.length; a++) {
  //      for ( let b = a + 1; b < this.defaultLanguages.length; b++) {
  //        if ( this.defaultLanguages[a] === this.defaultLanguages[b]) {
  //             this.defaultLanguages.splice(a, 1);
  //             console.log(this.defaultLanguages, 'one')
  //             this.content.splice(a, 1);
  //             this.defaultLanguages.splice((b - 1), 1);
  //             console.log(this.defaultLanguages, 'two')
  //             this.content.splice((b - 1), 1);
  //        }
  //      }
  //     }
  //   this.selectionTrack[index] = !this.selectionTrack[index];
   this.removeDuplicateLang(index, this.defaultLanguages, this.content);


}

    // for ( let a = 0; a < this.defaultLanguages.length; a++) {
    //    for ( let b = a + 1; b < this.defaultLanguages.length; b++) {
    //      if ( this.defaultLanguages[a] === this.defaultLanguages[b]) {
    //           this.defaultLanguages.splice(a, 1);
    //           console.log(this.defaultLanguages, 'one')
    //           this.content.splice(a, 1);
    //           this.defaultLanguages.splice((b - 1), 1);
    //           console.log(this.defaultLanguages, 'two')
    //           this.content.splice((b - 1), 1);
    //      }
    //    }
    //   }
    // this.selectionTrack[index] = !this.selectionTrack[index];
   // if (this.NotEditableLang.length !== 0) {
   //   for (let i = 0; i < this.NotEditableLang.length; i++) {
   //     if (id === this.NotEditableLang[i] ) {
   //       this.selectionTrack[index] = true;
   //        this.callDefaultContentLanguageToast();
   //     } else {

   //     }
   //   }
   // } else {

   // }


    // console.log(this.savedIsEditableData, 'data3')

    //   console.log(this.defaultLanguages, 'removed')
    //  this.selectionTrack[index] = !this.selectionTrack[index];
    //   console.log(this.selectionTrack[index], 'seltrack')
    //   if (this.selectionTrack[index] === false) {
    //     console.log(this.selectionTrack[index], 'selindex')
    //     for (let i = 0; i < this.completeContent.length; i++) {
    //     if (id === this.completeContent[i].l_code) {
    //       console.log(id, this.completeContent[i].l_code, 'inside if')
    //           if (this.completeContent[i].is_editable === '1') {
    //             console.log(this.selectionTrack[index],this.defaultLanguages, 'sel')
    //             this.selectionTrack[index] = true;
    //             console.log(this.selectionTrack[index], id ,this.defaultLanguages, 'ind')

    //             this.callDefaultContentLanguageToast();
    //           } else {
    //             this.selectionTrack[index] = !this.selectionTrack[index];
    //             console.log(this.selectionTrack[index],id, this.defaultLanguages,'abc')
    //           }

    //     }
    //   }
    // }
   }

   public removeDuplicateLang(index, defaultLanguages, content) {
        for ( let a = 0; a < this.defaultLanguages.length; a++) {
       for ( let b = a + 1; b < this.defaultLanguages.length; b++) {
         if ( this.defaultLanguages[a] === this.defaultLanguages[b]) {
              this.defaultLanguages.splice(a, 1);
              this.content.splice(a, 1);
              this.defaultLanguages.splice((b - 1), 1);
              this.content.splice((b - 1), 1);
         }
       }
      }
    this.selectionTrack[index] = !this.selectionTrack[index];
   }

   public saveLanguages() {
     this.sendLanguageDetailsGA();
     this.contentLan = this.userToken ? this.localStorage.getItem('UserContentLanguage') : this.localStorage.getItem('ContentLang');
     let b, str, str1, userContentLan, guestContentLan, langpresent = false, show_cat_1_pop_up;
     b = this.localStorage.getItem('ContentLang');
     str = this.defaultLanguages.join();
     str1 = this.content.join();
     this.localStoragevalue = [];
     this.localStoragevalue.push(str);
     let network;
     network = this.networkService.getPopupStatus();
     if (network === true) {
      if ( this.defaultLanguages.length < 1 ) {
        this.callToastContentDefault();
      } else {
      if ( this.userToken && this.settingsSuccess === true ) {
        userContentLan = this.localStoragevalue && this.localStoragevalue[0] ? this.localStoragevalue[0] : '';
        this.usercontentLanArray = userContentLan.split(',');
        show_cat_1_pop_up = true;
          for (let j = 0; j < this.usercontentLanArray.length; j++) {
             if (this.contentLanId.indexOf(this.usercontentLanArray[j]) >= 0) {
               langpresent = true;
               show_cat_1_pop_up = false;
               break;
             }
          }
           if (this.contentLanId.length === 0) {
            langpresent = true;
          }
          if (show_cat_1_pop_up && this.contentLanId.length !== 0) {
            this.callGetlangapi();
          } else {
            this.localStorage.setItem( 'UserContentLanguage', this.localStoragevalue);
            this.setContent('content_language', str);
          }
          if (langpresent) {
            this.callToastContent();
          }
        if (this.window.qg) {
            // if (!this.qgraph || this.qgraph === undefined) {
               qg('event', 'Content_language_chosen', {'language': str1, 'country': this.settingsService.getCountry(), 'state': this.localStorage.getItem('state_code') });
              qg('identify', {'content_language': str1 , 'country': this.settingsService.getCountry(), 'state': this.localStorage.getItem('state_code')});
            // } else {
            //   qg('event', 'Content_language_chosen', {'language': str1 });
            //   qg('identify', {'content_language': str1 });
            // }
        }
      } else if (!this.userToken) {
        let show_cat_1_pop_up_guest, langpresent_guest = false, x;
        x = this.localStorage.getItem('display_language');
        guestContentLan = this.localStoragevalue && this.localStoragevalue[0] ? this.localStoragevalue[0] : '';
        this.guestContentLanArray =  guestContentLan.split(',');
        show_cat_1_pop_up_guest = true;
          for (let j = 0; j < this.guestContentLanArray.length; j++) {
             if (this.contentLanId.indexOf(this.guestContentLanArray[j]) >= 0) {
                langpresent_guest = true;
                show_cat_1_pop_up_guest = false;
               break;
             }
          }
          if (this.contentLanId.length === 0) {
            langpresent_guest = true;
          }
          if (show_cat_1_pop_up_guest && this.contentLanId.length !== 0) {
            this.callGetlangapi();
          }  else {
            this.localStorage.setItem( 'ContentLang', this.localStoragevalue);
          }
          if (langpresent_guest) {
               this.callToastContent();
          }
        if (this.window.qg) {
          // if (!this.qgraph || this.qgraph === undefined) {
            qg('event', 'Content_language_chosen', {'language': str1, 'country': this.settingsService.getCountry(), 'state': this.localStorage.getItem('state_code')});
          // } else {
          //   qg('event', 'Content_language_chosen', {'language': str1 });
          // }
        }
      } else if (this.userToken && this.settingsSuccess === false) {
        this.callErrorToast();
      }
      }
    }
  }
public saveAndreload(): any {  // reload function
  let prev, display_language;
  prev = localStorage.getItem('previousRoute');
  display_language = this.userToken ? this.localStorage.getItem('UserDisplayLanguage') : this.localStorage.getItem('display_language');
   if (display_language === 'en') {
      this.window.location.href = this.window.location.origin  + prev;
    } else {
      this.window.location.href = this.window.location.origin + '/' + display_language  + prev;
    }
}
  public closeLanguage(screen) {
    $('#fullContainer').show();
    $('#searchOverlay').hide();
    this.headerservicesService.languageIcon(false);
    this.headerservicesService.modelChange(false);
    $('#body').removeClass('scrolldisbale');
    if (this.savedDisplayLang && this.contentLangClose && this.contentLangClose.view === 'language' && (this.contentLangClose.status === 'toast' || this.contentLangClose.status === 'route' || this.contentLangClose.status === 'display' || this.contentLangClose.status === 'close')) {
      this.saveAndreload();
    } else {
    if (screen === 'home') {
      this.routerLink.navigate(['/']);
    } else if (screen === 'browserback') {
      this.saveAndreload();
    } else {
      let prev;
      prev = localStorage.getItem('previousRoute');
      this.routerLink.navigate([prev]);
    }
    }
  }



  public setContent(key, n): any {       /*Setting in Service file*/
    this.userapiService.getParameter('put', key, n);
  }

  public callToastDisplay() {             /* Calling Toast for display language */
    let p;
    p = this.document.getElementById('snackbarDisplay');
    p.className = 'show';
    setTimeout(function() { p.className = p.className.replace('show', ''); }, 3000);
  }

  public callToastContent() {              /* Calling Toast for content language */
    let p, scope;
    scope = this;
    p = this.document.getElementById('snackbarContent');
    p.className = 'show';
    setTimeout(function() { p.className = p.className.replace('show', '');
      scope.saveAndreload();
    }, 3000);
  }

  public callToastContentDefault() {        /* Calling Toast if not even a single content language is selected */
    let p;
    p = this.document.getElementById('snackbarContentSelect');
    p.className = 'show';
    setTimeout(function() { p.className = p.className.replace('show', ''); }, 3000);
  }

  public callErrorToast() {                 /* Calling Toast if unable to save settings */
    let p;
    p = this.document.getElementById('snackbarError');
    p.className = 'show';
    setTimeout(function() { p.className = p.className.replace('show', ''); }, 3000);
  }

  public callDefaultContentLanguageToast() {
    let p;
    p = this.document.getElementById('snackbarDefaultContent');
    p.className = 'show';
    setTimeout(function() { p.className = p.className.replace('show', ''); }, 3000);
  }

  public dothis(value): any {
    let configDisplay, configContent, countryValue, display;
    configDisplay = value.fallback_languages.display;
    configContent = value.fallback_languages.content;
    countryValue = this.settingsService.getCountryValue();
    display = this.userToken ? this.localStorage.getItem('UserDisplayLanguage') : this.localStorage.getItem('display_language');
    this.http.get(environment.languagesApi + countryValue.country_code + '&state=' + countryValue.state_code + '&translation=' + display + '&version=' + 1.1).timeout(environment.timeOut).subscribe(valueLang => {
    $('#loaderPage').css('display', 'none');
    let completeDisplayId, completeContentId;
    this.completeDisplay = valueLang.json().display;
    this.completeContent = valueLang.json().content;
    this.notEditableLang = this.settingsService.getNonEditableLang(this.completeContent);
    this.settingsService.setContentLanguages(this.completeContent);
    this.settingsService.setDisplayLanguages(this.completeDisplay);
    completeDisplayId = [];
    completeContentId = [];
    let configdisplay;
     configdisplay = [];
    this.regionLanguage = [];
    this.regioncontentLanguage = [];


       this.contentLanId = [];
    if ( this.completeDisplay === undefined || this.completeContent === undefined) {
      this.completeDisplay = value.fallback_languages.display;
      this.completeContent = value.fallback_languages.content;
    }
    for (let j = 0; j < this.completeContent.length; j++) {
        if (this.completeContent[j].category === '1') {
          this.contentLanId.push(this.completeContent[j].l_code);
        }
     }
    // for (let i = 0; i < this.completeDisplay.length; i++) {
    //   completeDisplayId.push(this.completeDisplay[i].l_code);
    // }

    // for (let j = 0; j < this.completeContent.length; j++) {
    //   completeContentId.push(this.completeContent[j].l_code);
    // }
    // for (let i = 0; i<value.languages.length; i++) {
    //   configdisplay.push(value.languages[i].id)
    // }
    // for (let i = 0; i < completeDisplayId.length; i++) {
    //   if (configdisplay.indexOf(completeDisplayId[i]) >= 0) {
    //     this.regionLanguage.push(completeDisplayId[i]);

    //   }
    // }

    //  for (let i = 0; i < completeContentId.length; i++) {
    //   if (configdisplay.indexOf(completeContentId[i]) >= 0) {
    //     this.regioncontentLanguage.push(completeContentId[i]);
    //    // console.log(this.regioncontentLanguage, 'region1')
    //   }
    // }

  // this.regionLanguage = completeDisplayId;
  // this.regioncontentLanguage = completeContentId;
  this.regionLanguage = this.settingsService.getDisplayLanId();
  this.regioncontentLanguage = this.settingsService.getContentLanId();

    let z, y;
    z = this.localStorage.getItem('display_language');
    y = this.localStorage.getItem('UserDisplayLanguage');
    this.lang = value;
    if (!this.selectedLanguage && this.selectedLanguageId) {
      this.selectedLanguage = this.lang.languages_labels.en[this.selectedLanguageId];
      this.onClicked(this.selectedLanguage, this.selectedLanguageId, this.regionLanguage.indexOf(this.selectedLanguageId));
    }
    this.nativeChange = this.userToken ? this.lang.languages_labels[y] : this.lang.languages_labels[z];

    for (let k = 0; k < this.regionLanguage.length; k++) {

      this.selectDisLang[k] = false; // change color of selected option
      if (this.regionLanguage[k] === this.selectedButtonId[0]) {
        this.nativeChange = this.lang.languages_labels[this.selectedButtonId[0]];
        this.onClicked('', this.selectedButtonId[0], k);
      }
    }
    if (this.selectedButtonId[0] !== undefined)  {
      this.nativeChange = this.lang.languages_labels[this.selectedButtonId[0]];
    } else {
    this.nativeChange = this.userToken ? this.lang.languages_labels[y] : this.lang.languages_labels[z];
    }
    this.welcomeChange = this.lang.languages_labels['en'];
    this.language = [];

    let self;
    self = this;
    value.languages.forEach(function(obj) {
      let temp;
      temp = {
        'name': obj.name,
        'native': obj.native,
      };
      self.language[obj.id] = temp;
    });

    this.languageUpdation(value);
    return this.language;
    },
    error => {
      $('#loaderPage').css('display', 'none');
      let completeDisplayId, completeContentId;
      completeDisplayId = [];
      completeContentId = [];
      this.completeDisplay = value.fallback_languages.display;
      this.completeContent = value.fallback_languages.content;

      for (let i = 0; i < this.completeDisplay.length; i++) {
        completeDisplayId.push(this.completeDisplay[i].l_code);
      }

      for (let j = 0; j < this.completeContent.length; j++) {
        completeContentId.push(this.completeContent[j].l_code);
      }

    this.regionLanguage = completeDisplayId;
    this.regioncontentLanguage = completeContentId;

    let z;
    z = this.localStorage.getItem('display_language');
    this.lang = value;
    this.nativeChange = this.lang.languages_labels['en'];

    for (let k = 0; k < this.regionLanguage.length; k++) {
      if (this.regionLanguage[k] === this.selectedButtonId[0]) {
        this.nativeChange = this.lang.languages_labels[this.selectedButtonId[0]];
        this.onClicked('', this.selectedButtonId[0], k);
      }
    }
    if (this.selectedButtonId[0] !== undefined)  {
      this.nativeChange = this.lang.languages_labels[this.selectedButtonId[0]];
    } else {
    this.nativeChange = this.lang.languages_labels['en'];
    }
    this.welcomeChange = this.lang.languages_labels['en'];
    this.language = [];

    let self;
    self = this;
    value.languages.forEach(function(obj) {
      let temp;
      temp = {
        'name': obj.name,
        'native': obj.native,
      };
      self.language[obj.id] = temp;
    });

    this.languageUpdation(value);
    return this.language;

    });
  }

  public fetchlanguages(): any {
    this.dothis(this.settingsService.getCompleteConfig());
  }
  public contentLanguage(id, lang): any {  // on click of save in displayLang screen update and fire api
    this.sendLanguageDetailsGA();
    this.translate.use('z5-strings-' + id );
    this.savedDisplayLang = true;
    if (this.userToken) {
        let y;
        y = this.localStorage.getItem('UserDisplayLanguage');
        this.localStorage.setItem('previousDisplayLanguage', y);
       this.localStorage.setItem('UserDisplayLanguage', id);
       this.setDisplay(id);
    } else {
      this.localStorage.setItem( 'display_language', id);
      this.localStorage.setItem( 'Langoption', lang);
    }
    this.callToastDisplay();
    this.callDisplayGetlangapi(id);
  }
  public callGetlangapi(): any {  // on click of save in content lang screen fire api
    let countryValue, display;
    countryValue = this.settingsService.getCountryValue();
    display = this.userToken ? this.localStorage.getItem('UserDisplayLanguage') : this.localStorage.getItem('display_language');
    this.http.get(environment.languagesApi + countryValue.country_code + '&state=' + countryValue.state_code + '&translation=' + display + '&version=' + 1.1).timeout(environment.timeOut).subscribe(valueLang => {
    this.settingsService.setCompleteGetLanguages(valueLang.json());
    this.settingsService.setContentLanguages(valueLang.json().content);
    this.notEditableLang = this.settingsService.getNonEditableLang(valueLang.json().content);

    this.contentLanFlag = true;
    }, error => {
      this.contentLanFlag = true;
    });
  }
  public callDisplayGetlangapi(display): any {
    let countryValue;
    countryValue = this.settingsService.getCountryValue();
    this.http.get(environment.languagesApi + countryValue.country_code + '&state=' + countryValue.state_code + '&translation=' + display + '&version=' + 1.1).timeout(environment.timeOut).subscribe(valueLang => {
    this.settingsService.setCompleteGetLanguages(valueLang.json());
    this.settingsService.setContentLanguages(valueLang.json().content);
    this.notEditableLang = this.settingsService.getNonEditableLang(valueLang.json().content);
    this.settingsService.callContentLangFunction(display, 'language');
    }, error => {
    this.settingsService.callContentLangFunction(display, 'language');

    });
  }
  public ngOnDestroy () {
    this.localStorage.removeItem('chooseLang');
    this.linkservice.removeCanonicalLink();
    this.headerservicesService.LanguageScreen(false);
  }
  public sendLanguageDetailsGA() {
    let languageDetails;
    languageDetails = {
      'event': 'doneButtonClick',
      'Previous_Display_Lang': this.gtm.fetchLangName(this.prevDisplayLang),
      'Previous_Content_Lang': this.gtm.fetchLangName(this.prevContentLang)
    };
    this.gtm.sendEventDetails(languageDetails);
  }
}

