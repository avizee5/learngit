import { Component, OnInit, Input, Output, EventEmitter, HostListener, OnDestroy, OnChanges } from '@angular/core';
import * as $ from 'jquery';
import { environment } from '../../environments/environment';
declare const FB;
declare const gapi;
import { RouteService } from '../services/route.service';
import { CommonService } from '../services/common.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';

@Component({
  selector: 'app-share-options',
  templateUrl: './share-options.component.html',
  styleUrls: ['./share-options.component.less']
})
export class ShareOptionsComponent implements OnInit, OnChanges  {
  public menuShare: any;
  public previousTab: number;
  public options: any;
  public basepath: any;
  public gpselected: any;
  public gpnormal: any;
  public fbselected: any;
  public fbnormal: any;
  public mail: any;
  public fbsvg: any;
  public fbsvgselected: any;
  public gpsvg: any;
  public gpsvgselected: any;
  public mailsvg: any;
  public commonsharearrow: any;
  public document: any;
  public navigator: any;
  public shownative: any = false;
  @Input() public extern_url: any;
  @Input() public show: boolean;
  @Input() public player: boolean;
  @Input() public consumptionPage: any;
  @Output() public closeshare: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() public sharenetwork: EventEmitter<string> = new EventEmitter<string>();
  @Input() public url: any;
  public shareURL: any;
  public nowTvDomain: any = false;
  constructor(@Inject(PLATFORM_ID) private platformId: Object, private gtm: GoogleAnalyticsService, private routeservice: RouteService, private commonService: CommonService) { }

  public ngOnInit() {
    this.gtm.storeWindowError();
    if (isPlatformBrowser(this.platformId)) {
      this.document = document;
      this.navigator = navigator;
    }
    this.nowTvDomain = this.commonService.getNowTvDomain();
    this.basepath = environment.assetsBasePath;
    this.commonsharearrow = this.basepath + 'assets/common/share_arrow.png';
    this.gpselected = this.basepath + 'assets/social/googleplus_selected.png';
    this.fbselected = this.basepath + 'assets/social/fb_selected.png';
    this.mail = this.basepath + 'assets/social/email_normal.png';
    this.gpnormal = this.basepath + 'assets/social/googleplus_normal.png';
    this.fbnormal = this.basepath + 'assets/social/fb_normal.png';
    this.gpsvg = this.basepath + 'assets/social/social.svg#google_icon-view';
    this.fbsvg = this.basepath + 'assets/social/social.svg#fb_icon-view';
    this.mailsvg = this.basepath + 'assets/social/social.svg#mail_icon-view';
    this.gpsvgselected = this.basepath + 'assets/social/social.svg#google_icon_selected-view';
    this.fbsvgselected = this.basepath + 'assets/social/social.svg#fb_icon_selected-view';

    let urlstring, scope;
    if (this.extern_url || (this.url !== undefined && this.url !== null)) {
      if (this.extern_url) {
        this.shareURL = this.extern_url;
      } else {
        urlstring = this.url.split(' ').join('');
        if (urlstring[0] === '/') {
          urlstring = urlstring.replace('/', '');
        }
        this.shareURL = environment.shareUrl + this.routeservice.getBaseLocation() + urlstring;
            if (this.navigator.share) {
              this.shownative = true;
            this.navigator.share({
                url: this.shareURL,
            })
              .then(() => console.log('Successful share'))
              .catch((error) => console.log('Error sharing', error));
          }
      }
      setTimeout(() => {
        $('#email').attr('href', 'mailto:?subject='
          + encodeURIComponent('Zee5')
          + '&body='
          + encodeURIComponent('Hi,I found this website and thought you might like it ' + this.shareURL)
          );
      }, 0);

    }
    this.menuShare = [false, false, false];
    this.previousTab = 0;
    scope = this;
    $(this.document).mouseup(function(e) {
      this.container = $('#shareOptions');
      // if clicked element is not your element and parents aren't your div
      if (e.target.id !== '#shareOptions' && !$('#shareOptions').find(e.target).length) {
        if (scope.show || scope.player) {
          scope.closeShare();
        }
      }
    });
  }
  public ngOnChanges (changes: any) {
    if (this.show === true || this.player === true) {
      this.menuShare = [false, false, false];
    }
  }
  public closeShare(): void {
    if (this.show) {
      this.closeshare.emit(false);
      this.show = false;
      this.player = false;
    }
  }
  public openShare(index: any, id: any): void {


           if ( index === 0) {
            this.sharenetwork.emit('facebook');
            this.test();
          } else if (index === 1) {
            this.sharenetwork.emit('google+');
            $('#sharePost').click();
          } else if (index === 2) {
            this.sharenetwork.emit('mail');
          }

  }
  @HostListener('window:scroll', ['$event'])
  public onScroll(event) {
    this.closeShare();
  }

    public test() {
    FB.ui({
     method: 'feed',
    link: this.shareURL,
    caption: 'An example caption',
        // The same than link in feed method
     // The same than name in feed method
    }, function (response) {
      if (response && !response.error_message) {
        // todo
      } else {
        // todo
      }
    });
  }

  public onFocus(index: any) {
        this.menuShare[index] = true;
  }
  public outFocus(index: any) {
    this.menuShare[index] = false;
  }
}
