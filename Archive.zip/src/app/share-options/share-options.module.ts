import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShareOptionsComponent } from './share-options.component';
import { SharedModule } from '../shared.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule
  ],
  declarations: [ShareOptionsComponent],
  exports: [ShareOptionsComponent]

})
export class ShareoptionsModule {
}

