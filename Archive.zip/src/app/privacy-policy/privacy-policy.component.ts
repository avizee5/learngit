import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { RouteService } from '../services/route.service';
import { HeaderservicesService } from '../services/headerservices.service';
import {  NetworkService  } from '../services/network.service';
import * as $ from 'jquery';
import { LinkService } from '../services/link.service';
import { Http} from '@angular/http';
import { SettingsService } from '../services/settings.service';
import {DomSanitizer} from '@angular/platform-browser';
import {environment} from '../../environments/environment';
import { FooterService } from '../services/footerdata.service';


@Component({
  selector: 'app-privacy-policy',
  templateUrl: './privacy-policy.component.html',
  styleUrls: ['./privacy-policy.component.less']
})
export class PrivacyPolicyComponent implements OnInit, OnDestroy {
	public router: any;
  public router2: any;
  public pageName: any;
  public data: any;
  public country_code: any;
  public privacy_policy_src: any;
  public privacyBreadCrump: any;
  public contentValue: any;
  private translation: any;

  constructor(private footerservice: FooterService, private sanitizer: DomSanitizer, private settingsService: SettingsService, private http: Http, private linkservice: LinkService, private networkService: NetworkService, private routeservice: RouteService, private gtm: GoogleAnalyticsService, private routeLink: Router, private headerservicesService: HeaderservicesService) {
  	const scope = this;
    this.router = routeLink;
    this.router2 = window.location.pathname;
    this.headerservicesService.viewChange(this.router2);
    this.routeservice.setRoute(this.router2);
    this.routeservice.setLoginRoute(window.location.pathname);
  }

  public ngOnInit() {
    this.country_code = this.settingsService.getCountry();
    this.gtm.storeWindowError();

        this.privacyBreadCrump = [
        {
          'label': 'BREADCRUMB.HOME',
          'url': '/',
          'enable': true
        },
        {
          'label': 'BREADCRUMB.PRIVACY',
          'url': '/privacypolicy',
          'enable': false
        }
      ];

      let token;
      token = localStorage.getItem('token');
        if (token) {
            this.translation = localStorage.getItem('UserDisplayLanguage');
        } else {
            this.translation = localStorage.getItem('display_language');
        }
      this.headerservicesService.breadCrump(this.privacyBreadCrump);
    let network;
    this.linkservice.addTag({ rel: 'canonical', href: window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'privacypolicy'  } );
    network = this.networkService.getScreenStatus();
  	this.pageName = 'privacy policy';
    this.gtm.sendPageName(this.pageName);
    this.gtm.sendEvent();
  	window.scrollTo(0 , 0);
    this.privacy_policy_src = environment.shareUrl + 'zeeaction.php?ccode=' + this.country_code + '&text_type=privacy_policy_text' + '&translation=' + this.translation;
    this.footerservice.getFooterdata1(this.privacy_policy_src).subscribe( value => {
      this.contentValue = value._body;
      $('#loaderPage').css('display', 'none');
    });
  }
  public ngOnDestroy () {
    this.linkservice.removeCanonicalLink();
  }
}
