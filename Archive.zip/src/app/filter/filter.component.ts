import { Component, OnInit, Output, EventEmitter, Input, HostListener, OnDestroy, OnChanges, Inject, PLATFORM_ID  } from '@angular/core';
import * as $ from 'jquery';
import { FilterService } from '../services/filter.service';
import { Subscription } from 'rxjs/Subscription';
import { SettingsService } from '../services/settings.service';
import { UserApiService } from '../services/user-api.service';
declare const qg;
import { environment } from '../../environments/environment';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { isPlatformBrowser } from '@angular/common';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.less']
})
export class FilterComponent implements OnInit, OnDestroy, OnChanges {
  @Input() private filter: boolean;
  @Input() public arrayList: any;
  @Input() private view: any;
  @Input() private viewname: any;
  @Output() public changestatus: EventEmitter<boolean> = new EventEmitter<boolean>();
  private code: number;
  private filterbar: boolean;
  private filter_titles: any;
  private languages: Array<any> = [];
  private genre: Array<any> = [];
  private heading: string;
  private filterTitles: boolean;
  private filter_title: string;
  private selected_title: boolean;
  private filterData: boolean;
  private select_All: boolean;
  private all: string;
  private filters: Array<any> = [];
  private selectedFilters: Array<any> = [];
  private selectedFiltersLength: Array<any> = [];
  private selectedlanguages_length: number;
  private errorMessage: any;
  private count: number;
  private durationChk: boolean;
  private selectedgenre_length: number;
  private buttonName1: string;
  private all_index: number;
  private IE: boolean;
  private buttonType: string;
  private show: boolean;
  private className: any;
  private lang_id: any;
  private configData: any;
  private containerheight: any;
  private innerwindowheight: any;
  private val: any;
  private touch_screen: boolean;
  private tvshowsGenre: any;
  private moviesGenre: any;
  private channelsGenre: any;
  private videosGenre: any;
  private containerView: boolean;
  private prev_view: any;
  private filter_ser: Subscription;
  private livetv: Subscription;
  private assetbasepath: any;
  private fromLocalStorage: any;
   private localstorage: any;
   private window: any;
   private document: any;
   private navigator: any;
   private apiValue = false;
  constructor (@Inject(PLATFORM_ID) private platformId: Object, private gtm: GoogleAnalyticsService, private userapiService: UserApiService, private filterService: FilterService, private settingsService: SettingsService) {
    this.filter_ser = this.filterService.configObservable.subscribe(value => {
      this.selectedFilters = value.filter(x => x.code === this.code);
      this.check();
    });
    if (isPlatformBrowser(this.platformId)) {
   this.localstorage = localStorage;
    this.window = window;
    this.document = document;
    this.navigator = navigator;
}
    this.livetv = this.filterService.clickenable.subscribe(value => {
      if (value) {
        $('#check').css('cursor', '');
        $('.button_size').css('pointerEvents', '');
      } else {
        $('#check').css('cursor', 'not-allowed');
        $('.button_size').css('pointerEvents', 'none');
      }
    });
  }
  public ngOnInit() {
    this.assetbasepath = environment.assetsBasePath;
    this.show = false;
    this.gtm.storeWindowError();
    this.touch_screen = false;
    this.className = $('#router');
    this.lang_id = this.localstorage.getItem('display_language');
    this.all = 'Select All';
    this.heading = 'Filter';
    this.filterbar = false;
    this.filter_titles = this.arrayList;
    this.filterTitles = true;
    this.selected_title = false;
    this.apiValue = this.settingsService.getApiStatus();
    this.fetchConfig();
    this.innerwindowheight = this.window.innerHeight;
    this.IE = false;
    this.getbrowser();
    if (this.lang_id == null) {
      this.lang_id = 'en';
    }
    let img1, img2, img3, img4, scope;
    img1 = new Image();
    img1.src = this.assetbasepath + 'assets/common/close_icon.png';
    img2 = new Image();
    img2.src = this.assetbasepath + 'assets/common/next_icon.png';
    img3 = new Image();
    img3.src = this.assetbasepath + 'assets/common/prev_icon.png';
    img4 = new Image();
    img4.src = this.assetbasepath + 'assets/common/remove_icon.png';
    scope = this;
    $( this.document ).ready(function() {
      scope.selectedFilters = scope.filterService.getFilters();
      scope.check();
    });
    $(this.document).mouseup(function(e) {
      this.container = $('.outerContainer');
      // if clicked element is not your element and parents aren't your div
      if (scope.filter) {
        if (!this.container.is(e.target) && this.container.has(e.target).length === 0) {
          scope.exit();
          scope.closeFilter();
        }
      }
    });
    $(this.document).on('touchstart', function (e) {
      this.container = $('.outerContainer');
      // if clicked element is not your element and parents aren't your div
      if (scope.filter) {
        if (!this.container.is(e.target) && this.container.has(e.target).length === 0) {
          scope.exit();
          scope.closeFilter();
        }
      }
    });
  }

// to update the length label
private getbrowser(): void {
  if (this.navigator.userAgent.indexOf('Trident') !== -1 ) {
    this.IE = true;
  }
}
private setcontent(): void {
  let a, g, languagelist, token, settings, b, c;
  a = this.filterService.getView();
  this.filterService.setView(this.viewname);
  if (this.viewname === a) {
    g = this.filterService.getFilters();
    this.filterService.addarrayFilter(g, false);
  } else {
    token = this.localstorage.getItem('token');
    settings = this.userapiService.getSettings();
    if (token) {
      if (this.localstorage.getItem('UserContentLanguage') !== undefined) {
        b = this.localstorage.getItem('UserContentLanguage');
        this.fromLocalStorage = b.split(',');
        languagelist = this.fromLocalStorage;
        this.lang_id = this.localstorage.getItem('UserDisplayLanguage');
        if (this.lang_id === null) {
                this.lang_id = 'en';
        }
      } else {
        c = this.localstorage.getItem('ContentLang');
        this.fromLocalStorage = c.split(',');
        this.lang_id = this.localstorage.getItem('UserDisplayLanguage');
        languagelist = this.fromLocalStorage;
      }
    } else {
      c = this.localstorage.getItem('ContentLang');
      this.fromLocalStorage = c.split(',');
      languagelist = this.fromLocalStorage;
    }
    let temp, index;
    temp = [];
    for (let i = 0; i < languagelist.length; i++) {
      index = this.languages.findIndex(x => x.id === languagelist[i]);
      if (index > -1) {
              temp.push({code: 1, id: this.languages[index].id, name: this.languages[index].value});
      }
    }
    this.filterService.addarrayFilter(temp, true);
  }
  this.prev_view = this.viewname;
}

public ngOnChanges(changes: any) {
  if (this.filter) {
    this.filterService.togglelay(true);
    if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
      this.document.getElementById('body').classList.add('modalOpen');
      this.touch_screen = true;
    }
    this.innerwindowheight = this.window.innerHeight;
    setTimeout(() => {
      let b, h, h1, value;
      b = parseFloat($('#filterHeading').css('marginTop'));
      this.val = b;
      if (this.window.innerWidth <= 480) {
        value = 35 + 10 + 15 + (2 * b) + 21.6 + 15;
        h = this.window.innerHeight;
        h1 = h - value;
        this.containerheight = h1;
      } else {
        value = 42 + 10 + 15 + (2 * b) + 24 + 15;
        h  = this.window.innerHeight;
        h1 = h - value;
        this.containerheight = h1;
      }
    }, 0);
  }
}
private check(): void {
  if (this.languages) {
    this.selectedlanguages_length = (this.filterService.getSelectedLanguageView()).length;
    this.selectedFiltersLength[1] = this.selectedlanguages_length;
  }
  if (this.genre) {
    this.selectedgenre_length = (this.filterService.getSelectedGenreView()).length;
    this.selectedFiltersLength[0] =  this.selectedgenre_length;
  }
}
private isSelectedAll(list): boolean {
  if (list === this.languages) {
    this.all_index = 1;
  } else if (list === this.genre) {
    this.all_index = 0;
  }
  let a;
  a = this.selectedFiltersLength[this.all_index] === list.length;
  return this.selectedFiltersLength[this.all_index] === list.length;
}
// select the filter type
private select (title, n): void {
  switch (title) {
    case 'COMMON.LANGUAGE':
    this.selectLanguage(n);
    break;
    case  'DETAILS.GENRE':
    this.selectGenre(n);
    break;
    default:
    break;
  }
}
// to display the length label if selectedFilter is greater than 0
private checklength(i): boolean {
  if (i <= 1) {
    return this.selectedFiltersLength[i] > 0;
  }
}
private fetchConfig(): any {
  this.configData = this.settingsService.getCompleteConfig();
  this.fetchGenre();
  this.fetchlanguages();
  this.setcontent();
}
// to fetch languages from service
private fetchlanguages(): any {
  this.languages  = [];
  this.apiValue = this.settingsService.getApiStatus();
    if (this.apiValue) {
        let languagelist, contentLanguage;
        contentLanguage = this.settingsService.getContentLanguages();
        if (contentLanguage && contentLanguage !== undefined && contentLanguage !== null && contentLanguage.length > 0) {
          languagelist = contentLanguage.map(a => a.l_code);
          this.setLanguages(languagelist);
            this.filterService.setLanguages(languagelist, this.view);
        } else {
             this.getLanguageList();
        }
    } else {
         this.getLanguageList();
    }
}
private getLanguageList(): void {
      let languagelist, contentLanguage;
     contentLanguage = this.configData.fallback_languages.content;
      languagelist = contentLanguage.map(a => a.l_code);
     this.setLanguages(languagelist);
     this.filterService.setLanguages(languagelist, this.view);
}
private setLanguages(languagelist): void {
     let  languageLabels;
    this.lang_id = this.filterService.gettranslation();
    languageLabels = this.configData.languages_labels[this.lang_id];
      for (let i = 0; i < languagelist.length; i++) {
        this.languages.push({id: languagelist[i], value: languageLabels[languagelist[i]]});
      }
}
// to fetch genre from service
private fetchGenre(): void {
  this.tvshowsGenre = this.filterService.getShowsGenre();
  this.moviesGenre = this.filterService.getMoviesGenre();
  this.channelsGenre = this.filterService.getChannelsGenre();
  this.videosGenre = this.filterService.getVideosGenre();
  this.genre = [];
  if (this.view === 'movies') {
    this.genre = this.moviesGenre;
  } else if (this.view === 'tvshows' || this.view === 'zeeoriginals') {
    this.genre = this.tvshowsGenre;
  } else if (this.view === 'videos') {
    this.genre = this.videosGenre;
  } else {
    this.genre = this.channelsGenre;
  }
}

// to set the view based on the selection of filter type
private setView(): void {
  this.filterTitles = false;
  this.selected_title = true;
  this.filterData = true;
  this.durationChk = false;
  this.buttonType = 'checkbox';
  $('.innerContainer').scrollTop(0);
}
// language listing
private selectLanguage(n): void {
  this.containerView = true;
  this.fetchlanguages();
  this.setView();
  this.code = 1;
  this.filters = this.languages;
  this.buttonName1 = this.filter_titles[0].name;
  this.filter_title = this.filter_titles[1].name;
  let languageSelected;
   languageSelected = this.filterService.getSelectedLanguageView();
  let languageToHighlight;
   languageToHighlight = [];
  // this.selectedFilters = []
  for (let i = 0; i < languageSelected.length ; i++) {
    for (let j = 0 ; j < this.languages.length; j++) {
      if (languageSelected[i] === this.languages[j].id) {
          let languageToHighlightObject: any;
          languageToHighlightObject = {};
          languageToHighlightObject.name = this.languages[j].value;
          languageToHighlightObject.code = 1;
          languageToHighlightObject.id = this.languages[j].id;
          languageToHighlight.push(languageToHighlightObject);
      }
    }
  }
   this.selectedFilters = languageToHighlight;
  this.select_All = true;
}
// genre listing
private selectGenre(n): void {
  this.containerView = true;
  this.fetchGenre();
  this.setView();
  this.code = 3;
  this.filters = this.genre;

  let genreselected;
  genreselected = this.filterService.getSelectedGenreView();

  let genreToHighlight;
  genreToHighlight = [];
  for (let i = 0; i < genreselected.length ; i++) {
    for (let j = 0 ; j < this.genre.length; j++) {
      if (genreselected[i] === this.genre[j].id) {
          let genreToHighlightObject: any;
          genreToHighlightObject = {};
          genreToHighlightObject.name = this.genre[j].value;
          genreToHighlightObject.code = 3;
          genreToHighlightObject.id = this.genre[j].id;
          genreToHighlight.push(genreToHighlightObject);
      }
    }
  }


  this.selectedFilters = genreToHighlight;
  this.buttonName1 = this.filter_titles[1].name;
  this.filter_title = this.filter_titles[0].name;
  this.select_All = true;
}
// exit from sub filter type to main filter
private exit(): void {
  if (this.filterData || this.durationChk) {
    this.filterData = false;
    this.durationChk = false;
  }
  this.filterTitles = true;
  this.containerView = false;
  this.selected_title = false;
}
// selection of checkbox/radiobutton
private onClicked(option, event, i) {
  let checkbox, action;
  checkbox = event.target;
  action = (checkbox.checked ? 'add' : 'remove');
  this.updateSelection(option, action);
}
// based on the target add/remove from the selectedFilter array
private updateSelection(option, action) {
  if (action === 'add') {
    this.addFilter(option.value, option.id);
  } else if (action === 'remove') {
    // this.removeFilter(option.value);
    this.removeFilter(option.value, option.id);
  }
}
// select all
private selectAll = function(event, list) {
  let checkbox, action;
  checkbox = event.target;
  action = (checkbox.checked ? 'add' : 'remove');
  this.filterService.selectAll(list, action, this.code);
};
// to add the selected filter into an array
private addFilter(selected: string, id: any): void {
  this.filterService.addFilter(this.code, id, selected);
}
// to remove the selected filter from array
// private removeFilter(selected: string): void {
private removeFilter(selected: string, id: any): void {
  let index, remove;
  index = this.selectedFilters.findIndex(x => x.id === id);
  // index = this.selectedFilters.findIndex(x => x.name === selected);
  // console.log(selected, id, index, this.selectedFilters[index])
  remove = this.filterService.deleteFilter(id);
  // remove = this.filterService.deleteFilter(index);
}
// to set /reset the checkboxes
// private isSelected(name): boolean {
private isSelected(id): boolean {
  return this.selectedFilters.some(x => x.id === id);
  // return this.selectedFilters.some(x => x.name === name);
}
// if the mouse enters on the div -- browser scroll disable
private mouseEnter() {
  if (this.IE) {
        this.document.getElementById('body').classList.add('overlay-open');
  } else {
    let x, y;
    x = this.window.scrollX;
    y = this.window.scrollY;
    this.window.onscroll = function() {this.window.scrollTo(x, y); };
  }
}
// if the mouse leaves the div -- browser scroll enable
private mouseLeave() {
  if (this.IE) {
        this.document.getElementById('body').classList.remove('overlay-open');
  } else {
        this.window.onscroll = function() {
          // todo
        };
  }
}
private closeFilter() {
  this.filter = false;
  this.filter_title = '';
  this.changestatus.emit(this.filter);
  this.document.getElementById('body').classList.remove('modalOpen');
  this.mouseLeave();
}
private closeOverlay(): void {
  this.filterService.togglelay(false);
}
private checkTouch(): void {
  if (this.touch_screen) {
    this.document.getElementById('body').classList.add('modalOpen');
  } else {
    this.document.getElementById('body').classList.remove('modalOpen');
  }
}
@HostListener('window:resize', ['$event'])
public onResize(event) {
  let b, value, h, h1;
  if (this.filter) {
    setTimeout(() => {
      this.checkTouch();
      if (this.window.innerWidth <= 480) {
        b = this.val;
        value = 35 + 10 + 15 + (2 * b) + 21.6 + 15;
        h = this.window.innerHeight;
        if (h === NaN) {
          h = this.innerwindowheight;
          h1 = h - value;
        } else {
          h1 = h - value;
        }
        this.containerheight = h1;
      } else {
        b = this.val;
        value = 42 + 10 + 15 + (2 * b) + 24 + 15;
        h = this.window.innerHeight;
        if (h === NaN) {
          h = this.innerwindowheight;
          h1 = h - value;
        } else {
          h1 = h - value;
        }
        this.containerheight = h1;
      }
    }, 0);
  }
}
  public ngOnDestroy(): void {
    this.filter_ser.unsubscribe();
    this.livetv.unsubscribe();
    $('#check').css('cursor', '');
    $('.button_size').css('pointerEvents', '');
  }
 }
