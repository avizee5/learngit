import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FilterComponent } from '../filter/filter.component';
import { SelectedOptionsComponent } from '../filter/selected-options/selected-options.component';
import { SharedModule } from '../shared.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule
  ],
  declarations: [FilterComponent, SelectedOptionsComponent],
  exports: [FilterComponent, SelectedOptionsComponent]
})
export class FilterModule { }
