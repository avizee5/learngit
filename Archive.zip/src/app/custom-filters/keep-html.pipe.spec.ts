import { KeepHtmlPipe } from './keep-html.pipe';
import { DomSanitizer } from '@angular/platform-browser';

describe('KeepHtmlPipe', () => {
  it('create an instance', () => {
    const pipe = new KeepHtmlPipe(this.DomSanitizer);
    expect(pipe).toBeTruthy();
  });
});
