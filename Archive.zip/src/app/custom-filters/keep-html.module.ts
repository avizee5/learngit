import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { KeepHtmlPipe } from './keep-html.pipe';

@NgModule({
 exports: [KeepHtmlPipe],
  imports: [CommonModule],
  declarations: [KeepHtmlPipe]
})
export class KeepHtmlModule {}
