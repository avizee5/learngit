import { Component, ViewChild, ElementRef, OnInit, OnDestroy, Inject, PLATFORM_ID, HostListener, Renderer2} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import * as $ from 'jquery';
import * as api from '../data/subscription/api/api';
import * as SettingsApi from '../data/user/api/api';
import {FavoritesApi, RemindersApi, UserApi, WatchlistApi } from '../data/user/api/api';
import { Headers, Http , RequestOptions, Response} from '@angular/http';
import { UserProfileService } from './services/user-profile.service';
import { FilterService } from './services/filter.service';
import { VideoService } from './services/video.service';
import { SettingsService } from './services/settings.service';
import { UserApiService } from './services/user-api.service';
import {environment} from '../environments/environment';
import {Router, ActivatedRoute, NavigationEnd} from '@angular/router';
import { GoogleAnalyticsService } from './services/google-analytics.service';
import { HeaderservicesService } from './services/headerservices.service';
import * as subscriptionApi from '../data/subscription/api/api';
import { SubscriptionService } from './services/subscription.service';
import { CarouselComponent } from './carousel/carousel.component';
import 'rxjs/add/operator/timeout';
import {Event, NavigationStart, NavigationError } from '@angular/router';
import { SeoService } from './services/seo.service';
import {  NetworkService  } from './services/network.service';
import { Location, DOCUMENT } from '@angular/common';
import { Subject } from 'rxjs/Subject';
import {CommonService} from './services/common.service';
import { UseractionapiService } from './services/useractionapi.service';
/* Angular Universal */
import { isPlatformBrowser } from '@angular/common';
import { BehaviorSubject, Observable } from 'rxjs';

// declare const jwplayer: any;
// declare const conviva: any;
declare const Conviva: any;
declare const FB: any;
declare let window: any;
declare const qg;
declare let googletag;
declare let _comscore;
declare let AFBanner;
declare let _cc13772;

const mygp_UTM_source = 'mygp';
const mygpBD = {
  'country_code': 'BD',
  'country': 'Bangladesh',
  'state': 'Dhaka Division',
  'state_code': 'C'
};

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.less']
})
export class AppComponent implements OnInit, OnDestroy {
  private enableBlockingCalls = false;
  private gdprTravel = false;
  private ngUnsubscribe = new Subject<any>();
  public showPopup = false;
  public timeout = false;
  public CompleteconfigValue$: Observable<boolean>;
  public CompleteconfigValue: any;
  public selectCountryPopup: any = false;
  private title = 'app';
  private footer;
  private reminderList = [];
  private castVisible = false;
  private params: any = '';
  private data: any ;
  private defaultLanguages: Array<any> = [];
  private localStoragevalue: any = [];
  private postFlag = false;
  private userSettings: any;
  private userToken: any;
  private languageContent: any;
  private errorMessage: any;
  private response: any;
  private state: any;
  private country: any;
  private countryCode: any;
  private stateCode: any;
  private displayLang: any;
  private contentLang: any;
  private default_settings: any;
  private getToken: any;
  public userType: object;
  public observableUserType: any;
  private pageName: any;
  private repeatGaFlag = true;
  private planapicall: any;
  private countryapicall: any;
  private subscriptionApiCall: any;
  private activePlans: any;
  private planAssetType: Array<any> = []; // store assest type from active plan
  private delete_settings: any;
  private configValue: any;
  private configData: any;
  public accessible = true;
  private processComplete;
  private processComplete2;
  private qgDisplayLang: any = [];
  private qgContentLang: any = [];
  private storeqgDisplayLang: any;
  private storeqgContentLang: any;
  private display_language: any;
  private content_language: any;
  private default: any;
  private assetbasepath: any;
  private googletagAvailable: any;
  private localStorage: any;
  private window: any;
  private document: any;
  private navigator: any;
  private completeLanguageValue: any;
  private mode: any;
  private currency: any;
  private id: any;
  private pack: any;
  private amount: any;
  private promo: any;
  private start: any;
  private end: any;
  private activePlan: any;
  private receivedId: Array <any> = [];
  private previousUrl: any;
  private tokenValue: any;
  private packDuration: any;
  private packStart: any;
  private months: any = ['Jan', 'Feb', 'Mar',
  'Apr', 'May', 'Jun', 'Jul',
  'Aug', 'Sep', 'Oct',
  'Nov', 'Dec'
  ];
  private sendPaySuucess: any;
  private timestampTime: any;
  private timestampDateTime: any;
  private sendFailDetails: any;
  public cookiesCheck = false;
  public displayDialog = false;
  private isostring: any;
  private gdprValue: any;
  private gdprCheck: any;
  private imagePreload: any;
  private mobile: any = false;
  private setFlag: any = false;
  private country_parameters: any;
  private showCountry: any;
  public launchOfferShow: any;
  public signInReminder: any;
  public subscribeReminder: any;
  private blockSubscriptionCall: any = true;
  private subscriptionSuccess: any;
  private showAppsflyer = true;
  private banner: any;
  private cleartimer: any;
 private languageNew: any;
  private tokenNew: any;
  private countryNewConfig: any;
  private clientID: any;
  private marketingValue: any;
   private qgraph: any;
   public cookiesCheck1 = false;
   public freeEpisodeScreen = false;
   public isMobile: any;
   public landingPage = false;
   public callpopup: any;
public weyyak = false;
private weyyakObject: any;
public contentLangValue: any;
public contentString: any;
public contentID: any;
public contentView: any;
private displayLangstored: any;
public content_day0_check: any;
public contentDaychecknode: any = false;
public allLanguages: any = true;
public completeDisplayLanguageId: any;
public storeqgContentLangGuest: any;
public storeqgDisplayLangGuest: any;
private storeSettingsData: any;
public settingsComplete: any;
public getparams: any
  public changedCountryValue: any;
public urlBckBtnFlagVal: any;
public campaignValue = 'homepage';
public partnerApp = false;
public campaign = 'msite';
public robinumber = false;
private nowtv: any = false;
private oneTrust: any;
public myGPapp = false;
  constructor(@Inject(PLATFORM_ID) private platformId: Object,
    private userapiService: UserApiService,
    private headerservicesService: HeaderservicesService,
    private router: Router,
    private videoService: VideoService,
    private settingsService: SettingsService,
    private translate: TranslateService ,
    private filterService: FilterService,
    private http: Http,
    private userProfileService: UserProfileService,
    private gtm: GoogleAnalyticsService,
    private sub: SubscriptionService,
    private seoservice: SeoService,
    private location: Location,
    private commonService: CommonService,
    private networkService: NetworkService,
    private userAction: UseractionapiService,
    public elementref: ElementRef,
    private renderer2: Renderer2,
    private route: ActivatedRoute,
    @Inject(DOCUMENT) private doc: Document) {
      this.observableUserType = new BehaviorSubject<object>(this.userType);
      this.oneTrust = !window.OnetrustActiveGroups ? false : true;
      // console.log(window.OnetrustActiveGroups, 'OnetrustActiveGroups');
      if (this.oneTrust) {
        let scope;
        scope = this;
        window.OptanonWrapper = function() {
          console.log('onetrust - window - OptanonWrapper - called');
          scope.OptanonWrapper();
        };
      }
    }

    public OptanonWrapper(): any {
      // console.log('onetrust - app - OptanonWrapper - called');
      window.Optanon.InsertScript('//apv-launcher.minute.ly/api/v3/launcher/MIN-80900.js', 'head', function minutelyCallback() {
        // console.log('onetrust - minutelyCallback');
      }, null, 'C0003');


      if (environment.isPeer5) {
        window.Optanon.InsertScript('https://api.peer5.com/peer5.js?id=8kfkdw0cgb13dxqswj6t', 'head', function peer5_callback() {
          // console.log('onetrust - peer5_callback');
        }, null, 'C0001');
        window.Optanon.InsertScript('https://api.peer5.com/peer5.generic.plugin.js', 'head', function peer5_callback1() {
          // console.log('onetrust - peer5_callback1');
        }, null, 'C0001');
      }

      window.Optanon.InsertScript('https://tags.bkrtx.com/js/bk-coretag.js', 'head', function Bluekai() {
        // console.log('onetrust - Bluekai');
        }, null, 'C0004');

      window.Optanon.InsertScript('https://apis.google.com/js/platform.js', 'head', function platformJS() {
        // console.log('onetrust - platform JS');
        }, null, 'C0004');

    }

  private checkNowTvRegister(): any {
    let windowLocation;
    windowLocation = window.location;
    if (windowLocation.origin === environment.nowTvbasePath && (windowLocation.pathname === '/register' || windowLocation.pathname === '/myaccount/subscription' || windowLocation.pathname === '/subscribe')) {
      return true;
    } else {
      return false;
    }
  }

  private setMyGPgaParams(): any {
    let gaObj, osType;
    osType = this.navigator.userAgent.match(/iPhone|iPad|iPod/i) ? 'iOS' : this.navigator.userAgent.match(/Android/i) ? 'Android' : 'Web';
    gaObj = {
      'appType': osType,
      'sourceApp': 'mygp'
    };
    this.gtm.logEvent(gaObj);
  }

  public ngOnInit(): any {
    this.commonService.setNowTvDomain();
    this.getparams = this.getUrlVars();
    if (this.getparams && this.getparams['PlatformName'] && this.getparams['PlatformName'] === 'NowTV') {
      this.nowtv = true;
      this.commonService.setNowTvDetails(true, this.getparams);
      if (this.getparams['hexToken'] && (localStorage.getItem('nowTvHextoken') !== this.getparams['hexToken'] || !localStorage.getItem('token'))) {
        localStorage.setItem('nowTvHextoken', this.getparams['hexToken']);
        this.userAction.getUserFromHexToken(this.getparams['hexToken']).subscribe(response => {
          // console.log(response, response.user.token);
          if (((response || {}).user || {}).token) {
            localStorage.setItem('token', response.user.token);
            localStorage.setItem('login', 'Email');
            this.window.location.reload();
          } else {
            localStorage.removeItem('nowTvHextoken');
          }
        }, err => {
          localStorage.removeItem('nowTvHextoken');
          // console.log(err);
        });
      }
    } else if (this.checkNowTvRegister()) {
      this.nowtv = true;
      this.commonService.setNowTvDetails(true, '');
    } else {
      this.nowtv = false;
      this.commonService.setNowTvDetails(false, '');
    }
    if (this.getparams && this.getparams['web'] && this.getparams['web'] === 'true' && this.getparams['utm_medium'] && this.getparams['utm_medium'].includes('appinapp')) {
          this.partnerApp = false;
    } else {
      this.partnerApp = true;
    }
    if (localStorage.getItem('robiToken')) {
      this.settingsService.setMsisdnData();
    }

     this.seoservice.storeStaticSeoMetaData(null);
    $('body').css('pointer-events', 'none');

    this.headerservicesService.upgradeCardPopup.subscribe(value => {
      this.freeEpisodeScreen  = value;

    });
    // this.robinumber = this.headerservicesService.getrobiuserChanges();
    // console.log(this.robinumber,'this.robinumber')
    if (!localStorage.getItem('previousRoute')) {
      localStorage.setItem('previousRoute', '/');
    }
    // start
    this.translate.use('z5-strings-en');

  if (this.getParameterFromURL('af_c')) {
    this.campaignValue = this.getParameterFromURL('af_c');
  } else if (this.getParameterFromURL('utm_campaign')) {
    this.campaignValue = this.getParameterFromURL('utm_campaign');
  }

  if (this.getParameterFromURL('af_pid')) {
    this.campaign = this.getParameterFromURL('af_pid');
  } else if (this.getParameterFromURL('utm_source')) {
    this.campaign = this.getParameterFromURL('utm_source');
  }
    this.headerservicesService.robiuserValue.subscribe(value => {
      this.robinumber = value;
    });
    this.headerservicesService.contentLanguageValue.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.contentLangValue = value.boolean;
      this.contentString = value.string;
      this.contentID = value.id;
      this.contentView = value.view;
    });
    this.filterService.configfooter.subscribe(value => {
      this.footer = value;
    });
    this.videoService.alertCastState.subscribe(value => {
      this.castVisible = value;
    });
    this.headerservicesService.cookiescreenValue.subscribe(value => {
      this.showPopup = value;
    });
  this.headerservicesService.launchOfferValue.subscribe(value => {      // when profileView is open and clicked outside update varible
         this.launchOfferShow = value;
       });
     this.headerservicesService.signInReminder.subscribe(value => {
       this.signInReminder = value;
     });
     this.headerservicesService.subscribeReminder.subscribe(value => {
       this.subscribeReminder = value;
     });
     this.headerservicesService.rTRMValue.subscribe(value => {
       this.headerservicesService.calculateEvent();
     });
    this.headerservicesService.blockeventsValue.subscribe(value => {
     this.qgraph = this.headerservicesService.getRemarketing();
    });
    this.qgraph = this.headerservicesService.getRemarketing();
    this.sub.planApiSuccess.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.subscriptionSuccess = value;
      if (this.subscriptionSuccess !== undefined && this.blockSubscriptionCall === true) {
        // this.subscriptionSuccess = true
        // this.blockSubscriptionCall = false
        this.processComplete2 = true;
        let postRoute, previousUrl;
        postRoute = this.localStorage.getItem('postSubscriptionRoute');
        previousUrl = this.localStorage.getItem('previousRoute');
        if (previousUrl !== '/paymentsuccess' && previousUrl !== '/myaccount/subscription' && postRoute) {
          this.localStorage.removeItem('postSubscriptionRoute');
          this.commonService.playerRoute(postRoute, 'login');
        }
      }

      this.sub.getPendingPackList('launch'); // call pending pack api
      this.observableUserType.next(this.sub.getUserType('launch'));
      // this.userType = this.sub.getUserType('launch');
    });

    if (isPlatformBrowser(this.platformId)) {
      this.localStorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
    this.setMyGPgaParams();
    if (!localStorage.getItem('token')) {
      this.myGPapp = true;
      // location.href = environment.unidentifiedUser;
    }

  // //hola spark call
    // if (environment.spark) {
    //   this.holaSpark()
    // }

  // platformJS
  if (!this.oneTrust) {
    this.loadScript('https://apis.google.com/js/platform.js', function() {
      // console.log("Platform js is loaded");
    });
  }

  this.loadScript('https://www.gstatic.com/cv/js/sender/v1/cast_sender.js?loadCastFramework=1', function() {
      // console.log("Cast Sender library is loaded");
  });

 // this.loadScript('https://z.moatads.com/jwplayerplugin0938452/moatplugin.js', function() {
 //      // console.log("MoatPlugin js is loaded  ");
 //  });

  // Bluekai
  if (!this.oneTrust) {
    this.loadScript('https://tags.bkrtx.com/js/bk-coretag.js', function() {
        // console.log("Core Tag js is loaded  ");
    });
  }

    let me;
    me = this;
    // condition added not to load facebook SDK for annoymous user.
    // if ('ID' in this.localStorage && this.localStorage.getItem('ID') != null) {
      this.loadScript('https://connect.facebook.net/en_US/sdk.js', function () {
       // console.log("FaceBook sdk is loaded  ");

        me.cleartimer = setTimeout(() => {
          me.gtm.FacebookInitialization();
        //  console.log("Facebook Initialization Successfully");
        }, 0);
      });
    // }

    //    window['dataLayer']=window['dataLayer']||[];
    //    window['dataLayer'].push({'gtm.start':new Date().getTime(),event:'gtm.js'});

    // this.loadScript("https://www.googletagmanager.com/gtm.js?id=GTM-WCDR87M", function () {
    //  // console.log("google tag manager sdk is loaded  ");
    // });

    // minute_ly
    if (!this.oneTrust) {
      this.loadScript('//apv-launcher.minute.ly/api/v3/launcher/MIN-80900.js', function () {
          //    console.log("loaded streaming tag plugin jw player");
      });
    }

    // hola spark call
    if (environment.spark) {
      this.holaSpark();
    }
// commented for kaltura
    // this.loadScript('https://dl.conviva.com/zee/jwplayer/stable/conviva.js', function () {
    //  // console.log("Conviva is loaded");
    // });

    // this.loadScript('https://sb.scorecardresearch.com/c2/plugins/streamingtag_plugin_jwplayer.js', function () {
    //     //    console.log("loaded streaming tag plugin jw player");
    // });
// commented for kaltura

    // conviva core js sdk for kaltura player
    this.loadScript('assets/js/conviva/conviva-core-js-sdk-4.0.15.js', function () {
      console.log('loaded conviva core sdk');
    });
    this.loadScript('assets/js/conviva/conviva-html5native-impl-4.0.4.js', function () {
      console.log('loaded conviva html5native sdk');
    });
    
    // peer5
    if (environment.isPeer5 && !this.oneTrust) {
      this.loadScript('https://api.peer5.com/peer5.js?id=8kfkdw0cgb13dxqswj6t', function () {
      //  console.log("api.peer5.com is loaded");
      });
      this.loadScript('https://api.peer5.com/peer5.generic.plugin.js', function () {
      //  console.log("Peer5 generic plugin js is loaded");
      });
    }

    /*

     (function(w,d,s,l,i){

        w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});

        var f=d.getElementsByTagName(s)[0],
  j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
  'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);


  })(window,document,'script','dataLayer','GTM-WCDR87M');

  */

  // window['GoogleAnalyticsObject'] = 'ga';
  // window['ga']=window['ga']||function(){
  //   (window['ga'].q=window['ga'].q||[]).push(arguments)
  // };
  //  window['ga'].l= new Date();


    //     this.loadScript("https://www.google-analytics.com/analytics.js",function(){
    //     //console.log("google analytics  sdk is loaded  ");
    // });


  /*
  (function(i,s,o,g,r,a,m){

  i['GoogleAnalyticsObject']=r;
  i[r]=i[r]||function(){
    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();


    a=s.createElement(o),
    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)

    })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

    */

    /*
    this.loadScript("https://player.h-cdn.com/loader.js?customer=zeetv",function(){

        // console.log("holaSpark is loaded  ");

    });*/

     // Making Config api call in parallel with Country api to initialize route faster

     this.assetbasepath = environment.assetsBasePath;
     this.configValue = environment.configFile;
     // jwplayer.key = environment.jwplayerkey;

     // this.getValues();

      if (this.enableBlockingCalls) {
      this.countryCode = 'IN';
      this.state = 'Karnataka';
      this.seoservice.setCountryCode(this.countryCode);
      this.settingsService.setCountry(this.countryCode);
      let obj;
      obj = {
            'country': 'India',
            'country_code': 'IN',
            'state': 'Karnataka'
       };
      this.settingsService.setCountryValue(obj);
      this.callpopup = true;
      this.localStorage.setItem('country_code', this.countryCode);
      this.localStorage.setItem('ContentLang', 'en,hi');
      this.localStorage.setItem('display_language', 'en');
      this.localStorage.setItem('UserContentLanguage', 'en,hi');
      this.localStorage.setItem('UserDisplayLanguage', 'en');
      this.translate.use('z5-strings-en');
      this.getValues();
      } else {
      const h = new api.CountryApi(this.http, null, null);
      // h.v1GetCountryStage().timeout(3000).takeUntil(this.ngUnsubscribe).subscribe(valueTotal => { // for stage api
      //   this.countryCode = valueTotal.country.country_code;
      //   this.state = valueTotal.country.state;
      //   this.country = valueTotal.country.country;
      //   this.settingsService.setCountry(valueTotal.country.country_code);
      //   this.settingsService.setCountryValue(valueTotal.country);
      //   this.seoservice.setCountryCode(valueTotal.country.country_code);
      //   this.localStorage.setItem('country_code', this.countryCode);
      //   this.languageNew = valueTotal.lang;
      //   this.tokenNew = valueTotal.platform_token;
      //   this.countryNewConfig = valueTotal.countryconf;
      //   this.callTokenfunction();
      //    this.getValues();
      //   this.callCountryfunction();
      // }, error => {
      this.changedCountryValue = this.localStorage.getItem('changedCountryValue');
      this.changedCountryValue = JSON.parse(this.changedCountryValue);
      h.v1GetCountryXtra().timeout(500).takeUntil(this.ngUnsubscribe).subscribe(valuextra => { // for xtra api
        // if (this.changedCountryValue) {
        //   valuextra.country_code = this.changedCountryValue[0].country_code;
        //   valuextra.country = this.changedCountryValue[0].country;
        //   valuextra.state = this.changedCountryValue[0].state;
        //   valuextra.state_code = this.changedCountryValue[0].state_code;
        // }
        valuextra.country_code = mygpBD.country_code;
        valuextra.country = mygpBD.country;
        valuextra.state = mygpBD.state;
        valuextra.state_code = mygpBD.state_code;
        this.countryCode = valuextra.country_code;
        this.stateCode = valuextra.state_code;
        this.state = valuextra.state;
        this.country = valuextra.country;
        this.settingsService.setCountry(valuextra.country_code);
        this.settingsService.setCountryValue(valuextra);
        this.seoservice.setCountryCode(valuextra.country_code);
        this.callpopup = true;
        this.localStorage.setItem('country_code', this.countryCode);
        this.localStorage.setItem('state_code', this.stateCode);
        this.getValues();
        this.callTokenfunction();
        this.callCountryfunction();
      }, err => {
        h.v1CountryGet().timeout(environment.timeOut).takeUntil(this.ngUnsubscribe).subscribe(value => { // for b2b api
          // if (this.changedCountryValue) {
          //   value.country_code = this.changedCountryValue[0].country_code;
          //   value.country = this.changedCountryValue[0].country;
          //   value.state = this.changedCountryValue[0].state;
          //   value.state_code = this.changedCountryValue[0].state_code;
          // }
          value.country_code = mygpBD.country_code;
          value.country = mygpBD.country;
          value.state = mygpBD.state;
          value.state_code = mygpBD.state_code;
          this.countryCode = value.country_code;
          this.stateCode = value.state_code;
          this.state = value.state;
          this.country = value.country;
          this.settingsService.setCountry(value.country_code);
          this.settingsService.setCountryValue(value);
          this.seoservice.setCountryCode(value.country_code);
          this.callpopup = true;
          this.localStorage.setItem('country_code', this.countryCode);
          this.localStorage.setItem('state_code', this.stateCode);
          this.getValues();
          this.callTokenfunction();
          this.callCountryfunction();
        }, err1 => {
          this.countryCode = null;
          this.seoservice.setCountryCode('error');
          if (err1.name = 'TimeoutError') {
            this.timeout = true;
            this.accessible = true;
          } else {
            this.accessible = false;
            this.timeout = false;
          }
          this.gtm.sendErrorEvent('api', err);
          $('#loaderPage').css('display', 'none');
        });
      });
      // })
    }
    // end

    // this.CompleteconfigValue$ = this.settingsService.CountryPopup;
    this.CompleteconfigValue = this.settingsService.SelectCountryPopupValue.subscribe(data => {
        this.selectCountryPopup = data;
    })


    // if (isPlatformBrowser(this.platformId)) {
    //   this.localStorage = localStorage;
    //   this.window = window;
    //   this.document = document;
    //   this.navigator = navigator;
    // }
    let dialogcheck;
    dialogcheck = this.localStorage.getItem('dialogCheck');
    if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i) || this.window.innerWidth <= 480) {
      this.mobile = true;
    }
    this.subscriptionSuccess = this.sub.getPlanApiSucess();
    if ( dialogcheck === 'true') {
      // this.qgrapheventWith('source', { 'partner': 'dialog_hbb', 'country': this.settingsService.getCountry()})
      this.headerservicesService.DialogCheckValueChange(true);
      this.displayDialog = true;
    }

    this.footer = true;
    this.userToken = this.localStorage.getItem('token');
    if (this.userToken) {
      this.deviceAuthCodeExists();
    }
    this.processComplete2 = (this.userToken && this.userToken !== null) ? false : true;
    // conviva.integrate({key: environment.convivakey});
    this.headerservicesService.PersonalizeReloadChange(false);
    $('#loaderPage').css('display', 'block');
    this.filterService.setSort(0);
    /*Updating Metatags*/
    this.router.events.takeUntil(this.ngUnsubscribe).takeUntil(this.ngUnsubscribe).subscribe( (event: any) => {
      if (event instanceof NavigationEnd) {
        this.videoService.setPlayerLaunchStatus(event);
        if ((event.url === '/') || (event.url === '/news') || (event.url === '/premium') || (event.url === '/zee5originals') || (event.url === '/zee5originals/all') || (event.url === '/movies') || (event.url === '/movies/all') || (event.url === '/videos') || (event.url === '/videos/all') || (event.url === '/tvshows') || (event.url === '/tvshows/all') || (event.url.match(/collections/g))) {
          this.landingPage = true;
        } else {
          this.landingPage = false;
        }
        /* GA events to be fired for Subscriptions*/
        // this.lotamecall(event);
          if ((event.url.toLowerCase().indexOf('paymentfailure') >= 0) || (event.url.toLowerCase().indexOf('paymentcancelled') >= 0)) {
            this.localStorage.setItem('urlbacbtn', 'false');// Set Payment url back button flag valule to "false" 
              //  setTimeout(() => {
	    this.payFailGA();
	    //  },100)
          } 
          if(event.url === '/paymentsuccess'){
            this.localStorage.setItem('urlbacbtn', 'false');// Set Payment url back button flag valule to "false"
          }
          // remove flag for GA
          if (event.url.toLowerCase().indexOf('paymentsuccess') < 0) {
            this.localStorage.removeItem('gaEventFired');
          }
         if (event.url !== '/cookiePolicy') {
             this.cookiesCheck1 = true;
        } else {
            this.cookiesCheck1 = false;
          }
          // //console.log(this.cookiesCheck1,'check')
        this.seoservice.updateStaticMeta(event);
        // Show loading indicator
       // //console.log(event,'event')
       this.checkBackbtnPress(); // call Payment Url back botton function
       if (this.userToken && this.localStorage.getItem('deviceAuthenticateCode') && (event.url !== '/language')) {
        let deviceAuthCode;
        deviceAuthCode = this.localStorage.getItem('deviceAuthenticateCode');
        let currentState;
        currentState = 3;
        this.userAction.checkForDeviceAuthCode(currentState);
        this.router.navigate(['/device'], { queryParams: { device_code: deviceAuthCode } });
        this.localStorage.removeItem('deviceAuthenticateCode');
      // } else if (this.userToken && this.localStorage.getItem('nowTV') && this.localStorage.getItem('nowTV') === 'true' && (event.url !== '/signin')) {
      //   this.router.navigate(['/device']);
      //   this.localStorage.removeItem('nowTV');
      }
      }
      // Minutely call
    });

    /*Organisational Schema*/

      window.addEventListener('minute_impression', function(event) {
        // SEND DATA TO GA
       // console.log('minute_ly', event.detail);
        scope.gtm.minutelyGA(event.detail.target_url);
      });

    const json_ld = {
     '@context': 'https://schema.org',
     '@type': 'Organization',
     'image': '//z5staging.zeecdn.com/assets/common/Splash.jpg',
     'url': 'https://www.zee5.com',
     'email': 'support.in@zee5.com',
     'name' : 'ZEE5',
     'telephone': '1800 3000 3300',
     'sameAs': [environment.followOnFb, environment.followOnTw, environment.followOnGp, environment.downloadAndroid , environment.downloadIos]
    };

    let script;
    script = this.document.createElement('script');
    script.type = 'application/ld+json';
    script.innerHTML = JSON.stringify(json_ld);
    this.document.getElementsByTagName('head')[0].appendChild(script);

   $(this.window).on('unload', function() {
     $(this.window).scrollTop(0);
   });

   /*Listening on attributes from localstorage and reloading if null*/
   this.window.addEventListener('storage', function(e) {
   if (e.key === 'token'  || e.key === 'UserDisplayLanguage' || e.key === null) {
      if (e.newValue === null) {
        location.reload(true);
      }
      if ((e.newValue !== e.oldValue) && !(this.navigator.userAgent.match(/trident/i))) {
        location.reload(true);
      }
    }
  });

  /*Setting of Guest-user token in Localstorage*/
  if (this.localStorage.getItem('guestToken') === null || this.localStorage.getItem('guestToken') === 'null') {
    let object;
    object = {
     'user':
        {
          'apikey': '6BAE650FFC9A3CAA61CE54D',
          'aid': '91955485578'
        }
    };
    this.settingsService.convivaGuestId(JSON.stringify(object)).takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.localStorage.setItem('guestToken', JSON.parse(value._body).guest_user);
    }, error => {
      this.gtm.sendErrorEvent('api' , error);
    });
  }

    /*Preloading images*/

    /*
    this.assetbasepath + 'assets/sign_in/fb_icon.png',
      this.assetbasepath + 'assets/sign_in/twitter_icon.png',
      this.assetbasepath + 'assets/sign_in/google_icon.png',
      this.assetbasepath + 'assets/sign_in/banner_img1.png',
      this.assetbasepath + 'assets/sign_in/banner_img2.png',
      this.assetbasepath + 'assets/sign_in/banner_img3.png',
      this.assetbasepath + 'assets/sign_in/banner_img4.png',
      this.assetbasepath + 'assets/sign_in/mail_icon.png',
      this.assetbasepath + 'assets/sign_in/mobile_icon.png'
    */
    this.imagePreload = [
      this.assetbasepath + 'assets/default/internet_connection_lost.png'
    ];
    // this.preload();

    let z, b, a, s, scope;
    scope = this;
    z = this.localStorage.getItem('display_language');
    b = this.localStorage.getItem('ContentLang');
    a = this.localStorage.getItem('autoPlay');
    s = this.localStorage.getItem('streamingQuality');

    /*Google Ads Event listener*/
    this.window.addEventListener('load', function() {
      // scope.googletagAvailable = this.localStorage.getItem('googletag')
      scope.googletagAvailable = scope.commonService.checkGoogleTag();
      if (scope.googletagAvailable === 'true') {
        googletag = googletag || {};
        googletag.cmd = googletag.cmd || [];
        if (googletag.apiReady) {
          googletag.pubads().addEventListener('slotRenderEnded', function(event) {
            if (event.isEmpty) {
                if (event.slot.L === scope.commonService.getcarouselDesktopTag()) {
                  // todo
              } else {
                scope.gtm.sendErrorEvent('advertisement', 'The given slot is empty ' + event.slot.L);
              }
            }
          });
        }}
      }, false);

    /*URL check for Bot*/
    let botPattern, re, userAgent;
    botPattern = '(googlebot\/|Googlebot-Mobile|Googlebot-Image|Google favicon\
                  |Mediapartners-Google|bingbot|slurp|java|wget|curl|Commons-HttpClient\
                  |Python-urllib|libwww|httpunit|nutch|phpcrawl|msnbot|jyxobot|FAST-WebCrawler\
                  |FAST Enterprise Crawler|biglotron|teoma|convera|seekbot|gigablast|exabot|ngbot\
                  |ia_archiver|GingerCrawler|webmon |httrack|webcrawler|grub.org|UsineNouvelleCrawler\
                  |antibot|netresearchserver|speedy|fluffy|bibnum.bnf|findlink|msrbot|panscient|yacybot\
                  |AISearchBot|IOI|ips-agent|tagoobot|MJ12bot|dotbot|woriobot|yanga|buzzbot|mlbot\
                  |yandexbot|purebot|Linguee Bot|Voyager|CyberPatrol|voilabot|baiduspider\
                  |citeseerxbot|spbot|twengabot|postrank|turnitinbot|scribdbot|page2rss\
                  |sitebot|linkdex|Adidxbot|blekkobot|ezooms|dotbot|Mail.RU_Bot|discobot\
                  |heritrix|findthatfile|europarchive.org|NerdByNature.Bot|sistrix crawler\
                  |ahrefsbot|Aboundex|domaincrawler|wbsearchbot|summify|ccbot|edisterbot|seznambot\
                  |ec2linkfinder|gslfbot|aihitbot|intelium_bot|facebookexternalhit|yeti\
                  |RetrevoPageAnalyzer|lb-spider|sogou|lssbot|careerbot|wotbox|wocbot|ichiro\
                  |DuckDuckBot|lssrocketcrawler|drupact|webcompanycrawler|acoonbot|openindexspider\
                  |gnam gnam spider|web-archive-net.com.bot|backlinkcrawler|coccoc\
                  |integromedb|content crawler spider|toplistbot|seokicks-robot|it2media-domain-crawler\
                  |ip-web-crawler.com|siteexplorer.info|elisabot|proximic|changedetection|blexbot\
                  |arabot|WeSEE:Search|niki-bot|CrystalSemanticsBot|rogerbot|360Spider|psbot\
                  |InterfaxScanBot|Lipperhey SEO Service|CC Metadata Scaper|g00g1e.net\
                  |GrapeshotCrawler|urlappendbot|brainobot|fr-crawler|binlar|SimpleCrawler\
                  |Livelapbot|Twitterbot|cXensebot|smtbot|bnf.fr_bot|A6-Indexer|ADmantX|Facebot\
                  |Twitterbot|OrangeBot|memorybot|AdvBot|MegaIndex|SemanticScholarBot|ltx71|nerdybot\
                  |xovibot|BUbiNG|Qwantify|archive.org_bot|Applebot|TweetmemeBot|crawler4j|findxbot\
                  |SemrushBot|yoozBot|lipperhey|y!j-asr|Domain Re-Animator Bot|AddThis)';
    re = new RegExp(botPattern, 'i');
    userAgent = navigator.userAgent;
      if (re.test(userAgent)) {
        // //console.log('the user agent is a crawler!');
        let arr;
      localStorage.removeItem('display_language');
        arr = ['en', 'kn', 'te', 'ta', 'mr', 'hr', 'hi', 'gu' , 'pa' , 'ml' , 'bn', 'th', 'id', 'ms', 'de', 'ru'];
        for ( let language = 0; language < arr.length; language++) {
          if (arr[language] === window.location.pathname.split('/')[1] ) {
              localStorage.setItem('display_language', arr[language]);
              this.translate.use('z5-strings-' + arr[language]);
            break;
          }
        }
        this.settingsComplete = true; // settings blocking call
      } else  if (this.userToken) {
      const params = 'bearer ' + this.userToken;
      this.window.scrollTo(0, 0);
      const config = {
        apiKey: params,
        username: ' ',
        password: ' ',
        accessToken: ' ',
        withCredentials: true
      };
      /*Get User Reminders*/
      const remindersRequest = new RemindersApi(this.http, null, config);
      remindersRequest.v1RemindersGet().takeUntil(this.ngUnsubscribe).subscribe(value => {
        this.userProfileService.fullReminderData(value);
      },
      err => {
        // todo
      });

      /*Get User Details*/
      const userDetails = new UserApi(this.http, null, config);
      // let dataHextoken;
      // dataHextoken = {'identifier': 'web'};
      // userDetails.v1PostHextoken(dataHextoken).takeUntil(this.ngUnsubscribe).subscribe(hextoken_data => {
      //    this.localStorage.setItem('hextoken', hextoken_data.json().token);
      // });

      userDetails.v1UserGet().takeUntil(this.ngUnsubscribe).subscribe(value => {
        this.data = value;
        if (this.data.mobile !== undefined && this.data.email === undefined) {
          this.localStorage.setItem('login', 'Mobile');
        }
        // updating localstorage details with logged IN user for MyGP as token is added directly
        if (!this.localStorage.getItem('ID')) {
          this.localStorage.setItem('ID', this.data.id);
          this.localStorage.setItem('googletag', 'false');
          this.localStorage.setItem('login', 'Mobile');
        }
        // updating localstorage details with logged IN user for MyGP as token is added directly
        this.headerservicesService.addChanges(false);
        this.userProfileService.setUserdata(this.data);
        this.sub.setUserdata(this.data);
        this.gtm.myGPloginEvent();
      },
      err => {
          if (err.status !== 0) {
          this.localStorage.removeItem('token');
          this.localStorage.removeItem('login');
          this.myGPapp = true;
          // location.href = environment.unidentifiedUser;
          // this.window.location.reload(true);
          this.headerservicesService.addChanges(true);
        }
      });

      /*Get User Settings*/
      let disp;
      disp = this.localStorage.getItem('display_language');
      this.translate.use('z5-strings-' + disp);

      this.userSettings = new SettingsApi.SettingsApi(this.http, null, config);

      this.userSettings.v1SettingsGet().takeUntil(this.ngUnsubscribe).subscribe(response => {
        this.sub.storeSettings(response);
        if (this.userToken) {
          this.storeSettingsData = response;
          this.settingsComplete = true; // settings blocking call
          this.localStorage.setItem('registered', 'true')
        }

        this.getcontentDaychecknode(response);
        if (response.length <= 3) {
          if ( this.localStorage.getItem('ContentLang').length === 0) {
            this.localStorage.setItem('ContentLang', 'en,hi');
          }
          if (this.localStorage.getItem('display_language')) {
          this.translate.use('z5-strings-' + this.localStorage.getItem('display_language'));
          this.userapiService.getParameter('update', 'display_language', this.localStorage.getItem('display_language'));
          } else {
          this.translate.use('z5-strings-en');
          this.userapiService.getParameter('update', 'display_language', 'en');
          }

          this.default_settings =
          [
          {key: 'display_language', value: this.localStorage.getItem('display_language') },
          {key: 'content_language', value: this.localStorage.getItem('ContentLang') },
          {key: 'streaming_quality', value: 'Auto' },
          {key: 'auto_play', value: 'true' },
          {key: 'download_quality', value: '0' },
          {key: 'recent_search', value: '' },
          {key: 'stream_over_wifi', value: 'false' },
          {key: 'download_over_wifi', value: 'false' },
          ];

          for (let i = 0; i < 8 ; i++) {
            const defaultsettings = {
              'key': this.default_settings[i].key,
              'value': this.default_settings[i].value
            };

            this.userSettings.v1SettingsPost(defaultsettings).takeUntil(this.ngUnsubscribe).subscribe(responsePost => {
              if ( i === (this.default_settings.length - 1)) {
                this.postFlag = true;
                this.settingsCall();
              }
            },
            err => {
              // todo
            });
          }
        }
        if ( response.length > 3 || this.postFlag === true) {
          for (let i = 0; i < response.length; i++) {
            if ( response[i].key === 'content_language') {
              this.localStorage.setItem('UserContentLanguage', response[i].value);
              if (response[i].value && response[i].value.startsWith('[')) {
                response[i].value = this.localStorage.getItem('ContentLang');
              }
              this.content_language = response[i].value;
              this.userapiService.getParameter('update', response[i].key, response[i].value);
            }
            if ( response[i].key === 'display_language') {
              if (response[i].value && response[i].value.length > 1) {
                this.localStorage.setItem('UserDisplayLanguage', response[i].value);
                let disp_login;
                disp_login = response[i].value;
                this.translate.getTranslation('z5-strings-' + response[i].value).takeUntil(this.ngUnsubscribe).subscribe(value => {
                  this.translate.use('z5-strings-' + disp_login); },
                  err => {
                  this.translate.use('z5-strings-en');
                });
                this.userapiService.getParameter('update', response[i].key, response[i].value);
                this.display_language = response[i].value;
              } else {
                this.translate.use('z5-strings-en');
                this.userapiService.getParameter('update', 'display_language', 'en');
              }
            }
            if ( response[i].key === 'download_quality') {
              this.userapiService.getParameter('update', response[i].key, response[i].value);
            }
            if ( response[i].key === 'auto_play') {
              this.userapiService.getParameter('update', response[i].key, response[i].value);
              this.videoService.autoPlay = response[i].value === 'true';
            }
            if ( response[i].key === 'streaming_quality') {
              this.userapiService.getParameter('update', response[i].key, response[i].value);
              this.videoService.bitRate = response[i].value;
            }
            if ( response[i].key === 'stream_over_wifi') {
              this.userapiService.getParameter('update', response[i].key, response[i].value);
            }
            if ( response[i].key === 'download_over_wifi') {
              this.userapiService.getParameter('update', response[i].key, response[i].value);
            }
            if ( response[i].key === 'parental_control') {
              this.localStorage.setItem('parentalControl', 'true');
              this.userapiService.setAgeRating(response[i].value);
            }
            if (response[i].key === 'popups')  {
              let popupsValue, sendRTMValue;
              popupsValue = JSON.parse(response[i].value);
              sendRTMValue =  popupsValue[0].RTRM;
              if (sendRTMValue !== 'na') {
                this.headerservicesService.RTRMTrack(sendRTMValue);  // true/false string for logined user
              } else {
                this.localStorage.removeItem('BlockRTRM');
              }
            }
            if ( response[i].key === 'gdpr_policy') {
              if (!(response[i].value[0] === '{')) {
                this.gdprValue = JSON.parse(response[i].value);
                this.settingsService.setSettingsValue(this.gdprValue);
                 this.showCountry = this.localStorage.getItem('country_code');
                 let show, hide;
                show = this.localStorage.getItem('cookies');
                hide = this.localStorage.getItem('marketing');
                 this.gdprCheck = true;
                  let track;
                if (this.countryCode) {
                   track = this.userapiService.checkGdprTravel(this.gdprValue, this.countryCode);
                  if (track === true) {
                    this.localStorage.setItem('gdpr', true);  // to display gdpr screen after close
                  }
                }
                if (!(show === null || undefined) && !(hide === null || undefined) ) {  // to display gdpr screen if cookies thr
                    this.showPopup  = track;
                    localStorage.removeItem('gdpr');
                  } else if ((this.showCountry !== 'CA') && (this.showCountry !== 'DE') && (this.showCountry !== 'SG')) {
                    this.showPopup  = track;
                    localStorage.removeItem('gdpr');
                  } else if (!(show === null || undefined)) {
                  if (hide === null || undefined) {
                    if (this.showCountry === 'CA') {
                       this.showPopup  = track;
                      localStorage.removeItem('gdpr');
                    }
                }
              }
            } else {
               this.userSettings.v1SettingsDelete('gdpr_policy', this.userToken).subscribe(responseput => {
                this.gdprCheck = false;
               });
            }
        }
      }
          if (!this.gdprCheck) {
            this.showCountry = this.localStorage.getItem('country_code');
            let show, hide;
             show = this.localStorage.getItem('cookies');
               hide = this.localStorage.getItem('marketing');
            this.localStorage.setItem('gdpr', true);
            if (!(show === null || undefined) && !(hide === null || undefined) ) {
              this.showPopup = true;
              localStorage.removeItem('gdpr');
            } else if ((this.showCountry !== 'CA') && (this.showCountry !== 'DE') && (this.showCountry !== 'SG')) {
                this.showPopup  = true;
                localStorage.removeItem('gdpr');
            } else if (!(show === null || undefined)) {
              if (hide === null || undefined) {
                if (this.showCountry === 'CA') {
                   this.showPopup  = true;
                  localStorage.removeItem('gdpr');
                }
              }
            }
          }
          this.gdprTravel = this.showPopup ? false : true;
          this.settingsService.gdprTraveller(this.gdprTravel);
        }
      }, err => {
        this.settingsComplete = true; // settings blocking call

        this.translate.use('z5-strings-en');
        this.userapiService.getParameter('update', 'display_language', 'en');
        this.videoService.autoPlay = true;
        this.userapiService.getParameter('update', 'auto_play', 'true');
        this.videoService.bitRate = 'Auto';
        this.userapiService.getParameter('update', 'streaming_quality', 'Auto');
        this.userapiService.getParameter('update', 'content_language', this.localStorage.getItem('ContentLang'));
        this.gtm.sendErrorEvent('api', err);
      });
    } else {
        this.settingsComplete = true; // settings blocking call

       this.localStorage.removeItem('hextoken');
      if (z === null || b === null ||  z === 'null') {
        this.localStorage.setItem( 'ContentLang', this.localStoragevalue);
        } else {

          let arr, flag = false;
          arr = ['en', 'kn', 'te', 'ta', 'mr', 'hr', 'hi', 'gu' , 'pa' , 'ml' , 'bn', 'th', 'id', 'ms', 'de', 'ru'];
          for ( let a1 = 0; a1 < arr.length; a1++) {
            if (arr[a1] === window.location.pathname.split('/')[1] ) {
              this.localStorage.setItem('display_language', arr[a1]);
              this.translate.use('z5-strings-' + arr[a1]);
              flag = true;
              break;
            }
          }
          if (flag === false) {
              this.localStorage.setItem('display_language', 'en');
              this.translate.use('z5-strings-en');
          }
/*          this.translate.getTranslation('z5-strings-' + z.toLowerCase()).subscribe(value => {
           this.translate.use('z5-strings-' + z.toLowerCase())
           }, err => {
            this.translate.use('z5-strings-en')
          });*/
        }
        if (a === null) {
          this.localStorage.setItem( 'autoPlay', 'true');
        }
        if (s === null) {
          this.localStorage.setItem( 'streamingQuality', 'Auto');
        }
        this.videoService.autoPlay = this.localStorage.getItem('autoPlay') === 'true';
        this.videoService.bitRate = this.localStorage.getItem('streamingQuality');
      }

      $(this.document).ready(function() {
        scope.window.scrollTo(0, 0);
      });

      /*
      this.cleartimer = setTimeout(() => {
      this.gtm.FacebookInitialization();
      }, 500);
      */

      if ( this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
           this.isMobile = true;
      } else {
          this.isMobile = false;
      }
      this.checkForHomeSchema();
      // this.appsflyerIntialize(); // removed for MyGP
  }
  public checkForHomeSchema() {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        const url = event.urlAfterRedirects;
         url !== '/' ? (this.doc.getElementById('homePageOnly') ? this.renderer2.removeChild(this.doc.body, this.doc.getElementById('homePageOnly')) : this.renderer2.destroy()) : this.renderer2.destroy();
      }
    });
  }
  private weyyakfunction(configData): any {
    let localcountyCode, weyyakCountries;
    localcountyCode = this.localStorage.getItem('country_code');
    weyyakCountries = configData && configData.weyyak && configData.weyyak.countries ? configData.weyyak.countries : [];
    for (let i = 0; i < weyyakCountries.length; i++) {
      let enableflag;
      if (configData.weyyak && configData.weyyak.enable !== null && configData.weyyak.enable !== undefined ) {
        enableflag = configData.weyyak.enable;
        if (enableflag) {
              if (localcountyCode === weyyakCountries[i]) {
                this.weyyak = enableflag;
                break;
              } else {
                this.weyyak = false;
              }
        } else {
            if (localcountyCode === weyyakCountries[i]) {
              this.weyyak = enableflag;
              break;
            } else {
              this.weyyak = true;
            }
        }
      } else {
          this.weyyak = false;
      }
    }
    if (weyyakCountries.length === 0) {
      this.weyyak = configData.weyyak && configData.weyyak.enable !== null && configData.weyyak.enable !== undefined ? configData.weyyak.enable : false;
    }
    let weyyakUrl;
    weyyakUrl = configData && configData.weyyak_url ? configData.weyyak_url : '/';
      this.weyyakObject = {
              'value': this.weyyak,
              'url': weyyakUrl
           };
    this.headerservicesService.weyyakChanges(this.weyyakObject);
  }
  @HostListener('window:resize', ['$event'])
  public resizeEventListener(event) {
          if ( this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
           this.isMobile = true;
          } else {
          this.isMobile = false;
        }
      }
  private appsflyerIntialize() {
     setTimeout(() => {

      if (this.banner) {
        delete this.banner;
        this.banner = null;
      }
      this.banner = new AFBanner();
       let settings;
       settings = {
     // banner settings
     title: 'Enjoy ZEE5 better with our app',
     subtitle: 'Tap to Download',
     app_icon: '/assets/common/Zee5-Logo_v02.jpg',
     call_to_action: 'Install',
     show_only_mobile: true,
    // attribution settings
         media_source: this.campaign,
         campaign: this.campaignValue,
/*     ad: 'banner_ad',
     ad_id: 'banner_ad_id',
     site_id: 'banner_site_id',
     sub1: 'banner_sub1',*/
     // routing settings
     onelink_id: 'RlQq',
     subdomain: 'zee5',
     mobile_deeplink: 'https://www.zee5.com/',
     alt: 'logo'
  };
  this.banner.init('my-banner', settings);
}, 0);
  }

  private preload() {
    let images;
    images = [];
    for (let index = 0; index < this.imagePreload.length; index++) {
      images[index] = new Image();
      images[index].src = this.imagePreload[index];
    }
  }

  private closePopup(): void {
    $('#networkPopup').css('display', 'none');
    this.networkService.unLockScroll();
  }

  /*Changing content language depending on location*/
  private ConfigFileValue(value): any {
    this.settingsService.getLanguages(value);
    this.processComplete = true;

    if (this.enableBlockingCalls) {
      this.processComplete = true;
      this.processComplete2 = true;
    }


    this.callLangfunction(value);
    if (this.userToken) {
      this.sub.getServerTimeActive(true, false); // call my plan api
      let configFile, configLang;
      configFile = this.configData;
      configLang = configFile.languages;
      this.qgDisplayLang = [];
      this.storeqgDisplayLang = this.display_language ? this.display_language.split(',') : '';

      let j, k;
      if ( this.storeqgDisplayLang.length > 0) {
        for (k = 0; k < configLang.length ; k++) {
          for (j = 0; j < this.storeqgDisplayLang.length  ; j++) {
            if ( configLang[k].id === this.storeqgDisplayLang[j]) {
              this.qgDisplayLang.push(configLang[k].name);
            }
        }
      }
        this.qgraphevent('identify', {'display_language': this.qgDisplayLang.join(), 'country': this.settingsService.getCountry(), 'state': this.stateCode });

      }

      this.qgContentLang = [];
      this.storeqgContentLang = this.content_language ? this.content_language.split(',') : '';
      if (this.storeqgContentLang.length > 0) {
        for (k = 0; k < configLang.length ; k++) {
          for (j = 0; j < this.storeqgContentLang.length  ; j++) {
              if ( configLang[k].id === this.storeqgContentLang[j]) {
                this.qgContentLang.push(configLang[k].name);
              }
          }
        }
        this.qgraphevent('identify', {'content_language': this.qgContentLang.join(), 'country': this.settingsService.getCountry(), 'state': this.stateCode});
      }
    } else {

      let configFile, configLang;
      configFile = this.configData;
      configLang = configFile.languages;
       this.storeqgDisplayLangGuest = localStorage.getItem('display_language') ? localStorage.getItem('display_language').split(',') : '';

      let j, k;
      if ( this.storeqgDisplayLangGuest.length > 0) {
        for (k = 0; k < configLang.length ; k++) {
          for (j = 0; j < this.storeqgDisplayLangGuest.length  ; j++) {
            if ( configLang[k].id === this.storeqgDisplayLangGuest[j]) {
              this.qgDisplayLang.push(configLang[k].name);
            }
        }
      }
        // this.qgraphevent('identify', {'display_language': this.qgDisplayLang.join(), 'country': this.settingsService.getCountry(),'state': this.stateCode });

      }

      this.qgContentLang = [];
      this.storeqgContentLangGuest = localStorage.getItem('ContentLang') ? localStorage.getItem('ContentLang').split(',') : '';
      if (this.storeqgContentLangGuest.length > 0) {
        for (k = 0; k < configLang.length ; k++) {
          for (j = 0; j < this.storeqgContentLangGuest.length  ; j++) {
              if ( configLang[k].id === this.storeqgContentLangGuest[j]) {
                this.qgContentLang.push(configLang[k].name);
              }
          }
        }
        // this.qgraphevent('identify', {'content_language': this.qgContentLang.join(), 'country': this.settingsService.getCountry(),'state': this.stateCode});
      }

      this.sub.getServerTimeActive(true, true); // won't call my plan api
      if (this.localStorage.getItem('registered') === null) {
        this.qgraphevent('identify', {'country': this.countryCode, 'state': this.stateCode, 'display_language': this.qgDisplayLang.join(), 'content_language': this.qgContentLang.join(), 'user_type': 'guest', 'payment_type': '','user_id': localStorage.getItem('token') ? localStorage.getItem('ID'): localStorage.getItem('guestToken')});
      }
  }
  }
private callLangfunction(value): any {
    let z, b , lang;
    z = this.localStorage.getItem('display_language');
    b = this.localStorage.getItem('ContentLang');
    lang = [];
    this.languageContent = [];
    if (this.languageNew !== undefined ) {
           let completeDisplayLanguage = this.languageNew.display;

      if (completeDisplayLanguage !== undefined) {
        for ( let i = 0 ; i < completeDisplayLanguage.length ; i++) {
          if ( completeDisplayLanguage[i].is_default === '1') {
            this.default = completeDisplayLanguage[i].l_code;
          }
        }
      } else {
        completeDisplayLanguage = value.fallback_languages.display;
        let a;
        for ( a = 0 ; a < completeDisplayLanguage.length ; a++) {
          if ( completeDisplayLanguage[a].is_default === '1') {
            this.default = completeDisplayLanguage[a].l_code;
          }
        }
      }

      if (z === null || z === 'null') {
      let arr;
        arr = ['en', 'kn', 'te', 'ta', 'mr', 'bh', 'hi', 'gu' , 'pa' , 'ml' , 'bn', 'th', 'id', 'ms', 'de', 'ru'];
        let language;
        for ( language in arr) {
          if (arr[language] === window.location.pathname.split('/')[1] ) {
            this.localStorage.setItem( 'display_language', arr[language]);
            this.translate.use('z5-strings-' + arr[language]);
            break;
          } else {
            if ( this.default !== undefined && this.default !== 'en') {
              this.localStorage.setItem( 'display_language', this.default);
              this.translate.use('z5-strings-' + this.default);
              this.window.location.reload(true);
            } else if ( language === (arr.length - 1 ).toString()) {
              this.localStorage.setItem( 'display_language', 'en');
              this.translate.use('z5-strings-en');
            }
          }
        }
      }

      this.completeLanguageValue = this.languageNew.content;
      this.settingsService.setContentLanguages(this.completeLanguageValue);
      this.settingsService.getNonEditableLang(this.completeLanguageValue);
      this.settingsService.setApiStatus(true);


      if (this.completeLanguageValue === undefined || this.completeLanguageValue.length === 0) {
        this.completeLanguageValue = value.fallback_languages.content;
      }
        // this.dayzeroCheck();

      for ( let g = 0 ; g < this.completeLanguageValue.length ; g++) {
        lang.push(this.completeLanguageValue[g].l_code);
      }
      if (this.localStorage.getItem('ContentLang') === null || localStorage.getItem('ContentLang').length === 0) {
          this.languageContent = lang;
          this.defaultLanguages.push(this.languageContent);

          let str;
          str = this.defaultLanguages.join();
          this.localStoragevalue.push(str);
          this.localStorage.setItem( 'ContentLang', this.localStoragevalue);
          this.localStorage.setItem('UserContentLanguage', this.localStoragevalue);
      }
        this.checkAllLangs(this.completeLanguageValue.length);

          this.checkRoute();
          // this.processComplete = true;

       if (this.userToken) {
         this.sub.callQgraph(true, this.configData);
       }
        this.dayzeroCheck();

    } else {
     let display;
     display = this.userToken ? this.localStorage.getItem('UserDisplayLanguage') : this.localStorage.getItem('display_language');
      this.http.get(environment.languagesApi + this.countryCode + '&state=' + this.stateCode + '&translation=' + display + '&version=' + 1.1 ).timeout(environment.timeOut).subscribe( valueLang => {
      let completeDisplayLanguage = valueLang.json().display;

      if (completeDisplayLanguage !== undefined) {
        for ( let i = 0 ; i < completeDisplayLanguage.length ; i++) {
          if ( completeDisplayLanguage[i].is_default === '1') {
            this.default = completeDisplayLanguage[i].l_code;
          }
        }
      } else {
        completeDisplayLanguage = value.fallback_languages.display;
        let a;
        for ( a = 0 ; a < completeDisplayLanguage.length ; a++) {
          if ( completeDisplayLanguage[a].is_default === '1') {
            this.default = completeDisplayLanguage[a].l_code;
          }
        }
      }

      if (z === null || z === 'null') {
      let arr;
        arr = ['en', 'kn', 'te', 'ta', 'mr', 'bh', 'hi', 'gu' , 'pa' , 'ml' , 'bn', 'th', 'id', 'ms', 'de', 'ru'];
        let language;
        for ( language in arr) {
          if (arr[language] === window.location.pathname.split('/')[1] ) {
            this.localStorage.setItem( 'display_language', arr[language]);
            this.translate.use('z5-strings-' + arr[language]);
            break;
          } else {
            if ( this.default !== undefined && this.default !== 'en') {
              this.localStorage.setItem( 'display_language', this.default);
              this.translate.use('z5-strings-' + this.default);
              this.window.location.reload(true);
            } else if ( language === (arr.length - 1 ).toString()) {
              this.localStorage.setItem( 'display_language', 'en');
              this.translate.use('z5-strings-en');
            }
          }
        }
      }
      this.completeLanguageValue = valueLang.json().content;
      this.completeDisplayLanguageId = valueLang.json().display;
      this.settingsService.setCompleteGetLanguages(valueLang.json());
      this.sub.callTelcoUser(this.storeSettingsData);  // check telco user from settings

      this.settingsService.setContentLanguages(this.completeLanguageValue);
      this.settingsService.setDisplayLanguages(this.completeDisplayLanguageId);
      this.settingsService.getNonEditableLang(this.completeLanguageValue);
      this.settingsService.setApiStatus(true);


      if (this.completeLanguageValue === undefined || this.completeLanguageValue.length === 0) {
        this.completeLanguageValue = value.fallback_languages.content;
      }
        // this.dayzeroCheck();

      for ( let g = 0 ; g < this.completeLanguageValue.length ; g++) {
        lang.push(this.completeLanguageValue[g].l_code);
      }
      if (this.localStorage.getItem('ContentLang') === null || localStorage.getItem('ContentLang').length === 0) {
          this.languageContent = lang;
          this.defaultLanguages.push(this.languageContent);

          let str;
          str = this.defaultLanguages.join();
          this.localStoragevalue.push(str);
          this.localStorage.setItem( 'ContentLang', this.localStoragevalue);
          this.localStorage.setItem('UserContentLanguage', this.localStoragevalue);
      }
        this.checkAllLangs(this.completeLanguageValue.length);
          this.checkRoute();
          this.processComplete = true;

       if (this.userToken) {
         this.sub.callQgraph(true, this.configData);
       }
        this.dayzeroCheck();

    },
    err => {
      this.completeLanguageValue = value.fallback_languages.content;
        // this.dayzeroCheck();
      let fallbackDisplay, langu;
      fallbackDisplay = value.fallback_languages.display;
      langu = [];
      for ( let i = 0 ; i < this.completeLanguageValue.length ; i++) {
        langu.push(this.completeLanguageValue[i].l_code);
      }

       for ( let h = 0 ; h < fallbackDisplay.length ; h++) {
        if (fallbackDisplay[h].is_default === '1') {
          this.default = fallbackDisplay[h].l_code;
        }
      }

      if (this.localStorage.getItem('ContentLang') === null || localStorage.getItem('ContentLang').length === 0) {
          this.languageContent = langu;
          this.defaultLanguages.push(this.languageContent);

          let str;
          str = this.defaultLanguages.join();
          this.localStoragevalue.push(str);
          this.localStorage.setItem( 'ContentLang', this.localStoragevalue);
          this.localStorage.setItem('UserContentLanguage', this.localStoragevalue);
      }
        this.checkAllLangs(this.completeLanguageValue.length);

      if (z === null || z === 'null') {
      let arr;
        arr = ['en', 'kn', 'te', 'ta', 'mr', 'bh', 'hi', 'gu' , 'pa' , 'ml' , 'bn', 'th', 'id', 'ms', 'de', 'ru'];
        let language;
        for ( language in arr) {
          if (arr[language] === window.location.pathname.split('/')[1] ) {
            this.localStorage.setItem( 'display_language', arr[language]);
            this.translate.use('z5-strings-' + arr[language]);
            break;
          } else {
            if ( this.default !== undefined && this.default !== 'en') {

              this.localStorage.setItem( 'display_language', this.default);
              this.translate.use('z5-strings-' + this.default);
              this.window.location.reload(true);

            } else if ( language === (arr.length - 1 ).toString()) {
              this.localStorage.setItem( 'display_language', 'en');
              this.translate.use('z5-strings-en');
            }
          }
        }
      }

      this.checkRoute();
     this.processComplete = true;
        if (this.userToken) {
       this.sub.callQgraph(true, this.configData);
      }
      this.settingsService.setApiStatus(false);
      this.dayzeroCheck();

    });
    }
}
private checkAllLangs(actualllength): any {
  let y, currentcontentLanguages, pushLang = [];
  // let countryCode;
  currentcontentLanguages = [];
  y = this.localStorage.getItem('token') ? this.localStorage.getItem('UserContentLanguage') : this.localStorage.getItem('ContentLang');
  pushLang = y.split(',');
  for ( let i = 0; i < pushLang.length; i++) {
    currentcontentLanguages.push(pushLang[i]);
  }
  if (currentcontentLanguages.length !== actualllength ) {
     this.allLanguages = false;
  }
  let paths, lan;
  paths = location.pathname.split('/').splice(1, 1);
  lan = paths[0].length === 2 ? paths[0] : 'en';
  // countryCode = this.localStorage.getItem('country_code');
   // if (countryCode === 'IN') {
     if (lan === 'en') {
       if (this.localStorage.getItem('browserLanguage') === null) {
        this.localStorage.setItem('browserLanguage', 'true');
        this.sub.firsttimeDisplayLang();
       }
     }
  // }

}
private dayzeroCheck(): any {
  let sourceapp;
  sourceapp = this.userProfileService.getSourceapp();
  if (this.localStorage.getItem('content_language_day0_check') === null && !this.localStorage.getItem('token') && this.allLanguages)  {   // guest user localValue
    this.dayZerofunction();
    this.localStorage.setItem( 'content_language_day0_check', true);
  } else if (this.localStorage.getItem('token') && (sourceapp === 'Web' || sourceapp === undefined || sourceapp === '') && !this.contentDaychecknode && this.allLanguages) {   // logined user userapi node & settings node
    this.dayZerofunction();
    this.localStorage.setItem( 'content_language_day0_check', true);
  }
}
  public  dayZerofunction(): any {
  let completeDefault, firsttimeContent, y;
  completeDefault = [];
  if (this.completeLanguageValue) {
    for ( let g = 0 ; g < this.completeLanguageValue.length ; g++) {
      if ( this.completeLanguageValue[g].is_default === '1') {
        completeDefault.push(this.completeLanguageValue[g].l_code) ;
        // console.log(completeDefault, 'is_default');
      }
    }
    y = this.localStorage.getItem('token') ? this.localStorage.getItem('UserDisplayLanguage') : this.localStorage.getItem('display_language');
    if (completeDefault.indexOf(y) < 0) {
       completeDefault.push(y);
    }
    firsttimeContent = completeDefault.join();
    // console.log(firsttimeContent, 'firsttimeContent');
    this.localStorage.setItem( 'ContentLang', firsttimeContent);
    this.localStorage.setItem('UserContentLanguage', firsttimeContent);
    if (this.userToken) {
      this.userapiService.getParameter('put', 'content_language', firsttimeContent);
      this.contentsettingsPut();
    }
  }
}
 public contentsettingsPut(): any {
      const params = 'bearer ' + this.userToken;
      const config = {
        apiKey: params,
        username: ' ',
        password: ' ',
        accessToken: ' ',
        withCredentials: true
      };
    this.userSettings = new SettingsApi.SettingsApi(this.http, null, config);
    const contentsettings = {
      'key': 'content_language_day0_check',
      'value': 'true'
    };
    this.userSettings.v1SettingsPost(contentsettings).takeUntil(this.ngUnsubscribe).subscribe(responsePost => {
    // todo
    },
    err => {
      // todo
    });
  }
  public getcontentDaychecknode(settingsValue): any {
    if (settingsValue) {
      for (let i = 0; i < settingsValue.length; i++) {
        if ( settingsValue[i].key === 'content_language_day0_check') {
          // alert('content_language_day0_check')
          this.contentDaychecknode = true;
        }
      }
    }
  }
private callTokenfunction(): any {
 if (this.tokenNew !== undefined) {
  this.localStorage.setItem( 'xacesstoken', this.tokenNew.token);
 } else {
     this.userAction.gettoken().subscribe( value1 => {
      let gwapi_token;
      gwapi_token = value1.json();
      this.localStorage.setItem( 'xacesstoken', gwapi_token.token);
      // if (this.configData) {
      //   this.checkHE(this.configData);
      // }
    });
 }
}
 /*Checking language from URL and localStorage, if unmatched do a reload*/
 private checkRoute(): void {
   let paths, lan;
   paths = location.pathname.split('/').splice(1, 1);
   lan = paths[0].length === 2 ? paths[0] : 'en';
    let displaylan;
    if (this.userToken) {
        displaylan = (this.localStorage.getItem('UserDisplayLanguage') !== null) ? this.localStorage.getItem('UserDisplayLanguage') : this.localStorage.getItem('display_language');
        displaylan = (displaylan !== null) ? displaylan : 'en';
        if (this.localStorage.getItem('UserDisplayLanguage') === null && this.localStorage.getItem('display_language')) {
          this.localStorage.setItem('UserDisplayLanguage', displaylan);
        }
    } else {
        displaylan = (this.localStorage.getItem('display_language') !== null) ? this.localStorage.getItem('display_language') : 'en';
        if (this.localStorage.getItem('display_language') === null) {
          this.localStorage.setItem('display_language', displaylan);
        }
    }
     let code;
     // let intCountries = environment.cat2_countries;
     // for (let i = 0; i < intCountries.length; i++) {
     //    if ( intCountries[i] === this.countryCode.toLowerCase()) {
          code = (this.countryCode !== null) ? (displaylan + '-' + this.countryCode.toLowerCase()) : displaylan;
     //      break;
     //    } else {
     //      code = (this.countryCode !== null) ? (displaylan + '-' + 'in') : displaylan;
     //    }
     // }
     this.document.getElementsByTagName('html')[0].setAttribute('lang', code);

     if (lan !== displaylan) {
      let route, query;
      if(window.location.search){
        query = window.location.search;
      }
     
      if (lan === 'en') {
        route =  '/' + displaylan + this.window.location.pathname;
        if(query){
          this.window.location.href =  route + query;
        }else{
          this.window.location.href =  route;
        }
      } else {
        route = displaylan === 'en' ? this.window.location.pathname.slice(3) : '/' + displaylan + this.window.location.pathname.slice(3);
         if(query){
          this.window.location.href =  route + query;
        }else{
          this.window.location.href =  route;
        }
      }
    }
 }

 /*Config File, CountryList API, Carousel API*/
  private getValues(): any {
    let disp;
    disp = this.userToken ? localStorage.getItem('UserDisplayLanguage') : localStorage.getItem('display_language');
    if (disp === null || disp === 'null') {
      disp = 'en';
    }
        this.getAds();

   /* Config File */
  this.settingsService.getConfig(this.configValue).takeUntil(this.ngUnsubscribe).subscribe( value => { this.configData = value;
    this.configData = value;
    // if (localStorage.getItem('xacesstoken')) {
    //   this.checkHE(value);
    // }
    // this.checkHE(value)
    this.ConfigFileValue(value);
    this.settingsService.configListen(value);
    this.weyyakfunction(value);
    this.sub.callQgraph(true, value);
    if (localStorage.getItem('country_code') === 'IN') {
        this.adoric();
    }

    let data = this.configData && this.configData.music_menu ? this.configData.music_menu : undefined;
    if (data) {
      this.musicNodecalculation(data);
    }
     $('body').css('pointer-events', '');
  },
  error => {
    this.errorMessage = error;
    this.settingsService.getConfig('../assets/json/config.json').takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.configData = value;
      this.ConfigFileValue(value);
      this.settingsService.configListen(value);
      this.weyyakfunction(value);
    let data = this.configData && this.configData.music_menu ? this.configData.music_menu : undefined;
    if (data) {
      this.musicNodecalculation(data);
    }
    if (localStorage.getItem('country_code') === 'IN') {
      this.adoric();
    }
       $('body').css('pointer-events', '');
    }, err => {
      // todo
       $('body').css('pointer-events', '');
    });
  });

  // /* Country List setting */
  // this.settingsService.getCountryListValue(environment.CountryListApi + disp).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe( value => {
  //   this.settingsService.setCountryListValue(value); },
  //   error => {
  //     let ar;
  //     ar = [];
  //     this.settingsService.setCountryListValue(ar);
  // });



  }
  private musicNodecalculation(musicData): any {
    if (this.countryCode !=="IN" ) {
      let displang,contentlang;
      displang = this.userToken ? localStorage.getItem('UserDisplayLanguage') : localStorage.getItem('display_language');
      contentlang = this.userToken ? localStorage.getItem('UserContentLanguage') : localStorage.getItem('ContentLang'); 
      for (let i = 0; i < musicData.length; i++) {
      // if (musicData[i].c_code.indexOf(this.countryCode) >= 0 ) {
          if (musicData[i].lang === displang) {
           this.settingsService.considerMusicnode(true);
            if (contentlang.indexOf(musicData[i].lang) >= 0) {
              let datatoPass = {
                'value':true,
                'lang':musicData[i].content_lang_append
              }
             this.settingsService.passcontentLang(datatoPass)
            } else {
              let datatoPass = {
               'value':false,
               'lang':musicData[i].content_lang_append
              }
              this.settingsService.passcontentLang(datatoPass)
            }
            break;
          } else if (i === musicData.length - 1) {
            this.settingsService.considerMusicnode(false);
          }
          // if ((musicData[i].lang === displang) && (contentlang.indexOf(musicData[i].lang) >= 0) ) {
          //  let datatoPass = {
          //    'value':true,
          //    'lang':musicData[i].content_lang_append
          //  }
          //  this.settingsService.passcontentLang(datatoPass)
          // }else {
          //   let datatoPass = {
          //    'value':false,
          //    'lang':musicData[i].content_lang_append
          //   }
          //  this.settingsService.passcontentLang(datatoPass)
          // }
      }
    }
  }
  private getAds() {
    let url, platformName;
    if (this.isMobile === true) {
      platformName = 'mobile_web';
    } else {
      platformName = 'desktop_web';
    }
    if (this.stateCode) {
      url = environment.adBasePath + '?state=' + this.stateCode + '&country=' + this.countryCode + '&platform_name=' + platformName + '&utm_source=' + mygp_UTM_source;
    } else {
      url = environment.adBasePath + '?country=' + this.countryCode + '&platform_name=' + platformName + '&utm_source=' + mygp_UTM_source;
    }

  this.commonService.getAdsApiData(url).subscribe(value => {
    this.commonService.setAdsValue(value);
  });
}
private callCountryfunction() {

  /*Country Details for a specific country*/
  // if (localStorage.getItem('ccode')) {
  //  // this.processComplete2 = true;
  //       let qappid;
  //   qappid = '//cdn.qgr.ph/qgraph.' + JSON.parse(localStorage.getItem('ccode'))[0].qgraphAppID + '.js';
  //       !function(q, g, r, a, p, h, js) {
  //         if (q.qg) {return; }
  //         js = q.qg = function() {
  //           js.callmethod ? js.callmethod.call(js, arguments) : js.queue.push(arguments);
  //         };
  //         js.queue = [];
  //         p = g.createElement(r); p.async = !0; p.src = a; h = g.getElementsByTagName(r)[0];
  //         h.parentNode.insertBefore(p, h);
  //       }(window, document, 'script', qappid);
  // }
  if (this.countryNewConfig !== undefined ) {
   this.country_parameters = this.countryNewConfig;
   this.settingsService.setSignUpEvents(this.countryNewConfig);
 //  this.processComplete2 = true;

    // if (!localStorage.getItem('ccode')) {
        // let qappid_loggedin;
        // qappid_loggedin = '//cdn.qgr.ph/qgraph.' + this.country_parameters[0].qgraphAppID + '.js';
        // !function(q, g, r, a, p, h, js) {
        //   if (q.qg) {return; }
        //   js = q.qg = function() {
        //     js.callmethod ? js.callmethod.call(js, arguments) : js.queue.push(arguments);
        //   };
        //   js.queue = [];
        //   p = g.createElement(r); p.async = !0; p.src = a; h = g.getElementsByTagName(r)[0];
        //   h.parentNode.insertBefore(p, h);
        // }(window, document, 'script', qappid_loggedin);
    // }
    this.settingsService.setCountryValueNew(this.country_parameters);
    if (this.country_parameters.length > 0 ) {
     if (this.country_parameters[0].menu_options.premium_menu === 'no') {
          this.headerservicesService.menuOption(false);
      }
      if (this.country_parameters[0].menu_options.app_download_links === 'no') {
        this.headerservicesService.footerOption(false);
      }
      if (this.country_parameters[0].popups) {
         this.calculateCookiepopup(this.country_parameters[0].popups);
      }
    }
  } else {
    let disp;
    disp = this.userToken ? localStorage.getItem('UserDisplayLanguage') : localStorage.getItem('display_language');
    if (disp === null || disp === 'null') {
      let arr = ['en', 'kn', 'te', 'ta', 'mr', 'hr', 'hi', 'gu' , 'pa' , 'ml' , 'bn', 'th', 'id', 'ms', 'de', 'ru'];
      for ( let language = 0; language < arr.length; language++) {
        if (window.location.pathname.split('/')[1] && arr[language] === window.location.pathname.split('/')[1] ) {
            disp = arr[language];
          break;
        }
        else{disp = 'en';}
      }
    }
   this.settingsService.setCountryListNew(environment.CountryListApi + disp).subscribe(value => {
    this.settingsService.setSignUpEvents(value);
    // this.processComplete2 = true;
  this.country_parameters = value;

   // this.processComplete2 = true;

    // if (!localStorage.getItem('ccode')) {
        // let qappid_loggedin;
        // qappid_loggedin = '//cdn.qgr.ph/qgraph.' + this.country_parameters[0].qgraphAppID + '.js';
        // let scope;
        // scope = this;
        // !function(q, g, r, a, p, h, js) {
        //   if (q.qg) {return; }
        //   js = q.qg = function() {
        //     js.callmethod ? js.callmethod.call(js, arguments) : js.queue.push(arguments);
        //   };
        //   js.queue = [];
        //   p = g.createElement(r); p.async = !0; p.src = a; h = g.getElementsByTagName(r)[0];
        //   p.setAttribute('class', 'optanon-category-C0001-C0003');
        //   p.setAttribute('type', scope.gtm.checkCookieCategoryStatus([1, 3]));
        //   h.parentNode.insertBefore(p, h);
        // }(window, document, 'script', qappid_loggedin);
    // }
    this.settingsService.setCountryValueNew(this.country_parameters);
    if (this.country_parameters.length > 0 ) {
     if (this.country_parameters[0].menu_options.premium_menu === 'no') {
          this.headerservicesService.menuOption(false);
      }
      if (this.country_parameters[0].menu_options.app_download_links === 'no') {
        this.headerservicesService.footerOption(false);
      }
      if (this.country_parameters[0].popups) {
          if (this.country_parameters[0].popups.web_cookies.popup !== null) {
            if ( this.country_parameters[0].popups.web_cookies.popup.match(/yes/gi)) {
              this.headerservicesService.footerCookies(true);
            }
          }
         this.calculateCookiepopup(this.country_parameters[0].popups);
      }
    }
  }, err => {
    let arr;
    arr = [];
    this.settingsService.setSignUpEvents(arr);
    this.settingsService.setCountryValueNew(arr);
    // this.processComplete2 = true;
    // this.blockSubscriptionCall = false;
  });

  }

  // console.log(this.sub.getUserType('launch'),"getUserType()");
  // userType = this.sub.getUserType('launch');
  // console.log({ 'country': this.settingsService.getCountry(), 'state': this.stateCode, 'user_type': userType['userType'], 'payment_type': userType['paymentType']});
  if (!localStorage.getItem('token')) {
    this.userType = this.sub.getUserType('launch');
    this.qgrapheventWith('zee5_app_launched', { 'country': this.settingsService.getCountry(), 'state': this.stateCode, 'user_type': this.userType['userType'], 'payment_type': this.userType['paymentType']});
  }
  if (this.observableUserType.value) {
    this.qgrapheventWith('zee5_app_launched', { 'country': this.settingsService.getCountry(), 'state': this.stateCode, 'user_type': this.userType['userType'], 'payment_type': this.userType['paymentType']});
  }
  else{
    this.observableUserType.subscribe(value => {
      if (value && this.setFlag == false) {
        this.userType = value;
        this.qgrapheventWith('zee5_app_launched', { 'country': this.settingsService.getCountry(), 'state': this.stateCode, 'user_type': this.userType['userType'], 'payment_type': this.userType['paymentType']});
        this.setFlag = true;
      }
    });
  }
  
}
  /*Getting User Settings after successful registration*/
  private settingsCall() {
    if (this.userToken) {
      const userBearer = 'bearer ' + this.userToken;
      const config = {
        apiKey: userBearer,
        username: ' ',
        password: ' ',
        accessToken: ' ',
        withCredentials: false
      };
      this.userSettings = new SettingsApi.SettingsApi(this.http, null, config);
      this.userSettings.v1SettingsGet().takeUntil(this.ngUnsubscribe).subscribe(response => {
        this.response = response;
        for (let i = 0; i < this.response.length; i++) {
          if ( this.response[i].key === 'content_language') {
            this.userapiService.getParameter('update', this.response[i].key, this.response[i].value);
          }
          if ( this.response[i].key === 'display_language') {
            this.userapiService.getParameter('update', this.response[i].key, this.response[i].value);
            let disp;
            disp = this.response[i].value;
            this.translate.getTranslation('z5-strings-' + this.response[i].value).subscribe(value => {
              this.translate.use('z5-strings-' + disp);
            }, err => {
              this.translate.use('z5-strings-en');
            });
           }
          if ( this.response[i].key === 'download_quality') {
            this.userapiService.getParameter('update', this.response[i].key, this.response[i].value);
          }
          if ( this.response[i].key === 'auto_play') {
            this.userapiService.getParameter('update', this.response[i].key, this.response[i].value);
          }
          if ( this.response[i].key === 'streaming_quality') {
            this.userapiService.getParameter('update', this.response[i].key, this.response[i].value);
          }
        }
      }, err => {this.gtm.sendErrorEvent('api', err); });
    }
  }

  private dateChange(value) {
    if (value) {
      let date;
      let day, monthIndex, year;
      date = new Date(value);
      day = date.getDate();
      monthIndex = date.getMonth();
      year = date.getFullYear();
      return (day + ' ' + this.months[monthIndex]  + ', ' + year) ;
    } else {
      return '';
    }
  }

  /*Subscription- GA requirements*/
  private payFailGA(): any {
    let billingInfo, transaction_type, selectedCard, actAmt, couponcode ;
    if (isPlatformBrowser(this.platformId)) {
    this.mode = this.localStorage.getItem('subMode');
    this.currency = this.localStorage.getItem('subCurr');
    this.amount = this.localStorage.getItem('subPrice');
    this.pack = this.localStorage.getItem('subPack');
    this.start = this.localStorage.getItem('subStart');
    this.end = this.localStorage.getItem('subEnd');
    actAmt = this.localStorage.getItem('subActPrice');
    billingInfo = this.localStorage.getItem('subBillingInfo');
    couponcode = this.localStorage.getItem('subPromo');
    couponcode = (couponcode && couponcode !== "" && couponcode !== undefined) ? couponcode.trim() : 'NA';
    selectedCard = JSON.parse(this.localStorage.getItem('selectedCard'));
    transaction_type = (selectedCard && selectedCard[0][0].transcation_type) ? selectedCard[0][0].transcation_type : 'NA';
     this.packDuration = this.localStorage.getItem('subDuration');
     this.clientID = this.gtm.fetchClientId();
     this.marketingValue = this.gtm.fetchMarketing();
      if (this.mode) {
    this.isostring = new Date(this.end).toISOString();
    this.tokenValue = this.gtm.fetchToken();
    let packName, countryCode, couponType;
      countryCode = this.localStorage.getItem('country_code');
      packName = this.pack + '|' + this.packDuration.trim() + '|' + countryCode + '|' + this.amount;
      couponType = this.localStorage.getItem('CouponType') ? this.localStorage.getItem('CouponType') : 'NA';
      setTimeout(() => {
        this.sendFailDetails = {
        'event': 'Transaction_Failed',
        'userCountry': this.sub.getCountryName(),
        'G_ID': this.tokenValue,
        'Client_ID': this.clientID,
        'retargeting_remarketing' : this.marketingValue,
        'Payment Mode': this.mode,
        'Currency Value': this.currency,
        'Exchange Rate': 1,
        'Transacting Currency': this.currency,
        'TranactionAmount': this.amount,
        'PackDetails': packName,
        'FailureReason' : 'NA',
        'TimeHHMMSS': this.timestampTime,
        'DateTimeStamp': this.timestampDateTime,
        'productName': packName,
        'productValidity': this.packDuration.trim(),
        'Product Country' : this.sub.getCountryName(),
        'CouponType' : couponType,
        'originalPrice': actAmt,
        'Transaction Type': transaction_type,
        'productPrice': this.amount
      };
        this.gtm.logEvent(this.sendFailDetails);
        this.pageName = 'payment failure';
        this.gtm.sendPageName(this.pageName);
        if(this.urlBckBtnFlagVal == 'false'){
          this.gtm.sendEvent();
        }
      
        this.qgrapheventWith('subscription_cancelled', { 'duration': 0, 'terminator': 'backend', 'pack_name': this.pack, 'pack_duration': this.packDuration.trim(), 'country': this.settingsService.getCountry(), 'state': this.stateCode,'user_type': this.userType['userType'], 'payment_type': this.userType['paymentType']});
        this.qgrapheventWith('subscription_failure', { 'payment mode': this.mode, 'pack_type': this.pack, 'pack_duration': this.packDuration.trim(), 'couponcode': couponcode, 'subscription_start_date': this.start, 'subscription_expiry_date': this.end, 'country': this.settingsService.getCountry(), 'state': this.stateCode });  
    }, 1000);
    }
  }
  }
  private calculateCookiepopup(popup) {
    let cookies, marketing, country_parameterscookies , country_parametersmarketing;
    country_parameterscookies = (popup.web_cookies && popup.web_cookies.popup && popup.web_cookies.popup !== null) ? popup.web_cookies.popup : '';
    country_parametersmarketing = (popup.web_remarketing && popup.web_remarketing.popup && popup.web_remarketing.popup !== null ) ? popup.web_remarketing.popup : '';
    cookies = this.localStorage.getItem('cookies');
    marketing = this.localStorage.getItem('marketing');
    if (popup.web_remarketing.block_user !== null) {
      if (popup.web_remarketing.block_user.match(/yes/gi)) {
        this.headerservicesService.BlockScreen(false);
      } else if (popup.web_remarketing.block_user.match(/no/gi)) {
        this.headerservicesService.BlockScreen(true);
      }
    }
    if (popup.web_remarketing.popup !== null) {
      if (popup.web_remarketing.popup.match(/yes/gi)) {      // to track country have remarketing r not
        this.headerservicesService.RTRMCountryTrack(true);
      } else {
        this.headerservicesService.RTRMCountryTrack(false);
      }
    }
    if (country_parameterscookies.match(/yes/gi) && country_parametersmarketing.match(/yes/gi)) {
      if ((cookies === null || cookies === undefined ) && (marketing === null || marketing === undefined)) {
        this.headerservicesService.CookiesCheckValueChange(true);  // for component active in component
        this.headerservicesService.cookieValueChange(true);       // for cookies
        this.headerservicesService.marketingChange(true);        //  for marketing
        this.headerservicesService.cookieDisplayChange(true);    // // for  cookies false hide heading and arrow
         if (this.router.url !== '/cookiePolicy') {
            this.cookiesCheck = true;
          } else {
            this.cookiesCheck = false;
          }                                     // for component active in apphtml
      } else if (cookies === null || undefined) {
        this.headerservicesService.CookiesCheckValueChange(true);
        this.headerservicesService.cookieValueChange(true);
        this.headerservicesService.marketingChange(false);
        this.headerservicesService.cookieDisplayChange(true);
        if (this.router.url !== '/cookiePolicy') {
          this.cookiesCheck = true;
        } else {
            this.cookiesCheck = false;
          }
      } else if (marketing === null || undefined) {
         this.headerservicesService.CookiesCheckValueChange(true);
         this.headerservicesService.cookieValueChange(false);
         this.headerservicesService.marketingChange(true);
         this.headerservicesService.cookieDisplayChange(false);
          if (this.router.url !== '/cookiePolicy') {
            this.cookiesCheck = true;
          } else {
            this.cookiesCheck = false;
          }
      }
    } else if (country_parameterscookies.match(/yes/gi)) {
      if (cookies === null || undefined) {
        this.headerservicesService.CookiesCheckValueChange(true);
        this.headerservicesService.cookieValueChange(true);
        this.headerservicesService.marketingChange(false);
        this.headerservicesService.cookieDisplayChange(true);
        if (this.router.url !== '/cookiePolicy') {
          this.cookiesCheck = true;
        } else {
            this.cookiesCheck = false;
          }
      }
    } else if (country_parametersmarketing.match(/yes/gi)) {
       if (marketing === null || undefined) {
        this.headerservicesService.CookiesCheckValueChange(true);
        this.headerservicesService.cookieValueChange(false); // for cookies r remarketing
        this.headerservicesService.marketingChange(true);
        this.headerservicesService.cookieDisplayChange(false);
        if (this.router.url !== '/cookiePolicy') {
          this.cookiesCheck = true;
        } else {
            this.cookiesCheck = false;
          }
      }
    } else if (country_parameterscookies.match(/no/gi) && country_parametersmarketing.match(/no/gi)) {
      // todo
    }
    if (this.userToken === null ) {  // user block condition for RTRM
        let localMarketing;
        localMarketing = this.localStorage.getItem('marketing');
        if (localMarketing !== null && localMarketing !== undefined) {
          this.headerservicesService.RTRMTrack(localMarketing);       // true/false in string
        } else {
          this.localStorage.removeItem('BlockRTRM');
        }
    }
    // //console.log('this.cookiesCheck', this.cookiesCheck);
       this.headerservicesService.calculateEvent();
  }

  public ngOnDestroy(): any {
    if (Conviva && Conviva.Analytics) {
      Conviva.Analytics.release();
    }

    this.localStorage.removeItem('campaignDetails');
    this.castVisible = false;
    clearTimeout(this.cleartimer);
    this.observableUserType.unsubscribe();
    this.CompleteconfigValue.unsubscribe();
  }
  private qgraphevent(eventname, object) {
    if (this.window.qg) {
       if (this.qgraph) {
        object.user_id = localStorage.getItem('guestToken');
      
         qg(eventname, object);
       } else {
        qg(eventname, object);
       }
    }
  }
    private qgrapheventWith(eventname, object) {
    //  console.log(object, " " + eventname + " qgraph");
    if (this.window.qg) {
      // if (this.qgraph) {
      //   delete object.country;
      //   delete object.state;
      //   qg('event', eventname, object);
      // } else {
        qg('event', eventname, object);
      // }
    }
  }
  public closeFreeepisode(event): any {
    this.freeEpisodeScreen = event;
  }



  public holaSpark() {
    (function() {
    let s;
    s = document.createElement('script'); s.src = 'https://player.h-cdn.com/loader.js?customer=zeetv'; s.type = 'text/javascript'; s.async = true; (document.head || document.body).appendChild(s); }
    ());
  }

  public loadScript(url, callback) {

    let script;
    script = document.createElement('script');
    script.type = 'text/javascript';
    script.async = true;

    /*
    if (script.readyState){  //IE
        script.onreadystatechange = function(){
            if (script.readyState == "loaded" ||
                    script.readyState == "complete"){
                script.onreadystatechange = null;
                callback();
            }
        };
    } else {  //Others
        script.onload = function(){
            callback();
        };
    }

    */

        script.onload = function() {
            callback();
        };

    script.src = url;
    document.getElementsByTagName('head')[0].appendChild(script);


  }

  public lotamecall(event) {
    if (environment.lotame) {
      _cc13772.add('int', window.location.href);
      _cc13772.bcp();
    }
  }


public adoric() {
  if (this.configData.adoric) {
  (function (a, d, o, r, i, c, u, p, w, m) {
    m = d.getElementsByTagName(o)[0],
    a[c] = a[c] || {},
    a[c].trigger = a[c].trigger || function () {
      (a[c].trigger.arg = a[c].trigger.arg || []).push(arguments);
    },
      a[c].on = a[c].on || function () {
        (a[c].on.arg = a[c].on.arg || []).push(arguments);
      },
    a[c].off = a[c].off || function () {
      (a[c].off.arg = a[c].off.arg || []).push(arguments);
    },
    w = d.createElement(o),
    w.id = i,
    w.src = r,
    w.async = 1, w.setAttribute(p, u),
    m.parentNode.insertBefore(w, m),
    w = null;
  })(window/*a*/, document/*d*/, 'script'/*o*/, 'https://45972375.adoric-om.com/adoric.js'/*r*/, 'Adoric_Script'/*i*/, 'adoric'/*c*/, '32c01e9524a754197cc7b77e5fa8c340'/*u*/, 'data-key'/*p*/);
  }
}
// checking the payment page Url back button flag value and fire the GA payment failuer events
public checkBackbtnPress(){ 
    this.urlBckBtnFlagVal = this.localStorage.getItem('urlbacbtn');
    if (this.urlBckBtnFlagVal == 'true') {
      setTimeout(() => {     
        this.payFailGA();
      },0); 
      this.localStorage.setItem('urlbacbtn', 'false');
    }
}
public getParameterFromURL(name) {
  var url = window.location.href;
  name = name.replace(/[\[\]]/g, '\\$&');
  var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
    results = regex.exec(url);
  if (!results) return null;
  if (!results[2]) return '';
  return decodeURIComponent(results[2].replace(/\+/g, ' '));
}
public deviceAuthCodeExists() {
  this.route.queryParams.subscribe(params => {
    if (params['device_code'] && this.router.url.includes('register')) {
      let authenticationCode;
      authenticationCode = params['device_code'];
     localStorage.setItem('deviceAuthenticateCode', authenticationCode);
    }
    });
}
public getUrlVars() {
  let vars, decodeURI, parts;
    vars = {};
    decodeURI = decodeURIComponent(window.location.href);
    parts = decodeURI.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m, key, value) {
        vars[key] = value;
    });
    return vars;
}

public checkHE(value) {
  if (!this.userToken && !this.nowtv) {
  // if (!this.userToken) {
      if (value && value.header_enrichment && value.header_enrichment.length > 0) {
        let enable_check, flagcheck;
        enable_check = false;
        flagcheck = false;
        for (let i = 0; i < value.header_enrichment.length; i++) {
          if (this.isMobile === true) {
            if (value.header_enrichment[i].mobile_enable === true) {
              enable_check = true;
            } else {
              enable_check = false;
            }
          } else {
            if (value.header_enrichment[i].desktop_enable === true) {
              enable_check = true;
            } else {
              enable_check = false;
            }
          }
          if (value.header_enrichment[i].country === this.countryCode && enable_check === true) {
            if (this.getparams['telcoToken']) {
                localStorage.setItem('robiToken', this.getparams['telcoToken']);
                this.robinumber = this.settingsService.setMsisdnData();
            }
            if (localStorage.getItem('HE_detect')) {
            let x: any = new Date();
            let y = JSON.parse(localStorage.getItem('HE_detect'));
            let z: any = new Date(y.timestamp);
            let diff: any;
            diff = x - z;
            // console.log(diff, 'timediff');
            if (diff > value.header_enrichment[i].detect_api_time_internal ) {
              this.userAction.HE_redirect().timeout(10000).takeUntil(this.ngUnsubscribe).subscribe(HEvalue => {
              let response;
              response = HEvalue.json();
              for (let i = 0 ; i < value.header_enrichment[i].telco_partners.length; i++) {
                if (value.header_enrichment[i].telco_partners[i].toLowerCase().includes(response.data.telco.toLowerCase())) {
                    if (response.data.redirect === 'true') {
                      let obj;
                      obj = {
                        'HE_redirect': true,
                        'timestamp': new Date()
                      };
                      // console.log(obj, 'object');
                      localStorage.setItem('HE_detect', JSON.stringify(obj));
                      location.href = environment.HE_Redirect_URL
                     // location.href = environment.shareUrl.replace('https://', 'http://') + 'HE/index.html';
                    }
                  }
                }
              }, err => {
                // to do
              });
            } else {
              // console.log('wont fire with in half hour');
            }
          } else {
            this.userAction.HE_redirect().timeout(10000).takeUntil(this.ngUnsubscribe).subscribe(HEvalue => {
              let response;
              response = HEvalue.json();
              for (let j = 0 ; j < value.header_enrichment[j].telco_partners.length; j++) {
                if (value.header_enrichment[i].telco_partners[j].toLowerCase().includes(response.data.telco.toLowerCase())) {
                    if (response.data.redirect === 'true') {
                      let obj;
                      obj = {
                        'HE_redirect': true,
                        'timestamp': new Date()
                      };
                      localStorage.setItem('HE_detect', JSON.stringify(obj));
                      // location.href = 'http://stage.zee5.com/HE/index.html';
                      //location.href = environment.shareUrl.replace('https://', 'http://') + 'HE/index.html';
                      location.href = environment.HE_Redirect_URL
                    }
                }
              }
            }, err => {
            // t do
            });
          }
          flagcheck = true;
          break;
          }
        }
        if (flagcheck === false) {
          this.headerservicesService.robiuserChanges(false);
          this.settingsService.clearMsisdnData();
          localStorage.removeItem('HE_detect');
        }
}
}
}
}