import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

import { SettingsService } from './../services/settings.service';

@Component({
  selector: 'app-country-select-popup',
  templateUrl: './country-select-popup.component.html',
  styleUrls: ['./country-select-popup.component.less']
})

export class CountrySelectPopupComponent implements OnInit, OnDestroy {
  public  allowedCountries: any = []; // list of countries from config.json
  public countryForm: FormGroup;      // Form Group for country display
  public setCountryValue: any;        // drop-down value
  public configValue: any;            // read config.json into

  constructor(
    private formBuilder: FormBuilder,
    private settingsService: SettingsService) { }

  /**
   * Get config.json file.
   * Check for dropdown values.
   * Set default drop-down values.
   */
  ngOnInit() {
    this.configValue = this.settingsService.getCompleteConfig();
    let changedCountryValue = JSON.parse(localStorage.getItem('changedCountryValue'));
    if(this.configValue && this.configValue.country_selection){
      this.allowedCountries = this.configValue.country_selection;
      let defaultSelect = 'default';
      if(changedCountryValue){
        defaultSelect = changedCountryValue[0].country_code;
      }
      this.countryForm = this.formBuilder.group({
        setCountryValue: [defaultSelect]
      })
    }
  }

  /**
   * Set popupflag (in settings.service) to false on close.
   */
  public closeSelectCountry() {
    this.settingsService.SelectCountryPopupValue.next(false);
  }

  /**
   * Remove the current selection from local-storage and reload.
   */
  public cancelSelectCountry(){
    if(localStorage.getItem('changedCountryValue')){
      localStorage.removeItem('changedCountryValue');
      location.reload();
    }
    else{
      this.closeSelectCountry();
    }
  }

  /**
   * @param setCountryValue // value from the form (current selection).
   * Filter country_selection array to get current selection details.
   * Set current selection dettails to local-storage for use in app.component and reload.
   */
  public selectCountry(setCountryValue){
    if(setCountryValue !== "" && setCountryValue !== undefined && setCountryValue !== 'default' ){
      var setvar = this.allowedCountries.filter((allowedCountry) => {
        return allowedCountry.country_code === setCountryValue;
      })
      localStorage.setItem('changedCountryValue', JSON.stringify(setvar));
      location.reload();
    }
  }

  ngOnDestroy(){

  }

}
