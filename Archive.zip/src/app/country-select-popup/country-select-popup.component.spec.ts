import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CountrySelectPopupComponent } from './country-select-popup.component';

describe('CountrySelectPopupComponent', () => {
  let component: CountrySelectPopupComponent;
  let fixture: ComponentFixture<CountrySelectPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CountrySelectPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CountrySelectPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
