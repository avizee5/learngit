import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared.module';
import { CommonViewAllComponent } from './common-view-all.component';
import { DataUnavailableModule } from '../data-unavailable/data-unavailable.module';
import { CarouselModule } from '../carousel/carousel.module';
import { HomeGridModule } from '../home-grid/home-grid.module';
import { FilterModule } from '../filter/filter.module';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { BreadCrumbModule } from '../bread-crumb/bread-crumb.module';

const routes: Routes = [
    {
        path: '',
        component: CommonViewAllComponent,
    },
];
@NgModule({
  exports: [RouterModule],
  imports: [RouterModule.forChild(routes), InfiniteScrollModule, CommonModule, SharedModule, DataUnavailableModule, CarouselModule, HomeGridModule, FilterModule, BreadCrumbModule],
  declarations: [CommonViewAllComponent]
})
export class CommonViewAllModule {
}

