import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MoviesViewAllComponent } from './movies-view-all.component';

describe('MoviesViewAllComponent', () => {
  let component: MoviesViewAllComponent;
  let fixture: ComponentFixture<MoviesViewAllComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MoviesViewAllComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MoviesViewAllComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
