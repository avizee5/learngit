import { Component, OnInit, ViewChild, OnDestroy, HostListener } from '@angular/core';
import { FilterService } from '../services/filter.service';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
// import to control carousel in your views
import { CarouselComponent } from '../carousel/carousel.component';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { Http} from '@angular/http';
import {CollectionApi} from '../../data/gwapi_catalog/api/CollectionApi';
import {MovieApi} from '../../data/catalog/api/MovieApi';
import * as $ from 'jquery';
import { Location } from '@angular/common';
import { UserProfileService } from '../services/user-profile.service';
import { environment } from '../../environments/environment';
import { RouteService } from '../services/route.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { HeaderservicesService } from '../services/headerservices.service';
import {  NetworkService  } from '../services/network.service';
import { SettingsService } from '../services/settings.service';
import {CommonService} from '../services/common.service';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { LinkService } from '../services/link.service';
import {TvShowApi} from '../../data/catalog/api/TvShowApi';
import { SubscriptionService } from '../services/subscription.service';
import { SeoService } from '../services/seo.service';
declare var googletag;
declare const qg;

@Component({
	selector: 'app-common-view-all',
	templateUrl: './common-view-all.component.html',
	styleUrls: ['./common-view-all.component.less']
})
export class CommonViewAllComponent implements OnInit, OnDestroy {
	@ViewChild(CarouselComponent) public carousel_element: CarouselComponent;
	public collectionTags: any;
	public carouselTitle: any;
	public contentAvailable: any = true;
	public color: string;
	public mode: string;
	public value: number;
	public bufferValue: number;
	public international: any;
	public indian: any;
	public trending: any;
	public new: any;
	public books: any;
	public banner: any;
	public interface: string;
	public count: number;
	public count1: number;
	public count2: number;
	public count3: number;
	public count4: number;
	public tvshows: string;
	public carousel: any;
  	public carouselCollection: any;
	public modalVideoPopup = false;
	public modalVideoDetails: any;
	public selectedFilters: any;
	public filterbar = false;
	public filter_titles: any;
	public id: any;
	public name: any;
	public watch: any;
	public sub: any;
	public urlString: any;
	public data: any;
	public tvShowCategory: any;
	public title: any;
	public view: any;
	public viewName: any;
	public languages: any;
	public category: any;
	public overlayStatus: boolean;
	public filterFlag = false;
	public current: any;
	public page = 1;
	public collectionPageNo = 1;
	public totalCollectionPages: any;
	public collectionPageSize: any = 5;
	public destroyFilter: Subscription;
	public totalPages: any;
	public all: any;
	public router: any;
	public router2: any;
	public type: any;
	public dataAvailable: any = true;
	public pageSize: any = 24;
	public pageName: any;
	public config: any;
	// public touchScreen: any = false;
	public processPending: any = false;
	public googletagAvailable: any;
	public assetBasePath = environment.assetsBasePath;
	public tagValue: any;
	// public desktopTag: any;
	// public mobileTag: any;
	public nativeTag: any;
  	public showNativeAds: any = false;
	public timer: any;
	public localstorage: any;
	public window: any;
	public document: any;
	public navigator: any;
	// public mobilediv: any;
	// public desktopdiv: any;
	public nativediv: any;
	private ngUnsubscribe = new Subject<any>();
	public mobile = false;
	public countryCode: any;
	public videosScreen: any = false;
	public tvshowsScreen: any = false;
	public moviesScreen: any = false;
	public originalsScreen: any = false;
	public collectionID: any;
	public mastDivID: any;
  	public mastHeadStyle: any;
	public mastTag: any;
	public plans: any;
	public premiumUser: any = false;
	public itemLimit: any = 7;
	public apiRetry: any = 2;
	public apiRetryCount: any = 1;
  	public showMastAds: any = false;
  	public mastHeadAds: any;
  	public mastAd: any = false;
  	public adSlot: any;
	public infiniteScrollDistance: any = 0.5;
	private countryListget: any;
  	private collectionsWeb: any;
  	private collectionsConfig: any;
  	public breadcrumb: any = '';
  	public breadcrumball: any;
  	public breadcrumbroute: any;
  	public scrollCount: any = 0;
	constructor(private subService: SubscriptionService , private linkservice: LinkService, @Inject(PLATFORM_ID) private platformId: Object, private commonService: CommonService, private settingsService: SettingsService, private userProfileService: UserProfileService, private networkService: NetworkService, private gtm: GoogleAnalyticsService, private routeservice: RouteService,
		private location: Location, private filterService: FilterService, private route: ActivatedRoute ,  private router_link: Router, private http: Http, private headerservicesService: HeaderservicesService, private seoservice: SeoService) {
		this.destroyFilter =  this.filterService.configObservable.subscribe(value => {
			this.selectedFilters = value;
			if (this.selectedFilters.length >= 0) {
				this.update();
			}
		});
		if (isPlatformBrowser(this.platformId)) {
			this.localstorage = localStorage;
			this.window = window;
			this.document = document;
			this.navigator = navigator;
		}
		this.router = router_link;
		this.router2 = this.window.location.pathname;
		this.headerservicesService.viewChange(this.router2);
		this.routeservice.setRoute(this.router2);
		this.routeservice.setLoginRoute(this.window.location.pathname);
		if (this.router.url.match(/tvshows/g)) {
			this.tvshowsScreen = true;
		} else if (this.router.url.match(/movies/g)) {
			this.moviesScreen = true;
		} else if (this.router.url.match(/videos/g)) {
			this.videosScreen = true;
		} else if (this.router.url.match(/zee5originals/g)) {
			this.originalsScreen = true;
		}
	}

	public ngOnInit() {
		this.gtm.storeWindowError();
		if (isPlatformBrowser(this.platformId)) {
			this.localstorage = localStorage;
			this.window = window;
			this.document = document;
			this.navigator = navigator;
		}
		this.countryCode = this.settingsService.getCountry();
		let network;
		network = this.networkService.getScreenStatus();
		if (network) {
			this.plans = this.subService.checkPlanApiSuccess(false);
			if (this.plans && this.plans.length > 0) {
				this.premiumUser = true;
			}
			let token;
			token = this.localstorage.getItem('token');
			if (token) {
				this.userProfileService.httpgetFavoriteData();
				this.userProfileService.httpgetWatchData();
			}
			if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
				this.mobile = true;
				this.infiniteScrollDistance = 6;
			}
			this.tagValue = this.settingsService.getCompleteConfig();
    		// this.showMastAds = this.tagValue && this.tagValue.masthead_ads && this.tagValue.masthead_ads.web && (this.premiumUser && this.tagValue.masthead_ads.web.premium_user && (this.tagValue.masthead_ads.web.premium_user[this.countryCode] === undefined ? this.tagValue.masthead_ads.web.premium_user['default'] : this.tagValue.masthead_ads.web.premium_user[this.countryCode])) || !this.premiumUser;
   //  		let userType;
		 //    userType = this.commonService.getUserType();
		 //    this.mastHeadAds = this.commonService.getAdsValue();
		 //    this.showMastAds = this.mastHeadAds && this.mastHeadAds['masthead_ads'] && this.mastHeadAds['masthead_ads'][userType] && this.mastHeadAds['masthead_ads'][userType].ads_visibility && this.mastHeadAds['masthead_ads'][userType]['screens'];
			// if (this.showMastAds) {
		 //      this.mastHeadAds = this.mastHeadAds['masthead_ads'][userType]['screens'];
		 //    }
		    this.countryListget  = this.settingsService.getCountryValueNew();
    		this.collectionsWeb = (this.countryListget && this.countryListget[0] && this.countryListget[0].collections && this.countryListget[0].collections.web_app !== null) ? this.countryListget[0].collections.web_app : undefined;
    		this.collectionsConfig = (this.tagValue && this.tagValue.collections && this.tagValue.collections.web_app !== null) ? this.tagValue.collections.web_app : undefined;

        	if (this.tvshowsScreen) {
        		this.breadcrumb = 'BREADCRUMB.SHOWS';
				this.breadcrumball = 'BREADCRUMB.All_SHOWS';
				this.breadcrumbroute = '/tvshows';
				this.updateBreadCrump('BREADCRUMB.SHOWS', 'BREADCRUMB.All_SHOWS', '/tvshows');
				this.type = 'tvshows';
				// this.collectionID = environment.tvshowPageCollectionId;
				if (this.collectionsWeb !== undefined) {
		          this.collectionID = this.collectionsWeb.tvshows;
		        } else if (this.collectionsConfig !== undefined) {
		          this.collectionID = this.collectionsConfig.tvshows;
		        } else {
		          this.collectionID = environment.tvshowPageCollectionId;
		        }
				this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'tvshows/all'  } );
				// if (!this.premiumUser && this.tagValue && this.tagValue.ads && this.tagValue.ads.web && this.tagValue.ads.web.tvshows && this.tagValue.ads.web.tvshows.desktop  && this.tagValue.ads.web.tvshows.mobile && this.tagValue.ads.web.tvshows.desktop[Object.keys(this.tagValue.ads.web.tvshows.desktop).length - 1] && this.tagValue.ads.web.tvshows.mobile[Object.keys(this.tagValue.ads.web.tvshows.mobile).length - 1]) {
				// 	this.desktopTag = this.tagValue.ads.web.tvshows.desktop;
				// 	this.mobileTag =  this.tagValue.ads.web.tvshows.mobile;
				// 	this.desktopdiv = this.desktopTag[Object.keys(this.desktopTag).length - 1].div_id + '0';
				// 	this.mobilediv = this.mobileTag[Object.keys(this.mobileTag).length - 1].div_id + '0';
				// }
				// if (this.showMastAds && this.mobile && this.tagValue.masthead_ads.web['mobile'] && this.tagValue.masthead_ads.web['mobile'].tvshows && this.tagValue.masthead_ads.web['mobile'].tvshows[0]) {
				// 	this.mastTag = this.tagValue.masthead_ads.web['mobile'].tvshows[0].ad_tag;
				// 	this.mastDivID = this.tagValue.masthead_ads.web['mobile'].tvshows[0].div_id;
				// }
        		this.commonService.qgraphevent('TVshowssection_visited', {'country': this.countryCode, 'state': this.localstorage.getItem('state_code')});
				this.pageName = 'tv show/view all';
				this.gtm.sendPageName(this.pageName);
				this.gtm.sendEvent();
				this.filter_titles = [{'code': '2', 'name': 'DETAILS.GENRE'}, {'code': '1', 'name': 'COMMON.LANGUAGE'}];

			} else if (this.moviesScreen) {
				this.breadcrumb = 'BREADCRUMB.MOVIES';
				this.breadcrumball = 'BREADCRUMB.ALL_MOVIES';
				this.breadcrumbroute = '/movies';
				this.updateBreadCrump('BREADCRUMB.MOVIES', 'BREADCRUMB.ALL_MOVIES', '/movies');
				this.type = 'movies';
				// this.collectionID = environment.moviePageCollectionId;
				if (this.collectionsWeb !== undefined) {
		          this.collectionID = this.collectionsWeb.movies;
		        } else if (this.collectionsConfig !== undefined) {
		          this.collectionID = this.collectionsConfig.movies;
		        } else {
		          this.collectionID = environment.moviePageCollectionId;
		        }
				this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'movies/all'  } );
				// if (!this.premiumUser && this.tagValue && this.tagValue.ads && this.tagValue.ads.web && this.tagValue.ads.web.movies &&  this.tagValue.ads.web.movies.desktop && this.tagValue.ads.web.movies.mobile &&  this.tagValue.ads.web.movies.desktop[Object.keys(this.tagValue.ads.web.movies.desktop).length - 1]  &&  this.tagValue.ads.web.movies.mobile[Object.keys(this.tagValue.ads.web.movies.mobile).length - 1]) {
				// 	this.desktopTag = this.tagValue.ads.web.movies.desktop;
				// 	this.mobileTag =  this.tagValue.ads.web.movies.mobile;
				// 	this.desktopdiv = this.desktopTag[Object.keys(this.desktopTag).length - 1].div_id + '0';
				// 	this.mobilediv = this.mobileTag[Object.keys(this.mobileTag).length - 1].div_id + '0';
				// }
				// if (this.showMastAds && this.mobile && this.tagValue.masthead_ads.web['mobile'] && this.tagValue.masthead_ads.web['mobile'].movies && this.tagValue.masthead_ads.web['mobile'].movies[0]) {
				// 	this.mastTag = this.tagValue.masthead_ads.web['mobile'].movies[0].ad_tag;
				// 	this.mastDivID = this.tagValue.masthead_ads.web['mobile'].movies[0].div_id;
				// }
        		this.commonService.qgraphevent('Moviessection_visited', {'country': this.countryCode, 'state': this.localstorage.getItem('state_code')});
				this.pageName = 'movies/view all';
				this.gtm.sendPageName(this.pageName);
				this.gtm.sendEvent();
				this.filter_titles = [{'code': '2', 'name': 'DETAILS.GENRE'}, {'code': '1', 'name': 'COMMON.LANGUAGE'}];

			} else if (this.videosScreen) {
				this.breadcrumb = 'BREADCRUMB.VIDEOS';
				this.breadcrumball = 'BREADCRUMB.ALL_VIDEOS';
				this.breadcrumbroute = '/videos';
				this.updateBreadCrump('BREADCRUMB.VIDEOS', 'BREADCRUMB.ALL_VIDEOS', '/videos');
				this.type = 'videos';
				// this.collectionID = environment.videoPageCollectionId;
				if (this.collectionsWeb !== undefined) {
		          this.collectionID = this.collectionsWeb.videos;
		        } else if (this.collectionsConfig !== undefined) {
		          this.collectionID = this.collectionsConfig.videos;
		        } else {
		          this.collectionID = environment.videoPageCollectionId;
		        }
				this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'videos/all'  } );
				// if (!this.premiumUser && this.tagValue && this.tagValue.ads && this.tagValue.ads.web && this.tagValue.ads.web.videos && this.tagValue.ads.web.videos.desktop  && this.tagValue.ads.web.videos.mobile && this.tagValue.ads.web.videos.desktop[Object.keys(this.tagValue.ads.web.videos.desktop).length - 1] && this.tagValue.ads.web.videos.mobile[Object.keys(this.tagValue.ads.web.videos.mobile).length - 1]) {
				// 	this.desktopTag = this.tagValue.ads.web.videos.desktop;
				// 	this.mobileTag =  this.tagValue.ads.web.videos.mobile;
				// 	this.desktopdiv = this.desktopTag[Object.keys(this.desktopTag).length - 1].div_id + '0';
				// 	this.mobilediv = this.mobileTag[Object.keys(this.mobileTag).length - 1].div_id + '0';
				// }
				// if (this.showMastAds && this.mobile && this.tagValue.masthead_ads.web['mobile'] && this.tagValue.masthead_ads.web['mobile'].videos && this.tagValue.masthead_ads.web['mobile'].videos[0]) {
				// 	this.mastTag = this.tagValue.masthead_ads.web['mobile'].videos[0].ad_tag;
				// 	this.mastDivID = this.tagValue.masthead_ads.web['mobile'].videos[0].div_id;
				// }
        		this.commonService.qgraphevent('Videossection_visted', {'country': this.countryCode, 'state': this.localstorage.getItem('state_code')});
				this.pageName = 'videos/view all';
				this.gtm.sendPageName(this.pageName);
				this.gtm.sendEvent();
				this.filter_titles = [{'code': '2', 'name': 'DETAILS.GENRE'}, {'code': '1', 'name': 'COMMON.LANGUAGE'}];
			} else if (this.originalsScreen) {
				this.breadcrumb = 'BREADCRUMB.ZEEORIGINALS';
				this.breadcrumball = 'COMMON.ALL_ORIGINALS';
				this.breadcrumbroute = '/zee5originals';
				this.updateBreadCrump('BREADCRUMB.ZEEORIGINALS', 'BREADCRUMB.All_SHOWS', '/zee5originals');
				this.type = 'zeeOriginals';
				// 'parentType': 'originalPage', 'type': 'zeeOriginals',
				// this.collectionID = environment.originalPageCollectionId;
				if (this.collectionsWeb !== undefined) {
			      this.collectionID = this.collectionsWeb.originals;
			    } else if (this.collectionsConfig !== undefined) {
			      this.collectionID = this.collectionsConfig.originals;
			    } else {
			      this.collectionID = environment.originalPageCollectionId;
			    }
				this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'zee5originals/all'  } );
        		this.commonService.qgraphevent('Originalsection_visited', {'country': this.countryCode, 'state': this.localstorage.getItem('state_code')});
				this.pageName = 'zee originals/view all';
				this.gtm.sendPageName(this.pageName);
				this.gtm.sendEvent();
				this.filter_titles = [{'code': '2', 'name': 'DETAILS.GENRE'}, {'code': '1', 'name': 'COMMON.LANGUAGE'}];
				// if (this.showMastAds && this.mobile && this.tagValue && this.tagValue.masthead_ads && this.tagValue.masthead_ads.web && this.tagValue.masthead_ads.web && this.tagValue.masthead_ads.web['mobile'] && this.tagValue.masthead_ads.web && this.tagValue.masthead_ads.web['mobile'].originals && this.tagValue.masthead_ads.web['mobile'].originals[0]) {
				// 	this.mastTag = this.tagValue.masthead_ads.web['mobile'].originals[0].ad_tag;
				// 	this.mastDivID = this.tagValue.masthead_ads.web['mobile'].originals[0].div_id;
				// }
			}
			// this.googletagAvailable = this.localstorage.getItem('googletag')
    			this.googletagAvailable = this.commonService.checkGoogleTag();
			this.view = this.originalsScreen ? 'zeeoriginals' : this.type;
			this.viewName = this.originalsScreen ? 'originals' : this.type;
			// if (this.googletagAvailable === 'true' && this.desktopTag && this.mobileTag) {
			// 	if (!this.mobile) {
			// 		this.adCreation(this.desktopTag[Object.keys(this.desktopTag).length - 1].ad_tag, this.desktopTag[Object.keys(this.desktopTag).length - 1].div_id + '0' ,  [[728, 90], [970, 90]], 'native');
			// 	} else {
			// 		this.adCreation(this.mobileTag[Object.keys(this.mobileTag).length - 1].ad_tag, this.mobileTag[Object.keys(this.mobileTag).length - 1].div_id + '0' ,  [320, 50], 'native');
			// 	}
			// }
			// if (this.mastDivID && this.mastTag) {
			// 	this.adCreation(this.mastTag, this.mastDivID, ['fluid'], 'masthead');
			// }
			this.setAd();
			$('#loaderPage').css('display', 'block');
			this.config = {
				apiKey: ' ',
				username: ' ',
				password: ' ',
				accessToken: ' ',
				withCredentials: false
			};
			// if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
			// 	this.touchScreen = true;
			// 	this.infiniteScrollDistance = 6;
			// }
			this.initialApiCall();
			let scope;
			scope = this;
			this.window.scrollTo(0, 0);
			this.count = 0;
			this.window.onpopstate = function() {
				if (scope.filterbar === true) {
					scope.filterbar = false;
				}
			};
		}
	}
	  /*--------------new ad implementation--------------------*/
private setAd(): any {
    let userType, nativeAds;
    userType = this.commonService.getUserType();
    this.mastHeadAds = this.commonService.getAdsValue();
    nativeAds = this.commonService.getAdsValue();
    this.showNativeAds = nativeAds && nativeAds['native_tags_ads'] && nativeAds['native_tags_ads'][userType] && nativeAds['native_tags_ads'][userType].ads_visibility && nativeAds['native_tags_ads'][userType]['screens'];
    this.showMastAds = this.mastHeadAds && this.mastHeadAds['masthead_ads'] && this.mastHeadAds['masthead_ads'][userType] && this.mastHeadAds['masthead_ads'][userType].ads_visibility && this.mastHeadAds['masthead_ads'][userType]['screens'];
    if (this.showMastAds) {
      this.mastHeadAds = this.mastHeadAds['masthead_ads'][userType]['screens'];
      let mast_head_ad, scope;
      scope = this;
      mast_head_ad = $.grep(this.mastHeadAds, function(e) {
          return e.screen_id === scope.type.toLowerCase();
        });
      if (mast_head_ad && mast_head_ad[0] && mast_head_ad[0].ad_data && mast_head_ad[0].ad_data[0]) {
          mast_head_ad = mast_head_ad[0].ad_data[0];
          this.mastDivID = mast_head_ad.div_id;
          this.mastTag = mast_head_ad.ad_tag;
		  this.mastHeadStyle = this.commonService.getAdType(mast_head_ad.ad_type);
      }
      if (this.mastDivID && this.mastTag) {
        this.adCreation(this.mastTag, this.mastDivID, mast_head_ad.ad_dimension, 'masthead');
      }
    }
    if (this.showNativeAds) {
      nativeAds = nativeAds['native_tags_ads'][userType]['screens'];
      let native_ad, scope;
      scope = this;
      native_ad = $.grep(nativeAds, function(e) {
        return e.screen_id === scope.type.toLowerCase();
      });
      if (native_ad && native_ad[0] && native_ad[0].ad_data && native_ad[0].ad_data.length > 0) {
	      let index;
	      index = native_ad[0].ad_data.findIndex(ad => ad.position === 'footer');
        this.nativeTag = native_ad[0].ad_data[index !== -1 ? index : 0];
		  	if (this.nativeTag) {
		  		this.nativeTag.adStyle = this.commonService.getAdType(this.nativeTag.ad_type);
      		// this.adCreation(this.nativeTag.ad_tag, (this.nativeTag.div_id),  this.nativeTag.ad_dimension, 'native');
  		  }
	  		this.googleAdCreation();
      }
    }
}

public googleAdCreation () {
  if (this.nativeTag && this.nativeTag && this.nativeTag.div_id) {
    switch (this.nativeTag.ad_provider) {
      case 'adfox':
        let adFoxtagAvailable;
        adFoxtagAvailable = this.commonService.checkAdFoxTag();
        if (adFoxtagAvailable === 'true' && this.nativeTag.owner_id && this.nativeTag.params) {
        	let scope;
        	scope = this;
		      $(this.document).ready(function() {
		        scope.adFoxCreation(scope.nativeTag.div_id, scope.nativeTag.owner_id, scope.nativeTag.params , 'native');
		      });
        }
        break;
      default:
        this.googletagAvailable = this.commonService.checkGoogleTag();
        if (this.googletagAvailable === 'true' && this.nativeTag.ad_tag) {
          this.adCreation(this.nativeTag.ad_tag, this.nativeTag.div_id,  this.nativeTag.ad_dimension, 'native');
        }
        break;
    }
  }
}

public adFoxCreation(id: any, owner_id: any, params: any, adType: any) {
  let adFoxtagAvailable;
  adFoxtagAvailable = this.commonService.checkAdFoxTag();
  if (adFoxtagAvailable === 'true') {
      this.window.Ya.adfoxCode.create({
        ownerId: owner_id,
        containerId: id,
        params: params,
        // onLoad: function(data) { console.log(data, 'onLoad') },
        // onRender: function(render) { console.log(render, 'onRender') },
        onError: function(error) {
          // console.log(error, 'onError');
          $('#' + id).hide();
        },
        onStub: function(stub) {
          // console.log(stub, 'onstub');
          $('#' + id).hide();
        }
      });
  } else {
    $('#' + id).hide();
  }
}

	public initialApiCall() {
		let x, userType;
		x = new CollectionApi(this.http, null, this.config);
		userType = this.commonService.getUserType();
		// x.v1CollectionByIdGet(this.collectionID, this.collectionPageNo, this.collectionPageSize, this.itemLimit,  this.countryCode).takeUntil(this.ngUnsubscribe).subscribe(value => {
  		x.v1DetailCollectionByIdGet(this.collectionID, this.collectionPageNo, this.collectionPageSize, this.itemLimit, this.countryCode, null, null, null, null, userType).takeUntil(this.ngUnsubscribe).subscribe(value => {
			// this.setAd();
			value.items = value.buckets;
			value.items = this.commonService.removeWebView(value.items);
			this.data = value;
			this.seoservice.updatefromAPI(this.data, this.router);
			this.totalCollectionPages = Math.ceil((this.data.total) / (this.collectionPageSize));
			this.initialiseData(this.data);
		},
		err => {
			this.gtm.sendErrorEvent('api', err);
			$('#loaderPage').css('display', 'none');
			if (err.status === 401 && this.apiRetryCount < this.apiRetry) {
				this.apiRetryCount ++;
				this.commonService.refreshToken().then(
					() => {
						this.initialApiCall();
					},
					);
			}
		}
		);
	}
	public updateBreadCrump(title: any, subtitle: any, route: any) {
		let breadcrump;
		breadcrump = [
		{
			'label': 'BREADCRUMB.HOME',
			'url': '/',
			'enable': true
		},
		{
			'label': this.breadcrumb,
			'url': this.breadcrumbroute,
			'enable': true
		},
		{
			'label': this.breadcrumball,
			'url': this.router2,
			'enable': false
		},
		];
		if (this.breadcrumb === '') {
			this.headerservicesService.breadCrump('');
		} else {
			this.headerservicesService.breadCrump(breadcrump);
		}
	}
	// @HostListener('window:scroll', ['$event'])
	// public onScrollEvent($event) {
	// 	if (!this.current) {
	// 		return;
	// 	}
	// 	let factor;
	// 	if (this.touchScreen) {
	// 		factor = 0.35;
	// 	} else if (!this.touchScreen) {
	// 		factor = 0.75;
	// 	}
	// 	if ($(this.window).scrollTop() >= ($(this.document).height() - $(this.window).height()) * factor) {
	// 		// this.load();
	// 	}
	// }
	public adCreation(tag: any, id: any, dimension: any, adType: any) {
  		this.googletagAvailable = this.commonService.checkGoogleTag();
		if (this.googletagAvailable === 'true') {
			let scope;
      		scope = this;
			setTimeout(function() {
				if (googletag.apiReady) {
					googletag = googletag || {};
					googletag.cmd = googletag.cmd || [];
					googletag.cmd.push(function() {
					  googletag.pubads().addEventListener('slotRenderEnded', function(event) {
			              if (event.slot === scope.adSlot && (!event.isEmpty)) {
			                scope.mastAd = true;
			              } else if (event.slot === scope.adSlot && (event.isEmpty)) {
			                // ad slot is not empty
			              }
			          });
					  if (adType === 'masthead') {
						scope.adSlot = googletag.defineSlot(tag, dimension, id).setCollapseEmptyDiv(true).addService(googletag.pubads());
					  } else {
						googletag.defineSlot(tag, dimension, id).setCollapseEmptyDiv(true).addService(googletag.pubads());
					  }
						googletag.enableServices();
					});
					googletag.cmd.push(function() { googletag.display(id); });
				}
			}, 1000);
		}
	}
	public initialiseData(data: any): void {
		if ( data.items.length > 0) {
			this.title = {'title': data.title, 'original_title': data.original_title};
			if (data.items.length > 0) {
				for (let index = 0 ; index < data.items.length; index ++ ) {
					if (data.items[index].tags && data.items[index].tags[0] === 'banner' && !this.carousel) {
						if (data.items[index] && data.items[index].items.length > 0) {
							this.carouselTitle = {'title': data.items[index].title, 'original_title': data.items[index].original_title};
							this.carousel = data.items[index].items;
									this.carouselCollection = data.items[index].id;
									this.collectionTags = data.items[index].tags;
							// $('.breadcrumInit').addClass('topCarousel');
						}
					}
				}
			}
		}
	}
	public update(): void {
		if (this.networkService.getPopupStatus()) {
			$('#loaderPage').css('display', 'block');
			this.contentAvailable = true;
			this.page = 1;
			this.languages = this.filterService.getSelectedLanguage();
			this.category = this.filterService.getSelectedGenre();

			if (this.moviesScreen) {
				if (this.category.length > 0) {
					this.updateApiCallMovie('movie');
				} else {
					let x, userType;
					x = new MovieApi(this.http, null, this.config);
					userType = this.commonService.getUserType();
					x.v1MovieGenresGet('movie', undefined, this.countryCode, undefined, userType).timeout(environment.timeOut).takeUntil(this.ngUnsubscribe).subscribe(value => {
						if (value.genres) {
							this.category = this.filterService.getIds(value.genres);
							this.filterService.setMoviesGenre(value.genres);
						}
						this.updateApiCallMovie('movie');
					}, error => {
						this.updateApiCallMovie('movie');
						this.gtm.sendErrorEvent('api', error);
					});
				}
			} else if (this.tvshowsScreen || this.originalsScreen) {
				let type;
				type = this.originalsScreen ? 'original' : 'tvshow';
				if (this.category.length > 0) {
					this.updateApiCallTvshow(type);
				} else {
					let x, userType;
					x = new TvShowApi(this.http, null, this.config);
					userType = this.commonService.getUserType();
					x.v1TvshowGenresGet(undefined, this.countryCode, undefined, userType).timeout(environment.timeOut).subscribe(value => {
						if (value.genres) {
							this.category = this.filterService.getIds(value.genres);
							this.filterService.setShowsGenre(value.genres);
						}

						this.updateApiCallTvshow(type);
					}, error => {
						this.updateApiCallTvshow(type);
						this.gtm.sendErrorEvent('api', error);
					});
				}
			} else if (this.videosScreen) {
				if (this.category.length > 0) {
					this.updateApiCallMovie('video');
				} else {
					let x, userType;
					x = new MovieApi(this.http, null, this.config);
					userType = this.commonService.getUserType();
					x.v1MovieGenresGet('video', undefined, this.countryCode, undefined, userType).timeout(environment.timeOut).subscribe(value => {
						if (value.genres) {
							this.category = this.filterService.getIds(value.genres);
							this.filterService.setVideosGenre(value.genres);
						}
						this.updateApiCallMovie('video');
					}, error => {
						this.updateApiCallMovie('video');
						this.gtm.sendErrorEvent('api', error);
					});
				}
			}

		}
	}

	public initialiseUpdate(value: any) {
		$('#loaderPage').css('display', 'none');
		this.window.scrollTo(0, 0);
		this.data = value;
		if (this.data.items) {
			this.current = {'type': this.type, 'parentType': (this.originalsScreen ? 'originalPage' : ''),
			'content': this.data.items		};
			if (this.data.items.length === 0) {
				this.contentAvailable = false;
			}
		} else {
			this.contentAvailable = false;
		}
		this.filterFlag = true;
		this.totalPages = Math.ceil((this.data.total) / (this.pageSize));
	}
	public updateApiCallTvshow(type: any): void {
		let x, userType;
		x = new TvShowApi(this.http, null, this.config);
		userType = this.commonService.getUserType();
		x.v1TvshowGet( 'release_date', 'DESC', this.page, this.pageSize, this.category , undefined, this.languages, this.countryCode, undefined, undefined, type, undefined, userType).takeUntil(this.ngUnsubscribe).subscribe(value => {
			this.initialiseUpdate(value);
		},
		err => {
			this.contentAvailable = false;
			$('#loaderPage').css('display', 'none');
			this.gtm.sendErrorEvent('api', err);
		}
		);
	}
	public updateApiCallMovie(type: any): void {
		let x, userType;
		x = new MovieApi(this.http, null, this.config);
		userType = this.commonService.getUserType();
		x.v1MovieGet(type, 'release_date', 'DESC', this.page, this.pageSize, this.category , undefined, this.languages, this.countryCode, undefined, undefined, undefined, userType).takeUntil(this.ngUnsubscribe).subscribe(value => {
			this.initialiseUpdate(value);
		},
		err => {
			this.contentAvailable = false;
			$('#loaderPage').css('display', 'none');
			this.gtm.sendErrorEvent('api', err);
		}
		);
	}
	public load() {
		if (!this.current) {
			return;
		}
		if (this.networkService.getPopupStatus()) {
			if (this.processPending === false) {
				this.page++;
				if (this.totalPages >= this.page) {
					this.processPending = true;
					$('.auto-loader').css('display', 'block');
					if (this.moviesScreen) {
						this.loadMovie('movie');
					} else if (this.tvshowsScreen) {
						this.loadTvshow('tvshow');
					} else if (this.videosScreen) {
						this.loadMovie('video');
					} else if (this.originalsScreen) {
						this.loadTvshow('original');
					}
				} else {
					$('.load').hide();
				}

			}
		}
	}
	public loadInitialise(value: any) {
		this.processPending = false;
		this.current.content.push.apply(this.current.content, value.items);
		$('.auto-loader').css('display', 'none');
		if (this.scrollCount > 0) {
		    this.gtm.sendEventDetails({'event': 'scrollTracking', 'ScrollCount': '1'});
		}
		this.scrollCount++;
	}
	public loadMovie(type: any) {
		let x, userType;
		x = new MovieApi(this.http, null, this.config);
		userType = this.commonService.getUserType();
		x.v1MovieGet(type, 'release_date', 'DESC', this.page, this.pageSize, this.category, undefined, this.languages, this.countryCode, undefined, undefined, undefined, userType).takeUntil(this.ngUnsubscribe).subscribe(value => {
			this.loadInitialise(value);
		},
		err => {
			this.processPending = false;
			this.gtm.sendErrorEvent('api', err);
		});
	}
	public loadTvshow(type: any) {
		let x, userType;
		x = new TvShowApi(this.http, null, this.config);
		userType = this.commonService.getUserType();
		x.v1TvshowGet( 'release_date', 'DESC', this.page, this.pageSize, this.category, undefined, this.languages, this.countryCode, undefined, undefined, type, undefined, userType).takeUntil(this.ngUnsubscribe).subscribe(value => {
			this.loadInitialise(value);
		},
		err => {
			this.processPending = false;
			this.gtm.sendErrorEvent('api', err);
		});
	}
	public openfilterNav(): void {
		if (this.networkService.getPopupStatus()) {
			this.filterbar = true;
		}
	}
	public closeFilter(event: any): void {
		this.filterbar = false;
	}
	public ngOnDestroy () {
		this.linkservice.removeCanonicalLink();
		this.destroyFilter.unsubscribe();
		// this.googletagAvailable = this.localstorage.getItem('googletag')
    this.googletagAvailable = this.commonService.checkGoogleTag();
		if (this.googletagAvailable === 'true' && googletag.destroySlots) {
			googletag.destroySlots();
			// clearTimeout(this.timer);
		}
		let adFoxtagAvailable;
	  adFoxtagAvailable = this.commonService.checkAdFoxTag();
	  if (adFoxtagAvailable === 'true' && this.window.Ya.adfoxCode.destroy) {
	  // if (adFoxtagAvailable === 'true' && this.window.Ya && this.window.Ya.adfoxCode && this.window.Ya.adfoxCode.destroy) {
	    this.window.Ya.adfoxCode.destroy();
	  }
		this.ngUnsubscribe.next();
		this.ngUnsubscribe.complete();
		this.filterbar = false;
		// if  (this.carousel) {
		// 	$('.breadcrumInit').removeClass('topCarousel');
		// }
	}
	public trackByFn (index, show) {
    		return show.id; // or item.id
    	}
    }
