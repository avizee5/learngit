import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VideoCastComponent } from './video-cast.component';

describe('VideoCastComponent', () => {
  let component: VideoCastComponent;
  let fixture: ComponentFixture<VideoCastComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VideoCastComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VideoCastComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
