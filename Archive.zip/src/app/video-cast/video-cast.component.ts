import { Component, OnInit, HostListener, Input, Output, EventEmitter, OnDestroy, ViewChild} from '@angular/core';
import * as $ from 'jquery';
import { VideoService } from '../services/video.service';
import { Router, NavigationEnd, NavigationStart } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { Subject } from 'rxjs/Subject';
import { Http } from '@angular/http';
import { UserProfileService } from '../services/user-profile.service';
import { HeaderservicesService } from '../services/headerservices.service';
import {  NetworkService  } from '../services/network.service';
import {FavoritesApi, WatchlistApi } from '../../data/user/api/api';
import { SettingsService } from '../services/settings.service';
import { UseractionapiService } from '../services/useractionapi.service';
import { SubscriptionService } from '../services/subscription.service';
import { DeviceApiService } from '../services/device-api.service';
import { VideoAnalyticsService } from '../services/video-analytics.service';

import {environment} from '../../environments/environment';
import 'rxjs/add/operator/timeout';
import 'rxjs/add/operator/takeUntil';

import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';

declare let cast: any;
declare let chrome: any;
const epgAssetType = 10;
const nocast = 'PLAYER.CAST_ERROR';
const noqueue = 'PLAYER.CAST_QUEUE_ERROR';
const akamaiBasePath = environment.videoBasePath;

@Component({
  selector: 'app-video-cast',
  templateUrl: './video-cast.component.html',
  styleUrls: ['./video-cast.component.less']
})
export class VideoCastComponent implements OnInit, OnDestroy {
  public touchScreen: any = false;
  public firefox: any = false;
  public queueArray:  Array<any> = [];
  public queueIndex: any = 0;
  public castWidth: any = 1170;
  public castHeight: any = 93;
  public videoObject: any;
  public castControlsLeft: any;
  public castControlsHeight: any;
  public castControlsWidth: any;
  public castAutoplayWidth: any;
  public castAutoplayHeight: any;
  public castAutoplayLeft: any;
  public autoPlay = false; // to display or hide queue
  public nextPlayBlockHeight: any;
  public castAutoPlayVisible = true;
  public dropIcon: any;

  public close_icon = environment.assetsBasePath + 'assets/cast_icons/cast_close_icon.svg';
  public expand_screen_icon = environment.assetsBasePath + 'assets/cast_icons/expand_screen_icon.svg';
  public share_icon = environment.assetsBasePath + 'assets/cast_icons/share_icon.svg';
  public dropDownIcon = environment.assetsBasePath + 'assets/cast_icons/dropdwn_icon.svg';
  public dropUpIcon = environment.assetsBasePath + 'assets/cast_icons/dropup_icon.svg';
  public play = environment.assetsBasePath + 'assets/player_icons/play.svg';
  public pause = environment.assetsBasePath + 'assets/player_icons/pause.svg';
  public favIcon = environment.assetsBasePath + 'assets/cast_icons/fav_icon.svg';
  public watchLaterIcon = environment.assetsBasePath + 'assets/cast_icons/watch_later_icon.svg';
  public favIconSelected = environment.assetsBasePath + 'assets/cast_icons/fav_icon_selected.png';
  public watchLaterIconSelected = environment.assetsBasePath + 'assets/cast_icons/watch_later_icon_selected.png';

  public defaultImage = environment.assetsBasePath + 'assets/default/tvshow.png';
  public fav: any = this.favIcon;
  public watchLater: any = this.watchLaterIcon;

  public baseWidth: any = 800;
  public baseHeight: any = 93;
  public castControlsEnable: any = false;
  public castPlayPause: any;
  /*cast variables*/
  /*castNew*/
  public castSession: any;
  public mediaInfo: any;
  public castPlayer: any;
  public castPlayerController: any;
  public currentMediaTime: any = 0;
  public castDeviceInfo: any;
  public castDeviceName: any;
  public castDuration: any = '00:00:00';
  public castCurrentTime: any = '00:00:00';
  public totalDuration: any = 0;

  public mediaLoaded: any = false;

  public watched: any = false;
  public favorite: any = false;
  public autoPlayState: boolean;

  public defaultTitle = 'Not Available';
  public showshare: any = false;
  public enableQueue: any = false;
  public castQueueObject: any;
  public shareUrl: any;
  public mobile: any;
  public drmBasePath: any;
  public customData: any;
  public assetbasepath = environment.assetsBasePath;
  private ngUnsubscribe = new Subject<any>();
  public addOrPlay: any = false; // false -> play, true -> add
  public cdnData: any;
  public languages: any;
  public processing: any = false;
  public timer: any;

  public window: any;
  public navigator: any;
  public localStorage: any;
  public document: any;

  public activeSubtitleTrack: any;
  public subtitleUrl: any;

  public token: any;
  public resetDevicePopup: any = false;
  public deviceList: any;
  public addingContentIndex: any;
  public callTimer(): any {
    this.processing = true;
    clearTimeout(this.timer);
    let scope;
    scope = this;
    this.timer = setTimeout(() => {
      scope.processing = false;
    }, 2000);
  }
  constructor(@Inject(PLATFORM_ID) private platformId: Object, private videoAnalyticsService: VideoAnalyticsService, private deviceApi: DeviceApiService, private sub: SubscriptionService, private useractionapiService: UseractionapiService, private http: Http, private networkService: NetworkService, private settingsService: SettingsService, private headerservicesService: HeaderservicesService, private videoService: VideoService, private router: Router, private userProfileService: UserProfileService) {
    if (isPlatformBrowser(this.platformId)) {
      this.localStorage = localStorage;
      this.window = window;
      this.navigator = navigator;
      this.document = document;
    }
    this.videoService.alertQueueState.takeUntil(this.ngUnsubscribe).subscribe(value => {
      if (value) {
        this.autoPlay = false;
        this.setAutoPlayWindow();
        // this.castQueueObject = this.videoService.castQueueObject[0];
        this.castQueueObject = JSON.parse(JSON.stringify(this.videoService.castQueueObject[0]));
        let inQueue;
        if (this.castQueueObject.type === 'live' || this.videoObject[this.queueIndex].type === 'live' || (this.castSession && !this.castSession.getMediaSession() && this.queueArray.length > 0 && this.queueIndex === this.queueArray.length - 1)) {
          this.enableQueue = false;
          if (this.castQueueObject.type === 'live' && this.videoObject[this.queueIndex].type === 'live' && this.videoObject[this.queueIndex].channel_id === this.castQueueObject.channel_id) {
            // trying to cast same channel
          } else {
            this.castVideo();
          }
        } else {
          inQueue = this.searchCastQueue();
          if (inQueue >= 0) {
            if (inQueue !== this.queueIndex) {
              this.jumpToContent(inQueue);
            }
            this.enableQueue = false;
          } else {
            this.document.getElementById('body').classList.add('modal-open');
            this.enableQueue = true;
          }
        }
      }
    });
    this.userProfileService.favourite.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.favorite = this.userProfileService.inList('favorite', this.videoObject[this.queueIndex].id);
      this.fav = this.favorite ? this.favIconSelected : this.favIcon;
    });
    this.userProfileService.watchlater.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.watched = this.userProfileService.inList('watchList', this.videoObject[this.queueIndex].id);
      this.watchLater = this.watched ? this.watchLaterIconSelected : this.watchLaterIcon;
    });
  }

  public searchCastQueue(): any {
    for (let i = 0; i < this.videoObject.length; i++) {
      if (this.videoObject[i].id === this.castQueueObject.id) {
        return i;
      }
    }
    return -1;
  }

  public ngOnInit(): any {
    if (isPlatformBrowser(this.platformId)) {
      this.localStorage = localStorage;
      this.window = window;
      this.navigator = navigator;
      this.document = document;
    }
    let value;
    if (!this.videoService.videoObjectSelected) {
      this.toggleCast();
    }
    this.videoService.storeWindowError();
    $('#body').removeAttr('style');
    this.getbrowser();
    value = this.settingsService.getCompleteConfig();
    this.languages = value.languages;
    this.cdnData = value.cdn;
    if (!this.cdnData || this.cdnData.length < 1) {
      this.drmBasePath = akamaiBasePath;
    // } else if (this.cdnData.length === 1) {
    //   this.drmBasePath = this.cdnData[0].url_in;
    } else {
      // index = this.cdnData.findIndex(i => i.id === 'akamai');
      // if (index !== -1) {
      //   this.drmBasePath = this.cdnData[index].url_in;
      // } else {
        this.drmBasePath = this.cdnData[0].url_in;
      // }
    }
    this.autoPlayState = false; // to be replaced based on the availability of playlist
    // this.videoObject = [this.videoService.videoObjectSelected];
    this.videoObject = JSON.parse(JSON.stringify([this.videoService.videoObjectSelected]));
    this.videoObject[0].image = this.videoService.getImageUrl(this.videoObject[0], true);
    this.watched = this.userProfileService.inList('watchList', this.videoObject[0].id);
    this.favorite = this.userProfileService.inList('favorite', this.videoObject[0].id);
    this.fav = this.favorite ? this.favIconSelected : this.favIcon;
    this.watchLater = this.watched ? this.watchLaterIconSelected : this.watchLaterIcon;
    this.token = this.localStorage.getItem('token');
    this.castPlayPause = this.play;
    if (this.cdnData.length > 1) {
      this.getPrecision();
    }
    this.castResize();
    this.initializeCastApi();
  }

  public getPrecision(): any {
    let index, precisionAPI;
    if (this.videoObject[0]) {
      let id;
      id = this.videoObject[0].id || '';
      // asset_name = this.videoObject[0].episode_name_en || this.videoObject[0].title_en || '';
      // asset_name = this.videoAnalyticsService.getVrlAssetName(this.videoObject[0]);
      this.videoService.getAPI(this.videoObject[0].drm, id).takeUntil(this.ngUnsubscribe).timeout(this.videoService.getPrecisionTimeout()).subscribe(value => {
        precisionAPI = value;
        if (precisionAPI.resource_list && precisionAPI.resource_list.length > 0) {
          index = this.cdnData.findIndex(i => i.id === precisionAPI.resource_list[0].resource);
          if (index !== -1) {
            this.drmBasePath = this.cdnData[index].url_in;
          }
        }
      },
      err => {
        precisionAPI = null;
        this.videoService.apiErrorEvent(err);
      });
    }
  }

  @HostListener('window:orientationchange', ['$event'])
  @HostListener('window:resize', ['$event'])
  public fontReScale(event) {
    if (this.autoPlay) {
      this.toggleAutoPlay();
    } else {
      this.castResize();
    }
  }

  @HostListener('window:mousedown', ['$event'])
  public hideQueue(evt) {
    if (evt.target.id === 'castAutoPlayContainer' || evt.target.id === 'nextListMobile' || evt.target.id === 'dropDownControlMobile' || $(evt.target).closest('#castAutoPlayContainer').length || $(evt.target).closest('#nextListMobile').length || $(evt.target).closest('#dropDownControlMobile').length) {
      return;
    } else {
      if (this.autoPlay === true) {
        this.toggleAutoPlay();
      }
    }
  }


  public castResize(): any {
    /*on load take footer width*/
    if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i) || this.castWidth <= 480) {
      this.touchScreen = true;
    } else {
      this.touchScreen = false;
    }
    this.castWidth = this.videoService.castWindowWidth;
    this.closeShare();
    if (this.castWidth <= 480) {
      this.mobile = true;
      $(this.document).ready(function() {
        $('#castProgressBarBlockMobile').css('width', 'calc(100% - 162px)');
        $('#videoTitleSectionMobile').css('width', 'calc(100% - 155px)');
        $('.descriptionContainerMobile').css('width', 'calc(100% - 149px)');
        $('.timeLapse').text(this.castCurrentTime);
      });
      return;
    } else {
      this.mobile = false;
    }
    this.castControlsWidth = (this.castWidth * this.baseWidth / 1170) + 'px';
    this.castAutoplayWidth = (this.castWidth * 369 / 1170) + 'px';

    this.castHeight = this.castWidth * 93 / 1170;

    this.castControlsHeight = this.castHeight + 'px';
    this.setAutoPlayWindow();
    let left, autoPlayLeft, self;
    left = (this.window.innerWidth - this.castWidth) / 2;
    this.castControlsLeft = left + 'px';
    autoPlayLeft = left + (this.castWidth * this.baseWidth / 1170) + 1; // 800 for 1170 , so x for y value
    this.castAutoplayLeft = autoPlayLeft + 'px';
    self = this;
    $(this.document).ready(function() {
      $('#castBlock').css('font-size', self.castHeight * 14 / 93 + 'px');
      $('.timeLapse').text(this.castCurrentTime);
    });
  }

  public toggleAutoPlay(): any {
    this.autoPlay = !this.autoPlay;
    if (!this.mobile) {
      this.setAutoPlayWindow();
      this.disableScroll();
    } else {
      this.dropIcon = this.autoPlay ? this.dropDownIcon : this.dropUpIcon;
      this.castResize();
      this.disableScroll();
    }
  }

  public disableScroll(): void {
    if (this.touchScreen && this.autoPlay) {
      this.document.getElementById('body').classList.add('modal-open');
    } else {
      this.document.getElementById('body').classList.remove('modal-open');
    }
  }

  public setAutoPlayWindow(): any {
  	if (this.autoPlay  && this.autoPlayState) {
  		let autoPlayHeight;
      autoPlayHeight = (this.castWidth * (this.baseHeight + 5 + 503) / 1170) - 35;
  		this.castAutoplayHeight = autoPlayHeight + 'px';
      $('#nextPlay').css('height', 'calc(100%*' + this.castHeight + '/' + autoPlayHeight + ')');
  		this.castAutoPlayVisible = true;
  		$('#dropDownControl').css('background', '#130a16');
  		this.dropIcon = this.dropDownIcon;
  	} else {
      $('#nextPlay').css('height', '');
  		this.castAutoplayHeight = this.castHeight + 'px';
      this.castAutoPlayVisible = false;
  		$('#dropDownControl').css('background', '#1b0f1e');
  		this.dropIcon = this.dropUpIcon;
  	}
  }

  public toggleCast(): any {
    this.videoService.enableCastView = !this.videoService.enableCastView;
    this.videoService.toggleCastState(this.videoService.enableCastView);
  }


  public initializeCastApi(): any {
    this.castSession = cast.framework.CastContext.getInstance().getCurrentSession();
    // request session
    this.triggerCast();
  }

  public triggerCast(): any {
    let casting, scope, self;
    casting = cast.framework.CastContext.getInstance().requestSession();
    scope = this;
    casting.then(function(value) {
      scope.document.getElementById('body').classList.remove('modal-open');
      scope.videoService.closeModalVideo(true);
    }, function(reason) {
      $('#PlayerContainer').css('pointer-events', '');
      scope.closeApp();
    });

    this.castPlayer = new cast.framework.RemotePlayer();
    this.castPlayerController = new cast.framework.RemotePlayerController(this.castPlayer);
    self = this;
    // this.castPlayerController.addEventListener(cast.framework.RemotePlayerEventType.MEDIA_INFO_CHANGED, this.mediaInfoChange.bind(this))
    this.castPlayerController.addEventListener(cast.framework.RemotePlayerEventType.IS_CONNECTED_CHANGED, this.playerStateChange.bind(self));
    this.castPlayerController.addEventListener(cast.framework.RemotePlayerEventType.CURRENT_TIME_CHANGED, this.currentTimeChange.bind(self));
    this.castPlayerController.addEventListener(cast.framework.RemotePlayerEventType.DURATION_CHANGED, this.durationTimeChange.bind(self));
    this.castPlayerController.addEventListener(cast.framework.RemotePlayerEventType.PLAYER_STATE_CHANGED, this.playerstatechanged.bind(self));
    this.castPlayerController.addEventListener(cast.framework.RemotePlayerEventType.TITLE_CHANGED, this.titlechanged.bind(self));
  }

  public titlechanged(e): any {
    let index;
    if (this.videoObject.length > 1 && this.castSession && this.castSession.getMediaSession()) {
      index = this.castSession.getMediaSession().items.findIndex(x => x.media.metadata.title === e.value);
      if (index >= 0 && this.queueIndex !== index) {
        this.changeQueueIndex(index);
      }
    }
  }

  public changeQueueIndex(index): any {
    this.queueIndex = index;
    this.watched = this.userProfileService.inList('watchList', this.videoObject[this.queueIndex].id);
    this.favorite = this.userProfileService.inList('favorite', this.videoObject[this.queueIndex].id);
    this.fav = this.favorite ? this.favIconSelected : this.favIcon;
    this.watchLater = this.watched ? this.watchLaterIconSelected : this.watchLaterIcon;
  }

  public playerstatechanged(e): any {
    if (e.value === 'PLAYING') {
      this.castPlayPause = this.pause;
    } else if (e.value === 'PAUSED') {
      this.castPlayPause = this.play;
    }
  }

  public stopMedia(): any {
    this.castPlayerController.removeEventListener(cast.framework.RemotePlayerEventType.MEDIA_INFO_CHANGED);
    this.castPlayerController.removeEventListener(cast.framework.RemotePlayerEventType.IS_CONNECTED_CHANGED);
    this.castPlayerController.removeEventListener(cast.framework.RemotePlayerEventType.CURRENT_TIME_CHANGED);
    this.castPlayerController.removeEventListener(cast.framework.RemotePlayerEventType.DURATION_CHANGED);
    this.castPlayerController.removeEventListener(cast.framework.RemotePlayerEventType.IS_MEDIA_LOADED_CHANGED);
    this.castPlayerController.removeEventListener(cast.framework.RemotePlayerEventType.PLAYER_STATE_CHANGED);
    this.castPlayerController.removeEventListener(cast.framework.RemotePlayerEventType.TITLE_CHANGED);
    this.castPlayerController.stop();
     if (this.videoService.enableCastView === true) {
       this.toggleCast();
     }
  }

  public initializeSession(): any {
    this.castSession = cast.framework.CastContext.getInstance().getCurrentSession();
    this.castDeviceInfo = this.castSession.getCastDevice();
    this.castDeviceName = this.castDeviceInfo.friendlyName;
    this.loadMedia(0);
  }

  public loadMedia(index): any {
    if (this.videoObject[index].type === 'live' && this.videoObject[index].drm) {
      this.videoObject[index].drm = false;
    }
    if (this.videoObject[index].drm) {
      this.getCustomkeyAndLoad(index);
    } else {
      this.getTokenAndLoad(index);
    }
    this.castPlayPause = this.pause;
    this.mediaLoaded = true;
  }

  public getCustomkeyAndLoad(index): any {
    console.log("videoObject 1", this.videoObject)
    let object;
    object = this.videoService.getEntitlementObject(this.videoObject[index]);
    this.postEntitlement(object, index);
  }

  public postEntitlement(object: any, index: any): any {
    this.useractionapiService.postEntitlementV3(object).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
      if (value && value !== null && !this.useractionapiService.isEmptyObject(value)) {
        this.customData = value.drm;
        this.setUrl(index, '');
     } else {
              this.removefromArray(index);
     }
    }, error => {
      if (error.name === 'TimeoutError') {
        this.removefromArray(index);
      } else {
        let errorBody;
        errorBody = JSON.parse(error._body);
        if (this.token && (errorBody.code === 3604 || errorBody.code === 3608)) { // Device not found
          this.addDevice(index);
        } else {
          this.removefromArray(index);
        }
      }
      this.videoService.apiErrorEvent(error);
    });
  }

  public setUrl(index: any, token: any): any {
    let contentType, currentMediaURL;
    if (this.videoObject[index].drm) {
      currentMediaURL = this.videoObject[index].stream_url_dash;
    } else {
      currentMediaURL = this.videoObject[index].stream_url_hls || this.videoObject[index].stream_url_dash;
    }
    if (currentMediaURL) {
      currentMediaURL = this.generateUrl(currentMediaURL) + token;
    } else {
      this.removefromArray(index);
      return;
    }
    contentType = 'video/mp4';
    this.mediaInfo = new chrome.cast.media.MediaInfo(currentMediaURL, contentType);
    this.loadContent(index);
  }

  public addDevice(index: any): any {
    this.deviceApi.postDevice(this.token).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
      this.loadMedia(index);
    }, error => {
      if (error.name === 'TimeoutError') {
        this.removefromArray(index);
      } else {
        let body;
        body = JSON.parse(error._body);
        if (body.code === 3602) { // max devices registered
          this.addingContentIndex = index;
          this.resetDevicePopup = true;
        } else {
          this.removefromArray(index);
        }
      }
      this.videoService.apiErrorEvent(error);
    });
  }

  public resetDevice(event): any {
    let index;
    index = this.addingContentIndex;
    this.resetDevicePopup = false;
    if (event === 'success') { // reset success
      this.addDevice(index);
    } else { // close // reset failed // other error
      this.removefromArray(index);
    }
    this.addingContentIndex = null;
  }

  public loadContent(index): any {
    if (!this.mediaInfo.contentId) {
      this.removefromArray(index);
      return;
    }
    let currentMediaTitle, currentMediaThumb, request, queueInsert, queueItem, currentItemId, queueList, scope, queueLoad;
    currentMediaTitle = this.videoObject[index].episode_name || this.videoObject[index].title || 'Not Available';
    if (this.videoObject[index].image) {
      currentMediaThumb = this.videoObject[index].image;
    }
    this.mediaInfo.metadata = new chrome.cast.media.GenericMediaMetadata();
    this.mediaInfo.metadata.metadataType = chrome.cast.media.MetadataType.GENERIC;
    this.mediaInfo.metadata.title = currentMediaTitle;
    this.mediaInfo.metadata.images = [{'url': currentMediaThumb}];
    if (this.videoObject[index].drm) {
      this.mediaInfo.customData = {
        licenseUrl : '//wv-keyos-aps1.licensekeyserver.com',
        licenseCustomData: this.customData
      };
    } else {
      this.mediaInfo.customData = {
        licenseUrl : '',
        licenseCustomData: ''
      };
    }

    this.mediaInfo.customData = $.extend({}, this.mediaInfo.customData, this.videoAnalyticsService.getCastConvivaObject(this.videoObject[index]));
    if (index === 0) {
      this.mediaInfo.customData.quality = this.videoService.selectedQuality;
    } else {
      this.mediaInfo.customData.quality = -1;
    }

    let streamProtocol;
    if (this.mediaInfo.contentId.indexOf('.m3u8') >= 0) {
      streamProtocol = 'HLS';
    } else if (this.mediaInfo.contentId.indexOf('.mpd') >= 0) {
      streamProtocol = 'DASH';
    }
    this.mediaInfo.customData.streamProtocol = streamProtocol;

    this.mediaInfo.customData.audioLang = this.videoService.selectedAudio;
    this.mediaInfo.customData.audioLanguage = this.getAudLan(index);

    this.mediaInfo.customData.isDRM = (this.videoObject[index].type !== 'live' && this.videoObject[index].drm === false) ? 'no' : 'yes';
    this.mediaInfo.customData.id = this.videoObject[index].id;
    this.mediaInfo.customData.asset_type = this.videoObject[index].asset_type;
    if (this.videoService.selectedSubtitle) {
      this.mediaInfo.tracks = this.getSubtitles(index);
    }
    scope = this;
    if (!this.addOrPlay) {
      if (index === 0 || this.videoObject[index].type === 'live' || this.videoObject[this.queueIndex].type === 'live') {
        request = new chrome.cast.media.LoadRequest(this.mediaInfo);
        if (index === 0 && this.videoObject[0].type === 'vod') {
          request.currentTime = this.videoService.currentTime;
          this.videoService.currentTime = 0;
        }
        if (this.activeSubtitleTrack) {
          request.activeTrackIds = [this.activeSubtitleTrack];
        }
        queueItem = new chrome.cast.media.QueueItem(this.mediaInfo);
        this.callTimer();
        this.castSession.loadMedia(request).then(
        function() {
          scope.videoObject = [scope.videoObject[index]];
          scope.queuIndex = 0;
          scope.autoPlayState = false;
          scope.queueArray = [];
          scope.queueArray.push(queueItem);
          scope.changeQueueIndex(scope.queuIndex);
        },
        function(errorCode) {
          scope.removefromArray(index);
        });
      } else {
        queueItem = new chrome.cast.media.QueueItem(this.mediaInfo);
        if (this.activeSubtitleTrack) {
          queueItem.activeTrackIds = [this.activeSubtitleTrack];
        }
        queueInsert = new chrome.cast.media.QueueInsertItemsRequest([queueItem]);
        if (!this.castSession.getMediaSession() && this.queueArray.length > 0 && this.queueIndex === this.queueArray.length - 1) {
          this.queueArray.push(queueItem);
          queueLoad = new chrome.cast.media.QueueLoadRequest(this.queueArray);
          queueLoad.startIndex = index;
          this.castSession.c.queueLoad(queueLoad);
          return;
        }
        queueList = this.castSession.getMediaSession().items;
        if (this.queueIndex !== this.videoObject.length - 2) {
          currentItemId = this.castSession.getMediaSession().items.findIndex(x => x.itemId === this.castSession.getMediaSession().currentItemId);
          queueInsert.insertBefore = this.castSession.getMediaSession().items[currentItemId + 1].itemId;
        }
        this.callTimer();
        this.castSession.getMediaSession().queueInsertItems(queueInsert, function() {
         scope.queueArray.splice(index, 0, queueItem);
         scope.castSession.getMediaSession().queueNext( function() {
         scope.changeQueueIndex(index);
         },
         // function(errorCode) {}
         ); },
         function(errorCode) {
           scope.removefromArray(index);
         });
      }
    } else {
      if (this.castSession && this.castSession.getMediaSession()) {
        queueItem = new chrome.cast.media.QueueItem(this.mediaInfo);
        if (this.activeSubtitleTrack) {
          queueItem.activeTrackIds = [this.activeSubtitleTrack];
        }
        this.castSession.getMediaSession().queueAppendItem(queueItem, function() {
        scope.queueArray.push(queueItem);
        },
        function(errorCode) {
          scope.removefromArray(index);
        });
      } else {
        scope.removefromArray(index);
      }
    }
  }

  public getAudLan(index): any {
    let audLan;
    if (index !== 0 || this.videoService.selectedAudio === 'default') {
      audLan = (this.videoObject[index].audio_languages && this.videoObject[index].audio_languages.length) ? this.videoObject[index].audio_languages[0] : undefined;
    } else {
      audLan = this.videoService.selectedAudio;
    }
    if (audLan)  {
      audLan = this.languages.findIndex(e => e.id === audLan);
      if (audLan !== -1) {
        audLan = this.languages[audLan].name;
      } else {
        audLan = 'Audio Language 1';
      }
    }
    return audLan;
  }
  public getSubtitles(index): any {
    this.activeSubtitleTrack = 0;
    if (!this.videoObject[index].subtitles || !this.videoObject[index].subtitles.length) {
      return [];
    }
    let subtitleUrl, subtitle, url, resourceUrl, subtitleArray, language, languageArray, scope, unknownSubtitleCounter;
    scope = this;
    subtitleArray = [];
    unknownSubtitleCounter = 0;
    resourceUrl = this.subtitleUrl;
    if (resourceUrl.indexOf('.mpd') >= 0) {
      subtitleUrl = resourceUrl.replace('.mpd', '.vtt');
    } else if (resourceUrl.indexOf('.m3u8') >= 0) {
      subtitleUrl = resourceUrl.replace('.m3u8', '.vtt');
    }
    for (let i = this.videoObject[index].subtitles.length - 1; i >= 0; i--) {
      let subIndex;
      subIndex = i;
      if (this.videoObject[index].subtitles[i]) {
        languageArray = this.languages.findIndex(e => e.id === this.videoObject[index].subtitles[i]);
        if (languageArray !== -1) {
          language = this.languages[languageArray].name;
        } else {
          language = ('Subtitle Language ' + (++unknownSubtitleCounter));
        }
        url = subtitleUrl.replace('.vtt', '-' + this.videoObject[index].subtitles[i] + '.vtt');
        subtitle = new chrome.cast.media.Track((subIndex + 1), chrome.cast.media.TrackType.TEXT);
        subtitle.trackContentId = url;
        subtitle.trackContentType = 'text/vtt';
        subtitle.subtype = chrome.cast.media.TextTrackType.SUBTITLES;
        subtitle.name = language;
        subtitleArray.push(subtitle);
        url = '';
        if (this.videoService.selectedSubtitle === language) {
          this.activeSubtitleTrack = (subIndex + 1);
        }
      }
    }
    if (this.activeSubtitleTrack) {
      return subtitleArray;
    } else {
      return [];
    }
  }

  public removefromArray(index): any {
    if (index > 0) {
      this.videoObject.splice(index, 1);
    } else {
      this.callToast();
      this.closeApp();
      return;
    }
    if (!this.addOrPlay) {
      this.callToast();
    } else {
      this.callToastQueue();
    }
  }

  public jumpToContent(index): any {
    if (this.processing === true) {
      this.callToast();
      return;
    }
    let itemId, queueLoad, scope;
    if (!this.castSession.getMediaSession() && this.queueArray.length > 0 && this.queueIndex === this.queueArray.length - 1) {
      queueLoad = new chrome.cast.media.QueueLoadRequest(this.queueArray);
      queueLoad.startIndex = index;
      this.castSession.c.queueLoad(queueLoad);
      return;
    }
    scope = this;
    if (this.castSession.getMediaSession()) {
      itemId = this.castSession.getMediaSession().items[index].itemId;
      if (itemId >= 1) {
        this.callTimer();
        this.castSession.getMediaSession().queueJumpToItem(itemId, function() {
          scope.changeQueueIndex(index);
         // },
         // function(errorCode) {
         });
      }
    }
  }

  public getTokenAndLoad(index): any {
    this.token = this.localStorage.getItem('token');
    this.videoService.getToken(this.videoObject[index].type, this.videoObject[index].business_type).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
      this.setUrl(index, value.video_token);
    }, err => {
      if (err.name === 'TimeoutError') {
        this.removefromArray(index);
      } else {
        let errorBody;
        errorBody = JSON.parse(err._body);
        if (this.token && (errorBody.code === 3604 || errorBody.code === 3608)) {
          this.addDevice(index);
        } else {
          this.removefromArray(index);
        }
      }
      this.videoService.apiErrorEvent(err);
    });
  }

  public generateUrl(currentMediaURL): any {
    if (currentMediaURL.indexOf('/') === 0) {
      this.subtitleUrl = akamaiBasePath + currentMediaURL;
      currentMediaURL = this.drmBasePath + currentMediaURL;
    }
    if (currentMediaURL && currentMediaURL[4] !== 's') {
      currentMediaURL = currentMediaURL.replace('http', 'https');
    }
    if (this.subtitleUrl && this.subtitleUrl[4] !== 's') {
      this.subtitleUrl = this.subtitleUrl.replace('http', 'https');
    }
    return currentMediaURL;
  }

  /*====================================================================================*/
  /* - mediaiInfoChange -> apiConfig*/
  /*====================================================================================*/
  // mediaInfoChange(e): any {
  // }

  public playerStateChange(e): any {
    if (!this.castPlayer.isConnected) {
      let network;
      network = this.networkService.getPopupStatus();
      // Update local player to disconnected state
      this.stopMedia();
    } else {
      if (!this.mediaLoaded) {
        this.initializeSession();
      }
      this.castControlsEnable = true;
    }
  }

  public currentTimeChange(e): any {
    let currentSeekPercent;
    this.castCurrentTime = this.updateTime(e.value);
    $('.timeLapse').text(this.castCurrentTime);
    if (this.videoObject[this.queueIndex].type === 'vod') {
      currentSeekPercent = e.value / this.totalDuration * 100;
      $('#progressBar').css('width', currentSeekPercent + '%');
    } else if (this.videoObject[this.queueIndex].type === 'live') {
      $('#progressBar').css('width', '100%');
    }
  }

  public durationTimeChange(e): any {
    if (this.videoObject[this.queueIndex].type === 'vod') {
      this.totalDuration = e.value;
      this.castDuration = this.updateTime(e.value);
      $('.timeDuration').text(this.castDuration);
    }
  }

  public updateTime(s): any {
    let d, hh, mm, ss;
    d = Number(s);
    hh = Math.floor(d / 3600);
    mm = Math.floor(d % 3600 / 60);
    ss = Math.floor(d % 3600 % 60);
    return ('0' + hh).slice(-2) + ':' + ('0' + mm).slice(-2) + ':' + ('0' + ss).slice(-2);
  }

  public displayTime(s): any {
    let d, hh, mm, ss;
    d = Number(s);
    hh = Math.floor(d / 3600);
    mm = Math.floor(d % 3600 / 60);
    ss = Math.floor(d % 3600 % 60);
    return (hh ? ( ('0' + hh).slice(-2) + 'h ') : '') + (mm ? ( ('0' + mm).slice(-2) + 'm ') : '00m ') + (ss ? (('0' + ss).slice(-2) + 's ') : '00s');
  }

  public castPlay(): any {
    let network;
    network = this.networkService.getPopupStatus();
    if (!network) {
      return;
    }
    if (this.castSession && this.castSession.getMediaSession()) {
      if (this.castSession.getMediaSession().playerState === 'PAUSED') {
        this.castPlayPause = this.pause;
      } else {
        this.castPlayPause = this.play;
      }
      this.castPlayerController.playOrPause();
      this.currentMediaTime = this.castSession.getMediaSession().currentTime;
    }
  }

  public castSeek(event): any {
    let network, pageX, offset, value;
    network = this.networkService.getPopupStatus();
    if (!network  || this.videoObject[this.queueIndex].type === 'live') {
      return;
    }
    pageX = this.videoService.pageX(event);
    offset = pageX - $('.castProgressBarBlock').offset().left;
    value = offset * this.totalDuration / $('.castProgressBarBlock')[0].offsetWidth;
    this.castPlayer.currentTime = value;
    this.castPlayerController.seek();
    this.currentMediaTime = this.castSession.getMediaSession().currentTime;
  }

  public imageError(event): any {
    if (event.srcElement) {
      event.srcElement.src = this.defaultImage;
    } else {
      event.currentTarget.src = this.defaultImage;
    }
  }

  public watchNow(): void {
    let network, token, params, configUser, show, watchListRequest, currentValue;
    network = this.networkService.getPopupStatus();
    if (!network || this.videoObject[this.queueIndex].type === 'live' || this.videoObject[this.queueIndex].asset_type === epgAssetType || this.videoObject[this.queueIndex].asset_type === 9) {
      return;
    }
    token = this.localStorage.getItem('token');
    if (token) {
    currentValue = this.userProfileService.inList('watchList', this.videoObject[this.queueIndex].id);
    if (currentValue !== this.watched) {
      if (this.watched) {
        this.watched = false;
        this.watchLater = this.watchLaterIcon;
      } else {
        this.watched = true;
        this.watchLater = this.watchLaterIconSelected;
      }
      return;
    }
      params = 'bearer ' + token;
      configUser = {
        apiKey: params,
        username: ' ',
        password: ' ',
        accessToken: ' ',
        withCredentials: false
      };
      show = {'id': this.videoObject[this.queueIndex].id, 'asset_type': this.videoObject[this.queueIndex].asset_type};
      if (this.watched === true ) {
        watchListRequest = new  WatchlistApi(this.http, null, configUser);
        watchListRequest.v1WatchlistDelete(this.videoObject[this.queueIndex].id, this.videoObject[this.queueIndex].asset_type).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
          this.watched = false;
          this.watchLater = this.watchLaterIcon;
          this.userProfileService.removeWatchData(show);
        },
        err => {
          this.watched = true;
          this.watchLater = this.watchLaterIconSelected;
          this.videoService.apiErrorEvent(err);
        });
      } else {
        watchListRequest = new  WatchlistApi(this.http, null, configUser);
        show = this.userProfileService.createObject(this.videoObject[this.queueIndex]);
        watchListRequest.v1WatchlistPost(show).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
          this.watched = true;
          this.watchLater = this.watchLaterIconSelected;
          this.userProfileService.setWatchData(show);
        },
        err => {
          this.videoService.apiErrorEvent(err);
          this.watched = false;
          this.watchLater = this.watchLaterIcon;
        });
      }
    } else {
      this.headerservicesService.signReminderChange(true);
    }
  }

  public addFavorite(): void {
    let network, token, params, configUser, show, favoritesRequest, currentValue;
    network = this.networkService.getPopupStatus();
    if (!network || this.videoObject[this.queueIndex].type === 'live' || this.videoObject[this.queueIndex].asset_type === epgAssetType || this.videoObject[this.queueIndex].asset_type === 9) {
      return;
    }
    token = this.localStorage.getItem('token');
    if (token) {
    currentValue = this.userProfileService.inList('favorite', this.videoObject[this.queueIndex].id);
    if (currentValue !== this.favorite) {
      if (this.favorite) {
        this.favorite = false;
        this.fav = this.favIcon;
      } else {
        this.favorite = true;
        this.fav = this.favIconSelected;
      }
      return;
    }
      params = 'bearer ' + token;
      configUser = {
        apiKey: params,
        username: ' ',
        password: ' ',
        accessToken: ' ',
        withCredentials: false
      };
      show = {'id': this.videoObject[this.queueIndex].id, 'asset_type': this.videoObject[this.queueIndex].asset_type};
      if (this.favorite === true ) {
        favoritesRequest = new  FavoritesApi(this.http, null, configUser);
        favoritesRequest.v1FavoritesDelete(this.videoObject[this.queueIndex].id, this.videoObject[this.queueIndex].asset_type).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
          this.favorite = false;
          this.fav = this.favIcon;
          this.userProfileService.removeFavoriteData(show);
        },
        err => {
          this.videoService.apiErrorEvent(err);
          this.favorite = true;
          this.fav = this.favIconSelected;
        });
      } else {
        favoritesRequest = new  FavoritesApi(this.http, null, configUser);
        show = this.userProfileService.createObject(this.videoObject[this.queueIndex]);
        favoritesRequest.v1FavoritesPost(show).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
          this.favorite = true;
          this.fav = this.favIconSelected;
          this.userProfileService.setFavoriteData(show);
        },
        err => {
          this.videoService.apiErrorEvent(err);
          this.favorite = false;
          this.fav = this.favIcon;
        });
      }
    } else {
      this.headerservicesService.signReminderChange(true);
    }
  }
  public openShare(): void {
    let network;
    network = this.networkService.getPopupStatus();
    if (!network) {
      return;
    }
    this.shareUrl = this.videoObject[this.queueIndex].share_url;
    this.showshare = true;
  }
  public closeShare(): any {
    this.showshare = false;
  }
  public closeQueueModal(): any {
    this.enableQueue = false;
    this.document.getElementById('body').classList.remove('modal-open');
    this.videoService.toggleQueueState(this.enableQueue);
  }
  public castVideo(): any {
    let network;
    network = this.networkService.getPopupStatus();
    if (!network) {
      return;
    }
    this.closeQueueModal();
    if (!this.queueArray.length || this.processing === true) {
      this.callToast();
      return;
    }
    this.autoPlayState = true; // to be replaced based on the availability of playlist
    this.castQueueObject.image = this.videoService.getImageUrl(this.castQueueObject, true);
    this.videoObject.splice(this.queueIndex + 1, 0, this.castQueueObject);
    this.addOrPlay = false; // false -> play, true -> add
    this.loadMedia(this.queueIndex + 1);
  }
  public addToQueue(): any {
    let network;
    network = this.networkService.getPopupStatus();
    if (!network) {
      return;
    }
    this.closeQueueModal();
    if (!this.queueArray.length || this.processing === true) {
      this.callToastQueue();
      return;
    }
    this.autoPlayState = true; // to be replaced based on the availability of playlist
    this.castQueueObject.image = this.videoService.getImageUrl(this.castQueueObject, true);
    this.videoObject.push(this.castQueueObject);
    this.addOrPlay = true; // false -> play, true -> add
    this.loadMedia(this.videoObject.length - 1);
  }
  public callToast() {
    let p;
    p = this.document.getElementById('castError');
    p.className = 'show';
    setTimeout(function() { p.className = p.className.replace('show', ''); }, 3000);
  }
  public callToastQueue() {
    let p;
    p = this.document.getElementById('castQueueError');
    p.className = 'show';
    setTimeout(function() { p.className = p.className.replace('show', ''); }, 3000);
  }
  public closeApp(): any {
    this.toggleCast();
    if (this.castSession) {
      this.castSession.removeEventListener(cast.framework.SessionEventType.APPLICATION_STATUS_CHANGED);
      this.castSession.endSession(true);
    }
  }
  public ngOnDestroy(): any {
    this.mouseLeave();
    if (this.videoService.modalStatus) {
      this.document.getElementById('body').classList.remove('modalOpen');
    }
    this.castControlsEnable = false;
    this.videoService.selectedSubtitle = null;
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }
  public getbrowser(): void {
    if (this.navigator.userAgent.indexOf('Firefox') !== -1 ) {
      this.firefox = true;
    }
  }
  // if the mouse enters on the div -- browser scroll disable
  public mouseEnter() {
    if (this.firefox) {
      let x, y;
      x = this.window.scrollX;
      y = this.window.scrollY;
      this.window.onscroll = function() { this.window.scrollTo(x, y); };
    } else {
      this.document.getElementById('body').classList.add('overlay-open');
    }
  }
  // if the mouse leaves the div -- browser scroll enable
  public mouseLeave() {
    if (this.firefox) {
      // this.window.onscroll = function() {};
    } else {
      this.document.getElementById('body').classList.remove('overlay-open');
    }
  }
}
