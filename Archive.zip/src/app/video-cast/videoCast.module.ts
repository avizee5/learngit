import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from '../shared.module';
import { VideoCastComponent } from './video-cast.component';
import { DeviceCheckModule } from '../device-check/deviceCheck.module';
import { ShareoptionsModule } from '../share-options/share-options.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    DeviceCheckModule,
    ShareoptionsModule
  ],
  declarations: [VideoCastComponent],
  exports: [VideoCastComponent]

})
export class VideoCastModule { }

