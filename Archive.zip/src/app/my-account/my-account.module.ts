import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared.module';
import { DataUnavailableModule } from '../data-unavailable/data-unavailable.module';
import { MyAccountComponent } from '../my-account/my-account.component';
import { InfoCardComponent } from '../my-account/info-card/info-card.component';
import { PackDetailsComponent } from '../my-account/info-card/pack-details/pack-details.component';
import { MyPlanComponent } from '../my-account/my-plan/my-plan.component';
import { PaymentComponent } from '../my-account/payment/payment.component';
import { SubscriptionComponent } from '../my-account/subscription/subscription.component';
import { SubSummaryComponent } from '../my-account/subscription/sub-summary/sub-summary.component';
import { UnsubscribeComponent } from '../my-account/my-plan/unsubscribe/unsubscribe.component';
import { FailPaymentComponent } from '../my-account/fail-payment/fail-payment.component';
import { SuccessPaymentComponent } from '../my-account/success-payment/success-payment.component';
import { DateSuperscriptPipe } from './custom-filters/date-superscript.pipe';
import { GdprComponent } from './gdpr/gdpr.component';
import { CheckBoxModule } from '../checkbox/checkbox.module';
import { GaanaSubscriptionComponent } from '../my-account/gaana-subscription/gaana-subscription.component';
import { FormsModule } from '@angular/forms';

const routes: Routes = [
    {
        path: '',
        component: MyAccountComponent,
    },
];
@NgModule({
  exports: [RouterModule],
  imports: [RouterModule.forChild(routes),
  			CommonModule,
  			SharedModule,
  			DataUnavailableModule,
        CheckBoxModule,
        FormsModule
  			],
  declarations: [MyAccountComponent, InfoCardComponent,
  			PackDetailsComponent,
  			MyPlanComponent,
  			PaymentComponent,
  			SubscriptionComponent,
  			SubSummaryComponent,
  			UnsubscribeComponent,
  			FailPaymentComponent,
  			SuccessPaymentComponent,
         DateSuperscriptPipe,
         GdprComponent,
         GaanaSubscriptionComponent
           ]
})
export class MyAccountModule { }
