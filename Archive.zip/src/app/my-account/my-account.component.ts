import { Component, OnInit, HostListener, OnDestroy } from '@angular/core';
import { HeaderservicesService } from '../services/headerservices.service';
import { Subscription } from 'rxjs/Subscription';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import * as $ from 'jquery';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { SubscriptionService } from '../services/subscription.service';
import { RouteService } from '../services/route.service';
import { environment } from '../../environments/environment';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { LinkService } from '../services/link.service';
import { SeoService } from '../services/seo.service';
import { Subject } from 'rxjs/Subject';
import { SettingsService } from '../services/settings.service';

@Component({
  selector: 'app-my-account',
  templateUrl: './my-account.component.html',
  styleUrls: ['./my-account.component.less']
})
export class MyAccountComponent implements OnInit, OnDestroy {
  private menuTabs: any;    // for changing class
  private previousTab: any;
  public planComponentFlag = true;    // flags to enable different components
  public subscribeComponentFlag = false;
  public paymentComponentFlag = false;
  public historyComponentFlag = false;
  public callPackInfoFlag: boolean;
  public callPackGaanaFlag = false;
  public callUnsubscribePopupFlag: any; // unsubscribe pop up
  private router: any;
  private router2: any;
  private userToken: any;
  private string: any;
  private searchPlan = false; // click on search for a plan should open subscription
  private sub: any;
  private pageName: any;
  private paymentFailFortumoFlag = false;
  private switchTab: any;
  private paymentCancelFlag: boolean;
  private redirectSubscribe = false;
  private localstorage: any;
  private window: any;
  private document: any;
  private dialog = true;
  private paymentFlag: any;
  private displayComponent: any;
  private displayFlag: any;
  private displaySection: any;
  public onlySubscription = false;
  private breadcrumData: any;
  public showHeading = true;
  public successComponent = false;
  private backgroundImg: any;
  private country: any;
  private summaryDisplay: any;
  private noSub: any;
  public showBgImg = false;
  private ngUnsubscribe = new Subject<any>();
  constructor(private settingsService: SettingsService, private seoservice: SeoService, private linkservice: LinkService, @Inject(PLATFORM_ID) private platformId: Object, private routeservice: RouteService, private to: Location, private route: ActivatedRoute , private routerVal: Router, private headerservicesService: HeaderservicesService, private gtm: GoogleAnalyticsService, private subscription: SubscriptionService) {
    this.headerservicesService.dialogValue.subscribe(value => {     // login view changes to reflect login/register icon
      this.dialog = false;
 if (this.router.url === '/myaccount/subscription') {
        this.route.queryParams.subscribe(params => {
       this.router.navigate(['/myaccount/plans'], {queryParams : params});
       });
        this.sendBreadcrumData('SUSCRIPTION.MY_SUB', '/myaccount/plans');
      }
    });
    this.headerservicesService.subViewPackValue.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.callPackInfoFlag = value;
    });
    // unsubscribe popup in plans (subscription)
    this.headerservicesService.subUnsubscribeValue.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.callUnsubscribePopupFlag = value;
    });
    // unsubscribe gaana popup in plans(subscription)
    this.headerservicesService.closePackChangeValue.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.callPackGaanaFlag = value;
    });
    this.router = routerVal;
    this.router2 = window.location.pathname;
    this.headerservicesService.viewChange(this.router2);
    // plan component
    this.subscription.planCompFlag.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.planComponentFlag = value.planComp;
      this.subscribeComponentFlag = value.subComp;
      this.paymentComponentFlag = value.payComp;
      this.historyComponentFlag = value.historyComp;

      if (this.subscribeComponentFlag) {
        this.onlySubscription = true;
      }
    });
    // switch tab
    this.subscription.switchAccIndex.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.switchTab = value;
      this.openTab(this.switchTab);
    });

        // display cards in subscription
    this.headerservicesService.displayPlan.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.summaryDisplay = value.subEditSummaryValue;
        if (this.summaryDisplay === true) {
          this.backgroundImg = '';
         this.showBgImg = false;
        } else {
          this.backgroundImg = this.subscription.getBgImg('desktop');
          this.showBgImg = true;
        }
      });
  }

  public ngOnInit() {
    this.gtm.storeWindowError();
    if (isPlatformBrowser(this.platformId)) {
      this.localstorage = localStorage;
      this.window = window;
      this.document = document;
    }
    this.window.scrollTo(0, 0);
    this.redirectSubscribe = this.subscription.getRedirectSubscribe();
    if (!this.redirectSubscribe) {
      // redirect to same page after login
      this.routeservice.setLoginRoute(this.window.location.pathname);
    }
    this.sub = this.route.params.subscribe(params => {
    this.string = params['string'];
    // this.string is not available for payment success/failure/cancelled
      if (!(this.string) && ((this.router.url.toLowerCase().indexOf('paymentsuccess') >= 0 ) && (this.router.url.toLowerCase().indexOf('paymentfailure') >= 0) && (this.router.url.toLowerCase().indexOf('paymentcancelled') >= 0))) {
       this.routerVal.navigate(['/myaccount/subscription']);
      }
    this.menuTabs = [ true, false, false, false, false ];
    this.previousTab = 0;
    this.userToken = this.localstorage.getItem('token');
    this.paymentFailFortumoFlag = false;
    this.paymentCancelFlag = false;
    if (this.userToken) {
      if (this.router.url.toLowerCase().indexOf('paymentsuccess') >= 0) {
          this.successComponent = true;
          this.onlySubscription = false;
          this.showBgImg = false;
      } else if ((this.router.url.toLowerCase().indexOf('paymentfailure') >= 0) || (this.router.url.toLowerCase().indexOf('paymentcancelled') >= 0)) {
        this.paymentFailFortumoFlag = true;
        this.paymentCancelFlag = false;
        this.paymentFlag = 'failure';
        this.showBgImg = false;
        this.document.getElementById('body').classList.add('modal-open');
        let sendFlag;
        sendFlag = {
          'failFlag': this.paymentFailFortumoFlag,
          'cancelFlag' : this.paymentCancelFlag
        };
        this.subscription.paymentSuccessFortumo(sendFlag);
        this.enableSub(false);
        this.onlySubscription = true;
        this.route.queryParams.subscribe(queryparams => {
        let failCode, failReason, failObj;
        failCode = queryparams ['failure_code'];
        failReason = queryparams ['failure_reason'];
        failObj = {
          'code': failCode,
          'reason': failReason
        };
        this.subscription.storePayFailQuery(failObj);
       });
      } else if (this.string === 'plans') {
         let accCheck = false;
         accCheck = this.subscription.getTelcoFlag();
         if (!accCheck) {
          this.enablePlan(false);
          this.onlySubscription = false;
          this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'myaccount/plans'  } );
          this.openTab(0);
         } else {
            this.enableSub(true);
            this.onlySubscription = true;
            this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'myaccount/subscription'  } );
         }
      } else if (this.string === 'subscription' && this.dialog === true) {
        this.enableSub(true);
         this.onlySubscription = true;
        this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'myaccount/subscription'  } );
      } else if (this.string === 'subscription' && this.dialog === false) {
        this.enablePlan(false);
        this.onlySubscription = false;
        this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'myaccount/plans'  } );
        this.openTab(0);
      } else if (this.string === 'payments') {
        let accCheck = false;
         accCheck = this.subscription.getTelcoFlag();
         if (!accCheck) {
            this.enablePay();
            this.openTab(2);
            this.onlySubscription = false;
            this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'myaccount/payments'  } );
          } else {
              this.enableSub(true);
              this.onlySubscription = true;
              this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'myaccount/subscription'  } );
          }
      } else {
          // random url naviagte to page not found
          this.router.navigate(['/pagenotfound']);
      }
    } else {
        this.route.queryParams.subscribe( paramsNew => {
          this.routerVal.navigate(['/myaccount/subscription'], {queryParams: paramsNew});
          this.sendBreadcrumData('SUSCRIPTION.BUY_SUB', '/myaccount/subscription');
          this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'myaccount/subscription'  } );
          this.enableSub(true);
          this.onlySubscription = true;
        });

    }
    });
  }

  private sendBreadcrumData(lastLabel: any, lastURL: any): void {
        this.breadcrumData = [
        {
          'label': 'BREADCRUMB.HOME',
          'url': '/',
          'enable': true
        },
        {
          'label': lastLabel,
          'url': lastURL,
          'enable': false
        }];
        this.headerservicesService.breadCrump(this.breadcrumData);
}


  private openTab(index: any): void {
    this.menuTabs[this.previousTab] = false;
    this.menuTabs[index] = true;
    this.previousTab = index;
    if (index === 0) {
      this.sendBreadcrumData('SUSCRIPTION.ACTIVE', 'myaccount/plans');
    } else if (index === 1) {
      this.sendBreadcrumData('SUSCRIPTION.HISTORY', 'myaccount/plans');
    }
  }

  private enablePlan(paymentNavigation: any): any {
  this.showBgImg = false;
    if (this.userToken) {
      if (!paymentNavigation) {
        this.route.queryParams.subscribe(params => {
          this.routerVal.navigate(['myaccount/plans'], {queryParams : params});
        });
      }
      this.showHeading = true;
      this.displayComponent = {
         'planComp': true,
         'subComp': false,
         'payComp': false,
         'historyComp': false
      };
      this.subscription.storePlanCompFlag(this.displayComponent);
      this.displaySection = 'active';
      this.pageName = 'my account/active';
      this.gtm.sendPageName(this.pageName);
      this.gtm.sendEvent();
    } else {
      this.headerservicesService.signReminderChange(true);
    }
  }

  private enableSub(enable: any): any {
    if (enable) {
      this.route.queryParams.subscribe(params => {
        this.routerVal.navigate(['myaccount/subscription'], {queryParams: params});
      });
    } else {
      this.to.replaceState('myaccount/subscription');
    }
    this.showHeading = false;
    this.sendBreadcrumData('SUSCRIPTION.BUY_SUB', '/myaccount/subscription');
     this.displayComponent = {
         'planComp': false,
         'subComp': true,
         'payComp': false,
         'historyComp': false
      };
    this.subscription.storePlanCompFlag(this.displayComponent);

  }

  private enableHistory(): any {
    this.showBgImg = false;
    if (this.userToken) {
     this.displayComponent = {
         'planComp': false,
         'subComp': false,
         'payComp': false,
         'historyComp': true
      };
      this.showHeading = true;
      this.subscription.storePlanCompFlag(this.displayComponent);
      this.displaySection = 'history';
      this.pageName = 'my account/history';
      this.gtm.sendPageName(this.pageName);
      this.gtm.sendEvent();
    } else {
      this.headerservicesService.signReminderChange(true);
    }
  }

  private enablePay(): any {
  this.showBgImg = false;
    if (this.userToken) {
     this.route.queryParams.subscribe(params => {
       this.routerVal.navigate(['myaccount/payments'], {queryParams : params});
     });
     this.sendBreadcrumData('SUSCRIPTION.TRANSACTIONS', 'myaccount/payments');
     this.displayComponent = {
         'planComp': false,
         'subComp': false,
         'payComp': true,
         'historyComp': false
      };
      this.showHeading = true;
      this.subscription.storePlanCompFlag(this.displayComponent);
    } else {
      this.headerservicesService.signReminderChange(true);
    }
  }

  private searchPlanSub(plan) {
    this.searchPlan = plan.switchToSub;
    this.enableSub(true);
    this.previousTab = 0;
    this.displayFlag = {
        'showAvailableValue' : true,
        'showSelectedValue' : false,
        'subEditSummaryValue' : false,
        'subDisplayValue' : false,
      };
      this.headerservicesService.showAvailablePlan(this.displayFlag);
  }
    public ngOnDestroy () {
    this.linkservice.removeCanonicalLink();
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }
  public sendUserClickDetails(userMenu) {
    let details;
    details = {
      'event': 'userIconClick',
      'UserMenu': userMenu
    };
    this.gtm.sendEventDetails(details);
  }
}
