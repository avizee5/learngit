import { Component, OnInit, Input } from '@angular/core';
import * as $ from 'jquery';

@Component({
  selector: 'app-cast-grid',
  templateUrl: './cast-grid.component.html',
  styleUrls: ['./cast-grid.component.less']
})
export class CastGridComponent implements OnInit {

 @Input() private actorInfo: any;

@Input() private type: any;
private color: string;
private mode: string;
private value: number;
private bufferValue: number;
private progress: any;
private watched: any;
private favorite: any;
 @Input() public actorsName: string;

private roleName: Array<string>;


constructor() {
// todo
}
public ngOnInit () {
	this.color = 'primary';
	this.mode = 'determinate';
	this.value = 50;
	this.bufferValue = 75;
	this.watched = false;
	this.favorite = false;

	this.roleName = this.actorsName.split( ':' );



		if ( this.roleName[0] == null ) {
			this.roleName[0] = 'NA';
		} else if ( this.roleName[0].length === 0 ) {

			this.roleName[0] = 'NA';
		}

		if ( this.roleName[1] == null ) {
			this.roleName[1] = 'NA';
		} else if ( this.roleName[1].length === 0 ) {
			this.roleName[1] = 'NA';
		}

}
private watchNow = function (event: any) {
	event.stopPropagation();
	event.preventDefault();
	if (this.watched === true ) {
		this.watched = false;
	} else {
		this.watched = true;
	}
};

private addFavorite = function (event: any) {
	event.stopPropagation();
	if (this.favorite === true ) {
		this.favorite = false;
	} else {
		this.favorite = true;
	}
};
private share = function (event: any) {
	event.stopPropagation();
};

}
