import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CastGridComponent } from './cast-grid.component';

describe('CastGridComponent', () => {
  let component: CastGridComponent;
  let fixture: ComponentFixture<CastGridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CastGridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CastGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
