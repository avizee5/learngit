import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CastscrollListComponent } from './castscroll-list.component';

describe('CastscrollListComponent', () => {
  let component: CastscrollListComponent;
  let fixture: ComponentFixture<CastscrollListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CastscrollListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CastscrollListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
