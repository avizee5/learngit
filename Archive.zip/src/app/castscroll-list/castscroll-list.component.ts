import { Component, OnInit, Input, ViewChild, ElementRef, OnChanges } from '@angular/core';
import * as $ from 'jquery';
import { environment } from '../../environments/environment';

@Component({
  selector: 'app-castscroll-list',
  templateUrl: './castscroll-list.component.html',
  styleUrls: ['./castscroll-list.component.less']
})
export class CastscrollListComponent implements OnInit, OnChanges {

 @Input() public arrayList: Array<string>;
 @ViewChild('left') private previous_select: ElementRef;
 @ViewChild('right') private next_select: ElementRef;
 @ViewChild('list') private element_select: ElementRef;
  private count: any;
  public arrows: boolean;
  private gridWidth: any;
  public containerWidth: any;
  private lenght_c: any;
  private offsetval: number;
  private assetbasepath: any;
  private castCount = 0;
  private castWidth: any;
  constructor() {
  // todo
   }

  public ngOnChanges () {
    this.onagainload();
  }

  public ngOnInit() {

    this.assetbasepath = environment.assetsBasePath;
    this.count = 0;
    this.lenght_c = 50;
     this.offsetval = 50;
     this.arrows = true;
    if (navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
      $('.grid').css({
        overflowX: 'scroll'
      });

      this.arrows = false;

    }
    this.onagainload();
    setTimeout(() => {
      this.castWidth = (($('.grid').width())) + 20;

    }, 5);
  }



/*   private previous(): void {

    if (this.count < 0) {
      this.count += this.offsetval;
      if (this.count +  this.offsetval ===  this.offsetval && this.arrayList.length === 1) {
          this.previous_select.nativeElement.src = this.assetbasepath + 'assets/common/left_nav.png';
          this.next_select.nativeElement.src = this.assetbasepath + 'assets/common/right_nav_selected.png';
      } else if (this.count +  this.offsetval ===  this.offsetval && this.arrayList.length !== 1) {
              this.previous_select.nativeElement.src = this.assetbasepath + 'assets/common/left_nav.png';
              this.next_select.nativeElement.src = this.assetbasepath + 'assets/common/right_nav_selected.png';
      } else if (this.count < - (this.arrayList.length - 2) *  this.offsetval +  (this.offsetval * 2)) {
              this.next_select.nativeElement.src = this.assetbasepath + 'assets/common/right_nav_selected.png';
      }
      this.element_select.nativeElement.style.marginLeft = this.count + '%';
    }

  }*/

 private previous(): void {
      if (this.castCount >= 1) {
        this.castCount--;
        $('#scrollCast').animate({scrollLeft: '-=' + this.castWidth + 'px'});
          if (this.castCount === 0) {
            this.previous_select.nativeElement.src = this.assetbasepath + 'assets/common/left_nav.png';
            this.next_select.nativeElement.src = this.assetbasepath + 'assets/common/right_nav_selected.png';
          } else {
           this.previous_select.nativeElement.src = this.assetbasepath + 'assets/common/left_nav_selected.png';
           this.next_select.nativeElement.src = this.assetbasepath + 'assets/common/right_nav_selected.png';
          }
      }
}
/*  private next(): void {
    if (this.count >= - (this.arrayList.length - 2) *  this.offsetval +  this.offsetval) {
      this.count -=  this.offsetval;
      if (this.count === - this.offsetval && this.arrayList.length === 1) {
        this.previous_select.nativeElement.src = this.assetbasepath + 'assets/common/left_nav_selected.png';
        this.next_select.nativeElement.src = this.assetbasepath + 'assets/common/right_nav.png';
      } else if (this.count === - this.offsetval && this.arrayList.length !== 1) {
        this.previous_select.nativeElement.src = this.assetbasepath + 'assets/common/left_nav_selected.png';
      } else if ( this.count <= -(this.arrayList.length - 2) *  this.offsetval ) {
        this.next_select.nativeElement.src = this.assetbasepath + 'assets/common/right_nav.png';
      }
      this.element_select.nativeElement.style.marginLeft = this.count + '%';
    }
  }*/

  private next(): void {
      if (this.castCount < (this.arrayList.length - 2)) {
        this.castCount++;
        $('#scrollCast').animate({scrollLeft: '+=' + this.castWidth + 'px'}, 500);
        if (this.castCount === (this.arrayList.length - 2)) {
            this.previous_select.nativeElement.src = this.assetbasepath + 'assets/common/left_nav_selected.png';
            this.next_select.nativeElement.src = this.assetbasepath + 'assets/common/right_nav.png';
        } else {
           this.previous_select.nativeElement.src = this.assetbasepath + 'assets/common/left_nav_selected.png';
           this.next_select.nativeElement.src = this.assetbasepath + 'assets/common/right_nav_selected.png';
        }
      }
  }

  public onResize(event: any): void {
    if ( this.arrayList != null ) {
      if (window.innerWidth > 991) {
        this.gridWidth = (( 2 * this.lenght_c) / this.arrayList.length);
        this.containerWidth = this.lenght_c * this.arrayList.length;
      } else {
        this.gridWidth = 'unset';
        this.containerWidth = 'unset';
        this.arrows = false;
      }
       // else if (window.innerWidth > 768) {
     //      this.gridWidth = (( 2 * this.lenght_c) / this.arrayList.length);
     //      this.containerWidth = this.lenght_c * this.arrayList.length;
     //    }else if (window.innerWidth <= 768 && window.innerWidth > 480) {
     //      // this.gridWidth = (( 2 * this.lenght_c) / this.arrayList.length);
     //      // this.containerWidth = this.lenght_c * this.arrayList.length * 1.5;
     //    } else if (window.innerWidth <= 480) {
     //       // this.gridWidth = (( 4 * this.lenght_c) / this.arrayList.length);
     //     // this.containerWidth = this.lenght_c * this.arrayList.length * 2.75;
     //    }

        if ( this.arrayList.length < 2 ) {
          this.arrows = false;
        }
      }
  }

  private onagainload() {
  if ( this.arrayList != null ) {
      if (window.innerWidth > 991) {
        this.gridWidth = (( 2 * this.lenght_c) / this.arrayList.length);
        this.containerWidth = this.lenght_c * this.arrayList.length;
          if ( this.arrayList.length <= 2 ) {
          this.arrows = false;
          // console.log('this.arrows',this.arrows,this.arrayList.length)
          } else {
             this.arrows = true;
          }
      } else {
        this.gridWidth = 'unset';
        this.containerWidth = 'unset';
        this.arrows = false;
      }

      // else if (window.innerWidth > 768) {
      //   this.gridWidth = (( 2 * this.lenght_c) / this.arrayList.length);
      //   this.containerWidth = this.lenght_c * this.arrayList.length;
      // } else if (window.innerWidth <= 768 && window.innerWidth > 480) {
      //   // this.gridWidth = (( 4 * this.lenght_c) / this.arrayList.length);
      //   // this.containerWidth = this.lenght_c * this.arrayList.length * 1.5;
      // } else if (window.innerWidth <= 480) {

      //  //   this.gridWidth = (( 4 * this.lenght_c) / this.arrayList.length);
      //  // this.containerWidth = this.lenght_c * this.arrayList.length * 2.75;
      // }

    }
  }


}
