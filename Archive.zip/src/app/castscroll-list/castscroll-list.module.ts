import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared.module';
import { CastscrollListComponent } from './castscroll-list.component';
import { CastGridComponent } from './cast-grid/cast-grid.component';

@NgModule({
  imports: [
    CommonModule,
    SharedModule
  ],
  declarations: [CastscrollListComponent, CastGridComponent],
  exports: [CastscrollListComponent]
})
export class CastscrollListModule { }
