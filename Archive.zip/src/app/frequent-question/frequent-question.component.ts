import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { HeaderservicesService } from '../services/headerservices.service';
import { FooterService } from '../services/footerdata.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { RouteService } from '../services/route.service';
import {  NetworkService  } from '../services/network.service';
import { environment } from '../../environments/environment';
import * as $ from 'jquery';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { LinkService } from '../services/link.service';
import { SettingsService } from '../services/settings.service';

@Component({
  selector: 'app-frequent-question',
  templateUrl: './frequent-question.component.html',
  styleUrls: ['./frequent-question.component.less']
})
export class FrequentQuestionComponent implements OnInit, OnDestroy {
  private source: any;
  private flag = false;
  private questions: any;
  private router: any;
  private router2: any;
  public data: any;
  private pageName: any;
  private basepath: any;
  private localstorage: any;
private window: any;
private navigator: any;
private document: any;
private menu_options: any;
private faqbreadcrumb: any;
  constructor(private settingsService: SettingsService, private linkservice: LinkService, @Inject(PLATFORM_ID) private platformId: Object, private networkService: NetworkService, private routeservice: RouteService, private gtm: GoogleAnalyticsService, private route: Router, private headerservicesService: HeaderservicesService, private footerservice: FooterService) {
    const scope = this;
    if (isPlatformBrowser(this.platformId)) {
   this.localstorage = localStorage;
    this.window = window;
    this.document = document;
    this.navigator = navigator;
}
    this.router = route;
    this.router2 = this.window.location.pathname;
    this.headerservicesService.viewChange(this.router2);
    this.routeservice.setRoute(this.router2);
    this.routeservice.setLoginRoute(this.window.location.pathname);
  }
  public ngOnInit() {
     if (isPlatformBrowser(this.platformId)) {
   this.localstorage = localStorage;
    this.window = window;
    this.document = document;
    this.navigator = navigator;
}


        this.faqbreadcrumb = [
        {
          'label': 'BREADCRUMB.HOME',
          'url': '/',
          'enable': true
        },
        {
          'label': 'BREADCRUMB.FAQ',
          'url': '/faq',
          'enable': false
        }
      ];


      this.headerservicesService.breadCrump(this.faqbreadcrumb);

this.settingsService.getCountryListNew().subscribe(value => {
      this.menu_options = value;
      let countryEmail = 'support.in@adsf';
      if (this.menu_options) {
        countryEmail = this.menu_options[0].mail;
      }
      this.footerservice.getFooterdata('assets/json/z5-info-en.json?ver=' + this.window.appVersion).subscribe(value1 => {
        this.data = value1;
        for ( let i = 0; i < this.data.FAQ[0].value.length; i++) {

          if ( this.data.FAQ[0].value[i].Question === 'How do I cancel my subscription?') {
                  this.data.FAQ[0].value[i].Answer = " <p>We are sad to know that you are looking to cancel your existing subscription. Is there anything that we could do to change your mind? Please let us know by mailing us at " + "<a href='mailto:" + countryEmail + "'>" + countryEmail  + "</a>" + " if you're facing any problem in accessing ZEE5 app or website.</p>If you still decide to cancel your subscription, follow one of the steps below:</p><p>If you have an auto-renewal subscription, you can deactivate auto renewal and you will not be billed from the next billing cycle.</p><p>If you don't have an auto renew subscription, you can't unsubscribe from an active subscription. However your subscription will terminate automatically after the subscription period gets over.</p><p>We'd really like you to stay, so let us know if there is a specific issue you are facing that we could help with.</p>";
          }

        }
        const now = JSON.stringify(this.data);
        $('#loaderPage').css('display', 'none');
        });
    });


    this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'faq'  } );
    this.gtm.storeWindowError();
    this.basepath = environment.assetsBasePath;
    $('#loaderPage').css('display', 'block');
    let network;
    network = this.networkService.getScreenStatus();
    this.pageName = 'faqs';
    this.gtm.sendPageName(this.pageName);
    this.gtm.sendEvent();

    this.window.scrollTo(0 , 0);
    this.source = this.basepath + 'assets/common/plus.png';
  }

  private changeSource(): void {
    if (!this.flag) {
      this.source = this.basepath + 'assets/common/minus.png';
      this.flag = !this.flag;
    } else {
      this.source = this.basepath + 'assets/common/plus.png';
      this.flag = !this.flag;
    }
  }
   public ngOnDestroy () {
    this.linkservice.removeCanonicalLink();
  }

}
