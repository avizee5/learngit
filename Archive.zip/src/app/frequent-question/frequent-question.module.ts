import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FrequentQuestionComponent } from './frequent-question.component';
import { DisplayComponent } from './display/display.component';
import {SharedModule} from '../shared.module';

const routes: Routes = [
    { path: '', component: FrequentQuestionComponent},

];


@NgModule({
  exports: [RouterModule],
  imports: [RouterModule.forChild(routes), CommonModule, SharedModule],
  declarations: [
  	FrequentQuestionComponent,
  	DisplayComponent
  ]
})
export class FrequentQuestionModule { }
