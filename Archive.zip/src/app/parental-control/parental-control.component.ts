import { Component, OnInit, HostListener, OnDestroy  } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { Router } from '@angular/router';
import { HeaderservicesService } from '../services/headerservices.service';
import { UserApiService } from '../services/user-api.service';
import { VideoService } from '../services/video.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { NetworkService } from '../services/network.service';
import { SettingsService } from '../services/settings.service';
import { RouteService } from '../services/route.service';
import * as $ from 'jquery';
import * as SettingsApi from '../../data/user/api/api';
import { Http } from '@angular/http';
import {environment} from '../../environments/environment';
import { LinkService } from '../services/link.service';
import { Subject } from 'rxjs/Subject';
declare const FB: any;
declare const gapi: any;
/* Angular Universal */
import { isPlatformBrowser } from '@angular/common';
import { Inject , PLATFORM_ID } from '@angular/core';

@Component({
	selector: 'app-parental-control',
	templateUrl: './parental-control.component.html',
	styleUrls: ['./parental-control.component.less']
})
export class ParentalControlComponent implements OnInit  {
  private ngUnsubscribe = new Subject<any>();
  private router: any;
  private router2: any;
  private pageName: any;
  private qualityTypes: any;
  private selectedQuality: Array<any> = [];
  private open: any;
  private closed: any;
  private settings: any;   /*JSON handling */
  private errorMessage: any;
  private userSettings: any;
  private updated_settings: any;
  private userToken: any;
  private key: any;
  private configValue: any;
  private localStorage: any;
  private window: any;
  private document: any;
  private navigator: any;
  private config: any;
  private response: any;
  private default_settings: any;
  private ageRating: any;
  private pin: any;
  private loged = false;
  private token: any;
  private fbToken: any;
  private user: any;
  private age_rating_value: any;
  private age_rating_string: any;
  private changePinFlag: any = false;
  private countries: any;
  private selected_country: any;
  // Asset basepath variable
  private assetbasepath = environment.assetsBasePath;
  public ageRatingArray: any;
  public saveToastMessage: any;
  private parental_object: any = {'U': 0, 'U/A': 1, 'A': 2 };
  private post_array: any = ['U', 'U/A', 'A'];
  public range: any = 2;
  constructor(private linkservice: LinkService, @Inject(PLATFORM_ID) private platformId: Object, private networkService: NetworkService, private routeservice: RouteService, private settingsService: SettingsService, private gtm: GoogleAnalyticsService, private videoService: VideoService, private userapiService: UserApiService, private headerservicesService: HeaderservicesService,  private routerVal: Router,  private http: Http) {
  	if (isPlatformBrowser(this.platformId)) {
  		this.localStorage = localStorage;
  		this.window = window;
  		this.document = document;
  		this.navigator = navigator;
  	}
  	this.routeservice.setLoginRoute(this.window.location.pathname);  /*Return back to this page on login relaod */
  	this.router = routerVal;
  	this.router2 = this.window.location.pathname;
  	this.headerservicesService.viewChange(this.router2);
          this.userapiService.saveToastMsg.takeUntil(this.ngUnsubscribe).subscribe(value => { // confirm of password
                this.saveToastMessage = value;
                setTimeout(() => {
                  this.showToast();
                }, 1);
          });
  }

  public ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.localStorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
    let breadcrump;
    breadcrump = [
      {
        'label': 'BREADCRUMB.HOME',
        'url': '/',
        'enable': true
      },
      {
        'label': 'PARENTAL_CONTROL.PARENTAL_CONTROL',
        'url': this.router2,
        'enable': false
      }
      ];
      this.headerservicesService.breadCrump(breadcrump);
    this.userToken = this.localStorage.getItem('token');
    this.age_rating_value = this.userapiService.getAgeRating();
    this.countries = this.settingsService.getcountryApiList();
       let selected_country_api, country;
   if (this.countries.length === 0) {
     this.settingsService.getCountryList().timeout(environment.timeOut).subscribe(value => {
       $('#loaderPage').css('display', 'none');
       this.settingsService.setCountryListValue(value);
       this.countries = value;
       selected_country_api = this.settingsService.getCountry();
       for (country in this.countries) {
         if (this.countries[country].code === selected_country_api) {
           this.selected_country = this.countries[country];
           this.setAgeRatings(this.selected_country);
           break;
         }
       }
     },
     err => {
       $('#loaderPage').css('display', 'none');
       let ageRating, configdata;
       configdata = this.settingsService.getCompleteConfig();
       ageRating = configdata.age_rating;
       this.ageRatingArray = [ageRating['U'] , ageRating['U/A'] , ageRating['A']];
       this.range = 2;
     }
     );
   } else {
     $('#loaderPage').css('display', 'none');
     selected_country_api = this.settingsService.getCountry();
     for (country in this.countries) {
       if (this.countries[country].code === selected_country_api) {
         this.selected_country = this.countries[country];
         this.setAgeRatings(this.selected_country);
         break;
       }
     }
   }
 /*  $(this.document).ready(function() {
     $('#passwordField').focus();
     if ($('#passwordField')) {
       $('#passwordField').keydown(function (e) {
      // Allow: backspace, delete, tab, escape, enter.
      if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
        // Allow: Ctrl+A, Command+A
        (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
        // Allow: home, end, left, right, down, up
        (e.keyCode >= 35 && e.keyCode <= 40)) {
          // let it happen, don't do anything
        return;
      }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
          e.preventDefault();
        }
      });
     }
     });  */
     $('#passwordField').on('input change paste', function filterNumericAndDecimal(event) {
        let formControl;
        formControl = $(event.target);
        formControl.val(formControl.val().replace(/[^0-9]+/g, ''));
    });

    this.userToken = this.localStorage.getItem('token');
    if (this.userToken) {
      let scope;
      scope = this;
      if (this.age_rating_value) {
        $('input[type=range]').val(this.parental_object[this.age_rating_value.age_rating]);
        $('#passwordField').val(this.age_rating_value.pin);
        setTimeout(() => {
          scope.refresh();
        }, 0);
    let percent1, val;
    val = $('input[type=range]').val();
    percent1 = val * 100 / 2;

    $('input[type=range]').css('background-image',
      '-webkit-gradient(linear, left top, right top, ' +
      'color-stop(' + percent1 + '%, #bf006b), ' +
      'color-stop(' + percent1 + '%, #6e6e6e)' +
      ')');
      }  else {
        // console.log('inside else' + this.age_rating_value);
        setTimeout(() => {
          scope.age_rating_value = scope.userapiService.getAgeRating();
          if (scope.age_rating_value) {
            $('input[type=range]').val(scope.parental_object[scope.age_rating_value.age_rating]);
            $('#passwordField').val(scope.age_rating_value.pin);
             setTimeout(() => {
            scope.refresh();
             }, 0);
          } else {
            $('input[type=range]').val(2);
            setTimeout(() => {
              scope.refresh();
            }, 0);
          }
    let percent1, val;
    val = $('input[type=range]').val();
    // console.log(val);
    percent1 = val * 100 / 2;
    // console.log(percent1);
    $('input[type=range]').css('background-image',
      '-webkit-gradient(linear, left top, right top, ' +
      'color-stop(' + percent1 + '%, #bf006b), ' +
      'color-stop(' + percent1 + '%, #6e6e6e)' +
      ')');
        }, 100);
      }
    } else {
      this.routerVal.navigate(['/']);
    }
 //   var percent1, val;
 //   val = $('input[type=range]').val();
 //   percent1 = val * 100 / 2;
  //  $('input[type=range]').css('background-image',
  //    '-webkit-gradient(linear, left top, right top, ' +
   //   'color-stop(' + percent1 + '%, #bf006b), ' +
   //   'color-stop(' + percent1 + '%, #6e6e6e)' +
   //   ')');
   if (/Edge/.test(navigator.userAgent)) {
    $('body').addClass('edgeBrowser');
  }
  }
  private setAgeRatings(selected_country: any) {
    this.ageRatingArray = [selected_country.age_rating['U'] , selected_country.age_rating['U/A'] , selected_country.age_rating['A']];
    this.range = 2;
  }
  public refresh() {
    $('input[type="range"]').on('change mousemove', function () {
      let val;
      val = ($(this).val() - $(this).attr('min')) / ($(this).attr('max') - $(this).attr('min'));
      $(this).css('background-image',
        '-webkit-gradient(linear, left top, right top, '
        + 'color-stop(' + val + ', #BF006B), '
        + 'color-stop(' + val + ', #6E6E6E)'
        + ')'
        );

    });
  }

  public saveChanges() {
    this.gtm.sendEventDetails({'event': 'userIconClick', 'UserMenu': 'submit'});
    let age;
    age = $('input[type=range]').val();
    if (this.userToken) {
      this.age_rating_value = this.userapiService.getAgeRating();
            if (!this.age_rating_value && this.age_rating_value !== null &&  $('#passwordField').val() && $('#passwordField').val().length === 4) {
                this.headerservicesService.parentalChange({'flag': true, 'type': 'savePin', 'requestData': {'requestType': 'post', 'pin': $('#passwordField').val(), 'age': age}});
            } else if (this.age_rating_value && $('#passwordField').val() && $('#passwordField').val().length === 4) {
                this.headerservicesService.parentalChange({'flag': true, 'type': 'savePin', 'requestData': {'requestType': 'put', 'pin': $('#passwordField').val(), 'age': age}});
            } else {
                this.saveToastMessage = 'PARENTAL_CONTROL.ENTER_PIN';
                this.showToast();
            }

    }

  }
  private showToast() {
    let p;
    p = this.document.getElementById('snackbar1');
    if (p) {
      p.className = 'show';
      setTimeout(function() { p.className = p.className.replace('show', ''); }, 3000);
    }
  }
  private checkLoginState() {
    let network;
    network = this.networkService.getPopupStatus();
    if (network === true) {
      FB.getLoginStatus(response => {
        this.statusChangeCallback(response);
      });
    }
  }
  private statusChangeCallback(response: any) {
    if (response.status === 'connected') {
      this.login();

    } else {
      this.login();
    }
  }
    // Load the SDK asynchronously

  // Here we run a very simple test of the Graph API after login is
  // successful.  See statusChangeCallback() for when this call is made.
  private login() {
    FB.login(result => {
      this.loged = true;
      this.token = result;
      if (this.token.authResponse != null) {
        this.fbToken = this.token.authResponse.accessToken;
      }
      this.me();
    }, { scope: 'public_profile,email' });
  }

  private me() {
    FB.api('/me?fields=id,name,first_name,email,gender,picture.width(150).height(150),age_range',
      function(result) {
        if (result && !result.error) {
          this.user = result;
        } else {
          // to do
        }
      });
  }
}
