import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared.module';
import { ParentalControlComponent } from './parental-control.component';

const routes: Routes = [
    {
        path: '',
        component: ParentalControlComponent,
    },
];
@NgModule({
  exports: [RouterModule],
  imports: [RouterModule.forChild(routes), CommonModule, SharedModule],
  declarations: [ParentalControlComponent]
})
export class ParentalControlModule { }


