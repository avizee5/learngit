import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HeaderEnrichmentComponent } from './header-enrichment.component';

describe('HeaderEnrichmentComponent', () => {
  let component: HeaderEnrichmentComponent;
  let fixture: ComponentFixture<HeaderEnrichmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HeaderEnrichmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderEnrichmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
