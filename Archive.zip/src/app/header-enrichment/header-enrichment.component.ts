import { Component, OnInit, OnDestroy } from '@angular/core';
import * as $ from 'jquery';
import { SettingsService } from '../services/settings.service';
import * as SettingsApi from '../../data/user/api/api';
import { Http } from '@angular/http';
import {environment} from '../../environments/environment';
import { UserApi } from '../../data/user/api/api';
import * as userApi from '../../data/user/api/api';
import { HeaderservicesService } from '../services/headerservices.service';
import { UseractionapiService } from '../services/useractionapi.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';

const try_later = 'MESSAGES.TRY_LATER';

@Component({
  selector: 'app-header-enrichment',
  templateUrl: './header-enrichment.component.html',
  styleUrls: ['./header-enrichment.component.less']
})
export class HeaderEnrichmentComponent implements OnInit, OnDestroy {
	private receivedValue: any;
	public registerscreen: any;
	public msisdnnumber: any;
	private config: any;
	private msisdnData: any;
	private countrycode: any;
	private userSettings: any;
	private userapi: any;
	private default_settings: any;
	private cookiesLocal: any;
	private marketingLocal: any;
	private responsevalue: any;
	public gdprValue =[];
	public gdprscreen: any;
	public version_number: any;
	public error_message: any = try_later;
	private user_token: any;
	private processing: any = false;
	private gdprValues: any = true;
  constructor( private http: Http, private userAction: UseractionapiService, private gtm: GoogleAnalyticsService, private settingsService: SettingsService, private headerservicesService: HeaderservicesService) { }

  public ngOnInit() {
  	this.gdprscreen = false;
    $('#body').addClass('scrolldisbale');
    this.cookiesLocal = localStorage.getItem('cookies');
    this.marketingLocal = localStorage.getItem('marketing');
    this.msisdnData =  this.settingsService.getMsisdnData();
		this.registerscreen = (this.msisdnData && this.msisdnData.user === 'new_user') ? true : false;
		this.msisdnnumber = this.msisdnData && this.msisdnData.msisdn ? this.msisdnData.msisdn : '';
		this.countrycode = this.settingsService.getCountry();
    this.version_number = navigator.userAgent;  // gdpr additional field version number while post
  }
  private acceptEnable() {
	  if (!(this.receivedValue.sendFlag)) {
  		this.gdprValues = false;
      // $('.Accept').css({'background-color': '#50012f', 'color': '#703055'});
      // return true;
    } else {
  		this.gdprValues = true;
      // $('.Accept').css({'background-color': '#bf006b', 'color': '#eeeeee'});
      // return false;
    }
	}
	private sendData(value) {
    this.receivedValue = value ;
    this.acceptEnable();
    setTimeout(function () {
      $('.loaderImage').css('display', 'none');
    }, 500);
	}
  public closeContainer(): any {
  	this.headerservicesService.robiuserChanges(false);
    $('body').css('pointer-events', '');
    $('#body').removeClass('scrolldisbale');
 	}
  private createObject(register): any {
	  let obj;
	  if (register) {
	  	let policyValues, googleObjInt, country_Promotion;
    	country_Promotion = this.settingsService.getCountryPromotionalValue();
    	policyValues = [];
	    for (let i = 0; i < 4; i++) {
        if (!(this.receivedValue.sendValues[i].status) || this.receivedValue.sendValues[i].status === undefined) {
            policyValues[i] = 'na';
        } else if (!(this.receivedValue.sendValues[i].userValue)) {
            policyValues[i] = 'no';
        } else if (this.receivedValue.sendValues[i].userValue === true) {
           policyValues[i] = 'yes';
        }
	    }
    	googleObjInt = {
    		'fname': '',
        'lname': '',
       	'additional': {
          'gdpr_policy': [{
            'country_code': this.countrycode,
            'gdpr_fields': {
              'policy': policyValues[0],
              'profiling': policyValues[1],
              'age': policyValues[2],
              'subscription': policyValues[3]
            }
          }],
          'guest_token': localStorage.getItem('guestToken'),
          'sourceapp' : 'Web',
          'version_number' : this.version_number,
          'promotional': {
            'on': country_Promotion.on,
            'token': country_Promotion.token
          },
          'first_time_login': '1'
        },
        'token': this.msisdnData.token
      };
    	obj = this.gtm.checkUpdateCampaign(googleObjInt);
  	} else {
  		obj = {
  			'token': this.msisdnData.token
  		};
  	}
    return obj;
  }
	public registerApi(): any {
  	this.processing = true;
    $('body').css('pointer-events', 'none');
		let data;
		data = this.createObject(true);
    this.userAction.robiRegistration(JSON.stringify(data)).subscribe(value => {
    	let regData;
    	regData = JSON.parse(value._body);
    	if (regData && regData.data && regData.data.access_token) {
    		this.user_token = regData.data.access_token;
				this.updatedefaultSettings(regData.data.access_token);
        this.GAUpdateCommon('RegisterSuccess', 'mobile');
    	} else {
				this.error_message = (regData || {}).message || try_later;
    		this.callToast();
    	}
		}, err => {
				if (err.name === 'TimeoutError') {
					this.error_message = try_later;
				} else {
					err = err.json();
					this.error_message = err.error_message || try_later;
				}
        this.GAUpdateCommon('RegisterFailed', 'mobile');
        this.gtm.sendErrorEvent('api', err);
    		this.callToast();
		});
	}

	public loginApi(): any {
		this.processing = true;
    $('body').css('pointer-events', 'none');
		let data;
		data = this.createObject(false);
		this.userAction.robiLogin(JSON.stringify(data)).subscribe(value => {
			let loginData;
    	loginData = JSON.parse(value._body);
    	if (loginData && loginData.data && loginData.data.access_token) {
    		this.user_token = loginData.data.access_token;
				this.checksettings(loginData.data.access_token);
        this.GAUpdateCommon('LoginSuccess', 'mobile');
			} else {
				this.error_message = (loginData || {}).message || try_later;
    		this.callToast();
        this.closeContainer();
			}
		}, err => {
        if (err.name === 'TimeoutError') {
					this.error_message = try_later;
				} else {
					err = err.json();
					this.error_message = err.error_message || try_later;
				}
        this.GAUpdateCommon('LoginFailed', 'mobile');
        this.gtm.sendErrorEvent('api', err);
    		this.callToast();
		});
	}
  	private updatedefaultSettings(token): any {
  		if (token) {
			let params;
			params = 'bearer ' + token ;
			this.config = {
					apiKey: params,
					username: '',
					password: '',
					accessToken: '',
					withCredentials: false
			};
		}
		let policyValues;
		policyValues = [];
		for (let i = 0; i < 4; i++) {
				if (!(this.receivedValue.sendValues[i].status) || this.receivedValue.sendValues[i].status === undefined) {
						policyValues[i] = 'na';
				} else if (!(this.receivedValue.sendValues[i].userValue)) {
						policyValues[i] = 'no';
				} else if (this.receivedValue.sendValues[i].userValue === true) {
					 policyValues[i] = 'yes';
				}
		}
		this.countrycode = this.settingsService.getCountry();
		let gdprValue;
			gdprValue = [{
							'country_code': this.countrycode,
							'gdpr_fields': {
									'policy': policyValues[0],
									'profiling': policyValues[1],
									'age': policyValues[2],
									'subscription': policyValues[3]
								}
							}];

		this.default_settings = [
            {key: 'display_language', value: localStorage.getItem('display_language') },
            {key: 'content_language', value: localStorage.getItem('ContentLang') },
            {key: 'streaming_quality', value: 'Auto' },
            {key: 'auto_play', value: 'true' },
            {key: 'download_quality', value: '0' },
            {key: 'recent_search', value: '' },
            {key: 'stream_over_wifi', value: 'false' },
            {key: 'download_over_wifi', value: 'false' },
            {key: 'gdpr_policy', value: JSON.stringify(gdprValue)}];

          	for (let i = 0; i < 9 ; i++) {
	            const defaultsettings = {
	              'key': this.default_settings[i].key,
	              'value': this.default_settings[i].value
	            };
	            let k;
	            k = i;
	            this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
	            this.userSettings.v1SettingsPost(defaultsettings).subscribe(responsePost => {
	              if ( k === (this.default_settings.length - 1)) {
	                localStorage.setItem('googletag', 'false');
	              }
	            }, err => {

	            });
			}
	        this.cookiecall(token);
  	}
  	private getuserdata(token): any {
      let userDetails;
      userDetails = new UserApi(this.http, null, this.config);
      userDetails.v1UserGet().timeout(environment.timeOut).subscribe(uservalue => {
      	this.reload(uservalue.id, token);
      }, err => {
      	this.reload('NA', token);
      });
  	}
  	private reload(id, token): any {
  	  let previousUrl;
  	  previousUrl = localStorage.getItem('previousRoute');
  	  localStorage.setItem('ID', id );
      localStorage.setItem('login', 'Mobile');
      localStorage.setItem('token', token);
      location.href = window.location.origin + previousUrl;
  	}
  	private cookiecall(token): any {
	  	this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
	  	this.userSettings.v1SettingsGet().subscribe( response => {
		    this.cookieConcent(response);
		    this.getuserdata(token);
	    }, err => {
	        this.gtm.sendErrorEvent('api', err);
	      	this.reload('NA', token);
	    });
  	}
  	private cookieConcent(settingValue) {
	    if (this.cookiesLocal === null || undefined) {
	      this.cookiesLocal = 'na';
	    }
	    if (this.marketingLocal === null || undefined) {
	      this.marketingLocal = 'na';
	    }
	    let popup, popupValue, oldCookie, oldRTRM;
	    if ( settingValue.length > 0) {
	      for (let i = 0; i < settingValue.length; i++) {
	        if ( settingValue[i].key === 'popups') {
	          popup = true;
	          this.responsevalue = JSON.parse(settingValue[i].value);
	          oldCookie = this.responsevalue[0].Cookies;
	           oldRTRM = this.responsevalue[0].RTRM;
	           if (this.responsevalue[0].Cookies === 'na' && this.responsevalue[0].RTRM === 'na' ) {
	            popupValue = [{'Cookies': this.cookiesLocal, 'RTRM': this.marketingLocal}];
	            const cookies_settings = {
	              'key': 'popups',
	              'value': JSON.stringify(popupValue)
	            };
	            this.userSettings.v1SettingsPut(cookies_settings).subscribe(responseput => {
	              // nothing
	            });
	           } else if (this.responsevalue[0].RTRM === 'na' || this.responsevalue[0].Cookies === 'na') {
	            if (this.responsevalue[0].RTRM === 'na') {
	              popupValue = [{'Cookies': oldCookie, 'RTRM': this.marketingLocal}];
	            }
	            if (this.responsevalue[0].Cookies === 'na') {
	              popupValue = [{'Cookies': this.cookiesLocal, 'RTRM': oldRTRM}];
	            }
	            const cookies_settings = {
	            'key': 'popups',
	            'value': JSON.stringify(popupValue)
	            };
	            this.userSettings.v1SettingsPut(cookies_settings).subscribe(responseput => {
	              // nothing
	            });
	          }

	        }
	      }
	      if (popup === undefined) {
	        let popupValue1;
	        popupValue1 = [{'Cookies': this.cookiesLocal, 'RTRM': this.marketingLocal}];
	        const cookies_settings = {
	          'key': 'popups',
	          'value': JSON.stringify(popupValue1)
	        };
	        this.userSettings.v1SettingsPost(cookies_settings).subscribe(responsePost => {
	        // todo
	        });
	        // post
	      }
	    } else {
	      let popupValue2;
	        popupValue2 = [{'Cookies': this.cookiesLocal, 'RTRM': this.marketingLocal}];
	        const cookies_settings = {
	        'key': 'popups',
	        'value': JSON.stringify(popupValue2)
	        };
	       this.userSettings.v1SettingsPost(cookies_settings).subscribe(responsePost => {
	         // todo
	       });
	    }
  	}
  	private checksettings(token): any {
		if (token) {
			let params;
			params = 'bearer ' + token ;
			this.config = {
					apiKey: params,
					username: '',
					password: '',
					accessToken: '',
					withCredentials: false
			};
			this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
			    this.userSettings.v1SettingsGet().subscribe( response => {
				 this.cookieConcent(response);
				this.countrycode = this.settingsService.getCountry();
					let gdpr_Flag;
					if ( response.length > 0) {
						for (let i = 0; i < response.length; i++) {
							if ( response[i].key === 'gdpr_policy') {
								gdpr_Flag = true;
							   if (!(response[i].value[0] === '{')) {
									this.gdprValue = JSON.parse(response[i].value);
									let flagcheck = false;
									for (let j = 0; j < this.gdprValue.length; j++) {
									 if (this.countrycode === this.gdprValue[j].country_code) {
										flagcheck = true;
										break;
									 } else if (j === this.gdprValue.length - 1) {   // no country code match so show GDPR screen with put request
											flagcheck = false;
										}
									 }
									 if (flagcheck) {
										 this.getuserdata(token);
									 } else {
										this.showScreen(token);
									 }
									} else {
									    this.userSettings.v1SettingsDelete('gdpr_policy', token).subscribe(responseput => {
											this.showScreen(token);
										});
								 	}
							}
						}
						if (gdpr_Flag === undefined) {
							this.showScreen(token);
						}
					} else {
						if (gdpr_Flag === undefined) {
							this.showScreen(token);
						}
					}
				}, err => {
	        this.gtm.sendErrorEvent('api', err);
	      	this.reload('NA', token);
				});
		}
  	}
  	private showScreen(token): any {
  		this.processing = false;
  		this.gdprValues = true;
  		this.gdprscreen = true;
      $('body').css('pointer-events', '');
  	}
  	public acceptbutton(): any {
  		this.processing = true;
      $('body').css('pointer-events', 'none');
  		this.updatesettings(this.user_token);
  	}
  	private updatesettings(token): any {
  		if (token) {
			let params;
			params = 'bearer ' + token ;
			this.config = {
					apiKey: params,
					username: '',
					password: '',
					accessToken: '',
					withCredentials: false
			};
		}
		this.countrycode = this.settingsService.getCountry();
		let policyValues;
		policyValues = [];
		for (let i = 0; i < 4; i++) {
				if (!(this.receivedValue.sendValues[i].status) || this.receivedValue.sendValues[i].status === undefined) {
						policyValues[i] = 'na';
				} else if (!(this.receivedValue.sendValues[i].userValue)) {
						policyValues[i] = 'no';
				} else if (this.receivedValue.sendValues[i].userValue === true) {
					 policyValues[i] = 'yes';
				}
		}
		let gdprValue1, gdprsettings;
		gdprValue1 = {
						'country_code': this.countrycode,
						'gdpr_fields': {
							'policy': policyValues[0],
							'profiling': policyValues[1],
							'age': policyValues[2],
							'subscription': policyValues[3]
						}
					};
		this.gdprValue.push(gdprValue1);
		gdprsettings = {
					'key': 'gdpr_policy',
					'value': JSON.stringify(this.gdprValue)
		};
		this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
		this.userSettings.v1SettingsPut(gdprsettings).subscribe(responsePost => {
  			this.getuserdata(token);
  		}, err => {
        this.gtm.sendErrorEvent('api', err);
  			this.getuserdata(token);
		});
  	}
  private GAUpdateCommon(gAevent, loginMethod) {    ///  GA event = LoginSuccess/registerFailure  /// loginMethod = fb,g+,tw,mob,em
    let sendData;
    sendData = {
      'event' : gAevent,
      'G_ID' : this.gtm.fetchToken(),
      'Client_ID': this.gtm.fetchClientId(),
      'retargeting_remarketing' : this.gtm.fetchMarketing(),
      'LoginMethod' : loginMethod,
      'operator': 'Robi',
      'TimeHHMMSS': this.gtm.fetchCurrentTime(),
      'DateTimeStamp': this.gtm.fetchCurrentDate()
    };
    this.gtm.appendPara(gAevent, sendData);
  }
	private callToast() {
    let p, scope;
    scope = this;
    p = document.getElementById('he_error');
    p.className = 'show';
    setTimeout(function() {
    	p.className = p.className.replace('show', '');
      scope.closeContainer();
    }, 2000);
  }
	public ngOnDestroy(): any {
		this.closeContainer();
	}
}
