import { Component, OnInit , Input, Output, EventEmitter, OnDestroy, HostListener} from '@angular/core';
import {environment} from '../../environments/environment';
import * as $ from 'jquery';
import { SubscriptionService } from '../services/subscription.service';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { HeaderservicesService } from '../services/headerservices.service';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/takeUntil';
import { RouteService } from './../services/route.service';
@Component({
  selector: 'app-free-episode-popup',
  templateUrl: './free-episode-popup.component.html',
  styleUrls: ['./free-episode-popup.component.less']
})
export class FreeEpisodePopupComponent implements OnInit, OnDestroy {
  public assetbasepath: any;
  public termsUrl: any;
  public privacyUrl: any;
  public displayComponent: any;
  public changeButton  = false;
  public showBtn = true;
  @Output() public changestatusScreen: EventEmitter<boolean> = new EventEmitter<boolean>();
  private ngUnsubscribe = new Subject<any>();

  constructor(private subscription: SubscriptionService,
    private routeActivated: ActivatedRoute,
    private routerVal: Router,
    private headerservicesService: HeaderservicesService, private routeService: RouteService) {
    this.headerservicesService.storeSelectedPack.subscribe( value => {
        this.changeButton = true;
      });
    this.headerservicesService.upgradeBtn .subscribe( value => {
      this.showBtn = value;
      if (!this.showBtn) {
          $('.auto-loader_free').css('display', 'none');
      }
      });
  }
  public ngOnInit() {
    $('#body').addClass('scrolldisbale');
    this.assetbasepath = environment.assetsBasePath;
    let displayLan;
    displayLan  = this.routeService.getcurrentLanguage();
    this.termsUrl = `${displayLan}/termsofuse`;
    this.privacyUrl = `${displayLan}/privacypolicy`;
  }
	public closeSession(): any {
    	this.changestatusScreen.emit(false);
	}
  @HostListener('window:popstate', ['$event'])
  public onPopState(event) {
        this.closeSession();
  }
	public ngOnDestroy(): void {
    $('#body').removeClass('scrolldisbale');
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  public proceedClick(): any {
    if (!this.changeButton) {
      return;
    }
    this.subscription.storeUpgradePackSelect(true);
    // this.headerservicesService.callUpgradePopup(false);
    this.headerservicesService.subscribeReminderChange(true);

              // navigate to billing info
     this.subscription.storeSwitchAccIndex(1);
         this.routeActivated.queryParams.takeUntil(this.ngUnsubscribe).subscribe(params => {
        this.routerVal.navigate(['myaccount/subscription'], {queryParams: params});
      });
         this.displayComponent = {
         'planComp': false,
         'subComp': true,
         'payComp': false,
         'historyComp': false
      };
        this.subscription.storePlanCompFlag(this.displayComponent);
  }
}
