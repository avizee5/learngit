import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FreeEpisodePopupComponent } from './free-episode-popup.component';

describe('FreeEpisodePopupComponent', () => {
  let component: FreeEpisodePopupComponent;
  let fixture: ComponentFixture<FreeEpisodePopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FreeEpisodePopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FreeEpisodePopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
