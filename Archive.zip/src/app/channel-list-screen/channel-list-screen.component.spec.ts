import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChannelListScreenComponent } from './channel-list-screen.component';

describe('ChannelListScreenComponent', () => {
  let component: ChannelListScreenComponent;
  let fixture: ComponentFixture<ChannelListScreenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChannelListScreenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChannelListScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
