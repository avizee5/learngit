import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared.module';
import { ChannelListScreenComponent } from '../channel-list-screen/channel-list-screen.component';
import { ChannelListGridComponent } from '../channel-list-grid/channel-list-grid.component';
import { FilterModule } from '../filter/filter.module';
import { SortModule } from '../sort/sort.module';
import { MdGridListModule } from '@angular/material';
const routes: Routes = [
    { path: '', component: ChannelListScreenComponent},

];
@NgModule({
 exports: [RouterModule],
  imports: [RouterModule.forChild(routes),
  CommonModule,
  SharedModule,
  FilterModule,
  SortModule,
  MdGridListModule
  ],
  declarations: [ChannelListScreenComponent, ChannelListGridComponent]
})
export class ChannelListScreenModule {

}
