import { Component, OnInit, ViewChild, ElementRef, HostListener, OnDestroy} from '@angular/core';
import { Headers, Http, RequestOptions } from '@angular/http';
import * as $ from 'jquery';
import { FilterService } from '../services/filter.service';
import { WindowRefService } from '../services/window-ref.service';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { HeaderservicesService } from '../services/headerservices.service';
import { Router, ActivatedRoute } from '@angular/router';
// import * as api from '../../data/catalog/api/api';
import { ChannelApi } from '../../data/catalog/api/ChannelApi';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import {  NetworkService  } from '../services/network.service';
import { RouteService } from '../services/route.service';
import { Subject } from 'rxjs/Subject';
import {environment} from '../../environments/environment';
import 'rxjs/add/operator/timeout';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { LinkService } from '../services/link.service';
import { CommonService } from '../services/common.service';
const freeChannelTag = 'free_channels';


@Component({
  selector: 'app-channel-list-screen',
  templateUrl: './channel-list-screen.component.html',
  styleUrls: ['./channel-list-screen.component.less']
})


export class ChannelListScreenComponent implements OnInit, OnDestroy {

    public data: any;
    private router: any;
    private router2: any;
    public channel: Array<any>;
    private cols_number: number;
    public gutter_size: any;
    private windown_width: any;
    public selectedFilters: any;
    public sortbar = false;
    public filterbar = false;
    public filter_titles: any;
    public view: any = 'channels';
    public alphabet: boolean;
    private temp: Array<any> = [];
    public alphabets: any;
    public sortedarray: Array<any> = [];
    private index: number;
    private limit: number;
    private sortedarray_sliced: any;

    // for load more
     private showLoadMore: boolean;
     private load_count: number;
     private total_pages: number;

     // for filter api
     private languages: any;
     private category: any;
     private destroyFilter: Subscription;

     // no data avaoilabe;
     public showNoDataAvailable: boolean;
     private allChannelList: any;
     private totalChannelpages: any;
     private channelPageSize: number;
     private totalChannels: any;

     // tempChannels
     private tempchannels: any;
     private filteredlist: any;
     public filterFlag = false;
     private pageName: any;
     private sortcheck: any;
     private destroySort: any;
     private sorttype: any = null;
     private firstcall = false;
     public assetbasepath: any;
     private localstorage: any;
     private window: any;
     private document: any;
     private navigator: any;
     private sort_order: any;
     private channelsBreadCrump: any;
    private ngUnsubscribe = new Subject<any>();
    public isNewsPage = false;
    public freeChannels = false;
    public freeChannelTitle: any;
    public updateGenreCalled: any = false;
  @ViewChild('load_button') public load_button: ElementRef;
 private windowref: any;
 private checkScreenWidth() {    // depending on size number of grids
    if (this.window.innerWidth < 1180 && this.window.innerWidth >= 927) {
       return this.cols_number = 4;
    } else if (this.window.innerWidth <= 768 && this.window.innerWidth >= 481) {
       return  this.cols_number = 3;
    } else if (this.window.innerWidth >= 1300) {
       return this.cols_number = 6;
    } else if (this.window.innerWidth <= 480) {
      if (this.selectedFilters === 0) {
       $('.grid').css({'margin-top': '-120px'});
      } else {
       $('.grid').css({'margin-top': '-10px'});
       return this.cols_number = 2;
      }
    } else if (this.window.innerWidth <= 1300 && this.window.innerWidth >= 1181 ) {
       return this.cols_number = 5;
    } else if (this.window.innerWidth <= 928 && this.window.innerWidth >= 769) {
       return this.cols_number = 3;
    }
  }
constructor (private linkservice: LinkService, @Inject(PLATFORM_ID) private platformId: Object, private routeservice: RouteService, private networkService: NetworkService, private gtm: GoogleAnalyticsService, private activatedRoute: ActivatedRoute, private route: Router, private headerservicesService: HeaderservicesService, private filterService: FilterService, private windowRef: WindowRefService, private http: Http, public commonService: CommonService) {
        if (isPlatformBrowser(this.platformId)) {
          this.localstorage = localStorage;
          this.window = window;
          this.document = document;
          this.navigator = navigator;
        }
      this.isNewsPage = this.commonService.getNewsPage();
       this.routeservice.setLoginRoute(this.window.location.pathname);
       this.destroySort = this.filterService.configSortObservable.subscribe(value => {
         this.sortcheck = value;  // sort=0 r popularity=1
         if (value === 0) {
           this.alphabet = false;
         } else if (value === 1) {
           this.alphabet = true;
         }
         if (this.firstcall) {   // load more
           this.getSortchannels(value);
         }
         if (value === 0 && this.selectedFilters.length === 0) {  // css adjust when clear all
          this.adjustAllchannels();
         } else if (value === 1 && this.selectedFilters.length === 0 ) { //
        }
     });
    this.destroyFilter = this.filterService.configObservable.subscribe(value => {
    this.selectedFilters = value;
    if (this.selectedFilters.length >= 0) {
      $('#loaderPage').css('display', 'block');
      setTimeout(() => {
        this.load_count = 1;
        this.updateGenre();
      }, 1000);
    } else {
      $('#loaderPage').css('display', 'none');

      this.load_count = 1;
      if (this.allChannelList !== null) {
        if (this.allChannelList.length === 0) {
          this.showError();
        } else {
        this.groupArray();
        this.showNoDataAvailable = false;
         setTimeout(() => {
         $('#loaderPage').css('display', 'none');
         }, 500);
        }
      }
    }
    if (value.length === 0) {
      this.adjustAllchannels();
    } else {
      // todo
    }
    });

    this.windowref = windowRef.nativeWindow;
    this.router = route;
    this.router2 = window.location.pathname;
    this.headerservicesService.viewChange(this.router2);
    this.assetbasepath = environment.assetsBasePath;
    this.activatedRoute.queryParams.subscribe(queryparams => {
      if (queryparams['type'] && queryparams['type'] === freeChannelTag) {
        this.freeChannels = true;
        this.freeChannelTitle = sessionStorage.getItem('freeChannelTitle');
        if (this.updateGenreCalled) {
          this.updateGenre();
        }
      } else if (this.freeChannels) {
        this.freeChannels = false;
        if (this.updateGenreCalled) {
          this.updateGenre();
        }
      }
    });
  }

  public ngOnInit() {
    this.gtm.storeWindowError();
    let network;
    this.channelsBreadCrump = [
        {
          'label': 'BREADCRUMB.HOME',
          'url': '/',
          'enable': true
        },
        {
          'label': 'BREADCRUMB.CHANNELS',
          'url': '/channels',
          'enable': false
        }
      ];
      this.headerservicesService.breadCrump(this.channelsBreadCrump);
    this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'channels'  } );
    $('#outer').css('z-index', '1');
    network = this.networkService.getScreenStatus();
    if (network === true) {
    this.cols_number = this.checkScreenWidth();
    this.window.scrollTo(0, 0);
     this.pageName = 'channels';
     this.gtm.sendPageName(this.pageName);
     this.gtm.sendEvent();
     this.showLoadMore = false;
     this.load_count = 1;
    this.alphabets = ['&', '0-9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'G', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];

  this.filter_titles = [{'code': '2', 'name': 'DETAILS.GENRE'}, {'code': '1', 'name': 'COMMON.LANGUAGE'}];
    this.gutter_size = '30px';
    /*API Integration for Channel List*/
    $('#loaderPage').css('display', 'block');
    }
  }

    public openSort(): void {
      let network;
      network = this.networkService.getPopupStatus();
      if (network === true) {
      this.sortbar = true;
     }
   }

   public showError() {
     this.showNoDataAvailable = true;
      $('#loaderPage').css('display', 'none');
   }

    public closeSort(event): void {
      this.sortbar = false;
     if (this.sortcheck === 0 && this.selectedFilters.length === 0) {
          this.adjustAllchannels();
      } else if (this.sortcheck === 1 && this.selectedFilters.length === 0 ) {
         this.updateCss();
        }
   }
    public onResize(event) {
      if (event.target.innerWidth < 1180 && event.target.innerWidth > 928) {
        this.cols_number = 4;
      } else if (event.target.innerWidth <= 768 && event.target.innerWidth > 481) {
        this.cols_number = 3;
        if (this.selectedFilters.length === 0 && this.channel.length > 30) {
        $('.grid').css({'margin-top': '-60px'});
        } else if (this.selectedFilters.length === 0 && this.channel.length < 10 ) {
        $('.grid').css({'margin-top': '0px'});
        } else {
         $('.grid').css({'margin-top': '-20px'});
        }
      } else if (event.target.innerWidth >= 1300 && event.target.innerWidth < 1599) {
        this.cols_number = 6;
        if (this.channel.length < 12) {
        $('.grid').css({'margin-top': '0px'});
        } else {
        $('.grid').css({'margin-top': '-15px'});
        }
        } else if (event.target.innerWidth > 1600) {
          $('.grid').css({'margin-top': '-45px'});
      } else if (event.target.innerWidth <= 480) {
        this.cols_number = 2;
        if (this.channel.length <= 10) {
      $('.grid').css({'margin-top': '0px'});
        } else if (this.channel.length <= 35 ) {
      $('.grid').css({'margin-top': '-20px'});
    } else if (this.channel.length <= 55 ) {
      $('.grid').css({'margin-top': '-60px'});
    } else {
      $('.grid').css({'margin-top': '-125px'});
    }
      } else if (this.window.innerWidth < 1300 && this.window.innerWidth > 1181 ) {
        $('.grid').css({'margin-top': '-15px'});
       this.cols_number = 5;
      } else if (this.window.innerWidth < 927 && this.window.innerWidth > 769) {
       return this.cols_number = 3;
    }
 }

    public openfilterNav(): void {
      let network;
      network = this.networkService.getPopupStatus();
      if (network === true) {
            this.filterbar = true;
     }
   }
    public closeFilter = function(event) {
      this.filterbar = false;
    };
      public getSortchannels(sort): void {   // to select sort r popularity
      switch (sort) {
    case 0:
      if (this.firstcall) {
      $('#loaderPage').css('display', 'block');
      this.alphabet = false;
      this.updateGenre();
       }
      break;
    case 1:
      $('#loaderPage').css('display', 'block');
      this.alphabet = true;
      this.updateGenre();
      break;
    default:
       break;
    }
  }

 @HostListener('window:scroll', ['$event']) public onScrollEvent($event) {
let factor;
  factor = 0.98;
  if ($(this.window).scrollTop() >= ($(this.document).height() - $(this.window).height()) * factor) {
    if (this.showLoadMore) {
        this.loadMore();
      }
    }
 }
private updateGenre() {
  this.updateGenreCalled = true;
        this.languages = this.filterService.getSelectedLanguage();
        this.category = this.filterService.getSelectedGenre();
          if (this.alphabet) {
            this.sorttype = 'original_title';
            this.channelPageSize = 1000;
            this.load_count = 1;
            this.sort_order = 'ASC';
          } else {
            this.sorttype = 'channel_number';
            this.channelPageSize = 100;
            this.sort_order = null;
          }

          if (this.category.length > 0 ) {
            if (this.isNewsPage) {
              this.category = 'News';
            }
            this.update();
          } else {

        let  z;
         // z = new api.ChannelApi(this.http, null, null);  // genres list
         z = new ChannelApi(this.http, null, null);  // genres list
        z.v1ChannelByIdGet('genres').takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
         let data;
         data = value;
         if (data.genres) {
           if (this.isNewsPage) {
             data.genres = [{id: 'News', value: 'News'}];
             this.category = 'News';
           } else {
             this.category = this.filterService.getIds(data.genres);
             this.filterService.setChannelsGenre(data.genres);
           }
        }
        this.update();
      }, error => {
          this.update();
          this.gtm.sendErrorEvent('api', error);

        });
          }

}
private update(): void {   // channlist screen main api
      let config;
      config = {
        apiKey: '',
        username: '',
        password: '',
        accessToken: '',
        withCredentials: false
      };
      let x;
      // x = new api.ChannelApi(this.http, null, config);
      x = new ChannelApi(this.http, null, config);
      x.v1ChannelGet(this.sorttype, this.sort_order, null, this.channelPageSize, this.category, null, this.languages).timeout(environment.timeOut).subscribe(value => {
        if (this.freeChannels && value && value.items && value.items.length) {
          value.items = value.items.filter((val) => {
            return val.business_type.indexOf('premium') === -1;
          });
        }
        this.data = value;
        this.filterFlag = true;
        this.totalChannels = value.total;
        this.totalChannelpages = Math.ceil((this.data.total) / (this.channelPageSize));
        if (this.data.items != null) {
          if (this.data.items.length === 0) {
            this.showNoDataAvailable = true;
          } else {
            this.showNoDataAvailable = false;
                     setTimeout(() => {
                       this.window.scrollTo(0, 0);
                              }, 500);

          }
          this.channel = this.data.items;
          setTimeout(() => {
            this.window.scrollTo(0, 0);
          }, 0);
            if (value.total <= 0 || value.total <= this.channelPageSize - value.total ) {
              this.showLoadMore = false;
            } else {
              this.showLoadMore = true;
            }
          }
          if (this.alphabet) {
            this.groupArray();
          }
         setTimeout(() => {
       $('#loaderPage').css('display', 'none');
       }, 500);
         if (this.selectedFilters.length > 0) {
         this.updateCss();
         } else if (this.selectedFilters.length === 0 && this.alphabet === false) {
           this.adjustAllchannels();
         }
         this.firstcall = true;
         setTimeout(() => {
           $(this.window).scrollTop(0);
           }, 500);
      },
      err => {

        if (err.name === 'TimeoutError') {
        this.showNoDataAvailable = true;
        } else {
        if (err.status === 403 || 404) {
        this.showNoDataAvailable = true;
        }
      }
        $('#loaderPage').css('display', 'none');
        this.gtm.sendErrorEvent('api', err);
       });

 }
  private groupArray (): void {
    let idx;
    this.sortedarray = [];
      for (let i = 0; i < this.channel.length; i++) {
        let char1;
        char1 = (this.channel[i].original_title).charAt(0).toUpperCase();
        this.temp = [];
             if (char1 >= 'A' && char1 <= 'Z') {
                 idx = this.alphabets.indexOf(char1);
              } else if ((char1 >= '0' && char1 <= '9')) {
                  idx = 1;
              } else {
                  idx = 0;
         }
        if (this.sortedarray[idx]) {
          this.temp = this.sortedarray[idx];
          this.temp.push(this.channel[i]);
        } else {
           this.temp.push(this.channel[i]);
        }
           this.sortedarray[idx] = this.temp;
      }
}
private loadMore() {
       if (this.load_count < this.totalChannelpages) {
         $('.auto-loader').css('display', 'block');
            this.load_count ++;
            let x;
                x = new ChannelApi(this.http, null, null);
                // x = new api.ChannelApi(this.http, null, null);
                x.v1ChannelGet(null, null, this.load_count, this.channelPageSize, this.category, null, this.languages).timeout(environment.timeOut).subscribe(value => {
                if (value != null) {
                  if (this.freeChannels && value && value.items && value.items.length) {
                    value.items = value.items.filter((val) => {
                      return val.business_type.indexOf('premium') === -1;
                    });
                  }
                  this.channel = this.channel.concat(value.items);
                }

        }, err => {
            if (err.name === 'TimeoutError') {
                 this.showNoDataAvailable = true;
          }
          this.gtm.sendErrorEvent('api', err);
        });
                setTimeout(() => {
       $('.auto-loader').css('display', 'none');
       }, 500);
       }
}
  private sortArray(): void {   // A to z sort
     if (this.selectedFilters.length > 0) {
     this.allChannelList.sort(function(a, b) {
        if (a.title < b.title) {
            return -1;
          } else if ( a.title > b.title) {
            return 1;
        } else {
            return 0;
        }
    });
   } else {
       this.channel = this.allChannelList;
       this.channel.sort(function(a, b) {
        if (a.title < b.title) {
            return -1;
          } else if ( a.title > b.title) {
            return 1;
        } else {
            return 0;
        }
    });
   }
     this.groupArray();
  }
private adjustAllchannels() {
  if (this.window.innerWidth < 480) {
    $('.grid').css({'margin-top': '-120px'});
  } else if (this.window.innerWidth < 769) {
    $('.grid').css({'margin-top': '-80px'});
  } else if (this.window.innerWidth < 928) {
    $('.grid').css({'margin-top': '-100px'});
  }
}

private updateCss() {
  if (this.window.innerWidth < 480) {
    if (this.channel.length <= 10) {
      $('.grid').css({'margin-top': '0px'});
        } else if (this.channel.length <= 35 ) {
      $('.grid').css({'margin-top': '-20px'});
    } else if (this.channel.length <= 55 ) {
      $('.grid').css({'margin-top': '-60px'});
    } else {
      $('.grid').css({'margin-top': '-125px'});
    }
  } else if (this.window.innerWidth >= 1300 && this.window.innerWidth < 1599) {
     if (this.channel.length <= 18) {
        $('.grid').css({'margin-top': '0px'});
        } else {
        $('.grid').css({'margin-top': '-25px'});
        }
  } else if (this.window.innerWidth >= 481 && this.window.innerWidth < 769) {
      if (this.channel.length < 15) {
        $('.grid').css({'margin-top': '0px'});
      } else if (this.channel.length < 35) {
        $('.grid').css({'margin-top': '-40px'});
      } else if (this.channel.length > 50) {
        $('.grid').css({'margin-top': '-80px'});
      }
  } else if (this.window.innerWidth >= 769 && this.window.innerWidth < 927) {
        if (this.channel.length < 15) {
        $('.grid').css({'margin-top': '0px'});
      } else if (this.channel.length < 35) {
        $('.grid').css({'margin-top': '-40px'});
      } else if (this.channel.length > 50) {
        $('.grid').css({'margin-top': '-80px'});
      }
  }
}

  public allChannels(): any {
    this.route.navigate(['channels']);
  }

  public ngOnDestroy() {
  $('#outer').css('z-index', '');
  this.destroyFilter.unsubscribe();
  this.destroySort.unsubscribe();
  this.firstcall = false;
  this.linkservice.removeCanonicalLink();
  this.commonService.setNewsPage(false);
  this.category = [];
  }

}
