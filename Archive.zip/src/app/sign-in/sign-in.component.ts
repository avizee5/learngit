import { Component, OnInit, Input, Output, HostListener, EventEmitter, ElementRef, AfterViewChecked, OnDestroy, ViewChild } from '@angular/core';
import { HeaderservicesService } from '../services/headerservices.service';         // importing explorecomponent to perform outside click function
import { Subscription } from 'rxjs/Subscription';
import * as $ from 'jquery';
import { PlatformLocation } from '@angular/common';
import { Router , NavigationEnd , ActivatedRoute  } from '@angular/router';
import { RouteService } from '../services/route.service';
import { Location } from '@angular/common';
import { Http } from '@angular/http';
import * as userApi from '../../data/user/api/api';
import {environment} from '../../environments/environment';
declare const FB: any;
// declare const gapi: any;                              // G+ sigin api call variable
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import {  NetworkService  } from '../services/network.service';
import {UserApi } from '../../data/user/api/UserApi';
import 'rxjs/add/operator/timeout';
declare const qg;
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { SettingsService } from '../services/settings.service';
import * as SettingsApi from '../../data/user/api/api';
import { UseractionapiService } from '../services/useractionapi.service';
import { LinkService } from '../services/link.service';
import { SeoService } from '../services/seo.service';
import {CommonService} from '../services/common.service';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.less']
})
export class SignInComponent implements OnInit, AfterViewChecked, OnDestroy {
@Output() public emitGdpr: EventEmitter<any> = new EventEmitter<any>();
private GOOGLE_CLIENT_ID = environment.GOOGLE_CLIENT_ID;
public authenticationCode: any;
private registerHeadingFlag = true;
private loginHeadingFlag = false;
public signinDetailsFlag  = false;
private socialSectionFlag = false;
private loginComponentFlag = false;
private registerMobileFlag = false;
private loginMobileFlag = false;
private registerEmailFlag = false;
private loginEmailFlag = false;
public callLoginComponentFlag = false;
public callRegisterComponentFlag = false;
public signinRightTopFlag = true;
public signInLeftFlag = true;
public bg_imageFlag = true;
public registerComponentFlag = false;
public signInComponentFlag;
public profileFlag = false;
private code: any;
private forgotcode: any;
private twitterLogin = true;
private twitterError: any;
private pageName: any;
private loginStateflag: any;
public auth2: any;                                       // G+ sigin api call variable
private banner: any;
private token: any;
private loged = false;
private user = { name: 'Hello' };
private userapi: any;
private saveToken: any;
private fBToken: any;
private saveTokenFacebook: any;
private errors: any;
public error_message: any;
private userId: any;
private config: any;
private acces: any;
private previousUrl: any;
public assetbasepath: any;
private tokenValue: any;
private timestampTime: any;
private timestampDateTime: any;
private localstorage: any;
private window: any;
private document: any;
private navigator: any;
private configData: any;
private register_mobile: any = false;
private countrycode: any;
private countryList: any;
private countrycodeIndex: number;
private googleAccessToken: any;
private googleObj: any;
private socialType: any;
private socialFlag = false;
public gdprFlag: any;
private userSettings: any;
private receivedValue: any;
private loginFrom: any;
private sendToken: any;
private gdprValue: any;
private gdprCountryChange = false;
private userData: any;
private settingsResponse: any;
private displayDialog: any;
private promotional: any;
private countryToken: any;
private loginMethod: any;
private cookiesLocal: any;
private marketingLocal: any;
private responsevalue: any;
private clientID: any;
private marketingValue: any;
private qgraph: any;
public guest_token: any;
private version_number: any;
public timeoutError: any;
public queryparams: any;
@ViewChild('triggerClickLogin') public loaderPage: ElementRef;

@Input() private signinHide: any;
@Output()
private change: EventEmitter<boolean> = new EventEmitter<boolean>();


constructor(@Inject(PLATFORM_ID) private platformId: Object, private seoservice: SeoService, private commonService: CommonService, private linkservice: LinkService, private settingsService: SettingsService, private networkService: NetworkService, private to: Location, private router: Router, private route: ActivatedRoute , private headerservicesService: HeaderservicesService, location: PlatformLocation, private routeservice: RouteService, private http: Http , private gtm: GoogleAnalyticsService, private userAction: UseractionapiService) {
  if (isPlatformBrowser(this.platformId)) {
          this.localstorage = localStorage;
          this.window = window;
          this.document = document;
          this.navigator = navigator;
  }
  this.code = this.routeservice.getcode();
  this.forgotcode = this.routeservice.getforgotcode();
  this.assetbasepath = environment.assetsBasePath;
  location.onPopState(() => {
        this.headerservicesService.signinChange(false);
        this.document.getElementById('body').classList.remove('modal-open');
        $('#body').removeClass('scrolldisbale');
  });
  this.configData = this.settingsService.getCompleteConfig();

  // this.countryList = this.settingsService.getCountryValueNew();
  this.countryList = this.settingsService.getccodeCountryValue();
  if (this.countryList && this.countryList[0]) {
      this.onCountryCcode();
  } else if (this.countryList) {
    let displang;
    displang = this.token ? this.localstorage.getItem('UserDisplayLanguage') : this.localstorage.getItem('display_language');
    if (displang === null || displang === 'null') {
      displang = 'en';
    }
    this.settingsService.setCountryListNew(environment.CountryListApi + displang).subscribe(valuecountry => {
      this.countryList = valuecountry;
      this.onCountryCcode();
    }, err => {
      // console.log('here in error');
      this.timeoutError = true;
      $('.signinClose').hide();
      $('.signinRegisterHeading').hide();
      $('.signinBanner').css('display', 'none');
      $('.signinRightTop').hide();
      $('#ResponsiveTop').hide();
      $('#loaderPage').css('display', 'none');
    });
  } else {
    let ccode;
    ccode = this.settingsService.newCountryValue.subscribe(value => {
      if (value && value[0]) {
        this.countryList = value;
        this.onCountryCcode();
      } else {
        // console.log('here in error');
        this.timeoutError = true;
        $('.signinClose').hide();
        $('.signinRegisterHeading').hide();
        $('.signinBanner').css('display', 'none');
        $('.signinRightTop').hide();
        $('#ResponsiveTop').hide();
        $('#loaderPage').css('display', 'none');
      }
      ccode.unsubscribe();
    });
  }
  this.headerservicesService.signinValue.subscribe(value => {
    this.signInComponentFlag = value;
  });
  this.headerservicesService.signinRightTopValue.subscribe(value => {
    this.signinRightTopFlag = value;
  });
  this.headerservicesService.signinValueLeft.subscribe(value => {
    this.signInLeftFlag = value;
  });
  this.headerservicesService.bgImageValue.subscribe(value => {
    this.bg_imageFlag = value;
  });
  this.headerservicesService.registerMobileValue.subscribe(value => {
    this.registerMobileFlag = value;
  });
  this.headerservicesService.signInDetailValue.subscribe(value => {
    this.signinDetailsFlag = value;
  });
  this.headerservicesService.loginHeadingValue.subscribe(value => {
    this.loginHeadingFlag = value;
  });
  this.headerservicesService.registerHeadingValue.subscribe(value => {
    this.registerHeadingFlag = value;
  });
  this.headerservicesService.loginMobileValue.subscribe(value => {
    this.loginMobileFlag = value;
  });
  this.headerservicesService.loginEmailValue.subscribe(value => {
    this.loginEmailFlag = value;
  });
  this.profileFlag = this.headerservicesService.getProfileActivationChange();  // added newly for email verfication lonk
  this.headerservicesService.pofileActivationValue.subscribe(value => {  // profileactivation screen inside app value changes
  this.profileFlag = this.headerservicesService.getProfileActivationChange();
  });
  this.headerservicesService.blockeventsValue.subscribe(value => {
     this.qgraph = this.headerservicesService.getRemarketing();
  });
 }

private onCountryCcode(): any {
  // this.countryList = valuecountry;
  if (this.countryList && this.countryList.length >= 1) {
  let value;
  value = this.routeservice.sendSignal();
  if (value === 'mobile') {
      this.callLoginMobile();
  } else if (value === 'email') {
      this.callLoginEmail();
  } else if (value === 'register') {
      this.toggleRegisterHeading();
  } else if (value === '/register/mobile') {
    if (this.countryList) {
      if (this.countryList[0] && this.countryList[0].mobile_registration === 'true') {
        this.callRegisterMobile();
      } else if (this.countryList[0] && this.countryList[0].mobile_registration === 'false') {
            this.callRegisterEmail();
      } else if (this.configData) {
          if (this.configData.mobile_registration || this.configData.mobile_registration === undefined) {
            this.callRegisterMobile();
           }
      }
    } else if (this.configData) {
        if (this.configData.mobile_registration || this.configData.mobile_registration === undefined) {
            this.callRegisterMobile();
        } else {
            setTimeout(() => {
            $('#body').removeClass('scrolldisbale');
            this.close();
            }, 10);
        }
    }
    } else if (value === '/register/email') {
      this.callRegisterEmail();
    } else if (value === '/signin/mobile') {
    if (this.countryList) {
      if (this.countryList[0] && this.countryList[0].mobile_registration === 'true') {
        this.callLoginMobile();
      } else if (this.countryList[0] && this.countryList[0].mobile_registration === 'false') {
            this.callLoginEmail();
      } else if (this.configData) {
          if (this.configData.mobile_registration || this.configData.mobile_registration === undefined) {
            this.callLoginMobile();
           }
      }
    } else if (this.configData) {
        if (this.configData.mobile_registration || this.configData.mobile_registration === undefined) {
            this.callLoginMobile();
        } else {
            setTimeout(() => {
            $('#body').removeClass('scrolldisbale');
            this.close();
            }, 10);
        }
    }
    } else if (value === '/signin/email') {
      this.callLoginEmail();
    } else if (value === '/verify?code=' + this.code) {
    $('#loaderPage').css('display', 'block');
          this.settingsService.bluekaiPagename('verify');
          this.headerservicesService.modelChange(true);
          this.headerservicesService.ProfileActivationChange(true);
          this.loginEmailFlag = false;
          this.loginMobileFlag = false;
          this.signinDetailsFlag = false;
          this.callLoginComponentFlag = false;
          this.callRegisterComponentFlag = false;
          this.registerHeadingFlag = false;
          this.loginHeadingFlag = false;
          this.signInLeftFlag = false;
          this.bg_imageFlag = false;
          this.signinRightTopFlag = false;
          // this.headerservicesService.signinLeftChange(false);
          // this.headerservicesService.signinDetailsChange(false);
          // this.headerservicesService.bgImageValueChange(false);
          // this.headerservicesService.signinRightTopChange(false);
          // this.headerservicesService.signinChange(true);
          // this.headerservicesService.registerMobilechange(false);
          // this.headerservicesService.loginHeadingChange(false);
          // this.headerservicesService.registerHeadingChange(false);
          // this.headerservicesService.loginMobileChange(false);
          // this.headerservicesService.loginEmailChange(false);
    } else if (value === '/forgotpassword/email') {
          this.settingsService.bluekaiPagename('forgotpassword');
          this.routeservice.forgotSignal('email');
          this.loginEmailFlag = true;
          this.loginMobileFlag = false;
          this.signinDetailsFlag = false;
          this.callLoginComponentFlag = true;
          this.callRegisterComponentFlag = false;
          this.registerHeadingFlag = true;
          this.loginHeadingFlag = false;
    } else if (value === '/forgotpassword/mobile') {
          this.settingsService.bluekaiPagename('forgotpassword');
          this.routeservice.forgotSignal('mobile');
          this.loginEmailFlag = false;
          this.loginMobileFlag = true;
          this.signinDetailsFlag = false;
          this.callLoginComponentFlag = true;
          this.callRegisterComponentFlag = false;
          this.registerHeadingFlag = true;
          this.loginHeadingFlag = false;
          this.routeservice.Signal(null);

    } else if (value === '/resetpassword?code=' + this.forgotcode) {
          this.settingsService.bluekaiPagename('resetpassword');
          this.routeservice.forgotSignal(value);
          this.loginEmailFlag = false;
          this.loginMobileFlag = false;
          this.signinDetailsFlag = false;
          this.callLoginComponentFlag = true;
          this.callRegisterComponentFlag = false;
          this.registerHeadingFlag = true;
          this.loginHeadingFlag = false;
    } else {
      this.toggleLoginHeading();
    }
    if (this.countryList && this.countryList.length !== 0) {
      if (this.countryList[0] && this.countryList[0].mobile_registration) {
        if (this.countryList[0].mobile_registration === 'false') {
          this.register_mobile = false;
        } else if (this.countryList[0].mobile_registration === 'true') {
          this.register_mobile = true;
        }
      } else  {
        this.register_mobile = true;
      }
    } else if (this.configData) {
        if (this.configData.mobile_registration) {
         this.register_mobile = this.configData.mobile_registration;
        } else {
         this.register_mobile = true;
       }
    }
  } else {
      this.toggleLoginHeading();
  }
}



  public ngOnInit() {
    this.deviceAuthCodeExists();
    this.queryparams = this.router.url.split('?')[1];
    $('.auto-loader').css('display', 'block');
    this.gtm.storeWindowError();
    this.qgraph = this.headerservicesService.getRemarketing();
    this.previousUrl = this.routeservice.getLoginRoute();
     this.cookiesLocal = this.localstorage.getItem('cookies');
    this.marketingLocal = this.localstorage.getItem('marketing');
    this.guest_token = this.localstorage.getItem('guestToken');
    this.version_number = this.navigator.userAgent;  // gdpr additional field version number while post
    if (this.previousUrl === '/signin' || this.previousUrl === '/signin/email' || this.previousUrl === '/signin/mobile' || this.previousUrl === '/register' || this.previousUrl === '/register/email' || this.previousUrl === '/register/mobile' || this.previousUrl === '/forgotpassword/email' || this.previousUrl === '/forgotpassword/mobile') {
      this.routeservice.setLoginRoute('/'); // dont route if popup
      this.previousUrl = '/';
    }
    this.countrycode = this.settingsService.getCountry();
    $('#loaderPage').css('display', 'block');
    let img1;
    img1 = new Image();
    img1.src = this. assetbasepath + 'assets/sign_in/google_icon.png';
    img1.onload = function() {
      $('#loaderPage').css('display', 'none');
    };
     this.qgraphevent('login_page_visited', {'country' : this.countrycode });
    this.token = this.localstorage.getItem('token');
    if (this.token && (this.code || this.forgotcode)) {
      this.loginStateflag = true;
      this.routeservice.setloggedInstate(this.loginStateflag);
    } else if (this.token) {
      $('.SignIncomponent').css('display', 'none');
      $('#loaderPage').css('display', 'block');
      if (this.navigator.userAgent.match(/mozilla/i)) {
        setTimeout(() => {
          $('#body').removeClass('scrolldisbale');
          this.window.history.replaceState({}, '', '/');
          this.document.getElementById('body').classList.remove('modal-open');
          this.localstorage.removeItem('twitterToken');
        }, 10);
      } else {
        this.window.history.go(-2);
        this.document.getElementById('body').classList.remove('modal-open');
        this.localstorage.removeItem('twitterToken');
      }
    }
    this.twitterError = this.localstorage.getItem('twittermessage');
    if (this.twitterError !== null) {
      this.error_message = this.twitterError;
      this.callToast();
      setTimeout(() => {
         this.localstorage.removeItem('twittermessage');
         this.localstorage.removeItem('twitterToken');
      }, 100);
    }
    this.userapi = new userApi.UserApi(this.http, null, null);
    this.window.scrollTo(0, 0);
    $('#body').addClass('scrolldisbale');
    if ((!this.navigator.userAgent.match(/mobile/i) && this.window.innerWidth < 1281)) {
      $( '.bg_image').css({'display': 'none'});
    }
  	this.banner = [
    { id:  0, heading: 'LOGIN.SLIDE1_LINE1', subHeading: 'LOGIN.SLIDE1_LINE2', url : this.assetbasepath + 'assets/sign_in/banner_img1.png'},
    { id:  1, heading: 'LOGIN.SLIDE2_LINE1', subHeading: 'LOGIN.SLIDE2_LINE2', url : this.assetbasepath + 'assets/sign_in/banner_img2.png'},
    { id:  2, heading: 'LOGIN.SLIDE3_LINE1', subHeading: 'LOGIN.SLIDE3_LINE2', url : this.assetbasepath + 'assets/sign_in/banner_img3.png'},
    { id:  3, heading: 'LOGIN.SLIDE4_LINE1', subHeading: 'LOGIN.SLIDE4_LINE2', url : this.assetbasepath + 'assets/sign_in/banner_img4.png'},
     ];
     $('.auto-loader').css('display', 'none');
     this.gtm.FacebookInitialization();
  }
  public deviceAuthCodeExists() {
   if (this.route.snapshot.queryParams['device_code']) {
    this.route.queryParams.subscribe(params => {
      let currentState;
      if (params['device_code']) {
        this.authenticationCode  = params['device_code'];
        currentState = 1;
       localStorage.setItem('deviceAuthenticateCode', this.authenticationCode);
       this.userAction.checkForDeviceAuthCode(currentState);
      }
      });
   }
  }
  /////////////////// login with social network start////////////////
  private deleteCookie(): any {  // for twitter
    document.cookie = 'PHPSESSID' + '=; Path=/;Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
    this.localstorage.removeItem('twitterTime');
  }
  public ngAfterViewChecked(): void {
    if ((this.register_mobile === false || this.register_mobile === 'false') && this.loginHeadingFlag) {
       $('.socialSection').css('height', 'calc(49.813084%)');
    }
     this.googleInit();                                                             // G+ sigin api call start
  }
   private googleGm() {
   let network;
   network = this.networkService.getPopupStatus();
     if (network === true) {
      if ( this.registerComponentFlag === true) {                                // for register
        this.pageName = 'register/google';
        this.gtm.sendPageName(this.pageName);
        this.gtm.sendEvent();
       this.qgraphevent('signup_initiated', {'method': 'social_google', 'country' : this.countrycode });
      }
      if ( this.loginComponentFlag === true) {                                     // for login
       this.pageName = 'sign in/google';
       this.gtm.sendPageName(this.pageName);
       this.gtm.sendEvent();
       this.qgraphevent('signin_initiated', {'method': 'social_google', 'country' : this.countrycode });
      }
    }
  }
   private twitterGm() {
   let network;
   network = this.networkService.getPopupStatus();
   if (network === true) {
      this.deleteCookie();
      let x , y ;
      x = new Date();
      y = x.getTime();
      if ( this.loginComponentFlag === true) {
        // $('#twitterSigin').attr('href', environment.twitterLogin + '&ver=' + y);
        location.href = environment.twitterLogin + '&ver=' + y;
        this.pageName = 'sign in/twitter';
        this.gtm.sendPageName(this.pageName);
        this.gtm.sendEvent();
        this.qgraphevent('signin_initiated', {'method': 'social_twitter', 'country' : this.countrycode });
        location.href = environment.twitterLogin + '&ver=' + y;
      }
      if ( this.registerComponentFlag === true) {
        // $('#twitterSigin').attr('href', environment.twitterLogin + '&ver=' + y);
        location.href = environment.twitterLogin + '&ver=' + y;
        this.pageName = 'register/twitter';
        this.gtm.sendPageName(this.pageName);
        this.gtm.sendEvent();
        this.qgraphevent('signup_initiated', {'method': 'social_twitter', 'country' : this.countrycode});
        location.href = environment.twitterLogin + '&ver=' + y;
      }
    }
  }
  private facebookGm() {
    if ( this.registerComponentFlag === true) {                                // for register
      this.pageName = 'register/facebook';
      this.gtm.sendPageName(this.pageName);
      this.gtm.sendEvent();
      this.qgraphevent('signup_initiated', {'method': 'social_fb', 'country' : this.countrycode });
    }
    if ( this.loginComponentFlag === true) {                                     // for login
      this.pageName = 'sign in/facebook';
      this.gtm.sendPageName(this.pageName);
      this.gtm.sendEvent();
      this.qgraphevent('signup_initiated', {'method': 'social_fb', 'country' : this.countrycode });
    }
  }
  public googleInit() {
    if ( this.window && this.window.gapi) {
      this.window.gapi.load('auth2', () => {
         let that;
         that = this;
        this.auth2 = this.window.gapi.auth2.init({
          client_id:   that.GOOGLE_CLIENT_ID,
          cookiepolicy: 'single_host_origin',
          scope: 'profile'
        });
        this.attachSignin(this.document.getElementById('googleBtn'));
      });
    }
  }
  public attachSignin(element) {
    this.auth2.attachClickHandler(element, {},
      (googleUser) => {
        let profile;
        profile = googleUser.getBasicProfile();
        this.acces = this.window.gapi.auth2.getAuthInstance().currentUser.get().getAuthResponse(true).access_token;
        this.googleloginApi(this.acces);
      }, error => {
        // todo
      });
  }                                                                         // G+ sigin api call end
  private checkLoginState() {
    let network;
    network = this.networkService.getPopupStatus();
   if (network === true) {
     this.twitterError = this.localstorage.getItem('header');
      if (this.twitterError != null) {
            if (this.twitterError === 'false') {
                    this.error_message = 'TOAST_MESSAGES.TRACKING';
                    this.callToast();
            }
      }
        FB.getLoginStatus(response => {
              this.statusChangeCallback(response);
        });
    }
  }
  private statusChangeCallback(response: any) {
      if (response.status === 'connected') {
          this.login();
      } else {
          this.login();
      }
  }
  private login() {
      FB.login(result => {
          this.loged = true;
          this.token = result;
          if (this.token.authResponse != null) {
            this.fBToken = this.token.authResponse.accessToken;
          }
       this.me();
       this.facebookloginApi(this.fBToken);
      }, { scope: 'public_profile,email' });
  }
  private me() {
      FB.api('/me?fields=id,name,first_name,email,gender,picture.width(150).height(150),age_range',
          function(result) {
              if (result && !result.error) {
                  this.user = result;
              } else {
                // todo
              }
          });
  }
  private googleloginApi(acces): any {
    if (acces) {
      this.removeSignin();
      this.userapi.v1UserLogingoogleGet(acces).timeout(environment.timeOut).subscribe(response => {
      this.loginMethod = 'login';
      this.checkGdprNode(response.token, 'google');
      }, err => {
        this.openSignin();
                  if (err.name === 'TimeoutError') {
                     this.error_message = 'MESSAGES.TRY_LATER';
                     this.callToast();
                  } else if (err.status === 404) {
                    this.qgraphevent('signin_failure', {'method': 'social_google', 'country' : this.countrycode});
                    this.GAUpdateCommon('LoginFailed', 'googleplus');
                    this.gtm.sendErrorEvent('api', err);  // to show GDPR screen
                    this.gdprFlag = true;
                    this.socialFlag = true;
                    this.socialType = 'google';
                    this.loginFrom = 'register';
                    this.headerservicesService.bgImageValueChange(true);
                    this.headerservicesService.signinDetailsChange(false);
                    this.headerservicesService.signinRightTopChange(true);
                    this.headerservicesService.signinLeftChange(true);
                    this.simulateUserGesture();
                    $('#loaderPage').css('display', 'block');
                    this.triggerClick();
                  } else {
                    this.error_message = 'MESSAGES.TRY_LATER';
                    this.callToast();
                  }
      });
    }
  }
  private googleRegister(): any {
    this.createObject(this.acces);
    if (this.googleObj) {
       this.userapi.v1UserRegistergooglePost(this.googleObj).timeout(environment.timeOut).subscribe(response => {
         this.loginMethod = 'register';
         this.saveToken = response.token;
         // this.CommonConfigCall(this.saveToken);
        setTimeout(() => {
         this.updateSettingApi(this.saveToken, 'google', 'register');
          this.qgraphevent('signup_success', {'method': 'social_google', 'country' : this.countrycode});
        }, 0);
          this.GAUpdateCommon('RegisterSuccess', 'googleplus');
        }, error => {
            this.errors = error.json();
               this.openSignin();
               if (error.name === 'TimeoutError') {
               this.error_message = 'MESSAGES.TRY_LATER';
                 this.callToast();
               } else if (error.status === 404) {
                this.error_message = this.errors.message;
                setTimeout(() => {
                    if (this.error_message) {
                      this.callToast();
                    }
                }, 3000);
              } else if (error.status === 400) {
                this.gdprFlag = false;
                this.error_message = 'MESSAGES.TRY_LATER';
                 this.callToast();
              } else {
                 this.error_message = 'MESSAGES.TRY_LATER';
                 this.callToast();
              }
              this.GAUpdateCommon('RegisterFailed', 'googleplus');
              this.qgraphevent('signup_failure', {'method': 'social_google', 'country' : this.countrycode});
             this.gtm.sendErrorEvent('api', error);
       });
    }
  }
  private facebookloginApi(fBToken) {
   if (fBToken) {
     this.removeSignin();
     this.userapi.v1UserLoginfacebookGet(fBToken).timeout(environment.timeOut).subscribe(response => {
       this.loginMethod = 'login';
       this.checkGdprNode(response.token, 'facebook');
     }, error => {
          this.openSignin();
          if (error.name === 'TimeoutError') {
            this.error_message = 'MESSAGES.TRY_LATER';
            this.callToast();
          } else if (error.status === 404) {
             this.qgraphevent('signin_failure', {'method': 'social_fb', 'country' : this.countrycode});
             this.GAUpdateCommon('LoginFailed', 'facebook');
              this.gtm.sendErrorEvent('api', error);
              this.gdprFlag = true;
              this.socialFlag = true;
              this.socialType = 'facebook';
              this.loginFrom = 'register';
              this.headerservicesService.registerMobilechange(false);
              this.headerservicesService.bgImageValueChange(true);
              this.headerservicesService.signinDetailsChange(false);
              this.headerservicesService.signinRightTopChange(true);
              this.headerservicesService.signinLeftChange(true);
              this.simulateUserGesture();
              this.triggerClick();
               $('#loaderPage').css('display', 'block');
          } else {
            this.error_message = 'MESSAGES.TRY_LATER';
            this.callToast();
          }
     });
    }
  }
  private facebookRegister(): any {
  this.createObject(this.fBToken);
  if (this.googleObj) {
    this.userapi.v1UserRegisterfacebookPost(this.googleObj).timeout(environment.timeOut).subscribe(response => {
        this.loginMethod = 'register';
        this.saveTokenFacebook = response.token;
        // this.CommonConfigCall( this.saveTokenFacebook);
        setTimeout(() => {
        this.updateSettingApi(this.saveTokenFacebook, 'facebook', 'register');
         this.qgraphevent('signup_success', {'method': 'social_fb', 'country' : this.countrycode});
        }, 0);
        this.GAUpdateCommon('RegisterSuccess', 'facebook');
    }, errors => {
         this.errors = errors.json();
           this.openSignin();
           if (errors.name === 'TimeoutError') {
             this.error_message = 'MESSAGES.TRY_LATER';
             this.callToast();
            } else if (errors.status === 404) {
              this.error_message  = this.errors.message;
              setTimeout(() => {
                  if (this.error_message) {
                    this.callToast();
                  }
              }, 3000);
            } else if (errors.status === 400 || errors.status === 401) {
                this.gdprFlag = false;
                this.error_message = 'MESSAGES.TRY_LATER';
                this.callToast();
            } else {
              this.error_message = 'MESSAGES.TRY_LATER';
              this.callToast();
            }
            this.GAUpdateCommon('RegisterFailed', 'facebook');
            this.qgraphevent('signup_failure', {'method': 'social_fb', 'country' : this.countrycode});
            this.gtm.sendErrorEvent('api', errors);
    });
  }
  }
  private createObject(accessToken): any {
    let policyValues, googleObjInt, country_Promotion;
    country_Promotion = this.settingsService.getCountryPromotionalValue();
    policyValues = [];
    for (let i = 0; i < 4; i++) {
        if (!(this.receivedValue.sendValues[i].status) || this.receivedValue.sendValues[i].status === undefined) {
            policyValues[i] = 'na';
        } else if (!(this.receivedValue.sendValues[i].userValue)) {
            policyValues[i] = 'no';
        } else if (this.receivedValue.sendValues[i].userValue === true) {
           policyValues[i] = 'yes';
        }
    }
    googleObjInt = {
       'token' : accessToken,
       'mac_address': '',
       'ip_address': '',
       'registration_country': '',
       'additional': {
          'gdpr_policy': [{
            'country_code': this.countrycode,
            'gdpr_fields': {
              'policy': policyValues[0],
              'profiling': policyValues[1],
              'age': policyValues[2],
              'subscription': policyValues[3]
            }
          }],
           'guest_token': this.guest_token,
           'sourceapp' : 'Web',
           'version_number' : this.version_number,
           'promotional': {
             'on': country_Promotion.on,
             'token': country_Promotion.token
            },
            'first_time_login': '1'
        }
      };
      this.googleObj = this.gtm.checkUpdateCampaign(googleObjInt);
  }
  private updateSettingApi(token, method, type): any {
    if (token) {
      // this.CommonConfigCall(token);
         let params;
        params = 'bearer ' + token ;
       this.config = {
          apiKey: params,
          username: '',
          password: '',
          accessToken: '',
          withCredentials: false
        };
    }
    let policyValues;
    policyValues = [];
    for (let i = 0; i < 4; i++) {
        if (!(this.receivedValue.sendValues[i].status) || this.receivedValue.sendValues[i].status === undefined) {
            policyValues[i] = 'na';
        } else if (!(this.receivedValue.sendValues[i].userValue)) {
            policyValues[i] = 'no';
        } else if (this.receivedValue.sendValues[i].userValue === true) {
           policyValues[i] = 'yes';
        }
    }
    if (!this.gdprCountryChange) { // register
    let gdprValue, gdprsettings;
      gdprValue = [{
              'country_code': this.countrycode,
              'gdpr_fields': {
                  'policy': policyValues[0],
                  'profiling': policyValues[1],
                  'age': policyValues[2],
                  'subscription': policyValues[3]
                   }
              }];
    gdprsettings = {
              'key': 'gdpr_policy',
              'value': JSON.stringify(gdprValue)
           };
    this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
      this.userSettings.v1SettingsPost(gdprsettings).subscribe(responsePost => {
         if (type !== 'register') {
           this.updateGMID(token, method);
         } else {
          let disp, valuecountryCode;
            disp = this.localstorage.getItem('display_language');
              valuecountryCode = this.settingsService.getCountryValueNew();
             if (valuecountryCode && valuecountryCode.length > 0) {
                this.promotional = valuecountryCode[0].promotional;
                this.countryToken = this.promotional.token;
                if (this.promotional && this.promotional.on === '1') {
                  this.promotionalAPIcall(token, method);
                } else if (this.promotional && this.promotional.on === '0') {
                  this.setFirstTimeloginSocial('1', token, method);
                }
              }
        }
      }, err => {
         // this.SettingapiFails();
          this.settingsFailsRegister(gdprsettings, type, token, method);
        });
    } else {      // login
         let gdprValue1, gdprsettings;
          gdprValue1 = {
                  'country_code': this.countrycode,
                  'gdpr_fields': {
                    'policy': policyValues[0],
                    'profiling': policyValues[1],
                    'age': policyValues[2],
                    'subscription': policyValues[3]
                  }
          };
          this.gdprValue.push(gdprValue1);
          gdprsettings = {
              'key': 'gdpr_policy',
              'value': JSON.stringify(this.gdprValue)
           };
          this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
          this.userSettings.v1SettingsPut(gdprsettings).subscribe(responsePost => {
          this.updateGMID(token, method);
        }, err => {
             this.openSignin();
             this.error_message = 'MESSAGES.TRY_LATER';
             this.callToast();
        });
    }
    if (type === 'register') {
     this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
      this.userSettings.v1SettingsGet().subscribe( response => {
        this.settingsResponse = response;
         this.cookieConcent(this.settingsResponse);
      }, err => {
           // todo
      });
    }
  }
  private checkGdprNode(token, method): any {
     if (token) {
        this.CommonConfigCall(token);
        this.userSettings = new SettingsApi.SettingsApi(this.http, null, this.config);
        this.userSettings.v1SettingsGet().subscribe( response => {
          this.settingsResponse = response;
          this.cookieConcent(this.settingsResponse);
            let gdpr_Flag;
            if ( response.length > 0) {
              for (let i = 0; i < response.length; i++) {
                if ( response[i].key === 'gdpr_policy') {
                      gdpr_Flag = true;
                    if (!(response[i].value[0] === '{')) {
                     this.gdprValue = JSON.parse(response[i].value);
                     let flagcheck = false;
                    for (let j = 0; j < this.gdprValue.length; j++) {
                    if (this.countrycode === this.gdprValue[j].country_code) {
                      flagcheck = true;
                      break;
                    } else if (j === this.gdprValue.length - 1) {   // no country code match so show GDPR screen with put request
                        flagcheck = false;
                      }
                    }
                    if (flagcheck) {
                      this.updateGMID(token, method);
                    } else {
                      this.gdprCountryChange = true;
                      this.showScreen(token, method);
                    }
                   } else {
                       this.userSettings.v1SettingsDelete('gdpr_policy', token).subscribe(responseput => {
                          this.showScreen(token, method);
                       });
                  }
                }
              }
              if (gdpr_Flag === undefined) {
                this.getSocialUserDetails(token, method);
              }
            } else {
              if (gdpr_Flag === undefined) {
                this.getSocialUserDetails(token, method);
              }
            }

          }, err => {
              this.openSignin();
             this.error_message = 'MESSAGES.TRY_LATER';
             this.callToast();
          });
        }
  }
  private triggerClick() {
    let el: HTMLElement = this.loaderPage.nativeElement as HTMLElement;
    el.click();
}
  private getSocialUserDetails(token, method): any {
     let userDetails;
      userDetails = new UserApi(this.http, null, this.config);
      userDetails.v1UserGet().timeout(environment.timeOut).subscribe(value => {
      this.userData = value;
      this.localstorage.setItem('ID', this.userData.id);
        if (value.additional.gdpr_policy) {
          for (let j = 0; j < value.additional.gdpr_policy.length; j++) {
            if (this.countrycode === value.additional.gdpr_policy[j].country_code) {
                let gdprValue;
                gdprValue = [{'country_code': this.countrycode,
                    'gdpr_fields': {
                          'policy': value.additional.gdpr_policy[j].gdpr_fields.policy,
                          'profiling': value.additional.gdpr_policy[j].gdpr_fields.profiling,
                          'age': value.additional.gdpr_policy[j].gdpr_fields.age,
                          'subscription': value.additional.gdpr_policy[j].gdpr_fields.subscription
                     }}];
                const gdpr_settings = {
                    'key': 'gdpr_policy',
                    'value': JSON.stringify(gdprValue)
                };
                this.userSettings.v1SettingsPost(gdpr_settings).subscribe(responsePost => {
                  this.updateGMID(token, method);
                }, err => {
                  this.SettingapiFails();
                  });
            } else {
                this.showScreen(token, method);
            }
          }
        } else if (value.additional.gdpr_policy === undefined) { // GDPR post request no node
                this.showScreen(token, method);
        }
      }, err => {
                this.gtm.sendErrorEvent('api', err);
                if (err.name === 'TimeoutError') {
                  this.error_message = 'MESSAGES.TRY_LATER';
                  this.callToast();
                } else {
                  this.errors = err.json();
                  this.error_message = this.errors.message;
                  this.callToast();
                }
        });
  }
  private sendData(value) {
    this.receivedValue = value ;
    setTimeout(function () {
      $('.loaderImage').css('display', 'none');
    }, 500);
  }
  private AcceptEnable() {
    if (!(this.receivedValue.sendFlag)) {
          $('.AcceptSignin').css({'background-color': '#50012f', 'color': '#703055'});
          return true;
        } else {
           $('.AcceptSignin').css({'background-color': '#bf006b', 'color': '#eeeeee'});
          return false;
      }
  }
  private GdprUpdate() {
    if (this.socialFlag === true) {
         $('#loaderPage').css('display', 'block');
       if (this.loginFrom === 'register') {
          if (this.socialType === 'google') {
            this.googleRegister();
          } else {
            this.facebookRegister();
          }
        } else if (this.loginFrom === 'login') {
          this.updateSettingApi(this.sendToken, this.socialType, this.loginFrom);
        }
    }
  }
  private callToast() {
      let p;
      p = this.document.getElementById('snackbarSigin');
      p.className = 'show';
      setTimeout(function() { p.className = p.className.replace('show', ''); }, 5000);
  }
  private updateGMID(userId, method) {
        this.CommonConfigCall(userId);
          let userDetails;
          userDetails = new userApi.UserApi(this.http, null, this.config);
          userDetails.v1UserGet().timeout(environment.timeOut).subscribe(value => {
            this.userId = value.id;
            this.localstorage.setItem('ID', this.userId);
            if (method === 'facebook') {
            this.qgraphevent('Signin_Success', {'method': 'social_fb', 'country' : this.countrycode});
            this.GAUpdateCommon('LoginSuccess', 'facebook');
            }
            if (method === 'google') {
            this.qgraphevent('Signin_Success', {'method': 'social_google', 'country' : this.countrycode});
            this.GAUpdateCommon('LoginSuccess', 'googleplus');
            }
          this.updatePromotionSocial(value, userId, method);
        }, err => {
            this.userId = 'NA';
            this.callReload();
            this.gtm.sendErrorEvent('api', err);
          });
  }
  private SettingapiFails() {
    $('#loaderPage').css('display', 'none');
    this.error_message  = 'MESSAGES.TRY_LATER';
    this.callToast();
    this.gdprFlag = false;
    this.headerservicesService.registerMobilechange(false);
    this.headerservicesService.bgImageValueChange(true);
    this.headerservicesService.signinDetailsChange(true);
    this.headerservicesService.signinRightTopChange(true);
    this.headerservicesService.signinLeftChange(true);
    let scope;
    scope = this;
    setTimeout(function() { scope.callReload(); }, 2500);
  }
  private callReload() {
    $('#SignIncomponent').css('visibility', 'hidden');
    $('#loaderPage').css('display', 'block');
    this.localstorage.setItem('googletag', 'false');
    // if (!state) {
    //   location.href = this.window.location.origin + this.previousUrl;
    // } else {
      this.changeRoute();
    // }
  }
  private changeRoute(): any {
    let postRoute;
    postRoute = this.localstorage.getItem('postSubscriptionRoute');
    if (this.previousUrl !== '/myaccount/subscription' && postRoute) {
      this.localstorage.removeItem('postSubscriptionRoute');
      this.commonService.getPostSubscriptionRoute(postRoute, 'login');
    } else {
      location.href = this.window.location.origin + this.previousUrl;
    }
  }
  private confirmationPage(type, token) {
   this.localstorage.setItem('googletag', 'false');
   $('#loaderPage').css('display', 'none');
   this.headerservicesService.RegisterSuccessChange(true);
   this.headerservicesService.loginComponentChange(false);
   this.headerservicesService.loginMobileChange(false);
   this.headerservicesService.loginEmailChange(false);
   this.headerservicesService.registerMobilechange(false);
   this.profileFlag = true;
   this.registerEmailFlag = false;
   this.registerMobileFlag = false;
   $('#body').addClass('scrolldisbale');
   this.bg_imageFlag = false;
   this.signInLeftFlag = false;
   this.signinRightTopFlag = false;
   this.signinDetailsFlag = false;
   this.gdprFlag = false;
  }
  private removeSignin() {
    $('#loaderPage').css('display', 'block');
    // $('#ResponsiveTop').css('display', 'none');
    this.signinDetailsFlag = false;
    this.headerservicesService.signinRightTopChange(false);
    this.headerservicesService.bgImageValueChange(false);
    this.headerservicesService.signinLeftChange(false);
  }
  private openSignin() {
    $('#loaderPage').css('display', 'none');
   $('#ResponsiveTop').css('display', 'block');
   this.signinDetailsFlag = true;
   this.headerservicesService.signinRightTopChange(true);
   this.headerservicesService.bgImageValueChange(true);
   this.headerservicesService.signinLeftChange(true);
  }
  private showScreen(token, method) {
  this.gdprFlag = true;
  this.socialFlag = true;
  this.socialType = method;
  this.loginFrom = 'login';     // to differentate register r login
  this.sendToken = token;
  this.triggerClick();
  this.headerservicesService.bgImageValueChange(true);
  this.headerservicesService.signinDetailsChange(false);
  this.headerservicesService.signinRightTopChange(true);
  this.headerservicesService.signinLeftChange(true);
  this.simulateUserGesture();
  }
  private updatePromotionSocial(value, token, method) {
    this.userData = value;
    if (this.userData === undefined || this.userData.length === 0) {
        let userDetails;
        userDetails = new UserApi(this.http, null, this.config);
        userDetails.v1UserGet().timeout(environment.timeOut).subscribe(uservalue => {
        this.userData = uservalue;
        if ( this.settingsResponse.length > 0) {
          for (let i = 0; i < this.settingsResponse.length; i++) {
            if ( this.settingsResponse[i].key === 'first_time_login') {
              if (this.settingsResponse[i].value === '1') {
                 this.localstorage.setItem('login', method);
                 this.localstorage.setItem('token', token);
                this.callReload();
              } else if (this.settingsResponse[i].value === '0') {
                   let disp, valuecountryCode;
                  disp = this.localstorage.getItem('display_language');
                  valuecountryCode = this.settingsService.getCountryValueNew();
                  if (valuecountryCode && valuecountryCode.length > 0) {
                    this.promotional = valuecountryCode[0].promotional;
                    this.countryToken = this.promotional.token;
                    if (this.promotional && this.promotional.on === '1') {
                      this.promotionalAPIcall(token, method);
                    } else if (this.promotional && this.promotional.on === '0') {
                        this.setFirstTimeloginSocial('1', token, method);
                    }
                  }
              }
            } else if (i === this.settingsResponse.length - 1) {
                if (this.userData.additional.first_time_login) {
                  if (this.userData.additional.promotional && this.userData.additional.promotional.on === '1') {
                    this.promotionalAPIcall(token, method);
                  } else if (this.userData.additional.promotional && this.userData.additional.promotional.on === '0') {
                     this.setFirstTimeloginSocial('1', token, method);
                  } else {
                    this.setFirstTimeloginSocial('1', token, method);
                  }
                } else {
                      this.setFirstTimeloginSocial('1', token, method);
                    }
             }
          }
        }
      }, err => {
        this.openSignin();
        this.error_message = 'MESSAGES.TRY_LATER';
        this.callToast();
      });
    } else if (this.userData) {
        if ( this.settingsResponse.length > 0) {
          for (let i = 0; i < this.settingsResponse.length; i++) {
            if ( this.settingsResponse[i].key === 'first_time_login') {
                 this.localstorage.setItem('login', method);
                 this.localstorage.setItem('token', token);
                 this.callReload();
            } else if (i === this.settingsResponse.length - 1) {
                if (this.userData.additional.first_time_login) {
                  if (this.userData.additional.promotional && this.userData.additional.promotional.on === '1') {
                      this.promotionalAPIcall(token, method);
                  } else if (this.userData.additional.promotional && this.userData.additional.promotional.on === '0') {
                    this.setFirstTimeloginSocial('1', token, method);
                  } else {
                    this.setFirstTimeloginSocial('1', token, method);
                  }
                } else {
                    this.setFirstTimeloginSocial('1', token, method);
                }
            }
          }
        } else if (this.userData.additional.first_time_login) {
              if (this.userData.additional.promotional && this.userData.additional.promotional.on === '1') {
                  this.promotionalAPIcall(token, method);
              } else if (this.userData.additional.promotional && this.userData.additional.promotional.on === '0') {
                  this.setFirstTimeloginSocial('1', token, method);
              } else {
                this.setFirstTimeloginSocial('1', token, method);
              }
        } else {
            this.setFirstTimeloginSocial('1', token, method);
        }
    }
  }
  private setFirstTimeloginSocial(first_time_value, token, method) {
    let first_time_settings;
    first_time_settings = {
      key: 'first_time_login',
      value: first_time_value
    };
    this.userSettings.v1SettingsPost(first_time_settings).subscribe(responsePost => {
                this.localstorage.setItem('login', method);
                this.localstorage.setItem('token', token);
                if (this.loginMethod === 'login') {
                  this.callReload();
                } else {
                  let userDetails;
                  userDetails = new UserApi(this.http, null, this.config);
                  userDetails.v1UserGet().timeout(environment.timeOut).subscribe(valueUser => {
                  this.userId = valueUser.id;
                  this.localstorage.setItem('ID', this.userId);
                 });
                  this.confirmationPage(method, token);
                }
    }, err => {
      this.errors = err.json();
      if (this.errors.message === 'Item already exists') {   // for already node there
        this.userSettings.v1SettingsPut(first_time_settings).subscribe(responsePost => {
       this.localstorage.setItem('login', method);
       this.localstorage.setItem('token', token);
       this.callReload();
      }, error => {
       this.localstorage.setItem('login', method);
       this.localstorage.setItem('token', token);
       this.callReload();
      });
      } else {
        this.localstorage.setItem('login', method);
       this.localstorage.setItem('token', token);
       this.callReload();
      }
    });
    this.checkSubSilentLogin();

  }
  private promotionalAPIcall(token, method) {
    let promotionalData, language, tokentype;
      tokentype = this.localstorage.getItem('token');
      if (tokentype) {
        language = localStorage.getItem('UserDisplayLanguage');
      } else {
        language = localStorage.getItem('display_language');
      }
      promotionalData = {
        'createPromo' : { 'token' : this.countryToken },
        'translation' : language
      };
      this.userAction.postPromotionalData(promotionalData, token).subscribe(value => {
        let promoDesc;
        if (value && value.subscription_plan && value.subscription_plan.description) {
          promoDesc = value.json().subscription_plan.description;
        }
        localStorage.setItem('promotionalDesc', promoDesc);
        /*Set settings first-time-login = 1*/
         this.setFirstTimeloginSocial('1', token, method);
         this.localstorage.setItem('dialogCheck', 'true');
       }, err => {
         if (err.status === 404 || err.status === 400) {
            /*Set settings first-time-login = 1*/
            this.setFirstTimeloginSocial('1', token, method);
          } else {
            /*Set settings first-time-login = 0*/
            this.setFirstTimeloginSocial('0', token, method);
          }
      });
  }
  private cookieConcent(settingValue) {
    if (this.cookiesLocal === null || undefined) {
    this.cookiesLocal = 'na';
  }
   if (this.marketingLocal === null || undefined) {
    this.marketingLocal = 'na';
  }
  let popup, popupValue, oldCookie, oldRTRM;
  if ( settingValue.length > 0) {
    for (let i = 0; i < settingValue.length; i++) {
      if ( settingValue[i].key === 'popups') {
        popup = true;
        this.responsevalue = JSON.parse(settingValue[i].value);
         oldCookie = this.responsevalue[0].Cookies;
         oldRTRM = this.responsevalue[0].RTRM;
        if (this.responsevalue[0].Cookies === 'na' && this.responsevalue[0].RTRM === 'na' ) {
            popupValue = [{'Cookies': this.cookiesLocal, 'RTRM': this.marketingLocal}];
           const cookies_settings = {
           'key': 'popups',
           'value': JSON.stringify(popupValue)
           };
           this.userSettings.v1SettingsPut(cookies_settings).subscribe(responseput => {
             // todo
           });
        } else if (this.responsevalue[0].RTRM === 'na' || this.responsevalue[0].Cookies === 'na') {
          if (this.responsevalue[0].RTRM === 'na') {
             popupValue = [{'Cookies': oldCookie, 'RTRM': this.marketingLocal}];
          }
          if (this.responsevalue[0].Cookies === 'na') {
             popupValue = [{'Cookies': this.cookiesLocal, 'RTRM': oldRTRM}];
          }
           const cookies_settings = {
           'key': 'popups',
           'value': JSON.stringify(popupValue)
           };
           this.userSettings.v1SettingsPut(cookies_settings).subscribe(responseput => {
             // todo
           });
        }
      }
    }
    if (popup === undefined) {
       let popupValue1;
       popupValue1 = [{'Cookies': this.cookiesLocal, 'RTRM': this.marketingLocal}];
       const cookies_settings = {
       'key': 'popups',
       'value': JSON.stringify(popupValue1)
       };
      this.userSettings.v1SettingsPost(cookies_settings).subscribe(responsePost => {
        // todo
      });
      // post
    }
  } else {
    let popupValue2;
       popupValue2 = [{'Cookies': this.cookiesLocal, 'RTRM': this.marketingLocal}];
       const cookies_settings = {
       'key': 'popups',
       'value': JSON.stringify(popupValue2)
       };
      this.userSettings.v1SettingsPost(cookies_settings).subscribe(responsePost => {
        // todo
      });
  }
}
private settingsFailsRegister(gdprsettings, type, token, method): any {
  this.userSettings.v1SettingsPost(gdprsettings).subscribe(responsePost => {
     if (type !== 'register') {    // login just reload with update GA and QG
       this.updateGMID(token, method);
     } else {                      // check for promotional
        let disp, valuecountryCode;
          disp = this.localstorage.getItem('display_language');
           valuecountryCode = this.settingsService.getCountryValueNew();
            if (valuecountryCode && valuecountryCode.length > 0) {
               this.promotional = valuecountryCode[0].promotional;
               this.countryToken = this.promotional.token;
                if (this.promotional && this.promotional.on === '1') {
                   this.promotionalAPIcall(token, method);
                } else if (this.promotional && this.promotional.on === '0') {
                   this.setFirstTimeloginSocial('1', token, method);
                }
            }
     }
  }, err => {
     this.SettingapiFails();
  });
}
private simulateUserGesture() {
  $('#loaderPage').focus();
  $('#loaderPage').click();
  // console.log("Simulating spinner click event");
  setTimeout(() => {
    // nothing
   }, 0);
}
/////////////////// login with social network end////////////////
  public close(): any { /*closing various flags*/
    if (this.authenticationCode) {
      let currentState;
      currentState = 0;
      this.userAction.checkForDeviceAuthCode(currentState);
    }
    this.signInComponentFlag = false;
    this.loginMobileFlag = false;
    this.loginComponentFlag = true;
    this.loginEmailFlag = false;
    this.registerComponentFlag = false;
    this.registerEmailFlag = false;
    this.callRegisterComponentFlag = false;
    this.signinDetailsFlag = true;
    $('#body').removeClass('scrolldisbale');
    if (this.signinHide) {  /*enabling click on home*/
      this.signinHide.classList.remove('signinCalldisplay');
      this.signinHide.classList.add('signinCall');
    }
    this.headerservicesService.modelChange(false);
    this.headerservicesService.signinChange(false);
    this.headerservicesService.loginHeadingChange(false);
    this.document.getElementById('body').classList.remove('modal-open');
    this.routeservice.Signal(null);
    this.previousUrl = this.localstorage.getItem('previousRoute');
    let postRoute;
    postRoute = this.localstorage.getItem('postSubscriptionRoute');
    if (this.previousUrl !== '/myaccount/subscription' && postRoute) {
      this.localstorage.removeItem('postSubscriptionRoute');
      this.commonService.getPostSubscriptionRoute(postRoute, '');
    } else {
      if (this.previousUrl !== null) {
        if (this.previousUrl.match(/search\/result/g)) {
          let query;
          query = this.previousUrl.slice(17);
          query = decodeURIComponent(query);
          this.router.navigate(['/search/result'], { queryParams: { q: query} });
          this.to.go(this.previousUrl);
        } else if (this.previousUrl.match(/resetpassword/g)) {
          this.router.navigate(['/']);
          this.to.replaceState('/');
        } else {
          this.router.navigate([this.previousUrl]);
          this.to.replaceState(this.previousUrl);
        }
      } else {
        this.router.navigate(['/']);
        this.to.replaceState('/');
      }
    }
  }
  private toggleRegisterHeading(): any {
    $('.auto-loader').css('display', 'none');
    let network;
    network = this.networkService.getPopupStatus();
    this.seoservice.constructHrefLang({id: 1, url: '/register'});
    this.linkservice.addTag({ rel: 'canonical', href: window.location.origin + '/' + this.routeservice.getBaseLocation() + 'register'} );
    if (network === true) {
      this.routeservice.Signal(null);
      // this.to.replaceState('register');
      this.queryparams = window.location.href.split('?')[1];
      if (this.queryparams && this.queryparams.length > 0 ) {
        this.to.replaceState('register?' + this.queryparams);
      } else {
        this.to.replaceState('register');
      }
      this.qgraphevent('signup_initiated', {'method': 'swtichtoSignup', 'country' : this.countrycode });
      this.registerHeadingFlag = false;
      this.loginHeadingFlag = true;
      this.loginComponentFlag = false;
      this.registerComponentFlag = true;
      this.loginMobileFlag = false;
      this.loginEmailFlag = false;
      this.registerMobileFlag = false;
      this.signinDetailsFlag = true;
      this.callRegisterComponentFlag = false;
      this.callLoginComponentFlag = false;
      this.socialSectionFlag = true;
      $('#body').addClass('scrolldisbale');
      this.twitterLogin = false;
      this.pageName = 'register';
      this.gtm.sendPageName(this.pageName);
      this.gtm.sendEvent();
      this.settingsService.bluekaiPagename('register');
      this.gdprFlag = false;
      this.emitGdpr.emit(this.gdprFlag);
    }
  }
  private toggleLoginHeading(): any {
     $('.auto-loader').css('display', 'none');
    let network;
    network = this.networkService.getPopupStatus();
    if (network === true) {
      // this.to.replaceState('signin');
      this.queryparams = window.location.href.split('?')[1];
      if (this.queryparams && this.queryparams.length > 0 ) {
        this.to.replaceState('signin?' + this.queryparams);
      } else {
        this.to.replaceState('signin');
      }
      this.seoservice.constructHrefLang({id: 1, url: '/signin'});
      this.linkservice.addTag({ rel: 'canonical', href: window.location.origin + '/' + this.routeservice.getBaseLocation() + 'signin'} );
      this.qgraphevent('signin_initiated', {'method': 'swtichtosignin', 'country' : this.countrycode });
      this.routeservice.Signal(null);
      this.registerHeadingFlag = true;
      this.loginHeadingFlag = false;
      this.loginComponentFlag = true;
      this.registerComponentFlag = false;
      this.loginMobileFlag = false;
      this.loginEmailFlag = false;
      this.registerMobileFlag = false;
      this.signinDetailsFlag = true;
      this.socialSectionFlag = true;
      this.callRegisterComponentFlag = false;
      this.callLoginComponentFlag = false;
      $('#body').addClass('scrolldisbale');
      this.headerservicesService.forgotEmailValueChange(false);
      this.headerservicesService.forgotMobileValueChange(false);
      this.routeservice.forgotSignal(null);
      this.twitterLogin = true;
      this.pageName = 'sign in';
      this.gtm.sendPageName(this.pageName);
      this.gtm.sendEvent();
      this.settingsService.bluekaiPagename('login');
      this.gdprFlag = false;
    }
  }
  private callLoginMobile(html?: boolean): any {
    let network;
    if (html === undefined) {
      html = false;
    }
    network = this.networkService.getPopupStatus();
    this.seoservice.constructHrefLang({id: 1, url: '/signin/mobile'});
        this.linkservice.addTag({ rel: 'canonical', href: window.location.origin + '/' + this.routeservice.getBaseLocation() + 'signin/mobile'} );
    if (network === true) {
      this.routeservice.Signal(null);
      this.queryparams = window.location.href.split('?')[1];
      if (html) {
        this.to.replaceState('/signin/mobile');
      } else if (this.queryparams && this.queryparams.length > 0 && html === false) {
        this.to.replaceState('/signin/mobile?' + this.queryparams);
      }
      this.headerservicesService.LoginPageChange(true);
      this.headerservicesService.OtherContanierFlagChange(true);
      this.headerservicesService.IconFlagChange(false);
      this.socialSectionFlag = true;
      this.loginMobileFlag = true;
      this.signinDetailsFlag = false;
      this.callLoginComponentFlag = true;
      this.callRegisterComponentFlag = false;
      this.registerHeadingFlag = true;
      this.loginHeadingFlag = false;
      this.pageName = 'sign in/mobile';
      this.gtm.sendPageName(this.pageName);
      this.gtm.sendEvent();
      this.settingsService.bluekaiPagename('login');

    }
  }
  private callLoginEmail(html?: boolean): any {
    let network;
    if (html === undefined) {
      html = false;
    }
    network = this.networkService.getPopupStatus();
    this.seoservice.constructHrefLang({id: 1, url: '/signin/email'});
        this.linkservice.addTag({ rel: 'canonical', href: window.location.origin + '/' + this.routeservice.getBaseLocation() + 'signin/email'} );
    if (network === true) {
      this.routeservice.Signal(null);
      // this.to.replaceState('signin/email');
      this.queryparams = window.location.href.split('?')[1];
      if (html) {
        this.to.replaceState('/signin/email');
      } else if (this.queryparams && this.queryparams.length > 0 && html === false) {
        this.to.replaceState('/signin/email?' + this.queryparams);
      }
      this.headerservicesService.LoginPageChange(true);
      this.headerservicesService.OtherContanierFlagChange(true);
      this.loginEmailFlag = true;
      this.signinDetailsFlag = false;
      this.callLoginComponentFlag = true;
      this.callRegisterComponentFlag = false;
      this.headerservicesService.IconFlagChange(true);
      this.registerHeadingFlag = true;
      this.loginHeadingFlag = false;
      this.pageName = 'sign in/email';   // send page name to gtm
      this.gtm.sendPageName(this.pageName);
      this.gtm.sendEvent();
      this.settingsService.bluekaiPagename('login');

    }
  }
  private callRegisterMobile(html?: boolean): any {
    let network;
    if (html === undefined) {
      html = false;
    }
    network = this.networkService.getPopupStatus();
    this.seoservice.constructHrefLang({id: 1, url: '/register/mobile'});
        this.linkservice.addTag({ rel: 'canonical', href: window.location.origin + '/' + this.routeservice.getBaseLocation() + 'register/mobile'} );
    if (network === true) {
      this.queryparams = window.location.href.split('?')[1];
      if (html) {
        this.to.replaceState('/register/mobile');
      } else if (this.queryparams && this.queryparams.length > 0 && html === false) {
        this.to.replaceState('/register/mobile?' + this.queryparams);
      }
      this.registerMobileFlag = true;
      this.signinDetailsFlag = false;
      this.callRegisterComponentFlag = true;
      this.callLoginComponentFlag = false;
      this.registerEmailFlag = false;
      this.registerHeadingFlag = false;
      this.loginHeadingFlag = true;
      this.registerComponentFlag = false;
      this.loginComponentFlag = true;
      this.pageName = 'register/mobile';    // send page name to gtm
      this.gtm.sendPageName(this.pageName);
      this.gtm.sendEvent();
      this.settingsService.bluekaiPagename('register');

    }
  }
  private callRegisterEmail(html?: boolean): any {
    let network;
    if (html === undefined) {
      html = false;
    }
    network = this.networkService.getPopupStatus();
    this.seoservice.constructHrefLang({id: 1, url: '/register/email'});
        this.linkservice.addTag({ rel: 'canonical', href: window.location.origin + '/' + this.routeservice.getBaseLocation() + 'register/email'} );
    if (network === true) {
      // this.to.replaceState('register/email');
      this.queryparams = window.location.href.split('?')[1];
      if (html) {
        this.to.replaceState('/register/email');
      } else if (this.queryparams && this.queryparams.length > 0 && html === false) {
        this.to.replaceState('/register/email?' + this.queryparams);
      }
      this.registerEmailFlag = true;
      this.signinDetailsFlag = false;
      this.callRegisterComponentFlag = true;
      this.callLoginComponentFlag = false;
      this.registerHeadingFlag = false;
      this.loginHeadingFlag = true;
      this.registerComponentFlag = false;
      this.loginComponentFlag = true;
      this.pageName = 'register/email';
      this.gtm.sendPageName(this.pageName);
      this.gtm.sendEvent();
      this.settingsService.bluekaiPagename('register');
    }
  }
  private changeregister(reg) {
    this.signinRightTopFlag = reg.top;  // to get the data chnaged from registercomponent
    this.profileFlag = reg.profile;
    this.bg_imageFlag = reg.bg;
  }
  private changeprofile(reg) {
    this.profileFlag = reg.p1;
    this.signInComponentFlag = reg.p2;
  }
  private CommonConfigCall(token) {
   let params;
        params = 'bearer ' + token ;
       this.config = {
          apiKey: params,
          username: '',
          password: '',
          accessToken: '',
          withCredentials: false
        };
  }
  private GAUpdateCommon(gAevent, loginMethod) {    ///  GA event = LoginSuccess/registerFailure  /// loginMethod = fb,g+,tw,mob,em
    this.tokenValue = this.gtm.fetchToken();
    this.timestampTime = this.gtm.fetchCurrentTime();
    this.timestampDateTime = this.gtm.fetchCurrentDate();
    this.clientID = this.gtm.fetchClientId();
    this.marketingValue = this.gtm.fetchMarketing();
    this.gtm.logEvent({
          'event' : gAevent,
          'G_ID' : this.tokenValue,
          'Client_ID': this.clientID,
          'retargeting_remarketing' : this.marketingValue,
          'LoginMethod' : loginMethod,
          'operator': 'NA',
          'TimeHHMMSS': this.timestampTime,
          'DateTimeStamp': this.timestampDateTime
        });
  }
  public ngOnDestroy() {
    this.document.getElementById('body').classList.remove('modal-open');
  }
  private qgraphevent(eventname, object) {
    if (this.window.qg) {
      // if (this.qgraph) {
      //   delete object.country;
      //   qg('event', eventname, object);
      // } else {
        qg('event', eventname, object);
      // }
    }
  }
  private checkSubSilentLogin(): any {
  let recVal, sendVal;
  recVal = this.localstorage.getItem('subSilentLogin');
  if (recVal) {
    sendVal = {
      'subValue' : true,
      'loginValue' : true
    };
    this.localstorage.setItem('subSilentLogin', JSON.stringify(sendVal));
  }
}
}
