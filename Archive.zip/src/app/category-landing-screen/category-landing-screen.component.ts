import { Component, OnInit, OnDestroy, ViewChild, ElementRef, HostListener } from '@angular/core';
import { FilterService } from '../services/filter.service';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { Http} from '@angular/http';
import {CollectionApi} from '../../data/gwapi_catalog/api/CollectionApi';
import { Location } from '@angular/common';
import { environment } from '../../environments/environment';
import * as $ from 'jquery';
import { RouteService } from '../services/route.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { HeaderservicesService } from '../services/headerservices.service';
import {  NetworkService  } from '../services/network.service';
import { UserProfileService } from '../services/user-profile.service';
import {CommonService} from '../services/common.service';
import { Subject } from 'rxjs/Subject';
import { SeoService } from '../services/seo.service';
import { LinkService } from '../services/link.service';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { SettingsService } from '../services/settings.service';
import { SubscriptionService } from '../services/subscription.service';
import { Meta, Title} from '@angular/platform-browser';
declare let googletag;
const freeChannelTag = 'free_channels';

@Component({
	selector: 'app-category-landing-screen',
	templateUrl: './category-landing-screen.component.html',
	styleUrls: ['./category-landing-screen.component.less']
})
export class CategoryLandingScreenComponent implements OnInit, OnDestroy {
	@ViewChild('load_button') public load_button: ElementRef;
  public collectionTags: any;
	public current: any = {'content': []};
	public sub: any;
	public type: any;
	public movies: any;
	public category: any;
	public router: any;
	public id: any;
	public name: any;
	public router2: any;
	public data: any;
	public title: any;
	public categoryId: any;
	public token: any;
	public assetBasePath = environment.assetsBasePath;
	private ngUnsubscribe = new Subject<any>();
	public show_title: any;
	public localstorage: any;
	public window: any;
	public document: any;
	public navigator: any;
	public touchScreen: any = false;
	public processPending: any;
	public totalPages: any;
	public config: any;
	public pageSize: any = 24;
	public pageCollectionSize: any;
	public page: any = 1;
	public countryCode: any;
	public dataUnavailable: any = true;
	public apiRetry: any = 2;
	public apiRetryCount: any = 1;
	public infiniteScrollDistance: any = 0.5;
	public pagecollection: boolean;
	public pagecollectiondata: any;

	public popularData: any;
	public showViewAll = false;
	public popularTitle: any;
	public popularTitle_en: any;
	public popularItems: any;
	public banner: any;
	public count_ad: any = 0;
  	// public ads_sum: any = 0;
	// public desktopTag: any;
	// public mobileTag: any;
	public nativeTag: any;
  	public nativeAdPosition: any;
	public carouselTitle: any;
	public carousel_form: any;
	public carousel: any;
	public carouselCollection: any;
	public carousel_element: any;
	public channelsTitle: any;
	public channelsTitleEng: any;
	public channels: any;
	public channelsHover: any;
	public link: any;
	public recommended: any;
	public channelData: any;
	public adSpacing: any = 3;
  	// public totalAds: any;
	public popular: any;
	public popularShow: any;
	public channelHover: any;
	public count: any = 0;
	public premiumPage: any;
	// public dataAvailable: any;
	public tagValue: any;
	public showMastAds: any;
	public mastHeadAds: any;
	public mastHeadStyle: any;
	public mastAd: any = false;
	public adSlot: any;
	public showNativeAds: any = false;
	public nativeAds: any;
	public premiumUser: any;
	public mobile: any;
	public mastTag: any;
	public mastDivID: any;
	public plans: any;
	public googletagAvailable: any;
	public timer: any = [];
	public shownodataAvailable = false;
	// public adResponse: any;
  public traylength: any = 0;
	public dataTitle: any = '';
	public scrollCount: any = 0;

  public footerAd: any;
  private skippedAdIndex: any;
  public footerAdRendered: any = false;
  public footerAdSlot: any;
  public currentRoute: any;
	constructor(private titleService: Title, private metaService: Meta, private subscriptionService: SubscriptionService, private settingsService: SettingsService, @Inject(PLATFORM_ID) private platformId: Object, private linkservice: LinkService, private seoService: SeoService, private commonService: CommonService, private userProfileService: UserProfileService, private networkService: NetworkService, private gtm: GoogleAnalyticsService,
		private routeservice: RouteService, private location: Location, private route: ActivatedRoute , private filterService: FilterService, private router_link: Router, private http: Http, private headerservicesService: HeaderservicesService) {
		if (isPlatformBrowser(this.platformId)) {
			this.localstorage = localStorage;
			this.window = window;
			this.document = document;
			this.navigator = navigator;
		}
		this.router = router_link;
		this.router2 = this.window.location.pathname;
		this.routeservice.setRoute(this.router2);
		this.routeservice.setLoginRoute(this.window.location.pathname);
		this.headerservicesService.viewChange(this.router2);
	}

	public ngOnInit() {
		if (isPlatformBrowser(this.platformId)) {
			this.localstorage = localStorage;
			this.window = window;
			this.document = document;
			this.navigator = navigator;
			window.scrollTo(0, 0);
		}
		this.countryCode = this.settingsService.getCountry();
		this.gtm.storeWindowError();
		let network;
		network = this.networkService.getScreenStatus();
		this.pageCollectionSize = 5;
		if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
			this.touchScreen = true;
			this.infiniteScrollDistance = 6;
			this.pageCollectionSize = 3;
		}
		if (network) {
			this.token = this.localstorage.getItem('token');
			if (this.token) {
				this.userProfileService.httpgetFavoriteData();
				this.userProfileService.httpgetWatchData();
			}
			this.sub = this.route.params.subscribe(params => {
				this.window.scrollTo(0, 0);
  				this.count = 0;

				this.page = 1;
				this.current = {'content': []};
				this.category = params['category'];
				this.categoryId = params['categoryId'];
				this.id = params['id'];
				this.name = params['name'] ;
				this.config	 = {
					apiKey: ' ',
					username: ' ',
					password: ' ',
					accessToken: ' ',
					withCredentials: false
				};
				$('#loaderPage').css('display', 'block');
				// this.getAd();
				this.initialApiCall();
			});
			window.scrollTo(0, 0);
		}
	}
	@HostListener('window:scroll', ['$event'])
	public onScrollEvent($event) {
		let factor;
		if (this.touchScreen) {
			factor = 0.35;
		} else if (!this.touchScreen) {
			factor = 0.75;
		}
		if ($(this.window).scrollTop() >= ($(this.document).height() - $(this.window).height()) * factor) {
			// this.load();
		}
	}
	/*--------------new ad implementation--------------------*/
	// private getAd(): any {
	//    let adUrl, country, userType;
	//    country = this.settingsService.getCountryValue();
	//    userType = this.commonService.getUserType();
	//    adUrl = environment.adBasePath +
	//    '?collection_id=' + this.categoryId +
	//    '&platform_name=' + (this.touchScreen ? 'mobile_web' : 'desktop_web') +
	//    '&user_type=' + userType +
	//    '&country=' + country.country_code +
	//    (country.state_code ? ('&state=' + country.state_code) : '');
	//     this.http.get(adUrl).timeout(environment.timeOut).takeUntil(this.ngUnsubscribe).subscribe(value => {
	// 	    if (value && value['_body']) {
	// 		    this.adResponse = JSON.parse(value['_body']);
	// 	    }
	//     });

	// }
		private setAd(): any {
			let userType;
    		userType = this.commonService.getUserType();
				this.mastHeadAds = this.commonService.getAdsValue(); // this.adResponse;
		    this.nativeAds = this.commonService.getAdsValue(); // this.adResponse;
		    this.showNativeAds = this.nativeAds && this.nativeAds['native_tags_ads'] && this.nativeAds['native_tags_ads'][userType] && this.nativeAds['native_tags_ads'][userType].ads_visibility && this.nativeAds['native_tags_ads'][userType]['screens'];
		    this.showMastAds = this.mastHeadAds && this.mastHeadAds['masthead_ads'] && this.mastHeadAds['masthead_ads'][userType] && this.mastHeadAds['masthead_ads'][userType].ads_visibility && this.mastHeadAds['masthead_ads'][userType]['screens'];
		    if (this.pagecollection && this.showMastAds) {
		      this.mastHeadAds = this.mastHeadAds['masthead_ads'][userType]['screens'];
		      let mast_head_ad, scope;
		      scope = this;
		      mast_head_ad = $.grep(this.mastHeadAds, function(e) {
		          return e.screen_id === 'collections';
		        });
		      if (mast_head_ad && mast_head_ad[0] && mast_head_ad[0].ad_data && mast_head_ad[0].ad_data[0]) {
		          mast_head_ad = mast_head_ad[0].ad_data[0];
		          this.mastDivID = mast_head_ad.div_id;
		          this.mastTag = mast_head_ad.ad_tag;
		          this.mastHeadStyle = this.commonService.getAdType(mast_head_ad.ad_type);
		      }
		      if (this.mastDivID && this.mastTag) {
		        this.adCreation(this.mastTag, this.mastDivID, mast_head_ad.ad_dimension, 'masthead');
		        // this.adCreation(this.mastTag, this.mastDivID, ['fluid'], 'masthead');
		      }
		    }
		    if (this.showNativeAds) {
		      this.nativeAds = this.nativeAds['native_tags_ads'][userType]['screens'];
		      let native_ad, scope;
		      scope = this;
		      native_ad = $.grep(this.nativeAds, function(e) {
		          return e.screen_id === 'collections';
		        });
		      if (native_ad && native_ad[0] && native_ad[0].ad_data && native_ad[0].ad_data.length > 0) {
		          this.nativeTag = native_ad[0].ad_data;
		          this.nativeTag = this.subscriptionService.formatDuplicate(this.nativeTag, 'position');
		          this.nativeAdPosition = this.nativeTag.map(a => a.position);
		          let index;
          		index = native_ad[0].ad_data.findIndex(ad => ad.position === 'footer');
		          if (index !== -1 && native_ad[0].ad_data[index]) {
	            this.footerAd = native_ad[0].ad_data[index];
	            this.footerAd.adStyle = this.commonService.getAdType(this.footerAd.ad_type);
	            this.footerAd.adNative = this.footerAd.div_id;
	            this.googleAdCreation('footer', index);
	          }
		      }
		    }
	}
/*--------------new ad implementation--------------------*/
	public initialApiCall() {
	let x , tempTitle, getLanguageValue, userType,languages,content_lang,content_language;
	if(this.settingsService.getpage()== 'news' && this.settingsService.getconsiderMusicnode()) {
       content_lang = this.token ? localStorage.getItem('UserContentLanguage') : localStorage.getItem('ContentLang');
      let str1  =this.settingsService.getpasscontentLang()
      let str2 = str1.lang.join()
			            if(str1.value == true) {
              				let result = (content_lang + ',' + str2)
                                            .split(',')
                                              .filter(function(w, i, words) { return i === words.indexOf(w) })
                                                  .join(',')

						        content_language = result;
						      } else {
						        content_language = null;
						      }
						    } else {
						      content_language = null;
						    }
      getLanguageValue = this.commonService.getLanguagesValue();
        //languages = this.considerextralang();
        userType = this.commonService.getUserType();
		x = new CollectionApi(this.http, null, this.config);
		x.v1DetailCollectionByIdGet(this.categoryId, this.page, this.pageSize, null, this.countryCode, null, null, content_language, getLanguageValue).timeout(environment.timeOut).takeUntil(this.ngUnsubscribe).subscribe(value => {
			$('#loaderPage').css('display', 'none');
			this.apiRetryCount = 1;
			if (value.tags && value.tags.indexOf('pagecollection') !== -1) {
				this.shownodataAvailable = false;
				this.pagecollection = true;
				this.setAd();
				this.processPending = false;
				this.pagecollectiondata = [];
				value.items = value.buckets;
				value.items = this.commonService.removeWebView(value.items);
				this.data = value;
				this.show_title = this.commonService.convertToLowercase(this.data.original_title);
				if (this.data && this.data.extended && this.data.extended.seo_title) {
	            	tempTitle = (this.data.extended.seo_title !== null || this.data.extended.seo_title !== undefined || this.data.extended.seo_title !== '') ? this.data.extended.seo_title : this.data.original_title;
	          	} else {
	            	tempTitle = (this.data.seo_title && (this.data.seo_title !== null || this.data.seo_title !== undefined || this.data.seo_title !== '')) ? this.data.seo_title : this.data.original_title;
	          	}
	          	if (this.data && this.data.tags) {
	          		this.type = this.data.tags[0];
	          	}
				this.totalPages = Math.ceil((this.data.total) / (this.pageSize));
	    // if (value.items && value.items.length > 0 && this.nativeAdPosition && this.nativeAdPosition.length > 0) {
	    //     this.traylength = 0;
	    //     for (let index1 = 0; index1 < value.items.length; index1++) {
	    //       if (value.items[index1].tags && (value.items[index1].tags[0] === 'banner')) {
	    //         this.traylength++;
	    //       } else {
	    //         let adIndex;
	    //         adIndex = this.nativeAdPosition.indexOf((((this.page - 1) * this.pageSize) + index1 + 1 - this.traylength).toString());
	    //         if (adIndex >= 0) {
	    //           this.totalAds ++;
	    //           this.googleAdCreation('native', adIndex);
	    //         }
	    //       }
	    //     }
	    //     this.ads_sum = this.ads_sum + this.totalAds;
	    //   }
		  	this.initialisePageCollectionData(this.data);
		  	this.AdImplementation(this.data);
			} else {
				value.items = value.buckets[0].items;
				value.items = this.commonService.removeWebViewItems(value.items);
				this.pagecollection = false;
				this.setAd();
				// value.items = value.buckets.items;
				this.data = value;
				this.show_title = this.commonService.convertToLowercase(this.data.original_title);

				if (this.data && this.data.extended && this.data.extended.seo_title) {
	            	tempTitle = (this.data.extended.seo_title !== null || this.data.extended.seo_title !== undefined || this.data.extended.seo_title !== '') ? this.data.extended.seo_title : this.data.original_title;
	          	} else {
	            	tempTitle = (this.data.seo_title && (this.data.seo_title !== null || this.data.seo_title !== undefined || this.data.seo_title !== '')) ? this.data.seo_title : this.data.original_title;
	          	}
	          	if (this.data && this.data.tags) {
	          		this.type = this.data.tags[0];
	          	}
	   //        	this.seoService.updateCategoryLanding(tempTitle, this.type);
				// this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + this.routeservice.getBaseLocation()  + 'collections' + '/' + this.show_title  + '/' + this.data.id} );
				this.initialiseData(this.data);
				let scope;
				scope = this;
				setTimeout(() => {
					scope.commonService.updateTime();
				});
				this.totalPages = Math.ceil((this.data.total) / (this.pageSize));
				this.processPending = false;
			}
			 if (this.data.meta_title && (this.data.meta_title !== null || this.data.meta_title !== '')) {
		        this.titleService.setTitle(this.data.meta_title);
		        this.metaService.updateTag({ name: 'twitter:title', content: this.data.meta_title });
		        this.metaService.updateTag({ property: 'og:title', content: this.data.meta_title  });

		    } else {
		        this.seoService.updateCategoryLanding(tempTitle, this.type);
		    }

		    if (this.data.meta_description && (this.data.meta_description !== null || this.data.meta_description !== '')) {
		      this.metaService.updateTag({name: 'description', content : this.data.meta_description });
		      this.metaService.updateTag({ property: 'og:description', content: this.data.meta_description});
		      this.metaService.updateTag({ property: 'twitter:description', content: this.data.meta_description});
		    } else {
		      this.seoService.updateCategoryLanding(tempTitle, this.type);
		    }

		    if (this.data.meta_keywords && (this.data.meta_keywords !== null || this.data.meta_keywords !== '')) {
		      this.metaService.updateTag({name: 'keywords', content : this.data.meta_keywords });
		    } else {
		      this.seoService.updateCategoryLanding(tempTitle, this.type);
		    }

			this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + this.routeservice.getBaseLocation()  + 'collections' + '/' + this.show_title  + '/' + this.data.id} );
			this.sendPageName();
		},
		err => {
			$('#loaderPage').css('display', 'none');
			this.gtm.sendErrorEvent('api', err);
			this.headerservicesService.breadCrump('');
			if (err.status === 401 && this.apiRetryCount < this.apiRetry) {
				this.apiRetryCount ++;
				this.processPending = true;
				this.commonService.refreshToken().then(
					() => {
						this.initialApiCall();
					},
					() => {
						this.processPending = false;
						this.dataUnavailable = false;
					},
					);
			}  else {
				this.processPending = false;
				this.dataUnavailable = false;
				this.shownodataAvailable = true;
			}
		});

	}

public AdImplementation(value) {
  if (value.items && value.items.length > 0 && this.nativeAdPosition && this.nativeAdPosition.length > 0) {
      this.traylength = 0;
      for (let index1 = 0; index1 < value.items.length; index1++) {
        if (value.items[index1].tags && (value.items[index1].tags[0] === 'banner')) {
          this.traylength++;
        } else {
          let adIndex, adPosition;
          adPosition = ((this.page - 1) * this.pageSize) + index1 + 1 - this.traylength;
          // ((this.collectionPageNo - 1) * this.collectionPageSize) + index1 + 1 - this.traylength;
          adIndex = this.nativeAdPosition.indexOf((adPosition).toString());
          // if (adIndex >= 0) {
          if (adIndex >= 0) {
            // this.totalAds ++;
            if (this.footerAd && adPosition === this.pagecollectiondata.length) {
            // if (this.footerAd && this.footerAdRendered && adPosition === this.moviesCategory.length) {
              this.skippedAdIndex = adIndex;
            } else {
              this.googleAdCreation('native', adIndex);
            }
          }
        }
      }
      // this.ads_sum = this.ads_sum + this.totalAds;
    }
	}

    public  considerextralang(): any{
	    let value, userToken,contentLanguages = [],contentlang,pushLang = [];
	    value = this.settingsService.getpasscontentLang();
	    userToken = localStorage.getItem('token');
	    contentLanguages = [];	    
	    contentlang = userToken ? localStorage.getItem('UserContentLanguage') : localStorage.getItem('ContentLang'); 
	    if (value && value.value) {
	      pushLang = contentlang.split(',');
	      for ( let i = 0; i < pushLang.length; i++) {
	        contentLanguages.push(pushLang[i]);
	      }
	      for (let i = 0 ; i < value.lang.length; i++) {
	        if (pushLang.indexOf(value.lang[i]) === -1) {
	          contentLanguages.push(value.lang[i]);
	        }
	      }
	      return contentLanguages.join();
	    } else {
	    	return contentlang;
	    }
  	}
	private sendPageName(): any {
    	let configData, pageName, languageArray, languages;
    	languages = this.data.languages;
        languageArray = [];
    	configData = this.settingsService.getCompleteConfig();
		if (configData && configData.languages_labels && configData.languages_labels['en'] && languages && languages.length > 0) {
	       for (let j = 0; j < languages.length; j++ ) {
             let language;
             language = (configData.languages_labels['en'][languages[j]] === undefined) ? '' : configData.languages_labels['en'][languages[j]];
             if (language) {
	             languageArray.push(language);
             }
           }
		}
	    pageName = ((languageArray && languageArray.length > 0) ? languageArray.join(',') : 'NA') + '|Collections|NA|NA|' + this.data.original_title;
        this.gtm.sendPageName(pageName);
        this.gtm.sendEvent();
	}
	public load() {
		let content_language,content_lang
		// console.log(this.totalPages,this.page, 'checkout')
		if (this.networkService.getPopupStatus()) {
			if (this.processPending === false) {
				this.page++;
				// console.log(this.totalPages,this.page, 'check')
				if (this.totalPages >= this.page) {
					this.processPending = true;
					$('.auto-loader').css('display', 'block');
					let x, getLanguageValue, userType,languages ;
        			getLanguageValue = this.commonService.getLanguagesValue();
                    userType = this.commonService.getUserType();
        			languages = this.considerextralang();

					x = new CollectionApi(this.http, null, this.config);
					if(this.settingsService.getpage()== 'news' && this.settingsService.getconsiderMusicnode()) {
				       content_lang = this.token ? localStorage.getItem('UserContentLanguage') : localStorage.getItem('ContentLang');
				      let str1  =this.settingsService.getpasscontentLang()
				      let str2 = str1.lang.join()
				            if(str1.value == true) {
              				let result = (content_lang + ',' + str2)
                                            .split(',')
                                              .filter(function(w, i, words) { return i === words.indexOf(w) })
                                                  .join(',')

						        content_language = result;
						      } else {
						        content_language = null;
						      }
						    } else {
						      content_language = null;
						    }
      //getLanguageValue = this.commonService.getLanguagesValue();

					x.v1DetailCollectionByIdGet(this.categoryId, this.page, this.pageSize, null, this.countryCode, null, null, languages, getLanguageValue).timeout(environment.timeOut).takeUntil(this.ngUnsubscribe).subscribe(value => {
						this.apiRetryCount = 1;
						if (value.tags && value.tags.indexOf('pagecollection') !== -1) {
							this.pagecollection = true;
							this.processPending = false;
							this.shownodataAvailable = false;
							// this.pagecollectiondata = [];
							value.items = value.buckets;
							value.items = this.commonService.removeWebView(value.items);
							this.data = value;
							this.initialisePageCollectionData(this.data);
						            /*--------------new ad implementation--------------------*/
				          	if (value.items && value.items.length > 0 && this.nativeAdPosition && this.nativeAdPosition.length > 0) {
					            if (this.skippedAdIndex !== undefined) {
					              this.googleAdCreation('native', this.skippedAdIndex);
					              this.skippedAdIndex = undefined;
					            }
					            for (let index1 = 0; index1 < value.items.length; index1++) {
					              if (value.items[index1].tags && (value.items[index1].tags[0] === 'banner')) {
					                this.traylength++;
					              } else {
					                // let adIndex;
					                // adIndex = this.nativeAdPosition.indexOf((((this.page - 1) * this.pageSize) + index1 + 1 - this.traylength).toString());
					                // if (adIndex >= 0) {
					                //   // this.totalAds ++;
					                //   this.googleAdCreation('native', adIndex);
					                // }
					                let adIndex, adPosition;
					                adPosition = ((this.page - 1) * this.pageSize) + index1 + 1 - this.traylength;
					                adIndex = this.nativeAdPosition.indexOf(adPosition.toString());
					                if (adIndex >= 0) {
					                  // this.totalAds ++;
					                  if (this.footerAd && adPosition === this.pagecollectiondata.length) {
					                  // if (this.footerAd && this.footerAdRendered && adPosition === this.moviesCategory.length) {
					                    this.skippedAdIndex = adIndex;
					                  } else {
					                    this.googleAdCreation('native', adIndex);
					                  }
					                }
					              }
					            }
					            // this.ads_sum = this.ads_sum + this.totalAds;
				          	}
        						/*--------------new ad implementation--------------------*/
							// console.log(this.pagecollectiondata,'pagecollectiondata')
						} else {
								value.items = value.buckets[0].items;
								value.items = this.commonService.removeWebViewItems(value.items);
								// value.items = value.buckets.items;
								this.data = value;
								this.processPending = false;
								this.current.content.push.apply(this.current.content, this.data.items);
								$('.auto-loader').css('display', 'none');
								let scope;
								scope = this;
								setTimeout(() => {
									scope.commonService.updateTime();
								});

						}
						if (this.scrollCount > 0) {
						    this.gtm.sendEventDetails({'event': 'scrollTracking', 'ScrollCount': '1'});
						}
						this.scrollCount++;
					},
					err => {
						this.gtm.sendErrorEvent('api', err);
						$('.auto-loader').css('display', 'none');
						if (err.status === 401 && this.apiRetryCount < this.apiRetry) {
							this.apiRetryCount ++;
							this.commonService.refreshToken().then(
								() => {
									this.processPending = false;
									this.page --;
									this.load();
								},
								() => {
									this.processPending = false;
								},
								);
						}  else {
							this.processPending = false;
							this.shownodataAvailable = true;
						}
					});
				}
			}}
		}

		public initialiseData(data: any): void {
			this.title = {'title': data.title, 'original_title': data.original_title, 'seo_title': data.seo_title};
			this.dataTitle = data.title;
			this.updateBreadCrump(data.title);
			let collectionTitle;
			if (data.seo_title) {
				collectionTitle =  this.commonService.convertToLowercase(data.seo_title);
			} else {
				collectionTitle = this.commonService.convertToLowercase(data.original_title);
			}
			if (collectionTitle !== this.name) {
				// if (window.location.search.length > 0){
				// } else {
				// 	this.location.replaceState('/collections/' + collectionTitle + '/' + data.id);
				// }
				if (window.location.search.length <= 0) {
					this.location.replaceState('/collections/' + collectionTitle + '/' + data.id);
				}
			}
			if (data.items.length <= 0 ) {
				this.dataUnavailable = false;
			}
			if (data && data.tags && data.tags[0] === 'movies') {
				this.current = {   'type': 'movies',
				'content': (data.items) };
			} else if (data && data.tags && data.tags[0] === 'originals') {
				this.current = {   'type': 'zeeOriginals',
				'content': data.items };
			} else {
				this.current = {   'type': 'tvshows',
				'content': data.items };
			}
		}
		public updateBreadCrump(data: any) {
			let breadcrump;
			breadcrump = [
			{
				'label': 'BREADCRUMB.HOME',
				'url': '/',
				'enable': true
			},
			{
				'label': this.dataTitle,
				'url': this.router2,
				'enable': false
			},
			];
			if (this.dataTitle === '') {
				this.headerservicesService.breadCrump('');
			} else {
				this.headerservicesService.breadCrump(breadcrump);
			}
		}
		public ngOnDestroy() {
			this.ngUnsubscribe.next();
			this.ngUnsubscribe.complete();
			this.googletagAvailable = this.commonService.checkGoogleTag();
			  if (this.googletagAvailable === 'true' && googletag.destroySlots) {
			    googletag.destroySlots();
			    // clear all timers in the array
			    for (let i = 0; i < this.timer.length; i++) {
			      clearTimeout(this.timer[i]);
			    }
			  }
			   //  if  (this.carousel) {
				  //   $('.breadcrumInit').removeClass('topCarousel');
				  // }
			this.linkservice.removeCanonicalLink();
		}


		public initialisePageCollectionData(data: any): void {
			this.pagecollection = true;
			this.title = {'title': data.title, 'original_title': data.original_title};
			this.dataTitle = data.title;
			this.updateBreadCrump(data.title);
		  this.count ++;
		  let scope;
		  scope = this;
		  if (data.items && data.items.length > 0) {
		    for (let index = 0; index < data.items.length; index++) {
		      if (data.items[index].tags && data.items[index] && data.items[index].items && (data.items[index].tags[0] === 'Popular' || data.items[index].tags[0] === 'popular')) {
		        let popular;
		        popular = [];
		        this.popularData = data.items[index].items;
		        if (this.popularData.length > 5) {
		          this.showViewAll = true;
		        }
		        this.popularTitle = data.items[index].title;
		        this.popularTitle_en = data.items[index].original_title;
		        if (this.window.innerWidth < 769) {
		          this.popularItems = this.popularData;
		          this.banner = [undefined];
		        } else {
		          this.popularData[0].type = 'popular_banner';
		          this.banner = [
		          this.popularData[0]
		          ];
		          this.popularItems = this.popularData.slice(1, 5);
		        }
		        if (this.popularData.length > 0) {
		          this.popularShow = true;
		        } else {
		          this.popularShow = false;
		        }
		        let idValueNative, adIndex, adStyle;
		        idValueNative = '';
		        if (this.nativeAdPosition && this.nativeAdPosition.length > 0) {
		          adIndex = this.nativeAdPosition.indexOf((this.count_ad + 1).toString());
		          if (adIndex >= 0 && this.nativeTag && this.nativeTag[adIndex]) {
		            idValueNative = this.nativeTag[adIndex].div_id;
            		adStyle = this.commonService.getAdType(this.nativeTag[adIndex].ad_type);
		          }
		        }
        		this.popular = { 'id' : data.items[index].id, 'adNative': idValueNative, 'adStyle': adStyle, 'listType': 'popular', 'titleMain': this.popularTitle, 'titleMain_en': this.popularTitle_en, 'bannerItem': this.banner,  'type': 'home', 'link': 'collections',
			        'content': this.popularItems, 'parentType': 'homeScreen', popularShow: this.popularShow
			      };
      		  this.count_ad++;
		      this.pagecollectiondata.push(this.popular);
		      // console.log(this.pagecollectiondata,'pagecollectiondata')
		    } else if (data.items[index] && data.items[index].items && data.items[index].tags && (data.items[index].tags[0] === 'banner')) {
	      		if (!this.carousel) {
			      this.carouselTitle = {'title': data.items[index].title, 'original_title': data.items[index].original_title};
			      this.carousel_form = [];
			      if (data.items[index].items && data.items[index].items.length > 0) {
			        this.carousel = data.items[index].items;
	        		this.carouselCollection = data.items[index].id;
					this.collectionTags = data.items[index].tags;
				     // $('.breadcrumInit').addClass('topCarousel');
			        setTimeout(function() {
			          if (scope.router.currentUrlTree.root.children.primary) {
			            if (scope.router.currentUrlTree.root.children.primary.segments.length === 3) {
			              scope.currentRoute = scope.router.currentUrlTree.root.children.primary.segments[1].path;
			            } else {
			              scope.currentRoute = scope.router.currentUrlTree.root.children.primary.segments[0].path;
			            }
			            if (scope.carousel_element && scope.currentRoute === 'search') {
			              scope.carousel_element.stopCarousel();
			            }
			          }
			        }, 0);
			      }
			  	}
		    } else if (data.items[index] && data.items[index].items && data.items[index].tags && (data.items[index].tags[0] === 'channels')) {
		      this.channelData = [];
		      if (data.items[index].items) {
		        for (let index_sub = 0; index_sub < data.items[index].items.length; index_sub++) {
		          if (data.items[index].items[index_sub]) {
		            if (this.data.items[index].items[index_sub].list_image)  {
		              this.data.items[index].items[index_sub].image_url = this.settingsService.getbasePath() + this.data.items[index].items[index_sub].id + '/list/' + '170x120/' + this.data.items[index].items[index_sub].list_image;
		            } else {
		              this.data.items[index].items[index_sub].image_url = environment.assetsBasePath + 'assets/default/epg_channel_logo.png';
		            }
		            if (this.data.items[index].items[index_sub].cover_image)  {
		              this.data.items[index].items[index_sub].cover_url = this.settingsService.getbasePath() + this.data.items[index].items[index_sub].id + '/cover/' + '170x120/' + this.data.items[index].items[index_sub].cover_image;
		            } else {
		              this.data.items[index].items[index_sub].cover_image = environment.assetsBasePath + 'assets/default/epg_channel_logo.png';
		            }
		            this.channelData.push(data.items[index].items[index_sub]);
		          }
		        }
		        this.channelsTitle = data.items[index].title;
		        this.channelsTitleEng = data.items[index].original_title;
		        this.channels = this.channelData.slice(0, 6);
		        this.channelHover = [false, false, false, false, false, false];
		          let idValueNative, adIndex, adStyle;
			      idValueNative = '';
			      if (this.nativeAdPosition && this.nativeAdPosition.length > 0) {
			        adIndex = this.nativeAdPosition.indexOf((this.count_ad + 1).toString());
			        if (adIndex >= 0 && this.nativeTag && this.nativeTag[adIndex]) {
			          idValueNative = this.nativeTag[adIndex].div_id;
            adStyle = this.commonService.getAdType(this.nativeTag[adIndex].ad_type);
			        }
			      }
			      this.count_ad++;
		        this.pagecollectiondata.push({'listType': 'channel', 'adNative': idValueNative, 'adStyle': adStyle, 'title': this.channelsTitle , 'original_title': data.items[index].original_title , 'content': this.channels, 'tags': data.items[index].tags});
		      }
		    } else {
		      if (data.items[index] && data.items[index].tags && data.items[index].tags[0] === 'movies') {
		        this.type = 'movies';
		        this.link = 'movies';
		      } else if (data.items[index] && data.items[index].tags &&  data.items[index].tags[0] === 'tvshows') {
		        this.type = 'tvshows';
		        this.link = 'tvshows';

		      } else if (data.items[index] && data.items[index].tags &&  data.items[index].tags[0] === 'originals') {
		        this.type = 'zee5originals';
		        this.link = 'zee5originals';

		      } else if (data.items[index] && data.items[index].tags && (data.items[index].tags[0] === 'Videos' || data.items[index].tags[0] === 'videos')) {
		        this.type = 'videos';
		        this.link = 'videos';

		      } else if (data.items[index]) {
		        this.type = 'home';
		        this.link = 'collections';
		      }
		      let idValueNative, adIndex, adStyle;
		      idValueNative = '';
		      if (this.nativeAdPosition && this.nativeAdPosition.length > 0) {
		        adIndex = this.nativeAdPosition.indexOf((this.count_ad + 1).toString());
		        if (adIndex >= 0 && this.nativeTag && this.nativeTag[adIndex]) {
		          idValueNative = this.nativeTag[adIndex].div_id;
            adStyle = this.commonService.getAdType(this.nativeTag[adIndex].ad_type);
		        }
		      }
		      if (data.items[index].items) {
		        this.recommended = {
		        'adNative': idValueNative,
		        'adStyle': adStyle,
		        'listType': 'default',
		        'title': data.items[index].title,
		        'original_title': data.items[index].original_title,
		        'type': this.type,
		        'link': this.link,
		        'seo_title': data.items[index].seo_title,
		        'content': this.premiumPage ? this.commonService.restrictLength(data.items[index].items) : this.commonService.restrictLength(data.items[index].items),
		        // 'content': this.premiumPage ? this.commonService.restrictLength(data.items[index].items) : this.commonService.restrictLength(this.commonService.filterListData(data.items[index].items)),
		        'id':   data.items[index].id,
		        'parentType': 'homeScreen',
		        'original_length': data.items[index].items.length
		      };
      		  this.count_ad++;
		      this.pagecollectiondata.push(this.recommended);
		      // console.log(this.pagecollectiondata,'pagecollectiondata')
		    }
		  }
		}
		// this.count_ad = this.pagecollectiondata.length + 1;
		// console.log(this.pagecollectiondata,'pagecollectiondata')
		} else {
		  if ( this.count === 1) {
		    // this.dataAvailable = false;
		    
		    this.shownodataAvailable = true;
			this.headerservicesService.breadCrump('');

		  }
		}

		  // if (this.mastDivID && this.mastTag) {
		  //   this.adCreation(this.mastTag, this.mastDivID, ['fluid'], 'masthead');
		  // }
		}

		// public googleAdCreation (slotName: any, id: any) {
		//   this.googletagAvailable = this.commonService.checkGoogleTag();
		//   if (this.googletagAvailable === 'true' && this.nativeTag && this.nativeTag[id] && this.nativeTag[id].ad_tag && this.nativeTag[id].div_id) {
		//     if (!this.touchScreen) {
		//       this.adCreation(this.nativeTag[id].ad_tag, (this.nativeTag[id].div_id),  this.nativeTag[id].ad_dimension, 'native');
		//     } else {
		//       this.adCreation(this.nativeTag[id].ad_tag, (this.nativeTag[id].div_id),  this.nativeTag[id].ad_dimension, 'native');
		//     }
		//   }
		// }

		public googleAdCreation (adType: any, id: any) {
		  if (this.nativeTag && this.nativeTag[id] && this.nativeTag[id].div_id) {
		    switch (this.nativeTag[id].ad_provider) {
		      case 'adfox':
		        let adFoxtagAvailable;
		        adFoxtagAvailable = this.commonService.checkAdFoxTag();
		        if (adFoxtagAvailable === 'true' && this.nativeTag[id].owner_id && this.nativeTag[id].params) {
		          this.adFoxCreation(this.nativeTag[id].div_id, this.nativeTag[id].owner_id, this.nativeTag[id].params , adType);
		        }
		        break;
		      default:
		        this.googletagAvailable = this.commonService.checkGoogleTag();
		        if (this.googletagAvailable === 'true' && this.nativeTag[id].ad_tag) {
		          this.adCreation(this.nativeTag[id].ad_tag, (this.nativeTag[id].div_id),  this.nativeTag[id].ad_dimension, adType);
		        }
		        break;
		    }
		  }
		}

		public adFoxCreation(id: any, owner_id: any, params: any, adType: any) {
		  let adFoxtagAvailable;
		  adFoxtagAvailable = this.commonService.checkAdFoxTag();
		  if (adFoxtagAvailable === 'true') {
		    this.timer.push(setTimeout(function() {
		      this.window.Ya.adfoxCode.create({
		        ownerId: owner_id,
		        containerId: id,
		        params: params,
		        // onLoad: function(data) { console.log(data, 'onLoad') },
		        // onRender: function(render) { console.log(render, 'onRender') },
		        onError: function(error) {
		          // console.log(error, 'onError');
		          $('#' + id).hide();
		        },
		        onStub: function(stub) {
		          // console.log(stub, 'onstub');
		          $('#' + id).hide();
		        }
		      });
		    }, 0));
		  } else {
		    $('#' + id).hide();
		  }
		}

		public adCreation(tag: any, id: any, dimension: any, adType: any) {
		  this.googletagAvailable = this.commonService.checkGoogleTag();
		  if (this.googletagAvailable === 'true') {
		  	let scope;
    		scope = this;
		    this.timer.push(setTimeout(function() {
		      if (googletag.apiReady) {
		        googletag = googletag || {};
		        googletag.cmd = googletag.cmd || [];
		        googletag.cmd.push(function() {
		          googletag.pubads().enableSingleRequest();
				  googletag.pubads().addEventListener('slotRenderEnded', function(event) {
		              if (event.slot === scope.adSlot && (!event.isEmpty)) {
		                scope.mastAd = true;
		              } else if (event.slot === scope.adSlot && (event.isEmpty)) {
		                // ad slot is not empty
		              }
		          });
	          		if (adType === 'masthead') {
			          scope.adSlot = googletag.defineSlot(tag, dimension, id).setCollapseEmptyDiv(true).addService(googletag.pubads());
			        } else if (adType === 'footer') {
		            scope.footerAdSlot = googletag.defineSlot(tag, dimension, id).setCollapseEmptyDiv(true).addService(googletag.pubads());
		          } else {
			          googletag.defineSlot(tag, dimension, id).setCollapseEmptyDiv(true).addService(googletag.pubads());
			        }
		        googletag.enableServices();
		        });
		        googletag.cmd.push(function() { googletag.display(id); });
		      }
		    }, 0));
		  }
		}
public channelSrcError (event: any) {
  if (event.srcElement) {
    event.srcElement.src =  environment.assetsBasePath + 'assets/default/epg_channel_logo.png';
  } else {
    event.currentTarget.src =  environment.assetsBasePath + 'assets/default/epg_channel_logo.png';
  }
}
	public routeChannelAll(category): void {
		if (category && category.tags && category.tags.length && category.tags.indexOf(freeChannelTag) !== -1) {
	    // this.commonService.setFreeChannels(true);
	    sessionStorage.setItem('freeChannelTitle', category.title ? category.title : category.originalTitle);
	    this.router_link.navigate(['channels'], { queryParams: { type: freeChannelTag } });
	  } else {
	    this.router_link.navigate(['channels']);
	  }
	  // this.router_link.navigate(['channels']);
	}
	public onHover(index): void {
	  this.channelHover[index] = true;

	}
	public noHover(index): void {
	  this.channelHover[index] = false;
	}
	public routeChannel(name: any, id: any, xIndex: any, yIndex: any) {
	  let addCarousel;
	  addCarousel = (this.carousel && this.carousel.length > 0) ? 1 : 0;
	  this.gtm.setContentClickDetails(xIndex, (yIndex + addCarousel), this.channelsTitleEng);
	  this.gtm.GAsubCategory = this.channelsTitleEng;
	  let show_title = name.toLowerCase().replace(/ /g, '-');
	  show_title = show_title.replace(/---/g, '-');
	  show_title = show_title.replace(/&/g, 'and');
	  this.router_link.navigate(['channels/details', show_title, id ]);
	}

	}

