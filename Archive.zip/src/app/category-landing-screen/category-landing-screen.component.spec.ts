import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CategoryLandingScreenComponent } from './category-landing-screen.component';

describe('CategoryLandingScreenComponent', () => {
  let component: CategoryLandingScreenComponent;
  let fixture: ComponentFixture<CategoryLandingScreenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CategoryLandingScreenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CategoryLandingScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
