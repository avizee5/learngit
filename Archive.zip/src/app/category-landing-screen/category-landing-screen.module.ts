import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared.module';
import { CategoryLandingScreenComponent } from './category-landing-screen.component';
import { DataUnavailableModule } from '../data-unavailable/data-unavailable.module';
import { HomeGridModule } from '../home-grid/home-grid.module';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { ScrollGridModule } from '../scroll-grid/scroll-grid.module';
import { ScrollListModule } from '../scroll-list/scroll-list.module';
import { CarouselModule } from '../carousel/carousel.module';
import { BreadCrumbModule } from '../bread-crumb/bread-crumb.module';

const routes: Routes = [
    {
        path: ':category/:categoryId',
        component: CategoryLandingScreenComponent,
    },
     {
        path: '**',
        redirectTo: '/pagenotfound',
    },
];
@NgModule({
  exports: [RouterModule],
  imports: [RouterModule.forChild(routes), CarouselModule, InfiniteScrollModule, ScrollGridModule, ScrollListModule, CommonModule, SharedModule, DataUnavailableModule, HomeGridModule, BreadCrumbModule],
  declarations: [CategoryLandingScreenComponent]
})
export class CategoryLandingScreenModule { }
