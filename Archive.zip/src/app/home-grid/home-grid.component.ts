import { Component, OnInit, OnDestroy, Input, Output, ViewChild, ElementRef, EventEmitter } from '@angular/core';
// import {Show} from '../ts/show';
import { UserProfileService } from '../services/user-profile.service';
import * as $ from 'jquery';
import {MdMenuTrigger} from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { Http} from '@angular/http';
import {MovieApi} from '../../data/gwapi_catalog/api/MovieApi';
// import {TvShowApi} from '../../data/gwapi_catalog/api/TvShowApi';
import {ChannelApi} from '../../data/catalog/api/ChannelApi';
import {SeasonApi} from '../../data/catalog/api/SeasonApi';
import {EpisodeApi} from '../../data/gwapi_catalog/api/EpisodeApi';
import { HeaderservicesService } from '../services/headerservices.service';
import { Location } from '@angular/common';
import { environment } from '../../environments/environment';
import {  NetworkService  } from '../services/network.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { SettingsService } from '../services/settings.service';
import {FavoritesApi, WatchlistApi } from '../../data/user/api/api';
import { SubscriptionService } from '../services/subscription.service';
import {EpgApi} from '../../data/catalog/api/EpgApi';
import {CommonService} from '../services/common.service';
import {VideoService} from '../services/video.service';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { EpgService } from '../services/epg.service';
import { RouteService } from '../services/route.service';
import {TranslateService} from '@ngx-translate/core';
import { UseractionapiService } from '../services/useractionapi.service';
declare const qg;
// declare let googletag;
import { Subject } from 'rxjs/Subject';
import { VideoAnalyticsService } from './../services/video-analytics.service';


@Component({
	selector: 'app-home-grid',
	templateUrl: './home-grid.component.html',
	styleUrls: ['./home-grid.component.less']
})
export class HomeGridComponent implements OnInit, OnDestroy {
	@Input() public asset_subtype: any;
	@Input() public show: any;
	@Input() public parentType: any;
	@Input() public type: any;
	@Input() public showTitle: any;
	@Input() public titleRoute: any;
	@Input() public searchQuerySpecialChar: any;
	@Input() public showCard: any;
	@Input() public seasonsPage: any;
	@Input() public noEpisodes: any = false;
  	@Input() public collectionId: any = '';
	@Input() public railsView: boolean;
	@Input() public showRailDetails: boolean;
	@Input() public gaVideoDetails: any = {};
	// @Input() public popupPosition: any = 0;
	@Input() public rightAlign: any = false;
	@Input() public modelname: any;
	@Input() public xIndex: any = 'NA';
	@Input() public yIndex: any = 'NA';
	@ViewChild('cardImage') public image_container: ElementRef;
	@ViewChild(MdMenuTrigger) public trigger: MdMenuTrigger;
	private ngUnsubscribe = new Subject<any>();
	public seasonApi: any;
	public external = false;
	// public adSlot: any;
	// public googletagAvailable: any;
	public color: string;
	public mode: string;
	public value: number;
	public bufferValue: number;
	public progress: any;
	public watched: any = false;
	public favorite: any = false;
	public reminder: any = false;
	public menuOpen: any;
	public movieFlag: any;
	public originalsFlag: any;
	public normalFlag: any;
	public title: any;
	public premium: any = false;
	public subtitle: any;
	public image_url: any;
	public image_src: any;
	// public storedData: any;
	// public storedWatchData: any;
	public storedReminderData: any;
	public showShare: boolean;
	public shareUrl: any;
	public hrefBaseUrl: any;
	public basepath: any;
	public tvShowData: any;
	public catchUpFlag: any = 'N';
	public genres: any;
	public config: any;
	public configUser: any;
	public subtitle_main: any;
	public token: any;
	public tokenValue: any;
	public addReminder: any;
	public subscription: any;
	public timestampTime: any;
	public timestampDateTime: any;
	public basepathNew: any;
	public enable: any;
	public localstorage: any;
	public window: any;
	public document: any;
	public navigator: any;
	public mobile = false;
	public serverTime: any;
	public currentTime: any;
	public elapsed: any;
	public tagList: any;
	public startTime: any;
	public bannerError: any;
	public audioLanguage: any = [];
	public assetSubtype: any;
	private assetType: any;
	public months: any = ['Jan', 'Feb', 'Mar',
	'Apr', 'May', 'Jun', 'Jul',
	'Aug', 'Sep', 'Oct',
	'Nov', 'Dec'
	];
	public shareUrlExternal: any;
	public more_menu_src = environment.assetsBasePath + 'assets/common/threedots_icon.png';
	public watch_src = environment.assetsBasePath + 'assets/common/watch_later_icon_normal.png';
	public watch_selected_src = environment.assetsBasePath + 'assets/common/watch_later_icon_selected.png';
	public favorite_selected_src = environment.assetsBasePath + 'assets/common/fav_icon_selected.png';
	public favorite_src = environment.assetsBasePath + 'assets/common/fav_icon_normal.png';
	public share_src = environment.assetsBasePath + 'assets/common/share_icon.png';
	public dismiss_src = environment.assetsBasePath + 'assets/common/remove.png';
	public reminder_selected_src = environment.assetsBasePath + 'assets/common/reminder_icon_selected.png';
	public reminder_src = environment.assetsBasePath + 'assets/common/reminder_icon.png';
	public dot_image = environment.assetsBasePath + 'assets/common/seperator_round.png';
	public url1: any;
	public url2: any;
	public url3: any;
	public url4: any;
	public popular: any = false;
	public totalTime: any;
	public countryCode: any;
	public touchScreen: any = false;
	public currentCountry: any;
	public showPremium: any = true;
	public plans: any;
	public imgWidth: any = 270;
	public clientID: any;
	public marketingValue: any;
	private configValue: any;
	private language: any;
	public recommendedValue: any;
	public temp: any;
	public isNewsPage: any;
	public isTvcategory = false;

	// for popup
	public cardDetails = false;
	public age_rating: any;
	public card_title: any;
	public card_type: any;
	public card_season: any;
	public card_genre: any;
	public card_audio: any;
	public card_subtitle: any;
	public imagesrc: any;
	public topValue: any;
	public leftValue: any;
	public right_arrow = false;
	public left_arrow = false;
	public outerContainerImg: any;
	public leftValueImg: any;
	public isMoviePage = false;
	public isNewsPageCheck: any;
	public seasonNumberStr: any;
	public episodeNumberStr: any;
	public videoViewEvents: any;
    public notAvailable: any = 'NA';
    public audioLangsString: any = '';
    public gaFirstAPIAudioLang: any;
    public GAsubCategory: any;
	public loginToken: any;
	public showRating: any;
	public agetake = false;
	public valid_string: any;
	private displaylanguage: any;

	@Output() public onChange = new EventEmitter<any>();

	constructor(private useractionapi: UseractionapiService, private videoService: VideoService, private routeservice: RouteService, private epgService: EpgService , @Inject(PLATFORM_ID) private platformId: Object, private commonService: CommonService, private settingsService: SettingsService, private subscriptionService: SubscriptionService,
		private gtm: GoogleAnalyticsService, private networkService: NetworkService, private location: Location, private headerservicesService: HeaderservicesService, private userProfileService: UserProfileService, private route: ActivatedRoute ,  private router_link: Router, private http: Http, private translate: TranslateService, private videoAnalyticsService: VideoAnalyticsService) {
		this.commonService.serverTime.takeUntil(this.ngUnsubscribe).subscribe(value => {
			this.updateProgress(value);
		});
			this.configLanguage();
	}
	private configLanguage() {
    // let configValue;
    // configValue = this.settingsService.getCompleteConfig();
    // this.language = configValue.languages_labels;
    // this.language = [];
    // let self;
    // self = this;
    // configValue.languages.forEach(function(obj) {
    //   let temp;
    //   temp = {
    //     'name': obj.name,
    //     'native': obj.native,
    //   };
    //   self.language[obj.id] = temp;
    // });
  }
	public ngOnInit () {
		this.loginToken = localStorage.getItem ( 'token' );  
		if (this.loginToken) {
        	this.displaylanguage = localStorage.getItem('UserDisplayLanguage');
        } else {
        	this.displaylanguage = localStorage.getItem('display_language');
        }
		if (this.show.asset_type === 101) {
			if (this.show.genres[0].value !== 'internal_link') {
				this.external = true;
			} else {
				this.external = false;
			}
		}
		if (this.show) {
			if ( this.show.season_details && this.show.season_details.orderid ) {
			  	let  season_details;
			  	season_details = this.show.season_details.orderid;
	  			if (/^\d$/.test(season_details))  {
			  		this.seasonNumberStr = 'S 0';
	  			} else {
	  				this.seasonNumberStr = 'S ';
	  			}
			} else {
		  		$('.seasonNumberStr').css('display' , 'none');
			}
			if (this.show.episode_number) {
			  	let episode_number;
			  	episode_number = this.show.episode_number;
			  	if (/^\d$/.test(episode_number))  {
			  		this.episodeNumberStr = 'Ep 0';
	  			} else {
	  				this.episodeNumberStr = 'Ep ';
	  			}
			} else {
		  		$('.episodeNumberStr').css('display' , 'none');
			}
			if (this.show.season_details && this.show.season_details.orderid && this.show.episode_number) {
	  				this.episodeNumberStr = ' - ' + this.episodeNumberStr;
	  		}
		} else {
		  	$('.showDetails').css('display' , 'none');
		}
		this.gtm.storeWindowError();
		this.countryCode = this.settingsService.getCountry();
		if (isPlatformBrowser(this.platformId)) {
			this.localstorage = localStorage;
			this.window = window;
			this.document = document;
			this.navigator = navigator;
		}
		this.imagesrc = environment.assetsBasePath + 'assets/common/PlayIconPink.png';
		this.currentCountry = this.settingsService.getCountryValueNew();
		if (this.currentCountry && this.currentCountry[0] && this.currentCountry[0].menu_options.premium_tag === 'no') {
			this.plans = this.subscriptionService.checkPlanApiSuccess(false);
			if (this.plans.indexOf('9') >= 0) {
				this.plans.push('10');
			}
			if (this.plans.indexOf('6') >= 0) {
				this.plans.push('1');
			}
			if (this.plans && this.plans.length > 0 && this.plans.indexOf(this.show.asset_type.toString()) >= 0) {
				this.showPremium = false;
			}
		}
		if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
			this.touchScreen = true;
		}
		// if (this.show.type === 'advertisement') {
		// 	this.renderAd();
		// }
		if ( this.window.innerWidth <= 480) {
			this.mobile = true;
			this.imgWidth = 270;
			// this.imgWidth = 220;
		}
		if (this.type === 'popular_banner') {
			this.popular = true;
		}

		    this.configValue = this.settingsService.getCompleteConfig();
    // this.language = [];
    this.language = this.configValue.languages_labels;

    this.recommendedValue = this.configValue.recommended;

  //   let self;
  //   self = this;
  //   this.configValue.languages.forEach(function(obj) {
  //     self.temp = {
  //       'name': obj.name,
  //       'native': obj.native,
  //     };
  //     self.language[obj.id] = self.temp;
  //      // this.audioLanguage.push(self.temp.name);

  //   });
		this.tokenValue = this.gtm.fetchToken();
		this.token = this.localstorage.getItem('token');
		let params1;
		params1 = 'bearer ' + this.token;
		if (this.token) {
			this.configUser = {
				apiKey: params1,
				username: ' ',
				password: ' ',
				accessToken: ' ',
				withCredentials: false
			};
		}

	   this.assetType = {
           0: (this.show.asset_subtype === 'video' ? 'MENU.VIDEOS' : 'MENU.MOVIES' ),
           1: 'DETAILS.EPISODE',
           6: 'MENU.TVSHOWS',
           9: 'Channel'
         };
		if (this.type === 'movies' || this.type === 'movie' || this.type === 'movies_details' || this.type === 'categorymovies'  ) {
			this.image_url = environment.assetsBasePath + 'assets/default/movies.png';
			this.url1 = environment.assetsBasePath + 'assets/default/movies.png';
			this.isMoviePage = true;
		} else if (this.type === 'eventbanner') {
			this.image_url =  environment.assetsBasePath + 'assets/default/eventbanner.jpg';
			this.url4 = environment.assetsBasePath + 'assets/default/eventbanner.jpg';
		} else if (this.type === 'zeeOriginals' || this.type === 'categoryzeeOriginals') {
			this.image_url = environment.assetsBasePath + 'assets/default/tvshow.png';
			this.url2 = environment.assetsBasePath + 'assets/default/tvshow.png';
		} else if (this.popular) {
			this.image_url =  environment.assetsBasePath + 'assets/default/popular.png';
		} else {
			this.image_url = environment.assetsBasePath + 'assets/default/tvshow.png';
			this.url3 = environment.assetsBasePath + 'assets/default/tvshow.png';
		}
		if (this.type === 'catchUp') {
			this.catchUpFlag = 'Y';
			if (!this.show.business_type) {
				this.show.business_type = this.showTitle.business_type || this.show.business_type;
			}
			let tempTitle;
			if (this.show && this.show.extended && this.show.extended.seo_title) {
            		tempTitle = (this.show.extended.seo_title !== null || this.show.extended.seo_title !== undefined || this.show.extended.seo_title !== '') ? this.show.extended.seo_title : this.show.original_title;
          		} else {
            		tempTitle = (this.show.seo_title && (this.show.seo_title !== null || this.show.seo_title !== undefined || this.show.seo_title !== '')) ? this.show.seo_title : this.show.original_title;
          		}
			this.show.showTitle = tempTitle;
			if (this.show.asset_subtype === 'trailer') {
				this.premium = false;
			}
		}
		this.show.showTitle = this.show.tvshow ? this.show.tvshow.original_title : this.show.original_title;

		this.basepath = this.settingsService.getbasePath();
		this.basepathNew = this.settingsService.getbasePathNew();
		this.config = {
			apiKey: ' ',
			username: ' ',
			password: ' ',
			accessToken: ' ',
			withCredentials: false
		};
		if (this.show.asset_type === 9) {
			this.fetchEpgData();

			// let url
			// url = environment.serverTimeUrl
			// this.epgService.getcurrentTime(url).subscribe( value => {
			// 	this.serverTime = new Date(value.serverdate);
			// 	this.currentTime = this.serverTime.getTime();
			// 	this.fetchEpgData()
			// },
			// err => {
			// 	this.serverTime = new Date();
			// 	this.currentTime = this.serverTime.getTime();
			// 	this.fetchEpgData()

			// });
		}
		if (this.parentType === 'conviva') {
			this.show.tvshow = this.show.tvshow_details ? this.show.tvshow_details[0] : {};
			this.image_url = this.show.image_url;
		}
		if (this.parentType === 'search' && this.show.asset_type === 1) {
			this.show.tvshow = this.show.tvshow_details ? this.show.tvshow_details : {};
		}
			if (this.type === 'continue') {
				if (Math.floor((this.show.played_duration / this.show.duration) * 100) <= 100) {
					this.progress = Math.floor((this.show.played_duration / this.show.duration) * 100);
				} else {
					this.progress = 100;
				}
			}
			// if (this.type === 'continue' || this.type === 'watchList' || this.type === 'favorites' || (this.show.asset_type === 1 && this.parentType !== 'conviva' && this.type !== 'catchUp')) {
			// if (this.type === 'continue' || this.type === 'watchList' || this.type === 'favorites' ) {
			if (this.type === 'watchList' || this.type === 'favorites' ) {
			if (this.show.asset_type === 0 ) {
				let x, userType;
				x = new MovieApi(this.http, null, this.config);
				userType = this.commonService.getUserType();
				x.v1MovieByIdGet(this.show.id, undefined, this.countryCode, null, null, null, userType).subscribe(value => {
					this.show.release_date = value.release_date;
					this.genres = [];
					if (value.genres) {
					for (let index = 0; index < value.genres.length; index++) {
						this.genres.push(value.genres[index].id);
					}
					}
					this.show.genres = value.genres;
					this.show.tags = value.tags;
					this.show.content_owner = value.content_owner;
					this.show.video = value.video_details;
					this.show.title = value.title;
					this.show.original_title = value.original_title;
					this.show.list_image = value.list_image;
					this.show.totalDuration = value.duration;
					this.show.asset_subtype = value.asset_subtype;
					this.show.rating = value.rating;
					this.show.business_type = value.business_type;
					this.show.description = value.description;
					if (this.type !== 'continue') {
						this.show.duration = value.duration;
					}
					if (value.list_image) {
						this.image_url = this.basepathNew + this.show.id + '/list/' + '270x152/' + value.list_image  + '?imwidth=270&impolicy=akamai_vidz1_zee5_com-IPM';
					}
					if (Math.floor((this.show.duration / value.duration) * 100) <= 100) {
						this.progress = Math.floor((this.show.duration / value.duration) * 100);
					} else {
						this.progress = 100;
					}

					if (this.show.business_type === 'premium' || this.show.business_type === 'premium_downloadable') {
							this.premium = true;
						}
						this.hrefUrl();
						this.subtitleConstruct();
					},
					err => {
						this.gtm.sendErrorEvent('api', err);
						if (this.type === 'watchList' || this.type === 'favorites') {
						// if (this.type === 'continue' || this.type === 'watchList' || this.type === 'favorites') {
							this.show.type = 'missing';
							this.dismiss();
						}
					}
					);
				}  else if (this.show.asset_type === 1 ) {
					let x, userType;
					x = new EpisodeApi(this.http, null, this.config);
					userType = this.commonService.getUserType();
					x.v1EpisodeByIdGet(this.show.id, this.show.id, undefined, this.countryCode, null, null, null, userType).subscribe(value => {
						this.genres = [];
						if (value.genres) {
						for (let index = 0; index < value.genres.length; index++) {
							this.genres.push(value.genres[index].id);
						}
						}
						this.show.genres = value.genres;
						this.show.tags = value.tags;
						this.show.content_owner = value.content_owner;
						this.show.title = value.title;
						this.show.video = value.video_details;
						this.show.original_title = value.original_title;
						this.show.asset_subtype = value.asset_subtype;
						this.show.tvshow = value.tvshow;
						this.show.totalDuration = value.duration;
						this.show.list_image = value.list_image;
						this.show.release_date = value.release_date;
						this.show.description = value.description;
						this.show.index = value.index;
						this.show.rating = value.rating;
						this.show.season_id = value.season ? value.season.id : '';
						this.show.business_type = value.business_type ? value.business_type : 'free';
						if (this.type !== 'continue') {
							this.show.duration = value.duration;
						}
						if (Math.floor((this.show.duration / value.duration) * 100) <= 100) {
							this.progress = Math.floor((this.show.duration / value.duration) * 100);
						} else {
							this.progress = 100;
						}
						if (value.list_image) {
							this.image_url = this.basepath + this.show.id + '/list/' + (this.popular ? '1170x658/' :  (this.type === 'movies' ? '270x405/' : '270x152/') ) + this.show.list_image;
						}
						if (this.show.business_type && (this.show.business_type === 'premium' || this.show.business_type === 'premium_downloadable')) {
							this.premium = true;
						}
						this.hrefUrl();
						this.subtitleConstruct();
					},
					err => {this.gtm.sendErrorEvent('api', err);
					if (this.type === 'watchList' || this.type === 'favorites') {
					// if (this.type === 'continue' || this.type === 'watchList' || this.type === 'favorites') {
						this.show.type = 'missing';
						this.dismiss();
					}
				}
				);

			}
		}
		else if (this.parentType === 'search' && this.show.asset_type === 10 && this.show.channel_name) {
			this.currentTime = this.commonService.getServertime() ? this.commonService.getServertime() : Date.parse(new Date().toISOString());
			this.startTime = Date.parse(this.show.start_time);
			this.elapsed = (this.currentTime - this.startTime);
			this.show.elapsed = this.elapsed;
			let elapsedTime;
			elapsedTime = (this.elapsed / 1000);
			if (Math.floor((elapsedTime / (this.show.duration)) * 100) <= 100) {
				this.progress = Math.floor((elapsedTime / this.show.duration) * 100);
				this.progress ? this.show.progress = this.progress : this.show.progress = 0;
				this.progress ? this.show.un_progress = (100 - this.progress) : this.show.un_progress = 0;
			}
			this.show.channel_id = this.show.channel_name.id;
			this.show.channel_original_title = this.show.channel_name.original_title;
		}
		else {
			if (!this.show.genres) {
				this.show.genres = this.show.genre ? this.show.genre : [];
			}
			this.hrefUrl();
			this.subtitleConstruct();
		}
		if (this.type === 'livetv') {
			this.progress = this.show.progress;
		}
		if (!this.show.genres) {
			this.show.genres = this.show.genre ? this.show.genre : [];
		}
		if (this.show.asset_subtype === 'video' && this.show.genres.findIndex(i => i.id === 'News') !== -1) {
			if (!this.router_link.url.match(/search/g) && !this.router_link.url.match(/(videos\/all)/g) && !this.router_link.url.match(/myprofile/g)) {
				this.isNewsPage = true;
			}
		}
		if (this.show.asset_subtype === 'video' && this.show.genres.findIndex(i => i.id === 'News') !== -1) {
			this.isNewsPageCheck = true;
		}
		if (this.type === 'categorytvshows' || this.type === 'zeeOriginals' ||  this.type === 'zee5Originals' ||  this.type === 'categoryzeeOriginals' || this.type === 'watchList' ||  this.type === 'favorites' ||  this.type === 'categoryvideos') {
			if (!this.router_link.url.match(/search/g) && !this.router_link.url.match(/videos\/all/g) && !this.router_link.url.match(/myprofile/g)) {
				this.isTvcategory = true;
			}
		}
		let scope;
		scope = this;
		let img1;
		  if ( this.type === 'eventbanner') {
        		this.url4 = this.basepathNew + this.show.id + '/list/' + '1920x522/' + this.show.list_image  + '?imwidth=' + 400 + '&impolicy=akamai_vidz1_zee5_com-IPM';
				img1 = new Image();
				img1.src = this.url4;
				scope = this;
				img1.onload = function() {
					scope.image_url = scope.url4;
				// delete img1
				img1 = null;
        	 	// $('.emptyDiv').removeClass('border')
        	 };
        	} else if (this.show.asset_type === 101) {
		 	// this.external = true;
			this.shareUrl = this.show.slug;
			if (this.show.genres[0].id === 'webview_sdkuserinfo') {
				let separator, first, last, user_token, user_type, complete_share_url;
				separator = this.show.slug.indexOf('?') ? true : false;
				first =  this.show.slug.split('?')[0];
				last = separator ? '&' + this.show.slug.split('?')[1] : '';
				user_token = this.localstorage.getItem('token') ? this.localstorage.getItem('hextoken_game') : this.localstorage.getItem('guestToken');
				user_type = this.commonService.getUserType();
				complete_share_url = first + '?token=' + user_token + '&user_type=' + user_type + last;
				this.shareUrl = complete_share_url;
		     }
			this.url3 = this.notAvailable;
			// if (this.show.episodes && this.show.episodes[0] && this.show.episodes[0].list_image) {
				this.url3 = this.basepath + this.show.id + '/list/' + '270x152/' + this.show.list_image;
        		img1 = new Image();
        		img1.src = this.url3;
        		scope = this;
        		img1.onload = function() {
        			scope.image_url  = scope.url3;
        			// delete img1
        			img1 = null;
        	 	// $('.emptyDiv').removeClass('border')
        	 	};
			// }
		} else {

		if (this.show.asset_type === 2) {
			if (this.show.episodes && this.show.episodes[0] && this.show.episodes[0].list_image) {
				this.url3 = this.basepath + this.show.episodes[0].id + '/list/' + '270x152/' + this.show.episodes[0].list_image;
        		img1 = new Image();
        		img1.src = this.url3;
        		scope = this;
        		img1.onload = function() {
        			scope.image_url  = scope.url3;
        			// delete img1
        			img1 = null;
        	 	// $('.emptyDiv').removeClass('border')
        	 	};
			}
		} else if ((this.type === 'movies' || this.type === 'movie' || this.type === 'movies_details' || this.type === 'categorymovies') && this.show.cover_image ) {
			// $('.emptyDiv').addClass('border');
			this.url1 = this.basepathNew + this.show.id + '/cover/' + '270x405/' + this.show.cover_image  + '?imwidth=' + this.imgWidth + '&impolicy=akamai_vidz1_zee5_com-IPM';
			img1 = new Image();
			img1.src = this.url1;
			scope = this;
			img1.onload = function() {
				scope.image_url = scope.url1;
				// delete img1
				img1 = null;
        	 	// $('.emptyDiv').removeClass('border')
        	 };
        	} else if ((this.type === 'zeeOriginals' || this.type === 'categoryzeeOriginals') && this.show.list_image) {
			// $('.emptyDiv').addClass('border');
			this.url2 = this.basepathNew + this.show.id + '/list/' + '270x152/' + this.show.list_image  + '?imwidth=' + this.imgWidth + '&impolicy=akamai_vidz1_zee5_com-IPM';
			img1 = new Image();
			img1.src = this.url2;
			scope = this;
			img1.onload = function() {
				scope.image_url = scope.url2;
				// delete img1
				img1 = null;
        	 	// $('.emptyDiv').removeClass('border')
        	 };
        } else if (this.type === 'continue' && this.show.list_image && this.show.asset_type === 0) {
			this.image_url = this.basepathNew + this.show.id + '/list/' + '270x152/' + this.show.list_image  + '?imwidth=270&impolicy=akamai_vidz1_zee5_com-IPM';
        } else if ((this.type === 'livetv' || this.type === 'live' || this.type === 'search_live' || this.show.asset_type === 10) && this.show.list_image ) {
			// $('#emptyDiv').addClass('border');
			this.url3 = this.basepath + this.show.id + '/list/' + '270x152/' + this.show.list_image;
			img1 = new Image();
			img1.src = this.url3;
			scope = this;
			img1.onload = function() {
				scope.image_url  = scope.url3;
				// delete img1
				img1 = null;
        	 	// $('.emptyDiv').removeClass('border')
        	 };
        	} else if (this.type === 'catchUp' && this.show.list_image ) {
			// $('#emptyDiv').addClass('border');
			this.url3 = this.getEpisodeUrl(this.show.release_date, this.showTitle.original_title);
			img1 = new Image();
			img1.src = this.url3;
			scope = this;
			img1.onload = function() {
				scope.image_url  = scope.url3;
				// delete img1
				img1 = null;
        	 	// $('.emptyDiv').removeClass('border')
        	 };
        	} else if (this.parentType === 'conviva' || (( this.show.asset_type === 9 ) && this.show.list_image) ) {
        		// this.parentType === 'conviva' || (( this.show.asset_type === 9 ) && this.show.list_image
        	} else if (!(this.type === 'watchList' || this.type === 'favorites' ) && this.show.asset_type === 1 ) {
        	// } else if (!(this.type === 'continue' || this.type === 'watchList' || this.type === 'favorites' ) && this.show.asset_type === 1 ) {
        		this.url3 = this.basepath + this.show.id + '/list/' + (this.popular ? '1170x658/' :  (this.type === 'movies' ? '270x405/' : '270x152/') ) + this.show.list_image;
        		img1 = new Image();
        		img1.src = this.url3;
        		scope = this;
        		img1.onload = function() {
        			scope.image_url  = scope.url3;
        			// delete img1
        			img1 = null;
        	 	// $('.emptyDiv').removeClass('border')
        	 };
        		// this.image_url = this.basepath + this.show.id + '/list/' + (this.popular ? '1170x658/' :  (this.type === 'movies' ? '270x405/' : '270x152/') ) + this.show.list_image
        	}  	else if (this.popular) {
        		if ( this.show.asset_type === 8 && this.show.list_image) {
        			this.image_url = this.basepath + this.show.id + '/list/' + '1170x658/' + this.show.list_image;
        		} else if (this.show.asset_type !== 8 && this.show.list_image) {
        			this.url2 = this.basepathNew + this.show.id + '/list/' + '1170x658/' + this.show.list_image + '?imwidth=1170&impolicy=akamai_vidz1_zee5_com-IPM';
        			// let img1;
        			img1 = new Image();
        			img1.src = this.url2;
        			img1.onload = function() {
        				scope.image_url = scope.url2;
        				// delete img1
        				img1 = null;
        	 			// $('.emptyDiv').removeClass('border')
        	 		};
        	 	}
        	 } else if (this.show.asset_type === 8 && this.show.list_image) {
        	 	this.url3 = this.basepath + this.show.id + '/list/' + '270x152/' + this.show.list_image;
        	 	img1 = new Image();
        	 	img1.src = this.url3;
        	 	scope = this;
        	 	img1.onload = function() {
        	 		scope.image_url  = scope.url3;
        	 		// delete img1
        	 		img1 = null;
        	 	// $('.emptyDiv').removeClass('border')
        	 };

        	} else {
        		if (this.show.list_image) {
				// $('.emptyDiv').addClass('border');
				this.url3 = this.basepathNew + this.show.id + '/list/' + '270x152/' + this.show.list_image + '?imwidth=' + this.imgWidth + '&impolicy=akamai_vidz1_zee5_com-IPM';
				img1 = new Image();
				img1.src = this.url3;
				scope = this;
				img1.onload = function() {
					scope.image_url  = scope.url3;
					// delete img1
					img1 = null;
		        	 	// $('.emptyDiv').removeClass('border')
		        	 };
		        	}
		        }


		    }

		        if ((this.show.business_type === 'premium' || this.show.business_type === 'premium_downloadable') && !(this.showTitle && (this.showTitle.assetSubType === 'original' || this.showTitle.assetSubType === 'tvshow') && this.show.asset_subtype === 'sample_premium')) {
		        	this.premium = ((this.type === 'catchUp') && (this.show.asset_subtype === 'trailer')) ? false : true ;
		        }
		        this.menuOpen = false;
		        if (this.type === 'favorites') {
		        	this.title = 'My Favorites';
		        } else if (this.type === 'watchList') {
		        	this.title = 'Watchlist';
		        } else if (this.type === 'continue') {
		        	this.title = 'Continue Watching';
		        }
		        // let scope;
		        // scope = this;

		        $( this.window ).on( 'orientationchange', function( event ) {
		        	if (scope.menuOpen === true && (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i) || this.window.innerWidth < 769)) {
		        		scope.trigger.closeMenu();
		        		scope.menuOpen = false;
		        	}
		        });
		        $(this.window).scroll(function() {
		        	if (scope.menuOpen === true && (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|firefox|fxios|IEMobile/i) || this.window.innerWidth < 769)) {

		        		scope.trigger.closeMenu();
		        		scope.menuOpen = false;

		        	}
		        });

		              let string1;
		this.route.queryParams.subscribe(params => {
			string1 = params.q;
		});
            this.audioLanguage = [];
      		if (this.show.languages) {
        	  let suggestions;
        	  suggestions = this.show.languages;
        	  if (suggestions !== null) {

        	  let audio, audioSplit;
	          audioSplit = [];
	          audio = suggestions;
	          if (audio && audio.length > 0 && this.language[this.displaylanguage] && this.language[this.displaylanguage][audio[0]]) {
	            audioSplit.push(this.language[this.displaylanguage][audio[0]]);
	          } else {
	            audioSplit.push([]);
	          }
	          this.audioLanguage = audioSplit.join(',');
      	     }
              } else {
      	      this.audioLanguage = null;
            }
// to get asset_subtype
            this.card_type = this.commonService.getDefaultSub(this.show.asset_type, this.show.asset_subtype);
	   if (this.show.asset_subtype === 'video' && this.show.genres.findIndex(i => i.id === 'News') !== -1) {
		this.commonService.getSubcategory(this.show.tags, this.show.asset_type, this.show.asset_subtype, this.show.genres, this.show.content_owner);
	   }

	   this.setGAsubCatecory();
		    }

		    private setGAsubCatecory(): any {
    			if (this.show.asset_type === 0 ) {
    				this.GAsubCategory = (this.type === 'continue' || this.type === 'watchList' || this.type === 'favorites') ? this.title : (this.showTitle && this.showTitle.category) ? this.showTitle.category : ((this.showTitle && this.showTitle.original_title) ? this.showTitle.original_title : '');
    			} else if (this.show.asset_type === 2 ) {
    				this.GAsubCategory = '';
    			} else if (this.show.asset_type === 6 ) {
    				this.GAsubCategory = (this.showTitle && this.showTitle.category) ? this.showTitle.category : ((this.showTitle && this.showTitle.original_title) ? this.showTitle.original_title : '');
    			} else if (this.show.asset_type === 8) {
                	this.GAsubCategory = (this.showTitle && this.showTitle.category) ? this.showTitle.category : ((this.showTitle && this.showTitle.original_title) ? this.showTitle.original_title : '');
    			} else if (this.show.asset_type === 9) {
    				this.GAsubCategory = (this.showTitle && this.showTitle.original_title) ? this.showTitle.original_title : '';
    			} else if (this.show.asset_type === 10) {
    				this.GAsubCategory = this.type !== 'live' ? ((this.showTitle && this.showTitle.original_title) ? this.showTitle.original_title : '') : '';
    	 		} else if (this.show.asset_type === 1 && (this.type === 'catchUp')) {
					this.GAsubCategory = this.showTitle && this.showTitle.category ? this.showTitle.category : '';
    			} else if (this.show.asset_type === 1) {
    				this.GAsubCategory = (this.type === 'continue' || this.type === 'watchList' || this.type === 'favorites') ? this.title : (this.showTitle && this.showTitle.original_title) ? this.showTitle.original_title : '';
				} else {
	                this.GAsubCategory = (this.showTitle && this.showTitle.category) ? this.showTitle.category : ((this.showTitle && this.showTitle.original_title) ? this.showTitle.original_title : '');
				}
		    }
		    public subtitleConstruct() {
		    	// Subcategory Construction
		    	let genre_sub;
		    	genre_sub = this.show.genre ? this.show.genre : this.show.genres;
		    	this.tagList = this.commonService.getSubcategory(this.show.tags, this.show.asset_type, this.show.asset_subtype, genre_sub, this.show.content_owner);
		    	if (this.tagList.length <= 1) {
		    		this.subtitle_main = this.tagList.join(', ');
		    	} else {
		    		this.subtitle_main = this.tagList.join(', ');
		    		this.subtitle_main = this.transformTag(this.subtitle_main);
		    	}
		    }
		    public transformTag(value: any): any {
		    	let limit;
		    	if (this.window.innerWidth > 1200) {
		    		limit = 15;
		    	} else if (this.window.innerWidth < 1200 && this.window.innerWidth >= 768) {
		    		limit = 8;
		    	} else if (this.window.innerWidth < 768 && this.window.innerWidth > 480) {
		    		limit = 14;
		    	} else if (this.window.innerWidth <= 480 && this.window.innerWidth > 300) {
		    		limit = 16;
		    	} else {
		    		limit = 15;
		    	}
		    	if (!this.show.duration) {
		    		limit = 20;
		    	}
		    	let new_string;
		    	if (value) {
		    		if (value.length > limit) {
		    			new_string = value.slice(0, limit) + '..';
		    		} else {
		    			new_string = value;
		    		}
		    	} else {
		    		new_string = '';
		    	}
		    	return new_string;
		    }
		    public updateProgress(time: any) {
		    	if (this.show.asset_type === 9 && time) {
		    		this.currentTime = time;
		    		this.elapsed = (this.currentTime - this.startTime);
		    		this.show.elapsed = this.elapsed;
		    		let elapsedTime;
		    		elapsedTime = (this.elapsed / 1000);

		    		if ( Math.floor((elapsedTime / (this.totalTime)) * 100) <= 100) {
		    			this.progress = Math.floor((elapsedTime / this.totalTime) * 100);
		    		}
		    	}
		    }
		    public fetchEpgData() {
		    	let x, tempTitle;
		    	x = new EpgApi(this.http, null, null);
		    	x.v1EpgNowGet(this.show.id).subscribe( value1 => {
		    		this.show.channel_id = this.show.id;
		    		this.show.channel = this.show.title;
		    		// if (this.show && this.show.extended && this.show.extended.seo_title) {
        //     		tempTitle = (this.show.extended.seo_title !== null || this.show.extended.seo_title !== undefined || this.show.extended.seo_title !== '') ? this.show.extended.seo_title : this.show.original_title;
        //   		} else {
        //     		tempTitle = (this.show.seo_title && (this.show.seo_title !== null || this.show.seo_title !== undefined || this.show.seo_title !== '')) ? this.show.seo_title : this.show.original_title;
        //   		}
		    		// this.show.channel_original_title = tempTitle;
		    		this.show.channel_original_title = this.show.original_title;
		    		if (value1.items[0].items[0]) {
		    			this.show.title = value1.items[0].items[0].title;
		    			this.image_url = this.basepath + value1.items[0].items[0].id + '/list/' +  (this.popular ? '1170x658/' : '270x152/')  + value1.items[0].items[0].list_image;
		    			this.startTime = Date.parse(value1.items[0].items[0].start_time);
		    			this.elapsed = (this.currentTime - this.startTime);
		    			this.totalTime = value1.items[0].items[0].duration;
		    			this.show.elapsed = this.elapsed;
		    			let elapsedTime;
		    			elapsedTime = (this.elapsed / 1000);
		    			if ( Math.floor((elapsedTime / (this.totalTime)) * 100) <= 100) {
		    				this.progress = Math.floor((elapsedTime / value1.items[0].items[0].duration) * 100);
		    			}
		    		}
		    	},
		    	err => {
		    		this.gtm.sendErrorEvent('api', err);
		    	});
		    }
		    public getEpisodeUrl(date: any, tvshow_title: any) {
		    	if (date && tvshow_title  && (this.type === 'continue' || this.type === 'watchList' || this.type === 'favorites' )) {
		    		tvshow_title = tvshow_title.replace(/ /g, '_');
		    		let new_date, date_formatted, day, hrs, dayUpdate, month;
		    		new_date = new Date(date);
		    		day = new_date.getDate();
		    		hrs = new_date.getMonth() + 1;
		    		dayUpdate = day ? ((day < 10 ? '0' + day : day)) : '';
		    		month = hrs ? ((hrs < 10 ? '0' + hrs : hrs)) : '';
		    		date_formatted = dayUpdate.toString() + month.toString() + new_date.getFullYear().toString();
		    		let a, b, inRange;
		    		a = new Date(2015, 0, 15);
		    		b = new Date(2017, 9, 15);
		    		inRange = new_date >= a && new_date <= b;
		    		if (inRange) {
		    			this.image_url =  'https://akamaividz1.zee5.com/resources/episode-images/' + tvshow_title + '_Episode_' + date_formatted + '_574x358.jpg' +  '?imwidth=' + this.imgWidth + '&impolicy=akamai_vidz1_zee5_com-IPM';
		    		} else {
		    			this.image_url = this.basepath + this.show.id + '/list/' + (this.type === 'movies' ? '270x405/' : '270x152/') + this.show.list_image;

		    		}
		    	} else {
		    		this.image_url = this.basepath + this.show.id + '/list/' + (this.popular ? '1170x658/' :  (this.type === 'movies' ? '270x405/' : '270x152/') ) + this.show.list_image;
		    	}
		    	return this.image_url;
		    }
		    public closeShare(eve: any): any {
		    	this.showShare = false;
		    }
		    public loadMoreMenu() {
		    	// this.storedData = this.userProfileService.getFavoriteData();
		    	// this.storedWatchData = this.userProfileService.getWatchData();
		    	this.storedReminderData = this.userProfileService.getReminderData();
		    	// if (this.storedData) {
		    	// 	for (let index = 0; index < this.storedData.length; index++) {
		    	// 		if (this.storedData[index].id === this.show.id) {
		    	// 			this.favorite = true;
		    	// 			break;
		    	// 		} else {
		    	// 			this.favorite = false;
		    	// 		}
		    	// 	}
		    	// }
		    	// if (this.storedWatchData) {
		    	// 	for (let index1 = 0; index1 < this.storedWatchData.length; index1++) {
		    	// 		if (this.storedWatchData[index1].id === this.show.id) {
		    	// 			this.watched = true;
		    	// 			break;
		    	// 		} else {
		    	// 			this.watched = false;
		    	// 		}
		    	// 	}
		    	// }
	    		this.favorite = this.userProfileService.inList('favorite', this.show.id);
	    		this.watched = this.userProfileService.inList('watchList', this.show.id);
		    	if (this.storedReminderData) {
		    		for (let index2 = 0; index2 < this.storedReminderData.length; index2++) {
		    			if (this.storedReminderData[index2].id === this.show.id) {
		    				this.reminder = true;
		    			}
		    		}
		    	}
		    }
		    // public routeFunction() {
		    // 	if (this.show.asset_type === 101) {
		    // 		this.routeservice.assetCheck(this.show,this.router_link,this.url3,'videoNameClick',this.gtm);
		    // 	} else {
			   //  	this.startVideo(null, null);
		    // 	}
		    // }
		    public routeFunction() {
		    	if (this.parentType === 'search') {
				this.commonService.sendSearchClickEvent(this.image_url);
			}
			let data;
                 this.videoViewClickEvents();
                 data = this.videoViewEvents;
		         this.callTalamoosClick();
          		this.videoService.autoPlayed('');
          		this.commonService.updateCollectionId(this.collectionId);
		    	let tempTitle ;
		    	// if (this.show && this.show.extended && this.show.extended.seo_title) {
       //      		tempTitle = (this.show.extended.seo_title !== null || this.show.extended.seo_title !== undefined || this.show.extended.seo_title !== '') ? this.show.extended.seo_title : this.show.original_title;
       //    		} else {
       //      		tempTitle = (this.show.seo_title && (this.show.seo_title !== null || this.show.seo_title !== undefined || this.show.seo_title !== '')) ? this.show.seo_title : this.show.original_title;
       //    		}
    			tempTitle = this.show.original_title;
          		this.commonService.setTalamoosData(this.modelname, this.show.clickID, this.show.origin);
                this.gtm.GAsubCategory = (this.showTitle && this.showTitle.category) ? this.showTitle.category : ((this.showTitle && this.showTitle.original_title) ? this.showTitle.original_title : '');
               this.gtm.setContentClickDetails(this.xIndex, this.yIndex, this.gtm.GAsubCategory);
          		if (this.show.asset_type === 101) {		    	
		      	this.commonService.assetCheck(this.show, this.router_link, this.url3, 'videoNameClick', data);
		        } else if (this.mobile) {
			// call videoNameClick
		        	this.commonService.assetCheck(this.show, this.router_link, this.url3, 'videoNameClick', data);
		    		this.startVideo(false, '');
		    	} else {
			// call videoNameClick
		      	    this.commonService.assetCheck(this.show, this.router_link, this.url3, 'videoNameClick', data);		    		
		    		if (this.networkService.getPopupStatus()) {
	    				if (this.railsView) {
	        				this.sendGAevent();
	        			}
		    			if (this.show.asset_type === 0 ) {
		    				this.gtm.GAsubCategory = (this.type === 'continue' || this.type === 'watchList' || this.type === 'favorites') ? this.title : (this.showTitle && this.showTitle.category) ? this.showTitle.category : ((this.showTitle && this.showTitle.original_title) ? this.showTitle.original_title : '');
        					this.gtm.setContentClickDetails(this.xIndex, this.yIndex, this.gtm.GAsubCategory);
		    				if (this.show.asset_subtype === 'movie') {
		    					this.router_link.navigate(['/movies/details', this.commonService.convertToLowercase(tempTitle), this.show.id ]);
		    				} else if (this.show.asset_subtype === 'video' && this.show.genres.findIndex(i => i.id === 'News') !== -1) {
		    					this.router_link.navigate(['/news/details', this.commonService.convertToLowercase(tempTitle), this.show.id ]);
		    				} else {
		    					this.router_link.navigate(['/videos/details', this.commonService.convertToLowercase(tempTitle), this.show.id ]);
		    				}
		    			} else if (this.show.asset_type === 2 ) {
          					let base;
          					base = (this.show.tvshow.asset_subtype === 'original') ? 'zee5originals/details/' : 'tvshows/details/';
          					tempTitle = this.show.tvshow.original_title;
						    if (this.show.orderid === 1) {
				                this.router_link.navigate([base , this.commonService.convertToLowercase(tempTitle) , this.show.tvshow.id  , 'episodes']);
				            } else {
				                this.router_link.navigate([base , this.commonService.convertToLowercase(tempTitle) , this.show.tvshow.id , 'season-' + this.show.orderid , 'episodes']);
				            }
		    			} else if (this.show.asset_type === 6 ) {
		    				this.gtm.GAsubCategory = (this.showTitle && this.showTitle.category) ? this.showTitle.category : ((this.showTitle && this.showTitle.original_title) ? this.showTitle.original_title : '');
        					this.gtm.setContentClickDetails(this.xIndex, this.yIndex, this.gtm.GAsubCategory);
		    				if (this.show.title === undefined) {
		    					this.show.title = 'Title';
		    				}
		    				if (this.show.asset_subtype === 'original') {
		    					this.router_link.navigate(['/zee5originals/details', this.commonService.convertToLowercase(tempTitle), this.show.id  ]);
		    				} else {
		    					this.router_link.navigate(['/tvshows/details', this.commonService.convertToLowercase(tempTitle), this.show.id  ]);
		    				}
		    			} else if (this.show.asset_type === 8) {
		    				this.router_link.navigate(['/collections', this.commonService.convertToLowercase(tempTitle), this.show.id ]);
		    			} else if (this.show.asset_type === 9) {
		    				this.gtm.GAsubCategory = (this.showTitle && this.showTitle.original_title) ? this.showTitle.original_title : '';
        					this.gtm.setContentClickDetails(this.xIndex, this.yIndex, this.gtm.GAsubCategory);
		    				this.router_link.navigate(['/channels/details', this.commonService.convertToLowercase(tempTitle), this.show.id ]);
		    			} else if (this.show.asset_type === 10) {
		    				this.gtm.GAsubCategory = this.type !== 'live' ? ((this.showTitle && this.showTitle.original_title) ? this.showTitle.original_title : '') : '';
        					this.gtm.setContentClickDetails(this.xIndex, this.yIndex, this.gtm.GAsubCategory);
		    				if (this.type !== 'live') {
		    					if (this.show.channel_id) {
		    						this.router_link.navigate(['/channels/details', this.commonService.convertToLowercase(this.show.channel_original_title), this.show.channel_id ]);
		    					} else {
		    						let x;
		    						x = new EpgApi(this.http, null, this.config);
		    						x.v1EpgGetById(this.show.id, undefined, this.countryCode).subscribe(value => {
					    				this.gtm.GAsubCategory = (this.showTitle && this.showTitle.category) ? this.showTitle.category : '';
        								this.gtm.setContentClickDetails(this.xIndex, this.yIndex, this.gtm.GAsubCategory);
		    							this.show.channel_id = value.channel.id;
		    							this.router_link.navigate(['/channels/details', this.commonService.convertToLowercase(this.show.channel_name), this.show.channel_id ]);
		    						});
		    					}
		    				}
		    	 		} else if (this.show.asset_type === 1 && (this.type === 'catchUp')) {
							this.gtm.GAsubCategory = this.showTitle && this.showTitle.category ? this.showTitle.category : '';
        					this.gtm.setContentClickDetails(this.xIndex, this.yIndex, this.gtm.GAsubCategory);
		    				if (!this.showTitle.more) {
		    					this.router_link.navigate(['/' + (this.asset_subtype === 'original' ? 'zee5originals' : 'tvshows') + '/details', this.commonService.convertToLowercase(this.show.showTitle) , this.show.tvshow.id,  this.commonService.convertToLowercase(tempTitle), this.show.id ]);
		    				} else {
		    					this.router_link.navigate(['/' + (this.showTitle.tvshow_type === 'original' ? 'zee5originals' : 'tvshows') + '/details', this.commonService.convertToLowercase(this.show.showTitle) , this.show.tvshow.id,  this.commonService.convertToLowercase(tempTitle), this.show.id ]);
		    				}
		    			} else if (this.show.asset_type === 1) {
		    			// } else if (this.show.asset_type === 1 && this.show.tvshow) {
		    				this.gtm.GAsubCategory = (this.type === 'continue' || this.type === 'watchList' || this.type === 'favorites') ? this.title : (this.showTitle && this.showTitle.original_title) ? this.showTitle.original_title : '';
        					this.gtm.setContentClickDetails(this.xIndex, this.yIndex, this.gtm.GAsubCategory);
		    				// this.router_link.navigate([((this.show.tvshow && this.show.tvshow.asset_subtype === 'original') ? 'zee5originals' : 'tvshows') + '/details', this.commonService.convertToLowercase(this.show.showTitle) , this.show.tvshow.id ,  this.commonService.convertToLowercase(tempTitle), this.show.id]);
		    				if (this.show.tvshow) {
		    					this.router_link.navigate([((this.show.tvshow && this.show.tvshow.asset_subtype === 'original') ? 'zee5originals' : 'tvshows') + '/details', this.commonService.convertToLowercase(this.show.showTitle) , this.show.tvshow.id ,  this.commonService.convertToLowercase(tempTitle), this.show.id]);
							} else {
								let tvshowtitle, tvshowid;
								tvshowtitle = 'title';
								tvshowid = '0-6-0';
		    					this.router_link.navigate([((this.show.tvshow && this.show.tvshow.asset_subtype === 'original') ? 'zee5originals' : 'tvshows') + '/details', this.commonService.convertToLowercase(tvshowtitle) , tvshowid ,  this.commonService.convertToLowercase(tempTitle), this.show.id]);
							}
		    			}
		    			}
		    		}
		    	}
		    	public updateTime(s: number): any {
				      let secs, mins, hrs, secs_new, mins_new, time;
				      if (s) {
				        secs = s % 60;
				        s = (s - secs) / 60;
				        mins = s % 60;
				        s = (s - mins) / 60;
				        hrs = s % 60;
				        if (mins < 10) {
				          mins_new = '0' + mins;
				        } else {
				          mins_new = '' + mins;
				        }
				        if (secs < 10) {
				          secs_new = '0' + secs;
				        } else {
				         secs_new = '' + secs;
				        }
				        if (this.displaylanguage === 'ru') {
				        time = (hrs ? hrs + 'ч' : '') + (mins ? (' ' + mins_new) + 'м' : '') + (secs ? (' ' + secs_new) + 'с' : '');
				        } else {
				        time = (hrs ? hrs + 'h' : '') + (mins ? (' ' + mins_new) + 'm' : '') + (secs ? (' ' + secs_new) + 's' : '');
				        }
				        return time;
				      } else {
				         time = '';
				         return time;
				      }
		        }
		        public updateGMTime(UTC): any {
		        	let x, time;
		        	x = new Date(UTC);
		        	if ( x.getMinutes() < 9 ) {
		        		time = x.getHours() + ':' + '0' + x.getMinutes();
		        	} else {
		        		time = x.getHours() + ':' + x.getMinutes();
		        	}
		        	return time;
		        }
		        public updateLiveTime(s: number): any {
		        	/* Convert millisecs to hours+mins+secs */
		        	let secs, mins, hrs, hrsStr, time;
		        	secs = (s / 1000) % 60;
		        	s = ((s / 1000) - secs) / 60;
		        	mins = s % 60;
		        	s = (s - mins) / 60;
		        	hrs = s % 60;
		        	secs = Math.floor(secs);
		        	hrsStr = hrs ? ((hrs < 10 ? '0' + hrs : hrs) + ':') : '';
		        	if (this.displaylanguage === 'ru') {
                		time = (hrs ? hrs + 'ч' : '') + ' ' + (mins ? mins + 'м' : '') + ' ' + (secs ? secs + 'с' : '');
                	} else {
                		time = (hrs ? hrs + 'h' : '') + ' ' + (mins ? mins + 'm' : '') + ' ' + (secs ? secs + 's' : '');
                	}
		        	// time = (hrs ? hrs + 'h' : '') + ' ' + (mins ? mins + 'm' : '') + ' ' + (secs ? secs + 's' : '');
		        	return time;
		        }
		        public imageError(): void {
		        	if (this.type === 'movies' || this.type === 'movie' || this.type === 'movies_details' || this.type === 'categorymovies'  ) {
		        		this.image_container.nativeElement.src = environment.assetsBasePath + 'assets/default/movies.png';
		        	} else if (this.type === 'eventbanner') {
		        		this.image_container.nativeElement.src = environment.assetsBasePath + 'assets/default/eventbanner.jpg';
		        	} else if (this.type === 'zeeOriginals' || this.type === 'categoryzeeOriginals') {
		        		this.image_container.nativeElement.src = environment.assetsBasePath + 'assets/default/tvshow.png';
		        	} else if (this.popular) {
		        		this.image_container.nativeElement.src = environment.assetsBasePath + 'assets/default/popular.png';
		        	} else {
		        		this.image_container.nativeElement.src = environment.assetsBasePath + 'assets/default/tvshow.png';
		        	}

		        }
		        public videoError() {
          			this.commonService.updateCollectionId('');
          			this.commonService.setTalamoosData('', '', '');
        			this.gtm.clearContentClickDetails();
		        	let p;
		        	p = this.document.getElementById('snackbar');
		        	p.className = 'show';
		        	setTimeout(function() { p.className = p.className.replace('show', ''); }, 3000);
		        }
		        public dateChange(value) {
		        	if (value) {
		        		let date;
		        		let day, monthIndex, year;
		        		date = new Date(value);
		        		day = date.getDate();
		        		monthIndex = date.getMonth();
		        		year = date.getFullYear();
		        		return (day + ' ' + this.months[monthIndex]  + ', ' + year) ;
		        	} else {
		        		return '';
		        	}
		        }
		        public watchNow(event: any): void {
                    let ctaString;
                    ctaString = this.watched ? 'remove from watchlist' : 'add to watchlist';
		        	if (this.networkService.getPopupStatus()) {
		        		if (this.token) {
		        	$('.auto-loader-watch').css('display', 'inline-block');
    				$('#watched').css('display', 'none');
		        			event.stopPropagation();
		        			let watchListRequest;
		        			watchListRequest = new  WatchlistApi(this.http, null, this.configUser);
		        			if (this.watched === true ) {
		        				watchListRequest.v1WatchlistDelete(this.show.id, this.show.asset_type).subscribe(value => {
		        					this.watched = false;
		        					this.userProfileService.removeWatchData(this.show);
		        					$('.auto-loader-watch').css('display', 'none');
    								$('#watched').css('display', '');
		        				},
		        				err => {
		        					this.watched = true;
		        				});
		        			} else {
		                        let obj;
		                        obj = this.userProfileService.createObject(this.show);
		        				watchListRequest.v1WatchlistPost(obj).subscribe(value => {
		        					this.genres = [];
		        					let genres;
		        					if (this.type === 'watchList' || this.type === 'favorites') {
		        						genres = this.show.genres;
		        					} else if (this.show.genres) {
		        						for (let index = 0; index < this.show.genres.length; index++) {
		        							this.genres.push(this.show.genres[index].value);
		        						}
		        						genres = this.genres.join(', ');
		        					}

		        					if (this.show.asset_subtype === 'video') {
        								this.commonService.qgraphevent('videosection_added_to_watch_later', {'video_name': this.show.title , 'language': '', 'genre': genres, 'time_spent': this.show.duration, 'country': this.countryCode, 'state': this.localstorage.getItem('state_code')});
		        					} else {
        								this.commonService.qgraphevent('moviessection_added_to_watch_later', {'movie_name': this.show.title, 'genre': genres, 'time_spent': this.show.duration, 'language': '', 'country': this.countryCode, 'state': this.localstorage.getItem('state_code')});
		        					}
		        					this.watched = true;
		        					this.userProfileService.setWatchData(this.show);
		        					$('.auto-loader-watch').css('display', 'none');
    								$('#watched').css('display', '');
		        				},
		        				err => {
		        					this.watched = false;
		        					this.gtm.sendErrorEvent('api', err);
		        					$('.auto-loader-watch').css('display', 'none');
    								$('#watched').css('display', '');
		        				});
		        			}
		        		} else {
		        			this.headerservicesService.signReminderChange(true);
		        		}
		        	}
		        	
		        	this.gtm.logEvent(this.threeDotEvent(ctaString));     	
		        }
		        private callTalamoosClick(): any {

		        	if (this.modelname && this.show.clickID) {
		        		let data;
		        		data = {
							'type': 'zee5',
							'action': 'click',
							'modelName': this.modelname,
							// 'userID': this.localstorage.getItem('token') ? this.localstorage.getItem('token') : this.localstorage.getItem('guestToken'),
							'itemID': this.show.id,
							'clickID': this.show.clickID
						};

						this.useractionapi.talamoosClick(data).subscribe(callback => {
							// console.log(callback, 'callback');
						});
		        	}
				}
				public checkVideo(thumbnailClick): any {
		        	this.callTalamoosClick();
				if (this.railsView) {
        				this.sendGAevent();
        			}
				if (this.parentType === 'search') {
					this.commonService.sendSearchClickEvent(this.image_url);
				}
				 let data;
                          this.videoViewClickEvents();
                           data = this.videoViewEvents;
                   this.gtm.GAsubCategory = (this.showTitle && this.showTitle.category) ? this.showTitle.category : ((this.showTitle && this.showTitle.original_title) ? this.showTitle.original_title : '');
            	   this.gtm.setContentClickDetails(this.xIndex, this.yIndex, this.gtm.GAsubCategory);
		        	if (this.show.asset_type === 101) {
		        	this.commonService.assetCheck(this.show, this.router_link, this.url3, 'thumbnailImageClick', data);
		        	} else {
			        	// if ( this.parentType === 'episodes') {
			        	// 	this.routeFunction();
			        	// } else {
			        		this.startVideo(thumbnailClick, data);
			        	// }
		        	}
		        }
		        public addFavorite(event: any): void {
		        	let ctaString;
		        	ctaString = this.favorite ?  'remove from favourite' : 'add to favourite';
		        	if (this.networkService.getPopupStatus()) {
		        		let token;
		        		token = this.localstorage.getItem('token');
		        		if (token) {
		        		$('.auto-loader').css('display', 'inline-block');
    					$('#favorite').css('display', 'none');
		        			event.stopPropagation();
		        			let favoritesRequest;
		        			favoritesRequest = new  FavoritesApi(this.http, null, this.configUser);
		        			if (this.favorite === true ) {
		        				favoritesRequest.v1FavoritesDelete(this.show.id, this.show.asset_type).subscribe(value => {
		        					this.favorite = false;
		        					this.userProfileService.removeFavoriteData(this.show);
    								$('.auto-loader').css('display', 'none');
    								$('#favorite').css('display', '');
		        				},
		        				err => {
		        					this.favorite = true;
		        					this.gtm.sendErrorEvent('api', err);
    								$('.auto-loader').css('display', 'none');
    								$('#favorite').css('display', '');

		        				});
		        			} else {
		        				let obj;
		        				obj = this.userProfileService.createObject(this.show);
		        				favoritesRequest.v1FavoritesPost(obj).subscribe(value => {
		        					this.favorite = true;
		        					this.userProfileService.setFavoriteData(this.show);
    								$('.auto-loader').css('display', 'none');
    								$('#favorite').css('display', '');

		        				},
		        				err => {
		        					this.favorite = false;
		        					this.gtm.sendErrorEvent('api', err);
    								$('.auto-loader').css('display', 'none');
    								$('#favorite').css('display', '');

		        				});
		        			}
		        		} else {
		        			this.headerservicesService.signReminderChange(true);
		        		}
		        	}
		        	this.gtm.logEvent(this.threeDotEvent(ctaString));
		        }
		        public setreminder(event: any): void {
		        	let ctaString;
		        	ctaString = this.reminder ? 'remove reminder' : 'set reminder';
		        	if (this.networkService.getPopupStatus()) {
		        		let token;
		        		token = this.localstorage.getItem('token');
		        		if (token) {
		        			let reminderType, login_type;
		        			login_type = this.localstorage.getItem('login');
		        			reminderType = (( login_type === 'Mobile') ? 'Mobile' : 'Email');
		        			event.stopPropagation();
		        			if (this.reminder === true ) {
		        				this.reminder = false;
		        				this.userProfileService.removeReminderData(this.show.vod_id, this.show.vod_asset_type );
		        			} else {
		        				this.reminder = true;
		        				this.userProfileService.setReminderData({'id': this.show.vod_id, 'asset_type': this.show.vod_asset_type , 'reminder_type' : reminderType});
		      //   				this.timestampTime = this.gtm.fetchCurrentTime();
		      //   				this.timestampDateTime = this.gtm.fetchCurrentDate();
		      //   				this.clientID = this.gtm.fetchClientId();
								// this.marketingValue = this.gtm.fetchMarketing();

		      //   				let genres;
		      //   				genres = [];
		      //   				if (this.show.genres) {
		      //   				for ( let index = 0; index < this.show.genres.length; index++) {
		      //   					genres.push(this.show.genres[index].value);
		      //   				}
		      //   				}
		      //   				let genresdata;
		      //   				genresdata = genres.join(',');

		      //   				this.addReminder =  {
		      //   					'event' : 'AddRemider',
		      //   					'VideoName' : this.show.title,
		      //   					'VideoCategory': genresdata,
		      //   					'VideoSection': this.notAvailable,
		      //   					'VideoSubTitle': this.notAvailable,
		      //   					'TVChannels': '',
		      //   					'VideoDuration': this.show.duration,
		      //   					'VideoStartTime': this.show.start_time,
		      //   					'Time_Slot': this.notAvailable,
		      //   					'Episode_Number': this.notAvailable,
		      //   					'Tumbnail_Image': this.image_url,
		      //   					'G_ID': this.tokenValue,
		      //   					'Client_ID': this.clientID,
		      //   					'retargeting_remarketing' : this.marketingValue,
		      //   					'TimeHHMMSS': this.timestampTime,
		      //   					'DateTimeStamp': this.timestampDateTime
		      //   				};
		      //   				this.gtm.logEvent(this.addReminder);
		        			}
		        		} else {
		        			this.headerservicesService.signReminderChange(true);
		        		}
		        	}
		        	this.gtm.logEvent(this.threeDotEvent(ctaString));
		        }
		        public stopEvent(event: any) {
		        	event.stopPropagation();
		        }
		        public share(event: any): void {
		        	let ctaString;
		        	ctaString = 'share';
		        	if (this.networkService.getPopupStatus()) {
		        		event.stopPropagation();
		        		if (this.show.asset_type === 101) {
		        			if (this.show.genres[0].value === 'internal_link') {
		        				this.shareUrlExternal = this.show.slug;
		        				this.showShare = true;
		        			} else {
		        				this.showShare = false;
		        			}
		        		} else {
		        			this.shareUrl = this.hrefBaseUrl;
		        			this.showShare = true;
		        		}

		        	}
		        	this.gtm.logEvent(this.threeDotEvent(ctaString));
		        }
		        private sendGAevent(): any {
		        	let details;
		        	details = {
		        		'event': 'videoPopupClick',
		        		'Video_Popup_Position': (this.xIndex + 1) || this.notAvailable,
		        		'collection_id': this.commonService.getCollectionId() || this.notAvailable
		        	};
    				details = $.extend({}, this.gaVideoDetails, details);
		        	this.videoService.googleAnalyticPost(details, '', {});
		        }
		        public hrefUrl(): void {

		        	let tempTitle ;
		           //  if (this.show && this.show.extended && this.show.extended.seo_title) {
            	// 		tempTitle = (this.show.extended.seo_title !== null || this.show.extended.seo_title !== undefined || this.show.extended.seo_title !== '') ? this.show.extended.seo_title : this.show.original_title;
          			// } else {
            	// 		tempTitle = (this.show.seo_title && (this.show.seo_title !== null || this.show.seo_title !== undefined || this.show.seo_title !== '')) ? this.show.seo_title : this.show.original_title;
          			// }
    				tempTitle = this.show.original_title;
		        	if (this.networkService.getPopupStatus()) {
		        		if (this.show.asset_type === 101) {
		        			// changed genre spelling
		        			if (this.show.genres[0].value !== 'internal_link') {
		        				this.external = true;
		        			}
		        			this.shareUrl = this.show.slug;

		        		}
		        		if (this.show.asset_type === 0 ) {
		        			if (this.show.asset_subtype === 'movie') {
		        				this.hrefBaseUrl =  'movies/details/' +  this.commonService.convertToLowercase(tempTitle)  + '/' + this.show.id;
		        			} else if (this.show.asset_subtype === 'video' && this.show.genres.findIndex(i => i.id === 'News') !== -1) {
		        				this.hrefBaseUrl =  'news/details/' + this.commonService.convertToLowercase(tempTitle) + '/' + this.show.id;
		    				} else {
		        				this.hrefBaseUrl =  'videos/details/' + this.commonService.convertToLowercase(tempTitle) + '/' + this.show.id;
		        			}
		        			} else if (this.show.asset_type === 2 ) {
	          					let base;
	          					base = (this.show.tvshow.asset_subtype === 'original') ? 'zee5originals/details/' : 'tvshows/details/';
          						tempTitle = this.show.tvshow.original_title;
							    if (this.show.orderid === 1) {
					                this.hrefBaseUrl =  base + this.commonService.convertToLowercase(tempTitle) + '/' + this.show.tvshow.id  + '/episodes';
					            } else {
					                this.hrefBaseUrl =  base + this.commonService.convertToLowercase(tempTitle) + '/' + this.show.tvshow.id + '/season-' + this.show.orderid + '/episodes';
					            }
					        } else if (this.show.asset_type === 6 ) {
		        			if (this.show.title === undefined) {
		        				this.show.title = 'title';
		        			}
		        			if (this.show.asset_subtype === 'original') {
		        				this.hrefBaseUrl =  'zee5originals/details/' +  this.commonService.convertToLowercase(tempTitle)  + '/' + this.show.id;
		        			} else {
		        				this.hrefBaseUrl =  'tvshows/details/' +  this.commonService.convertToLowercase(tempTitle)  + '/' + this.show.id;
		        			}
		        		} else if (this.show.asset_type === 9) {
		        			this.hrefBaseUrl =  'channels/details/' +  this.commonService.convertToLowercase(tempTitle)  + '/' + this.show.id;
		        		}  else if (this.show.asset_type === 8) {
		        			this.hrefBaseUrl = 'collections/' + this.commonService.convertToLowercase(tempTitle) + '/' + this.show.id;
		        		} else if (this.show.asset_type === 10) {
		        			if (this.type !== 'live') {
		        				if (this.show.channel_id) {
		        					this.hrefBaseUrl = 'channels/details/' + this.commonService.convertToLowercase(this.show.channel_original_title) + '/' + this.show.channel_id ;
		        				} else {
		        					let x;
		        					x = new EpgApi(this.http, null, this.config);
		        					x.v1EpgGetById(this.show.id, undefined, this.countryCode).subscribe(value => {
		        						this.show.channel_id = value.channel.id;
		        						this.hrefBaseUrl = 'channels/details/' + this.commonService.convertToLowercase(this.show.channel_name) + '/' + this.show.channel_id ;
		        					});
		        				}
		        			} else  {
		        				this.hrefBaseUrl = this.router_link.url;
		        			}
		        		} else if (this.show.asset_type === 1 && (this.type === 'continue' || this.type === 'watchList' || this.type === 'favorites')) {
		        			this.hrefBaseUrl = (this.show.tvshow && this.show.tvshow.asset_subtype === 'original' ? 'zee5originals' : 'tvshows') + '/details/' + this.commonService.convertToLowercase(this.show.showTitle) + '/' + this.show.tvshow.id + '/' + this.commonService.convertToLowercase(tempTitle) + '/' + this.show.id ;
		        		} else if (this.show.asset_type === 1 && (this.type === 'catchUp')) {
		        			if (!this.showTitle.more) {
		        				this.hrefBaseUrl = (this.asset_subtype === 'original' ? 'zee5originals' : 'tvshows') + '/details/' + this.commonService.convertToLowercase(this.show.showTitle) + '/' + this.show.tvshow.id + '/' + this.commonService.convertToLowercase(tempTitle) + '/' + this.show.id ;
		        			} else {
		        				this.hrefBaseUrl =  (this.showTitle.tvshow_type === 'original' ? 'zee5originals' : 'tvshows') + '/details/' + this.commonService.convertToLowercase(this.show.showTitle) + '/' + this.show.tvshow.id + '/' + this.commonService.convertToLowercase(tempTitle) + '/' + this.show.id ;
		        			}
		        		} else if (this.show.asset_type === 1 && this.show.tvshow && !(this.type === 'continue' || this.type === 'watchList' || this.type === 'favorites' )) {
		        			this.hrefBaseUrl = (this.show.tvshow && this.show.tvshow.asset_subtype === 'original' ? 'zee5originals' : 'tvshows') + '/details/' + this.commonService.convertToLowercase(this.show.showTitle) + '/' + this.show.tvshow.id + '/' + this.commonService.convertToLowercase(tempTitle) + '/' + this.show.id ;			}
		        		}

		     //    		if(this.localstorage.getItem('token')) {
		     //    			if(this.localstorage.getItem('UserDisplayLanguage') !== 'en') {
		     //    				this.hrefBaseUrl = this.localstorage.getItem('UserDisplayLanguage') + '/' + this.hrefBaseUrl
		     //    			}
		     //    		} else {
							// if(this.localstorage.getItem('display_language') !== 'en') {
		     //    				this.hrefBaseUrl = this.localstorage.getItem('display_language') + '/' + this.hrefBaseUrl
		     //    			}
		     //    		}
		        	}

		        	public remove (event: any): void {
		        		let ctaString;
		        		ctaString = 'remove';
		        		if (this.networkService.getPopupStatus()) {
		        			$('.auto-loader-remove').css('display', 'inline-block');
    						$('#remove').css('display', 'none');
		        			event.stopPropagation();
		        			if ( this.type === 'favorites' ) {
		        				let favoritesRequest;
		        				favoritesRequest = new  FavoritesApi(this.http, null, this.configUser);
		        				favoritesRequest.v1FavoritesDelete(this.show.id, this.show.asset_type).subscribe(value => {

		        					this.userProfileService.removeFavoriteData(this.show);
		        					this.favorite = false;
		        					this.onChange.emit({'show': this.show, 'type': this.type});
		        					$('.auto-loader-remove').css('display', 'none');
    								$('#remove').css('display', '');
		        				},
		        				err => {
		        					this.favorite = true;
		        					this.gtm.sendErrorEvent('api', err);
		        					$('.auto-loader-remove').css('display', 'none');
    								$('#remove').css('display', '');
		        				});
		        			} else if (this.type === 'watchList') {
		        				let watchListRequest;
		        				watchListRequest = new  WatchlistApi(this.http, null, this.configUser);
		        				watchListRequest.v1WatchlistDelete(this.show.id, this.show.asset_type).subscribe(value => {
		        					this.userProfileService.removeWatchData(this.show);
		        					this.watched = false;
		        					this.onChange.emit({'show': this.show, 'type': this.type});
		        					$('.auto-loader-remove').css('display', 'none');
    								$('#remove').css('display', '');
		        				},
		        				err => {
		        					this.watched = true;
		        					$('.auto-loader-remove').css('display', 'none');
    								$('#remove').css('display', '');
		        				});
		        			}
		        		}
		        		this.gtm.logEvent(this.threeDotEvent(ctaString));
		        	}
		        	public dismiss(): void {
		        		this.onChange.emit( this.show);
		        		let ctaString;
		        		ctaString = 'dismiss';
		        	}
		        	public catchUp(event: any): void {
		        		event.stopPropagation();
		        	}

		        	public startVideo(thumbnailClick, data): any {
          			this.videoService.autoPlayed('');
          			this.commonService.updateCollectionId(this.collectionId);
          			this.commonService.setTalamoosData(this.modelname, this.show.clickID, this.show.origin);
		        	let tempTitle ;
		           //  if (this.show && this.show.extended && this.show.extended.seo_title) {
            	// 		tempTitle = (this.show.extended.seo_title !== null || this.show.extended.seo_title !== undefined || this.show.extended.seo_title !== '') ? this.show.extended.seo_title : this.show.original_title;
          			// } else {
            	// 		tempTitle = (this.show.seo_title && (this.show.seo_title !== null || this.show.seo_title !== undefined || this.show.seo_title !== '')) ? this.show.seo_title : this.show.original_title;
          			// }
    			tempTitle = this.show.original_title;
		        		if (this.networkService.getPopupStatus()) {
		        			this.loadMoreMenu();
		        			if (thumbnailClick) {
		        	           this.commonService.assetCheck(this.show, this.router_link, this.url3, 'thumbnailImageClick', data);
		        			}
		        			let scope;
		        			scope = this;
		        			if (this.show.asset_type === 0 && this.type === 'continue') {
		        				this.gtm.GAsubCategory = this.title;
        						this.gtm.setContentClickDetails(this.xIndex, this.yIndex, this.gtm.GAsubCategory);
		        				if (this.show.asset_subtype === 'movie') {
		        					this.router_link.navigate(['movies/details/' , this.commonService.convertToLowercase(tempTitle) , this.show.id ]);
		        				} else if (this.show.asset_subtype === 'video' && this.show.genres.findIndex(i => i.id === 'News') !== -1) {
		        					this.router_link.navigate(['news/details/' , this.commonService.convertToLowercase(tempTitle) , this.show.id]);
		    					} else {
		        					this.router_link.navigate(['videos/details/' , this.commonService.convertToLowercase(tempTitle) , this.show.id]);
		        				}
		        			} else if (this.show.asset_type === 0 && (this.type === 'watchList' || this.type === 'favorites') && this.show.video) {
		        				this.gtm.GAsubCategory = this.title;
        						this.gtm.setContentClickDetails(this.xIndex, this.yIndex, this.gtm.GAsubCategory);
		        				if (this.show.asset_subtype === 'movie') {
		        					this.router_link.navigate(['movies/details/' , this.commonService.convertToLowercase(tempTitle) , this.show.id ]);
		        				} else if (this.show.asset_subtype === 'video' && this.show.genres.findIndex(i => i.id === 'News') !== -1) {
		        					this.router_link.navigate(['news/details/' , this.commonService.convertToLowercase(tempTitle) , this.show.id]);
		    					} else {
		        					this.router_link.navigate(['videos/details/' , this.commonService.convertToLowercase(tempTitle) , this.show.id]);
		        				}
		        			} else if (this.show.asset_type === 0 && this.type !== 'continue' && this.type !== 'watchList' && this.type !== 'favorites') {
							    this.gtm.GAsubCategory = (this.showTitle && this.showTitle.category) ? this.showTitle.category : ((this.showTitle && this.showTitle.original_title) ? this.showTitle.original_title : '');
        						this.gtm.setContentClickDetails(this.xIndex, this.yIndex, this.gtm.GAsubCategory);
		        				if (this.show.asset_subtype === 'movie') {
		        					this.router_link.navigate(['movies/details/' , this.commonService.convertToLowercase(tempTitle) , this.show.id ]);
		        				} else if (this.show.asset_subtype === 'video' && this.show.genres.findIndex(i => i.id === 'News') !== -1) {
		        					this.router_link.navigate(['news/details/' , this.commonService.convertToLowercase(tempTitle) , this.show.id]);
		    					} else {
		        					this.router_link.navigate(['videos/details/' , this.commonService.convertToLowercase(tempTitle) , this.show.id ]);
		        				}
		        			}  else if (this.show.asset_type === 8) {
		        				this.router_link .navigate(['/collections', this.commonService.convertToLowercase(tempTitle), this.show.id ]);
		        			} else if (this.show.asset_type === 2 ) {
	          					let base;
	          					base = (this.show.tvshow.asset_subtype === 'original') ? 'zee5originals/details/' : 'tvshows/details/';
          						tempTitle = this.show.tvshow.original_title;
							    if (this.show.orderid === 1) {
					                this.router_link.navigate([base , this.commonService.convertToLowercase(tempTitle) , this.show.tvshow.id  , 'episodes']);
					            } else {
					                this.router_link.navigate([base , this.commonService.convertToLowercase(tempTitle) , this.show.tvshow.id , 'season-' + this.show.orderid , 'episodes']);
					            }
					        } else if (this.show.asset_type === 6 ) {
			    				this.gtm.GAsubCategory = (this.showTitle && this.showTitle.category) ? this.showTitle.category : ((this.showTitle && this.showTitle.original_title) ? this.showTitle.original_title : '');
        						this.gtm.setContentClickDetails(this.xIndex, this.yIndex, this.gtm.GAsubCategory);
			    				this.router_link.navigate([(this.show.asset_subtype === 'original' ? 'zee5originals' : 'tvshows') + '/details/' , this.commonService.convertToLowercase(tempTitle), this.show.id, 'latest'  ]);
		        			} else if (this.show.asset_type === 9 ) {
		        				this.gtm.GAsubCategory = (this.showTitle && this.showTitle.original_title) ? this.showTitle.original_title : '';
        						this.gtm.setContentClickDetails(this.xIndex, this.yIndex, this.gtm.GAsubCategory);
		        				this.router_link.navigate(['/channels/details', this.commonService.convertToLowercase(tempTitle), this.show.id ]);
		        			} else if (this.show.asset_type === 1 && (this.type === 'watchList' || this.type === 'favorites') && this.show.video) {
		        				this.gtm.GAsubCategory = this.title;
        						this.gtm.setContentClickDetails(this.xIndex, this.yIndex, this.gtm.GAsubCategory);
		        				if ( this.show.tvshow && this.show.tvshow.asset_subtype === 'original') {
		        					this.router_link.navigate(['zee5originals/details/' , this.commonService.convertToLowercase(this.show.showTitle) , this.show.tvshow.id ,  this.commonService.convertToLowercase(tempTitle)  , this.show.id  ]);
		        				} else if (this.show.tvshow && this.show.tvshow.asset_subtype ) {
		        					this.router_link.navigate(['tvshows/details/' , this.commonService.convertToLowercase(this.show.showTitle) , this.show.tvshow.id ,  this.commonService.convertToLowercase(tempTitle)  , this.show.id  ]);
		        				}
		        			} else if (this.show.asset_type === 1 && this.type === 'continue') {
		        				this.gtm.GAsubCategory = this.title;
        						this.gtm.setContentClickDetails(this.xIndex, this.yIndex, this.gtm.GAsubCategory);
		        				if ( this.show.tvshow && this.show.tvshow.asset_subtype === 'original') {
		        					this.router_link .navigate(['zee5originals/details/' , this.commonService.convertToLowercase(this.show.showTitle) , this.show.tvshow.id ,  this.commonService.convertToLowercase(tempTitle)  , this.show.id  ]);
		        				} else if (this.show.tvshow && this.show.tvshow.asset_subtype ) {
		        					this.router_link .navigate(['tvshows/details/' , this.commonService.convertToLowercase(this.show.showTitle) , this.show.tvshow.id ,  this.commonService.convertToLowercase(tempTitle)  , this.show.id  ]);
		        				}
		        			} else if (this.show.asset_type === 1 && (this.type === 'catchUp' ) ) {
		        				// if ( this.show.video_details ) {
		        						if (!this.showTitle.more) {
		        							this.gtm.GAsubCategory = this.showTitle ? this.showTitle.category : '';
        									this.gtm.setContentClickDetails(this.xIndex, this.yIndex, this.gtm.GAsubCategory);
		        							if (this.show.tvshow.asset_subtype === 'original') {
		        								this.router_link.navigate(['zee5originals/details/' ,  this.commonService.convertToLowercase(this.show.showTitle) , this.show.tvshow.id ,  this.commonService.convertToLowercase(tempTitle)  , this.show.id ]);
		        							} else {
		        								this.router_link.navigate(['tvshows/details/' ,  this.commonService.convertToLowercase(this.show.showTitle) , this.show.tvshow.id ,  this.commonService.convertToLowercase(tempTitle)  , this.show.id ]);
		        							}
		        						} else {
		        							this.gtm.GAsubCategory =  this.showTitle ? this.showTitle.category : '';
        									this.gtm.setContentClickDetails(this.xIndex, this.yIndex, this.gtm.GAsubCategory);
		        							this.router_link.navigate(['/' + (this.showTitle.tvshow_type === 'original' ? 'zee5originals' : 'tvshows') + '/details', this.commonService.convertToLowercase(this.show.showTitle) , this.show.tvshow.id,  this.commonService.convertToLowercase(tempTitle), this.show.id ]);
		        						}
		        				// } else {
		        				// 	this.videoError();
		        				// }
		        			} else if (this.show.asset_type === 1 && (this.type !== 'catchUp' ) && (this.type !== 'continue' ) && this.type !== 'watchList' && this.type !== 'favorites' ) {
							this.gtm.GAsubCategory = (this.showTitle && this.showTitle.original_title) ? this.showTitle.original_title : '';
        					this.gtm.setContentClickDetails(this.xIndex, this.yIndex, this.gtm.GAsubCategory);
							if ( this.show.tvshow && this.show.tvshow.asset_subtype === 'original') {
								this.router_link.navigate(['zee5originals/details/' ,  this.commonService.convertToLowercase(this.show.tvshow.original_title) , this.show.tvshow.id , this.commonService.convertToLowercase(tempTitle) , this.show.id ]);
							} else if (this.show.tvshow) {
								this.router_link.navigate(['tvshows/details/' ,  this.commonService.convertToLowercase(this.show.tvshow.original_title) , this.show.tvshow.id , this.commonService.convertToLowercase(tempTitle) , this.show.id ]);
							} else {
								let tvshowtitle, tvshowid;
								tvshowtitle = 'title';
								tvshowid = '0-6-0';
								this.router_link.navigate(['tvshows/details/' ,  this.commonService.convertToLowercase(tvshowtitle) , tvshowid , this.commonService.convertToLowercase(tempTitle) , this.show.id ]);
							}
					} else if (this.show.asset_type === 10) {
						if (this.type !== 'live') {
							if (this.show.channel_id ) {
								this.gtm.GAsubCategory = (this.showTitle && this.showTitle.original_title) ? this.showTitle.original_title : '';
        						this.gtm.setContentClickDetails(this.xIndex, this.yIndex, this.gtm.GAsubCategory);
								this.router_link.navigate(['/channels/details', this.commonService.convertToLowercase(this.show.channel_original_title), this.show.channel_id ]);
							} else {
								let x;
								x = new EpgApi(this.http, null, this.config);
								x.v1EpgGetById(this.show.id, undefined, this.countryCode).subscribe(value => {
				    				this.gtm.GAsubCategory = (this.showTitle && this.showTitle.category) ? this.showTitle.category : '';
        							this.gtm.setContentClickDetails(this.xIndex, this.yIndex, this.gtm.GAsubCategory);
									this.show.channel_id = value.channel.id;
									this.router_link.navigate(['channels/details', this.commonService.convertToLowercase(this.show.channel), this.show.channel_id ]);
								}
								);
							}
						}
					} else {
						this.videoError();
					}
				}
			}
			public showMenu(): void {
				this.loadMoreMenu();
				let scope;
				scope = this;
				this.menuOpen = true;
				if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
					// mobile devices
				} else {
					if (this.window.innerWidth > 769) {
						$('.cdk-overlay-backdrop').css('pointer-events', 'none');
						$(this.document).mouseup(function(e) {
							let container;
							container = $('.mat-menu-content');
					// if the target of the click isn't the container nor a descendant of the container
					if (!container.is(e.target) && container.has(e.target).length === 0 && scope.menuOpen === true) {
						scope.trigger.closeMenu();
						scope.menuOpen = false;
					}
				});
					}
				}
			}
			public showCardDetails(event, show): void {
				this.topValue = 0;
				this.left_arrow = false;
				this.right_arrow = false;
				this.cardDetails = false;

				if (this.showCard) {
					if (show.asset_type === 0 || show.asset_type === 1 || show.asset_type === 6) {
					if (this.window.innerWidth > 769) {
						if (this.isMoviePage) {
							if (event.target.offsetHeight > 212) {
							this.topValue = Math.floor((event.target.offsetHeight - 212) / 2);
						} else {
							if ((this.window.innerWidth - event.clientX) > 460) {
							this.topValue = -5;
							} else {
							this.topValue = -11;
							}
						}
							if ((this.window.innerWidth - event.clientX) > 460) {
								this.leftValue = event.target.offsetWidth + 4;
								this.leftValueImg = -17;
								this.left_arrow = true;
								this.outerContainerImg = environment.assetsBasePath + 'assets/common/popup_outerContainer.png';
							} else {
								this.leftValue = -290;
								this.right_arrow = true;
								this.leftValueImg = 5;
								this.outerContainerImg = environment.assetsBasePath + 'assets/common/popup_outerContainer_right.png';
							}

					} else {
						if (event.target.offsetHeight > 212) {
						this.topValue = Math.floor((event.target.offsetHeight - 212) / 2);
					} else {
						if (this.window.innerWidth > 769 && this.window.innerWidth < 1000 ) {
							this.topValue = -4;
						} else {
							this.topValue = -3;
						}
					}
					if ((this.window.innerWidth - event.clientX) > (1.75 * event.target.offsetWidth)) {
						this.leftValue = event.target.offsetWidth + 4;
						this.leftValueImg = -5.85;
						this.left_arrow = true;
						this.outerContainerImg = environment.assetsBasePath + 'assets/common/popup_outerContainer.png';
					} else {
						let temp;
						temp = event.target.offsetParent.offsetWidth - event.target.offsetWidth;
						this.leftValue = - (event.target.offsetWidth + (2 * temp));
						this.right_arrow = true;
						this.leftValueImg = 3.8;
						this.topValue = -4;
						this.outerContainerImg = environment.assetsBasePath + 'assets/common/popup_outerContainer_right.png';
					}
					}
					this.cardDetails = true;
					this.card_title = show.title && (show.title !== null || show.title !== '') ? show.title : null;
					// let cardType = show.asset_subtype && (show.asset_subtype !== null || show.asset_subtype !== '') ? show.asset_subtype : null;
					// if ( cardType !== null ) {
					// 	this.card_type = cardType.charAt(0).toUpperCase() + cardType.slice(1);
					// }
					this.card_type = this.commonService.getDefaultSub(show.asset_type, show.asset_subtype);
					show.genres = show.genres ? show.genres : (show.genre ? show.genres : []);
					if (show.asset_subtype === 'video' && show.genres.findIndex(i => i.id === 'News') !== -1) {
				    	this.card_type = this.tagList.join(', ');
					}
					this.card_season = show.season && show.season.orderid && (show.season.orderid != null || show.season.orderid !== '') ? show.season.orderid : null;
					this.showRating = show.age_rating && (show.age_rating !== null || show.age_rating !== '') ? show.age_rating : null;
				      let ageratingList, countryList;
				            countryList = this.settingsService.getCountryValueNew();
				            ageratingList = countryList[0].age_rating; // age rating number json
				            let validText;
				             if (ageratingList && ageratingList[this.showRating]) {
				                if ( ageratingList[this.showRating] === '0' ) {
				                     this.valid_string = this.translate.instant('MESSAGES.FOR_ALL');
				                } else {
				                this.translate.get(['MESSAGES.AGE_RATING']).subscribe(value => {
				                validText = value['MESSAGES.AGE_RATING'];
				                this.valid_string = validText.replace(/<age>/g, +  ageratingList[this.showRating]);
				                });
				              }
				            } else {
				                 this.valid_string = this.showRating;
				             }
				           this.ageratefunction();
				      if (this.agetake) {
				             this.age_rating= this.valid_string;
				      } else {
				             this.age_rating =this.showRating;
				      }
                 // this.age_rating = show.age_rating && (show.age_rating !== null || show.age_rating !== '') ? show.age_rating : null;
					let genreArray;
					genreArray = [];
					let display_lang;
					if (this.token) {
						display_lang = this.localstorage.getItem('UserDisplayLanguage');
					} else {
						display_lang = this.localstorage.getItem('display_language');
					}
					for ( let i = 0; i < show.genres.length ; i++) {
						genreArray.push(show.genres[i].value);
					}
					this.card_genre = genreArray.length > 0 ? genreArray.toString() : null;

					if ( show.languages && show.languages.length && show.languages.length > 0) {
						let audioArray;
						audioArray = [];
						for (let i = 0; i < show.languages.length; i++) {
						let lang;
						lang = this.configValue.languages_labels[display_lang][show.languages[i]];
						if (lang) {
							audioArray.push(lang);
						}
					}
					this.card_audio = audioArray.length > 0 ? audioArray.toString() : null ;
					}

					if ( show.subtitle_languages && show.subtitle_languages.length && show.subtitle_languages.length > 0) {
						let subtitleArray;
						subtitleArray = [];
						for (let i = 0; i < show.subtitle_languages.length; i++) {
						let subtitle;
						subtitle = this.configValue.languages_labels[display_lang][show.subtitle_languages[i]];
						if (subtitle) {
							subtitleArray.push(subtitle);
						}
					}
					this.card_subtitle = subtitleArray.length > 0 ? subtitleArray.toString() : null ;
					}
			     }
					}
				}
			}
			public hideCardDetails() {
				this.cardDetails = false;
			}

			public videoViewClickEvents() {
				let langObj, userAccessType, tvshowcategory, business_type;
                langObj = this.gtm.displayContentLan();
                userAccessType = this.commonService.getUserAccessType();
                tvshowcategory = this.show.tvshow_details ? this.show.tvshow_details.asset_subtype : '';
                if (this.show.business_type) {
                	if (this.show.business_type.indexOf('premium') !== -1) {
                		business_type = 'premium';
                	} else {
                		business_type = 'Free';
                	}

                } else {
                	business_type = this.notAvailable;
                }
                this.videoViewEvents = {
	                'TopCategory' : this.videoAnalyticsService.getTopCategory(this.show.asset_subtype),
	                'Video_Language' : this.commonService.getVideoLanguages(this.show) || this.notAvailable,
	                'Content_ID': this.show.id || this.notAvailable,
	                'Show_ID': (this.show.asset_type === 1 ? (this.show.tvshow_details ? this.show.tvshow_details.id : '') : this.show.id) || this.notAvailable,
	                'Season_ID': this.show.season_details ? this.show.season_details.id : this.notAvailable,
	                'ShowSubtype': this.show.asset_type === 0 ? this.show.asset_subtype || this.notAvailable : ((this.show.asset_type === 1 && this.show.tvshow_details) ? this.show.tvshow_details.asset_subtype || this.notAvailable : this.notAvailable),
			        'Content_Lang': langObj.contentLang,
			        'Display_Lang': langObj.displayLang,
			        'Business_Type': (this.show.business_type && this.show.business_type.indexOf('premium') !== -1) ? 'Premium' : 'Free' || this.notAvailable,
			        'User_Access_Type': userAccessType,
			        'G_ID': this.gtm.fetchToken(),
			        'Client_ID': this.gtm.fetchClientId(),
			        'TimeHHMMSS': this.gtm.fetchCurrentTime(),
			        'DateTimeStamp': this.gtm.fetchCurrentDate()
                };

			}

			public threeDotEvent(ctadetails) {
				let langObj, availableChannelOriginal;
                langObj = this.gtm.displayContentLan();
                availableChannelOriginal = (this.show.channels && this.show.channels !== (null && undefined) && this.show.channels.length > 0) ? this.show.channels.map(function(elem) {return elem.original_title; }).join(', ') : this.notAvailable;
				return {
			    'event': 'buttonClicks',
                'PageName': this.gtm.getPageName(),
                'UserType': this.token ? 'loggedin' : 'guest',
                'ContentLang': langObj.contentLang,
				'DisplayLang': langObj.displayLang,
				'NetworkType': '',
			    'GoogleID': this.gtm.fetchToken(),
				'cta': ctadetails,
				'VideoName': this.show.original_title ? this.show.original_title : this.notAvailable,
				'VideoCategory': this.show.genres ? this.show.genres.map(function(elem) {return elem.id; }).join(', ') : this.notAvailable,
				'VideoSection': this.videoService.getVideoSection(this.show.asset_type, this.show.asset_subtype) || this.notAvailable,
			    'VideoSubTitle': this.show.original_title ? this.show.original_title : this.notAvailable,
			    'TVChannels': availableChannelOriginal || this.notAvailable,
				'VideoDuration': this.show.duration || 0,
				'VideoStartTime': this.show.start_time ? this.show.start_time : this.notAvailable ,
				'Time_Slot': this.show.time_slot || this.notAvailable,
				'Episode_Number': this.show.index ? this.show.index : this.notAvailable,
				'Tumbnail_Image': this.image_url,
			    'Content_Specification': this.videoService.getContentSpec(this.show.asset_subtype) || this.notAvailable,
				'Content_Show': this.show.original_title || this.show.title || this.notAvailable,
				'Content_Date': this.commonService.dateChange(this.show.release_date) || this.notAvailable,
				'Vertical_Index': this.yIndex || (this.yIndex !== 0 ? this.notAvailable : this.yIndex),
				'Horizontal_Index': this.xIndex || (this.xIndex !== 0 ? this.notAvailable : this.xIndex),
				'SubCategory': this.GAsubCategory || this.notAvailable,
				'modelName': this.modelname || this.notAvailable,
				'clickID': this.show.clickID || this.notAvailable,
				'Click_Metrics': '1',
				'Carousal_Name': this.GAsubCategory || this.notAvailable
				};
			}

			public ngOnDestroy() {
				this.ngUnsubscribe.next();
				this.ngUnsubscribe.complete();
				this.isNewsPage = false;
				this.isTvcategory = false;
				this.isMoviePage = false;
			}
			/* Function to translate day and month */
		    private getDateTranslate(date) {
		        let dateString;
		        dateString = (new Date(date)).toString().toUpperCase();
		        return this.translate.instant('TVGUIDE.' + dateString.split(' ')[1]) + ' ' + dateString.split(' ')[2] + ', ' + dateString.split(' ')[3]; // translate day eg: Mon, Tue, Wed, ...
		    }

		    ////changing ageratings to number function//////
		    private ageratefunction(): any {
       let localcountyCode, configCountries;
          localcountyCode = this.settingsService.getCountry();
          // console.log(localcountyCode);
          configCountries = this.configValue && this.configValue.AgeDisplay && this.configValue.AgeDisplay.countries ? this.configValue.AgeDisplay.countries : [];
      for (let i = 0; i < configCountries.length; i++) {
        let enableflag;
       if (this.configValue.AgeDisplay && this.configValue.AgeDisplay.enable !== null && this.configValue.AgeDisplay.enable !== undefined ) {
          enableflag = this.configValue.AgeDisplay.enable;
           if (enableflag) {
                if (localcountyCode === configCountries[i] || configCountries.length === 0 ) {
                  this.agetake = enableflag;
                   break;
                 } else {
                  this.agetake = false;
                 }
           } else {
              if (localcountyCode === configCountries[i] || configCountries.length === 0) {
                this.agetake = enableflag;
                 break;
               } else {
                this.agetake = enableflag;
               }
           }
         } else {
            this.agetake = false;
         }
       }
}
		}
