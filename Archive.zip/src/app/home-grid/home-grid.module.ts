import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeGridComponent } from './home-grid.component';
import { SharedModule } from '../shared.module';
import { MdMenuModule } from '@angular/material';
import { ShareoptionsModule } from '../share-options/share-options.module';

@NgModule({
  imports: [CommonModule, SharedModule, MdMenuModule, ShareoptionsModule],
  declarations: [HomeGridComponent],
  exports: [HomeGridComponent]
})
export class HomeGridModule {
}
