import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { VideoComponent } from './video.component';
// import { ToggleModule } from './toggle/toggle.module';
import { ToggleComponent } from './toggle/toggle.component';
import { RailsModule } from './rails/rails.module';
import { SharedModule } from '../shared.module';
import { DeviceCheckModule } from '../device-check/deviceCheck.module';
import { ShareoptionsModule } from '../share-options/share-options.module';
import { ReminderSignupModule } from '../reminder-signup/reminder-signup.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    DeviceCheckModule,
    ShareoptionsModule,
    ReminderSignupModule,
    RailsModule
  ],
  declarations: [VideoComponent, ToggleComponent],
  exports: [VideoComponent, ToggleComponent]
})
export class VideoModule { }



