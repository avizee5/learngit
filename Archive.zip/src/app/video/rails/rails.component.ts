import { Component, OnInit, Input, ViewChild, ElementRef, Output, EventEmitter, OnDestroy} from '@angular/core';
import * as $ from 'jquery';
import { environment } from '../../../environments/environment';
import { GoogleAnalyticsService } from '../../services/google-analytics.service';
import { isPlatformBrowser } from '@angular/common';
import { Inject, PLATFORM_ID } from '@angular/core';
import { VideoService } from '../../services/video.service';
import { CommonService } from '../../services/common.service';

@Component({
  selector: 'app-rails',
  templateUrl: './rails.component.html',
  styleUrls: ['./rails.component.less']
})

export class RailsComponent implements OnInit, OnDestroy {
  @Input() public arrayList: any;
  @Input() public screen: any;
  @Input() public countDown: any;
  @Input() public gaVideoDetails: any = {};
  @ViewChild('list') public element_select: ElementRef;
  @ViewChild('parentList') public element_parent: ElementRef;
  @ViewChild('child') public element_child: ElementRef;
  @Output() public close = new EventEmitter<any>();

  public count: any;
  public arrows: any;
  public gridWidth: any;
  public containerWidth: any;
  public scrollEnable: any = false;
  public gridTitle: any;
  public window: any;
  public navigator: any;
  public index_limit: any = 4;
  public pageSize: any = 4;
  public totalPages: any;
  public currentPage: any = 1;
  public currentPosition: any = 4;
  public updatedArray: any;
  public isDesktop: any = true;
  public assetBasePath = environment.assetsBasePath;
  @Output() public onChange = new EventEmitter<any>();
  public percent: any = 0;
  public right_arrow: any = true;
  public left_arrow: any = false;
  public pagecount: any;
  private scrollTimeout: any;
  private previous_index: any;
  // public countDownInterval: any;
  public collectionId: any;
  constructor(@Inject(PLATFORM_ID) private platformId: Object, private gtm: GoogleAnalyticsService, private videoService: VideoService, private commonService: CommonService) { }
  // public ngOnChanges (changes: any): void {
    // if (changes['arrayList'] && changes['arrayList'].previousValue !== changes['arrayList'].currentValue) {
    //   if (isPlatformBrowser(this.platformId)) {
    //     this.window = window;
    //     this.navigator = navigator;
    //   }
    //   this.pageSize = 4;
    //   this.currentPosition = 4;
    //   if (this.arrayList.content && this.arrayList.content.length > 0) {
    //     this.totalPages = Math.ceil(this.arrayList.content.length / this.pageSize);
    //   }
    //   if (this.arrayList.content) {
    //     if (this.arrayList.content.length < this.pageSize + 1 || this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
    //       this.arrows = false;
    //     } else {
    //       this.arrows = true;
    //       this.isDesktop = true;
    //     }
    //     if ( this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
    //       this.isDesktop = false;
    //     } else {
    //       this.isDesktop = true;
    //     }
    //     if (this.isDesktop === false) {
    //       if (this.updatedArray === undefined || this.updatedArray == null ) {
    //         this.updatedArray = this.arrayList.content.slice(0, this.pageSize);
    //       }
    //     }
    //     if (this.window.innerWidth > 768) {
    //       this.index_limit = this.pageSize + 1;
    //     }
    //     this.setContainerWidth();
    //   }
    //   this.collectionId = this.commonService.getCollectionId();
    // }
  // }
  public ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.window = window;
      this.navigator = navigator;
    }
    setTimeout(() => {
      this.gtm.storeWindowError();
    }, 0);
    // this.countDownInterval = setInterval(() => {
    //   if (this.countDown > 0) {
    //     this.countDown--;
    //   } else {
    //     clearInterval(this.countDownInterval);
    //   }
    //   // if (this.countDown <= 0) {
    //   //   this.close.emit('resize');
    //   // }
    // }, 1000);
    this.arrayList.pageNo = 1;
    if (this.arrayList.title) {
      this.gridTitle = this.arrayList;
    } else {
      this.gridTitle = '';
    }
    this.pageSize = 4;
    this.currentPosition = 4;
    if (this.arrayList.content && this.arrayList.content.length > 0) {
      this.totalPages = Math.ceil(this.arrayList.content.length / this.pageSize);
    }
    if (this.arrayList.content) {
      this.count = 0;
      this.arrows = true;
      this.pagecount = 4;
      if (this.arrayList.content.length < this.pageSize + 1 || this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
        this.arrows = false;
      } else {
        this.arrows = true;
      }
      if ( this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
        this.isDesktop = false;
      } else {
        this.isDesktop = true;
      }
      this.updatedArray = this.arrayList.content.slice(0, this.pageSize);
      if (this.window.innerWidth > 768) {
        this.index_limit = this.pageSize + 1;
      }
      if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
        this.scrollEnable = true;
      }
      this.setContainerWidth();
    }
    // if (this.arrayList.content) {
    //   this.count = 0;
    //   this.arrows = true;
    //   this.pagecount = 4;
    //   if (this.arrayList.content.length < this.pagecount + 1 || this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
    //     this.arrows = false;
    //   } else {
    //     this.arrows = true;
    //   }
    //   this.updatedArray = this.arrayList.content.slice(0, 4);
    //   if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
    //     this.scrollEnable = true;
    //   }
    //   this.setContainerWidth();
    // }
    this.collectionId = this.commonService.getCollectionId();
  }

  public dismiss(event: any, index: any): void {
    if (event.type === 'missing') {
       this.arrayList.content = this.arrayList.content.filter(function(el) {
        return el.id !== event.id;
      });
      this.updatedArray = [];
      this.updatedArray = this.arrayList.content.slice(0, 4);
    } else {
      this.onChange.emit(event);
    }
    let scope;
    scope = this;
    setTimeout(function() {
      if (event.type !== 'missing' && (scope.arrayList.content.length - index) <= 4 && index > 3) {
        scope.count += 25;
        scope.element_select.nativeElement.style.marginLeft = scope.count + '%';
      } else if (event.type !== 'missing' &&  scope.arrayList.content.length <= 4 && scope.arrayList.content.length) {
        scope.count = 0;
        scope.element_select.nativeElement.style.marginLeft = scope.count + '%';
        scope.arrows = false;
      }
      scope.onResize('event');
    }, 200);
  }
  public previous(): void {
    if (this.count < 0) {
      this.currentPosition--;
      this.count += 25;
      if (this.count + 25 === 25 && this.arrayList.content.length === this.pagecount + 1) {
        this.right_arrow = true;
        this.left_arrow = false;
      } else if (this.count + 25 === 25 && this.arrayList.content.length !== this.pagecount + 1) {
        this.right_arrow = true;
        this.left_arrow = false;
      } else if (this.count < - (this.arrayList.content.length - this.pagecount) * 25 + 50) {
         this.right_arrow = true;
      }
      this.element_select.nativeElement.style.marginLeft = (this.count * 23.525 / 25) + '%';
    }
    // console.log(this.count, 'previous', this.count / 25) // ignore -ve sign
    let items;
    items = this.window.innerwidth < 768 ? 2 : 4;
    this.sendGAscrollevent((this.currentPosition - (items - 1)), 'right');
  }
  public next(): void {
    if ((this.currentPage < this.totalPages - 1 ) && (this.currentPosition % this.pagecount === 0)) {
      this.currentPage ++;
      this.updateArray();
    } else if (this.currentPage === this.totalPages - 1) {
      this.currentPage ++;
      this.updateArray();
    }
    if (this.count >= - (this.arrayList.content.length - this.pagecount) * 25 + 25) {
      let last;
      this.currentPosition ++;
      this.count -= 25;
      if (this.count === -25 && this.arrayList.content.length === this.pagecount + 1) {
        this.left_arrow = true;
        this.right_arrow = false;
      } else if (this.count === -25 && this.arrayList.content.length !== this.pagecount + 1) {
       this.left_arrow = true;
      } else if ( this.count <= -(this.arrayList.content.length - this.pagecount) * 25 ) {
        last = true;
        this.right_arrow = false;
      } this.element_select.nativeElement.style.marginLeft = this.count + '%';
      if (last) {
        this.element_select.nativeElement.style.marginLeft = ((this.count * 23.525 / 25) + (23.525 / this.pagecount)) + '%';
      } else {
        this.element_select.nativeElement.style.marginLeft = (this.count * 23.525 / 25) + '%';
      }
    }
    // console.log(this.count, 'next', (this.count / 25) - 4) // ignore -ve sign
    this.sendGAscrollevent(this.currentPosition, 'left');
  }

  public scrollData(event: any) {
    let fetchdetailPercentage;
    fetchdetailPercentage = 0.625;
    if (this.element_parent.nativeElement.scrollLeft  >=  (fetchdetailPercentage * (this.element_parent.nativeElement.scrollWidth * (this.index_limit / this.arrayList.content.length) - this.element_parent.nativeElement.clientWidth))) {
      if (this.index_limit < this.arrayList.content.length) {
        if ((this.currentPage < this.totalPages - 1 ) && (this.currentPosition % 4 === 0)) {
          this.currentPage ++;
        } else if (this.currentPage === this.totalPages - 1) {
          this.currentPage ++;
        }
        this.updateArray();
        this.setContainerWidth();
      }
    }
    this.detectScrollEnd(this.element_parent.nativeElement, this.element_child.nativeElement);
  }

  private detectScrollEnd(parent, child): any {
    if (this.scrollTimeout) {
      clearTimeout(this.scrollTimeout);
    }
    this.scrollTimeout = setTimeout(() => {
      let index, items, direction;
      index = Math.floor((parent.scrollLeft + parent.clientWidth) / child.clientWidth);
      if (!this.previous_index) {
        this.previous_index = this.window.innerWidth < 768 ? 2 : 4;
      }
      if (index > this.previous_index) {
        direction = 'left';
      } else {
        direction = 'right';
      }
      this.previous_index = index;
      items = (this.window.innerWidth < 768) ? 2 : 4;
      index = (direction === 'right') ? (index - (items - 1)) : index;
      this.sendGAscrollevent(index, direction);
    }, 1000);
  }

  private sendGAscrollevent(index, direction): any {
    let details;
    details = {
      'event': direction === 'right' ? 'videoScrollRight' : 'videoScrollLeft',
      'video_index': (index < 1) ? 1 : index,
      'collection_id': this.commonService.getCollectionId() || 'NA'
    };
    details = $.extend({}, this.gaVideoDetails, details);
    this.videoService.googleAnalyticPost(details, '', {});
  }

  public updateArray() {
    if (!this.isDesktop) {
      let item;
      item = this.arrayList.content.slice(this.index_limit, (this.index_limit + 4));
      if (item) {
        for (let index = 0; index < item.length ; index ++) {
          this.updatedArray.push(item[index]);
        }
        this.index_limit = this.index_limit + 4;
      }
    } else {
     this.index_limit = this.index_limit + 4;
    }
  }

  public setContainerWidth(): any {
      if (this.window.innerWidth > 768) {
        this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
        this.containerWidth = 25 * this.arrayList.content.length * 0.941;
      } else if (this.window.innerWidth <= 768 && this.window.innerWidth > 480) {
        this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
        this.containerWidth = 25 * this.arrayList.content.length * 1.5;
      } else if (this.window.innerWidth <= 480) {
        if (this.arrayList.content.length !== 1) {
        this.gridWidth = (( 4 * 25) / this.arrayList.content.length);
        } else {
          this.gridWidth = 10;
        }
        if (this.isDesktop === true) {
          this.containerWidth = 25 * this.arrayList.content.length * 2.75;
        } else {
          this.containerWidth = 25 * this.arrayList.content.length * 1.75;
        }
      }
  }

  public onResize(event: any): void {
    if (this.arrayList.content.length < this.pageSize + 1 || this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
      this.arrows = false;
    } else {
      this.arrows = true;
    }
    if (this.window.innerWidth > 768 && this.index_limit === this.pagecount) {
      this.index_limit = this.pagecount + 1;
    }

    this.setContainerWidth();
  }

  public watchCredits(event): any {
    event.stopPropagation();
    // GA event
    this.close.emit('watchCredits');
  }

  public ngOnDestroy(): any {
    // on Destroy
    if (this.scrollTimeout) {
      clearTimeout(this.scrollTimeout);
    }
    // if (this.countDownInterval) {
    //   clearInterval(this.countDownInterval);
    // }
  }

}
