import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RailsComponent } from './rails.component';
import { SharedModule } from '../../shared.module';
import { HomeGridModule } from '../../home-grid/home-grid.module';


@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    HomeGridModule
  ],
  declarations: [RailsComponent],
  exports: [RailsComponent]

})
export class RailsModule {
}

