import { Component, OnInit, Input } from '@angular/core';

import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';

@Component({
  selector: 'app-toggle',
  templateUrl: './toggle.component.html',
  styleUrls: ['./toggle.component.less']
})
export class ToggleComponent implements OnInit {

  @Input() public enabled: any;
  constructor(@Inject(PLATFORM_ID) private platformId: Object) { }

  public ngOnInit() {
  	// init function call
  }

}
