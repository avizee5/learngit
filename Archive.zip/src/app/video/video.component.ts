import { Component, OnInit, Input, HostListener, OnDestroy, OnChanges, Output, EventEmitter, ViewChild, ElementRef} from '@angular/core';
// declare let jwplayer: any;
declare let KalturaPlayer: any;
declare let RadiantMP: any;
import * as $ from 'jquery';
import { Subscription } from 'rxjs/Subscription';
import { Subject } from 'rxjs/Subject';
import { Http } from '@angular/http';

import { EpgService } from '../services/epg.service';
import { VideoAnalyticsService } from '../services/video-analytics.service';
import { VideoService } from '../services/video.service';
import { UserProfileService } from '../services/user-profile.service';
import { HeaderservicesService } from '../services/headerservices.service';
import { SettingsService } from '../services/settings.service';
import { NetworkService } from '../services/network.service';
import { UseractionapiService } from '../services/useractionapi.service';
import { DeviceApiService } from '../services/device-api.service';
import {CommonService} from '../services/common.service';
import {LotameService} from '../services/lotame.service';

import {FavoritesApi, WatchHistoryApi, WatchlistApi } from '../../data/user/api/api';
import { SubscriptionService } from '../services/subscription.service';
import {environment} from '../../environments/environment';
import 'rxjs/add/operator/timeout';
import 'rxjs/add/operator/takeUntil';
import { LinkService } from '../services/link.service';
import { RouteService } from '../services/route.service';
import { TranslateService} from '@ngx-translate/core';

import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';

// declare const moatjw;
declare const qg;
declare let cast: any;
// declare let zee5Touch: any;
// declare let destroyCBplugin: any;
const noNetworkText = 'MESSAGES.NETWORK_ERROR'; // 'Please check your network connection and retry!'
const noUrlText = 'MESSAGES.NO_DATA'; // 'No data available'
// const tryAgainMessage = 'PLAYER.TRY_AGAIN' // 'Sorry, something went wrong while playing the video. Please try again.'
const tryAgainMessage = 'MESSAGES.TIMEOUT_ERROR'; // 'Sorry, something went wrong, please try again.'
const sorryError = 'MESSAGES.TIMEOUT_ERROR'; // 'Sorry, something went wrong, please try again.'
const timeLimit = 'DEVICE_MANAGMENT.DEVICE_TIME'; // 'Sorry! Any device can be added only once in 24 hours'
const deviceLimit = 'DEVICE_MANAGMENT.DEVICE_REMOVE'; // 'Your device limit is reached. Do you want to add this device and remove one of your other devices ?
const fallbackBasepath = environment.aesBasePath;
const adBaseUrl = environment.videoAdBasePath;
const adBaseUrlMobile = environment.videoAdBasePathMobile;
const newsAdBaseUrl = environment.videoNewsAdBasePath;
const newsAdBaseUrlMobile = environment.videoNewsAdBasePathMobile;
const liveAdBaseUrl = environment.videoLiveAdBasePath;
const liveAdBaseUrlMobile = environment.videoLiveAdBasePathMobile;
const akamaiBasePath = environment.videoBasePath;
const keyCodes = {
  spaceBar : 32,
  arrowLeft : 37,
  arrowUp : 38,
  arrowRight : 39,
  arrowDown : 40,
  letterM : 77,
  letterF : 70,
  backSpace : 8,
};
// const showCredits = 5; // in seconds
// const controlsVisibleTime = 5000;
const epgAssetType = 10;
// const watchDurationTime = 15; // seconds
// const watchDurationTimeOnAir = 60; // seconds
const defaultContinueWatchingTime = 60; // seconds
const retryCount = 1; // seconds
const defaultImageInterval = 10; // seconds
const defaultVttVideoMinLength = 300; // seconds
const signup_event_delay = 60; // seconds
const playerKey = 'amx0anV3dG95YkAxNjAzNzc0'; // new production license
// const playerKey = 'Y21zZ2Vpc29zbyEqXyUxdnYyNzk/cm9tNWRhc2lzMzBkYjBBJV8q'; // zee5.tv
// const playerKey = 'Y21zZ29ta29tayEqXyUxdnYyeWVpP3JvbTVkYXNpczMwZGIwQSVfKg=='; // zee5.com
@Component({
  selector: 'app-video',
  templateUrl: './video.component.html',
  styleUrls: ['./video.component.less']
})

export class VideoComponent implements OnInit, OnDestroy, OnChanges {
  @Input() public pausevideo: any;
  @Input() public autoplay_episode: any = false;
  @Input() public videoObject: any;
  @Input() public videoIsLive: any = false;
  @Output() public update = new EventEmitter<boolean>();
  @Input() public showPage: any = false;
  @Input() public videoAdData: any;
  @Output() public playerRead = new EventEmitter<boolean>();
  @Output() public premiumParent = new EventEmitter<boolean>();

  @ViewChild('backgroundImage') public image_container: ElementRef;
  @ViewChild('thumbnailImage') public thumbnail_container: ElementRef;
  public continueWatchingTime: any;
  private showCredits: any = 5; // in seconds
  private controlsVisibleTime: any = 5000;
  private contentUrl: any;
  public retryCounter: any = retryCount;
  public drmRetry: any = 1;
  public currentAdId: any;
  public player_play = environment.assetsBasePath + 'assets/player_icons/ic_play.svg';
  public player_pause = environment.assetsBasePath + 'assets/player_icons/ic_pause.svg';
  public previous_icon = environment.assetsBasePath + 'assets/player_icons/ic_previous.svg';
  public next_icon = environment.assetsBasePath + 'assets/player_icons/ic_next.svg';
  public play = environment.assetsBasePath + 'assets/player_icons/player_icons.svg#play_icon-view';
  public pause = environment.assetsBasePath + 'assets/player_icons/player_icons.svg#pause_icon-view';
  public castIcon = environment.assetsBasePath + 'assets/player_icons/player_icons.svg#cast_icon-view';
  public more = environment.assetsBasePath + 'assets/player_icons/player_icons.svg#more_icon-view';
  public rewind10 = environment.assetsBasePath + 'assets/player_icons/player_icons.svg#rewind_icon-view';
  public forward10 = environment.assetsBasePath + 'assets/player_icons/player_icons.svg#forward_icon-view';
  public settings = environment.assetsBasePath + 'assets/player_icons/player_icons.svg#quality_icon-view';
  public cc = environment.assetsBasePath + 'assets/player_icons/player_icons.svg#CC_icon-view';
  public full_volume_icon = environment.assetsBasePath + 'assets/player_icons/player_icons.svg#full_volume_icon-view';
  public volume_icon = environment.assetsBasePath + 'assets/player_icons/player_icons.svg#volume_icon-view';
  public mute_icon = environment.assetsBasePath + 'assets/player_icons/player_icons.svg#mute_icon-view';
  public volumeIcon: any;
  public expand_screenIcon = environment.assetsBasePath + 'assets/player_icons/player_icons.svg#expand_screen_icon-view';
  public collapse_screenIcon = environment.assetsBasePath + 'assets/player_icons/player_icons.svg#collapse_screen_icon-view';
  public back_menu = environment.assetsBasePath + 'assets/player_icons/player_icons.svg#back_icon-view';
  public next_menu = environment.assetsBasePath + 'assets/player_icons/player_icons.svg#next_icon-view';
  public selection_tick_menu = environment.assetsBasePath + 'assets/player_icons/player_icons.svg#selection_tick_icon-view';
  public shareIcon = environment.assetsBasePath + 'assets/player_icons/player_icons.svg#share_icon-view';
  public favIcon = environment.assetsBasePath + 'assets/player_icons/player_icons.svg#fav_icon_normal-view';
  public watchLaterIcon = environment.assetsBasePath + 'assets/player_icons/player_icons.svg#watch_later_icon_normal_icon-view';
  public favIconSelected = environment.assetsBasePath + 'assets/player_icons/player_icons.svg#fav_icon_selected-view';
  public watchLaterIconSelected = environment.assetsBasePath + 'assets/player_icons/player_icons.svg#watch_later_icon_selected_icon-view';
  public loader = environment.assetsBasePath + 'assets/common/loading.gif';
  public replay_icon = environment.assetsBasePath + 'assets/player_icons/ic_replay.svg';
  // public replay_icon = environment.assetsBasePath + 'assets/player_icons/player_icons.svg#replay_icon-view';
  public defaultImage = environment.assetsBasePath + 'assets/default/popular.png';
  public fullscreenIcon = environment.assetsBasePath + 'assets/player_icons/player_icons.svg#ic_expand-view';
  public tooltip_thumbnail: any = environment.assetsBasePath + 'assets/default/tvshow.png';
  public defaultThumbnailImage: any = environment.assetsBasePath + 'assets/default/tvshow.png';

  public player: any;
  public resourceUrl: any;
  public resourceUrlConviva: any;
  public currentTime: any = '00:00';
  public totalTime: any = '00:00';
  public currentTimePercent: number;
  public totalTimeMS: number;
  public volume: number;
  public volumeBefore: any = 0.5;
  public bufferValue: number;
  public playPause: string;
  public screenIcon: string;
  public captionLanguages: any;
  public audioLanguages: Array<any> = [];
  public selectedAudioString: any;
  public jwAudioLanguageString: Array<any> = [];
  public seekEvent: any;
  public isSeeking: any = false;
  public controlsTimer: any;
  public videoDiv: any;
  public forward1: any;
  /*Control Menu Flags*/
  public autoplay: boolean;
  public enableAutoplay: any = false;
  public showMovieRails: any = false;
  public subtitleState: any = false;
  public settingsOpen: any = false;
  public audioMenu: any = false;
  public qualityMenu: any = false;
  public mainSettingsMenu: any = false;
  public ccOpen: any = false;
  /*Control Menu Flags*/

  /* Control Menu Variables*/
  public ccPlayerText: string;
  public selectedAudio: string;
  public selectedQuality: any = 'High';
  public selectedBitrate: string;
  public subtitleStateText: string;
  public selectedCC: string;
  /* Control Menu Variables*/

  public mediaProfiles: Array<any> = [];
  public buffering: boolean;
  public hasClosedCaptions: any = 'hidden';

  /*controls modification based on selection*/
  public videoType: any = 'Vod';
  public castEnabled: any = 'CastDisabled';
  public moreVisible: any = 'hidden';

  public drm: any;
  public drmFlag: boolean;
  private drmDeviceInfo: any;

  public adOffsets: any = [];
  public adVisible: any = false;
  public adPoints: any = [];
  public enablePlayback: any = false;
  public replay: any = false;
  public currentTimeSec: number;

  public settingLength: any = 'hidden';
  public playlist: any;
  public playerMediaObj: any;
  public precisionAPI: any;
  public error: any = false;
  public customData: any;

  public watchHistoryApi: any;
  public watched: any = false;
  public favorite: any = false;
  public watchedShow: any;
  public titleText: string;
  public touchScreen = false;
  public cdnData: any;
  public videoToken: any;
  public showShare: any = '';
  public showshare: any = false;
  public shareUrl: any;
  public advertisement: any;
  public inHistory: any = false;
  public updatedHistoryTime: any;
  public deletedInHistory: any = false;
  public unsupported: any = false;
  public errorMsg: string;
  public streamProtocol: any;
  public gaWatchPercent: any = 0;
  public seekSliderStart: number;
  public seekSliderEnd: number;

  public reminderText: any; // let for reminder pop up
  public typeofpopup: any;
  public showSignUpPromt: any;
  public moreType: any = 'Vod';
  public mobile: any;
  public languages: any;
  public subtitles: any;
  public seekStartTime: any;
  public seekStart: any;
  public seekEnd: any;

  public token: any;
  public params: any;
  public configUser: any;
  public recoConfig: any;
  public drmBasePath: any;
  private ngUnsubscribe = new Subject<any>();
  public postHistoryAPI: Subscription;
  public putHistoryAPI: Subscription;
  public deleteHistory: Subscription;
  public background: any;
  public showBackgroundImage: any = true;
  public ebvs: any = true;
  public canonical: any;
  public browser: any;
  public selectedAudioqg: any;
  public androidORiOS: any;
  // public passedGAWatchDuration: any = 0;
  public previousTime: any = 0;
  public gaCounter: any = 0;
  // public Yposition: number;
  public startPlayback: any = true;
  public unsupportederrorMsg: any;
  public tryagain: any = false;
  public unknownSubtitleCounter: any = 0;
  public unknownAudioCounter: any = false;
  public browser_timer_flag: any = false;
  public window: any;
  public navigator: any;
  public localStorage: any;
  public document: any;
  public expand_screen: any;
  public muteLaunch: any = false;
  public mobile_UC = false;
  public xiaomi = false;
  public browserUnSupported: any = false;
  public originalDrm: any;
  public configData: any;
  public notAvailable: any = 'NA';
  public videoItemforGA: any;
  public gaSubCategory: any;
  public userAccessType: any;
  public networkStatus: any;
  public launchButton: any;
  public condition_show_DownloadApp: any;
  public downloadApp: any;
  public networkErrPosition: any;
  public resetDevicePopup: any = false;
  public deviceList: any;
  public signup_counter = 0;
  public videoViewCounter: number;
  public videoViewBuffer: number;
  public browser_timer: number;
  public country: any;
  public countryListData: any;
  public countrycodeIndex: number;
  public playAES: any;
  public qgraph: any;
  public gaFirstAPIAudioLang: any;
  public audioLangsString: any; // comma seperated audio languages string
  // public watchDurationInterval: any;
  public peer5enabled: any = false;
  public checkMoat: any = false;
  public checkfocus: any = false;
  public showPopUpOnComplete: any = false;
  public thumbnail_data: any;
  public thumbnailTime: any;
  public thumbnailTimeSec: any;
  public thumbnailUrl: any;
  public popUpFromHeader: any = false;
  private videoPaused: any = false;
  private pausedByUser: any = false;
  // skip intro variables
  public showSkipIntro: any = false;
  public showSkipRecap: any = false;
  public skipIntroStart: any;
  public skipIntroend: any;
  public skipRecapStart: any;
  public skipRecapEnd: any;
  public currenttimeIntro: any;
  private contentPopup = false;
  public contentLangPopup = false;
  public userId: any;
  public showWaterMark: any = false;
  private historyRetryCount = 1;
  private apiRetry = 2;
  public prevData: any;
  public nextData: any;
  public showPlayerControls: any = true;
  // new autoplay
  public showRails: any = false;
  public endCreditsStart: any;
  public showCountdownTimer: any = false;
  public showWatchCredits: any = false;
  public railData: any = {};
  public watchCreditsClick: any =  false;
  public countDown: any;
  public assetbasepath: any;
  // Forward Rewind variables
  public count: any = 0;
  public forwardRewind: any;
  public displayFRTime: any = 300;
  public forwardImg = false;
  public rewindImg = false;
  public forwardValue: any;
  public rewindValue: any;

  public isLastFiveSec: any = false;
  private nextPlayTimeout: any;
  private countDownInterval: any;
  private startAutoplayTimer: any = false;
  public searchOpen: any = false;
  public parentalControls: any = false;
  public playerInstance: any;
  public adDetails: any;
  private fullscreenFromAd: any = false;
  private adTimeStamp: any;

  private talamoosData: any;
  public contentText: any;
  private clickDetails: any;
  private recoWatchHistoryApi: any;
  private recoInHistory: any;
  private recoPostHistoryAPI: any;
  private recoPutHistoryAPI: any;
  private updatedRecoHistoryTime: any;

  private videoCompleted: any;
  private imageInterval: any;
  private vttVideoMinLength: any;

  private showVideoViewSignup: any;
  private signUp_event_delay: any;
  private recoDmpSync: any = false;

  private pageX: any;
  private routeStartPoint: any;

  private playerState: any;
  private kalturaUiState: any = false;

  public iOSDevice: any = false;
  private playerContainer: any = false;
  private initializeAfterDestroy: any = false;

  public triggerPlayback: any = false;
  public playerCalledOnLaunch: any = false;

 constructor(
   @Inject(PLATFORM_ID) private platformId: Object,
   private routeservice: RouteService,
   private linkservice: LinkService,
   private sub: SubscriptionService,
   private userapiService: UseractionapiService,
   private networkService: NetworkService,
   private deviceApi: DeviceApiService,
   private epg: EpgService,
   private settingsService: SettingsService,
   private headerService: HeaderservicesService,
   private videoAnalyticsService: VideoAnalyticsService,
   private videoService: VideoService,
   private http: Http,
   private userProfile: UserProfileService,
   private lotameService: LotameService,
   private commonService: CommonService,
   private translate: TranslateService) {
    // this.assetbasepath = environment.assetsBasePath;
    this.assetbasepath = environment.assetsBasePath;
    this.headerService.subscribeReminder.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.playerStateOnPopup(value);
      this.popUpFromHeader = value;
    });
    this.headerService.signInReminder.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.playerStateOnPopup(value);
      this.popUpFromHeader = value;
    });
    this.userProfile.favourite.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.favorite = this.userProfile.inList('favorite', this.videoObject[0].id);
    });
    this.userProfile.watchlater.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.watched = this.userProfile.inList('watchList', this.videoObject[0].id);
    });
    this.headerService.contentLanguageValue.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.contentLangPopup = value.boolean;
      this.playerStateOnPopup( value.boolean);
    });
    this.headerService.searchValue.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.searchOpen = value;
      this.playerStateOnPopup(this.searchOpen); // ZFED-13216
    });
    this.headerService.parentalValue.subscribe(value => {
      this.parentalControls = value.flag;
      this.playerStateOnPopup(this.parentalControls);
    });
     // ZFED-13216
    this.headerService.modelValue.takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.playerStateOnPopup(value);
    });
    // ZFED-13216
  }

  public playerStateOnPopup(value: any): any {
    if (!this.player || (this.player && this.getplayerState() === 'idle') || this.error || this.showPopUpOnComplete) {
    // if (!this.player || (this.player && this.player.getState() === 'idle') || this.error || this.showPopUpOnComplete) {
      this.showPopUpOnComplete = false;
      return;
    }
    let popUps;
    popUps = this.headerService.popupsShown();
    if (!popUps) {
      if ((this.getplayerState() === 'paused' || this.getplayerState() === 'buffering') && !this.pausedByUser) {
      // if ((this.player.getState() === 'paused' || this.player.getState() === 'buffering') && !this.pausedByUser) {
          this.pausedByUser = false;
          this.playVideo();
      }
    } else {
      if (!this.adDetails) {
        this.setPlayerControls(false);
      }
      if (this.getplayerState() === 'playing') {
      // if (this.player.getState() === 'playing') {
          this.pauseVideo();
      }
      if (this.getPlayerFullscreen() || this.document.fullscreenElement || this.document.webkitFullscreenElement || this.document.mozFullScreenElement || this.document.msFullscreenElement) {
        this.toggleFullScreen();
      }
    }
  }

  private getPlayerCurrentTime(): any {
    return this.iOSDevice ? Math.round(this.player.getCurrentTime() / 1000) : this.player.currentTime;
  }

  private getPlayerFullscreen(): any {
    return this.iOSDevice ? this.player.getFullscreen() : this.player.isFullscreen();
  }

  private setPlayerControls(display): any {
    if (this.iOSDevice) {
      this.player.setControls(false);
	    // this.player.setControls(display);
    } else {
    	this.kalturaUiState = display;
      let displayType;
      displayType = $('.playkit-playback-gui-wrapper').css('display');
      if (displayType) {
        if (display && displayType === 'none') {
          $('.playkit-playback-gui-wrapper').css('display', 'block');
        } else if (!display && displayType === 'block') {
          // console.log(displayType, 'setPlayerControls - hidden');
          $('.playkit-playback-gui-wrapper').css('display', 'none');
        }
      }
      // $('.playkit-playback-gui-wrapper').css('display', display ? 'block' : 'none');
    }
  }

  private getPlayerControlsState(): any {
    return this.iOSDevice ? this.player.getControls() : this.kalturaUiState;
  }

  // private setPlayerControlsState (): any {
  // }

  public caststatechanged(event): any {
    this.setCastIcon(event.castState);
  }

  public setCastIcon(state): any {
    /* NO_DEVICES_AVAILABLE-NOT_CONNECTED-CONNECTING-CONNECTED*/
    if (state === 'NOT_CONNECTED') {
      this.castEnabled  = 'CastEnabled';
    } else {
      this.castEnabled  = 'CastDisabled';
    }
  }

  public ngOnInit(): any {
    if (isPlatformBrowser(this.platformId)) {
      this.localStorage = localStorage;
      this.window = window;
      this.navigator = navigator;
      this.document = document;
    }
    this.videoService.setTestPage();
    this.playerCalledOnLaunch = this.videoService.getPlayerLaunchStatus();
    this.iOSDevice = this.navigator.platform.match(/(iPhone|iPod|iPad)/i);
    // this.iOSDevice = true;
    // if (this.navigator.platform.match(/(iPhone|iPod|iPad)/i) && this.window.webView) {
    //   this.window.webView.customUserAgent = 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1.2 Mobile/15E148 Safari/604.1';
    // }
    let getservice, ad_end_string;
    getservice = this.headerService.getcontentLanguageChanges();
    ad_end_string = 'PLAYER.AD_END';
    this.translateString(ad_end_string);
    this.contentLangPopup = getservice && getservice.boolean ? getservice.boolean : false;
    this.popUpFromHeader = this.headerService.getSigninreminder() || this.headerService.getSubscribeReminder();
    this.headerService.blockeventsValue.subscribe(value => {
     this.qgraph = this.headerService.getRemarketing();
    });
    this.qgraph = this.headerService.getRemarketing();
    this.networkStatus = this.navigator.onLine ? 'online' : 'offline';
    this.configData = this.settingsService.getCompleteConfig();
    this.continueWatchingTime = (this.configData && this.configData.continue_watching && this.configData.continue_watching.web) ? this.configData.continue_watching.web : defaultContinueWatchingTime;
    this.showCredits = this.configData && this.configData.player_configuration && this.configData.player_configuration.web && this.configData.player_configuration.web.end_credits !== undefined ? this.configData.player_configuration.web.end_credits : this.showCredits; // in seconds
    this.controlsVisibleTime = this.configData && this.configData.player_configuration && this.configData.player_configuration.web && this.configData.player_configuration.web.player_controls !== undefined ? this.configData.player_configuration.web.player_controls : this.controlsVisibleTime; // in milli seconds
    this.checkMoat = (this.configData && this.configData.moatEnable) ? this.configData.moatEnable : false;
    this.imageInterval = (this.configData && this.configData.vtt_thumbnail && this.configData.vtt_thumbnail.web && this.configData.vtt_thumbnail.web.image_interval) ? this.configData.vtt_thumbnail.web.image_interval : defaultImageInterval;
    this.vttVideoMinLength = (this.configData && this.configData.vtt_thumbnail && this.configData.vtt_thumbnail.web && this.configData.vtt_thumbnail.web.video_min_length) ? this.configData.vtt_thumbnail.web.video_min_length : defaultVttVideoMinLength;
    // this.imageInterval = (this.configData && this.configData.thumbnail_image_interval) ? this.configData.thumbnail_image_interval : defaultImageInterval;
    this.signUp_event_delay = this.configData && this.configData.video_view_signup_event_delay && this.configData.video_view_signup_event_delay.web ? this.configData.video_view_signup_event_delay.web : signup_event_delay; // in seconds

    this.setBackgroundImage();
    this.gaSubCategory = this.videoService.getGAsubCategory();
    this.talamoosData = this.commonService.getTalamoosData();
    this.clickDetails = this.videoService.getContentClickDetails();
    this.browser = this.videoService.get_browser();
    if ((this.browser.name.match(/UCBrowser/i) || this.browser.name.match(/UBrowser/i)) && this.navigator.userAgent.match(/mobile|iPhone|iPod|iPad/i)) {
         this.mobile_UC = true;
    }
    if (this.browser.name.match(/MiuiBrowser|XiaoMi/i) && this.navigator.userAgent.match(/mobile|iPhone|iPod|iPad/i)) {
         this.xiaomi = true;
    }
    this.videoService.comScoreFunction();
    this.initializeOnVideoObjectChange();
    this.androidORiOS = this.navigator.userAgent.match(/Android|iPhone|iPad|iPod/i);
    this.checkForAES();
    this.country = this.settingsService.getCountry();
    this.videoService.storeWindowError();
    this.downloadUrl();
    this.titleText = this.videoObject[0].title || 'Not Available';
    // this.titleText = this.videoObject[0].episode_name || this.videoObject[0].title || 'Not Available';
    this.fontResize();
    this.playPause = this.play;
    this.screenIcon = this.expand_screenIcon;
    this.volumeIcon = this.full_volume_icon;
    this.videoDiv = this.document.getElementById('playerListener');
    this.videoService.enableCastView = false;
    if (this.window.innerWidth < 481) {
      this.mobile = true;
    }
    this.expand_screen = this.navigator.userAgent.match(/mobile/i) ? true : false;
    this.touchScreen = this.navigator.userAgent.match(/mobile|Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i) ? true : false;

    /* for reminder pop up */
    $('body').css('pointer-events', '');
    this.reminderText = 'LOGIN.LOGIN_REQUEST';
    this.typeofpopup = 'reminder';
    /* for reminder pop up */
    if (this.unsupported) {
      $(this.document).ready(function() {
        $('#playerOverlay').css('display', 'none');
      });
      return;
    }
    // if ((browser.name === 'Chrome' || browser.name === 'CriOS') && browser.version > 50) {
    if ((this.browser.name === 'Chrome' || this.browser.name === 'CriOS') && this.browser.version > 50 && this.window.cast && this.window.cast.framework && cast && cast.framework) {
      this.setCastIcon(cast.framework.CastContext.getInstance().getCastState());
      cast.framework.CastContext.getInstance().addEventListener(cast.framework.CastContextEventType.CAST_STATE_CHANGED, this.caststatechanged.bind(this));
    }
    $('#playerOverlay').css('display', 'block');
    this.controlsSetup();
    this.fetchConfig();
    // this.videoAnalyticsService.init();
    $('#PlayerContainer').css('pointer-events', 'none');

    this.autoplay = this.videoService.autoPlay;
    if (this.videoObject[0].asset_type === epgAssetType || this.videoObject[0].type === 'live' || this.videoObject[0].asset_type === 9) {
      this.moreType = 'Live';
      this.autoplay = true;
    }
    this.selectedBitrate = this.videoService.bitRate;
    this.fontResize();
    if (this.videoIsLive) {
      this.moreType = 'Live';
      this.videoType = 'Live';
    }
    this.token = this.localStorage.getItem('token');
    if (this.token)  {
      this.userId = this.localStorage.getItem('ID');
    }

    this.params = 'bearer ' + this.token;
    let guestToken;
    guestToken = this.localStorage.getItem('guestToken');
    if (this.token) {
      this.configUser = {
        apiKey: this.params,
        username: ' ',
        password: ' ',
        accessToken: ' ',
        withCredentials: false
      };
      this.recoConfig = {
        apiKey: localStorage.getItem('ID'),
        username: ' ',
        password: ' ',
        accessToken: '',
        withCredentials: false
      };
    } else {
      this.recoConfig = {
        apiKey: '',
        username: ' ',
        password: ' ',
        accessToken: guestToken,
        withCredentials: false
      };
    }
    if (this.token && !this.videoIsLive && this.videoObject[0].asset_type !== epgAssetType && this.videoObject[0].asset_type !== 9 && this.videoObject[0].content_type !== 'trailer' && this.videoObject[0].content_type !== 'promo') {
      this.watchHistoryApi = new  WatchHistoryApi(this.http, null, this.configUser);
    }
    this.videoViewCounter = this.settingsService.getVideoCounter();

    this.checkVideoInit(false);
    // this.countryListData = this.settingsService.getcountryApiList();
    this.countryListData = this.settingsService.getCountryValueNew();

    if (this.countryListData && this.countryListData[0] && this.countryListData[0].recommendations) {
      this.recoWatchHistoryApi = new  WatchHistoryApi(this.http, environment.recoWatchHistory, this.recoConfig);
    }

    this.countrycodeIndex = this.settingsService.getCountryIndex();
    let hms;
    if (this.countryListData && this.countryListData.length !== 0) {
      if (this.countryListData[this.countrycodeIndex].signup_events.browsing_video) {
        hms = this.countryListData[this.countrycodeIndex].signup_events.browsing_video;
        this.browser_timer_flag = true;
        this.videoViewBuffer = this.countryListData[this.countrycodeIndex].signup_events.video_views;
        if (this.countryListData[this.countrycodeIndex] && this.countryListData[this.countrycodeIndex].signup_events.browsing_video === 'hh:mm:ss') {
         this.browser_timer_flag = false;
          this.videoViewBuffer = this.countryListData[this.countrycodeIndex].signup_events.video_views;
        }
      } else {
        hms = this.countryListData[this.countrycodeIndex].signup_events.browsing_video;
        this.videoViewBuffer = this.countryListData[this.countrycodeIndex].signup_events.video_views;
      }
    } else if (this.configData) {
      if (this.configData.signup_events) {
        if (this.configData.signup_events.browsing_video) {
          hms = this.configData.signup_events.browsing_video;
          this.videoViewBuffer = this.configData.signup_events.video_views;
        } else {
          this.browser_timer_flag = false;
        }
        if (this.configData.signup_events.video_views) {
          this.videoViewBuffer = this.configData.signup_events.video_views;
        } else {
           this.videoViewBuffer = null;
        }
      } else {
        this.browser_timer_flag = false;
        this.videoViewBuffer = null;
      }
    } else {
      this.browser_timer_flag = false;
      this.videoViewBuffer = null;
    }
    if (this.browser_timer_flag) {
      let a;
      a = hms.split(':');
      this.browser_timer = (+a[0]) * 60 * 60 + (+a[1]) * 60 + (+a[2]);
    }
  }

  private checkVideoStartTime(): any {
    if (!this.videoIsLive && this.videoObject[0].asset_type !== epgAssetType && this.videoObject[0].asset_type !== 9 && this.videoObject[0].id === this.videoObject[0].parent_id) {
      let queryparam;
      queryparam = this.getParameterFromURL('t');
      if (queryparam) {
        this.routeStartPoint = parseInt(queryparam, 10);
      } else {
        this.routeStartPoint = undefined;
      }
    }
  }

  private checkVideoInit(replay): any {
    if (!replay) {
      this.checkVideoStartTime();
    }
    if (this.player) {
      this.removePlayer();
      if (this.iOSDevice) {
        this.initializeAfterDestroy = true;
      } else {
        this.startVideo();
      }
    } else {
      this.startVideo();
    }
  }

  public startVideo(): any {
    /* diabling autostart */
    if (this.iOSDevice && this.playerCalledOnLaunch && !this.triggerPlayback) {
    // if (this.testPage3 && this.iOSDevice && this.playerCalledOnLaunch && !this.triggerPlayback && !this.autoClosePosition) {
      this.triggerPlayback = true;
      setTimeout(() => $('#playerOverlay').css('display', 'none'), 0);
      $('#PlayerContainer').css('pointer-events', '');
      return;
    } else {
      this.triggerPlayback = false;
    }
    /* diabling autostart */
    this.initializeAfterDestroy = false;
    this.videoAnalyticsService.init();
    if (!this.videoIsLive && this.videoObject[0].asset_type !== 10 && (this.videoObject[0].id === this.videoObject[0].parent_id)) {
      this.getAutoPlayData();
    } else if (!this.videoIsLive && this.videoObject[0].asset_type !== 10 && (this.country === 'IN' || !(this.videoObject[0].parent_business_type && this.videoObject[0].parent_business_type.indexOf('premium') !== -1 && this.configData && this.configData.subscription_popup && this.configData.subscription_popup.asset_subtype && this.configData.subscription_popup.asset_subtype.indexOf(this.videoObject[0].content_type.toLowerCase()) !== -1))) {
      // if (!this.videoIsLive && this.videoObject[0].asset_type !== 10 && this.country === 'IN' && !(this.videoObject[0].content_type === 'trailer' && this.headerService.premium)) {
      this.getAutoPlayData();
    }
    if (this.videoObject[0].drm && !this.playAES) {
      // this.iOSDevice = this.navigator.platform.match(/(iPhone|iPod|iPad)/i);
      this.generateCustomkey();
    } else {
      // this.iOSDevice = false;
      this.getVideoToken(this.videoObject[0].type);
    }
  }

  private getAutoPlayData(): any {
    let id;
    id = JSON.stringify({'id': this.videoObject[0].id, 'extra': (this.videoObject[0].id === this.videoObject[0].parent_id) ? null : this.videoObject[0].parent_id});
    this.commonService.getAutoPlayData(id, null).timeout(environment.timeOut).subscribe(value => {
      if (value && value.items && value.items.length > 0) {
        this.nextData = value.items;
      }
      if (value && value.previous_items && value.previous_items.length > 0) {
        this.prevData = value.previous_items;
      }
      this.setAutoplayState();
    },
    err => {
      this.videoService.apiErrorEvent(err);
    });
  }

  private setAutoplayState(): any {
    // this.enableAutoplay =  this.nextData && this.nextData[0] && ((this.videoObject[0].content_type === 'episode' && this.nextData[0].asset_type === 1) || (this.videoObject[0].content_type !== 'episode' && this.commonService.getCollectionId())) ? true : false;
    // this.enableAutoplay =  this.nextData && this.nextData[0] && ((this.videoObject[0].content_type === 'episode' && this.nextData[0].asset_type === 1) || this.commonService.getCollectionId()) ? true : false;
    this.enableAutoplay =  this.nextData && this.nextData[0] && (!(this.videoObject[0].asset_type === 0 && this.videoObject[0].content_type === 'movie' && !this.commonService.getCollectionId())) ? true : false;
    this.showMovieRails =  this.nextData && this.nextData[0] && ((this.videoObject[0].asset_type === 0 && this.videoObject[0].content_type === 'movie' && !this.commonService.getCollectionId())) ? true : false;
    // this.enableAutoplay =  this.nextData && this.nextData[0] && (!(this.videoObject[0].asset_type === 0 && this.videoObject[0].content_type === 'movie' && !this.commonService.getCollectionId()) || !(this.videoObject[0].content_type === 'episode' && (this.nextData.length > 1) && !this.commonService.getCollectionId())) ? true : false;
    // this.showrails(true, this.nextData, true, true)
    this.railData = {
      // 'assetSubType': 'tvshow',
      // 'id': '0-6-199',
      'link': 'tvshows',
      'parentType': 'rails',
      'type': 'home',
      'content': this.nextData
    };
  }

  public changeContent(type): any {
    let data, details;
    if (type === 'prev') {
      data = this.prevData[0];
      details = {
        'event': 'previousVideoClick',
        'Previous_Video': data.original_title
      };
    } else {
      data = this.nextData[0];
      details = {
        'event': 'nextVideoClick',
        'Next_Video': data.original_title
      };
    }
    this.googleAnalyticPost(details);
    // GA events
    this.commonService.changeContent(data);
  }

  public initializeOnVideoObjectChange(): any {
    this.triggerPlayback = false;
    // if (this.checkMoat === true && this.window.moatjw) {
    //   this.window.moatjw.removeAll();
    // }
    this.drmDeviceInfo = undefined;
    this.drmRetry = 1;
    this.retryCounter = retryCount;
    this.error = false;
    this.unsupported = false;
    this.showBackgroundImage = true;
    this.launchButton = false;
    this.networkErrPosition = undefined;
    this.playAES = false;
    this.videoCompleted = false;

    this.gaWatchPercent = 0;
    this.gaCounter = 0;
    this.previousTime = 0;
    // this.passedGAWatchDuration = 0;
    this.updatedHistoryTime = undefined;
    this.inHistory = false;

    this.updatedRecoHistoryTime = undefined;
    this.recoInHistory = false;

    this.gaFirstAPIAudioLang = '';
    this.audioLangsString = '';

    this.adOffsets = [];
    this.adVisible = false;
    this.adPoints = [];
    this.enablePlayback = false;

    this.ebvs = true;
    this.buffering = true;

    this.hasClosedCaptions = 'hidden';
    this.showPopUpOnComplete = false;
    this.videoPaused = false;
    this.pausedByUser = false;
    this.contentPopup = false;

    // skip intro intialization
    this.skipIntroStart = undefined;
    this.skipIntroend = undefined;
    this.skipRecapStart = undefined;
    this.skipRecapEnd = undefined;
    this.showSkipIntro = false;
    this.showSkipRecap = false;
    if (this.videoObject[0].type !== 'live' &&  this.videoObject[0].asset_type !== epgAssetType && this.videoObject[0] && this.videoObject[0].skip_available && this.videoObject[0].skip_available != null) {
    // if ( this.videoObject[0] && this.videoObject[0].skip_available && this.videoObject[0].skip_available != null){
      this.skipIntroStart = (this.videoObject[0].skip_available.intro_start_s && (this.videoObject[0].skip_available.intro_start_s != null || this.videoObject[0].skip_available.intro_start_s !== '')) ? this.convertTimetoSeconds(this.videoObject[0].skip_available.intro_start_s) : null;
      this.skipIntroend = (this.videoObject[0].skip_available.intro_end_s && (this.videoObject[0].skip_available.intro_end_s != null || this.videoObject[0].skip_available.intro_end_s !== '')) ? this.convertTimetoSeconds(this.videoObject[0].skip_available.intro_end_s) : null;
      this.skipRecapStart = (this.videoObject[0].skip_available.recap_start_s && (this.videoObject[0].skip_available.recap_start_s != null || this.videoObject[0].skip_available.recap_start_s !== '')) ? this.convertTimetoSeconds(this.videoObject[0].skip_available.recap_start_s) : null;
      this.skipRecapEnd = (this.videoObject[0].skip_available.recap_end_s && (this.videoObject[0].skip_available.recap_end_s != null || this.videoObject[0].skip_available.recap_end_s !== '')) ? this.convertTimetoSeconds(this.videoObject[0].skip_available.recap_end_s) : null;
    }
      // new autoplay
    this.watchCreditsClick = false;
    this.showRails = false;
    this.enableAutoplay = false;
    this.showMovieRails = false;
    this.prevData = undefined;
    this.nextData = undefined;
    // this.showCountdownTimer = false;
    this.showWatchCredits = false;
    this.railData = {};
    this.endCreditsStart = undefined;
    this.countDown = undefined;
    clearTimeout(this.nextPlayTimeout);
    clearInterval(this.countDownInterval);
    this.nextPlayTimeout = undefined;
    this.countDownInterval = undefined;
    this.startAutoplayTimer = false;
    this.showWatchCredits = (this.videoObject[0].endCreditsStart && (this.videoObject[0].endCreditsStart != null || this.videoObject[0].endCreditsStart !== '')) ? true : false;
    this.endCreditsStart = this.showWatchCredits ? this.convertTimetoSeconds(this.videoObject[0].endCreditsStart) : this.showCredits;
    this.historyRetryCount = 1;

    this.adTimeStamp = undefined;
    this.showVideoViewSignup = false;
    this.recoDmpSync = false;

    this.thumbnail_data = undefined;
    this.pageX = undefined;
    this.routeStartPoint = undefined;
  }

  public downloadUrl(): any {
    if (this.navigator.userAgent.match(/iPhone|iPad|iPod/i)) {
        this.downloadApp = environment.downloadIos;
    } else {
        this.downloadApp = environment.downloadAndroid;
    }
  }

  public checkForAES(): any {
    let businessType;
    businessType = this.videoObject[0].business_type;
    this.browserUnSupported = this.videoService.checkWindows(this.videoObject[0]);
    // if ((this.browserUnSupported || this.browser.name.match(/opera|chrome|crios|OPR/i)) && (businessType !== 'premium' && businessType !== 'premium_downloadable') && this.videoObject[0].drm && this.videoObject[0].type === 'vod' && (!this.browser.name.match(/IE/i))) { //  && !(this.navigator.userAgent.match(/Android/i) && this.browser.name.match(/firefox/i))
    if (businessType !== 'premium' && businessType !== 'premium_downloadable' && this.videoObject[0].drm && this.videoObject[0].type === 'vod') {
      this.playAES = true;
    } else {
      this.unsupported = this.browserUnSupported;
      this.unsupportederrorMsg = this.videoService.errorMsg;
      if (this.unsupportederrorMsg === 'PLAYER.ERROR_MSG' && this.androidORiOS) {
        this.checkAppDownloadLinks();
        // this.launchButton = true
      }
    }
  }

  public checkAppDownloadLinks(): any {
    if (this.condition_show_DownloadApp === undefined) {
      // this.settingsService.getCountryListNew().takeUntil(this.ngUnsubscribe).subscribe(value => {
        let menu_options;
        menu_options = this.settingsService.getCountryValueNew();
        if (menu_options[0].menu_options['app_download_links'] === 'yes') {
          this.condition_show_DownloadApp = true;
        } else {
          this.condition_show_DownloadApp = false;
          this.unsupportederrorMsg = 'PLAYER.ERROR_MSG_WITHOUT_APPS';
        }
        this.launchButton = this.condition_show_DownloadApp;
      // })
    } else {
      this.unsupportederrorMsg = this.condition_show_DownloadApp ? 'PLAYER.ERROR_MSG' : 'PLAYER.ERROR_MSG_WITHOUT_APPS';
      this.launchButton = this.condition_show_DownloadApp;
    }
  }

  public getVideoToken(live): any {
    this.drm = null;
    live = this.playAES ? 'fallback' : live;
    this.videoService.getToken(live, this.videoObject[0].business_type, this.videoObject[0].id).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
      if (value && value.video_token) {
        this.videoToken = value.video_token;
        this.initializePlayer();
      } else {
        this.videoToken = null;
        this.showErrorState(tryAgainMessage);
      }
    },
    err => {
      if (err.name === 'TimeoutError') {
        if (this.retryCounter === 1) {
          // this.videoAnalyticsService.playerInsightsConviva(this.player, 'API response failure', {'API Response Failure': err.message});
        }
        this.showErrorState(tryAgainMessage);
      } else {
        try {
          let errorBody;
          errorBody = JSON.parse(err._body);
          if (this.token && (errorBody.code === 3604 || errorBody.code === 3608) && errorBody.devices) {
            this.addDevice();
          } else {
            if (this.retryCounter === 1) {
              // this.videoAnalyticsService.playerInsightsConviva(this.player, 'API response failure', {'API Response Failure': errorBody.message ? errorBody.message : this.notAvailable});
            }
            this.videoToken = null;
            this.showErrorState(tryAgainMessage);
          }
        } catch (error) {
          this.videoToken = null;
          this.showErrorState(tryAgainMessage);
        }
      }
      this.videoService.apiErrorEvent(err);
    });
  }

  public setBackgroundImage(): any {
    this.background = this.videoService.getImageUrl(this.videoObject[0], false);
    this.playerRead.emit(true);
  }

  public showErrorState(message): any {
    if (message !== sorryError && message !== tryAgainMessage && message !== timeLimit && message !== deviceLimit && message !== noNetworkText && message !== noUrlText) {
      this.errorMsg = tryAgainMessage;
      if (this.retryCounter === 1) {
        if (this.ebvs) {
          // this.videoAnalyticsService.playerInsightsConviva(this.player, 'Video Received', {'CDN Delivery': false});
        }
        // this.videoAnalyticsService.playerInsightsConviva(this.player, 'Play Failure', {'Play Failure': message});
      }
    } else {
      this.errorMsg = message;
    }
    if ((this.mobile_UC || this.xiaomi) && this.player) {
      this.removePlayer();
      // this.player.remove();
    }
    if (this.retryCounter && message !== noUrlText && message !== noNetworkText && message !== timeLimit && message !== deviceLimit) {
      --this.retryCounter;
      this.retryClick();
    } else {
      if (message !== sorryError && message !== tryAgainMessage && message !== timeLimit && message !== deviceLimit) {
        let details, msg;
        msg = message === noNetworkText ? 'Network Error' : message === noUrlText ? 'No data available' : message;
        details = {
          'event': 'ErrorEvent',
          'ErrorType': 'video error',
          'ErrorDescription': msg,
          'ErrorTimings': (this.player ? this.getPlayerCurrentTime() : this.notAvailable) || this.notAvailable,
          'ErrorMetrics': '1',
        };
        this.googleAnalyticPost(details);
      }
      this.buffering = false;
      this.showBackgroundImage = true;
      this.error = true;
      this.startPlayback = true; // not to show play icon in UC browser
      this.tryagain = true; // not to show re-try icon in UC browser
      $('#playerOverlay').css('display', 'block');
      $('#PlayerContainer').css('pointer-events', 'none');
    }
  }

  public retryClick(): any {
    if (this.errorMsg === deviceLimit) {
      this.deleteDevice();
    } else {
      this.tryAgain();
    }
  }

  public fetchConfig(): void {
    let value;
    value = this.configData;
    this.cdnData = value.cdn;
    this.languages = value.languages;
    if (!this.cdnData || this.cdnData.length < 1) {
      this.drmBasePath = akamaiBasePath;
    } else {
      this.drmBasePath = this.cdnData[0].url_in;
    }
  }

  @HostListener('window:resize', ['$event'])
  public fontReScale(event) {
    if (this.window.innerWidth < 481) {
      this.mobile = true;
      if (this.showRails) {
        this.hideRails('resize');
      }
    } else {
      this.mobile = false;
    }
    this.touchScreen = this.navigator.userAgent.match(/mobile|Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i) ? true : false;
    if (this.touchScreen) {
      $(this.document).ready(function() {
      $('.rewind1').hide();
      $('.forward1').hide();
      $('.rewind').css('display', 'none');
      $('.forward').css('display', 'none');
      });
    } else {
      $(this.document).ready(function() {
      $('.rewind1').css('display', 'none');
      $('.forward1').css('display', 'none');
      });
    }
    this.progressCss();
    this.fontResize();
  }

  @HostListener('window:online', ['$event'])
  @HostListener('window:offline', ['$event'])
  public networkChange(event) {
    if (this.networkStatus === 'offline' && event.type === 'online' && this.player) {
      if (this.videoObject[0].type === 'vod') {
        this.networkErrPosition = Math.floor((this.currentTimePercent / 100) * this.totalTimeMS);
      }
      this.error = false;
      this.checkVideoInit(false);
    }
    this.networkStatus = event.type;
  }

  @HostListener('document:mozfullscreenchange', ['$event'])
  @HostListener('document:webkitfullscreenchange', ['$event'])
  @HostListener('document:MSFullscreenChange', ['$event'])
  @HostListener('document:fullscreenchange', ['$event'])
  public fullScreen(event) {
      this.hideThumbnail(0);
      if (this.document.fullscreenElement || this.document.webkitFullscreenElement || this.document.mozFullScreenElement || this.document.msFullscreenElement) {
      this.epg.disableWindowScroll(true);
      this.videoAnalyticsService.updateMetaTags(this.player, 'viewingMode', 'Full Screen');
      this.screenIcon = this.collapse_screenIcon;
    } else {
      this.epg.disableWindowScroll(false);
      this.videoAnalyticsService.updateMetaTags(this.player, 'viewingMode', this.videoAnalyticsService.getViewingMode());
      this.screenIcon = this.expand_screenIcon;
      $('#body').css('overflow', '');
    }
  }

  @HostListener('window:orientationchange', ['$event'])
  public orientationChange(event) {
    setTimeout(() => {
      let screenOrientation;
      screenOrientation = this.window.orientation;
      this.fontResize();
      if (screenOrientation === 0) {
        if (this.window.innerWidth < 481) {
          this.mobile = true;
        }
        this.videoAnalyticsService.updateMetaTags(this.player, 'viewingMode', 'Portrait');
      } else if (screenOrientation === 90 || screenOrientation === -90) {
        if (this.window.innerWidth < 481) {
          this.mobile = false;
        }
        this.videoAnalyticsService.updateMetaTags(this.player, 'viewingMode', 'Landscape');
      }
      this.progressCss();
    }, 0);
  }

  @HostListener('document:mousewheel', ['$event'])
  @HostListener('document:DOMMouseScroll', ['$event'])
  @HostListener('document:keypress', ['$event'])
  public eventlistener(event) {
    this.resetTimer(event);
  }

  @HostListener('document:mousedown', ['$event'])
  public mousedownlistener(event) {
    this.closePopup(event);
  }

  @HostListener('document:keydown', ['$event'])
  public handleKeyboardEvent(event) {
    let network;
    network = this.networkService.getPopupStatus();
    if (!network || this.showSignUpPromt || this.popUpFromHeader || this.contentLangPopup || this.showRails || this.searchOpen || this.parentalControls) {
      return;
    }
    let ishovered;
    ishovered = $('#PlayerContainer').is(':hover');
    if (event.keyCode === keyCodes.spaceBar) {
      event.preventDefault();
      this.videocontrols();
    } else if (event.keyCode === keyCodes.arrowLeft) {
      if (!this.replay) {
        this.skip(-10, '');
      }
    } else if (event.keyCode === keyCodes.arrowRight) {
      if (!this.replay) {
        this.skip(10, '');
      }
    } else if (ishovered && event.keyCode === keyCodes.arrowUp) {
        event.preventDefault();
        this.resetTimer(event);
        this.volumeDisplay();
        this.changeVolume(+0.1);
    } else if (ishovered && event.keyCode === keyCodes.arrowDown) {
      event.preventDefault();
      this.resetTimer(event);
      this.volumeDisplay();
      this.changeVolume(-0.1);
    } else if (event.keyCode === keyCodes.letterM) {
      this.mute();
    // } else if (event.keyCode === keyCodes.letterF) {
    //   if (!this.getPlayerControlsState()) {
    //   // if (!this.player.getControls()) {
    //     this.toggleFullScreen();
    //   }
    //   // this.toggleFullScreen();
    // } else if (event.keyCode === keyCodes.backSpace) {
    //   // if (this.document.fullscreenElement || this.document.webkitFullscreenElement) {
    //   if (this.document.fullscreenElement || this.document.webkitFullscreenElement || this.document.mozFullScreenElement || this.document.msFullscreenElement) {
    //     this.toggleFullScreen();
    //   }
    }
  }

  /*
    Code to Setup Player and Play Video based on selection.
  */
  public initializePlayer(): any {
    if (this.watchHistoryApi) {
      this.getHistory();
    }
    // this.player = jwplayer('videoDiv');
    this.configurePlayer();
    this.setCanonicalUrl();
    this.fetchUrl(this.videoObject[0]);
  }

  private configurePlayer(): any {
    if (this.iOSDevice) {
      let elementID;
      elementID = 'videoDiv';
      this.player = new RadiantMP(elementID);
      this.playerContainer = document.getElementById(elementID);
      // this.window.radiantPlayer = this.player;
    } else {
      let config;
      config = {
      targetId: 'videoDiv',
      provider: {
          partnerId: 2504201
        }
      };
      this.player = KalturaPlayer.setup(config);
      // this.window.kalturaPlayer = this.player;
    }
  }

  public fetchUrl(videoObject): any {
    this.drmFlag = videoObject.drm && !this.playAES;
    if (videoObject) {
      if (videoObject.stream_url_dash && videoObject.stream_url_hls && this.drmFlag) {
        this.resourceUrl = videoObject.stream_url_dash;
        if (this.navigator.platform.match(/(Mac|iPhone|iPod|iPad)/i) && this.browser.name.match(/safari|netscape/i)) {
        // if (this.navigator.platform.match(/(Mac|iPhone|iPod|iPad)/i) && this.browser.name === 'Safari') {
          if (videoObject.type === 'live') {
            this.resourceUrl = this.resourceUrl.replace('.mpd', '.m3u8');
          } else if (videoObject.type === 'vod') {
            this.resourceUrl = videoObject.stream_url_hls;
          }
        } else if (videoObject.type === 'live') {
        // } else if ((this.androidORiOS || this.browser.name.match(/firefox/i)) && videoObject.type === 'live') {
          this.resourceUrl = videoObject.stream_url_hls;
          this.drm = null;
          this.drmFlag = false;
        }
        this.generateUrl(true);
      } else if (videoObject.stream_url_hls) {
        this.resourceUrl = videoObject.stream_url_hls; // default stream_url/url
        this.generateUrl(true);
      } else if (videoObject.stream_url_dash) {
        this.resourceUrl = videoObject.stream_url_dash; // hls if present i.e stream_urlHls
        this.generateUrl(true);
      } else {
        this.errorUrl();
      }
    }
  }

  public errorUrl(): any {
    this.resourceUrl = '';
    this.showErrorState(noUrlText);
  }

  /*
    video URL formation
  */
  public generateUrl(checkSubtitle): any {
    if (checkSubtitle) {
      let subtitleUrl;
      if (this.resourceUrl.indexOf('/') === 0) {
        subtitleUrl = akamaiBasePath + this.resourceUrl;
        if (this.playAES || (this.navigator.platform.match(/(Mac|iPhone|iPod|iPad)/i) && this.browser.name.match(/safari|netscape/i) && this.videoObject[0].type === 'vod' && this.drmFlag)) {
        // if (this.playAES || (this.navigator.platform.match(/Mac/i) && this.browser.name === 'Safari' && this.videoObject[0].type === 'vod' && this.drmFlag)) {
          subtitleUrl = subtitleUrl.replace('index.m3u8', 'manifest.mpd');
        }
      } else {
        subtitleUrl = this.resourceUrl;
      }
      if (subtitleUrl && subtitleUrl[4] !== 's') {
        subtitleUrl = subtitleUrl.replace('http', 'https');
      }
      this.getSubtitles(subtitleUrl);
    }

    if (this.resourceUrl.indexOf('/') === 0) {
      if (this.playAES) {
        this.resourceUrl = this.resourceUrl.replace('/drm', '/hls');
        this.resourceUrl = fallbackBasepath + this.resourceUrl;
        this.contentUrl = this.resourceUrl;
        if (this.videoService.testPage) {
          this.resourceUrl = this.videoToken;
          this.contentUrl = this.videoToken;
          this.resourceUrlConviva = this.videoToken;
        }
      } else {
        let callPrecision;
        callPrecision = (this.configData.default_values && this.configData.default_values.precision_enabled && this.configData.default_values.precision_enabled.web !== undefined) ? this.configData.default_values.precision_enabled.web : true;
        if (this.cdnData && this.cdnData.length > 1 && this.configData.default_values.precision_enabled.web) {
          this.getPrecision();
          return;
        } else {
          this.precisionAPI = null;
          this.resourceUrl = this.drmBasePath + this.resourceUrl;
          this.contentUrl = this.resourceUrl;
        }
      }
    }
    if (this.resourceUrl && this.resourceUrl[4] !== 's') {
      this.resourceUrl = this.resourceUrl.replace('http', 'https');
    }
    if (!this.drmFlag && (!this.videoService.testPage || !this.playAES)) {
    // if (!this.drmFlag && !this.playAES) {
    // if (!this.drmFlag) {
    // } else {
      this.contentUrl = this.resourceUrl;
      this.resourceUrl = this.resourceUrl + this.videoToken;
      this.resourceUrlConviva = this.resourceUrl;
    }
    this.enablePeer5scripts();
    // this.enablePlayback = true;
    this.createPlaylist();
    // this.checkPeer5inPrecision()
  }

  public enablePeer5scripts(): any {
    if (this.window.peer5) {
      this.window.peer5.destroy();
      if (this.configData.peer5 && environment.isPeer5) {
        this.peer5enabled = true;
        this.window.peer5.init();
      }
    }
  }

  public getPrecision(): any {
    let index;
    if (this.videoObject[0]) {
      let id;
      id = this.videoObject[0].id || '';
      this.videoService.getAPI(this.drmFlag, id).takeUntil(this.ngUnsubscribe).timeout(this.videoService.getPrecisionTimeout()).subscribe(value => {
        this.precisionAPI = value;
        if (this.precisionAPI.resource_list && this.precisionAPI.resource_list.length > 0) {
          index = this.cdnData.findIndex(i => i.id === this.precisionAPI.resource_list[0].resource);
          if (index !== -1) {
            this.drmBasePath = this.cdnData[index].url_in;
          }
          this.resourceUrl = this.drmBasePath + this.resourceUrl;
          if (this.precisionAPI['c3.ri']) {
            this.contentUrl = this.resourceUrl;
            this.resourceUrlConviva = this.resourceUrl + '?c3.ri=' + this.precisionAPI['c3.ri'];
          } else {
            this.contentUrl = this.resourceUrl;
            this.resourceUrlConviva = this.resourceUrl;
          }
          this.generateUrl(false);
        }
      },
      err => {
        this.precisionAPI = null;
        this.resourceUrl = this.drmBasePath + this.resourceUrl;
        this.contentUrl = this.resourceUrl;
        this.resourceUrlConviva = this.resourceUrl;
        this.generateUrl(false);
        this.videoService.apiErrorEvent(err);
      });
    }
  }

  public getSubtitles(resourceUrl): any {
    this.subtitles = [];
    if (!this.videoObject[0].subtitles || !this.videoObject[0].subtitles.length) {
      return;
    }
    let subtitleUrl, subtitle, url, language, languageArray, scope;
    this.unknownSubtitleCounter = 0;
    scope = this;
    if (resourceUrl.indexOf('.m3u8') >= 0) {
      subtitleUrl = resourceUrl.replace('.m3u8', '.vtt');
    } else if (resourceUrl.indexOf('.mpd') >= 0) {
      subtitleUrl = resourceUrl.replace('.mpd', '.vtt');
    }
    for (let i = this.videoObject[0].subtitles.length - 1; i >= 0; i--) {
      if (this.videoObject[0].subtitles[i]) {
        url = subtitleUrl.replace('.vtt', '-' + this.videoObject[0].subtitles[i] + '.vtt');
        subtitle = {};
        languageArray = $.grep(this.languages, function(e) {
          return e.id === scope.videoObject[0].subtitles[i];
        });
        if (languageArray && languageArray.length > 0) {
          language = languageArray[0].name;
        } else {
          language = 'Subtitle Language ' + (++this.unknownSubtitleCounter);
        }
        if (this.iOSDevice) {
          subtitle = [
            this.videoObject[0].subtitles[i],
            language,
            url
          ];
        } else {
          subtitle = {
            label: language,
            language: this.videoObject[0].subtitles[i],
            type: 'vtt',
            url: url
          };
        }
        this.subtitles.push(subtitle);
        url = '';
      }
    }
  }

  /*
    Setup player
  */
  public createPlaylist(): any {
    this.enablePlayback = true;
    if (this.videoAdData) {
      if (this.retryCounter === 1 ) {
        // this.videoAnalyticsService.playerInsightsConviva(this.player, 'Video Request', {'Play Initiated': true});
      }
      this.enablePlayback = false;
      if (!this.videoIsLive && this.videoObject[0].asset_type !== epgAssetType && this.videoObject[0].asset_type !== 9 && this.videoObject[0].type !== 'live' && this.videoObject[0].vtt_thumbnail) {
        this.getThumbnail();
      }
      if (this.iOSDevice) {
        this.createRadiantPlaylist();
      } else {
        this.createKalturaPlaylist();
      }
    }
  }

  public createRadiantPlaylist(): any {
    if (this.videoAdData && this.videoAdData.ads_visibility) {
      this.advertisement = {
        ads: true,
        adVpaidMode: 'enabled',
        adContinuousPlayback: 'yes',
        adSchedule: this.getAds()
      };
    } else {
      this.advertisement = {
        ads: false
      };
      if (this.retryCounter === 1 ) {
        // this.videoAnalyticsService.playerInsightsConviva(this.player, 'Ad request', {'Ad request': false});
      }
    }
    this.setupRadiantPlayer();
  }

  public createKalturaPlaylist(): any {
    if (this.videoAdData && this.videoAdData.ads_visibility) {
      this.advertisement = {
        ima: {
          adsResponse: this.VMAPgenerator(),
          // debug: true,
          adsRenderingSettings: {playAdsAfterTime: -1}
        }
      };
    } else {
      this.advertisement = null;
      if (this.retryCounter === 1 ) {
        // this.videoAnalyticsService.playerInsightsConviva(this.player, 'Ad request', {'Ad request': false});
      }
    }
    this.playerMediaObj = {
      'plugins' : this.advertisement ? this.advertisement : {},
      'session' : {}
    };
		this.setupKalturaPlayer();
	}

  private getStartTime(): any {
    let time;
    if (this.networkErrPosition !== undefined && this.networkErrPosition > 0 && this.networkErrPosition !== Math.floor(this.totalTimeMS)) {
      time = this.networkErrPosition;
      this.networkErrPosition = undefined;
    } else if (this.watchHistoryApi && this.inHistory && this.currentTimeSec > 0 && this.currentTimeSec !== Math.floor(this.totalTimeMS)) {
      time = this.currentTimeSec;
    } else if (this.routeStartPoint > 0) {
      if (this.routeStartPoint >= Math.floor(this.totalTimeMS)) {
        time = this.totalTimeMS;
      } else {
        time = this.routeStartPoint;
      }
    } else {
      time = 0;
      this.updateRecoHistory('', time);
    }
    this.videoAnalyticsService.updateMetaTags(this.player, 'videoStartPoint', this.updateTime(time));
    return time;
  }

  public setupRadiantPlayer(): any {
    let mute, autostart;
    mute = false;
    // if (this.navigator.userAgent.match(/mobile|iPhone|iPod|iPad/i) && !this.mobile_UC) {
    //   this.muteLaunch = true;
    //   mute = true;
    // } else {
    //   mute = false;
    // }
    autostart =  this.mobile_UC ? false : true;
    this.startPlayback = autostart;
    if (!autostart) {
      $('#PlayerContainer').css('pointer-events', '');
      $('#playerOverlay').css('display', 'none');
    }

    this.playerMediaObj = {
      licenseKey: playerKey,
      autoHeightMode: true,
      autoplay: true,
      hideControls: true,
      ccFiles: this.subtitles,
      ...this.advertisement,
    };
    this.callRadiantPlayer();
    this.addPlayerEventListeners();
  }

  private callRadiantPlayer(): any {
    let streamDetails;
    if (this.drmFlag && this.drmDeviceInfo) {
      if ((this.drmDeviceInfo.type === 'widevine') || ( this.drmDeviceInfo.type === 'playready')) {
        let scope, shakaCustomRequestFilter;
        scope = this;
        shakaCustomRequestFilter = function (type, request) {
          if (type != scope.window.shaka.net.NetworkingEngine.RequestType.LICENSE) return;
          if (scope.customData) {
            request.headers['customData'] = scope.customData;
            return;
          }
        };
        streamDetails = {
          'src': {
            'dash': this.resourceUrl
          },
          'shakaDrm': {
            'servers': {
              'com.widevine.alpha': '//wv-keyos-aps1.licensekeyserver.com/',
              'com.microsoft.playready': '//pr-keyos-aps1.licensekeyserver.com/core/rightsmanager.asmx'
            }
          },
          'shakaCustomRequestFilter': shakaCustomRequestFilter
        };
      } else if (this.drmDeviceInfo.type === 'fairplay') {
        let scope, fpsDrm;
        scope = this;
        fpsDrm = {
          'certificatePath': 'https://fp-keyos.licensekeyserver.com/cert/b19d422d890644d5112d08469c2e5946.der',
          'processSpcPath': '//fp-keyos-aps1.licensekeyserver.com/getkey/',
          licenseRequestHeaders: [{
            'name': 'customdata',
            'value': scope.customData
          }],
          extractContentId: function (initData) {
            var arrayToString = function (array) {
              var uint16array = new Uint16Array(array.buffer);
              return String.fromCharCode.apply(null, uint16array);
            };
            var contentId = arrayToString(initData);
            var idx = contentId.indexOf('skd://');
            if (idx > -1) {
              return contentId.substring(8, 40);
            }
            throw "Invalid Content ID format. The format of the Content ID must be the following: skd://xxx where xxx is the Key ID in hex format.";
          }
        };
        streamDetails = {
          'src': {
            'fps': this.resourceUrl
          },
          'fpsDrm': fpsDrm
        };
      }
    } else {
      streamDetails = {
        'src': {
          'hls': this.resourceUrl
        }
      };
    }
    if (this.advertisement) {
      $('#PlayerContainer').css('pointer-events', '');
      $('#playerOverlay').css('display', 'none');
      this.showBackgroundImage = false;
    }
    let playerObj;
    playerObj = {...this.playerMediaObj, ...streamDetails};
    console.log(playerObj, 'playerMediaObj');
    this.player.init(playerObj);
  }

  public setupKalturaPlayer(): any {
    let mute, autostart;
    mute = false;
    // if (this.navigator.userAgent.match(/mobile|iPhone|iPod|iPad/i) && !this.mobile_UC) {
    //   this.muteLaunch = true;
    //   mute = true;
    // } else {
    //   mute = false;
    // }
    autostart =  this.mobile_UC ? false : true;
    this.startPlayback = autostart;
    if (!autostart) {
      $('#PlayerContainer').css('pointer-events', '');
      $('#playerOverlay').css('display', 'none');
    }

    this.playerMediaObj.playback = {
      autoplay: autostart,
      allowMutedAutoPlay: autostart,
      muted: mute,
      startTime: this.getStartTime()
    };
    this.callPlayer();
    this.addPlayerEventListeners();
  }

  private callPlayer(): any {
    if (this.drmFlag && this.drmDeviceInfo) {
      if ((this.drmDeviceInfo.type === 'widevine') || ( this.drmDeviceInfo.type === 'playready')) {
        let scope;
        scope = this;
        this.player.addEventListener(this.player.Event.ABR_MODE_CHANGED, (event) => {
          const engine = this.player._localPlayer._engine;
          const adapter = engine._mediaSourceAdapter || engine._engine._mediaSourceAdapter;
          const networkEngine = adapter._shaka.getNetworkingEngine();
          networkEngine.registerRequestFilter(function(type, request) {
            if (type === networkEngine.constructor.RequestType.LICENSE) {
                request.headers['customData'] = scope.drmDeviceInfo.licenseRequestData;
            }
          });
        });
        this.playerMediaObj.sources = {
          'captions' : this.subtitles,
          'metadata': {
            'name': 'sample'
          },
          'dash': [{
            'id': '0_2jiaa9tb_997,mpegdash',
            'url': this.resourceUrl,
            'mimetype': 'application/dash+xml',
            'drmData': [{
                'licenseUrl': this.drmDeviceInfo.licenseUrl,
                'scheme': this.drmDeviceInfo.scheme,
                'certificate': ''
            }]
          }],
        };
        this.player.setMedia(this.playerMediaObj);
      } else if ((this.drmDeviceInfo.type === 'fairplay')) {
        this.fetchCert();
      }
    } else {
      this.playerMediaObj.sources = {
        'captions' : this.subtitles,
        'metadata': {
          'name': 'sample'
        },
        'hls': [
          {
          'id': 'id2',
          'mimetype': 'application/x-mpegURL',
          'url': this.resourceUrl
          }
        ]
      };
      this.player.setMedia(this.playerMediaObj);
    }
  }

  // async function fetchCert() {
  private async fetchCert(): Promise<any> {
    const req = await fetch(this.drmDeviceInfo.certificateUrl);
    // const req = await fetch('https://fp-keyos.licensekeyserver.com/cert/b19d422d890644d5112d08469c2e5946.der');
    const cert = await req.arrayBuffer();
    let unitArray;
    unitArray = new Uint8Array(cert);
    const certBase64 = btoa(String.fromCharCode(... unitArray));
    let scope = this;
    this.player.setMedia({...this.playerMediaObj,
      network: {
        requestFilter: function(type, request) {
          if (type !== KalturaPlayer.core.RequestType.LICENSE) {
            return;
          }
          const originalPayload = request.body;
          const params = 'spc=' + originalPayload + '&assetid=' + scope.videoObject[0].drm_keyid.toString().split('-').join('');
          request.headers['customData'] = scope.drmDeviceInfo.licenseRequestData;
          request.body = params;
        },
        responseFilter: function(type, response) {
          if (type !== KalturaPlayer.core.RequestType.LICENSE) {
            return;
          }
          var ckc = response.data;
          var base64EncodedKey = String.fromCharCode.apply(null, new Uint8Array(ckc));
          if (base64EncodedKey.substr(0, 5) === '<ckc>' && base64EncodedKey.substr(-6) === '</ckc>') {
              base64EncodedKey = base64EncodedKey.slice(5, -6);
          }
          var arraykey = Array.from(atob(base64EncodedKey), c => c.charCodeAt(0));
          var key = new Uint8Array(arraykey);
          response.data = key;
        }
      },
      sources: {
        'captions' : this.subtitles,
        'metadata': {
          'name': 'sample'
        },
        'hls': [{
          'id': '0_4s6xvtx3_972,applehttp',
          'url': this.resourceUrl,
          'mimetype': 'application/x-mpegURL',
          'drmData': [{
            'licenseUrl': this.drmDeviceInfo.licenseUrl,
            'scheme': this.drmDeviceInfo.scheme,
            'certificate': certBase64,
          }]
        }],
      }
    });
  }

  private getAds(): any {
    if (this.videoAdData && this.videoAdData.intervals) {
      let schedule, tag;
      schedule = {
        preroll: [],
        midroll: [],
        postroll: []
      };
      for (tag of this.videoAdData.intervals) {
        let timeStamp;
        timeStamp = ((this.videoAdData.type && this.videoAdData.type === 'vpaid') ? '' : this.getTimeStamp());
        if (tag.time === 'pre' || tag.time === 'start') {
          schedule.preroll.push([tag.tag + timeStamp]);
        } else if (!this.videoIsLive && this.videoObject[0].type !== 'live' && tag.time === 'post' || tag.time === 'end') {
          schedule.postroll.push([tag.tag + timeStamp]);
        } else if (!this.videoIsLive && this.videoObject[0].type !== 'live') {
          schedule.midroll.push([Number(tag.time), tag.tag + timeStamp]);
        }
        this.getAdOffsets(tag.time);
      }
      return schedule;
    } else {
      return null;
    }
  }

  public getAdOffsets(timeString): any {
    let sec = 0;
    if (timeString !== 'start' && timeString !== 'end' && timeString !== 'pre' && timeString !== 'post') {
      sec = parseInt(timeString, 10);
      if (this.adOffsets.indexOf(sec) === -1) {
        this.adOffsets.push(sec);
      }
    }
  }

	private getTimeStamp(): any {
    if (!this.adTimeStamp) {
      this.adTimeStamp = Date.now();
    } else {
      ++this.adTimeStamp;
    }
		return this.adTimeStamp;
	}
  private VMAPgenerator(): any {
    let ad_Type, ads, adsHeader, adsFooter, imagTagMidArray, imaTagPreArray, imagTagPostArray;
    imagTagMidArray = [];
    imaTagPreArray = [];
    imagTagPostArray = [];
    ad_Type = this.videoAdData.type === 'vpaid' ? 'vpaid' : 'vast3';
    ads = null;
    adsHeader = `<vmap:VMAP xmlns:vmap="http://www.iab.net/videosuite/vmap" version="1.0">`;
    adsFooter = `</vmap:VMAP>`;
    this.videoAdData.intervals.map((ad_time, index) => {
      this.getAdOffsets(ad_time.time);
      let ad_Time, ad_Url, ad_Tag, imaTag, imagTagPost, imagTagMid;
      ad_Time = ad_time.time;
      ad_Url = ad_time.tag;
      ad_Tag = ad_time.tag_name;
      ad_Time = Number(ad_Time);
      if (isNaN(ad_Time)) {
          ad_Time = ad_time.time;
      } else {
        let h, m, s, hDisplay, mDisplay, sDisplay;
        h = Math.floor(ad_Time / 3600);
        m = Math.floor((ad_Time % 3600) / 60);
        s = Math.floor((ad_Time % 3600) % 60);
        hDisplay = h > 9 ? h : `0${h}`;
        mDisplay = m > 9 ? m : `0${m}`;
        sDisplay = s > 9 ? `${s}.000` : `0${s}.000`;
        ad_Time = hDisplay + ':' + mDisplay + ':' + sDisplay;
      }
      switch (ad_Time) {
        case 'pre':
          imaTag = `<vmap:AdBreak timeOffset="start" breakType="linear" breakId="preroll">
          <vmap:AdSource id="${ad_Tag}" allowMultipleAds="false" followRedirects="true">
          <vmap:AdTagURI templateType="${ad_Type}">
          <![CDATA[${ad_Url + this.getTimeStamp()}]]>
          </vmap:AdTagURI>
          </vmap:AdSource>
          </vmap:AdBreak>`;
          imaTagPreArray.push(imaTag);
          break;
        case 'post':
          imagTagPost = `<vmap:AdBreak timeOffset="end" breakType="linear" breakId="postroll">
          <vmap:AdSource id="${ad_Tag}" allowMultipleAds="false" followRedirects="true">
          <vmap:AdTagURI templateType="${ad_Type}">
          <![CDATA[${ad_Url + this.getTimeStamp()}]]>
          </vmap:AdTagURI>
          </vmap:AdSource>
          </vmap:AdBreak>`;
          imagTagPostArray.push(imagTagPost);
          break;
        default:
          imagTagMid = `<vmap:AdBreak timeOffset="${ad_Time}" breakType="linear" breakId="midroll-${index}">
          <vmap:AdSource id="${ad_Tag}" allowMultipleAds="false" followRedirects="true">
          <vmap:AdTagURI templateType="${ad_Type}">
          <![CDATA[${ad_Url + this.getTimeStamp()}]]>
          </vmap:AdTagURI>
          </vmap:AdSource>
          </vmap:AdBreak>`;
          imagTagMidArray.push(imagTagMid);
      }
    });

    let preAds, midAds, postAds;
    preAds = imaTagPreArray.join('');
    midAds = imagTagMidArray.join('');
    postAds = imagTagPostArray.join('');
    imaTagPreArray.length > 0 && imagTagMidArray.length > 0 && imagTagPostArray.length > 0
    ? (ads = adsHeader + preAds + midAds + postAds + adsFooter)
    : imaTagPreArray.length > 0 && imagTagMidArray.length > 0
    ? (ads = adsHeader + preAds + midAds + adsFooter)
    : imaTagPreArray.length > 0 && imagTagPostArray.length > 0
    ? (ads = adsHeader + preAds + postAds + adsFooter)
    : imagTagMidArray.length > 0 && imagTagPostArray.length > 0
    ? (ads = adsHeader + midAds + postAds + adsFooter)
    : imaTagPreArray.length > 0
    ? (ads = adsHeader + preAds + adsFooter)
    : imagTagPostArray.length > 0
    ? (ads = adsHeader + postAds + adsFooter)
    : (ads = adsHeader + midAds + adsFooter);
    return ads;
  }

  public getThumbnail(): any {
    this.thumbnailUrl = this.videoObject[0].vtt_thumbnail;
    let scope;
    scope = this;
    this.videoService.getAdInfo(this.thumbnailUrl).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
      if (value && value._body) {
        let data;
        data = value._body.split('\n\n');
        data.shift();
        data = data.map(function (item) {
          let parts;
          parts = item.split('\n');
          return {
            time: parts[0],
            text: parts[1],
          };
        });
        this.thumbnail_data = data;
      }
    });
  }
  
  public generateCustomkey(): any {
    let object;

    console.log("videoObject", this.videoObject)
    console.log("videoObject", this. videoObject.drm_keyid)
    object = this.videoService.getEntitlementObject(this.videoObject[0]);
    this.postEntitlement(object);
  }

  public postEntitlement(object: any): any {
    this.userapiService.postEntitlementV3(object).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
      if (value && value !== null && !this.userapiService.isEmptyObject(value)) {
        this.customData = value.drm;
        if (this.iOSDevice) {
          // this.setDRM();
          this.setDRMinfo();
        } else {
          this.setDRMinfo();
        }
        this.initializePlayer();
      } else {
        this.showErrorState(tryAgainMessage);
      }
    }, error => {
      if (error.name === 'TimeoutError') {
        if (this.retryCounter === 1) {
          // this.videoAnalyticsService.playerInsightsConviva(this.player, 'API response failure', {'API Response Failure': error.message});
        }
        this.showErrorState(tryAgainMessage);
      } else {
        let errorBody;
        errorBody = JSON.parse(error._body);
        if (this.token && (errorBody.code === 3604 || errorBody.code === 3608)) { // Device not found
          this.addDevice();
        } else {
          if (this.retryCounter === 1) {
            // this.videoAnalyticsService.playerInsightsConviva(this.player, 'API response failure', {'API Response Failure': errorBody.message ? errorBody.message : this.notAvailable});
            // this.videoAnalyticsService.playerInsightsConviva(this.player, 'DRM Error', {'DRM Error': errorBody.message ? errorBody.message : this.notAvailable});
          }
          this.showErrorState(tryAgainMessage);
        }
      }
      this.videoService.apiErrorEvent(error);
    });
  }

  public addDevice(): any {
    this.deviceApi.postDevice(this.token).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
      this.checkVideoInit(false);
    }, error => {
      if (error.name === 'TimeoutError') {
        this.showErrorState(sorryError);
      } else {
        let body;
        body = JSON.parse(error._body);
        if (body.code === 3602) { // max devices registered
          this.resetDevicePopup = true;
        } else {
          this.showErrorState(sorryError);
        }
      }
      this.videoService.apiErrorEvent(error);
    });
  }

  public resetDevice(event): any {
    this.resetDevicePopup = false;
    if (event === 'success') { // reset success
      this.addDevice();
    } else { // close // reset failed // other error
      this.showErrorState(event);
    }
  }

  public deleteDevice(): any {
    this.error = false;
    this.deviceApi.deleteDevice(this.token).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
      this.addDevice();
    }, error => {
      if (error.name === 'TimeoutError') {
        this.showErrorState(sorryError);
      } else {
        let body;
        body = JSON.parse(error._body);
        if (body.code === 3607) { // device can be reset only once in 24hrs
          this.showErrorState(timeLimit);
        } else {
          this.showErrorState(sorryError);
        }
      }
      this.videoService.apiErrorEvent(error);
    });
  }

  private setDRMinfo(): any {
    this.drmDeviceInfo = {};
    this.drmDeviceInfo['licenseRequestData'] = this.customData;
    switch (this.browser.name.toLowerCase()) {
        case 'safari':
        case 'netscape':
                this.drmDeviceInfo['licenseUrl'] = '//fp-keyos-aps1.licensekeyserver.com/getkey/';
                this.drmDeviceInfo['certificateUrl'] = 'https://fp-keyos.licensekeyserver.com/cert/b19d422d890644d5112d08469c2e5946.der';
                this.drmDeviceInfo['scheme'] = 'com.apple.fairplay';
                this.drmDeviceInfo['type'] = 'fairplay';
        break;
        case 'ie':
        case 'edge':
                this.drmDeviceInfo['licenseUrl'] = 'https://pr-keyos-aps1.licensekeyserver.com/core/rightsmanager.asmx';
                this.drmDeviceInfo['scheme'] = 'com.microsoft.playready';
                this.drmDeviceInfo['type'] = 'playready';
        break;
        default:
                this.drmDeviceInfo['licenseUrl'] = 'https://wv-keyos-aps1.licensekeyserver.com/';
                this.drmDeviceInfo['scheme'] = 'com.widevine.alpha';
                this.drmDeviceInfo['type'] = 'widevine';
        break;
    }
  }

  /*
    Sets up Event Listners to the Player:
    - Append the respective event Listeners to the player
  */
  public addPlayerEventListeners(): any {
    if (this.iOSDevice) {
      this.playerContainer.addEventListener('ready', () => this.onRadiantPlayerReady(event));
      this.playerContainer.addEventListener('error', (e) => {this.onRadiantErrors(), this.updatePlayerState(e)});
    } else {
      let playerTag;
      playerTag = this.player.getVideoElement();
      this.videoAnalyticsService.setPlayer(playerTag);
      this.videoAnalyticsService.createAnalyticSession(this.player, this.videoObject[0], this.resourceUrlConviva);

      this.player.addEventListener(this.player.Event.Core.LOAD_START, () => this.onPlaylistItem());
      this.player.ready().then(() => this.onKalturaPlayerReady(event));
      this.player.addEventListener(this.player.Event.Core.ERROR, (e) => this.onKalturaErrors(e));
      this.player.addEventListener(this.player.Event.UI.UI_VISIBILITY_CHANGED, (e) => this.uiControlsVisibility(e));
    }
  }

  private uiControlsVisibility(event): any {
    // console.log(event, 'uiControlsVisibility', this.getPlayerControlsState());
    this.setPlayerControls(false);
  }

  private updatePlayerState(state): any {
    if (this.iOSDevice) {
      switch (state.type) {
        case 'play':
        case 'playing':
          this.playerState = 'playing';
          break;
        case 'waiting':
          this.playerState = 'buffering';
          break;
        case 'pause':
          this.playerState = 'paused';
          break;
        default:
          this.playerState = 'idle';
          break;
      }
    } else {
      this.playerState = state.payload.newState.type;
    }
    // console.log(state, 'updatePlayerState', this.playerState);
    if (this.playerState !== 'buffering') {
      this.buffering = false;
    }
  }

  private getplayerState(): any {
    return this.playerState;
  }

  public onRadiantPlayerReady(event): any {
    let playerTag;
    playerTag = this.document.getElementsByTagName('video')[0];
    // console.log('conviva', playerTag);
    this.videoAnalyticsService.setPlayer(playerTag);
    this.videoAnalyticsService.createAnalyticSession(this.player, this.videoObject[0], this.resourceUrlConviva);

    this.setPlayerControls(false);
    if (this.error || !this.player) {
      return;
    }
    // this.onKalturaCaptionsList();
    // this.onAudioTracks();

    this.playerContainer.addEventListener('loadedmetadata', () => {this.onPlaylistItem(), this.onAudioTracks()});
    // this.playerContainer.addEventListener('loadedmetadata', () => {this.onPlaylistItem(), this.onlevels(), this.onAudioTracks()});
    this.playerContainer.addEventListener('firstframe', (e) => this.initialization(e));
    this.playerContainer.addEventListener('ended', () => this.onComplete());
    this.playerContainer.addEventListener('waiting', (e) => {this.onBuffer(e), this.updatePlayerState(e);});
    // this.playerContainer.addEventListener('levelswitching', (e) => this.reportPlaybackBitrate());
    this.playerContainer.addEventListener('hlslevelswitched', (e) => this.reportPlaybackBitrate());
    this.playerContainer.addEventListener('seeked', (e) => this.onseeked(e));
    // this.playerContainer.addEventListener('play', (e) => {this.onplay(e), this.updatePlayerState(e)});
    this.playerContainer.addEventListener('playing', (e) => {this.onplay(e), this.updatePlayerState(e)});
    this.playerContainer.addEventListener('pause', (e) => {this.onpause(e), this.updatePlayerState(e)});
    this.playerContainer.addEventListener('timeupdate', (e) => this.updateCurrentTime(e));
    this.playerContainer.addEventListener('adstarted', (e) => {this.onAdPlay(e), this.onAdProgress(e)}); // AD_BREAK_START
    this.playerContainer.addEventListener('adclick', (e) => this.onAdClick(e));
    this.playerContainer.addEventListener('adimpression', (e) => this.onAdImpression(e));
    this.playerContainer.addEventListener('adskipped', (e) => this.onAdSkipped(e));
    this.playerContainer.addEventListener('adcomplete', (e) => this.onAdComplete(e)); // AD_BREAK_END
    this.playerContainer.addEventListener('aderror', (e) => this.onAdError(e));
    this.playerContainer.addEventListener('adloadererror', (e) => this.onAdError(e));
    this.playerContainer.addEventListener('addurationchange', (e) => this.onAdProgress(e));
    this.playerContainer.addEventListener('enterfullscreen', (e) => this.onFullscreenchange(e));
    this.playerContainer.addEventListener('exitfullscreen', (e) => this.onFullscreenchange(e));
    // this.playerContainer.addEventListener(playerCoreEvents.MUTE_CHANGE, (e) => this.onVolumeChange(e));
    this.playerContainer.addEventListener('volumechange', (e) => this.onVolumeChange(e));
    this.playerContainer.addEventListener('destroycompleted', (e) => {this.onDestroyCompleted(), this.updatePlayerState(e)});
    this.playerContainer.addEventListener('autoplaymodedetected', (e) => {console.log(this.player.getAutoplayMode(), 'getAutoplayMode ')});
  }


  private reportPlaybackBitrate(): any {
    // console.log(this.player.getCurrentBitrateIndex(), this.player.getAbrAutoMode(), 'reportPlaybackBitrate');
    let currentBitrate;
    if (!this.player.getAbrAutoMode()) {
      currentBitrate = this.player.getBitrates()[this.player.getCurrentBitrateIndex()].bitrate;
    } else {
      currentBitrate = this.player.getBitrates().filter((i) => i.active)[0].bitrate;
    }
    console.log(currentBitrate);
    if (currentBitrate) {
      this.videoAnalyticsService.reportPlaybackBitrate(currentBitrate);
    }
  }

  public onKalturaPlayerReady(event): any {
    this.setPlayerControls(false);
    if (this.error || !this.player) {
      return;
    }
    let playerCoreEvents;
    playerCoreEvents = this.player.Event.Core;
    this.onKalturaCaptionsList();
    this.onAudioTracks();
    this.onlevels();

    this.player.addEventListener(playerCoreEvents.PLAYER_STATE_CHANGED, (e) => this.updatePlayerState(e));
    this.player.addEventListener(playerCoreEvents.LOADED_DATA, (e) => this.initialization(e));
    this.player.addEventListener(playerCoreEvents.PLAYBACK_ENDED, () => this.onComplete()); // ENDED
    this.player.addEventListener(playerCoreEvents.WAITING, (e) => this.onBuffer(e));
    this.player.addEventListener(playerCoreEvents.VIDEO_TRACK_CHANGED, (e) => this.videoAnalyticsService.reportPlaybackBitrate(e));
    this.player.addEventListener(playerCoreEvents.SEEKED, (e) => this.onseeked(e));
    this.player.addEventListener(playerCoreEvents.PLAY, (e) => this.onplay(e));
    this.player.addEventListener(playerCoreEvents.PAUSE, (e) => this.onpause(e));
    this.player.addEventListener(playerCoreEvents.TIME_UPDATE, (e) => this.updateCurrentTime(e));
    this.player.addEventListener(playerCoreEvents.AD_STARTED, (e) => this.onAdPlay(e)); // AD_BREAK_START
    this.player.addEventListener(playerCoreEvents.AD_CLICKED, (e) => this.onAdClick(e));
    this.player.addEventListener(playerCoreEvents.AD_LOADED, (e) => this.onAdImpression(e));
    this.player.addEventListener(playerCoreEvents.AD_SKIPPED, (e) => this.onAdSkipped(e));
    this.player.addEventListener(playerCoreEvents.AD_COMPLETED, (e) => this.onAdComplete(e)); // AD_BREAK_END
    this.player.addEventListener(playerCoreEvents.AD_ERROR, (e) => this.onAdError(e));
    this.player.addEventListener(playerCoreEvents.AD_PROGRESS, (e) => this.onAdProgress(e));
    this.player.addEventListener(playerCoreEvents.ENTER_FULLSCREEN, (e) => this.onFullscreenchange(e));
    this.player.addEventListener(playerCoreEvents.EXIT_FULLSCREEN, (e) => this.onFullscreenchange(e));
    this.player.addEventListener(playerCoreEvents.MUTE_CHANGE, (e) => this.onVolumeChange(e));
    this.player.addEventListener(playerCoreEvents.VOLUME_CHANGE, (e) => this.onVolumeChange(e));
  }

  private onAdProgress(e): any {
    let displayType;
    displayType = $('.playkit-bottom-bar');
    // displayType = this.iOSDevice ? $('.rmp-fullscreen') : $('.playkit-bottom-bar');
    if (displayType && displayType.css('display') === 'block') {
      displayType.css('display', 'none');
    }
  }

  private onVolumeChange(event): any {
    // console.log('onVolumeChange')
    this.volumeIconChange();
    this.volume = this.getVolume();
    this.volumeCss();
  }

  public onautostartNotAllowed(event): any {
    if (event.reason === 'autoplayDisabled') { // Android firefox
      this.buffering = false;
      this.startPlayback = false;
      this.showBackgroundImage = true;
      $('#PlayerContainer').css('pointer-events', '');
      $('#playerOverlay').css('display', 'none');
    }
  }

  public onAdPlay(event): any {
    // console.log('onAdPlay', event);

    this.videoAnalyticsService.reportAdEvent('start');
    let details;
    details = {
      'event': 'adView',
      'AdName': this.videoAnalyticsService.getRemarketingBlock() ? undefined : this.iOSDevice ? this.player.getAdMediaUrl() : (((event || {}).payload || {}).ad || {}).url, // .title // event.adtitle,
      'AdCategory': '',
      'AdRole': this.iOSDevice ? this.notAvailable : ((event || {}).payload || {}).adType || this.notAvailable, // event.adposition, // event.vmap.breakid adType
      'AdDuration': ((this.videoAdData.type && this.videoAdData.type === 'vpaid') ? event.duration : this.iOSDevice ? this.player.getAdPodInfo().getMaxDuration() : (((event || {}).payload || {}).ad || {}).duration) || this.notAvailable,
      'adViewMeterics': '1',
    };
    this.googleAnalyticPost(details);


    this.showBackgroundImage = false;
    this.setPlayerControls(true);
    this.buffering = false;
    $('#playerOverlay').css('display', 'none');
    if (this.showSignUpPromt || this.popUpFromHeader || this.contentLangPopup) {
      this.pauseVideo();
      this.setPlayerControls(false);
    }
    if (this.showRails) {
      this.hideRails('adplay');
    }
    if ((this.document.fullscreenElement || this.document.webkitFullscreenElement || this.document.mozFullScreenElement || this.document.msFullscreenElement) && !(this.navigator.platform.match(/(iPhone|iPod|iPad)/i) && this.browser.name === 'Safari')) {
      this.fullscreenFromAd = true;
      this.setFullscreen();
    }
  }

  public onAdClick(event): any {
    // console.log('onAdClick');
    let details;
    details = {
      'event': 'AdClick',
      'adclickMetrics': '1',
    };
    this.googleAnalyticPost(details);
  }

  public onAdError(event): any {
    // console.log('onAdError', event, this.player.getAdErrorMessage());
    event.message = this.iOSDevice ? this.player.getAdErrorMessage() : (((((event || {}).payload || {}).data || {}).innerError || {}).g || {}).errorMessage;
    let details;
    details = {
      'event': 'ErrorEvent',
      'ErrorType': 'advertisement', // event.type,
      'ErrorDescription': event.message || '',
      'ErrorTimings': this.getPlayerCurrentTime(),
      'ErrorMetrics': '1',
    };
    this.googleAnalyticPost(details);
    this.updateAdProgressBar('');
    if (this.adDetails) {
      this.videoAnalyticsService.reportAdEvent('end');
      $('#playerOverlay').css('display', 'block');
    }
    this.setPlayerControls(false);

    // let adErrorDetails, playerpos, adType; // Conviva Ad error event
    // playerpos = this.getPlayerCurrentTime();
    // adType = (playerpos === 0 ? 'pre' : (playerpos < this.videoObject[0].duration) ? 'mid' : 'post');
    // adErrorDetails = {
    //   'Ad Error': event.message,
    //   'Ad Type': adType
    // };
    // this.videoAnalyticsService.playerInsightsConviva(this.player, 'Ad Server Error', adErrorDetails);
  }

  public onAdSkipped(event): any {
    // console.log('onAdSkipped');
    this.videoAnalyticsService.reportAdEvent('end');
    let details;
    details = {
      'event': 'AdSkip',
      'adSkipMetrics': '1',
    };
    this.googleAnalyticPost(details);
    this.setPlayerControls(false);
    $('#playerOverlay').css('display', 'block');
    if (this.getPlayerFullscreen() && !(this.navigator.platform.match(/(iPhone|iPod|iPad)/i) && this.browser.name === 'Safari')) {
      this.fullscreenFromAd = true;
      this.setFullscreen();
    }
    // let adDetails;
    // adDetails = {
    //   'Ad ID': ((this.videoAdData.type && this.videoAdData.type === 'vpaid') ? event.id : ((((event || {}).ima || {}).ad || {}).g || {}).adId) || this.notAvailable,
    //   'Ad Name': event.adtitle || this.notAvailable
    // };
    // this.videoAnalyticsService.playerInsightsConviva(this.player, 'Ad Skip', {'Ad Skip': true, ...adDetails});
    // this.videoAnalyticsService.playerInsightsConviva(this.player, 'Ad Completion', {'Ad Completion': false, ...adDetails});  // Conviva Ad complete NO event

  }

  public onAdComplete(event): any {
    // console.log('onAdComplete');
    this.videoAnalyticsService.reportAdEvent('end');
    this.setPlayerControls(false);

    $('#playerOverlay').css('display', 'block');
    if (this.xiaomi) {
      this.volume = this.getVolume() ? this.getVolume() : 0.5;
      this.volumeChange();
    }
    if (this.getPlayerFullscreen() && !(this.navigator.platform.match(/(iPhone|iPod|iPad)/i) && this.browser.name === 'Safari')) {
      this.fullscreenFromAd = true;
      this.setFullscreen();
    }
    // let adDetails;
    // adDetails = {
    //   'Ad ID': ((this.videoAdData.type && this.videoAdData.type === 'vpaid') ? event.id : ((((event || {}).ima || {}).ad || {}).g || {}).adId) || this.notAvailable,
    //   'Ad Name': event.adtitle || this.notAvailable
    // };
    // this.videoAnalyticsService.playerInsightsConviva(this.player, 'Ad Completion', {'Ad Completion': true, ...adDetails});  // Conviva Ad complete YES event
    // this.videoAnalyticsService.playerInsightsConviva(this.player, 'Ad Abandoned', {'Ad Abandoned': false, ...adDetails}); // Conviva Ad Abandoned NO event
    // if (this.videoAdData.type && this.videoAdData.type !== 'vpaid' && ((((event || {}).ima || {}).ad || {}).g || {}).skippable) { // Conviva Ad Skip NO event
    //   this.videoAnalyticsService.playerInsightsConviva(this.player, 'Ad Skip', {'Ad Skip': false, ...adDetails});
    // }
    // this.adDetails = null;
  }

  public onAdImpression(event): any {
    // console.log('onAdImpression', event, this.player.getAdsManager());
    // this.videoAnalyticsService.reportAdEvent('start');
    this.adDetails = event;
    let offset;
    if (this.iOSDevice) {
      offset = '';
      // offset = (this.videoAdData.type && this.videoAdData.type === 'vpaid') ? event.offset : event.ima.ad.g.adPodInfo.timeOffset;
    } else {
      offset = ((this.videoAdData.type && this.videoAdData.type === 'vpaid') ? event.offset : ((((event || {}).payload || {}).extraAdData || {}).adPodInfo || {}).timeOffset) || '';
    }
    this.updateAdProgressBar(offset);
    if (this.xiaomi) {
      this.volume = this.getVolume() ? this.getVolume() : 0.5;
      this.volumeChange();
    }
    // let details;
    // details = {
    //   'event': 'adView',
    //   'AdName': this.videoAnalyticsService.getRemarketingBlock() ? undefined : (((event || {}).payload || {}).ad || {}).url, // .title // event.adtitle,
    //   // 'AdName': this.videoAnalyticsService.getRemarketingBlock() ? undefined : event.tag, // event.adtitle,
    //   'AdCategory': '',
    //   'AdRole': ((event || {}).payload || {}).adType || this.notAvailable, // event.adposition, // event.vmap.breakid adType
    //   'AdDuration': ((this.videoAdData.type && this.videoAdData.type === 'vpaid') ? event.duration : (((event || {}).payload || {}).ad || {}).duration) || this.notAvailable,
    //   'adViewMeterics': '1',
    // };
    // this.googleAnalyticPost(details);
    // let convivaMetaData, assetDeatails, isLive, convivaAdMetaData, convivaAdDefinedMetaData;
    // convivaMetaData = {
    //   'ad': true,
    //   'Ad Id': event.adBreakId ? event.adBreakId : this.notAvailable,
    //   'Ad Name': event.adtitle ? event.adtitle : this.notAvailable,
    //   'Ad Category': this.notAvailable,
    //   'Ad Role': event.adposition ? event.adposition : this.notAvailable, // event.vmap.breakid
    //   'AdDuration': ((this.videoAdData.type && this.videoAdData.type === 'vpaid') ? event.duration : ((((event || {}).ima || {}).ad || {}).g || {}).duration) || this.notAvailable,
    //   'Ad System': event.adsystem ? event.adsystem : this.notAvailable,
    //   'Ad Type': event.creativetype ? event.creativetype : this.notAvailable,
    //   'Ad CreativeId': event.id ? event.id : this.notAvailable,
    //   'Ad CreativeName': event.client ? event.client : this.notAvailable,
    //   'adViewMeterics': '1',
    //   'viewerId': event.adPlayId ? event.client : this.notAvailable,
    //   'streamUrl': event.tag ? event.client : this.notAvailable,
    //   'encodedFrameRate': this.notAvailable
    // };
    // if (this.videoObject[0].type === 'vod') {
    //   isLive = false;
    // } else {
    //   isLive = true;
    // }
    // assetDeatails = {
    //   'asset_name': this.videoObject[0].title ? this.videoObject[0].title : this.notAvailable,
    //   'asset_source': this.videoObject[0].stream_url_dash ? this.videoObject[0].stream_url_dash : this.notAvailable, // streamUrl
    //   'asset_islive': isLive, // false for VOD
    //   'asset_cdn':  this.videoObject[0].content_type ? this.videoObject[0].content_type : this.notAvailable,
    //   'asset_duration': this.videoObject[0].duration ?  this.videoObject[0].duration : this.notAvailable,
    //   'player_name': 'Z5 Web JWPlayer 8.5.6', // although you can update, we recommend to keep the same for new video asset
    //   'viewer_id': this.videoObject[0].id ? this.videoObject[0].id : this.notAvailable, // although you can update, we recommend to keep the same for new video asset
    //   'my_player_name': 'JW Player',
    //   'my_player_DRM': 'Yes',
    //   'customTag1': 'updated_value1',
    //   'customTag2': 'updated_value2'
    // };

    // convivaAdMetaData = {
    //   'assetName': this.videoObject[0].title ? this.videoObject[0].title : this.notAvailable,
    //   'isLive': isLive,
    //   'duration': this.videoObject[0].duration ?  this.videoObject[0].duration : this.notAvailable,
    //   'applicationName': this.notAvailable,
    //   'viewerId': this.videoObject[0].id ? this.videoObject[0].id : this.notAvailable,
    //   'streamUrl': this.notAvailable,
    //   'encodedFrameRate': this.notAvailable
    // };

    // convivaAdDefinedMetaData = {
    //   'c3.ad.technology': this.notAvailable,
    //   'c3.ad.id': event.id ? event.id : this.notAvailable,
    //   'c3.ad.system': event.adsystem ? event.adsystem : this.notAvailable,
    //   'c3.ad.position': event.adposition ? event.adposition : this.notAvailable,
    //   'c3.ad.isSlate': this.notAvailable,
    //   'c3.ad.mediaFileApiFramework': this.notAvailable,
    //   'c3.ad.adStitcher': this.notAvailable,
    //   'c3.ad.unitName': this.notAvailable,
    //   'c3.ad.sequence': this.notAvailable,
    //   'c3.ad.creativeId': ((this.videoAdData.type && this.videoAdData.type === 'vpaid') ? event.creativeId : ((((event || {}).ima || {}).ad || {}).g || {}).creativeId) || this.notAvailable,
    //   'c3.ad.creativeName': this.notAvailable,
    //   'c3.ad.breakId': event.adBreakId ? event.adBreakId : this.notAvailable,
    //   'c3.ad.category': this.notAvailable,
    //   'c3.ad.classification': this.notAvailable,

    //   'c3.ad.advertiser': ((this.videoAdData.type && this.videoAdData.type === 'vpaid') ? '' : ((((event || {}).ima || {}).ad || {}).g || {}).advertiserName) || this.notAvailable,
    //   'c3.ad.advertiserCategory': this.notAvailable,
    //   'c3.ad.advertiserId': this.notAvailable,
    //   'c3.ad.campaignName': this.notAvailable,
    //   'c3.ad.dayPart': this.notAvailable,
    //   'c3.ad.adManagerName': this.notAvailable,
    //   'c3.ad.adManagerVersion': this.notAvailable,
    //   'c3.ad.sessionStartEvent': this.notAvailable
    // };
    // // call Conviva Ad start
    // // let playerInstance;
    // this.videoAnalyticsService.convivaAdMetadataUpdates(this.player, assetDeatails);
    // this.videoAnalyticsService.convivaAdMetaData(this.player, convivaAdMetaData);
    // this.videoAnalyticsService.convivaDefinedAdMetadata(this.player, convivaAdDefinedMetaData);

    // let adServedDetails; // Ad Served Event
    // adServedDetails = {
    //   'Ad served': event.adtitle,
    //   'Ad ID': (this.videoAdData.type && this.videoAdData.type === 'vpaid') ? event.id : ((((event || {}).ima || {}).ad || {}).g || {}).adId,
    //   'Ad Type': event.adposition
    // };
    // this.videoAnalyticsService.playerInsightsConviva(this.player, 'Ad Served', adServedDetails);

    // if (this.checkMoat === true && this.window.moatjw && event && event.ima && event.ima.ad && event.ima.ad.g && event.ima.ad.g.traffickingParameters && event.ima.ad.g.traffickingParameters.indexOf('moatenable=1') >= 0) {
    // // if (this.checkMoat === true && this.window.moatjw && this.videoAdData && this.videoAdData.moat) {
    //   this.currentAdId = this.window.moatjw.add({
    //     partnerCode: 'zeedfpvideo717778523215',
    //     player: this,
    //     adImpressionEvent: event
    //   });
    // }
  }

	public updateAdProgressBar(adTime): any {
		let index;
		if (adTime) {
				index = this.adOffsets.indexOf(adTime) + 1;
		} else {
      if (this.adOffsets.length === 1) {
        index = this.adOffsets[0] < this.getPlayerCurrentTime() ? 1 : -1;
      } else {
        index = this.adOffsets.findIndex(e => e > this.getPlayerCurrentTime());
      }
		}
		this.adOffsets = this.adOffsets.slice(index);
		this.adPoints = this.adPoints.splice(index);
	}

  public onseeked(event): any {
    // console.log('onseeked - here');
    if (this.seekStartTime) {
      let seekEndTime, restartTime, duration, details;
      seekEndTime = new Date().getTime();
      restartTime = Math.round((seekEndTime - this.seekStartTime) / 1000);
      this.seekStartTime = null;
      duration = this.seekEnd - this.seekStart;
      details = {
        'event': 'SeektoRestart',
        'VideoSeekFrom': this.seekStart,
        'VideoSeekto': this.seekEnd,
        'SeekDuration': duration < 0 ? (duration * -1) : duration,
        'SeekRestartTime': restartTime
      };
      this.googleAnalyticPost(details);
    }
    this.updateContinuewatching('');
    this.buffering = false;
    // if (this.bufferValue > this.currentTimePercent) {
      this.isSeeking = false;
    // }
    if (this.ifSeeking()) {
      this.player.pause();
      // this.player.pause(true);
    }
  }

  public updateContinuewatching(videoObject: any): any {
    if (this.watchHistoryApi && this.inHistory) {
      this.updateElapsedTime(videoObject, null);
    } else if (this.watchHistoryApi && !this.inHistory) {
      this.postHistory(videoObject, null);
    }
    this.updateRecoHistory(videoObject, null);
  }

  private updateRecoHistory(videoObject, time): any {
    if (!this.recoWatchHistoryApi) {
      return;
    }
    let duration, type;
    duration = time;
    if (time === null) {
      duration = this.isSeeking ? this.currentTimeSec : (this.player ? this.getPlayerCurrentTime() : 0);
      if (duration < this.continueWatchingTime) {
        return;
      }
    }
    // if (Math.round(time) !== this.updatedRecoHistoryTime) {
      videoObject = videoObject || this.videoObject;
      let object;
      object = {
        'id': (this.videoIsLive || videoObject[0].asset_type === epgAssetType || videoObject[0].asset_type === 9) ? videoObject[0].channel_id : videoObject[0].id,
        'asset_type': videoObject[0].asset_type,
        'duration': Math.floor(duration)
      };
      this.updatedRecoHistoryTime = Math.floor(duration);
      type = this.recoInHistory ? 'Put' : 'Post';
      this['reco' + type + 'HistoryAPI'] = this.recoWatchHistoryApi['v1RecoWatchhistory' + type](object).subscribe(value => {
        this.recoInHistory = (type === 'Post') ? true : this.recoInHistory;
        // this.updatedRecoHistoryTime = Math.floor(time);
        if (this['reco' + type + 'HistoryAPI'] !== null) {
          this['reco' + type + 'HistoryAPI'].unsubscribe();
        }
        if (value && value.meta && value.meta.dmpSync) {
          this.recoDmpSync = true;
        }
      },
      err => {
        this.recoInHistory = (type === 'Post') ? false : this.recoInHistory;
        this.videoService.apiErrorEvent(err);
        if (this['reco' + type + 'HistoryAPI'] !== null) {
          this['reco' + type + 'HistoryAPI'].unsubscribe();
        }
      });
    // }
  }

  public onplay(event): any {
    // console.log('onplay - here');
    // if ($('.jw-open').length) {
    //   $('.jw-open').removeClass('jw-open');
    // }
    if (this.getPlayerControlsState() && !this.iOSDevice) { // not when radiant player controls are enabled
    // if (this.getPlayerControlsState()) {
      this.setPlayerControls(false);
      $('#playerOverlay').css('display', 'block');
    }
    if (this.showSignUpPromt || this.popUpFromHeader || this.contentLangPopup ) {
      this.pauseVideo();
      return;
    }
    if (this.playPause === this.play) {
      this.playPause = this.pause;
    }
    // this.replay = false;
    this.showBackgroundImage = false;
    this.replayState(false);
    this.buffering = false;
    this.isSeeking = false;
    // this.startPlayback = false
    if (this.videoPaused) {
      this.videoPaused = false;
      let details;
      details = {
        'event': 'VideoResume',
        'ResumMetrics': '1'
      };
      this.googleAnalyticPost(details);
    }
    if (this.error) {
      this.error = false;
    }
    // if (this.checkMoat === true && this.window.moatjw) {
    //   this.window.moatjw.removeAll();
    // }
    this.pausedByUser = false;
    this.adDetails = null;
  }

  public signInCheck(type): any {
    if (!this.token) {
      if (this.countryListData && this.countryListData.length !== 0) {
        if (this.countryListData[this.countrycodeIndex] && this.countryListData[this.countrycodeIndex].signup_events[type] === true) {
          this.showSignUpPromt = !this.error;
        }
      } else if (this.configData && this.configData.signup_events && this.configData.signup_events[type] === true) {
          this.showSignUpPromt = !this.error;
        }
    }
  }

  public onpause(event): any {
    // console.log('onpause');
    this.videoPaused = true;
    if (!this.videoService.enableCastView) {
      this.signInCheck('video_pause');
    }
    if (this.playPause === this.pause) {
      this.playPause = this.play;
    }
    let details;
    details = {
      'event': 'VideoPause',
      'PauseMetrics': '1'
    };
    this.googleAnalyticPost(details);
    this.updateContinuewatching('');
  }

  public onBuffer(event): any {
    // console.log('onBuffer - here')
    let network;
    network = this.networkStatus === 'offline' ? false : true;
    if (!network) {
      this.showErrorState(noNetworkText);
      return;
    } else {
      this.buffering = true;
      this.error = false;
    }
    this.replay = false;
    // this.replayState(false)
  }

  public onComplete(): any {
    // console.log('onComplete');
    this.videoCompleted = true;
    this.postGAwatchDuration(this.videoObject);
    this.videoAnalyticsService.updateMetaTags(this.player, 'videoEndPoint', this.currentTime);
    this.videoAnalyticsService.clearAnalyticSession();
    this.sendToLotame(true);
    this.qgPlayed(this.videoObject);
    // if (environment.charmboard && this.videoObject[0].content_type === 'episode' && this.window.destroyCBplugin) {
    //   destroyCBplugin();
    // }
    this.destroyPeer5();
    this.showBackgroundImage = true;
    this.currentTime = '00:00';
    this.totalTime = '00:00';
    this.thumbnailTime = '';
    this.tooltip_thumbnail = '';
    this.hideThumbnail(0);
    $('#livetime').text(this.currentTime + '/' + this.totalTime);
    this.currentTimePercent = 0;
    this.totalTimeMS = 0;
    this.bufferValue = 0;
    this.gaWatchPercent = 0;
    this.gaCounter = 0;
    this.previousTime = 0;
    // this.passedGAWatchDuration = 0;
    this.progressCss();
    this.buffering = false;
    this.showSkipIntro = false;
    this.showSkipRecap = false;
    if (this.videoObject[0].asset_type === epgAssetType && !this.videoIsLive) {
      this.epg.gonext(true);
    }
    if (!(this.videoIsLive || this.videoObject[0].type === 'live') && (!this.token || (this.token && this.videoService.getSpecificSubscription(this.videoObject[0].asset_type, this.videoObject[0].audio_languages) === -1))) {
      let asset_type;
      asset_type = this.videoObject[0].asset_type.toString();
      asset_type = (asset_type === '1') ? '6' : asset_type;
      if (this.videoObject[0].parent_business_type && this.videoObject[0].parent_business_type.indexOf('premium') !== -1 && this.configData && this.configData.subscription_popup && this.configData.subscription_popup.asset_subtype && this.configData.subscription_popup.asset_subtype.indexOf(this.videoObject[0].content_type.toLowerCase()) !== -1) {
      // if (this.videoObject[0].parent_business_type.indexOf('premium') !== -1 && this.videoObject[0].content_type.toLowerCase().match(/trailer|promo|preview/i)) {
        this.headerService.premium = true;
        this.showPopUpOnComplete = !this.error;
        this.showSignUpPromt = !this.error;
        this.premiumParent.emit(true);
      } else if (this.videoObject[0].content_type === 'trailer' && this.headerService.premium) {
        this.showPopUpOnComplete = !this.error;
        this.showSignUpPromt = !this.error;
      }
    }
    clearTimeout(this.controlsTimer);
    if (this.watchHistoryApi && this.videoObject[0].id && this.videoObject[0].asset_type >= 0) {
      let id, asset_type;
      id = this.videoObject[0].id;
      asset_type = this.videoObject[0].asset_type;
      this.deleteHistory = this.watchHistoryApi.v1WatchhistoryDelete(id, asset_type).subscribe(value => {
        // this.videoService.toggleHistoryStatus(true);
        this.inHistory = false;
        this.deletedInHistory = true;
        if (this.deleteHistory !== null) {
          this.deleteHistory.unsubscribe();
        }
      }, err => {
        this.videoService.apiErrorEvent(err);
        if (this.deleteHistory !== null) {
          this.deleteHistory.unsubscribe();
        }
      });
    }
    if (this.player) {
      if (this.iOSDevice) {
        this.player.stop();
      } else {
        this.player.reset();
      }
    }
    if (this.autoplay && this.enableAutoplay && !this.showSignUpPromt && !this.showPopUpOnComplete && !this.contentLangPopup) {
      this.autoplayNext();
      $('#playerControlsBar').css('pointer-events', 'none');
      $('#playerHeaderBar').css('pointer-events', 'none');
      $('#forward1').css('pointer-events', 'none');
      $('#rewind1').css('pointer-events', 'none');
    } else {
      this.videoService.autoPlayed('');
      this.signInCheck('video_end');
      this.replayState(true);
      this.playPause = this.play;
      if (this.nextData && this.nextData[0]) {
        if (this.showRails) {
          this.railData.watchCredits = false;
        } else if (this.videoObject[0].content_type === 'episode' || this.commonService.getCollectionId()) {
          this.showrails(false, this.nextData, false, true);
        } else {
          this.showrails(false, this.nextData, false, false);
        }
      }
    }
    if (this.videoObject[0].audio_languages[0]) {
      this.settingsService.callContentLangFunction(this.videoObject[0].audio_languages[0], 'videoDestroy');
      this.contentPopup = true;
    }
  }

  public autoplayNext(): any {
    if ((this.nextData[0].id === this.videoObject[0].id) || ((this.showPage && (this.nextData[0].id === this.videoObject[0].series_id)))) {
      setTimeout(() => {
        this.videoService.autoPlayed(this.videoObject[0].title_en);
        this.initializeOnVideoObjectChange();
        this.checkForAES();
        this.checkVideoInit(false);
      }, 0);
    } else {
      this.commonService.setTalamoosData('', '', '');
      this.videoService.autoPlayed(this.videoObject[0].title_en);
      this.commonService.changeContent(this.nextData[0]);
      this.videoService.clearContentClickDetails();
    }
  }

  public replayState(state: boolean): any {
    this.replay = state;
    if (state) {
      $('#playerControlsBar').css('pointer-events', 'none');
      $('#playerHeaderBar').css('pointer-events', 'none');
      $('#forward1').css('pointer-events', 'none');
      $('#rewind1').css('pointer-events', 'none');
    } else {
      $('#playerControlsBar').css('pointer-events', '');
      $('#playerHeaderBar').css('pointer-events', '');
      $('#forward1').css('pointer-events', '');
      $('#rewind1').css('pointer-events', '');
    }
  }
  public onRadiantErrors(): any {
    let event;
    event = this.player.getErrorData();
    if (this.networkStatus === 'offline' || !this.navigator.onLine) {
      event.message = noNetworkText;
    }
    if (!this.unsupported) {
      // if (!(event.message === 'Captions failed to load')) {
        this.playPause = this.play;
        this.showErrorState(event.message);
      // }
    }
  }

  public onKalturaErrors(event): any {
    // console.log('onErrors', event, this.networkStatus, this.navigator.onLine);
    if (this.networkStatus === 'offline' || !this.navigator.onLine) {
      event.message = noNetworkText;
    }
    if (!this.unsupported) {
      let errorUrl;
      errorUrl = (((event || {}).payload || {}).data || {}).url || '';
      if (errorUrl.indexOf('.vtt') === -1) {
        this.playPause = this.play;
        let msg;
        msg = event.message ? event.message : (((event || {}).payload || {}).data || {}).name;
        this.videoAnalyticsService.reportErrorEvent(msg);
        this.showErrorState(msg);
      } else {
        this.playerState = this.player.State.PLAYING;
      }
    }
  }

  public tryAgain(): any {
    this.tryagain = false;
    this.error = false;
    this.checkVideoInit(false);
    $('#playerOverlay').css('display', 'block');
    this.fontResize();
  }

  public onSetupErrors(event): any {
    // console.log(event, 'onSetupErrors')
    this.buffering = false;
    this.showErrorState(event.message);
    // this.showErrorState(event.code + ' ' + event.message);
  }

  public setCanonicalUrl(): any {
    let title, episode;
    title = this.videoObject[0].title_en || this.videoObject[0].title;
    episode = this.videoObject[0].episode_name_en || this.videoObject[0].episode_name;
    if (this.videoObject[0].category === 'tvshow') {
      this.canonical = this.window.location.origin + '/' + this.routeservice.getBaseLocation() + this.videoObject[0].category + 's/details' + '/' + this.commonService.convertToLowercase(title) + '/' + this.videoObject[0].series_id + '/' + this.commonService.convertToLowercase(episode) + '/' + this.videoObject[0].id;
    } else if (this.videoObject[0].category === 'original') {
      this.canonical = this.window.location.origin + '/' + this.routeservice.getBaseLocation() + 'zee5original' + 's/details' + '/' + this.commonService.convertToLowercase(title) + '/' + this.videoObject[0].series_id + '/' + this.commonService.convertToLowercase(episode) + '/' + this.videoObject[0].id;
    } else if (this.videoObject[0].category === 'movie' || this.videoObject[0].category === 'video') {
      this.canonical = this.window.location.origin + '/' + this.routeservice.getBaseLocation() + this.videoObject[0].category + 's/details' + '/' + this.commonService.convertToLowercase(title) + '/' + this.videoObject[0].id;
    } else if (this.videoObject[0].category === 'Live TV' ) {
      this.canonical = this.window.location.origin + '/' + this.routeservice.getBaseLocation() + this.videoObject[0].share_url;
    }
  }

  public setVideoCount(): any {
    let localVideoCount;
    localVideoCount = this.localStorage.getItem('video_count');
    if (localVideoCount) {
      localVideoCount = parseInt(localVideoCount, 10);
    } else {
      localVideoCount = 0;
    }
    this.localStorage.setItem('video_count', ++localVideoCount);
    this.GAvideoClick('first');
    if (this.configData && this.configData.video_views_events && this.configData.video_views_events.length > 0) {
      let countIndex;
      countIndex = $.grep(this.configData.video_views_events, function(e) {
        return e.video_count === localVideoCount;
      });
      if (countIndex && countIndex.length > 0) {
        this.sendGAvideoCount(countIndex[0].event_name);
      /* videoview event for qgraph */
      this.qgraphevent(countIndex[0].event_name, {'video_name': (this.videoObject[0].title_en || this.notAvailable), 'genre': this.videoObject[0].genre , 'language': this.selectedAudioqg, 'sections': this.videoService.getQGsection(this.videoObject[0]), 'country': this.country , 'image': this.background });
      /* videoview event for qgraph */
      }
    }
  }

  public sendGAvideoCount(event_name): any {
    let details;
    this.userAccessType = this.getUserAccessType();
    details = {
      'event': event_name,
      'country_id': this.country,
      'ClickMetrics': 1,
      'Business_Type': this.videoObject[0].business_type.indexOf('premium') !== -1 ? 'Premium' : 'Free',
      'User_Access_Type': this.userAccessType,
      'AudLan': (this.videoObject[0].audio_languages && this.videoObject[0].audio_languages.length) ? this.gaFirstAPIAudioLang : this.notAvailable,
      'content_language': this.getUserContentlang(),
      'qualityChoice': this.selectedBitrate ? this.selectedBitrate : this.notAvailable,
      'autoPlay': this.autoplay ? 'on' : 'off'
    };
    details = $.extend({}, details, this.talamoosData);
    this.googleAnalyticPost(details);
  }

  private getUserContentlang(): any {
    let languages_api;
    if (this.token) {
      languages_api = localStorage.getItem('UserContentLanguage');
    } else {
      languages_api = localStorage.getItem('ContentLang');
    }
    return this.videoService.getLang(languages_api);
  }

  public GAvideoClick(instance): any {
    let details, autoPlayed, localVideoCount;
    localVideoCount = this.localStorage.getItem('video_count');
    this.userAccessType = this.getUserAccessType();
    details = {
      'event': 'VideoClicks',
      'userCountry': this.sub.getCountryName(),
      'ClickMetrics': 1,
      'Business_Type': this.videoObject[0].business_type.indexOf('premium') !== -1 ? 'Premium' : 'Free',
      'User_Access_Type': this.userAccessType,
      'AudLan': (this.videoObject[0].audio_languages && this.videoObject[0].audio_languages.length) ? this.gaFirstAPIAudioLang : this.notAvailable,
      'ViewCounts': localVideoCount,
      'qualityChoice': this.selectedBitrate ? this.selectedBitrate : this.notAvailable,
      'autoPlay': this.autoplay ? 'on' : 'off'
    };
    if (instance === 'next' || (this.videoIsLive && this.videoService.instance > 1)) {
      details.videoCTR = 'secondcall';
    }
    autoPlayed = this.videoService.autoPlayed('');
    if (autoPlayed) {
      details.Previous_Video = autoPlayed;
    }
    details = $.extend({}, details, this.talamoosData);
    this.googleAnalyticPost(details);
  }

  public getUserAccessType(): any {
    let active, expired;
    if (!this.token) {
      return 'Free';
    } else {
      active = this.sub.checkPlanApiSuccess(false);
      if (active && active.length > 0) {
        return 'Premium';
      } else {
        expired = this.sub.getAllHistoryPlan();
        return (expired && expired.length) > 0 ? 'Expired' : 'Free';
      }
    }
  }

  public onPlaylistItem(): any {
    // console.log('onPlaylistItem - loadeddata');
    if (this.iOSDevice && this.advertisement) {
      this.player.play(true);
    }
    this.volume = this.getVolume() ? this.getVolume() : 0.5;
    this.volumeIconChange();
    this.volumeCss();
    if (this.navigator.userAgent.match(/mobile|iPhone|iPod|iPad/i) && this.startPlayback) {
      this.showBackgroundImage = false;
    }
    this.titleText = this.videoObject[0].title || 'Not Available';
    // this.titleText = this.videoObject[0].episode_name || this.videoObject[0].title || 'Not Available';
    if (this.startPlayback) {
      $('#playerOverlay').css('display', 'block');
    }
    this.ld_playbackEvent();
    if (!(this.headerService.premium && this.videoObject[0].asset_type === 0 && (!this.token || (this.token && this.videoService.getSpecificSubscription(this.videoObject[0].asset_type, this.videoObject[0].audio_languages) === -1)))) {
      this.linkservice.addTag({ rel: 'canonical', href: this.canonical} );
    }
    this.watched = this.userProfile.inList('watchList', this.videoObject[0].id);
    this.favorite = this.userProfile.inList('favorite', this.videoObject[0].id);
    let streamProtocol;
    if (this.resourceUrl.indexOf('.m3u8') >= 0) {
      streamProtocol = 'HLS';
    } else if (this.resourceUrl.indexOf('.mpd') >= 0) {
      streamProtocol = 'DASH';
    }
    this.videoAnalyticsService.updateMetaTags(this.player, 'streamProtocol', streamProtocol);
    $('#PlayerContainer').css('pointer-events', '');
    $('#playerInfoSection').css('pointer-events', '');
    $('#playerControlsBar').css('pointer-events', 'none');
    $('#playerHeaderBar').css('pointer-events', 'none');
    $('#forward1').css('pointer-events', 'none');
    $('#rewind1').css('pointer-events', 'none');
    // this.videoAnalyticsService.createAnalyticSession(this.player, this.videoObject[0], this.resourceUrlConviva); // commented for kaltura
    this.replay = false;
    this.getAudioLanguages();
    this.settingLength = (this.settingsControlLength() && $('#playerHeaderBar') && $('#playerHeaderBar')[0] && $('#playerHeaderBar')[0].style.visibility === 'visible') ? 'visible' : 'hidden'; // changed coz icon displayed when controls were hidden
  }

  public getAudioLanguages(): any {
    if (!this.videoObject[0].audio_languages || !this.videoObject[0].audio_languages.length) {
      return;
    }
    let language, gaAudioLanguages, counter;
    counter = 0;
    gaAudioLanguages = '';
    for (let i = 0; i < this.videoObject[0].audio_languages.length; i++) {
      language = this.languages.findIndex(index => index.id === this.videoObject[0].audio_languages[i]);
      if (i === 0) {
        this.gaFirstAPIAudioLang = (language !== -1) ? this.languages[language].name : 'Audio Language 1';
      }
      if (language !== -1) {
        gaAudioLanguages += (i !== 0 ? ',' : '') + this.languages[language].name;
      } else {
        gaAudioLanguages += (i !== 0 ? ',' : '') + 'Audio Language ' + (++counter);
      }
    }
    this.audioLangsString = gaAudioLanguages;
    this.selectedAudioqg = this.gaFirstAPIAudioLang;
    this.selectedAudioString = this.gaFirstAPIAudioLang;
    this.videoAnalyticsService.updateMetaTags(this.player, 'audioLanguage', this.selectedAudioqg);
  }

	public getHistory(): any {
	  let scope, show;
	  scope = this;
	  this.userapiService.checkWatchHistory().takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
	    if (value && value.code === 401) {
	      this.videoService.apiErrorEvent(value);
	      return;
	    }
	    this.historyRetryCount = 1;
	    show = $.grep(value, function(e) {
	      return e.id === scope.videoObject[0].id;
	    });
	    scope.replayOrPlay(show);
	  }, err => {
	    this.videoService.apiErrorEvent(err);
	    if (err.status === 401 && this.historyRetryCount < this.apiRetry) {
	      this.historyRetryCount ++;
	      this.commonService.refreshToken().then(
	        () => {
	          this.getHistory();
	        });
	    } else {
	      scope.replayOrPlay(null);
	    }
	  });
	}
  public replayOrPlay(show: any): any {
    if (show && show.length) {
      this.inHistory = true;
			this.currentTimeSec = show[0].played_duration;
    } else {
      this.currentTimeSec = 0;
      this.inHistory = false;
    }
  }

  public postHistory(videoObject, time): any {
    let duration = time;
    if (time === null) {
      duration = this.isSeeking ? this.currentTimeSec : (this.player ? this.getPlayerCurrentTime() : 0);
      // if (!duration) {
      if (duration < this.continueWatchingTime) {
        return;
      }
    }
    if (!videoObject) {
      videoObject = this.videoObject;
    }
    let object;
    object = {
      'id': videoObject[0].id,
      'asset_type': videoObject[0].asset_type,
      'duration': Math.floor(duration)
    };
    this.postHistoryAPI = this.watchHistoryApi.v1WatchhistoryPost(object).subscribe(value => {
      this.inHistory = true;
      // this.videoService.toggleHistoryStatus(true);
      if (this.postHistoryAPI !== null) {
        this.postHistoryAPI.unsubscribe();
      }
    },
    err => {
      this.inHistory = false;
      this.videoService.apiErrorEvent(err);
      if (this.postHistoryAPI !== null) {
        this.postHistoryAPI.unsubscribe();
      }
      if (err && err._body) {
        let error;
        error = JSON.parse(err._body);
        if (error.code === 2311 && error.message === 'Item already exists') {
          this.inHistory = true;
        } else {
          this.watchHistoryApi = undefined;
        }
      } else if (err && err.name !== 'TimeoutError') {
        this.watchHistoryApi = undefined;
      }
    });
  }

  public videoReplay(): any {
    this.replay = false;
    this.isSeeking = false;
    let details;
    details = {
      'event': 'VideoReplay',
      'ReplayMetrics': '1',
      'Business_Type': this.videoObject[0].business_type.indexOf('premium') !== -1 ? 'Premium' : 'Free',
      'User_Access_Type': this.userAccessType
    };
    this.googleAnalyticPost(details);
    this.initializeOnVideoObjectChange();
    this.checkForAES();
    this.checkVideoInit(true);
  }

  public ld_playbackEvent(): any {
    while (document.getElementById('videodetailsMarkup').hasChildNodes()) {
      document.getElementById('videodetailsMarkup').removeChild(document.getElementById('videodetailsMarkup').lastChild);
    }
    const json_ld = {
      '@context': 'http://schema.org',
      '@type': 'VideoObject',
      'name': this.videoObject[0].episode_name_en || this.videoObject[0].episode_name || this.videoObject[0].title_en || this.videoObject[0].title || this.notAvailable,
      'description': this.videoObject[0].description,
      'thumbnailUrl': this.background,
      'uploadDate': this.videoObject[0].release_date,
      'duration': this.videoObject[0].duration,
      'contentUrl': this.contentUrl
      // 'embedUrl': '',
      // 'interactionCount': ''
    };
    if (this.videoObject[0].business_type.indexOf('premium') === -1) {
      json_ld['embedUrl'] = environment.shareUrl + 'embed/' + this.videoObject[0].id;
    }

    let script;
    script = this.document.createElement('script');
    script.id = 'schema';
    script.type = 'application/ld+json';
    script.innerHTML = JSON.stringify(json_ld);
    this.document.getElementById('videodetailsMarkup').appendChild(script);
  }

  public initialization(event): any {
    // console.log('initialization - ')
    this.playerRead.emit(true);

    this.showBackgroundImage = false;
    this.ebvs = false;
    // this.GAvideoClick('first');
    this.setVideoCount();
    if (this.xiaomi && !this.muteLaunch) {
      this.volume = this.getVolume() ? this.getVolume() : 0.5;
      this.volumeChange();
    }
    $('#playerControlsBar').css('pointer-events', '');
    $('#playerHeaderBar').css('pointer-events', '');
    $('#forward1').css('pointer-events', '');
    $('#rewind1').css('pointer-events', '');
     this.qgraphevent('video_play', {'video_name': (this.videoObject[0].title_en || this.notAvailable), 'genre': this.videoObject[0].genre , 'language': this.selectedAudioqg, 'sections': this.videoService.getQGsection(this.videoObject[0]), 'country': this.country , 'image': this.background });
    this.totalTimeMS = this.iOSDevice ? this.player.getDuration() : this.player.duration;
    if (this.iOSDevice) {
      let startTime;
      startTime = this.getStartTime();
      if (startTime) {
        this.skip(startTime, '');
      }
    }
    if (this.videoIsLive === true || this.totalTimeMS === Infinity) {
      this.currentTimePercent = 100;
      this.progressCss();
    } else {
      this.totalTime = this.updateTime(this.totalTimeMS);
      this.adProgress();
    }
    if (this.iOSDevice) {
      this.onRadiantCaptionsList();
    }
    this.fontResize();
    if (!this.token && this.videoViewCounter !== null) {
      if (this.videoViewCounter !== 0) {
        --this.videoViewCounter;
        this.settingsService.setVideoCounter(this.videoViewCounter);
      }
      if (this.videoViewCounter === 0) {
        this.showVideoViewSignup = true;
      }
      if (this.videoViewCounter < 0) {
        this.videoViewCounter = this.videoViewBuffer;
        this.settingsService.setVideoCounter(this.videoViewCounter);
      }
    }
    this.languagepopupCount();
    // this.videoAnalyticsService.playerInsightsConviva(this.player, 'Video Received', {'CDN Delivery': true});
  }

  public languagepopupCount() {  // content lang popup to display taking from api
    let language_popup, language_popupValue, count, getlocalCount, videoLang;
    count = 1;
    videoLang = this.videoObject[0].audio_languages[0];
    language_popup  = this.countryListData && this.countryListData[0].content_language_popup && this.countryListData[0].content_language_popup.web_app ? this.countryListData[0].content_language_popup.web_app.content_language_popup : undefined;
    if (language_popup !== undefined) {
            if (language_popup === 0) {         // if its 0 no popup
              this.settingsService.Languagepopupvalue(false);
            } else if (language_popup === 1) {      // 1 then Pop up should appear on every click of other language content
              this.settingsService.Languagepopupvalue(true);
            } else if (language_popup > 1) {         // if x after x times popup appears
                language_popupValue = {
                 'lang': videoLang,
                 'count': count
                };
                getlocalCount = JSON.parse(localStorage.getItem('language_popup'));
                if (getlocalCount === null) {
                    localStorage.setItem('language_popup', JSON.stringify(language_popupValue));  // first time if no values store count as 0
                } else {
                  if (getlocalCount.lang === videoLang && getlocalCount.count < language_popup) {  // less then the api value increment count and store
                      this.settingsService.Languagepopupvalue(false);
                      language_popupValue = {
                       'lang': videoLang,
                       'count': ++getlocalCount.count
                      };
                      if (getlocalCount.count === language_popup) {
                        this.settingsService.Languagepopupvalue(true);
                      } else {
                        this.settingsService.Languagepopupvalue(false);
                      }
                      localStorage.setItem('language_popup', JSON.stringify(language_popupValue));
                  } else if (getlocalCount.lang === videoLang && getlocalCount.count === language_popup){ // if count is equall to api value then show popup and restcount
                        this.settingsService.Languagepopupvalue(false);
                      language_popupValue = {
                       'lang': videoLang,
                       'count': 1
                      };
                      localStorage.setItem('language_popup', JSON.stringify(language_popupValue));
                  } else {
                    this.settingsService.Languagepopupvalue(false);
                      language_popupValue = {
                       'lang': videoLang,
                       'count': count
                      };
                    localStorage.setItem('language_popup', JSON.stringify(language_popupValue));
                  }
              }
        }
  }
}
  public adProgress(): any {
    if (this.adOffsets && this.adOffsets.length > 0 && this.totalTimeMS) {
      this.adPoints = [];
      let percent;
      for (let i = 0; i < this.adOffsets.length; i++) {
        if (this.adOffsets[i] < this.totalTimeMS) {
          percent = this.adOffsets[i] * 970 / this.totalTimeMS;
          this.adPoints.push(percent);
        }
      }
      this.adVisible = true;
    }
  }

  public updateElapsedTime(videoObject, time): any {
    let duration = time;
    if (time === null) {
      duration = this.isSeeking ? this.currentTimeSec : (this.player ? this.getPlayerCurrentTime() : 0);
      // if (!duration) {
      if (duration < this.continueWatchingTime) {
        return;
      }
    }
    if (!videoObject) {
      videoObject = this.videoObject;
    }
    let object;
    object = {
      'id': videoObject[0].id,
      'asset_type': videoObject[0].asset_type,
      'duration' : Math.floor(duration),
    };
    this.updatedHistoryTime = Math.floor(duration);
    this.putHistoryAPI = this.watchHistoryApi.v1WatchhistoryPutWithHttpInfo(object).subscribe( value => {
      // this.videoService.toggleHistoryStatus(true);
      if (this.putHistoryAPI !== null) {
        this.putHistoryAPI.unsubscribe();
      }
    },
    err => {
        this.videoService.apiErrorEvent(err);
        if (this.putHistoryAPI !== null) {
          this.putHistoryAPI.unsubscribe();
        }
    });
  }

  public onRadiantCaptionsList(): any {
    let captionList;
    captionList = this.player.getCaptionsList();
    this.captionLanguages = captionList && captionList.length > 0 ? captionList.map(x => {x['label'] = x[1]; return x;}) : undefined;
    if (this.captionLanguages) {
      let currentCaption;
      currentCaption = this.player.getCCVisibleLanguage();
      if (currentCaption !== 'off') {
        currentCaption = this.captionLanguages.filter((i) => currentCaption === i[0]);
        this.selectedCC = currentCaption ? currentCaption[0][1] : '';
        this.subtitleState = true;
        this.subtitleStateText = 'TVGUIDE.ON';
        this.videoAnalyticsService.updateMetaTags(this.player, 'Subtitles', 'ON');
      } else {
        this.selectedCC = 'Off';
        this.subtitleStateText = 'TVGUIDE.OFF';
        this.subtitleState = false;
        this.videoAnalyticsService.updateMetaTags(this.player, 'Subtitles', 'OFF');
      }
    }
    if (this.captionLanguages && this.captionLanguages.length > 0) {
      this.hasClosedCaptions = 'visible';
    }
  }

  public onKalturaCaptionsList(): any {
    let captionList, type;
    // captionList = this.player.getCaptionsList();
    type = this.player.Track.TEXT;
    captionList = this.player.getTracks(type);
    this.captionLanguages = captionList && captionList.length > 0 ? captionList.slice(0, captionList.length - 1) : undefined;
    // this.captionLanguages = captionList && captionList.length > 1 ? captionList.slice(1) : undefined;
    // console.log('onCaptionsList', captionList, this.captionLanguages);
    if (this.captionLanguages) {
      let currentCaption;
      // currentCaption = this.player.getCurrentCaptions();
      currentCaption = this.player.getActiveTracks()[type];
      this.selectedCC = currentCaption ? currentCaption.label : 'Off';
      // this.selectedCC = captionList[currentCaption].label;
      if (currentCaption && currentCaption.label !== 'Off') {
      // if (currentCaption > 0) {
        this.subtitleState = true;
        this.subtitleStateText = 'TVGUIDE.ON';
        this.videoAnalyticsService.updateMetaTags(this.player, 'Subtitles', 'ON');
      } else if (currentCaption && currentCaption.label === 'Off') {
      // } else if (currentCaption === 0) {
        this.subtitleStateText = 'TVGUIDE.OFF';
        this.subtitleState = false;
        this.videoAnalyticsService.updateMetaTags(this.player, 'Subtitles', 'OFF');
      }
    }
    if (this.captionLanguages && this.captionLanguages.length > 0) {
      this.hasClosedCaptions = 'visible';
    }
  }

    public onAudioTracks(event: any = undefined): any {
    // console.log('onAudioTracks');
    this.jwAudioLanguageString = [];
    this.audioLanguages = [];
    let type;
    type = this.iOSDevice ? '' : this.player.Track.AUDIO;
    this.audioLanguages = (this.iOSDevice ? this.player.getAudioTracks() : this.player.getTracks(type)) || [];
    if (this.audioLanguages && this.audioLanguages.length) {
      let currentAudio, language;
      currentAudio = this.iOSDevice ? this.audioLanguages.filter((i) => i.active)[0] || {} : this.player.getActiveTracks()[type];
      this.selectedAudio = (currentAudio && currentAudio.language) ? currentAudio.language : '';
      this.unknownAudioCounter = 0;
      for (let i = 0; i < this.audioLanguages.length; i++) {
        language = this.languages.findIndex(index => index.id === this.audioLanguages[i].language);
        if (language !== -1) {
          this.jwAudioLanguageString.push(this.languages[language].name);
        } else {
          this.jwAudioLanguageString.push('Audio Language ' + (++this.unknownAudioCounter));
        }
      }
      // this.selectedAudioqg = this.jwAudioLanguageString[currentAudio];
      this.selectedAudioString = (this.audioLanguages && this.audioLanguages.length > 1 && currentAudio >= 0) ? this.jwAudioLanguageString[currentAudio] : this.gaFirstAPIAudioLang;
      this.videoAnalyticsService.updateMetaTags(this.player, 'audioLanguage', this.jwAudioLanguageString[currentAudio]);
    }
  }

  public onlevels(): any {
    this.mediaProfiles = [];
    let profiles, track;
    if (this.iOSDevice) {
      profiles = this.player.getBitrates();
      let index;
      index = this.player.getCurrentBitrateIndex();
      // console.log(index);
      if (index !== -1) {
        track = profiles[index];
        this.selectedQuality = track.height + 'p';
      } else {
        track = profiles.filter((i) => i.active)[0] || {};
        this.selectedQuality = 'Auto';
      }
      this.mediaProfiles.push({active: false, bitrate: undefined, height: undefined, label: 'Auto', id: -1, width: undefined});
    } else {
      let type;
      type = this.player.Track.VIDEO;
      track = this.player.getActiveTracks()[type];
      this.selectedQuality = this.player.isAdaptiveBitrateEnabled() ? 'Auto' : track ? track.label : 'Auto';
      if (!this.player.isAdaptiveBitrateEnabled() && this.selectedQuality === 'Auto') {
        this.player.enableAdaptiveBitrate();
      }
      profiles = this.player.getTracks(type);
      this.mediaProfiles.push({bandwidth: undefined, label: 'Auto', width: undefined, height: undefined});
    }
    /*removing duplicate quality levels*/
    for (let l = 0; l < profiles.length; l++) {
      if (this.mediaProfiles.findIndex(i => i.label === profiles[l].label) === -1) {
        profiles[l].label = profiles[l].height + 'p'
        this.mediaProfiles.push(profiles[l]);
      }
    }
    if (this.mediaProfiles) {
      if (this.mediaProfiles.length === 1 && this.mediaProfiles[0].label !== 'Auto') {
        this.mediaProfiles = [];
      } else {
        let selectedProfileIndex;
        selectedProfileIndex = this.matchQuality();
        // this.changeMediaQuality(selectedProfileIndex);
        if (selectedProfileIndex) {
          // this.changeMediaQuality(this.mediaProfiles[selectedProfileIndex]);
          this.changeMediaQuality(selectedProfileIndex);
        }
      }
    }
    // console.log('onlevels', this.mediaProfiles, profiles, track);
    this.videoAnalyticsService.reportPlaybackBitrate(track.bitrate || track.bandwidth);
    this.videoAnalyticsService.updateMetaTags(this.player, 'playbackQuality', this.selectedQuality);
    this.settingLength = (this.settingsControlLength() && $('#playerHeaderBar')[0].style.visibility === 'visible') ? 'visible' : 'hidden'; // changed coz icon displayed when controls were hidden
  }

  public matchQuality(): any {
    let mediaProfiles;
    mediaProfiles = this.mediaProfiles.slice(1);
    for (let i = 0 ; i < mediaProfiles.length;  i++) {
      if ( mediaProfiles[i].height === parseInt (this.selectedBitrate.slice(0, -1), 10)) {
        return i + 1;
      }
    }
    return 0;
  }

  public videocontrols(): void {
    let network;
    network = this.networkService.getPopupStatus();
    if (!network || this.showSignUpPromt || this.popUpFromHeader || this.contentLangPopup) {
      return;
    }
    if (this.replay) {
      this.videoReplay();
    } else if (this.playPause === this.play) {
        this.playVideo();
    } else if (this.playPause === this.pause) {
        this.pausedByUser = true;
        this.pauseVideo();
    }
  }

  public playVideo(): void {
    if (!this.player) {
      return;
    }
    this.startPlayback = true;
    if (!this.error) {
      this.showBackgroundImage = false;
    }
    if (!this.adDetails) {
      $('#playerOverlay').css('display', 'block');
    }
    this.player.play();
    // this.player.play(true);
    this.playPause = this.pause;
  }

  public pauseVideo(): void {
    if (!this.player || (this.player && this.getplayerState() === 'idle')) {
    // if (!this.player || (this.player && this.player.getState() === 'idle')) {
      return;
    }
    this.player.pause();
    // this.player.pause(true);
    this.playPause = this.play;
  }

  public controlsSetup(): void {
    if (this.videoDiv) {
      this.videoDiv.addEventListener('mousemove', (event) => this.resetTimer(event));
      this.videoDiv.addEventListener('touchstart', (event) => this.resetTimer(event));
      this.videoDiv.addEventListener('mouseup', (event) => this.resetTimer(event));
      this.videoDiv.addEventListener('touchmove', (event) => this.resetTimer(event));
      this.startTimer();      
    }
  }

  public startTimer(): void {
      this.controlsTimer = setTimeout(() => this.hideControls(), this.controlsVisibleTime);
      // this.controlsTimer = setTimeout(() => this.hideControls(), controlsVisibleTime);
  }

  public resetTimer(event): void {
    if ((event.type === 'mousemove' || event.type === 'mouseup') && this.navigator.maxTouchPoints) { // event.sourceCapabilities.firesTouchEvents
      return;
    } else if (event.type === 'touchstart' || event.type === 'touchmove') {
      setTimeout(() => {
        clearTimeout(this.controlsTimer);
        this.showControls();
      }, 500);
      return;
    }
    clearTimeout(this.controlsTimer);
    this.showControls();
  }

  public hideControls(): void {
    $('#playerInfoControls').css('visibility', 'hidden');
    if (this.playPause === this.play || this.muteLaunch || this.checkfocus ) {
      this.startTimer();
      return;
    }
    $('#ccPlayerText').css('bottom', '0');
    this.showPlayerControls = false;
    $('#playerHeaderBar').css('visibility', 'hidden');
    $('#playerControlsBar').css('visibility', 'hidden');
    this.settingsOpen = false;
    this.ccOpen = false;
    this.moreVisible = 'hidden';
    this.closeShare();
    this.hasClosedCaptions = 'hidden';
    this.settingLength = 'hidden';

    this.hideThumbnail(0);
  }

  public showControls(): void {
    this.fontResize();
    $('#ccPlayerText').css('bottom', 'calc(100%*65.5/546)');
    this.showPlayerControls = true;
    $('#playerHeaderBar').css('visibility', 'visible');
    $('#playerControlsBar').css('visibility', 'visible');
    $('#playerInfoControls').css('visibility', 'visible');
    if (this.captionLanguages && this.captionLanguages.length > 0) {
      this.hasClosedCaptions = 'visible';
    }
    if (this.settingsControlLength()) {
      this.settingLength = 'visible';
    }
    if (this.playPause === this.pause) {
      this.startTimer();
    }
  }

  public getTotalDuration(duration): any {
    if (duration && (!this.totalTimeMS || this.totalTimeMS !== duration)) {
    // if (!this.totalTimeMS || this.totalTimeMS !== duration)) {
      this.totalTimeMS = duration;
      if (this.videoIsLive === true || this.totalTimeMS === Infinity) {
        this.currentTimePercent = 100;
        this.progressCss();
      } else {
        this.totalTime = this.updateTime(this.totalTimeMS);
        this.adProgress();
      }
    }
  }

  public updateCurrentTime(currentTime): any {
    if (!this.iOSDevice) { // not when radiant player controls are enabled
      this.setPlayerControls(false);
    }
    if (!this.iOSDevice) {
      currentTime.position = this.getPlayerCurrentTime();
      currentTime.duration = this.player.duration;
    } else {
      currentTime.position = this.getPlayerCurrentTime();
      currentTime.duration = Math.round(this.player.getDuration() / 1000);
    }
    if (currentTime.position === 0 && this.isSeeking === false) {
      return;
    }
    let currentTimeSec;
    currentTimeSec = currentTime.position;
    this.getWaterMark(currentTimeSec);

    if (this.skipIntroend !== null &&  this.skipRecapStart !== null && this.skipIntroend  > this.skipRecapStart ) {
      this.showSkipIntro = false;
      this.showSkipRecap = false;
    } else {
      if (this.skipIntroStart !== null && this.skipIntroend !== null) {
        if (currentTime.position >=  this.skipIntroStart &&  currentTime.position <= this.skipIntroend) {
          this.showSkipIntro = true;
        } else {
          this.showSkipIntro = false;
        }
      }
      if (this.skipRecapStart != null && this.skipRecapEnd !== null) {
        if (currentTime.position >=  this.skipRecapStart &&  currentTime.position <= this.skipRecapEnd) {
          this.showSkipRecap = true;
        } else {
          this.showSkipRecap = false;
        }
      }
    }
    //  skip intro functionality starts
    this.getTotalDuration(currentTime.duration);

    if (currentTimeSec > this.totalTimeMS) {
      this.currentTime = this.updateTime(this.totalTimeMS);
    } else {
      this.currentTime = this.updateTime(currentTimeSec);
    }
    if (this.totalTimeMS && this.totalTimeMS !== Infinity) {
      $('#livetime').text(this.currentTime + '/' + this.totalTime);
    }
    if (this.videoIsLive === false && !this.isSeeking) {
      this.currentTimePercent = (currentTimeSec / this.totalTimeMS) * 100;
      // this.bufferValue = this.player.getBuffer();
      this.progressCss();
    }
    this.continueWatching(currentTimeSec);
    this.browsingVideoPopup(currentTimeSec);

    if (!this.watchCreditsClick  && !this.isSeeking && (this.enableAutoplay || this.showMovieRails) && !this.mobile) {
      this.checkEndPoint(Math.round(currentTimeSec));
    }

    if (this.showVideoViewSignup && (Math.round(currentTimeSec) / this.signUp_event_delay > 1)) {
      this.showVideoViewSignup = false;
      this.videoViewCounter = this.videoViewBuffer;
      this.settingsService.setVideoCounter(this.videoViewCounter);
      this.showSignUpPromt = true;
      this.pauseVideo();
      $('#PlayerContainer').css({'pointer-events': ''});
      $('#body').css('overflow', 'hidden');
    }

    if (!this.iOSDevice && this.subtitleState && !this.isSeeking) {
      this.setSubTitleStyles();
    }

  }

  private setSubTitleStyles(): any {
    let divTag;
    divTag = ((($('.playkit-subtitles') || {}).children() || {}).children() || {}).children();
    // // console.log(divTag);
    if (divTag && divTag.length && divTag.css('font-size') === '0px') {
      // console.log('here1', divTag.css('font-size'));
      divTag.css('font-size', 'inherit');
    }
  }

  public getWaterMark(value) {
    let waterMarkData, time, watermarkDuration, businessType, videoDur, count, lastFiveSec;
    videoDur = [];
    lastFiveSec = 5;
    waterMarkData = this.configData && this.configData.watermark_properties;
    if (this.token && waterMarkData && waterMarkData.watermark === true && waterMarkData.watermark_position) {
    watermarkDuration = waterMarkData.watermark_duration * 1000;
    businessType = this.videoObject[0].business_type;
    time = Math.floor(value);
    if (this.showRails) {
      this.showWaterMark = false;
    }
    for (let k = 1; k <= lastFiveSec; k++) {
      count = Math.floor(this.totalTimeMS) - k;
      videoDur.push(count);
     }

     for (let j = 1; j <= videoDur.length; j++) {
      if (time === videoDur[j]) {
        this.isLastFiveSec = true;
        this.showWaterMark = false;
      }
     }

    if (!this.isLastFiveSec) {
     if (!this.showWaterMark && !this.showRails) {
       for (let i = 0; i < waterMarkData.watermark_position.length; i++) {
         if (time > (waterMarkData.watermark_position[i] * 60) && time < ((waterMarkData.watermark_position[i] * 60) + waterMarkData.watermark_duration)) {
            this.showWaterMark = true;
            setTimeout(() => {
             this.showWaterMark = false;
           }, watermarkDuration);
         }
      }
    }
  }
 }
}
  private checkEndPoint(time): any {
    if (!this.showRails && this.endCreditsStart >= Math.round(this.totalTimeMS - time)) {
      if (this.autoplay && this.enableAutoplay && (this.endCreditsStart > this.showCredits && this.showCredits < Math.round(this.totalTimeMS - time))) {
        this.countDown = this.showCredits;
        this.startAutoplayTimer = true;
      } else {
        this.countDown = Math.round(this.totalTimeMS - time);
      }
      /* showDetails is set to true when content os not part of collection - Title is shown based on this and asset_type=1 and asset_subtype=episode) */
      if (this.showMovieRails) {
        this.showrails(this.showWatchCredits, this.nextData, false, true);
      } else if (!this.commonService.getCollectionId()) {
        this.showrails(this.showWatchCredits, this.nextData, this.autoplay, true);
      } else {
        this.showrails(this.showWatchCredits, this.nextData, this.autoplay, true);
      }
    } else if (this.showRails && this.railData.showTimer) {
      // this.countDown = Math.round(this.totalTimeMS - time);
    }
  }
  // private showrails(watchCredits, railData, showTimer): any {
  private showrails(watchCredits, railData, showTimer, showDetails): any {
      this.railData.watchCredits = watchCredits;
      this.railData.showTimer = showTimer;
      this.railData.showDetails = showDetails;
      this.showRails = true;
      let details;
      details = {
        'event': 'videoPopup',
        'Popup_Counts': railData.length,
        'collection_id': this.commonService.getCollectionId() || this.notAvailable
      };
      this.googleAnalyticPost(details);
      if (this.autoplay && this.enableAutoplay && this.endCreditsStart > this.showCredits && this.startAutoplayTimer) {
        this.startAutoplayTimer = false;
        this.nextPlayTimeout = setTimeout(() => {
          this.autoplayNext();
        }, (this.countDown * 1000));
      }
      this.countDownInterval = setInterval(() => {
        if (this.countDown > 0) {
          this.countDown--;
        } else {
          clearInterval(this.countDownInterval);
        }
      }, 1000);
  }
  public hideRails(event): any {
    if (event !== 'adplay') {
      this.watchCreditsClick = true;
    }
    if (this.nextPlayTimeout) {
      clearTimeout(this.nextPlayTimeout);
    }
    if (this.countDownInterval) {
      clearInterval(this.countDownInterval);
    }
    // this.watchCreditsClick = true;
    this.showRails = false;
  }
  // skip intro GA events starts
  public skipIntro() {
    this.showSkipIntro = false;
    this.GAskipIntro();
    this.skip(this.skipIntroend, '');
  }
  public skipRecap() {
    this.showSkipRecap = false;
    this.GAskipRecap();
    this.skip(this.skipRecapEnd, '');
  }

  public convertTimetoSeconds(time): any {
    let result = 0, seconds, mins, hrs, temp;
    temp = time.split(':');
    seconds = temp[temp.length - 1] ? parseInt(temp[temp.length - 1], 10) : 0;
    mins = temp[temp.length - 2] ? parseInt(temp[temp.length - 2], 10) : 0;
    hrs = temp[temp.length - 3] ? parseInt(temp[temp.length - 3], 10) : 0;
    result = (hrs * 3600) + (mins * 60) + seconds;
    return result;
  }
  public GAskipIntro(): any {
    let details;
    details = {
      'event' : 'skipIntro',
      'introDuration': this.skipIntroend - this.skipIntroStart,
      'skipIntroFrom': Math.round(this.currenttimeIntro),
      'skipIntroTo': this.skipIntroend
    };
     this.googleAnalyticPost(details);
  }
  public GAskipRecap(): any {
    let details;
    details = {
      'event' : 'skipRecap',
      'recapDuration': this.skipRecapEnd - this.skipRecapStart,
      'skipRecapFrom': Math.round(this.currenttimeIntro),
      'skipRecapTo': this.skipRecapEnd
    };
     this.googleAnalyticPost(details);
  }
  // skip intro GA events ends

  public browsingVideoPopup(duration: number): any {
    let  durationFloored;
    durationFloored = Math.floor(duration);
    if (durationFloored - this.previousTime !== 0) {
        ++this.gaCounter;
        this.previousTime = durationFloored;
    }
    if (!this.token && this.browser_timer_flag) {
      if (this.gaCounter > this.browser_timer) {
       this.settingsService.setGAcounter(true);
      }
    }
  }

  public postGAwatchDuration(videoObject: any): any {
    let details;
    details = {
        'event': 'videowatchduration',
        'Watch_Duration_New': this.gaCounter, // 'TimeInternal': this.gaCounter 'TimeInterval ': this.gaCounter
        'Network_Type': '',
        'BitRate': '',
        'User_Type': this.localStorage.getItem('token') ? 'loggedin' : 'guest'
    };
    details = $.extend({}, details, this.talamoosData);
    if (!this.videoItemforGA || this.videoItemforGA.Content_ID !== videoObject[0].id) {
      this.videoDetails();
    }
    let videoItemforGA;
    videoItemforGA = $.extend({}, this.videoItemforGA, details);
    this.videoService.googleAnalyticPost(videoItemforGA, this.gaSubCategory, this.clickDetails);
    // this.googleAnalyticPost(details);
  }

  public continueWatching(currentTimeSec: number): any {
    if (this.videoObject[0].id && this.videoObject[0].asset_type >= 0 && currentTimeSec > this.continueWatchingTime) {
      if (this.watchHistoryApi) {
        if (!this.inHistory) {
          this.postHistory('', currentTimeSec);
          this.inHistory = true;
        // } else if (Math.round(currentTimeSec % continueWatchingTime) === 0) {
        } else if (Math.round(currentTimeSec % this.continueWatchingTime) === 0 && Math.round(currentTimeSec) !== this.updatedHistoryTime) {
          this.updatedHistoryTime = Math.round(currentTimeSec);
          this.updateElapsedTime('', currentTimeSec);
        }
      }
      if (Math.round(currentTimeSec % this.continueWatchingTime) === 0 && Math.round(currentTimeSec) !== this.updatedRecoHistoryTime) {
        this.updatedRecoHistoryTime = Math.round(currentTimeSec);
        this.updateRecoHistory('', currentTimeSec);
      }
    }
  }

  public progressCss(): any {
    let head;
    if (this.mobile) {
      head = 24;
    } else {
      head = 14;
    }
    let currentTimeCssWidth, bufferCssWidth;
    currentTimeCssWidth = this.currentTimePercent * 970 / 100;
    // if (this.isSeeking === false) {
    //   bufferCssWidth = this.bufferValue * 970 / 100;
    //   $('#progressBuffer').css('width', 'calc(100% * ' + bufferCssWidth + '/970)');
    // }
    $('#progressSeek').css('width', 'calc(100% *' + currentTimeCssWidth + '/970)');
    if (Math.floor(currentTimeCssWidth) < head) {
      $('#progressHead').css('left', 'calc(0%)');
    } else if ((970 - head) <= Math.floor(currentTimeCssWidth)) {
      $('#progressHead').css('left', 'calc(100% * ' + (970 - head) + '/970)');
    } else {
      $('#progressHead').css('left', 'calc(100% * (' + (currentTimeCssWidth - (head / 2)) + ')/970)');
    }
  }

  public updateTime(s): any {
    let secs, mins, hrs, time, hrsStr;
    secs = s % 60;
    s = (s - secs) / 60;
    mins = s % 60;
    s = (s - mins) / 60;
    hrs = s % 60;
    secs = Math.floor(secs);
    hrsStr = hrs ? ((hrs < 10 ? '0' + hrs : hrs) + ':') : '';
    time = hrsStr + (mins < 10 ? '0' + mins : mins) + ':' + (secs < 10 ? '0' + secs : secs);
    return time;
  }

  public forward(pos) {
    let scope;
    scope = this;
    scope.count++;
    clearTimeout(this.forwardRewind);
    this.forwardRewind = setTimeout(() => {
      let value;
      if (scope.count > 1) {
        value = pos * 10 * (scope.count - 1);
        scope.skip(value, 'doubletap');
      }
      scope.count = 0;
    }, this.displayFRTime);
  }
  public rewind(neg) {
    let scope;
    scope = this;
    scope.count++;
    clearTimeout(this.forwardRewind);
    this.forwardRewind = setTimeout(() => {
      let value;
      if (scope.count > 1) {
        value = neg * 10 * (scope.count - 1);
        scope.skip(value, 'doubletap');
      }
      scope.count = 0;
    }, this.displayFRTime);
  }
  public skip(value, doubletap): any {
    let network, currentTime;
    network = this.networkService.getPopupStatus();
    if (!network || this.videoIsLive || this.videoObject[0].type === 'live' || this.showSignUpPromt || this.popUpFromHeader || this.contentLangPopup) {
      return;
    }
    if ( doubletap === 'doubletap' ) {
      let details;
      if (value < 0 ) {
        this.rewindImg = true;
        details = {
          'event': 'Backward',
          'BackwardValue': (value * -1)
        };
        this.rewindValue = (value * -1);
        $('.rewind').css('display', 'inline-flex');
        setTimeout(() =>  { $('.rewind').fadeOut();
          $('.rewind').css('display', 'none');
          this.rewindImg = false;
        }, 800);
      } else {
        this.forwardImg = true;
        details = {
          'event': 'Forward',
          'ForwardValue': value
        };
        this.forwardValue = value;
        $('.forward').css('display', 'inline-flex');
        setTimeout(() =>  { $('.forward').fadeOut();
          $('.forward').css('display', 'none');
          this.forwardImg = false;
        }, 800);
      }
      this.googleAnalyticPost(details);
    }
    if (value === 10 || value === -10 || doubletap === 'doubletap') {
    //   if (this.isSeeking && this.currentTimeSec < 10 && value < 0 || this.getPlayerCurrentTime() < 10 && value < 0) {
    //     value = 0;
    //   } else if ((this.isSeeking && this.currentTimeSec > this.totalTimeMS - 10 || this.getPlayerCurrentTime() > this.totalTimeMS - 10) && value > 0) {
    //     value = this.totalTimeMS - 1;
    //   } else if (this.isSeeking) {
    //     value += this.currentTimeSec;
    //   } else {
    //     value += this.getPlayerCurrentTime();
    //   }
    // } else if ( doubletap === 'doubletap' ) {
      if (this.isSeeking) {
        value += this.currentTimeSec;
      } else {
        value += this.getPlayerCurrentTime();
      }
      if (value < 0) {
        value = 0;
      } else if (value > this.totalTimeMS) {
        value = this.totalTimeMS - 1;
      }
    } else if (value < 1) {
      return;
    } else if (value > this.totalTimeMS) {
      value = this.totalTimeMS - 1;
    }
    if (!this.videoItemforGA || this.videoItemforGA.Content_ID !== this.videoObject[0].id) {
      this.videoDetails();
    }
    this.videoService.seekGoogleAnalyticPost(this.videoItemforGA, this.getPlayerCurrentTime(), value, this.gaSubCategory, this.clickDetails);
    // this.videoService.seekGoogleAnalyticPost(this.videoItemforGA, this.getPlayerCurrentTime(), value, this.gaSubCategory);
    this.isSeeking = true;
    this.GAVideoRestartTime(this.getPlayerCurrentTime(), value);
    this.playerseek(value);
    // this.player.seek(value);
    currentTime = {
      position: value,
      duration: this.totalTimeMS
    };
    this.currentTimeSec = value;
    // this.updateCurrentTime(currentTime);
  }

  public GAVideoRestartTime(start, end): any {
    if (!this.seekStartTime) {
      this.seekStartTime = new Date().getTime();
      this.seekStart = Math.round(start);
    }
    this.seekEnd = Math.round(end);
  }

  public seekOnClick(event): any {
    let network, pageX, offset, value;
    network = this.networkService.getPopupStatus();
    if (!network || this.videoIsLive || !this.totalTimeMS || this.totalTimeMS === Infinity) {
      return;
    }
    this.isSeeking = true;
    // pageX = this.videoService.pageX(event);
    // offset = pageX - $('#videoDiv').offset().left;
    // value = offset * this.totalTimeMS / $('.progressBackground')[0].offsetWidth;
    // /* 10 sec seek for VTT thumbnail*/
    // if (this.thumbnail_data) {
    //   value = Math.floor(value / this.imageInterval) * this.imageInterval;
    //   // value = Math.floor(value / 10) * 10;
    //   this.hideThumbnail(0);
    // }
    // /* 10 sec seek for VTT thumbnail*/
    if (this.thumbnail_data) {
      value = this.thumbnailTimeSec;
      value = Math.floor(value / this.imageInterval) * this.imageInterval;
      offset = value * $('.progressBackground')[0].offsetWidth / this.totalTimeMS;
      this.hideThumbnail(0);
    } else {
      pageX = this.videoService.pageX(event);
      offset = pageX - $('#videoDiv').offset().left;
      value = offset * this.totalTimeMS / $('.progressBackground')[0].offsetWidth;
    }
    if (value > this.totalTimeMS) {
      return;
    }
    if (!this.videoItemforGA || this.videoItemforGA.Content_ID !== this.videoObject[0].id) {
      this.videoDetails();
    }
    this.videoService.seekGoogleAnalyticPost(this.videoItemforGA, this.getPlayerCurrentTime(), value, this.gaSubCategory, this.clickDetails);
    // this.videoService.seekGoogleAnalyticPost(this.videoItemforGA, this.getPlayerCurrentTime(), value, this.gaSubCategory);
    this.GAVideoRestartTime(this.getPlayerCurrentTime(), value);
    this.playerseek(value);
    // this.player.seek(value);
    this.currentTimeSec = value;
    this.currentTime = this.updateTime(value);
    if (this.totalTimeMS && this.totalTimeMS !== Infinity) {
      $('#livetime').text(this.currentTime + '/' + this.totalTime);
    }
    this.currentTimePercent = (offset < 0 ? 0 : offset) * 100 / $('.progressBackground')[0].offsetWidth;
    this.progressCss();
  }

  private playerseek(time): any {
    if (this.iOSDevice) {
      this.player.seekTo(time * 1000);
    } else {
      this.player.currentTime = time;
    }
  }

  public seekOnDrag(event): any {
    let pageX, offset, value;
    pageX = this.videoService.pageX(event);
    this.pageX = pageX;
    offset = pageX - $('#videoDiv').offset().left;
    value = offset * this.totalTimeMS / $('.progressBackground')[0].offsetWidth;
    if ($('.progressHead')[0].offsetLeft === 0 && offset <= 0) {
    // if($('.progressHead')[0].offsetLeft===0){
      value = 0;
    } else if ($('.progressHead')[0].offsetLeft >= ($('.progressBackground')[0].offsetWidth - ($('.progressHead')[0].offsetWidth)) && offset >= this.totalTimeMS) {
      value = this.totalTimeMS - 1;
    }
    value = value < 0 ? 0 : value;
    /* 10 sec seek for VTT thumbnail*/
    if (this.thumbnail_data) {
      value = Math.floor(value / this.imageInterval) * this.imageInterval;
      // value = Math.floor(value / 10) * 10;
    }
    /* 10 sec seek for VTT thumbnail*/

    this.currentTimeSec = value;
    this.thumbnailTimeSec = value;
    // this.currentTime = this.updateTime(value);
    this.thumbnailTime = this.updateTime(value);
    if (this.totalTimeMS && this.totalTimeMS !== Infinity) {
      $('#livetime').text(this.currentTime + '/' + this.totalTime);
    }
    this.currentTimePercent = (offset < 0 ? 0 : offset) * 100 / $('.progressBackground')[0].offsetWidth;
    this.progressCss();
    this.seekSliderEnd = value;
    if (!this.videoIsLive && this.videoObject[0].asset_type !== 10) {
    this.showThumbnail(value);
    // tooltip styles
    let divWidth, tooltipWidth, left, lastLeft, firstLeft, tooltipDiv, playerDiv;
    playerDiv = $('#PlayerContainer');
    tooltipDiv = $('#tooltiptext');
    divWidth = playerDiv[0].clientWidth;
    tooltipWidth = (tooltipDiv && tooltipDiv.length > 0) ? tooltipDiv[0].clientWidth : '';
    left = pageX - playerDiv.offset().left;
    if (divWidth && tooltipWidth) {
      lastLeft = divWidth - (tooltipWidth / 2);
      if (left <= (tooltipWidth / 2)) {
        firstLeft = (tooltipWidth / 2);
        $('.tooltipVideo .tooltiptext').css('left', firstLeft + 'px');
      } else if (left < lastLeft) {
        $('.tooltipVideo .tooltiptext').css('left', left + 'px');
      } else {
        $('.tooltipVideo .tooltiptext').css('left', lastLeft + 'px');
      }
    }
       // let x, y, z;
       // x = Math.floor($('.tooltiptext').width());
       // x = x / 2;
       // y = Math.floor($('.progressSeek').width());
       // z = Math.floor($('.progressBar').width());
       // if (y < x) {
       //   $('.tooltipVideo .tooltiptext').css('left', (x - y) + 'px');
       // } else if ((z - y) < x) {
       //   $('.tooltipVideo .tooltiptext').css('left', (z - y - x) + 'px');
       // } else {
       //   $('.tooltipVideo .tooltiptext').css('left', '');
       // }
    }
  }

  public setThumbnail(event): any {
    let network;
    network = this.networkService.getPopupStatus();
    // if (!network) {
    if (!network || event.target.id === 'tooltiptext' || this.ccOpen || this.settingsOpen || $(event.target).closest('#tooltiptext').length || this.videoIsLive || this.videoObject[0].asset_type === 10) {
      return;
    }
    let pageX, offset, value;
    pageX = this.videoService.pageX(event);
    this.pageX = pageX;
    offset = pageX - $('#videoDiv').offset().left;
    value = offset * this.totalTimeMS / $('.progressBackground')[0].offsetWidth;
    if ($('.progressHead')[0].offsetLeft === 0 && offset <= 0) {
    // if($('.progressHead')[0].offsetLeft===0){
      value = 0;
    } else if ($('.progressHead')[0].offsetLeft >= ($('.progressBackground')[0].offsetWidth - ($('.progressHead')[0].offsetWidth)) && offset >= this.totalTimeMS) {
      value = this.totalTimeMS - 1;
    }
    value = value < 0 ? 0 : value;

    /* 10 sec seek for VTT thumbnail*/
    if (this.thumbnail_data) {
      value = Math.floor(value / this.imageInterval) * this.imageInterval;
      // value = Math.floor(value / 10) * 10;
    }
    /* 10 sec seek for VTT thumbnail*/

    this.thumbnailTimeSec = value;
    this.thumbnailTime = this.updateTime(value);

    this.showThumbnail(value);

    // tooltip styles
    let divWidth, tooltipWidth, left, lastLeft, firstLeft, tooltipDiv, playerDiv;
    playerDiv = $('#PlayerContainer');
    tooltipDiv = $('#tooltiptext');
    divWidth = playerDiv[0].clientWidth;
    tooltipWidth = (tooltipDiv && tooltipDiv.length > 0) ? tooltipDiv[0].clientWidth : '';
    left = pageX - playerDiv.offset().left;
    if (divWidth && tooltipWidth) {
      lastLeft = divWidth - (tooltipWidth / 2);
      if (left <= (tooltipWidth / 2)) {
        firstLeft = (tooltipWidth / 2);
        $('.tooltipVideo .tooltiptext').css('left', firstLeft + 'px');
      } else if (left < lastLeft) {
        $('.tooltipVideo .tooltiptext').css('left', left + 'px');
      } else {
        $('.tooltipVideo .tooltiptext').css('left', lastLeft + 'px');
      }
    }
     // let x, y, z, a;
     // x = Math.floor($('.tooltiptext').width());
     // x = x / 2;
     // y = Math.floor(offset); // Math.floor($('.progressSeek').width());
     // z = Math.floor($('.progressBar').width());
     // a = Math.floor($('.progressSeek').width());
     // if (y < x) {
     //   $('.tooltipVideo .tooltiptext').css('left', (x - a) + 'px');
     // } else if ((z - y) < x) {
     //   $('.tooltipVideo .tooltiptext').css('left', (z - x - a) + 'px');
     // } else {
     //   $('.tooltipVideo .tooltiptext').css('left', (y - a) + 'px');
     // }
  }

  public showThumbnail(value): any {
    if (this.thumbnail_data && this.thumbnail_data.length > 0) {
    // if (!this.mobile && this.thumbnail_data && this.thumbnail_data.length > 0) {
      let thumbnail_index, thumbnail_image;
      thumbnail_index = Math.floor(value / this.imageInterval);
      if (thumbnail_index > this.thumbnail_data.length) {
        thumbnail_image = this.thumbnail_data[this.thumbnail_data.length - 1] && this.thumbnail_data[this.thumbnail_data.length - 1]['text'] ? this.thumbnail_data[this.thumbnail_data.length - 1]['text'] : this.defaultThumbnailImage;
      } else {
        thumbnail_image = this.thumbnail_data[thumbnail_index] && this.thumbnail_data[thumbnail_index]['text'] ? this.thumbnail_data[thumbnail_index]['text'] : this.defaultThumbnailImage;
      }
      this.tooltip_thumbnail = (thumbnail_image !== this.defaultThumbnailImage) ? this.thumbnailUrl.replace('index.vtt', thumbnail_image) : this.defaultThumbnailImage;
    }
    if (!this.thumbnail_data || this.touchScreen)  {
      $('.tooltipVideo .tooltiptext').css('visibility', 'visible');
      // this.showTooltip = true;
    }
    // $('.tooltipVideo .tooltiptext').css('opacity', 1);
  }

  public hideThumbnail(offset): any {
    setTimeout(() => {
      $('.tooltipVideo .tooltiptext').css('visibility', 'hidden');
    }, offset);
  }

  public thumbnailLoaded(event): any {
    if (this.touchScreen) {
      return;
    }
    let divWidth, tooltipWidth, left, lastLeft, firstLeft, tooltipDiv, playerDiv;
    playerDiv = $('#PlayerContainer');
    tooltipDiv = $('#tooltiptext');
    divWidth = playerDiv[0].clientWidth;
    tooltipWidth = (tooltipDiv && tooltipDiv.length > 0) ? tooltipDiv[0].clientWidth : '';
    left = this.pageX - playerDiv.offset().left;
    if (divWidth && tooltipWidth) {
      lastLeft = divWidth - (tooltipWidth / 2);
      if (left <= (tooltipWidth / 2)) {
        firstLeft = (tooltipWidth / 2);
        $('.tooltipVideo .tooltiptext').css('left', firstLeft + 'px');
      } else if (left < lastLeft) {
        $('.tooltipVideo .tooltiptext').css('left', left + 'px');
      } else {
        $('.tooltipVideo .tooltiptext').css('left', lastLeft + 'px');
      }
    }
    $('.tooltipVideo .tooltiptext').css('visibility', 'visible');
  }

  public addSeekEvents(): any {
    let network;
    this.checkfocus = true;
    network = this.networkService.getPopupStatus();
    if (!network || this.videoIsLive || !this.totalTimeMS || this.totalTimeMS === Infinity) {
      return;
    }
    this.seekSliderStart = this.getPlayerCurrentTime();
    this.isSeeking = true;
    $('#playerOverlay').bind( 'mousemove touchmove', (event) => this.seekOnDrag(event));
    $('#body').bind( 'mouseup touchend', () => this.removeSeekEvents());
  }

  public removeSeekEvents(): any {
    this.checkfocus = false;
    $('#playerOverlay').unbind('mousemove touchmove');
    $('#body').unbind( 'mouseup touchend');
    this.playerseek(this.seekSliderEnd);
    // this.player.seek(this.seekSliderEnd);
    if (!this.videoItemforGA || this.videoItemforGA.Content_ID !== this.videoObject[0].id) {
      this.videoDetails();
    }
    this.videoService.seekGoogleAnalyticPost(this.videoItemforGA, this.seekSliderStart, this.seekSliderEnd, this.gaSubCategory, this.clickDetails);
    // this.videoService.seekGoogleAnalyticPost(this.videoItemforGA, this.seekSliderStart, this.seekSliderEnd, this.gaSubCategory);
    this.GAVideoRestartTime(this.seekSliderStart, this.seekSliderEnd);

    this.hideThumbnail(1000);

  }

  // function to check whether the player is already in seeking mode
  public ifSeeking(): any {
    if (this.playPause === this.play) {
        return true;
    }
    return false;
  }

  private setVolume(): any {
    if (this.iOSDevice) {
      this.player.setVolume(this.volume);
    } else {
      this.player.volume = this.volume;
    }
  }

  private setMute(state: any = null): any {
    if (this.iOSDevice) {
      state = (state !== null) ? state : !this.getMute();
      this.player.setMute(state);
    } else {
      this.player.muted = (state !== null) ? state : !this.player.muted;
    }
  }

  private getVolume(): any {
    return this.iOSDevice ? this.player.getVolume() : this.player.volume;
  }

  private getMute(): any {
    return this.iOSDevice ? this.player.getMute() : this.player.muted;
  }

  public volumeChange(): any {
    if (this.getMute()) {
      this.setMute(false);
    }
    this.setVolume();
    this.volumeIconChange();
    this.volumeCss();
  }

  public changeVolume(value): any {
    if ((value === +0.1 && this.volume < 1) ||  (value === -0.1 && this.volume > 0)) {
      this.volume += value;
      this.volumeChange();
    }
  }

  public volumeDisplay(): any {
    $('#volumeBar')[0].style.display = 'block';
    $('#timeLapse').css('left', 'calc(100%*142/610)');
  }

  public volumeHide(): any {
    $('#volumeBar')[0].style.display = 'none';
    $('#timeLapse').css('left', 'calc(100%*62/610)');
  }

  public mute(): any {
    let network;
    network = this.networkService.getPopupStatus();
    if (!network) {
      return;
    }
    if (this.volume === 0) {
      if (this.volumeBefore) {
        this.volume = this.volumeBefore;
      } else {
        this.volume = 0.5;
      }
      this.volumeChange();
    } else {
      this.muteLaunch = false;
      this.setMute();
      this.volumeIconChange();
      this.volumeCss();
    }
  }

  public volumeOnClick(event): any {
    let network, pageX, offset;
    network = this.networkService.getPopupStatus();
    if (!network) {
      return;
    }
    pageX = this.videoService.pageX(event);
    offset = pageX - $('.volumeBar').offset().left;
    this.volume = (offset < 0 ? 0 : offset) / $('.volumeBackground')[0].offsetWidth;
    this.volumeChange();
  }

  public volumeOnDrag(event): any {
    let pageX, offset;
    pageX = this.videoService.pageX(event);
    offset = pageX - $('.volumeBar').offset().left;
    this.volume = (offset < 0 ? 0 : offset) / $('.volumeBackground')[0].offsetWidth;
    this.volumeCss();
    if ($('.volumeHead')[0].offsetLeft === 0) {
      this.volume = 0;
    } else if ($('.volumeHead')[0].offsetLeft >= ($('.volumeBar')[0].offsetWidth - ($('.volumeHead')[0].offsetWidth))) {
      this.volume = 1;
    }
    this.volumeChange();
  }

  public addVolumeEvents(): any {
    let network;
    network = this.networkService.getPopupStatus();
    if (!network) {
      return;
    }
    this.volumeBefore = this.volume;
    $('.volumeBar').bind( 'mousemove touchmove', (event) => this.volumeOnDrag(event));
    $('#body').bind( 'mouseup touchend', () => this.removeVolumeEvents());
  }

  public removeVolumeEvents(): any {
    $('.volumeBar').unbind('mousemove touchmove');
    $('#body').unbind( 'mouseup touchend');
  }

  public volumeIconChange(): any {
    let muted;
    muted = this.getMute();
    // muted = this.player.getMute();
    if (this.volume === 0 || muted) {
      this.volumeIcon = this.mute_icon;
    } else if (this.volume <= 0.5) {
      this.volumeIcon = this.volume_icon;
    } else {
      this.volumeIcon = this.full_volume_icon;
    }
  }

  public volumeCss(): any {
    let cssWidth;
    if (this.getMute()) {
    // if (this.player.getMute()) {
      cssWidth = 0;
    } else {
      cssWidth = this.volume * 72;
    }
    if (Math.floor(cssWidth) < 0) {
      $('#volumeSeek').css('width', 'calc(100% * 0/72)');
    } else if (60 <= Math.floor(cssWidth)) {
      $('#volumeSeek').css('width', 'calc(100% * 60/72)'); // 72 - 6
    } else {
      $('#volumeSeek').css('width', 'calc(100% * (' + (cssWidth - 6) + ')/72)');
    }
    if (Math.floor(cssWidth) < 12) {
      $('#volumeHead').css('left', 'calc(0%)');
    } else if (60 <= Math.floor(cssWidth)) {
      $('#volumeHead').css('left', 'calc(100% * 60/72)');
    } else {
      $('#volumeHead').css('left', 'calc(100% * (' + (cssWidth - 6) + ')/72)');
    }
  }

  public onFullscreenchange(event): any {
    let fullscreen;
    fullscreen = event.type === 'enterfullscreen';
    // fullscreen = this.iOSDevice ? event.fullscreen : event.type === 'enterfullscreen';
    if (fullscreen) {
    // if (event.type === 'enterfullscreen') {
    // if (event.fullscreen) {
      this.videoAnalyticsService.updateMetaTags(this.player, 'viewingMode', 'Full Screen');
      // if (!this.fullscreenFromAd && !(this.navigator.platform.match(/(iPhone|iPod|iPad)/i) && (this.browser.name === 'Safari' || this.browser.name === 'CriOS'))) {
      //   if (!(this.document.fullscreenElement || this.document.webkitFullscreenElement || this.document.mozFullScreenElement || this.document.msFullscreenElement)) {
      //     this.toggleFullScreen();
      //   }
      // }
    } else {
      this.videoAnalyticsService.updateMetaTags(this.player, 'viewingMode', this.videoAnalyticsService.getViewingMode());
      // if (!this.fullscreenFromAd && !(this.navigator.platform.match(/(iPhone|iPod|iPad)/i) && (this.browser.name === 'Safari' || this.browser.name === 'CriOS'))) {
      //   setTimeout(() => {
      //     if (this.document.fullscreenElement || this.document.webkitFullscreenElement || this.document.mozFullScreenElement || this.document.msFullscreenElement) {
      //       this.toggleFullScreen();
      //     }
      //     $('#body').css('overflow', '');
      //   }, 0);
      // }
    }
    this.fullscreenFromAd = false;
  }

  public toggleFullScreen(): void {
    let network, element;
    network = this.networkService.getPopupStatus();
    if (!network) {
      return;
    }
    this.hideControls();
    this.hideThumbnail(0);
    element = this.document.querySelector('#PlayerContainer');
    if (this.navigator.platform.match(/(iPhone|iPod|iPad)/i) && (this.browser.name === 'Safari' || this.browser.name === 'CriOS')) {
      this.setFullscreen();
    }
    // if ( this.document.fullscreenElement || this.document.webkitFullscreenElement ) {
    if (this.document.fullscreenElement || this.document.webkitFullscreenElement || this.document.mozFullScreenElement || this.document.msFullscreenElement) {
      if (this.document.webkitExitFullscreen) {
        this.document.webkitExitFullscreen();
      } else if (this.document.mozFullScreenElement) {
        this.document.mozCancelFullScreen();
      } else if (this.document.msFullscreenElement) {
        this.document.msExitFullscreen();
      } else if (this.document.exitFullscreen) {
        this.document.exitFullscreen();
      }
      $('#body').css('overflow', '');
    } else {
      this.epg.disableWindowScroll(true);
      if (element.webkitRequestFullscreen) {
        element.webkitRequestFullscreen();
      } else if (element.mozRequestFullScreen) {
        element.mozRequestFullScreen();
      } else if (element.requestFullscreen) {
        element.requestFullscreen();
      } else if (element.msRequestFullscreen) {
        element.msRequestFullscreen();
      }
      if ( this.navigator.userAgent.match(/mobile/i)) {
        setTimeout(() => {
          $(screen)[0].orientation.lock('landscape');
        }, 0); // not available on this device//in device to do this it should be full screen
      }
    }
  }

  /*
     function to resize the font on each resize of window
     - Info:
       - append code snippet based on the text sections to resize
  */
  public fontResize(): void {
    if (this.player && this.getPlayerControlsState()) {
    // if (this.player && this.player.getControls()) {
      $('#playerOverlay').css('display', 'none');
    }
    if (this.window.innerWidth < 481 || (this.player && this.getPlayerControlsState())) {
      return;
    }
    $(this.document).ready(function() {
      let titleFontSize, titleLineHeight, timeFontSize;
      titleFontSize = parseInt($('#titleText').height(), 10) - 4 + 'px';
      titleLineHeight = parseInt($('#titleText').height(), 10) + 'px';
      $('#titleText p').css('font-size', titleFontSize);
      $('#titleText p').css('line-height', titleLineHeight);
      timeFontSize = parseInt($('#timeLapse').height(), 10);
      $('#timeLapse p').css('font-size', timeFontSize + 'px');
      $('#ccWindow').css('font-size', timeFontSize + 'px');
      $('#settingsWindow').css('font-size', timeFontSize + 'px');
      $('#ccPlayerText').css('font-size', timeFontSize + 'px');
      $('#moreMenu ').css('font-size', timeFontSize + 'px');
      $('#error p').css('font-size', titleFontSize);
      if (this.moreVisible === 'visible') {
        $('.menuText').css('line-height', parseInt($('.menuIconTextBlock').height(), 10) + 'px');
      }
      let width;
      width = parseInt($('.menuOption').height(), 10) * 3 * 192 / 122;
      $('#moreMenu ').css('width', width + 'px');
    });
  }

  public toggleSettings(selection): any {
    let network;
    network = this.networkService.getPopupStatus();
    if (!network) {
      return;
    }
    if (selection === 'AUTOPLAY') {
      this.autoplay = !this.autoplay;
    } else if (selection === 'Quality') {
      this.mainSettingsMenu = false;
      this.audioMenu = false;
      this.setOptionsHeight('settingsWindow', 'settingsListOption', this.mediaProfiles.length + 1, 41);
      this.qualityMenu = true;
    } else if (selection === 'AUDIO_LANG') {
    this.mainSettingsMenu = false;
    this.qualityMenu = false;
    this.setOptionsHeight('settingsWindow', 'settingsListOption', this.audioLanguages.length + 1, 41);
    this.audioMenu = !this.audioMenu;
    }
  }

  public settingsBack(): any {
    let network;
    network = this.networkService.getPopupStatus();
    if (!network) {
      return;
    }
    this.audioMenu = false;
    this.qualityMenu = false;
    this.mainSettingsMenu = true;
    this.setOptionsHeight('settingsWindow', 'settingsControlOption', this.settingsControlLength(), 51);
  }

  public settingsControlLength(): any {
     let settingLength = 0;
     if (this.mediaProfiles.length > 0) {
       settingLength++;
     }
     if (this.audioLanguages.length > 1) {
       settingLength++;
     }
     if (this.enableAutoplay) {
     // if (this.nextData && this.nextData[0]) {
     // if (this.videoObject[0].asset_type !== epgAssetType && this.videoObject[0].asset_type !== 9 && this.autoplay_episode) {
       settingLength++;
     }
     return settingLength;
  }

  public changeAudioLanguages(audio_lang_index): void {
    // let network, tracks;
    let network, item, tracks;
    item = this.player;
    network = this.networkService.getPopupStatus();
    if (!network || this.audioLanguages.length < 2) {
    // if (!network || this.audioLanguages.length < 2 || audio_lang_index === this.player.getCurrentAudioTrack()) {
      return;
    }
    if (this.iOSDevice) {
      tracks = item.getAudioTracks();
    } else {
      tracks = item.getTracks(item.Track.AUDIO);
    }

    if (audio_lang_index >= 0 && audio_lang_index < tracks.length) {
      if (this.iOSDevice) {
        item.setAudioTrack(audio_lang_index);
        // item.setCurrentAudioTrack(audio_lang_index);
      } else {
        item.selectTrack(tracks[audio_lang_index]);
      }
      this.selectedAudio = tracks[audio_lang_index].language;
      this.selectedAudioqg = this.jwAudioLanguageString[audio_lang_index];
      this.selectedAudioString = this.jwAudioLanguageString[audio_lang_index];
    }
    this.videoAnalyticsService.updateMetaTags(this.player, 'audioLanguage', this.selectedAudioqg);
    let details;
    details = {
      'event': 'AudLanChange',
      'LanguageMetrics': '1',
      'Video_Language': this.selectedAudioqg
    };
    this.googleAnalyticPost(details);
  }

  public setOptionsHeight(windowName, windowOption, listLength, height) {
    let minListLength, optionHeight;
    minListLength = 5;
    let settingsHeight;
    listLength = listLength > minListLength ? minListLength : listLength;
    settingsHeight = (listLength) * height - 1;
    $('#' + windowName).css('height', 'calc(100%*' + settingsHeight + '/395)');
    $('#' + windowName).css('visibility', 'visible');
    optionHeight = height - 1;
    $('#' + windowName + ' .' + windowOption).css('height', 'calc(100%*' + optionHeight + '/' + settingsHeight + ' )');
    $('#' + windowName + ' .' + windowOption ).css('border-bottom-width', ($('#' + windowName).height() / settingsHeight) + 'px');
  }

  public settingsToggle(): any {
     let network;
    network = this.networkService.getPopupStatus();
    if (!network) {
      return;
    }
    this.ccOpen = false;
    this.moreVisible = 'hidden';
    this.closeShare();
    if (!this.settingsOpen) {
      this.setOptionsHeight('settingsWindow', 'settingsControlOption', this.settingsControlLength(), 51);
    }
    this.settingsOpen = !this.settingsOpen;
    this.audioMenu = false;
    this.qualityMenu = false;
    this.mainSettingsMenu = true;
  }

  public ccToggle(): any {
    let network;
    network = this.networkService.getPopupStatus();
    if (!network) {
      return;
    }
    this.settingsOpen = false;
    this.moreVisible = 'hidden';
    this.closeShare();
     if (!this.ccOpen) {
      this.setOptionsHeight('ccWindow', 'ccOption', this.captionLanguages.length + 2, 41);
    }
    this.ccOpen = !this.ccOpen;
  }

  public toggleSubtitles(): any {
    let network;
    network = this.networkService.getPopupStatus();
    if (!network) {
      return;
    }
    let previousIndex, captionLanguages;
    captionLanguages = this.captionLanguages;
    // captionLanguages = this.iOSDevice ? this.player.getCaptionsList() : this.captionLanguages;
    this.subtitleState = !this.subtitleState;
    if (this.subtitleState) {
      this.subtitleStateText = 'TVGUIDE.ON';
      if (this.selectedCC === undefined || this.selectedCC === 'Off') {
        previousIndex = 0;
        // previousIndex = this.iOSDevice ? 1 : 0;
      } else {
        previousIndex = captionLanguages.findIndex(i => i.label === this.selectedCC);
      }
      this.changeCaptionLanguage(previousIndex);
      // this.changeCaptionLanguage(previousIndex - (this.iOSDevice ? 1 : 0));
      this.videoAnalyticsService.updateMetaTags(this.player, 'Subtitles', 'ON');
    } else {
      this.subtitleStateText = 'TVGUIDE.OFF';
      if (this.iOSDevice) {
        this.player.hideCaptions();
        // this.player.setCurrentCaptions(0);
      } else {
        this.changeCaptionLanguage(this.captionLanguages.length);
      }
      this.videoAnalyticsService.updateMetaTags(this.player, 'Subtitles', 'OFF');
      this.selectedCC = 'Off';
    }
    setTimeout(() => this.setOptionsHeight('ccWindow', 'ccOption', this.captionLanguages.length + 2, 41), 0);
  }

  public changeCaptionLanguage(cc_index): void {
    let network, tracks;
    // let network, item, tracks;
    network = this.networkService.getPopupStatus();
    if (!network) {
      return;
    }
    // item = this.player;
    // tracks = item.getCaptionsList();
    tracks = this.iOSDevice ? this.captionLanguages : this.player.getTracks(this.player.Track.TEXT);
    if (cc_index >= 0 && cc_index < (tracks.length - (this.iOSDevice ? 0 : 1)) && this.subtitleState && this.selectedCC !== this.captionLanguages[cc_index].label) {
      if (this.iOSDevice) {
        this.player.showCaptions(this.captionLanguages[cc_index][0]);
        // this.player.setCurrentCaptions(cc_index + 1);
        this.selectedCC = this.captionLanguages[cc_index].label; // selectedCaption[1];
      } else {
        this.player.selectTrack(tracks[cc_index]);
        this.selectedCC = tracks[cc_index].label;
      }
    }
  }

  /*
    Change video Resolution based on selection:
    Input:
      max_bitrate : bitrate of the selection to find its index in the available bitrates list.
  */
  public changeMediaQuality(max_bitrate): any {
    // console.log('changeMediaQuality', max_bitrate);
    let network;
    network = this.networkService.getPopupStatus();
    if (!network) {
      return;
    }
    if (this.iOSDevice) {
      this.player.setBitrate(max_bitrate - 1);
      // this.player.setCurrentQuality(max_bitrate);
    } else {
      if (!max_bitrate) {
        this.player.enableAdaptiveBitrate();
      } else {
        this.player.selectTrack(this.player.getTracks(this.player.Track.VIDEO)[max_bitrate - 1]);
      }
    }
    if (this.mediaProfiles[max_bitrate]) {
      this.selectedQuality = this.mediaProfiles[max_bitrate].label;
      // this.videoAnalyticsService.reportPlaybackBitrate(this.mediaProfiles[max_bitrate].bandwidth);
      this.videoAnalyticsService.updateMetaTags(this.player, 'playbackQuality', this.selectedQuality);
    }
  }

  public closePopup(evt): any {
    if (this.videoIsLive === true || this.totalTimeMS === Infinity) {
      this.currentTimePercent = 100;
      this.progressCss();
    }
    if (evt.target.id === 'skipIntro' || evt.target.id === 'skipRecap' || evt.target.id === 'settingsWindow' || evt.target.id === 'ccWindow' || evt.target.id === 'moreMenu' || evt.target.id === 'moreIcon' || evt.target.id === 'ccToggle' || evt.target.id === 'settingsToggle') {
      return;
    } else if ($(evt.target).closest('#settingsWindow').length || $(evt.target).closest('#ccWindow').length || $(evt.target).closest('#moreMenu').length || $(evt.target).closest('#moreIcon').length || $(evt.target).closest('#ccToggle').length || $(evt.target).closest('#settingsToggle').length) {
      return;
    } else if (this.settingsOpen === true || this.ccOpen === true || this.moreVisible === 'visible') {
      let network;
      network = this.networkService.getPopupStatus();
      if (!network) {
        return;
      }
      this.settingsOpen = false;
      this.ccOpen = false;
      this.moreVisible = 'hidden';
      this.closeShare();
    }
    //  else if ((evt.target.id === 'playerInfoSection' || $(evt.target).closest('#playerInfoSection').length)) {
    //   if ($('#playerHeaderBar').css('visibility') === 'visible') {
    //     this.videocontrols();
    //   }
    // }
    this.resetTimer(evt);
  }

  public ngOnChanges(changes: any) {
    if (changes['videoAdData'] && changes['videoAdData'].previousValue === undefined && this.enablePlayback) {
      this.createPlaylist();
    }
    if (changes['pausevideo']) {
      if (changes['pausevideo'].currentValue === true && this.player) {
        this.pauseVideo();
      } else if (changes['pausevideo'].currentValue === false && this.player && !this.pausedByUser) {
        this.pausedByUser = false;
        this.playVideo();
      }
    }
    if (changes['videoIsLive']) {
      if (changes['videoIsLive'].currentValue === true) {
        this.videoType = 'Live';
      } else if (changes['videoIsLive'].currentValue === false) {
        this.videoType = 'Vod';
      }
    }
    if (changes['videoObject']) {
      if (changes['videoObject'].currentValue[0].channel_name === this.videoObject[0].channel_name && this.videoIsLive && this.player) {
        this.titleText = this.videoObject[0].title || 'Not Available';
        // this.titleText = this.videoObject[0].episode_name || this.videoObject[0].title || 'Not Available';
        this.videoService.setGAsubCategory('');
        this.gaSubCategory = '';
        this.videoService.clearContentClickDetails();
        this.clickDetails = this.videoService.getContentClickDetails();
        if (this.videoObject[0].type === 'live') {
          this.GAvideoClick('next');
        }
      } else if (this.videoObject[0].asset_type === 1 || this.videoObject[0].asset_type === 0) {
        if (changes['videoObject'].previousValue === undefined || changes['videoObject'].previousValue === changes['videoObject'].currentValue) {
          // no change in object
        } else if (this.unsupported && (!this.player || (this.player && this.getplayerState() === 'idle'))) {
        // } else if (this.unsupported && (!this.player || (this.player && this.player.getState() === 'idle'))) {
          this.ngOnInit();
        } else {
          this.settingsService.callContentLangFunction(changes['videoObject'].previousValue[0].audio_languages[0], 'videoDestroy');    
          if (this.adDetails) { // Conviva Ad Abandoned Event
            // let adAbandonedDetails;
            // adAbandonedDetails = {
            //   'Ad Abandoned': true,
            //   // 'Ad ID': this.adDetails.ima.ad.g.adId,
            //   'Ad ID': (this.videoAdData.type && this.videoAdData.type === 'vpaid') ? this.adDetails.id : this.adDetails.ima.ad.g.adId,
            //   'Ad Name': this.adDetails.adtitle
            // };
            // this.videoAnalyticsService.playerInsightsConviva(this.player, 'Ad Abandoned', adAbandonedDetails);
            // let adCompletionDetails;
            // adCompletionDetails = {
            //   'Ad Completion': false,
            //   // 'Ad ID': this.adDetails.ima.ad.g.adId,
            //   'Ad ID': (this.videoAdData.type && this.videoAdData.type === 'vpaid') ? this.adDetails.id : this.adDetails.ima.ad.g.adId,
            //   'Ad Name': this.adDetails.adtitle
            // };
            // this.videoAnalyticsService.playerInsightsConviva(this.player, 'Ad Completion', adCompletionDetails);
            this.adDetails = null;
          }
          if (!this.videoCompleted && this.player) {
            this.postGAwatchDuration(changes['videoObject'].previousValue);
            this.qgPlayed(changes['videoObject'].previousValue);
            this.videoAnalyticsService.updateMetaTags(this.player, 'videoEndPoint', this.currentTime);
            this.updateContinuewatching(changes['videoObject'].previousValue);
            this.sendToLotame(false);
          }
          if (this.ebvs && !this.unsupported) {
            let details;
            details = {
              'event': 'ExitBeforeStart',
              'VideoComplete': 'N/A',
              'EBVS': '1',
            };
            this.googleAnalyticPost(details);
          }
          this.videoAnalyticsService.clearAnalyticSession();
          this.titleText = this.videoObject[0].title || 'Not Available';
          // this.titleText = this.videoObject[0].episode_name || this.videoObject[0].title || 'Not Available';
          this.initializeOnVideoObjectChange();
          this.setBackgroundImage();
          this.gaSubCategory = this.videoService.getGAsubCategory();
          this.talamoosData = this.commonService.getTalamoosData();
          this.clickDetails = this.videoService.getContentClickDetails();
          this.checkForAES();
          if (this.unsupported) {
            $(this.document).ready(function() {
              $('#playerOverlay').css('display', 'none');
            });
            return;
          }
          this.currentTime = '00:00';
          this.totalTime = '00:00';
          this.hideThumbnail(0);
          this.thumbnailTime = '';
          this.tooltip_thumbnail = '';
          $('#livetime').text('');
          this.currentTimePercent = 0;
          this.totalTimeMS = 0;
          this.bufferValue = 0;
          this.gaWatchPercent = 0;
          this.gaCounter = 0;
          this.previousTime = 0;
          this.progressCss();
          clearTimeout(this.controlsTimer);
          clearInterval(this.countDownInterval);
          this.checkVideoInit(false);
          if (this.token && !this.videoIsLive && this.videoObject[0].asset_type !== epgAssetType && this.videoObject[0].asset_type !== 9 && this.videoObject[0].content_type !== 'trailer' && this.videoObject[0].content_type !== 'promo') {
            this.watchHistoryApi = new  WatchHistoryApi(this.http, null, this.configUser);
          }
          if (this.countryListData && this.countryListData[0] && this.countryListData[0].recommendations) {
            this.recoWatchHistoryApi = new  WatchHistoryApi(this.http, environment.recoWatchHistory, this.recoConfig);
          }
        }
      }
    }
  }

  public toggleCast(): any {
    let network, qualityIndex, audioIndex;
    network = this.networkService.getPopupStatus();
    if (!network) {
      return;
    }
    $('#PlayerContainer').css('pointer-events', 'none');

    if (this.videoObject[0].type === 'vod') {
      this.videoService.currentTime = this.isSeeking ? this.currentTimeSec : this.getPlayerCurrentTime();
    } else {
      this.videoService.currentTime = 0;
    }
    if (this.iOSDevice) {
      qualityIndex = this.player.getCurrentBitrateIndex() + 1;
      // audioIndex = this.player.getCurrentAudioTrack();
      if (this.audioLanguages && this.audioLanguages.length > 1) {
        this.videoService.selectedAudio = (this.audioLanguages.filter((i) => i.active)[0] || {}).language || 'default';
      } else {
        this.videoService.selectedAudio = 'default';
      }
    } else {
      qualityIndex = this.player.isAdaptiveBitrateEnabled() ? 0 : this.player.getActiveTracks()[this.player.Track.VIDEO] ? this.player.getActiveTracks()[this.player.Track.VIDEO].index + 1 : 0;
      audioIndex = this.player.getActiveTracks()[this.player.Track.AUDIO];
      this.videoService.selectedAudio = audioIndex ? audioIndex.language : 'default';
    }
    this.videoService.videoObjectSelected = this.videoObject[0];
    this.videoService.selectedQuality = this.getQualityIndexCast(qualityIndex);
    this.videoService.selectedSubtitle = this.subtitleState ? this.selectedCC : null;

    this.videoService.enableCastView = !this.videoService.enableCastView;
    this.videoService.toggleCastState(this.videoService.enableCastView);
    this.pauseVideo();
  }

  public getQualityIndexCast(index): any {
    if (index && this.mediaProfiles) {
      return (this.mediaProfiles.length - 1 - index);
    } else {
      return -1;
    }
  }

  public toggleMore(): any {
    let network;
    network = this.networkService.getPopupStatus();
    if (!network) {
      return;
    }
    $('.menuText').css('line-height', parseInt($('.menuIconTextBlock').height(), 10) + 'px');
    this.settingsOpen = false;
    this.ccOpen = false;
    if (this.moreVisible === 'hidden') {
      this.moreVisible = 'visible';
    } else {
      this.moreVisible = 'hidden';
      this.closeShare();
    }
  }

  public watchNow(): void {
    let network, show, watchListRequest, details, ctaString;
    ctaString = this.watched ? 'remove from watchlist' : 'add to watchlist';
    network = this.networkService.getPopupStatus();
    if (!network) {
      return;
    }
    show = {'id': this.videoObject[0].id, 'asset_type': this.videoObject[0].asset_type};
    if (this.token) {
      if (this.watched === true ) {
        watchListRequest = new  WatchlistApi(this.http, null, this.configUser);
        watchListRequest.v1WatchlistDelete(this.videoObject[0].id, this.videoObject[0].asset_type).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
          this.watched = false;
          this.userProfile.removeWatchData(show);
        },
        err => {
          this.watched = true;
          this.videoService.apiErrorEvent(err);
        });
      } else {
        watchListRequest = new  WatchlistApi(this.http, null, this.configUser);
        show = this.userProfile.createObject(this.videoObject[0]);
        watchListRequest.v1WatchlistPost(show).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
          this.watched = true;
          this.userProfile.setWatchData(show);
          details = {
            'event': 'WatchLater',
            'wLaterMetrics': '1'
          };
          this.googleAnalyticPost(details);
          this.qgAddToWatchList();
        },
        err => {
          this.videoService.apiErrorEvent(err);
          this.watched = false;
        });
      }
    } else {
      this.showSignUpPromt = true && !this.error;
      this.pauseVideo();
    }
    this.threeDotEvent(ctaString);
  }

  public qgAddToWatchList(): any {
    if (this.window.qg) {
      let asset_subtype, duration;
      duration = this.isSeeking ? this.currentTimeSec : this.getPlayerCurrentTime();
      asset_subtype = this.videoObject[0].category;
      switch (asset_subtype) {
        case 'video':
          this.qgraphevent('videosection_added_to_watch_later', {'video_name': (this.videoObject[0].title_en || this.notAvailable), 'language': this.selectedAudioqg, 'genre': this.videoObject[0].genre , 'time_spent': duration, 'country': this.country, 'image': this.background });
          break;
        case 'movie':
          this.qgraphevent('moviessection_added_to_watch_later', {'movie_name': (this.videoObject[0].title_en || this.notAvailable), 'genre': this.videoObject[0].genre, 'time_spent': duration, 'language': this.selectedAudioqg, 'country': this.country , 'image': this.background });
          break;
        case 'tvshow':
          this.qgraphevent('TVshowssection_added_to_watch_later', {'program_name': (this.videoObject[0].title_en || this.notAvailable) , 'channel_name': this.videoObject[0].channel_name , 'genre': this.videoObject[0].genre, 'time_spent': duration, 'language': this.selectedAudioqg, 'episode_number': this.videoObject[0].episode_no, 'episode_name': (this.videoObject[0].episode_name_en || this.notAvailable), 'country': this.country, 'image': this.background  });
          break;
        case 'original':
          this.qgraphevent('originalssection_added_to_watch_later', {'program_name': (this.videoObject[0].title_en || this.notAvailable) , 'channel_name': this.videoObject[0].channel_name , 'genre': this.videoObject[0].genre, 'time_spent': duration, 'language': this.selectedAudioqg, 'episode_number': this.videoObject[0].episode_no, 'episode_name': (this.videoObject[0].episode_name_en || this.notAvailable), 'country': this.country , 'image': this.background  });
          break;
        default:
          break;
      }
    }
  }

  public openShare(): void {
    let network;
    network = this.networkService.getPopupStatus();
    if (!network) {
      return;
    }
    this.shareUrl = this.videoObject[0].share_url;
    this.showShare = 'showShare';
    // this.showshare = true
    this.showshare = !this.showshare;
    this.fontResize();
    this.threeDotEvent('share');
  }

  public closeShare(): any {
    this.showShare = '';
    this.showshare = false;
    this.fontResize();
  }

  public shareNetwork(event: any): any {
    let details;
    details = {
      'event': 'ShareClicks',
      'SocialPlatform': event,
      'SocialAction': 'Share',
      'SocialMetrics': '1',
    };
    this.googleAnalyticPost(details);
    this.videoAnalyticsService.updateMetaTags(this.player, 'socialNetwork', event);
  }

  /*for reminder pop up*/
  public closeReminder(event): any {
    this.showSignUpPromt = false;
  }
  /*for reminder pop up*/

  public backRoute(): any {
    this.update.emit(null);
  }

  public imageError(): any {
    this.image_container.nativeElement.src = this.defaultImage;
  }

  public imageErrorThumbnail(): any {
    if (this.thumbnail_container && this.thumbnail_container.nativeElement && this.thumbnail_container.nativeElement.src) {
      this.thumbnail_container.nativeElement.src = this.defaultThumbnailImage;
    }
  }

  public qgPlayed(videoObject): any {
    if (this.window.qg) {
      let asset_subtype, duration;
      duration = this.isSeeking ? this.currentTimeSec : this.getPlayerCurrentTime();
      asset_subtype = this.videoIsLive ? 'live' : videoObject[0].category;
      switch (asset_subtype) {
        case 'movie':
          this.qgraphevent('moviessection_played', {'movie_name': (videoObject[0].title_en || this.notAvailable), 'language': this.selectedAudioqg, 'genre': videoObject[0].genre, 'time_spent': duration, 'country': this.country, 'image': this.background });
          break;
        case 'tvshow':
          this.qgraphevent('TVshowssection_played', {'program_name': (videoObject[0].title_en || this.notAvailable) , 'language': this.selectedAudioqg, 'channel_name': videoObject[0].channel_name , 'genre': videoObject[0].genre, 'time_spent': duration, 'episode_number': videoObject[0].episode_no, 'episode_name': (videoObject[0].episode_name_en || this.notAvailable), 'country': this.country, 'image': this.background });
          break;
        case 'video':
          this.qgraphevent('videosection_played', {'video_name': (videoObject[0].title_en || this.notAvailable) , 'language': this.selectedAudioqg, 'genre': videoObject[0].genre , 'time_spent': duration, 'country': this.country , 'image': this.background});
          break;
        case 'original':
          this.qgraphevent('originalssection_played', {'program_name': (videoObject[0].title_en || this.notAvailable) , 'language': this.selectedAudioqg, 'channel_name': videoObject[0].channel_name , 'genre': videoObject[0].genre, 'time_spent': duration, 'episode_number': videoObject[0].episode_no, 'episode_name': (videoObject[0].episode_name_en || this.notAvailable), 'country': this.country, 'image': this.background });
          break;
        case 'live':
          this.qgraphevent('live_channel_played', {'channel_name': (videoObject[0].channel_name || this.notAvailable) , 'language': this.selectedAudioqg, 'time_spent': this.notAvailable, 'genre': videoObject[0].genre, 'country': this.country, 'image': this.background });
          break;
        default:
          break;
      }
      this.qgraphevent('video_play', {'video_name': (videoObject[0].title_en || this.notAvailable), 'genre': videoObject[0].genre , 'language': this.selectedAudioqg, 'sections': this.videoService.getQGsection(videoObject[0]), 'country': this.country, 'time_spent': duration , 'image': this.background });
    }
  }

  public googleAnalyticPost(details): any {
    if (!this.videoItemforGA || this.videoItemforGA.Content_ID !== this.videoObject[0].id) {
      this.videoDetails();
    }
    let videoItemforGA;
    videoItemforGA = $.extend({}, this.videoItemforGA, details);
    this.videoService.googleAnalyticPost(videoItemforGA, this.gaSubCategory, this.clickDetails);
    // this.videoService.googleAnalyticPost(videoItemforGA, this.gaSubCategory);
  }

  public videoDetails(): any {
    let image;
    image = this.settingsService.getbasePath() + this.videoObject[0].id + '/list/' + '270x152/' + this.videoObject[0].image;
    this.videoItemforGA = {
      'VideoName': this.videoObject[0].title_en || this.notAvailable,
      'VideoCategory': this.videoObject[0].genre ? this.videoObject[0].genre.replace(', ', ',') : this.notAvailable,
      'VideoSection': this.videoService.getVideoSection(this.videoObject[0].asset_type, this.videoObject[0].category),
      'Content_Specification': this.videoService.getContentSpec(this.videoObject[0].content_type), // asset sub_type
      'VideoSubTitle': this.videoObject[0].episode_name_en || this.videoObject[0].title_en || this.notAvailable,
      'TVChannels': this.videoService.getChannels(this.videoObject[0].channel_name),
      'VideoDuration': this.videoObject[0].duration || 0,
      'Time_Slot': this.videoObject[0].time_slot || this.notAvailable, // pass time slot of the programme
      'Episode_Number': this.videoObject[0].episode_no || this.notAvailable,
      'Tumbnail_Image': image || this.notAvailable,
      'Content_Date': this.videoObject[0].release_date || this.notAvailable,
      'TopCategory': this.videoAnalyticsService.getTopCategory(this.videoObject[0].category),
      'Video_Language': this.audioLangsString || this.notAvailable,
      'Content_ID': this.videoObject[0].id || this.notAvailable,
      'Show_ID': (this.videoObject[0].asset_type === 1 ? this.videoObject[0].series_id : this.videoObject[0].id) || this.notAvailable,
      'Season_ID': this.videoObject[0].season_id || this.notAvailable,
      // 'ShowSubtype': (this.videoObject[0].asset_type === 1  ? this.videoObject[0].category : this.notAvailable) || this.notAvailable,
      // 'ShowSubtype': ((this.videoObject[0].asset_type === 1)  ? (this.videoObject[0].category ?  this.videoService.getTopCategory(this.videoObject[0].category) : this.notAvailable) : ((this.videoObject[0].asset_type === 0) ? (this.videoObject[0].category) : (this.notAvailable))) || this.notAvailable,
      'ShowSubtype': this.videoService.getShowSubtype(this.videoObject[0].asset_type, this.videoObject[0].category, this.videoObject[0].content_type) || this.notAvailable,
      // 'ShowSubtype': (((this.videoObject[0].asset_type === 1) || (this.videoObject[0].asset_type === 0)) ? this.videoObject[0].category : this.notAvailable) || this.notAvailable,
      'BroadcastState': (this.videoObject[0].asset_type === 1 ? this.videoObject[0].broadcastState : this.notAvailable) || this.notAvailable,
    };
    this.videoItemforGA = $.extend({}, this.videoItemforGA, this.videoService.getDisplayContentLang());
  }

  private sendToLotame(complete): any {
    let duration;
    duration = this.isSeeking ? this.currentTimeSec : (this.player ? this.getPlayerCurrentTime() : 0);
    if (this.recoDmpSync && ((duration >= 60) || complete)) {
      this.lotameService.getContentDetails(this.videoObject[0], this.currentTimePercent, this.selectedAudioString);
    }
  }

  private setFullscreen(state: any = null): any {
    state = state === null ? this.getPlayerFullscreen() : state;
    if (this.iOSDevice) {
      this.player.setFullscreen(state);
    } else {
      if (state) {
        this.player.enterFullscreen();
      } else {
        this.player.exitFullscreen();
      }
    }
  }

  public close(): void {
    clearTimeout(this.controlsTimer);
    this.totalTime = null;
    if (!this.player || (this.player && this.getplayerState() === 'idle')) {
    // if (!this.player || (this.player && this.player.getState() === 'idle')) {
      return;
    }
    if (this.getPlayerFullscreen()) {
      this.setFullscreen(false);
    }
    if (this.watchHistoryApi && this.inHistory) {
      this.updateElapsedTime('', null);
    } else if (this.watchHistoryApi && !this.inHistory && !this.deletedInHistory) {
      this.postHistory('', null);
    } else if (this.watchHistoryApi) {
      // this.videoService.toggleHistoryStatus(true);
    }
    this.updateRecoHistory('', null);
    this.postGAwatchDuration(this.videoObject);
    this.videoAnalyticsService.updateMetaTags(this.player, 'videoEndPoint', this.currentTime);
    this.videoAnalyticsService.clearAnalyticSession();
    this.sendToLotame(false);
    this.qgPlayed(this.videoObject);
    // this.player.remove();
    this.removePlayer();
  }

  public removePlayer(): any {
    if (this.player) {
      if (this.iOSDevice) {
        this.player.destroy();
        // this.window.radiantPlayer = '';
      } else {
        this.player.destroy();
        this.player = '';
        // this.window.kalturaPlayer = '';
        // this.removePlayerEventListeners();
      }
    }
  }

  private onDestroyCompleted(): any {
    let parentContainer;
    parentContainer = this.playerContainer.parentNode;
      if (parentContainer) {
        try {
          parentContainer.removeChild(this.playerContainer);
          // console.log(parentContainer);
          let newDiv;
          newDiv = document.createElement('div');
          newDiv.setAttribute('id', 'videoDiv');
          newDiv.setAttribute('class', 'occupyAvailableSpace');
          newDiv.style.width = '100%';
          newDiv.style.height = '100%';
          parentContainer.appendChild(newDiv);
        } catch (e) {
          console.log(e);
        }
      }
      this.player = '';
      this.playerContainer = '';
      if (this.initializeAfterDestroy) {
        this.startVideo();
      }
  }

  public destroyPeer5(): any {
    if (this.configData.peer5 && this.peer5enabled && environment.isPeer5) {
      this.peer5enabled = false;
      this.window.peer5.destroy();
    }
  }

  public ngOnDestroy(): any {
    if (this.nextPlayTimeout) {
      clearTimeout(this.nextPlayTimeout);
    }
    if (this.countDownInterval) {
      clearInterval(this.countDownInterval);
    }
    // if (environment.charmboard && this.videoObject[0].content_type === 'episode' && this.window.destroyCBplugin) {
    //  $('.headerInit').css('cssText', 'z-index: 2 !important;');
    //   destroyCBplugin();
    // }
    this.destroyPeer5();
    // if (this.checkMoat === true && this.window.moatjw) {
    //   this.window.moatjw.removeAll();
    // }
    if (this.videoObject[0].asset_type !== 0) {
      this.linkservice.removeCanonicalLink();
    }
    let details;
    if (this.ebvs && !this.unsupported) {
      details = {
        'event': 'ExitBeforeStart',
        'VideoComplete': 'N/A',
        'EBVS': '1',
      };
      this.googleAnalyticPost(details);
    }
    this.close();
    if ((this.browser.name === 'Chrome' || this.browser.name === 'CriOS') && this.browser.version > 50 && this.window.cast && this.window.cast.framework && cast && cast.framework) {
      cast.framework.CastContext.getInstance().removeEventListener(cast.framework.CastContextEventType.CAST_STATE_CHANGED);
    }
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
    let routeCheck;
    routeCheck = this.headerService.getLanguageScreen();
    if (this.contentPopup === false && routeCheck !== true && this.videoObject[0].audio_languages[0]) {
      this.settingsService.callContentLangFunction(this.videoObject[0].audio_languages[0], 'video');
    }
    if (this.adDetails) { // Conviva Ad Abandoned Event
      // let adAbandonedDetails;
      // adAbandonedDetails = {
      //   'Ad Abandoned': true,
      //   // 'Ad ID': this.adDetails.ima.ad.g.adId,
      //   'Ad ID': (this.videoAdData.type && this.videoAdData.type === 'vpaid') ? this.adDetails.id : this.adDetails.ima.ad.g.adId,
      //   'Ad Name': this.adDetails.adtitle
      // };
      // this.videoAnalyticsService.playerInsightsConviva(this.player, 'Ad Abandoned', adAbandonedDetails);
      // let adCompletionDetails;
      // adCompletionDetails = {
      //   'Ad Completion': false,
      //   // 'Ad ID': this.adDetails.ima.ad.g.adId,
      //   'Ad ID': (this.videoAdData.type && this.videoAdData.type === 'vpaid') ? this.adDetails.id : this.adDetails.ima.ad.g.adId,
      //   'Ad Name': this.adDetails.adtitle
      // };
      // this.videoAnalyticsService.playerInsightsConviva(this.player, 'Ad Completion', adCompletionDetails);
      this.adDetails = null;
    }
  }

  public qgraphevent(eventname, object) {
    if (this.window.qg) {
      if (this.qgraph) {
        delete object.country;
        qg('event', eventname, object);
      } else {
        object.state = this.localStorage.getItem('state_code') || this.notAvailable;
        qg('event', eventname, object);
      }
    }
  }
 
  // adString tranlation function
  public translateString(text): any {
    this.translate.get([text]).takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.contentText = value[text];
    });
  }

  public threeDotEvent(ctadetails) {
    let langObj, threeDotClickEvent;
    langObj = this.videoService.getDisplayContentLang();
    threeDotClickEvent = {
      'event': 'buttonClicks',
      'cta': ctadetails,
      'UserType': this.token ? 'loggedin' : 'guest',
      'ContentLang': langObj.Content_Lang,
      'DisplayLang': langObj.Display_Lang,
      'Click_Metrics': '1',
      'NetworkType': '',
      'VideoStartTime': this.videoObject[0].start_time ? this.videoObject[0].start_time : this.notAvailable ,
      'Content_Show': this.videoObject[0].episode_name_en || this.videoObject[0].title_en || this.notAvailable,
      'modelName': this.talamoosData.modelName || this.notAvailable,
      'clickID': this.talamoosData.clickID || this.notAvailable,
      'Carousal_Name': this.clickDetails.SubCategory || this.notAvailable
    };
    if (!this.videoItemforGA || this.videoItemforGA.Content_ID !== this.videoObject[0].id) {
      this.videoDetails();
    }
    let videoItemforGA;
    videoItemforGA = $.extend({}, this.videoItemforGA, threeDotClickEvent);
    this.videoService.threeDotEvent(videoItemforGA, this.clickDetails);
  }

  public getParameterFromURL(name) {
    var url = window.location.href;
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
      results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
  }
}
