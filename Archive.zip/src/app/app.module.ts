import { BrowserModule , Title} from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { MdNativeDateModule, MdSnackBar, MdSnackBarConfig} from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import {NoopAnimationsModule} from '@angular/platform-browser/animations';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { ViewContainerRef } from '@angular/core';
import { AppComponent } from './app.component';
import { RouterModule } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { CarouselModule } from './carousel/carousel.module';
import { HomeGridModule } from './home-grid/home-grid.module';
import 'hammerjs';
import { Http} from '@angular/http';
import { AppRoutingModule } from './app-routing.module';
import { HomeComponent } from './home/home.component';
import { FilterService } from './services/filter.service';
import { WindowRefService } from './services/window-ref.service';
import { FilterModule } from './filter/filter.module';
import { FooterModule } from './footer/footer.module';
import { SortModule } from './sort/sort.module';
import { ScrollListModule } from './scroll-list/scroll-list.module';
import {TranslateModule, TranslateLoader} from '@ngx-translate/core';
import {TranslateHttpLoader} from '@ngx-translate/http-loader';
import { SignInComponent } from './sign-in/sign-in.component';
import { SigninBannerComponent } from './signin-banner/signin-banner.component';
import { HeaderservicesService } from './services/headerservices.service';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { MoreComponent } from './more/more.component';
import { SearchComponent } from './search/search.component';
import { EpgService } from './services/epg.service';
import { ProfileActivationScreenComponent } from './profile-activation-screen/profile-activation-screen.component';
import {UserProfileService} from './services/user-profile.service';
import { HamburgerComponent } from './hamburger/hamburger.component';
import { SettingsService } from './services/settings.service';
import { LanguagesComponent } from './languages/languages.component';
import { ContentLanguagesComponent } from './languages/content-language/content-language.component';
import { VideoAnalyticsService } from './services/video-analytics.service';
import { FooterService } from './services/footerdata.service';
import { VideoService } from './services/video.service';
import { LotameService } from './services/lotame.service';
import { DeviceApiService } from './services/device-api.service';
import { UserApiService } from './services/user-api.service';
import {GoogleAnalyticsService} from './services/google-analytics.service';
import { ReminderSignupModule } from './reminder-signup/reminder-signup.module';
// AoT requires an exported function for factories
import { RouteService } from './services/route.service';
import { HammerGestureConfig, HAMMER_GESTURE_CONFIG } from '@angular/platform-browser';
import { SubscriptionService } from './services/subscription.service';
import {  NetworkService  } from './services/network.service';
import { UseractionapiService } from './services/useractionapi.service';
import { TwitterloginComponent } from './twitterlogin/twitterlogin.component';
import { ProfileDropdownComponent } from './profile-dropdown/profile-dropdown.component';
import { APP_BASE_HREF, DatePipe } from '@angular/common';
import { environment } from 'environments/environment';
import { LinkService } from './services/link.service';
import { GoogleAdService } from './services/google-ad.service';
import { SeoService } from './services/seo.service';
import { CommonService } from './services/common.service';
import * as $ from 'jquery';
import { LanguageSlideComponent } from './language-slide/language-slide.component';
import { CountryCheckPopupComponent } from './country-check-popup/country-check-popup.component';
import { ParentalAuthenticateComponent } from './parental-control/parental-authenticate/parental-authenticate.component';
import { HeaderScrollComponent } from './header-scroll/header-scroll.component';
import { CookiesCheckPopupComponent } from './cookies-check-popup/cookies-check-popup.component';
import { GdprPolicyComponent } from './gdpr-policy/gdpr-policy.component';
import { DialogPopUpComponent } from './dialog-pop-up/dialog-pop-up.component';
import { LaunchOfferPopupComponent } from './launch-offer-popup/launch-offer-popup.component';
import {CurrencyPipe} from '@angular/common';
// import { BreadCrumbComponent } from './bread-crumb/bread-crumb.component';
import {KeepHtmlModule} from './custom-filters/keep-html.module';
import {DataUnavailableModule} from './data-unavailable/data-unavailable.module';
import { CheckBoxModule } from './checkbox/checkbox.module';
import { VideoCastModule } from './video-cast/videoCast.module';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { AuthenticateDeviceComponent } from './authenticate-device/authenticate-device.component';
import { FreeEpisodePopupComponent } from './free-episode-popup/free-episode-popup.component';
import { CardsComponent } from './free-episode-popup/cards/cards.component';
import { NewsGridModule } from './news-grid/news-grid.module';
import { BreadCrumbModule } from './bread-crumb/bread-crumb.module';
import { ContentLangpopupComponent } from './content-langpopup/content-langpopup.component';
import { InternationalComponent } from './international/international.component';
import { InternationalLoginComponent} from './international/international-login/international-login.component';
import { ModalComponent } from './_directives';
import { ModalService } from './services/modal.service';
import { InternationalGdprPolicyComponent } from './international-gdpr-policy/international-gdpr-policy.component';
import { CountrySelectPopupComponent } from './country-select-popup/country-select-popup.component';
import { HeaderEnrichmentComponent } from './header-enrichment/header-enrichment.component';
declare var Hammer: any;
declare var window;

export function HttpLoaderFactory(http: Http) {
    return new TranslateHttpLoader(http, 'i18n/', '.json?ver=' + window.appVersion);
}
export class MyHammerConfig extends HammerGestureConfig  {
  public overrides = <any>{
    'swipe': {velocity: 0.4, threshold: 20} // override default settings
  };

   public buildHammer(element: HTMLElement) {
    const mc = new Hammer(element, {
      touchAction: 'pan-y'
    });
    return mc;
  }
}

/* If Cookies is disabled, show can alert to enable */
let cookieEnabled;
cookieEnabled = navigator.cookieEnabled;
if (!cookieEnabled) {
  alert('LocalStorage access denied! Please enable cookies to continue to the app..');
}


export function getBaseLocation(routeservice: RouteService) {

  return routeservice.forappmodule();
}



// for (var j = arr.length - 1; j >= 0; j--) {
//     if (arr[j] === searchItem) {
//         arr.splice(j, 1);
//         break;
//     }
// }

// for (var i = 0; i < arr.length ; i++) {
//      var x
//      x = document.createElement('LINK');
//      x.setAttribute('rel', 'alternate');
//      if (arr[i] !== 'en') {
//        x.setAttribute('href', window.location.origin + '/' + arr[i] )
//      } else {
//        x.setAttribute('href', window.location.origin + '/')
//      }
//       x.setAttribute('hreflang', arr[i]);
//       document.head.appendChild(x);
//   }
@NgModule({
  declarations: [
  AppComponent,
  HeaderComponent,
  HomeComponent,
  SignInComponent,
  SigninBannerComponent,
  LoginComponent,
  RegisterComponent,
  MoreComponent,
  SearchComponent,
  ProfileActivationScreenComponent,
  HamburgerComponent,
  LanguagesComponent,
  ContentLanguagesComponent,
  TwitterloginComponent,
  ProfileDropdownComponent,
  LanguageSlideComponent,
  CountryCheckPopupComponent,
  ParentalAuthenticateComponent,
  HeaderScrollComponent,
  CookiesCheckPopupComponent,
  GdprPolicyComponent,
  DialogPopUpComponent,
  LaunchOfferPopupComponent,
  // BreadCrumbComponent,
  AuthenticateDeviceComponent,
  FreeEpisodePopupComponent,
  CardsComponent,
  ContentLangpopupComponent,
  InternationalComponent,
  InternationalLoginComponent,
  ModalComponent,
  InternationalGdprPolicyComponent,
  CountrySelectPopupComponent,
  HeaderEnrichmentComponent,
  ],
  imports: [
  BrowserModule,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  MdNativeDateModule,
  HttpModule,
  AppRoutingModule,
  FilterModule,
  FooterModule,
  SortModule,
  DataUnavailableModule,
  FormsModule,
  ReactiveFormsModule,
  VideoCastModule,
  HomeGridModule,
  ScrollListModule,
  ReminderSignupModule,
  CarouselModule,
  KeepHtmlModule,
  CheckBoxModule,
  InfiniteScrollModule,
  NewsGridModule,
  BreadCrumbModule,
  TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: HttpLoaderFactory,
            deps: [Http]
          }
        })
  ],
  providers: [
  FilterService,
  WindowRefService,
  HeaderservicesService,
  EpgService,
  UserProfileService,
  SettingsService,
  VideoAnalyticsService,
  FooterService,
  VideoService,
  LotameService,
  DeviceApiService,
  SubscriptionService,
  NetworkService,
  UseractionapiService,
  GoogleAdService,
  CommonService,
  LinkService,
  Title,
  SeoService,
  CurrencyPipe,
  DatePipe,
  {provide: HAMMER_GESTURE_CONFIG,
    useClass: MyHammerConfig
  } , {provide: APP_BASE_HREF, useFactory: getBaseLocation, deps: [RouteService]},
  UserApiService,
  RouteService,
  GoogleAnalyticsService,
  ModalService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
