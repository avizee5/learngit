import { Component, OnInit, Input, OnDestroy} from '@angular/core';
import * as $ from 'jquery';
import {  NetworkService  } from '../services/network.service';
import {environment} from '../../environments/environment';

@Component({
  selector: 'app-signin-banner',
  templateUrl: './signin-banner.component.html',
  styleUrls: ['./signin-banner.component.less']
})
export class SigninBannerComponent implements OnInit, OnDestroy {
  @Input() public banner: any;
  public current: any;
  private selected: any;
  private currentIndex: number;
  public checkSrc: Array<string>;
  private check: any;
  private uncheck: any;
  private prevSelect: any;
  private timer: any;
  private loading: any;
  private scope: any;
  public assetbasepath: any;
  constructor(private networkService: NetworkService) {
    this.assetbasepath = environment.assetsBasePath;
  }

  public ngOnInit () {
    this.uncheck = this.assetbasepath + 'assets/sign_in/signin_banner_unselected.png';
    this.check = this.assetbasepath + 'assets/sign_in/signin_banner_selected.png';
    let index = 0;
    this.checkSrc = [];
    while (index < this.banner.length) {
      if (index === 0) {
        this.checkSrc.push(this.check);
      } else {
        this.checkSrc.push(this.uncheck);
      }
      index ++;
    }
    this.prevSelect = 0;
    this.selected = true;

    this.currentIndex = 0;
    this.current = this.banner[this.currentIndex];
    this.startCarousel();
}

public ngOnDestroy() {
	if (this.timer) {
      clearInterval(this.timer);
   }
}


public showImage () {
  $('.div-outer1').css('height', 'inherit');
}
  private timerFunction = function() {
      const scope = this;
      this.timer = setInterval(function() {
        scope.currentIndex++;
        if (scope.currentIndex > scope.banner.length - 1 ) {
          scope.currentIndex = 0;
        }
        scope.current = scope.banner[scope.currentIndex];
        scope.checkSrc[scope.prevSelect] = scope.uncheck;
        scope.checkSrc[scope.currentIndex] = scope.check;
        scope.prevSelect = scope.currentIndex;
      }, 4000);
    };
  private changeCarousel = function (index) {

    clearInterval(this.timer);
    this.currentIndex = index;
    this.timerFunction();
    this.current = this.banner[index];
    this.checkSrc[this.prevSelect] = this.uncheck;
    this.checkSrc[index] = this.check;
    this.prevSelect = index;
  };

  private nextPrevious = function(index) {
    clearInterval(this.timer);
    this.currentIndex = this.currentIndex + index;
    if (this.currentIndex > this.banner.length - 1 ) {
      this.currentIndex = 0;
    } else if (this.currentIndex < 0) {
      this.currentIndex = this.banner.length - 1 ;
    }
    this.current = this.banner[ this.currentIndex ];
    this.checkSrc[this.prevSelect] = this.uncheck;
    this.checkSrc[this.currentIndex] = this.check;
    this.prevSelect = this.currentIndex;
    this.timerFunction();
  };

  private stopCarousel = function () {
    clearInterval(this.timer);
  };
  private startCarousel = function () {
    this.timerFunction();
  };
}

