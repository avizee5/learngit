import { Component, OnInit, ViewChild, ElementRef, OnDestroy, ValueProvider} from '@angular/core';
import { FilterService } from '../services/filter.service';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
// import to control carousel in your views
import { CarouselComponent } from '../carousel/carousel.component';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { Http} from '@angular/http';
import {CollectionApi} from '../../data/gwapi_catalog/api/CollectionApi';
import {TvShowApi} from '../../data/catalog/api/TvShowApi';
import * as $ from 'jquery';
import { Location } from '@angular/common';
import { UserProfileService } from '../services/user-profile.service';
import {FavoritesApi, RemindersApi, UserApi, WatchlistApi } from '../../data/user/api/api';
import { VideoService } from '../services/video.service';
import { environment } from '../../environments/environment';
import { RouteService } from '../services/route.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { HeaderservicesService } from '../services/headerservices.service';
import {  NetworkService  } from '../services/network.service';
import { SettingsService } from '../services/settings.service';
import { CommonService } from '../services/common.service';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { LinkService } from '../services/link.service';
import { SubscriptionService } from '../services/subscription.service';
import { SeoService } from '../services/seo.service';
import 'rxjs/add/operator/timeout';
declare let googletag;
declare const qg;

@Component({
  selector: 'app-zee-originals-landing',
  templateUrl: './zee-originals-landing.component.html',
  styleUrls: ['./zee-originals-landing.component.less']
})
export class ZeeOriginalsLandingComponent implements OnInit, OnDestroy {
  @ViewChild(CarouselComponent) public carousel_element: CarouselComponent;
  @ViewChild('load_button') public load_button: ElementRef;
  public collectionTags: any;
  public color: string;
  public mode: string;
  public value: number;
  public bufferValue: number;
  public latest: any;
  public trending: any;
  public weekly: any;
  public new: any;
  public page: any;
  public banner: any;
  public interface: string;
  public count: number;
  public count1: number;
  public count2: number;
  public count3: number;
  public count4: number;
  public tvshows: string;
  public carousel: any;
  public carouselCollection: any;
  public current: any;
  public index: number;
  public limit: number;
  public selectedFilters: any;
  public filterbar = false;
  public filter_titles: any;
  public id: any;
  public name: any;
  public watch: any;
  public sub: any;
  public urlString: any;
  public zeeOriginals: any;
  public data: any;
  public title: any;
  public all: any;
  public view: any = 'zeeoriginals';
  public destroyFilter: Subscription;
  public filterFlag = false;
  public languages: any;
  public category: any;
  public showcase: any;
  public totalPages: any;
  public carouselTitle: any;
  public dataAvailable: any = true;
  public contentAvailable: any = true;
  public favoriteList: any;
  public watchList: any;
  public router: any;
  public router2: any;
  public pageSize: any = 24;
  public zeeOriginalsCopy: any;
  public originalsBucket: any= [];
  public pageName: any;
  public touchScreen: any = false;
  public processPending: any = false;
  public googletagAvailable: any;
  public assetBasePath = environment.assetsBasePath;
  public tagValue: any;
  // public desktopTag: any;
  // public mobileTag: any;
  // public timer: any;
  public localstorage: any;
  public window: any;
  public document: any;
  public navigator: any;
  // public mobilediv: any;
  // public desktopdiv: any;
  // public mastTag: any;
  // public mastDivID: any;
  public plans: any;
  public premiumUser: any = false;
  // public defaultDesktopTag: any = '/21665149170/Z5_Desktop_ShowListing_970x90_ATF';
  // public defaultMobileTag: any = '/21665149170/Z5_Mobile_ShowListing_320x50_ATF';
  private ngUnsubscribe = new Subject<any>();
  // public mobile = false;
  public countryCode: any;
  public apiRetry: any = 2;
  public apiRetryCount: any = 1;
  public showMastAds: any = false;
  private countryListget: any;
  private collectionsWeb: any;
  private collectionsConfig: any;
  private collectionID: any;
  public dataTitle: any = '';
  public gridView: any = false;
  public homeView: any = false;
  public collectionPageNo = 1;
  public collectionPageSize: any = 5;
  public itemLimit: any = 20;
  public totalCollectionPages: any;
  public infiniteScrollDistance: any = 0.5;

  public scrollCount: any = 0;

  public nativeTag: any;
  public nativeAds: any;
  public nativeAdPosition: any;
  public skippedAdIndex: any;
  public traylength: any;
  public footerAd: any;
  public count_ad: any = 0;
  public timer: any = [];
  constructor (private subscriptionService: SubscriptionService, private linkservice: LinkService, @Inject(PLATFORM_ID) private platformId: Object, private commonService: CommonService,  private settingsService: SettingsService, private networkService: NetworkService, private gtm: GoogleAnalyticsService, private routeservice: RouteService ,
    private videoService: VideoService,  private location: Location, private filterService: FilterService, private route: ActivatedRoute ,  private router_link: Router, private http: Http, private userProfileService: UserProfileService, private headerservicesService: HeaderservicesService, private seoservice: SeoService ) {
    this.router = router_link;
    if (isPlatformBrowser(this.platformId)) {
      this.localstorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
    this.router2 = this.window.location.pathname;
    this.routeservice.setRoute(this.router2);
    this.routeservice.setLoginRoute(this.window.location.pathname);
    this.headerservicesService.viewChange(this.router2);
  }
  public ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.localstorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }

    this.countryCode = this.settingsService.getCountry();
    this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'zee5originals'  } );
    this.gtm.storeWindowError();
    this.tagValue = this.settingsService.getCompleteConfig();
    this.countryListget  = this.settingsService.getCountryValueNew();
    this.collectionsWeb = (this.countryListget && this.countryListget[0] && this.countryListget[0].collections && this.countryListget[0].collections.web_app !== null) ? this.countryListget[0].collections.web_app : undefined;
    this.collectionsConfig = (this.tagValue && this.tagValue.collections && this.tagValue.collections.web_app !== null) ? this.tagValue.collections.web_app : undefined;
    if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i) || this.window.innerWidth <= 768) {
      this.touchScreen = true;
      this.infiniteScrollDistance = 6;
    }
    if (this.collectionsWeb !== undefined) {
      this.collectionID = this.collectionsWeb.originals;
    } else if (this.collectionsConfig !== undefined) {
      this.collectionID = this.collectionsConfig.originals;
    } else {
      this.collectionID = environment.originalPageCollectionId;
    }
    // this.showMastAds = this.tagValue && this.tagValue.masthead_ads && this.tagValue.masthead_ads.web && (this.premiumUser && this.tagValue.masthead_ads.web.premium_user && (this.tagValue.masthead_ads.web.premium_user[this.countryCode] === undefined ? this.tagValue.masthead_ads.web.premium_user['default'] : this.tagValue.masthead_ads.web.premium_user[this.countryCode])) || !this.premiumUser;
    this.commonService.qgraphevent('Originalsection_visited', {'country': this.countryCode, 'state': localStorage.getItem('state_code')});
    let network;
    network = this.networkService.getScreenStatus();
    if (network) {
      // this.plans = this.subscriptionService.checkPlanApiSuccess(false);
      // if (this.plans && this.plans.length > 0) {
      //   this.premiumUser = true;
      // }
      // this.googletagAvailable = this.localstorage.getItem('googletag')
      // this.googletagAvailable = this.commonService.checkGoogleTag();
      // if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
      //   this.mobile = true;
      // }
      // this.googletagAvailable = this.localstorage.getItem('googletag')
      // this.googletagAvailable = this.commonService.checkGoogleTag();
      // if (this.showMastAds && this.mobile && this.tagValue.masthead_ads.web['mobile'] && this.tagValue.masthead_ads.web && this.tagValue.masthead_ads.web['mobile'].originals && this.tagValue.masthead_ads.web['mobile'].originals[0]) {
      //   this.mastTag = this.tagValue.masthead_ads.web['mobile'].originals[0].ad_tag;
      //   this.mastDivID = this.tagValue.masthead_ads.web['mobile'].originals[0].div_id;
      // }
      // if (this.mastDivID && this.mastTag) {
      //   this.adCreation(this.mastTag, this.mastDivID, ['fluid']);
      // }
      $('#loaderPage').css('display', 'block');

      this.showcase = true;
      this.pageName = 'zee originals';
      this.gtm.sendPageName(this.pageName);
      this.gtm.sendEvent();
      let scope;
      scope = this;
      this.window.onpopstate = function() {
        if (scope.filterbar === true) {
          scope.filterbar = false;
        }
      };
      this.initialApi();
      this.count = 0;
      this.tvshows = 'tvshows';
      this.index = 12;
      if (this.localstorage.getItem('ContentLang') && this.localstorage.getItem('country_code') !== 'IN'){
        let contentLang, UserContentLanguage, token;
        contentLang = [this.localstorage.getItem('ContentLang')];
        UserContentLanguage = [this.localstorage.getItem('UserContentLanguage')];
        token = localStorage.getItem('token');
        if (token) {
          if (UserContentLanguage.length === 1 && UserContentLanguage[0] === 'de') {
            this.showcase = false;
          }
        } else {
          if (contentLang.length === 1 && contentLang[0] === 'de') {
            this.showcase = false;
          }
        }
      }
    }
  }
  public initialApi() {
    let config;
    config = {
      apiKey: ' ',
      username: ' ',
      password: ' ',
      accessToken: ' ',
      withCredentials: false
    };
    let x, max_lim = 1,userType;
    x = new CollectionApi(this.http, null, config);
    userType = this.commonService.getUserType();
    x.v1DetailCollectionByIdGet(this.collectionID, this.collectionPageNo, this.collectionPageSize, this.itemLimit, this.countryCode, undefined, undefined, undefined, undefined,  userType ).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
    // x.v1DetailCollectionByIdGet(environment.originalPageCollectionId, undefined, undefined, undefined, this.countryCode).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
      this.setAd();
      this.apiRetryCount = 1;
      value.items = value.buckets;
      value.items = this.commonService.removeWebView(value.items);
      this.data = value;
     
      // if(this.data.meta_title && (this.data.meta_title !== null || this.data.meta_title !== '')) {
      //   if(window.localStorage.getItem("display_language") == "de"){
      //     this.data.meta_title = "Bolly.Thek"
      //   }
      //   else{
      //     this.data.meta_title = "MENU.ZEEORIGINALS";
      //   }
      // }

      this.seoservice.updatefromAPI(this.data, this.router);
      for (let y = 0; y < value.items.length; y++) {
        if (value.items[y].tags && value.items[y].tags.includes('banner')) {
          max_lim++ ;
        }
      }
      // if(this.countryCode != "IN" && value.items.length > max_lim && !value.tags.includes("GridView")){
      if (this.countryCode !== 'IN' && value.items.length > max_lim) {
        // if( value.items.length > max_lim){
            this.commonProcedureAfterLandingAPI(value);
            this.homeView = true;
            // carousel cal
            // this.initialiseDataIN(this.data);
        } else {
          this.gridView = true;
          this.initialiseData(this.data);
        }

      setTimeout(() => {
        this.commonService.updateTime();
      });
      $('#loaderPage').css('display', 'none');
    },
    err => {
      $('#loaderPage').css('display', 'none');
      this.gtm.sendErrorEvent('api', err);
      if (err.status === 401 && this.apiRetryCount < this.apiRetry) {
        this.apiRetryCount ++;
        this.processPending = true;
        this.commonService.refreshToken().then(
          () => {
            this.initialApi();
          },
          () => {
            this.processPending = true;
            this.dataAvailable = false;
          }
          );
      } else {
        this.dataAvailable = false;
      }
    }
    );
  }

  private setAd(): any {
    let userType, showNativeAds;
    userType = this.commonService.getUserType();
    // this.mastHeadAds = this.commonService.getAdsValue();
    // this.showMastAds = this.mastHeadAds && this.mastHeadAds['masthead_ads'] && this.mastHeadAds['masthead_ads'][userType] && this.mastHeadAds['masthead_ads'][userType].ads_visibility && this.mastHeadAds['masthead_ads'][userType]['screens'];
    // if (this.showMastAds) {
    //   this.mastHeadAds = this.mastHeadAds['masthead_ads'][userType]['screens'];
    //   let mast_head_ad, scope;
    //   scope = this;
    //   mast_head_ad = $.grep(this.mastHeadAds, function(e) {
    //       return e.screen_id === scope.type;
    //     });
    //   if (mast_head_ad && mast_head_ad[0] && mast_head_ad[0].ad_data && mast_head_ad[0].ad_data[0]) {
    //       mast_head_ad = mast_head_ad[0].ad_data[0];
    //       this.mastDivID = mast_head_ad.div_id;
    //       this.mastTag = mast_head_ad.ad_tag;
    //   this.mastHeadStyle = this.commonService.getAdType(mast_head_ad.ad_type);
    //   }
    //   if (this.mastDivID && this.mastTag) {
    //     this.adCreation(this.mastTag, this.mastDivID, mast_head_ad.ad_dimension, 'masthead');
    //   }
    // }
    this.nativeAds = this.commonService.getAdsValue();
    showNativeAds = this.nativeAds && this.nativeAds['native_tags_ads'] && this.nativeAds['native_tags_ads'][userType] && this.nativeAds['native_tags_ads'][userType].ads_visibility && this.nativeAds['native_tags_ads'][userType]['screens'];
    // if (showNativeAds) {
    //   nativeAds = nativeAds['native_tags_ads'][userType]['screens'];
    //   let native_ad, scope;
    //   scope = this;
    //   native_ad = $.grep(nativeAds, function(e) {
    //     return e.screen_id === 'zeeOriginals';
    //   });
    //   if (native_ad && native_ad[0] && native_ad[0].ad_data && native_ad[0].ad_data.length > 0) {
    //     let index;
    //     index = native_ad[0].ad_data.findIndex(ad => ad.position === 'footer');
    //     this.nativeTag = native_ad[0].ad_data[index !== -1 ? index : 0];
    //     if (this.nativeTag) {
    //       this.nativeTag.adStyle = this.commonService.getAdType(this.nativeTag.ad_type);
    //       // this.adCreation(this.nativeTag.ad_tag, (this.nativeTag.div_id),  this.nativeTag.ad_dimension, 'native');
    //     }
    //     console.log(this.nativeTag, index, native_ad);
    //     this.googleAdCreation();
    //   }
    // }
    if (showNativeAds) {
      this.nativeAds = this.nativeAds['native_tags_ads'][userType]['screens'];
      let native_ad, scope;
      scope = this;
      native_ad = $.grep(this.nativeAds, function(e) {
          return e.screen_id === 'zeeoriginals';
        });
      if (native_ad && native_ad[0] && native_ad[0].ad_data && native_ad[0].ad_data.length > 0) {
          this.nativeTag = native_ad[0].ad_data;
          this.nativeTag = this.subscriptionService.formatDuplicate(this.nativeTag, 'position');
          this.nativeAdPosition = this.nativeTag.map(a => a.position);
          let index;
          index = native_ad[0].ad_data.findIndex(ad => ad.position === 'footer');
          if (index !== -1 && native_ad[0].ad_data[index]) {
            this.footerAd = native_ad[0].ad_data[index];
            this.footerAd.adStyle = this.commonService.getAdType(this.footerAd.ad_type);
            this.footerAd.adNative = this.footerAd.div_id;
            this.googleAdCreation('footer', index);
          }
      }
    }
}

// public googleAdCreation () {
//   if (this.nativeTag && this.nativeTag && this.nativeTag.div_id) {
//     switch (this.nativeTag.ad_provider) {
//       case 'adfox':
//         let adFoxtagAvailable;
//         adFoxtagAvailable = this.commonService.checkAdFoxTag();
//         if (adFoxtagAvailable === 'true' && this.nativeTag.owner_id && this.nativeTag.params) {
//           let scope;
//           scope = this;
//           $(this.document).ready(function() {
//             scope.adFoxCreation(scope.nativeTag.div_id, scope.nativeTag.owner_id, scope.nativeTag.params , 'native');
//           });
//         }
//         break;
//       default:
//         this.googletagAvailable = this.commonService.checkGoogleTag();
//         if (this.googletagAvailable === 'true' && this.nativeTag.ad_tag) {
//           this.adCreation(this.nativeTag.ad_tag, this.nativeTag.div_id,  this.nativeTag.ad_dimension, 'native');
//         }
//         break;
//     }
//   }
// }

  public googleAdCreation (adType: any, id: any) {
    // this.googletagAvailable = this.commonService.checkGoogleTag();
    // if (this.googletagAvailable === 'true' && this.nativeTag && this.nativeTag[id] && this.nativeTag[id].ad_tag && this.nativeTag[id].div_id) {
    //   if (!this.mobile) {
    //     this.adCreation(this.nativeTag[id].ad_tag, (this.nativeTag[id].div_id),  this.nativeTag[id].ad_dimension, 'native');
    //   } else {
    //     this.adCreation(this.nativeTag[id].ad_tag, (this.nativeTag[id].div_id),  this.nativeTag[id].ad_dimension, 'native');
    //   }
    // }
    if (this.nativeTag && this.nativeTag[id] && this.nativeTag[id].div_id) {
      switch (this.nativeTag[id].ad_provider) {
        case 'adfox':
          let adFoxtagAvailable;
          adFoxtagAvailable = this.commonService.checkAdFoxTag();
          if (adFoxtagAvailable === 'true' && this.nativeTag[id].owner_id && this.nativeTag[id].params) {
            this.adFoxCreation(this.nativeTag[id].div_id, this.nativeTag[id].owner_id, this.nativeTag[id].params , adType);
          }
          break;
        default:
          this.googletagAvailable = this.commonService.checkGoogleTag();
          if (this.googletagAvailable === 'true' && this.nativeTag[id].ad_tag) {
            this.adCreation(this.nativeTag[id].ad_tag, (this.nativeTag[id].div_id),  this.nativeTag[id].ad_dimension, adType);
          }
          break;
      }
    }
  }

public adFoxCreation(id: any, owner_id: any, params: any, adType: any) {
  let adFoxtagAvailable;
  adFoxtagAvailable = this.commonService.checkAdFoxTag();
  if (adFoxtagAvailable === 'true') {
      this.timer.push(setTimeout(function() {
      this.window.Ya.adfoxCode.create({
        ownerId: owner_id,
        containerId: id,
        params: params,
        // onLoad: function(data) { console.log(data, 'onLoad') },
        // onRender: function(render) { console.log(render, 'onRender') },
        onError: function(error) {
          // console.log(error, 'onError');
          $('#' + id).hide();
        },
        onStub: function(stub) {
          // console.log(stub, 'onstub');
          $('#' + id).hide();
        }
      });
      }, 1000));
  } else {
    $('#' + id).hide();
  }
}

  public adCreation(tag: any, id: any, dimension: any, adType: any) {
      this.googletagAvailable = this.commonService.checkGoogleTag();
    if (this.googletagAvailable === 'true') {
      let scope;
          scope = this;
      this.timer.push(setTimeout(function() {
        if (googletag.apiReady) {
          googletag = googletag || {};
          googletag.cmd = googletag.cmd || [];
          googletag.cmd.push(function() {
            // googletag.pubads().addEventListener('slotRenderEnded', function(event) {
            //         if (event.slot === scope.adSlot && (!event.isEmpty)) {
            //           scope.mastAd = true;
            //         } else if (event.slot === scope.adSlot && (event.isEmpty)) {
            //           // ad slot is not empty
            //         }
            //     });
            // if (adType === 'masthead') {
            // scope.adSlot = googletag.defineSlot(tag, dimension, id).setCollapseEmptyDiv(true).addService(googletag.pubads());
            // } else {
            googletag.defineSlot(tag, dimension, id).setCollapseEmptyDiv(true).addService(googletag.pubads());
            // }
            googletag.enableServices();
          });
          googletag.cmd.push(function() { googletag.display(id); });
        }
      }, 1000));
    }
  }

  public commonProcedureAfterLandingAPI(value) {
    // this.setAd();
    this.apiRetryCount = 1;
    // this.homepageData = [];
    this.processPending = false;
    value.items = this.commonService.removeWebView(value.items);
    value.items = value.buckets;

    this.data = value;
    this.seoservice.updatefromAPI(this.data, this.router);
    this.initialiseDataIN(this.data);
    this.totalCollectionPages = Math.ceil((this.data.total) / (this.collectionPageSize));

    /*--------------new ad implementation--------------------*/
    this.AdImplementation(value);
    /*--------------new ad implementation--------------------*/
}

public AdImplementation(value) {
  if (value.items && value.items.length > 0 && this.nativeAdPosition && this.nativeAdPosition.length > 0) {
  this.traylength = 0;
  for (let index1 = 0; index1 < value.items.length; index1++) {
    if (value.items[index1].tags && (value.items[index1].tags[0] === 'banner')) {
      this.traylength++;
    } else {
      let adIndex, adPosition;
      adPosition = ((this.collectionPageNo - 1) * this.collectionPageSize) + index1 + 1 - this.traylength;
      adIndex = this.nativeAdPosition.indexOf((adPosition).toString());
      // if (adIndex >= 0) {
      if (adIndex >= 0) {
        if (this.footerAd && adPosition === this.originalsBucket.length) {
          this.skippedAdIndex = adIndex;
        } else {
          this.googleAdCreation('native', adIndex);
        }
      }
    }
  }
  }
}


public loadCollection(): void {
  if (this.networkService.getPopupStatus()) {
    if (this.processPending === false) {
      this.processPending = true;
      this.collectionPageNo++;
      if (this.totalCollectionPages >= this.collectionPageNo) {
        $('.auto-loader').css('display', 'block');
        let x, userType;
        let config;
          config = {
          apiKey: ' ',
          username: ' ',
          password: ' ',
          accessToken: ' ',
          withCredentials: false
        };
        x = new CollectionApi(this.http, null, config);
        userType = this.commonService.getUserType();
        x.v1DetailCollectionByIdGet(this.collectionID, this.collectionPageNo, this.collectionPageSize, this.itemLimit, this.countryCode, undefined, undefined, undefined, undefined,  userType ).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
        // x.v1DetailCollectionByIdGet(environment.originalPageCollectionId, undefined, undefined, undefined, this.countryCode).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
          this.apiRetryCount = 1;
          value.items = value.buckets;
          value.items = this.commonService.removeWebView(value.items);
          this.data = value;
          this.processPending = false;
          $('.auto-loader').css('display', 'none');
          this.homeView = true;
          // carousel cal
          this.initialiseDataIN(this.data);
          /*--------------new ad implementation--------------------*/
          if (value.items && value.items.length > 0 && this.nativeAdPosition && this.nativeAdPosition.length > 0) {
            if (this.skippedAdIndex !== undefined) {
              this.googleAdCreation('native', this.skippedAdIndex);
              this.skippedAdIndex = undefined;
            }
            for (let index1 = 0; index1 < value.items.length; index1++) {
              if (value.items[index1].tags && (value.items[index1].tags[0] === 'banner')) {
                this.traylength++;
              } else {
                let adIndex, adPosition;
                adPosition = ((this.collectionPageNo - 1) * this.collectionPageSize) + index1 + 1 - this.traylength;
                adIndex = this.nativeAdPosition.indexOf(adPosition.toString());
                if (adIndex >= 0) {
                  // this.totalAds ++;
                  if (this.footerAd && adPosition === this.originalsBucket.length) {
                  // if (this.footerAd && this.footerAdRendered && adPosition === this.moviesCategory.length) {
                    this.skippedAdIndex = adIndex;
                  } else {
                    this.googleAdCreation('native', adIndex);
                  }
                }
              }
            }
          }
          /*--------------new ad implementation--------------------*/
        },
        err => {
          $('#loaderPage').css('display', 'none');
          this.gtm.sendErrorEvent('api', err);
          if (err.status === 401 && this.apiRetryCount < this.apiRetry) {
            this.apiRetryCount ++;
            this.commonService.refreshToken().then(
              () => {
                this.processPending = false;
                this.collectionPageNo --;
                this.loadCollection();
              },
              () => {
                this.processPending = false;
              }
              );
          } else {
            this.processPending = false;
          }
        }
        );
      }
    }
  }
}
  public changeroute() {
    if (this.networkService.getPopupStatus()) {
      this.filterOptions();
      let route;
      route = '/zee5originals/all';
      this.router_link.navigate([route]);
    }
    this.sendButtonClickDetails('all originals');
  }
  public filterOptions(): void {
    let count;
    count = this.filterService.getcount();
    if (count === false) {
      this.filterService.Setcount(true);
      this.filterService.setView('home');
    } else {
      this.filterService.Setcount(true);
      this.filterService.setView('originals');
    }
  }
  public initialiseData(data: any): void {
    this.contentAvailable = true;
    this.title = {'title': data.title, 'original_title': data.original_title};
    let banner, grid;
    grid = false;
    // if(this.countryCode == 'IN'){
      this.dataTitle = 'BREADCRUMB.ZEEORIGINALS';
    // }
    // else{
    //   this.dataTitle = 'MENU.ZEEORIGINALS_INT';
    // }
    this.updateBreadCrump(this.dataTitle);
    if (data.items) {
      for (let index = 0; index < data.items.length ; index++ ) {
        // if (data.items[index].tags[0] === 'banner' && data.items[index].items && data.items[index].items.length > 0 && !banner && !this.carousel) {
        if (data.items[index].tags && data.items[index].tags[index] === 'banner' && data.items[index].items && data.items[index].items.length > 0) {
          if (!banner && !this.carousel) {
            banner = true;
            this.carouselTitle = {'title': data.items[index].title, 'original_title': data.items[index].original_title};
            this.carousel = data.items[index].items;
            this.carouselCollection = data.items[index].id;
            this.collectionTags = data.items[index].tags;
          }
          // $('.breadcrumInit').addClass('topCarousel');
        } else if (data.items[index].tags && data.items[index].tags[0] !== 'banner' && data.items[index].items && data.items[index].items.length > 0 && !grid) {
        // } else if (data.items[index].tags[index] !== 'banner' && data.items[index].items) {
          grid = true;
          this.zeeOriginals = {   'type': 'zeeOriginals', 'parentType': 'originalPage', 'seo_title': data.items[index].seo_title, 'original_title': data.items[index].original_title, 'id': data.items[index].id,
          'content': data.items[index].items };
          this.zeeOriginalsCopy = this.zeeOriginals;
        }
      }
      if (!grid) {
        this.contentAvailable = false;
      }
    }
    if (this.scrollCount > 0) {
      let details;
      details = {
         'event': 'scrollTracking',
         'ScrollCount': '1'
      };
      this.gtm.sendEventDetails(details);
    }
  }
  public initialiseDataIN(data: any): void {
    this.contentAvailable = true;
    this.title = {'title': data.title, 'original_title': data.original_title};
    let banner, grid;
    grid = false;
    // if(this.countryCode == 'IN'){
      this.dataTitle = 'BREADCRUMB.ZEEORIGINALS';
    // }
    // else{
    //   this.dataTitle = 'MENU.ZEEORIGINALS_INT';
    // }
    this.updateBreadCrump(this.dataTitle);
    if (data.items) {
      // for (let i = 0; i < value.items.length ; i++ ) {
        // let data = value.items[i];
        for (let index = 0; index < data.items.length ; index++ ) {
          // if (data.items[index].tags[0] === 'banner' && data.items[index].items && data.items[index].items.length > 0 && !banner && !this.carousel) {
          if (data.items[index].tags[index] === 'banner' && data.items[index].items && data.items[index].items.length > 0) {
            if (!banner && !this.carousel) {
              banner = true;
              this.carouselTitle = {'title': data.items[index].title, 'original_title': data.items[index].original_title};
              this.carousel = data.items[index].items;
              this.carouselCollection = data.items[index].id;
              this.collectionTags = data.items[index].tags;
            }
            // $('.breadcrumInit').addClass('topCarousel');
          } else if (data.items[index].tags[0] !== 'banner') {
          // } else if (data.items[index].tags[index] !== 'banner' && data.items[index].items) {
            grid = true;
            let idValueNative, adIndex, adStyle;
            idValueNative = '';
            // debugger
            if (this.nativeAdPosition && this.nativeAdPosition.length > 0) {
              adIndex = this.nativeAdPosition.indexOf((this.count_ad + 1).toString());
              if (adIndex >= 0 && this.nativeTag && this.nativeTag[adIndex]) {
                idValueNative = this.nativeTag[adIndex].div_id;
                adStyle = this.commonService.getAdType(this.nativeTag[adIndex].ad_type);
              }
            }
            this.count_ad++;
            this.zeeOriginals = ({'adNative': idValueNative, 'adStyle': adStyle, 'id': data.items[index].id, 'type': 'zeeOriginals', 'link': 'collections', 'parentType': 'originalPage', 'title': data.items[index].title, 'seo_title': data.items[index].seo_title, 'original_title': data.items[index].original_title, 'content': data.items[index].items });
            this.originalsBucket.push(this.zeeOriginals);
          }
        }
      // }
      if (!grid) {
        this.contentAvailable = false;
      }
    }
  }
  
	public trackByFn (index, show) {
    return show.id; // or item.id
  }
  public updateBreadCrump(data: any) {
    let breadcrump;
    breadcrump = [
    {
      'label': 'BREADCRUMB.HOME',
      'url': '/',
      'enable': true
    },
    {
      'label': this.dataTitle,
      'url': this.router2,
      'enable': false
    },
    ];
    if (this.dataTitle === '') {
      this.headerservicesService.breadCrump('');
    } else {
      this.headerservicesService.breadCrump(breadcrump);
    }
  }
  public ngOnDestroy() {
    this.linkservice.removeCanonicalLink();
    this.googletagAvailable = this.commonService.checkGoogleTag();
    if (this.googletagAvailable === 'true' && googletag.destroySlots) {
      googletag.destroySlots();
      // clearTimeout(this.timer);
    }
    let adFoxtagAvailable;
    adFoxtagAvailable = this.commonService.checkAdFoxTag();
    if (adFoxtagAvailable === 'true' && this.window.Ya.adfoxCode.destroy) {
    // if (adFoxtagAvailable === 'true' && this.window.Ya && this.window.Ya.adfoxCode && this.window.Ya.adfoxCode.destroy) {
      this.window.Ya.adfoxCode.destroy();
    }
    for (let i = 0; i < this.timer.length; i++) {
      clearTimeout(this.timer[i]);
    }
    // if  (this.carousel) {
      // $('.breadcrumInit').removeClass('topCarousel');
    // }
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }
  public sendButtonClickDetails(details) {
    let buttonclickDetails;
    buttonclickDetails = {
      'event': 'buttonClicks',
      'cta': details
    };
    this.gtm.sendEventDetails(buttonclickDetails);
  }
}
