import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared.module';
import { ZeeOriginalsLandingComponent } from './zee-originals-landing.component';
import { CarouselModule } from '../carousel/carousel.module';
import { DataUnavailableModule } from '../data-unavailable/data-unavailable.module';
import { HomeGridModule } from '../home-grid/home-grid.module';
import { BreadCrumbModule } from '../bread-crumb/bread-crumb.module';
import { ScrollListModule } from '../scroll-list/scroll-list.module';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';

const routes: Routes = [
    {
    	path: '',
        component: ZeeOriginalsLandingComponent
    },

];
@NgModule({
 exports: [RouterModule],
  imports: [RouterModule.forChild(routes),ScrollListModule,InfiniteScrollModule, CommonModule, SharedModule, DataUnavailableModule, CarouselModule, HomeGridModule, BreadCrumbModule],
declarations: [ZeeOriginalsLandingComponent]
})
export class ZeeOriginalsLandingModule {}
