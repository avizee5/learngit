import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ZeeOriginalsLandingComponent } from './zee-originals-landing.component';

describe('ZeeOriginalsLandingComponent', () => {
  let component: ZeeOriginalsLandingComponent;
  let fixture: ComponentFixture<ZeeOriginalsLandingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ZeeOriginalsLandingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ZeeOriginalsLandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
