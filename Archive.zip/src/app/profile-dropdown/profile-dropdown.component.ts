import { Component, OnInit, Input, Output, EventEmitter, AfterViewInit} from '@angular/core';
import { HeaderservicesService } from '../services/headerservices.service';
import {environment} from '../../environments/environment';
import { UserApiService } from '../services/user-api.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { RouteService } from '../services/route.service';
import { UserApi } from '../../data/user/api/api';
import * as userApi from '../../data/user/api/api';
import { Http } from '@angular/http';
import { Subject } from 'rxjs/Subject';
import { UserProfileService } from '../services/user-profile.service';
import { Router , NavigationEnd , ActivatedRoute  } from '@angular/router';
import { PlatformLocation } from '@angular/common';
import { Location } from '@angular/common';
import { NetworkService } from '../services/network.service';
import { SubscriptionService } from '../services/subscription.service';
import { SettingsService } from '../services/settings.service';

declare const FB: any;
// declare const gapi: any;
@Component({
  selector: 'app-profile-dropdown',
  templateUrl: './profile-dropdown.component.html',
  styleUrls: ['./profile-dropdown.component.less']
})
export class ProfileDropdownComponent implements OnInit, AfterViewInit {
private ngUnsubscribe = new Subject<any>();
public auth2: any;                                       // G+ sigin api call variable

private clientId = '416550389298-8tcrqujfrefaikium01cm3lt2kqvdk1o.apps.googleusercontent.com';
private GOOGLE_CLIENT_ID = environment.GOOGLE_CLIENT_ID;
private token: any;
private tokenValue: any;
private timestampTime: any;
private timestampDateTime: any;
private localstorage: any;
private window: any;
private document: any;
private logoutTime: any;
private previousUrl: any;
private fBToken: any;
private user: any;
private userapi: any;
private params: any = '';
private saveToken: any;
private data: any ;
private logintype: any;
public logout: any;
private loged = false;
public error_message_Login: any;
public currentTabProfile: any;
private clientID: any;
private marketingValue: any;
public telcoFlag = true;
@Input() private routeValue: any;
@Input() public dialogCheck: any;
@Input() public telconPlanCheck: any;
constructor(private sub: SubscriptionService, private settingsService: SettingsService, @Inject(PLATFORM_ID) private platformId: Object, private routeservice: RouteService, private headerservicesService: HeaderservicesService, private userapiService: UserApiService, private gtm: GoogleAnalyticsService, private to: Location, location: PlatformLocation, private router: Router, private userProfileService: UserProfileService, private networkService: NetworkService, private http: Http) {}

  public ngOnInit() {
  if (isPlatformBrowser(this.platformId)) {
    this.localstorage = localStorage;
    this.window = window;
    this.document = document;
  }
  this.logout = this.localstorage.getItem('token');
  this.previousUrl = this.routeservice.getLoginRoute();
  this.gtm.storeWindowError();
  this.checkviewValue();
  let scope;
  scope = this;
  this.window.onpopstate = function() {
    scope.headerservicesService.profileChange(false);
    scope.headerservicesService.modelChange(false);
  };
  this.logoutTime = this.localstorage.getItem('twitterTime');
  this.logintype = this.localstorage.getItem('login');
  this.userapi = new userApi.UserApi(this.http, null, null);
  // let telcoCheckAcc, telcoCheckSub;
 /* // check if telco user for my account
  telcoCheckAcc = this.sub.getTelcoFlag();
  this.telcoFlag = (telcoCheckAcc) ? true : false;*/
/*  telcoCheckSub = this.sub.getTelcoFlagSub();
  this.dialogCheck = telcoCheckSub ? false : true;*/
}
  public ngAfterViewInit(): void {                                                                  // G+ sigin api call start
    this.googleInit();
  }
  private checkviewValue() {

   if ((this.routeValue.match(/plans/g))  || (this.routeValue.match(/payments/g))) {
      this.currentTabProfile  = 1;
    } else if (this.routeValue === '/myprofile') {
      this.currentTabProfile  = 0;
    } else if (this.routeValue === '/myprofile/watchlist') {
      this.currentTabProfile  = 2;
    } else if (this.routeValue === '/myprofile/favorites') {
      this.currentTabProfile  = 3;
    } else if (this.routeValue === '/myprofile/reminders') {
      this.currentTabProfile  = 5;
    } else if (this.routeValue.match(/parentalcontrol/g)) {
      this.currentTabProfile  = 4;
    } else if (this.routeValue === '/myaccount/subscription') {
      this.currentTabProfile  = 6;
    } else if (this.routeValue === '/device') {
      this.currentTabProfile  = 7;
    } else {
      this.currentTabProfile = null;
    }
  }
  public screenClose() {
    this.headerservicesService.profileChange(false);
    this.headerservicesService.modelChange(false);
  }
  public logoutScreen() {
    this.gtm.logEvent({
      'event': 'userIconClick',
      'UserMenu': 'logout',
      'Previous_Screen': this.gtm.previousScreenName
    });
    this.localstorage.setItem('googletag', 'false');
    let logintype;
    logintype = this.localstorage.getItem('login');
    this.localstorage.removeItem('parentalControl');
    this.localstorage.removeItem('parental');
    if (logintype === 'twitter') {
      this.localstorage.removeItem('token');
      this.localstorage.removeItem('ID');
      this.localstorage.removeItem('login');
      this.localstorage.removeItem('twitterToken');
      this.window.location.href = environment.twitterLogout + '&ver=' + this.logoutTime;
      this.localstorage.removeItem('twittermessage');
      this.localstorage.removeItem('twitterTime');
      this.localstorage.removeItem('twitterType');
    } else {
      this.localstorage.removeItem('login');
      this.localstorage.removeItem('token');
      this.localstorage.removeItem('ID');
      this.token = '';
      this.setDisplay(this.token);
      this.window.location.reload(true);
      this.tokenValue = this.gtm.fetchToken();
      this.timestampTime = this.gtm.fetchCurrentTime();
      this.timestampDateTime = this.gtm.fetchCurrentDate();
      this.clientID = this.gtm.fetchClientId();
      this.marketingValue = this.gtm.fetchMarketing();
      this.gtm.logEvent(
        {
          'event': 'LogOut',
          'G_ID': this.tokenValue,
          'Client_ID': this.clientID,
          'retargeting_remarketing' : this.marketingValue,
          'TimeHHMMSS': this.timestampTime,
          'DateTimeStamp': this.timestampDateTime
        });
    }
    this.settingsService.clearMsisdnData();
    if(localStorage.getItem('HE_detect')) {
      let y = JSON.parse(localStorage.getItem('HE_detect'));
      y.timestamp = new Date();
      localStorage.setItem('HE_detect',JSON.stringify(y))
    }
    // to remove subscription purchase details
    this.sub.removeSubLocal();
    this.localstorage.setItem('urlbacbtn', 'false'); // Set Flag value to false for browser url back button in payment page
  }
  private setDisplay(n): void {
    this.userapiService.gettoken(n);
  }
  public parentControl() {
      if (this.logintype === 'facebook') {
        this.checkLoginState();
      } else if (this.logintype === 'google') {
        this.attachSignin(this.document.getElementById('googleParent'));
      } else if (this.logintype === 'Mobile' || this.logintype === 'Email') {
        this.headerservicesService.profileChange(false);
        this.headerservicesService.parentalChange({'flag': true, 'type': 'password' });
      } else if (this.logintype === 'twitter') {
       this.headerservicesService.profileChange(false);
        this.localstorage.setItem('parental', true);
        this.deleteCookie();
        let x, y;
         x = new Date();
         y = x.getTime();
        window.location.href = environment.twitterLogin + '&ver=' + y;
      }
  }
  private deleteCookie(): any {  // for twitter
    document.cookie = 'PHPSESSID' + '=; Path=/;Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
    this.localstorage.removeItem('twitterTime');
  }
  // for facebook
  private checkLoginState() {
    let network;
    network = this.networkService.getPopupStatus();
    if (network === true) {
      FB.getLoginStatus(response => {
        this.statusChangeCallback(response);
      });
    }
  }
  private statusChangeCallback(response: any) {
    if (response.status === 'connected') {
      this.login();
    } else {
      this.login();
    }
  }
  private login() {
    FB.login(result => {
      this.loged = true;
      this.token = result;
      if (this.token.authResponse != null) {
        this.fBToken = this.token.authResponse.accessToken;
      }
      this.me();
      this.facebookParentalApi(this.fBToken);
    }, { scope: 'public_profile,email' });
  }
  private me() {
    let scope;
    scope = this;
    FB.api('/me?fields=id,name,first_name,email,gender,picture.width(150).height(150),age_range',
      function(result) {
        if (result && !result.error) {
          scope.user = result;
        } else {
          // todo
        }
      });
  }
  // for google
  public googleInit() {
   if ( this.window && this.window.gapi) {
      this.window.gapi.load('auth2', () => {
        let that;
        that = this;
        that.auth2 = this.window.gapi.auth2.init({
          client_id:   that.GOOGLE_CLIENT_ID,
          cookiepolicy: 'single_host_origin',
          scope: 'profile'
        });
        if (this.logintype === 'google') {
          this.attachSignin(this.document.getElementById('googleParent'));
        }
      });
    }
  }
  public attachSignin(element) {
    let scope;
    scope = this;
    this.auth2.attachClickHandler(element, {},
      (googleUser) => {
        let profile;
        profile = googleUser.getBasicProfile();
        let acces;
        acces = this.window.gapi.auth2.getAuthInstance().currentUser.get().getAuthResponse(true).access_token;
        this.googleParentalApi(acces);
      }, error => {
        // console.log(Error, 'Error');
      });
  }
    // Zee API call
    private googleParentalApi(acces) {
      if (acces) {
        this.userapi.v1UserLogingoogleGet(acces).timeout(environment.timeOut).subscribe(response => {
          this.saveToken = response.token;
          this.UserDetails(this.saveToken);
        }, err => {
          if (err.name === 'TimeoutError') {
                    this.error_message_Login = 'MESSAGES.TRY_LATER';
                    this.callToastApi();
          } else if (err.status === 404) {
                  let errors;
                  errors = err.json();
             this.error_message_Login  = errors.message;
             if (this.error_message_Login) {
               this.callToastApi();
              }
            }
        });
      }
    }
    private facebookParentalApi(fBToken) {
      if (fBToken) {
        this.userapi.v1UserLoginfacebookGet(fBToken).timeout(environment.timeOut).subscribe(response => {
          this.saveToken = response.token;
          this.UserDetails(this.saveToken);
        }, err => {
          let error;
          error = err.json();
            if (err.name === 'TimeoutError') {
              this.error_message_Login = 'MESSAGES.TRY_LATER';
              this.callToastApi();
            } else if (err.status === 404) {
             this.error_message_Login  = error.message;
             if (this.error_message_Login) {
               this.callToastApi();
              }
            }
        });
      }
    }
  private UserDetails(gettoken) {   // get the details of parental login user
    if (gettoken) {
      this.params = 'bearer ' + gettoken;
      const config = {
        apiKey: this.params,
        username: ' ',
        password: ' ',
        accessToken: ' ',
        withCredentials: false
      };
      const userDetails = new UserApi(this.http, null, config);
      userDetails.v1UserGet().takeUntil(this.ngUnsubscribe).subscribe(value => {
        this.data = value;
        this.compareUserData(this.data);

      },
      err => {
        if (err.status !== 0) {
            this.localstorage.removeItem('token');
          this.localstorage.removeItem('login');
          this.window.location.reload(true);

        }
      });
    }
  }
  private compareUserData(parentalData) {   // compare first login user and parental login user
    let orginalData;
    orginalData = this.userProfileService.getuserdata();
    if (orginalData.id === parentalData.id) {
      this.headerservicesService.profileChange(false);
      this.localstorage.setItem('parentalControl', true);
      location.href = this.window.location.origin + '/parentalcontrol';
    } else {
      this.callToast();
    }

  }
    private callToast() {
    let p;
    p = this.document.getElementById('snackbarProfile');
    p.className = 'show';
    this.headerservicesService.profileChange(false);
    setTimeout(function() { p.className = p.className.replace('show', ''); }, 3000);

  }
  private callToastApi() {
    let p;
      p = this.document.getElementById('snackbarApi');
      p.className = 'show';
      let scope;
      scope = this;
      setTimeout(function() { p.className = p.className.replace('show', '');
       scope.headerservicesService.profileChange(false);
        }, 5000);
  }
  public sendUserMenuDetails(details) {
    let userIconDetails;
    userIconDetails = {
      'event': 'userIconClick',
      'UserMenu': details
    };
    this.gtm.sendEventDetails(userIconDetails);
  }
}
