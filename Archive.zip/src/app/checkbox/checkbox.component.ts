import { Component, OnInit, Input, OnChanges} from '@angular/core';
import * as $ from 'jquery';
import {environment} from '../../environments/environment';

/* Angular Universal */
import { isPlatformBrowser } from '@angular/common';
import { Inject , PLATFORM_ID } from '@angular/core';

@Component({
  selector: 'app-checkbox',
  templateUrl: './checkbox.component.html',
  styleUrls: ['./checkbox.component.less']
})
export class CheckboxComponent implements OnInit, OnChanges {
  @Input() public enabled: any;
  @Input() public ripple: any;
  @Input() public shiftLeft = false; // shift checkbox to left(-12px)
  @Input() public shiftLeftMore = false; // shift checkbox to left(-13px)

  public rippleAnimate: boolean;
  public controlRipple: any;

  public localStorage: any;
  public window: any;
  public document: any;
  public navigator: any;

  // Asset basepath letiable
  public assetbasepath = environment.assetsBasePath;

  constructor(@Inject(PLATFORM_ID) private platformId: Object) { }

  public ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.localStorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
    this.rippleAnimate = false;

    let img1;
    img1 = new Image();
    img1.src = this.assetbasepath + 'assets/common/check_box_selected.png';
    let img2;
    img2 = new Image();
    img2.src = this.assetbasepath + 'assets/common/check_box_unselected.png';
    }

  public ngOnChanges(changes: any) {
    let self;
    self = this;
    self.rippleAnimate = true;
    setTimeout(() => {
    self.rippleAnimate = false;   }, 610);
  }
}
