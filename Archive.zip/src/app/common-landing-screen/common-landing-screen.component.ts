import { Component, OnInit, ViewChild, OnDestroy, HostListener } from '@angular/core';
import { FilterService } from '../services/filter.service';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
// import to control carousel in your views
import { CarouselComponent } from '../carousel/carousel.component';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { Http} from '@angular/http';
import {CollectionApi} from '../../data/gwapi_catalog/api/CollectionApi';
import {MovieApi} from '../../data/catalog/api/MovieApi';
import * as $ from 'jquery';
import { Location } from '@angular/common';
// import { VideoService } from '../services/video.service';
// import {FavoritesApi, RemindersApi, UserApi, WatchHistoryApi, WatchlistApi } from '../../data/user/api/api'
import { UserProfileService } from '../services/user-profile.service';
import { environment } from '../../environments/environment';
import { RouteService } from '../services/route.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { HeaderservicesService } from '../services/headerservices.service';
import {  NetworkService  } from '../services/network.service';
import { SettingsService } from '../services/settings.service';
import {CommonService} from '../services/common.service';
import { Subject } from 'rxjs/Subject';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { LinkService } from '../services/link.service';
import { SubscriptionService } from '../services/subscription.service';
import { SeoService } from '../services/seo.service';
import 'rxjs/add/operator/timeout';
declare var googletag;
declare const qg;

@Component({
  selector: 'app-common-landing-screen',
  templateUrl: './common-landing-screen.component.html',
  styleUrls: ['./common-landing-screen.component.less']
})
export class CommonLandingScreenComponent implements OnInit, OnDestroy {
  @ViewChild(CarouselComponent) public carousel_element: CarouselComponent;
  public collectionTags: any;
  public carouselTitle: any;
  public color: string;
  public mode: string;
  public value: number;
  public bufferValue: number;
  public international: any;
  public indian: any;
  public trending: any;
  public new: any;
  public books: any;
  public documentaries: any;
  public popular: any;
  public biopics: any;
  public banner: any;
  public interface: string;
  public count: number;
  public count1: number;
  public count2: number;
  public count3: number;
  public count4: number;
  public tvshows: string;
  public carousel: any;
  public carouselCollection: any;
  public modalVideoPopup = false;
  public modalVideoDetails: any;
  public selectedFilters: any;
  public selected: any;
  public filterbar = false;
  public filter_titles: any;
  public id: any;
  public name: any;
  public watch: any;
  public sub: any;
  public urlString: any;
  public data: any;
  public moviesCategory: any;
  public title: any;
  public languages: any;
  public category: any;
  public overlayStatus: boolean;
  public filterFlag = false;
  public destroyFilter: Subscription;
  public page: any;
  public totalPages: any;
  public all: any;
  public params: any;
  public htmlHeight: any;
  public current: any;
  public dataAvailable: any = true;
  public callFlag: any = false;
  public contentAvailable: any = true;
  public router: any;
  public router2: any;
  public pageSize: any = 24;
  public pageName: any;
  public collectionPageNo = 1;
  public totalCollectionPages: any;
  public collectionPageSize: any = 5;
  public config: any;
  public touchScreen: any = false;
  public processPending: any = false;
  // public totalAds: any;
  public googletagAvailable: any;
  public assetBasePath = environment.assetsBasePath;
  public tagValue: any;
  public desktopTag: any;
  public mobileTag: any;
  public nativeTag: any;
  public nativeAdPosition: any;
  public token: any;
  public languages_api: any;
  public destroy: any = true;
  public adSpacing: any = 3;
  public divDesktop: any;
  public divMobile: any;
  public timer: any = [];
  public localstorage: any;
  public window: any;
  public document: any;
  public navigator: any;
  public count_ad: any = 0;
  // public ads_sum: any = 0;
  public mobile = false;
  public countryCode: any;
  public videosScreen: any = false;
  public tvshowsScreen: any = false;
  public moviesScreen: any = false;
  public collectionID: any;
  public type: any;
  public viewAll: any;
  public mastDivID: any;
  public mastHeadStyle: any;
  public mastTag: any;
  public plans: any;
  public premiumUser: any = false;
  public cardType: any;
  public itemLimit: any = 20;
  public apiRetry: any = 2;
  public apiRetryCount: any = 1;
  public showMastAds: any = false;
  public mastHeadAds: any;
  public mastAd: any = false;
  public adSlot: any;
  public showNativeAds: any = false;
  public nativeAds: any;
  private countryListget: any;
  private collectionsWeb: any;
  private collectionsConfig: any;
  private ngUnsubscribe = new Subject<any>();
  public infiniteScrollDistance: any = 0.5;
  public breadcrumb: any = '';
  public traylength: any = 0;
  public scrollCount: any = 0;

  public footerAd: any;
  private skippedAdIndex: any;
  public footerAdRendered: any = false;
  public footerAdSlot: any;

  constructor (private subService: SubscriptionService , private linkservice: LinkService, @Inject(PLATFORM_ID) private platformId: Object, private commonService: CommonService,  private settingsService: SettingsService, private networkService: NetworkService, private gtm: GoogleAnalyticsService, private routeservice: RouteService ,
    private userProfileService: UserProfileService, private location: Location, private filterService: FilterService, private route: ActivatedRoute ,  private router_link: Router , private http: Http, private headerservicesService: HeaderservicesService, private seoservice: SeoService) {
    if (isPlatformBrowser(this.platformId)) {
      this.localstorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
    this.router = router_link;
    this.router2 = this.window.location.pathname;
    this.routeservice.setRoute(this.router2);
    this.headerservicesService.viewChange(this.router2);
    this.routeservice.setLoginRoute(this.window.location.pathname);
    if (this.router.url.match(/tvshows/g)) {
      this.tvshowsScreen = true;
    } else if (this.router.url.match(/movies/g)) {
      this.moviesScreen = true;
    } else if (this.router.url.match(/videos/g)) {
      this.videosScreen = true;
    }
  }

  public ngOnInit() {
    this.gtm.storeWindowError();
    if (isPlatformBrowser(this.platformId)) {
      this.localstorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
    this.countryCode = this.settingsService.getCountry();
    this.countryListget  = this.settingsService.getCountryValueNew();
    this.collectionsWeb = (this.countryListget && this.countryListget[0] && this.countryListget[0].collections && this.countryListget[0].collections.web_app !== null) ? this.countryListget[0].collections.web_app : undefined;
    this.tagValue = this.settingsService.getCompleteConfig();
    this.collectionsConfig = (this.tagValue && this.tagValue.collections && this.tagValue.collections.web_app !== null) ? this.tagValue.collections.web_app : undefined;
    if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i) || this.window.innerWidth <= 768) {
      this.touchScreen = true;
      this.infiniteScrollDistance = 6;
    }
    if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)) {
      this.mobile = true;
    }
    // this.plans = this.subService.checkPlanApiSuccess(false);
    // if (this.plans && this.plans.length > 0) {
    //   this.premiumUser = true;
    // }
    // this.showMastAds = this.tagValue && this.tagValue.masthead_ads && this.tagValue.masthead_ads.web && (this.premiumUser && this.tagValue.masthead_ads.web.premium_user && (this.tagValue.masthead_ads.web.premium_user[this.countryCode] === undefined ? this.tagValue.masthead_ads.web.premium_user['default'] : this.tagValue.masthead_ads.web.premium_user[this.countryCode])) || !this.premiumUser;
    let network;
    network = this.networkService.getScreenStatus();
    if (network) {
      $('#loaderPage').css('display', 'block');
      let token, params;
      token = this.localstorage.getItem('token');
      if (token) {
        this.userProfileService.httpgetFavoriteData();
        this.userProfileService.httpgetWatchData();
      }
      params = 'bearer ' + token;
      this.params = params;
      this.config = {
        apiKey: ' ',
        username: ' ',
        password: ' ',
        accessToken: ' ',
        withCredentials: false
      };
      this.count = 0;
      if (this.tvshowsScreen) {
        this.breadcrumb = 'BREADCRUMB.SHOWS';
        this.updateBreadCrump('BREADCRUMB.SHOWS');
        this.viewAll = 'COMMON.ALL_SHOWS';
        this.type = 'tvshows';
        if (this.collectionsWeb !== undefined && this.collectionsWeb.tvshows) {
          this.collectionID = this.collectionsWeb.tvshows;
        } else if (this.collectionsConfig !== undefined && this.collectionsConfig.tvshows) {
          this.collectionID = this.collectionsConfig.tvshows;
        } else {
          this.collectionID = environment.tvshowPageCollectionId;
        }
        this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'tvshows'  } );
        // this.tagValue = this.settingsService.getCompleteConfig();
        // if (!this.premiumUser && this.tagValue && this.tagValue.ads && this.tagValue.ads.web && this.tagValue.ads.web.tvshows && this.tagValue.ads.web.tvshows.desktop  && this.tagValue.ads.web.tvshows.mobile && this.tagValue.ads.web.tvshows.desktop[Object.keys(this.tagValue.ads.web.tvshows.desktop).length - 1] && this.tagValue.ads.web.tvshows.mobile[Object.keys(this.tagValue.ads.web.tvshows.mobile).length - 1]) {
        //   this.desktopTag = this.tagValue.ads.web.tvshows.desktop;
        //   this.mobileTag =  this.tagValue.ads.web.tvshows.mobile;
        // }
        // this.showMastAds = this.tagValue && this.tagValue.masthead_ads && this.tagValue.masthead_ads.web && (this.premiumUser && this.tagValue.masthead_ads.web.premium_user && (this.tagValue.masthead_ads.web.premium_user[this.countryCode] === undefined ? this.tagValue.masthead_ads.web.premium_user['default'] : this.tagValue.masthead_ads.web.premium_user[this.countryCode])) || !this.premiumUser
        // if (this.showMastAds && this.mobile && this.tagValue.masthead_ads.web['mobile'].tvshows && this.tagValue.masthead_ads.web['mobile'].tvshows[0]) {
        //   this.mastTag = this.tagValue.masthead_ads.web['mobile'].tvshows[0].ad_tag;
        //   this.mastDivID = this.tagValue.masthead_ads.web['mobile'].tvshows[0].div_id;
        // }
        this.commonService.qgraphevent('TVshowssection_visited', {'country': this.countryCode, 'state': this.localstorage.getItem('state_code')});
        this.pageName = 'tv show';
        this.gtm.sendPageName(this.pageName);
        this.gtm.sendEvent();
        this.settingsService.bluekaiPagename('shows');

      } else if (this.moviesScreen) {
        this.breadcrumb = 'BREADCRUMB.MOVIES';
        this.updateBreadCrump('BREADCRUMB.MOVIES');
        this.viewAll = 'COMMON.ALL_MOVIES';
        this.adSpacing = 2;
        this.type = 'movies';
        if (this.collectionsWeb !== undefined && this.collectionsWeb.movies) {
          this.collectionID = this.collectionsWeb.movies;
        } else if (this.collectionsConfig !== undefined && this.collectionsConfig.movies) {
          this.collectionID = this.collectionsConfig.movies;
        } else {
          this.collectionID = environment.moviePageCollectionId;
        }
        this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'movies'  } );
        // this.tagValue = this.settingsService.getCompleteConfig();
        // if (!this.premiumUser && this.tagValue && this.tagValue.ads && this.tagValue.ads.web  && this.tagValue.ads.web.movies && this.tagValue.ads.web.movies.desktop && this.tagValue.ads.web.movies.mobile) {
        //   this.desktopTag = this.tagValue.ads.web.movies.desktop;
        //   this.mobileTag =  this.tagValue.ads.web.movies.mobile;
        // }
        // this.showMastAds = this.tagValue && this.tagValue.masthead_ads && this.tagValue.masthead_ads.web && (this.premiumUser && this.tagValue.masthead_ads.web.premium_user && (this.tagValue.masthead_ads.web.premium_user[this.countryCode] === undefined ? this.tagValue.masthead_ads.web.premium_user['default'] : this.tagValue.masthead_ads.web.premium_user[this.countryCode])) || !this.premiumUser
        // if (this.showMastAds && this.mobile && this.tagValue.masthead_ads.web['mobile'] && this.tagValue.masthead_ads.web['mobile'].movies && this.tagValue.masthead_ads.web['mobile'].movies[0]) {
        //   this.mastTag = this.tagValue.masthead_ads.web['mobile'].movies[0].ad_tag;
        //   this.mastDivID = this.tagValue.masthead_ads.web['mobile'].movies[0].div_id;
        // }
        this.commonService.qgraphevent('Moviessection_visited', {'country': this.countryCode, 'state': this.localstorage.getItem('state_code')});
        this.pageName = 'movies';
        this.gtm.sendPageName(this.pageName);
        this.gtm.sendEvent();
        this.settingsService.bluekaiPagename('movies');

      } else if (this.videosScreen) {
        this.breadcrumb = 'BREADCRUMB.VIDEOS';
        this.updateBreadCrump('BREADCRUMB.VIDEOS');
        this.viewAll = 'COMMON.ALL_VIDEOS';
        this.type = 'videos';
        if (this.collectionsWeb !== undefined && this.collectionsWeb.videos) {
          this.collectionID = this.collectionsWeb.videos;
        } else if (this.collectionsConfig !== undefined && this.collectionsConfig.videos) {
          this.collectionID = this.collectionsConfig.videos;
        } else {
          this.collectionID = environment.videoPageCollectionId;
        }
        this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'videos'  } );
        // this.tagValue = this.settingsService.getCompleteConfig();
        // if (!this.premiumUser && this.tagValue && this.tagValue.ads && this.tagValue.ads.web && this.tagValue.ads.web.videos && this.tagValue.ads.web.videos.desktop  && this.tagValue.ads.web.videos.mobile) {
        //   this.desktopTag = this.tagValue.ads.web.videos.desktop;
        //   this.mobileTag =  this.tagValue.ads.web.videos.mobile;
        // }
        // this.showMastAds = this.tagValue && this.tagValue.masthead_ads && this.tagValue.masthead_ads.web && (this.premiumUser && this.tagValue.masthead_ads.web.premium_user && (this.tagValue.masthead_ads.web.premium_user[this.countryCode] === undefined ? this.tagValue.masthead_ads.web.premium_user['default'] : this.tagValue.masthead_ads.web.premium_user[this.countryCode])) || !this.premiumUser
        // if (this.showMastAds && this.mobile && this.tagValue.masthead_ads.web['mobile'] && this.tagValue.masthead_ads.web['mobile'].videos && this.tagValue.masthead_ads.web['mobile'].videos[0]) {
        //   this.mastTag = this.tagValue.masthead_ads.web['mobile'].videos[0].ad_tag;
        //   this.mastDivID = this.tagValue.masthead_ads.web['mobile'].videos[0].div_id;
        // }
        this.commonService.qgraphevent('Videossection_visted', {'country': this.countryCode, 'state': this.localstorage.getItem('state_code')});
        this.pageName = 'videos';
        this.gtm.sendPageName(this.pageName);
        this.gtm.sendEvent();
        this.settingsService.bluekaiPagename('videos');

      }
      this.initialApiCall();
      // if (this.mastDivID && this.mastTag) {
      //   this.adCreation(this.mastTag, this.mastDivID, ['fluid'], 'masthead');
      // }
    }
  }

  public adCreation(tag: any, id: any, dimension: any, adType: any ) {
    this.googletagAvailable = this.commonService.checkGoogleTag();
    if (this.googletagAvailable === 'true') {
      let scope;
      scope = this;
      this.timer.push(setTimeout(function() {
        if (googletag.apiReady) {
          googletag = googletag || {};
          googletag.cmd = googletag.cmd || [];
          googletag.cmd.push(function() {
          googletag.pubads().addEventListener('slotRenderEnded', function(event) {
              if (event.slot === scope.adSlot && (!event.isEmpty)) {
                scope.mastAd = true;
              } else if (event.slot === scope.adSlot && (event.isEmpty)) {
                // ad slot is not empty
              }
          });
          if (adType === 'masthead') {
            scope.adSlot = googletag.defineSlot(tag, dimension, id).setCollapseEmptyDiv(true).addService(googletag.pubads());
          } else if (adType === 'footer') {
            scope.footerAdSlot = googletag.defineSlot(tag, dimension, id).setCollapseEmptyDiv(true).addService(googletag.pubads());
          } else {
            googletag.defineSlot(tag, dimension, id).setCollapseEmptyDiv(true).addService(googletag.pubads());
          }
            googletag.enableServices();
          });
          googletag.cmd.push(function() { googletag.display(id); });
        }
      }, 1000));
    }
  }
  public updateBreadCrump(title: any) {
    let breadcrump;
    breadcrump = [
    {
      'label': 'BREADCRUMB.HOME',
      'url': '/',
      'enable': true
    },
    {
      'label': this.breadcrumb,
      'url': this.router2,
      'enable': false
    },
    ];
    if (this.breadcrumb === '') {
      this.headerservicesService.breadCrump('');
    } else {
      this.headerservicesService.breadCrump(breadcrump);
    }
  }
  public googleAdCreation (adType: any, id: any) {
    // this.googletagAvailable = this.commonService.checkGoogleTag();
    // if (this.googletagAvailable === 'true' && this.nativeTag && this.nativeTag[id] && this.nativeTag[id].ad_tag && this.nativeTag[id].div_id) {
    //   if (!this.mobile) {
    //     this.adCreation(this.nativeTag[id].ad_tag, (this.nativeTag[id].div_id),  this.nativeTag[id].ad_dimension, 'native');
    //   } else {
    //     this.adCreation(this.nativeTag[id].ad_tag, (this.nativeTag[id].div_id),  this.nativeTag[id].ad_dimension, 'native');
    //   }
    // }
    if (this.nativeTag && this.nativeTag[id] && this.nativeTag[id].div_id) {
      switch (this.nativeTag[id].ad_provider) {
        case 'adfox':
          let adFoxtagAvailable;
          adFoxtagAvailable = this.commonService.checkAdFoxTag();
          if (adFoxtagAvailable === 'true' && this.nativeTag[id].owner_id && this.nativeTag[id].params) {
            this.adFoxCreation(this.nativeTag[id].div_id, this.nativeTag[id].owner_id, this.nativeTag[id].params , adType);
          }
          break;
        default:
          this.googletagAvailable = this.commonService.checkGoogleTag();
          if (this.googletagAvailable === 'true' && this.nativeTag[id].ad_tag) {
            this.adCreation(this.nativeTag[id].ad_tag, (this.nativeTag[id].div_id),  this.nativeTag[id].ad_dimension, adType);
          }
          break;
      }
    }
  }

  public adFoxCreation(id: any, owner_id: any, params: any, adType: any) {
    let adFoxtagAvailable;
    adFoxtagAvailable = this.commonService.checkAdFoxTag();
    if (adFoxtagAvailable === 'true') {
      this.timer.push(setTimeout(function() {
        this.window.Ya.adfoxCode.create({
          ownerId: owner_id,
          containerId: id,
          params: params,
          // onLoad: function(data) { console.log(data, 'onLoad') },
          // onRender: function(render) { console.log(render, 'onRender') },
          onError: function(error) {
            // console.log(error, 'onError');
            $('#' + id).hide();
          },
          onStub: function(stub) {
            // console.log(stub, 'onstub');
            $('#' + id).hide();
          }
        });
      }, 0));
    } else {
      $('#' + id).hide();
    }
  }

private setAd(): any {
  let userType;
    userType = this.commonService.getUserType();
    this.mastHeadAds = this.commonService.getAdsValue();
    this.nativeAds = this.commonService.getAdsValue();
    this.showNativeAds = this.nativeAds && this.nativeAds['native_tags_ads'] && this.nativeAds['native_tags_ads'][userType] && this.nativeAds['native_tags_ads'][userType].ads_visibility && this.nativeAds['native_tags_ads'][userType]['screens'];
    this.showMastAds = this.mastHeadAds && this.mastHeadAds['masthead_ads'] && this.mastHeadAds['masthead_ads'][userType] && this.mastHeadAds['masthead_ads'][userType].ads_visibility && this.mastHeadAds['masthead_ads'][userType]['screens'];
    if (this.showMastAds) {
      this.mastHeadAds = this.mastHeadAds['masthead_ads'][userType]['screens'];
      let mast_head_ad, scope;
      scope = this;
      mast_head_ad = $.grep(this.mastHeadAds, function(e) {
          return e.screen_id === scope.type;
        });
      if (mast_head_ad && mast_head_ad[0] && mast_head_ad[0].ad_data && mast_head_ad[0].ad_data[0]) {
          mast_head_ad = mast_head_ad[0].ad_data[0];
          this.mastDivID = mast_head_ad.div_id;
          this.mastTag = mast_head_ad.ad_tag;
          this.mastHeadStyle = this.commonService.getAdType(mast_head_ad.ad_type);
      }
      if (this.mastDivID && this.mastTag) {
        this.adCreation(this.mastTag, this.mastDivID, mast_head_ad.ad_dimension, 'masthead');
      }
    }
    if (this.showNativeAds) {
      this.nativeAds = this.nativeAds['native_tags_ads'][userType]['screens'];
      let native_ad, scope;
      scope = this;
      native_ad = $.grep(this.nativeAds, function(e) {
          return e.screen_id === scope.type;
        });
      if (native_ad && native_ad[0] && native_ad[0].ad_data && native_ad[0].ad_data.length > 0) {
          this.nativeTag = native_ad[0].ad_data;
          this.nativeTag = this.subService.formatDuplicate(this.nativeTag, 'position');
          this.nativeAdPosition = this.nativeTag.map(a => a.position);
          let index;
          index = native_ad[0].ad_data.findIndex(ad => ad.position === 'footer');
          if (index !== -1 && native_ad[0].ad_data[index]) {
            this.footerAd = native_ad[0].ad_data[index];
            this.footerAd.adStyle = this.commonService.getAdType(this.footerAd.ad_type);
            this.footerAd.adNative = this.footerAd.div_id;
            this.googleAdCreation('footer', index);
          }
      }
    }
}
/*--------------new ad implementation--------------------*/
  public initialApiCall(): void {
    let x, userType;
    this.processPending = true;
    userType = this.commonService.getUserType();
    x = new CollectionApi(this.http, null, this.config);
    x.v1DetailCollectionByIdGet(this.collectionID, this.collectionPageNo, this.collectionPageSize, this.itemLimit, this.countryCode, null, null, null, null, userType ).timeout(environment.timeOut).takeUntil(this.ngUnsubscribe).subscribe(value => {
      this.apiRetryCount = 1;
    let countrylist = this.settingsService.getCountryValueNew()
    if(countrylist && countrylist.length > 0 && countrylist[0].recommendations && countrylist[0].recommendations == true) {
        x.v1RecommendationByIdGet(this.collectionID, null, null, null, this.countryCode, null, null, null, userType, null).takeUntil(this.ngUnsubscribe).subscribe( Rvalue => {

        value = this.talamoosFilter(value, Rvalue);
        this.commonProcedureAfterLandingAPI(value);
        }, err => {
        this.commonProcedureAfterLandingAPI(value);
        });
      } else {
        this.commonProcedureAfterLandingAPI(value);
      }
    },
    err => {
      $('#loaderPage').css('display', 'none');
      this.gtm.sendErrorEvent('api', err);
      if (err.status === 401 && this.apiRetryCount < this.apiRetry) {
        this.apiRetryCount ++;
        this.processPending = true;
        this.commonService.refreshToken().then(
          () => {
            this.initialApiCall();
          },
          () => {
            this.processPending = false;
            this.dataAvailable = false;
          },
          );
      } else {
        if (this.tagValue && this.tagValue.talamoos_allowed_countries && this.tagValue.talamoos_allowed_countries.indexOf(this.countryCode) >= 0) {
          x.v1RecommendationByIdGet(this.collectionID, null, null, null, this.countryCode, null, null, null, userType, null).takeUntil(this.ngUnsubscribe).subscribe(Rvalue => {
          this.commonProcedureAfterLandingAPI(Rvalue);
          }, error => {
            this.processPending = false;
            this.dataAvailable = false;
          });
        } else {
          this.processPending = false;
          this.dataAvailable = false;
        }
      }
    });
  }



  public talamoosFilter(value, Rvalue) {
    let bannercount = 0;
      if (value.buckets && value.buckets.length > 0) {
        if(value.buckets.length > Rvalue.rails_position) {
          for ( let checkbannerindex = 0 ; checkbannerindex < Rvalue.rails_position; checkbannerindex++) {
            if (value.buckets[checkbannerindex].tags && (value.buckets[checkbannerindex].tags[0] === 'banner')) {
              bannercount++;
            }
          }
        }
      }
      if (value.buckets.length > Rvalue.rails_position) {
        for ( let i = 0 ; i < Rvalue.buckets.length; i++ ) {
          value.buckets.splice(Rvalue.rails_position + i + bannercount -1, 0 ,Rvalue.buckets[i])
        }
      } else {
        value.buckets = value.buckets.concat(Rvalue.buckets);
      }
    return value;
  }


  public commonProcedureAfterLandingAPI(value) {

      value.items = value.buckets;

      value.items = this.commonService.removeWebView(value.items);
      this.setAd();
      this.data = value;
      this.seoservice.updatefromAPI(this.data, this.router);
      this.processPending = false;
      this.totalCollectionPages = Math.ceil((this.data.total) / (this.collectionPageSize));
      this.moviesCategory = [];
      this.title = this.data.title;
      this.initialiseData(this.data);
      $('#loaderPage').css('display', 'none');

      /*--------------new ad implementation--------------------*/
      this.AdImplementation(value);
      /*--------------new ad implementation--------------------*/
      let scope;
      scope = this;
      setTimeout(() => {
        scope.commonService.updateTime();
      });
  }

  public AdImplementation(value) {
    if (value.items && value.items.length > 0 && this.nativeAdPosition && this.nativeAdPosition.length > 0) {
    this.traylength = 0;
    for (let index1 = 0; index1 < value.items.length; index1++) {
      if (value.items[index1].tags && (value.items[index1].tags[0] === 'banner')) {
        this.traylength++;
      } else {
        let adIndex, adPosition;
        adPosition = ((this.collectionPageNo - 1) * this.collectionPageSize) + index1 + 1 - this.traylength;
        adIndex = this.nativeAdPosition.indexOf((adPosition).toString());
        // if (adIndex >= 0) {
        if (adIndex >= 0) {
          // this.totalAds ++;
          if (this.footerAd && adPosition === this.moviesCategory.length) {
          // if (this.footerAd && this.footerAdRendered && adPosition === this.moviesCategory.length) {
            this.skippedAdIndex = adIndex;
          } else {
            this.googleAdCreation('native', adIndex);
          }
        }
      }
    }
    // this.ads_sum = this.ads_sum + this.totalAds;
    }
  }
  public loadCollection(): void {
    if (this.networkService.getPopupStatus()) {
      if (this.processPending === false) {
        this.processPending = true;
        this.collectionPageNo++;
        if (this.totalCollectionPages >= this.collectionPageNo) {
          $('.auto-loader').css('display', 'block');
          let x, userType;
          userType = this.commonService.getUserType();
          x = new CollectionApi(this.http, null, this.config);
          x.v1DetailCollectionByIdGet(this.collectionID, this.collectionPageNo, this.collectionPageSize, this.itemLimit, this.countryCode, null, null, null, null, userType).timeout(environment.timeOut).takeUntil(this.ngUnsubscribe).subscribe(value => {
            this.apiRetryCount = 1;
            value.items = value.buckets;
            value.items = this.commonService.removeWebView(value.items);

            this.data = value;
            this.processPending = false;
            $('.auto-loader').css('display', 'none');
            let scope;
            scope = this;
            setTimeout(() => {
              scope.commonService.updateTime();
            });
            this.initialiseData(value);
            /*--------------new ad implementation--------------------*/
            if (value.items && value.items.length > 0 && this.nativeAdPosition && this.nativeAdPosition.length > 0) {
              if (this.skippedAdIndex !== undefined) {
                this.googleAdCreation('native', this.skippedAdIndex);
                this.skippedAdIndex = undefined;
              }
              for (let index1 = 0; index1 < value.items.length; index1++) {
                if (value.items[index1].tags && (value.items[index1].tags[0] === 'banner')) {
                  this.traylength++;
                } else {
                  let adIndex, adPosition;
                  adPosition = ((this.collectionPageNo - 1) * this.collectionPageSize) + index1 + 1 - this.traylength;
                  adIndex = this.nativeAdPosition.indexOf(adPosition.toString());
                  if (adIndex >= 0) {
                    // this.totalAds ++;
                    if (this.footerAd && adPosition === this.moviesCategory.length) {
                    // if (this.footerAd && this.footerAdRendered && adPosition === this.moviesCategory.length) {
                      this.skippedAdIndex = adIndex;
                    } else {
                      this.googleAdCreation('native', adIndex);
                    }
                  }
                }
              }
              // this.ads_sum = this.ads_sum + this.totalAds;
            }
            /*--------------new ad implementation--------------------*/
          },
          err => {
            $('#loaderPage').css('display', 'none');
            this.gtm.sendErrorEvent('api', err);
            if (err.status === 401 && this.apiRetryCount < this.apiRetry) {
              this.apiRetryCount ++;
              this.commonService.refreshToken().then(
                () => {
                  this.processPending = false;
                  this.collectionPageNo --;
                  this.loadCollection();
                },
                () => {
                  this.processPending = false;
                },
                );
            } else {
              this.processPending = false;
            }
          }
          );
        }
      }
    }
  }
  public initialiseData(data: any): void {
    this.contentAvailable = true;
    // let count = 0;
    if (data && data.items && data.items.length > 0) {
      for (let index = 0 ; index < data.items.length; index ++ ) {
        if (data.items[index] && data.items[index].items && data.items[index].items.length > 0 && data.items[index].tags && data.items[index].tags[0] === 'banner') {
          if (!this.carousel) {
            this.carouselTitle = {'title': data.items[index].title, 'original_title': data.items[index].original_title};
            this.carousel = data.items[index].items;
            this.carouselCollection = data.items[index].id;
            this.collectionTags = data.items[index].tags;
          }
          // $('.breadcrumInit').addClass('topCarousel');
        } else if (data.items[index] && data.items[index].items && data.items[index].items.length > 0) {
          let dataFiltered, contenttype;
          if (data.items[index].tags && data.items[index].tags[0] === 'eventbanner') {
              contenttype = 'eventbanner';
          } else {
              contenttype = this.commonService.assignType(data.items[index]);
          }
          dataFiltered = this.commonService.restrictLength(data.items[index].items);
          // dataFiltered = this.commonService.restrictLength(this.commonService.filterListData(data.items[index].items));
          if (dataFiltered && dataFiltered.length > 0) {
            let idValueNative, adIndex, adStyle;
            idValueNative = '';
            if (this.nativeAdPosition && this.nativeAdPosition.length > 0) {
              adIndex = this.nativeAdPosition.indexOf((this.count_ad + 1).toString());
              if (adIndex >= 0 && this.nativeTag && this.nativeTag[adIndex]) {
                idValueNative = this.nativeTag[adIndex].div_id;
            adStyle = this.commonService.getAdType(this.nativeTag[adIndex].ad_type);
              }
            }
            this.count_ad++;
            this.moviesCategory.push ( {'adNative': idValueNative, 'adStyle': adStyle,
              'title': data.items[index].title , modelname: data.items[index].modelName, 'seo_title': data.items[index].seo_title, 'original_title': data.items[index].original_title , 'id': data.items[index].id, 'parentType': this.type, 'type': contenttype, 'link': 'collections', 'original_length': data.items[index].items.length
              , 'content': dataFiltered
            });
            // this.moviesCategory.push ( {'adDesktop': idValueDesktop, 'adMobile': idValueMobile,
            //   'title': data.items[index].title , 'original_title': data.items[index].original_title , 'id': data.items[index].id, 'parentType': this.type, 'type': contenttype, 'link': 'collections', 'original_length': data.items[index].items.length
            //   , 'content': dataFiltered
            // });
          }
        }
      }
      // this.count_ad = this.moviesCategory.length + 1;
      if ( this.moviesCategory && this.moviesCategory.length === 0) {
        this.contentAvailable = false;
      }
    } else {
      this.dataAvailable = false;
    }
    if (this.scrollCount > 0) {
      this.gtm.sendEventDetails({'event': 'scrollTracking', 'ScrollCount': '1'});
    }
    this.scrollCount++;
  }
  public changeroute() {
    if (this.networkService.getPopupStatus()) {
      this.filterOptions();
      let route;
      route = '/' + this.type + '/all';
      this.router_link.navigate([route]);
    }
    this.sendButtonClickDetails(this.type);
  }
  public filterOptions(): void {
    let count;
    count = this.filterService.getcount();
    if (count === false) {
      this.filterService.Setcount(true);
      this.filterService.setView('home');
    } else {
      this.filterService.Setcount(true);
      this.filterService.setView(this.type);
    }
  }
  public ngOnDestroy() {
    this.linkservice.removeCanonicalLink();
    this.googletagAvailable = this.commonService.checkGoogleTag();
    if (this.googletagAvailable === 'true' && googletag.destroySlots) {
      googletag.destroySlots();
    }
    let adFoxtagAvailable;
    adFoxtagAvailable = this.commonService.checkAdFoxTag();
    if (adFoxtagAvailable === 'true' && this.window.Ya.adfoxCode.destroy) {
    // if (adFoxtagAvailable === 'true' && this.window.Ya && this.window.Ya.adfoxCode && this.window.Ya.adfoxCode.destroy) {
      this.window.Ya.adfoxCode.destroy();
    }
    for (let i = 0; i < this.timer.length; i++) {
      clearTimeout(this.timer[i]);
    }
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
    this.commonService.count = 0;
    // if  (this.carousel) {
    //   $('.breadcrumInit').removeClass('topCarousel');
    // }
  }
  public trackByFn (index, show) {
    return show.id; // or item.id
  }
  public sendButtonClickDetails(details) {
    let buttonclickDetails;
    let cta;
    cta = (details === 'movies') ? 'all movies' : ((details === 'videos') ? 'all videos' : 'all shows');
    buttonclickDetails = {
      'event': 'buttonClicks',
      'cta': cta
    };
    this.gtm.sendEventDetails(buttonclickDetails);
  }
}
