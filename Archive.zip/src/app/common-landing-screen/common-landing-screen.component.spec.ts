import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MoviesLandingScreenComponent } from './movies-landing-screen.component';

describe('MoviesLandingScreenComponent', () => {
  let component: MoviesLandingScreenComponent;
  let fixture: ComponentFixture<MoviesLandingScreenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MoviesLandingScreenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MoviesLandingScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
