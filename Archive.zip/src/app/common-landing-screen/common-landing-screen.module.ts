import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared.module';
import { CommonLandingScreenComponent } from './common-landing-screen.component';
import { DataUnavailableModule } from '../data-unavailable/data-unavailable.module';
import { CarouselModule } from '../carousel/carousel.module';
import { ScrollListModule } from '../scroll-list/scroll-list.module';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { BreadCrumbModule } from '../bread-crumb/bread-crumb.module';

const routes: Routes = [
    {
        path: '',
        component: CommonLandingScreenComponent,
    },
];
@NgModule({
  exports: [RouterModule],
  imports: [RouterModule.forChild(routes), InfiniteScrollModule, CommonModule, SharedModule, DataUnavailableModule, CarouselModule, ScrollListModule, BreadCrumbModule],
  declarations: [CommonLandingScreenComponent]
})
export class CommonLandingScreenModule { }
