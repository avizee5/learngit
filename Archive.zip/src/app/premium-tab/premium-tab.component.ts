import { Component, OnInit, Input, EventEmitter, OnDestroy, HostListener } from '@angular/core';
import {environment} from '../../environments/environment';
import * as $ from 'jquery';
import { Router } from '@angular/router';
import { SubscriptionService } from '../services/subscription.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { HeaderservicesService } from '../services/headerservices.service';


@Component({
  selector: 'app-premium-tab',
  templateUrl: './premium-tab.component.html',
  styleUrls: ['./premium-tab.component.less']
})
export class PremiumTabComponent implements OnInit, OnDestroy {
@Input() public contentId: any = 'NA';
public assetbasepath: any;

    
    constructor(private sub: SubscriptionService, private gtm: GoogleAnalyticsService, private router: Router,private headerservicesService: HeaderservicesService,) {
    this.assetbasepath = environment.assetsBasePath;
  }

  public ngOnInit() {
    // nothing
  }

  public subscribeNow() {
    /*let displayEvent;
    displayEvent = {
      'event': 'inAppClicks',
      'pageName': this.gtm.getPageName(),
      'buttonName': 'Subscribe Now',
      'contentID': this.contentId
    };
    this.gtm.logEvent(displayEvent);*/
    // if (this.assetbasepath.indexOf('0-9-') === -1) {
    //   localStorage.setItem('postSubscriptionRoute', this.contentId);
    // }
    // this.router.navigate(['/myaccount/subscription']);
    this.headerservicesService.MygpSubscriptionroute();
    this.sub.storeRedirectSubscribe(true);
  }
   public ngOnDestroy(): any {
     // nothing
  }


}
