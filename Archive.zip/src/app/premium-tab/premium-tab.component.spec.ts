import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PremiumTabComponent } from './premium-tab.component';

describe('BeforetvpopupComponent', () => {
  let component: PremiumTabComponent;
  let fixture: ComponentFixture<PremiumTabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PremiumTabComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PremiumTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
