import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PremiumTabComponent } from './premium-tab.component';
import { SharedModule } from '../shared.module';

@NgModule({
  imports: [CommonModule, SharedModule],
  declarations: [PremiumTabComponent],
  exports: [PremiumTabComponent]
})
export class PremiumTabModule {
}
