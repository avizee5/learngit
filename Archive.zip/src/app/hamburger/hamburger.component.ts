import { Component, OnInit , Input, Output, EventEmitter, HostListener, AfterViewInit} from '@angular/core';
import { HeaderservicesService } from '../services/headerservices.service';    // services for letiable update
import * as $ from 'jquery';
import { Subscription } from 'rxjs/Subscription';
import { UserApiService } from '../services/user-api.service';
import { Location } from '@angular/common';
import {environment} from '../../environments/environment';
import {NetworkService} from '../services/network.service';
import { FilterService } from '../services/filter.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { RouteService } from '../services/route.service';
import { UserApi } from '../../data/user/api/api';
import * as userApi from '../../data/user/api/api';
import { Http } from '@angular/http';
import { Subject } from 'rxjs/Subject';
import { UserProfileService } from '../services/user-profile.service';
import { Router , NavigationEnd , ActivatedRoute  } from '@angular/router';
import { PlatformLocation } from '@angular/common';
import { SettingsService } from '../services/settings.service';
import { SubscriptionService } from '../services/subscription.service';
import {CommonService} from '../services/common.service';
declare const FB: any;
// declare const gapi: any;
@Component({
  selector: 'app-hamburger',
  templateUrl: './hamburger.component.html',
  styleUrls: ['./hamburger.component.less']
})
export class HamburgerComponent implements OnInit, AfterViewInit {
private ngUnsubscribe = new Subject<any>();
public auth2: any;                                       // G+ sigin api call letiable

private clientId = '416550389298-8tcrqujfrefaikium01cm3lt2kqvdk1o.apps.googleusercontent.com';
private GOOGLE_CLIENT_ID = environment.GOOGLE_CLIENT_ID;
private firefox: boolean;
private signInFlagShow = false;
private signInFlag: boolean;
private token: any;
private landscape: any = true;
private tokenValue: any;
private timestampTime: any;
private timestampDateTime: any;
public closeIconHamburger: any;
private localstorage: any;
private window: any;
private document: any;
private navigator: any;
private logoutTime: any;
private countryListData: any;
private configData: any;
private countrycodeIndex: any;
private countryList: any;
private previousUrl: any;
private FBTOKEN: any;
private user: any;
private userapi: any;
private params: any = '';
private saveToken: any;
private data: any ;
private logintype: any;
private loged = false;
public premiumHamburger = 'COMMON.PREMIUM';
public dialogSub = true;
public error_message_Login: any;
private clientID: any;
private marketingValue: any;
public appVersion: any;
public countyCode: any;
public displayLang: any;
public cookieOption = false;
public assetbasepath: any;
public  internationalFlag = false;
public telcoFlag = false;
public CompleteconfigValue: any;
public selectCountry: boolean = false;
public selectCountryPopup: boolean = false;
public newsNavItem: any = 'NEWS_PAGE.NEWS';
public originalsNavItem: any = 'MENU.ORIGINALS';
public helpRoute: any;
public premiumTab = 'premium';
@Input() public weyyakUrl: any;
@Input() public weyyak: any;
@Input() public usersigin: any;
@Input() private mobileDrop: any;
@Output() public update = new EventEmitter<boolean>();
 constructor(private routeservice: RouteService, private sub: SubscriptionService, private userProfileService: UserProfileService, private http: Http, @Inject(PLATFORM_ID) private platformId: Object, private settingsService: SettingsService, private gtm: GoogleAnalyticsService, private filterService: FilterService, private router: Router, private networkService: NetworkService, private location: Location , private headerservicesService: HeaderservicesService , private userapiService: UserApiService, private commonService: CommonService) {
   this.headerservicesService.menuOptionValue.subscribe(value => {     // login view changes to reflect login/register icon
        if ( value === false) {
            this.premiumHamburger = 'MENU.EXCLUSIVE';
            this.premiumTab = 'exclusive';
        }
      });
   this.headerservicesService.hamburgerValue.subscribe(value => {     // login view changes to reflect login/register icon
        this.mobileDrop = value;
      });
   this.headerservicesService.dialogValue.subscribe(value => {     // depending on subscription show r hide tab
      this.dialogSub = false;
    });
    this.headerservicesService.cookieOptionValue.subscribe(value => {
      this.cookieOption = value;
    });
    this.headerservicesService.internationalRegisterValue.subscribe(value => {          // signin
        this.internationalFlag = value;
      });

    // check telco user for my account
    this.sub.telcoUsersFlag.subscribe(value => {
      this.telcoFlag = value;
    });

     // check telco user for subscription
    this.sub.telcoUsersFlagSub.subscribe(value => {
      this.dialogSub = value ? false : true;
    });

    // check all access pack for subscription
     this.sub.storeAllAccessPack.subscribe(value => {
      this.dialogSub = value ? false : true;
    });
}
  public ngOnInit() {
    this.CompleteconfigValue = this.settingsService.getCompleteConfig();
    this.gtm.storeWindowError();
    this.closeIconHamburger = environment.assetsBasePath + 'assets/common/close_icon.png';
    this.firefox = false;
  if (isPlatformBrowser(this.platformId)) {
   this.localstorage = localStorage;
    this.window = window;
    this.document = document;
    this.navigator = navigator;
  }
  this.assetbasepath = environment.assetsBasePath;
  this.appVersion = this.window.appVersion;
  this.displayLang = this.localstorage.getItem('display_language');
    let germanLanguage = this.localstorage.getItem('token') ? this.localstorage.getItem('UserDisplayLanguage') : this.localstorage.getItem('display_language') 
    this.countyCode = this.localstorage.getItem('country_code');
    if (this.countyCode === 'DE' && germanLanguage === 'de') {
      this.newsNavItem = 'MENU.NEWS_DE';
    } else {
      this.newsNavItem = 'NEWS_PAGE.NEWS';
    }
    this.hextokenFunction();
   this.logoutTime = this.localstorage.getItem('twitterTime');
   this.logintype = this.localstorage.getItem('login');
   this.userapi = new userApi.UserApi(this.http, null, null);
   this.getbrowser();
   this.device();
     let scope;
     scope = this;
    $(this.document).mouseup(function(e) {
        this.container = $('#hide');
        if (!this.container.is(e.target) && this.container.has(e.target).length === 0) {
          if (scope.mobileDrop === true) {
               scope.headerservicesService.hamburgerDrop(false);
               scope.mouseLeave();
               $('#body').removeClass('scrolldisbale');
             }
           }
    });
     $(this.document).on('touchstart', function (e) {
          this.container = $('#hide');
            if (!this.container.is(e.target) && this.container.has(e.target).length === 0) {
              if (scope.mobileDrop === true) {
                   scope.headerservicesService. hamburgerDrop(false);
                   scope.mouseLeave();
                   $('#body').removeClass('scrolldisbale');
                 }
          }
        });
     if (window.innerWidth < 800) {
    setTimeout(() => {
    this.countryListData = this.settingsService.newCountryValue.subscribe(value => {
    this.countryListData = value;
    if (this.countryListData.length !== 0) {
      this.countryList = this.countryListData;
    }
  });
  }, 0);
  }
  this.settingsService.getCompleteConfigValues.subscribe(value => {
    if(value){
      if(value.country_selection && value.country_selection_popup && environment.internationalBuild){
        this.selectCountry = true;
      }else{ this.selectCountry = false;}
    }
  })
}
  public hextokenFunction(): any {
    let ccode, language, userType, hextoken;
    ccode = this.localstorage.getItem('country_code');
    language = this.localstorage.getItem('token') ? this.localstorage.getItem('UserDisplayLanguage') : this.localstorage.getItem('display_language');
    userType = this.localstorage.getItem('token') ? 'loggedin' : 'guest';
    hextoken = this.localstorage.getItem('hextoken');
    this.helpRoute = environment.shareUrl + 'help?translation=' + language + '&country=' + ccode + '&hextoken=' + hextoken + '&platform=desktop_web' + '&user_type=' + userType + '&app_version=' + this.appVersion;
  }

  public goToHelp(): any {
    let ccode, language, userType, hextoken, userToken;
    ccode = this.localstorage.getItem('country_code');
    language = this.localstorage.getItem('token') ? this.localstorage.getItem('UserDisplayLanguage') : this.localstorage.getItem('display_language');
    userType = this.localstorage.getItem('token') ? 'loggedin' : 'guest';
    hextoken = this.localstorage.getItem('hextoken');
    // url = 'http://localhost:5000/help/?translation=' + language + '&country=' + ccode + '&hextoken=' + hextoken + '&platform=desktop_web' + '&user_type=' + userType + '&app_version=' + this.appVersion;
    if ((userType === 'loggedin') && ((hextoken == null) || (hextoken === 'null') || (hextoken === ''))) {
      userToken = this.localstorage.getItem('token');
      const params = 'bearer ' + userToken;
      this.window.scrollTo(0, 0);
      const config = {
        apiKey: params,
        username: ' ',
        password: ' ',
        accessToken: ' ',
        withCredentials: true
      };
       const userDetails = new UserApi(this.http, null, config);
       let dataHextoken;
       dataHextoken = {'identifier': 'web', 'partner': 'contactus'};
       userDetails.v1PostHextoken('contactus', dataHextoken).takeUntil(this.ngUnsubscribe).subscribe(hextoken_data => {
          hextoken = hextoken_data.json().token;
          window.open(environment.shareUrl + '/help?translation=' + language + '&country=' + ccode + '&hextoken=' + hextoken + '&platform=desktop_web' + '&user_type=' + userType + '&app_version=' + this.appVersion, '_blank');
        },
        err => {
         window.open(environment.shareUrl + '/help?translation=' + language + '&country=' + ccode + '&hextoken=' + hextoken + '&platform=desktop_web' + '&user_type=' + userType + '&app_version=' + this.appVersion, '_blank');
        });

    } else {
         window.open(environment.shareUrl + '/help?translation=' + language + '&country=' + ccode + '&hextoken=' + hextoken + '&platform=desktop_web' + '&user_type=' + userType + '&app_version=' + this.appVersion, '_blank');
      }
  }

  public ngAfterViewInit(): void {                                                              // G+ sigin api call start
    this.googleInit();
  }
  @HostListener('window:resize', ['$event'])      // to check poterate mode
  public onResize(event) {
      this.device();
  }
private device() {
  if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i) || this.window.innerWidth <= 480) {
    this.landscape = true;
  }
   if (this.window.innerHeight < this.window.innerWidth) {          // checking for landscape mode
     this.landscape = false;
   }
}
  public viewclose() {                       // for mobile view header dropdown close
   this.headerservicesService.hamburgerDrop(false);
   this.headerservicesService.modelChange(false);
   this.mouseLeave();
   $('#body').removeClass('scrolldisbale');
  }

  public SelectCountry(){
    this.settingsService.SelectCountryPopupValue.next(true);
  }

  private getbrowser(): void {
    if (this.navigator.userAgent.indexOf('Firefox') !== -1 ) {
      this.firefox = true;
    }
  }
  public mouseEnter() {                                       // if the mouse leaves the div -- browser scroll disable
  if (this.firefox) {
     let x;
     x = this.window.scrollX;
     let y;
     y = this.window.scrollY;
    this.window.onscroll = function() { window.scrollTo(x, y);
     };
  } else {
    this.document.getElementById('body').classList.add('modal-open');
  }
  }
  public mouseLeave() {                            // if the mouse leaves the div -- browser scroll enable
  if (this.firefox) {
       this.window.onscroll = function() {
         // nothing
       };
  } else {
   this.document.getElementById('body').classList.remove('modal-open');
  }
  }
  private logout() {
    this.localstorage.setItem('googletag', 'false');
    this.localstorage.removeItem('parentalControl');
    this.localstorage.removeItem('parental');
      this.usersigin = true;
      this.update.emit(this.usersigin);
      let logintype;
      logintype = this.localstorage.getItem('login');
    if (logintype === 'twitter') {
      this.localstorage.removeItem('token');
      this.localstorage.removeItem('ID');
      this.window.location.href = environment.twitterLogout + '&ver=' + this.logoutTime;
      this.localstorage.removeItem('twittermessage');
      this.localstorage.removeItem('twitterTime');
      this.localstorage.removeItem('login');
      this.localstorage.removeItem('twitterToken');
      this.localstorage.removeItem('twitterType');
    } else {
      this.localstorage.removeItem('token');
      this.localstorage.removeItem('ID');
      this.token = '';
      this.setDisplay(this.token);
      this.localstorage.removeItem('login');
      this.window.location.reload(true);
    }
    this.tokenValue = this.gtm.fetchToken();
    this.timestampTime = this.gtm.fetchCurrentTime();
    this.timestampDateTime = this.gtm.fetchCurrentDate();
    this.clientID = this.gtm.fetchClientId();
    this.marketingValue = this.gtm.fetchMarketing();
    this.gtm.logEvent(
        {
          'event': 'LogOut',
          'G_ID': this.tokenValue,
          'Client_ID': this.clientID,
          'retargeting_remarketing' : this.marketingValue,
          'TimeHHMMSS': this.timestampTime,
          'DateTimeStamp': this.timestampDateTime
        });
    this.settingsService.clearMsisdnData();
    if(localStorage.getItem('HE_detect')) {
      let y = JSON.parse(localStorage.getItem('HE_detect'));
      y.timestamp = new Date();
      localStorage.setItem('HE_detect',JSON.stringify(y))

    }
    // to remove subscription purchase details
    this.sub.removeSubLocal();
    this.localstorage.setItem('urlbacbtn', 'false'); // Set Flag value to false for browser url back button in payment page
  }
  private setDisplay(n): void {
      this.userapiService.gettoken(n);
  }
public toggleSigin() {
  let network;
  network = this.networkService.getPopupStatus();
  if (network === true) {
     this.gtm.comScoreFunction();
     this.headerservicesService.modelChange(true);                // track of model popup
     this.document.getElementById('body').classList.add('modal-open');
     // NationalFlag
     if (this.localstorage.getItem('country_code') === 'IN') {

      this.signInFlag = !this.signInFlagShow;                         // toggle function for sigin
     this.headerservicesService.signinChange(this.signInFlag);

        if (this.countryListData && this.countryListData.length !== 0 ) {
          if (this.countryListData[this.countrycodeIndex] && this.countryListData[this.countrycodeIndex].mobile_registration !== undefined) {
            if (this.countryListData[this.countrycodeIndex].mobile_registration === 'true' || this.countryListData[this.countrycodeIndex].mobile_registration === true ) {
            this.router.navigate(['signin/mobile']);
              } else if (this.countryListData[this.countrycodeIndex].mobile_registration === 'false') {
           this.router.navigate(['signin/email']);
              } else {
           this.router.navigate(['signin/mobile']);
              }
            } else {
         this.router.navigate(['signin/mobile']);
            }
          } else if (this.configData) {
            if (this.configData.mobile_registration) {
           this.router.navigate(['signin/mobile']);
            } else if (this.configData.mobile_registration === undefined) {
            this.router.navigate(['signin/mobile']);
            } else {
             this.router.navigate(['signin/email']);
            }
     } else {
         this.router.navigate(['signin/mobile']);
     }
    } else {
       // InterNationalFlag
       this.signInFlag = !this.internationalFlag;
       this.headerservicesService.internationalRegisterChange(this.signInFlag);
       this.routeservice.Signal('/signin');
      this.router.navigate(['signin']);
    }
  }
}
public registerCall() {
  let network;
  network = this.networkService.getPopupStatus();
  if (network === true) {
     this.gtm.comScoreFunction();
     this.headerservicesService.modelChange(true);                // track of model popup
     this.document.getElementById('body').classList.add('modal-open');
     // NationalFlag
     if (this.localstorage.getItem('country_code') === 'IN') {

      this.signInFlag = !this.signInFlagShow;                         // toggle function for sigin
    this.headerservicesService.signinChange(this.signInFlag);

        if (this.countryListData && this.countryListData.length !== 0 ) {
          if (this.countryListData[this.countrycodeIndex] && this.countryListData[this.countrycodeIndex].mobile_registration !== undefined) {
            if (this.countryListData[this.countrycodeIndex].mobile_registration === 'true' || this.countryListData[this.countrycodeIndex].mobile_registration === true ) {
         this.router.navigate(['register/mobile']);
              } else if (this.countryListData[this.countrycodeIndex].mobile_registration === 'false') {
           this.router.navigate(['register/email']);
              } else {
           this.router.navigate(['register/mobile']);
              }
            } else {
        this.router.navigate(['register/mobile']);
            }
          } else if (this.configData) {
            if (this.configData.mobile_registration) {
         this.router.navigate(['register/mobile']);
            } else if (this.configData.mobile_registration === undefined) {
          this.router.navigate(['register/mobile']);
            } else {
           this.router.navigate(['register/email']);
            }
        } else {
         this.router.navigate(['register/mobile']);
        }
    } else {
      // InternationalFlag

      this.signInFlag = !this.internationalFlag;
      this.headerservicesService.internationalRegisterChange(this.signInFlag);
      this.router.navigate(['register']);
    }
  }
}
public commonCalltologinpage(value): any {
  let network;
  network = this.networkService.getPopupStatus();
  if (network === true) {

    if (value === 'register') {
          this.registerCall();
        } else {
          this.toggleSigin();
        }
  }
}
  private userAccount() {
    let logintype;
    logintype = this.localstorage.getItem('token');
    if (logintype === null) {
      this.window.location.reload(true);
    }
  }
public setView(name): any {
  this.filterService.deleteAll();
  this.filterService.setView(name);
}
private parentControl() {
    if (this.logintype === 'facebook') {
      this.checkLoginState();
    } else if (this.logintype === 'google') {
      this.attachSignin(this.document.getElementById('googleParent'));
    } else if (this.logintype === 'Mobile' || this.logintype === 'Email') {
      this.viewclose();
      this.headerservicesService.parentalChange({'flag': true, 'type': 'password' });
    } else if (this.logintype === 'twitter') {
      this.viewclose();
      this.localstorage.setItem('parental', true);
      this.deleteCookie();
      let x, y;
       x = new Date();
       y = x.getTime();
      window.location.href = environment.twitterLogin + '&ver=' + y;
    }
}
  private deleteCookie(): any {  // for twitter
    document.cookie = 'PHPSESSID' + '=; Path=/;Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
    this.localstorage.removeItem('twitterTime');
  }
  // for facebook
  private checkLoginState() {
    let network;
    network = this.networkService.getPopupStatus();
    if (network === true) {
      FB.getLoginStatus(response => {
        this.statusChangeCallback(response);
      });
    }
  }
  private statusChangeCallback(response: any) {
    if (response.status === 'connected') {
      this.login();
    } else {
      this.login();
    }
  }
  private login() {
    FB.login(result => {
      this.loged = true;
      this.token = result;
      if (this.token.authResponse != null) {
        this.FBTOKEN = this.token.authResponse.accessToken;
      }
      this.me();
      this.facebookParentalApi(this.FBTOKEN);
    }, { scope: 'public_profile,email' });
  }
  private me() {
    let scope;
    scope = this;
    FB.api('/me?fields=id,name,first_name,email,gender,picture.width(150).height(150),age_range',
      function(result) {
        if (result && !result.error) {
          scope.user = result;
        }
      });
  }
  // for google
  public googleInit() {
    if ( this.window && this.window.gapi) {
      this.window.gapi.load('auth2', () => {
        let that;
        that = this;
        that.auth2 = this.window.gapi.auth2.init({
          client_id:   that.GOOGLE_CLIENT_ID,
          cookiepolicy: 'single_host_origin',
          scope: 'profile'
        });
        if (this.logintype === 'google') {
          this.attachSignin(this.document.getElementById('googleParent'));
        }
      });
    }
  }
  public attachSignin(element) {
    let scope;
    scope = this;
    this.auth2.attachClickHandler(element, {},
      (googleUser) => {
        let profile;
        profile = googleUser.getBasicProfile();
        let acces;
        acces = this.window.gapi.auth2.getAuthInstance().currentUser.get().getAuthResponse(true).access_token;
        this.googleParentalApi(acces);
      }, error => {
        // console.log(Error, 'Error');
      });
  }
    // Zee API call
    private googleParentalApi(acces) {
      if (acces) {
        this.userapi.v1UserLogingoogleGet(acces).timeout(environment.timeOut).subscribe(response => {
          this.saveToken = response.token;
          this.UserDetails(this.saveToken);
        }, err => {
            if (err.name === 'TimeoutError') {
                    this.error_message_Login = 'MESSAGES.TRY_LATER';
                    this.callToastApi();
            } else if (err.status === 404) {
                  let errors;
                  errors = err.json();
             this.error_message_Login  = errors.message;
             if (this.error_message_Login) {
               this.callToastApi();
              }
            }
          });
      }
    }
    private facebookParentalApi(FBTOKEN) {
      if (FBTOKEN) {
        this.userapi.v1UserLoginfacebookGet(FBTOKEN).timeout(environment.timeOut).subscribe(response => {
          this.saveToken = response.token;
          this.UserDetails(this.saveToken);
        }, err => {
          if (err.name === 'TimeoutError') {
                   this.error_message_Login = 'MESSAGES.TRY_LATER';
                  this.callToastApi();
          }  else if (err.status === 404) {
                  let errors;
                  errors = err.json();
             this.error_message_Login  = errors.message;
             if (this.error_message_Login) {
               this.callToastApi();
              }
            }
       });
      }
    }
  private UserDetails(gettoken) {   // get the details of parental login user
    if (gettoken) {
      this.params = 'bearer ' + gettoken;
      const config = {
        apiKey: this.params,
        username: ' ',
        password: ' ',
        accessToken: ' ',
        withCredentials: false
      };
      const userDetails = new UserApi(this.http, null, config);
      userDetails.v1UserGet().takeUntil(this.ngUnsubscribe).subscribe(value => {
        this.data = value;
        this.compareUserData(this.data);
      },
      err => {
        if (err.status !== 0) {
          this.localstorage.removeItem('token');
          this.localstorage.removeItem('login');
          this.window.location.reload(true);
        }
      });
    }
  }
  private compareUserData(parentalData) {   // compare first login user and parental login user
    let  orginalData;
    orginalData = this.userProfileService.getuserdata();
    if (orginalData.id === parentalData.id) {
      this.viewclose();
      this.localstorage.setItem('parentalControl', true);
      location.href = this.window.location.origin + '/parentalcontrol';
    } else {
       this.callToast();
    }
  }
  private callToast() {
    let p;
    p = this.document.getElementById('snackbarParental');
    p.className = 'show';
    this.viewclose();
    setTimeout(function() { p.className = p.className.replace('show', ''); }, 3000);
  }
private callToastApi() {
    let p;
    p = this.document.getElementById('snackbarSocialApi');
    p.className = 'show';
    let scope ;
    scope = this;
    setTimeout(function() { p.className = p.className.replace('show', '');
      scope.viewclose();
    }, 5000);
}
  public sendHamburgerMenu(hambugerName) {
    let hamburgerMenu;
    hamburgerMenu = {
      'event': 'hamburgerMenu',
      'HamburgerMenu': hambugerName
    };
    this.gtm.sendEventDetails(hamburgerMenu);
  }
  public mygpSubscriptionroute(): any {
    this.headerservicesService.MygpSubscriptionroute();
  }
}
