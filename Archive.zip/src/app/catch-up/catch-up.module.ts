import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared.module';
import { CatchUpComponent } from './catch-up.component';
import { DataUnavailableModule } from '../data-unavailable/data-unavailable.module';
import { ScrollListModule } from '../scroll-list/scroll-list.module';

const routes: Routes = [
	{
		path: '',
		component: CatchUpComponent
	},
	{
		path: ':channelId',
		component: CatchUpComponent
	},
];
@NgModule({
 exports: [RouterModule],
  imports: [RouterModule.forChild(routes), CommonModule, SharedModule, ScrollListModule, DataUnavailableModule],
  declarations: [CatchUpComponent]
})
export class CatchUpModule {
}
