import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { VideoService } from '../services/video.service';
import { ChannelApi } from '../../data/catalog/api/ChannelApi';
import { Http} from '@angular/http';
import {TvShowApi} from '../../data/gwapi_catalog/api/TvShowApi';
import { RouteService } from '../services/route.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { HeaderservicesService } from '../services/headerservices.service';
import { UserProfileService } from '../services/user-profile.service';
import * as $ from 'jquery';
import {  NetworkService  } from '../services/network.service';
import { environment } from '../../environments/environment';
import { SeoService } from '../services/seo.service';
import { LinkService } from '../services/link.service';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import {CommonService} from '../services/common.service';
import { SettingsService } from '../services/settings.service';

@Component({
	selector: 'app-catch-up',
	templateUrl: './catch-up.component.html',
	styleUrls: ['./catch-up.component.less']
})
export class CatchUpComponent implements OnInit, OnDestroy {
	public seasonApi: any;
	public catchUp: any;
	public selectedFilters: any;
	public filter_titles: any;
	public filterbar: any;
	public totalResults: number;
	public modalVideoPopup = false;
	public modalVideoDetails: any;
	public id: any;
	public name: any;
	public watch: any;
	public sub: any;
	public urlString: any;
	public channelId: any;
	public dataAvailable: any = true;
	public data: any;
	public showtitle: any;
	public router: any;
	public router2: any;
	public pageName: any;
	public show_business_type: any;
	public showtitle_en: any;
	public token: any;
	public localstorage: any;
	public window: any;
	public document: any;
	public navigator: any;
	public show_asset_subtype: any;
	public show_id: any;
	public sort_order: any;
	public assetBasePath = environment.assetsBasePath;
	public countryCode: any;
	constructor (@Inject(PLATFORM_ID) private platformId: Object, private settingsService: SettingsService, private commonService: CommonService,  private userProfileService: UserProfileService, private linkservice: LinkService, private seoService: SeoService, private networkService: NetworkService, private gtm: GoogleAnalyticsService, private routeservice: RouteService, private videoService: VideoService, private location: Location, private route: ActivatedRoute ,  private router_link: Router ,  private http: Http, private headerservicesService: HeaderservicesService) {
		if (isPlatformBrowser(this.platformId)) {
			this.localstorage = localStorage;
			this.window = window;
			this.document = document;
			this.navigator = navigator;
		}
		this.router = router_link;
		this.router2 = this.window.location.pathname;
		this.routeservice.setRoute(this.router2);
		this.routeservice.setLoginRoute(this.window.location.pathname);
		this.headerservicesService.viewChange(this.router2);

	}
	public ngOnInit(): void {
		if (isPlatformBrowser(this.platformId)) {
			this.localstorage = localStorage;
			this.window = window;
			this.document = document;
			this.navigator = navigator;
		}
		this.gtm.storeWindowError();
		this.countryCode = this.settingsService.getCountry();
		let network;
		network = this.networkService.getScreenStatus();
		if (network) {
			this.pageName = 'catch up';
			this.gtm.sendPageName(this.pageName);
			this.gtm.sendEvent();
			this.sub = this.route.params.subscribe(params => {
				this.channelId = params['channelId'];
				// this.id = params['id'];
				// this.name = params['name']
				// this.watch = params['watch']
			});
			this.token = this.localstorage.getItem('token');
			if (this.token) {
				this.userProfileService.httpgetFavoriteData();
				this.userProfileService.httpgetWatchData();
			}
			let config;
			config = {
				apiKey: ' ',
				username: ' ',
				password: ' ',
				accessToken: ' ',
				withCredentials: false
			};
			let x, tvShowGet;
			x = new ChannelApi(this.http, null, config);
			tvShowGet = new TvShowApi(this.http, null, config);
			this.catchUp = [];
			this.showtitle = [];
			this.showtitle_en = [];
			this.show_business_type = [];
			this.show_asset_subtype = [];
			this.show_id = [];
			this.sort_order = {};
			if (this.channelId === null || this.channelId === undefined) {
				$('#loaderPage').css('display', 'none');
				this.dataAvailable = false;
			} else {
				$('#loaderPage').css('display', 'block');
				x.v1ChannelByIdGet(this.channelId, undefined, this.countryCode ).subscribe(value => {
					let breadcrump;
					breadcrump = [
					{
						'label': 'BREADCRUMB.HOME',
						'url': '/',
						'enable': true
					},
					{
						'label': 'BREADCRUMB.CATCHUP',
						'url': this.router2,
						'enable': false
					},
					{
						'label': value.title,
						'url': this.router2,
						'enable': false
					},
					];
					this.headerservicesService.breadCrump(breadcrump);
					this.name = value.title;
					let genres, tempTitle;
					genres = [];
					for (let index = 0; index < value.genres.length; index++) {
						genres.push(value.genres[index].id);
					}
					genres = genres.join(', ');
					let language;
					language = [];
					for (let index = 0; index < value.languages.length; index++) {
						language.push(value.languages[index]);
					}
					language = language.join(', ');

					if (value.extended && value.extended.seo_title) {
            			tempTitle = (value.extended.seo_title !== null || value.extended.seo_title !== undefined || value.extended.seo_title !== '') ? value.extended.seo_title : value.original_title;
          			} else {
            			tempTitle = (value.seo_title && (value.seo_title !== null || value.seo_title !== undefined || value.seo_title !== '')) ? value.seo_title : value.original_title;
          			}
					// this.seoService.catchupPage(this.commonService.convertToLowercase(tempTitle), language, genres );
					this.seoService.catchupPage(tempTitle, language, genres );

					this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation() + 'catchUp' + '/' + value.id} );
					if (value.related.length === 0) {
						this.dataAvailable = false;
						$('#loaderPage').css('display', 'none');
					} else {
						this.dataAvailable = true;
					}
					for (let index = 0; index < value.related.length; index++) {
						this.showtitle.push(value.related[index].title);
						this.showtitle_en.push(value.related[index].original_title);
						this.show_id.push(value.related[index].id);
						this.show_business_type.push(value.related[index].business_type);
						this.show_asset_subtype.push(value.related[index].asset_subtype);
						if (value.related[index] && value.related[index].id) {
							let userType;
							userType = this.commonService.getUserType();
							tvShowGet.v1TvshowByIdGet(value.related[index].id, undefined, this.countryCode, undefined, undefined, userType).subscribe(result => {
								this.sort_order[result.id] = 'DESC';
								if (result.extended) {
									this.sort_order[result.id] = ((result.extended.broadcast_state !== (null || undefined)) && result.extended.broadcast_state === 'ARCHIVE') ? 'ASC' : 'DESC';
								}
								if (result.seasons && result.seasons[0] && result.seasons[0].episodes) {
									for (let index_sub = 0; index_sub < result.seasons[0].episodes.length; index_sub++) {
										result.seasons[0].episodes[index_sub].show_title = this.showtitle[index];
										result.seasons[0].episodes[index_sub].business_type = this.show_business_type[index];
									}
									this.data = {'title': this.showtitle[index], 'original_title': this.showtitle_en[index], 'category': 'catchup', 'id': this.show_id[index], 'business_type': this.show_business_type[index], 'asset_subtype': this.show_asset_subtype[index], 'type': 'catchUp',
									'content': this.commonService.restrictLength(result.seasons[0].episodes) , 'original_length': result.seasons[0].episodes.length};
									this.catchUp.push(this.data);
									$('#loaderPage').css('display', 'none');
								}
							},
							err => {
								$('#loaderPage').css('display', 'none');
								this.gtm.sendErrorEvent('api', err);
							}
							);
						}
					}
				},
				err => {
					this.dataAvailable = false;
					$('#loaderPage').css('display', 'none');
					this.gtm.sendErrorEvent('api', err);
					this.headerservicesService.breadCrump('');
				}
				);
			}
			this.window.scrollTo(0, 0);
		}
	}
	public ngOnDestroy(): void {
		this.linkservice.removeCanonicalLink();
	}
}
