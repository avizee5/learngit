import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import * as userapi from '../../data/user/api/api';
import { Http } from '@angular/http';
import * as $ from 'jquery';
import { Router } from '@angular/router';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { RouteService } from '../services/route.service';
import { HeaderservicesService } from '../services/headerservices.service';
import {  NetworkService  } from '../services/network.service';
import { UseractionapiService } from '../services/useractionapi.service';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { LinkService } from '../services/link.service';
import { SettingsService } from '../services/settings.service';
import { environment } from '../../environments/environment';
declare const appVersion;

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.less']
})
export class ContactComponent implements OnInit, OnDestroy {
  private flag = false;
  private dropzone: any;
  private fileslist: any;
  public introduction: string;
  public zeeSupport: string;
  private userMobileNumber: string;
  public userEmailId: string;
  private files: any = [];
  private try: any;
  private getUserInfo: any;
  private params: any;
  private router: any;
  private router2: any;
  private pageName: any;
  private errortext: any;
  public mobilenumbertext: any = 'LOGIN.MOBILE_NUM';
  private username = '';
  private sendContactUs: any; // pass contact us event for GA
  private errortextflag = false;
  private errormobileflag = false;
  private email_return = false;
  private email_return_keypress = false;
  private mobile_return = false;
  private mobile_return_keypress = false;
  public enter_mobile: any = 'LOGIN.ENTER_MOBILE_NO';
  public enter_mobile_incorrect: any = 'LOGIN.INCORRECT_MOBILE_NO';
  private error_return = false;
  private error_return_keypress = false;
  private tokenValue: any;
  private timestampTime: any;
  private timestampDateTime: any;
  public toast_message = '';
  private localstorage: any;
  private window: any;
  private document: any;
  private navigator: any;
  private validation_keypress = false;
  private mobile_length = 0;
  private email_length = 0;
  private countries: any;
  public selected_country: any;
  public dropDownCheck = false;
  public logintype: any;
  public code: any;
  private mailTo: any;
  private token: any;
  public alternateString: any;
  private currentIndex: any = 0;
  private previousIndex: any = 0;
  private configFile: any;
  private maxLength: any = 13;
  private userData: any;
  private contactBreadCrump: any;
  public contacthrefURL: any;

  private disabled = false;
  private clientID: any;
  private marketingValue: any;
  constructor(private settingsService: SettingsService, private linkservice: LinkService, @Inject(PLATFORM_ID) private platformId: Object, private userActionApi: UseractionapiService, private networkService: NetworkService, private routeservice: RouteService, private gtm: GoogleAnalyticsService, private routerVal: Router, private http: Http, private headerservicesService: HeaderservicesService) {
    const scope = this;
    if (isPlatformBrowser(this.platformId)) {
      this.localstorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
    this.router = routerVal;
    this.router2 = this.window.location.pathname;
    this.routeservice.setRoute(this.router2);
    this.headerservicesService.viewChange(this.router2);
    this.routeservice.setLoginRoute(this.window.location.pathname);
  }
  public ngOnInit() {
    $('#loaderPage').css('display', 'block');
    this.alternateString = 'CONTACT_US.ALT_MOB_NO';
    this.token = this.localstorage.getItem('token');
    this.configFile = this.settingsService.getCompleteConfig();

    this.contactBreadCrump = [
        {
          'label': 'BREADCRUMB.HOME',
          'url': '/',
          'enable': true
        },
        {
          'label': 'BREADCRUMB.CONTACTUS',
          'url': '/contactus',
          'enable': false
        }
      ];


      this.headerservicesService.breadCrump(this.contactBreadCrump);
      // alert(appVersion)
      if (isPlatformBrowser(this.platformId)) {
        this.localstorage = localStorage;
        this.window = window;
        this.document = document;
        this.navigator = navigator;
      }
      this.logintype = this.localstorage.getItem('login');
      this.countries = this.settingsService.getcountryApiList();
      let re, selected_country_api, country;
      if (this.countries.length === 0) {
        this.settingsService.getCountryList().timeout(environment.timeOut).subscribe(value => {
          this.settingsService.setCountryListValue(value);
          this.countries = value;
          selected_country_api = this.settingsService.getCountry();
          for (country in this.countries) {
            if (this.countries[country].code === selected_country_api) {
              this.selected_country = this.countries[country];
              this.currentIndex = country;
              break;
            }
          }
          this.maxLength = 13;
          this.zeeSupport = this.selected_country.mail;
          this.contacthrefURL = 'mailto:' + this.selected_country.mail + '?Subject=Feedback';
          // re = /^([a-zA-Z0-9]+)(([^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
         // re = /^([a-zA-Z0-9]+)(([^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
           // re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/; // to validate c.abcd@gags.co
        re = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?/; // to validate c.@asd.adf and caps 
          if (this.zeeSupport && this.zeeSupport !== null && this.zeeSupport.match(re)) {
            this.zeeSupport = this.selected_country.mail;
          } else {
            this.zeeSupport = this.configFile.default_values.support_email;
          }
          this.code = '+' + this.selected_country['phone-code'] + '-';
          $('#mobileNumber').attr('maxlength', '13');
          this.codeStyles();
          $('#loaderPage').css('display', 'none');
        },
        err => {
          $('#loaderPage').css('display', 'none');
          this.maxLength = 20;
          country = this.settingsService.getCountryValue();
          this.selected_country = {'name': country.country, 'code': country.country_code, 'phone-code': undefined};
          this.countries = [{'name': country.country, 'code': country.country_code, 'phone-code': undefined}];
          this.zeeSupport = this.selected_country.mail;
          $('#mobileNumber').attr('maxlength', '20');
          // re = /^([a-zA-Z0-9]+)(([^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
          // re = /^([a-zA-Z0-9]+)(([^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
           // re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/; // to validate c.abcd@gags.co       
        re = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?/; // to validate c.@asd.adf and caps 
          if (this.zeeSupport && this.zeeSupport !== null && this.zeeSupport.match(re)) {
            this.zeeSupport = this.selected_country.mail;
          } else {
            this.zeeSupport = this.configFile.default_values.support_email;
          }
        });
      } else {
        selected_country_api = this.settingsService.getCountry();
        for (country in this.countries) {
          if (this.countries[country].code === selected_country_api) {
            this.selected_country = this.countries[country];
            this.currentIndex = country;
            break;
          }
        }
        this.maxLength = 13;
        $('#mobileNumber').attr('maxlength', '13');
        this.zeeSupport = this.selected_country.mail;
        this.contacthrefURL = 'mailto:' + this.selected_country.mail + '?Subject=Feedback';
        let re1;
        re1 = /^([a-zA-Z0-9]+)(([^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

        if (this.zeeSupport && this.zeeSupport !== null && this.zeeSupport.match(re1)) {
          this.zeeSupport = this.selected_country.mail;
        } else {
          this.zeeSupport = this.configFile.default_values.support_email;
        }
        this.code = '+' + this.selected_country['phone-code'] + '-';
        this.codeStyles();
      $('#loaderPage').css('display', 'none');
      }
      this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'contactus'  } );
      this.gtm.storeWindowError();
      let network;
      network = this.networkService.getScreenStatus();
      this.pageName = 'contact us';
      this.gtm.sendPageName(this.pageName);
      this.gtm.sendEvent();
      $(this.document).ready(function() {
        $('.inputMobileNumber').on('paste', function (e) {
          setTimeout(function () {
            $('.inputMobileNumber').val($('.inputMobileNumber').val().replace(/[^0-9]/g, ''));
          }, 1);
        });
      });
      this.window.scrollTo(0, 0);
      let self;
      self = this;
      self.introduction =
      'CONTACT_US.INFO';

      this.userMobileNumber = null;
      this.userEmailId = null;
      const token = this.localstorage.getItem('token');
      $('#mobileNumber').focus();
      if ( token ) {
        this.params = 'bearer ' + token;
        const config = {
          apiKey: this.params,
          username: ' ',
          password: ' ',
          accessToken: ' ',
          withCredentials: false
        };
        this.getUserInfo = new userapi.UserApi(this.http, null, config);
        this.getUserInfo.v1UserGet().subscribe(value => {
          this.userData = value;
          this.username = value.first_name;
          if (value.email) {
            this.userEmailId = value.email;
            $('.inputEmailId').prop('readonly', true);
            $('.inputEmailId').prop('disabled', true);
            this.email_return_keypress = true;
            this.email_return = true;
          } else {
            this.userEmailId = '';
          }
          if (value.mobile) {
            this.userMobileNumber = value.mobile;
            this.mobilenumbertext = 'PROFILE.REG_MOBILE_NO';
            this.mobile_return_keypress = true;
            this.mobile_return = true;
          } else {
            this.userMobileNumber = '';
            this.mobilenumbertext = 'LOGIN.MOBILE_NUM';
          }
        }, err => {
          // to do
        });
      }

      let measurer;
      measurer = $('<span>', {
        style: 'display:inline-block;word-break:break-word;visibility:hidden;white-space:pre-wrap;'})
      .appendTo('body');
      function initMeasurerFor(textarea) {
        if (!textarea[0].originalOverflowY) {
          textarea[0].originalOverflowY = textarea.css('overflow-y');
        }
        let maxWidth;
        maxWidth = textarea.css('max-width');
        measurer.text(textarea.text())
        .css('max-width', maxWidth === 'none' ? '100%' : maxWidth)
        .css('font', textarea.css('font'))
        .css('overflow-y', textarea.css('overflow-y'))
        .css('max-height', textarea.css('max-height'))
        .css('min-height', textarea.css('min-height'))
        .css('min-width', textarea.css('min-width'))
        .css('padding', textarea.css('padding'))
        .css('border', textarea.css('border'))
        .css('box-sizing', textarea.css('box-sizing'));
      }
      function updateTextAreaSize(textarea) {
        textarea.height(measurer.height());
        let w;
        w = measurer.width();
        if (textarea[0].originalOverflowY === 'auto') {
          let mw;
          mw = textarea.css('max-width');
          if (mw !== 'none') {
            if (w === parseInt(mw , 10)) {
              textarea.css('overflow-y', 'auto');
            } else {
              textarea.css('overflow-y', 'hidden');
            }
          }
        }
        textarea.width(w + 2);
      }
      $('textarea.autofit').on({
        input: function() {
          let text;
          text = $(this).val();
          if ($(this).attr('preventEnter') === undefined) {
            text = text.replace(/[\n]/g, '<br>&#8203;');
          }
          measurer.html(text);
          updateTextAreaSize($(this));
        },
        focus: function() {
          initMeasurerFor($(this));
        },
        keypress: function(e) {
          if (e.which === 13 && $(this).attr('preventEnter') !== undefined) {
            e.preventDefault();
          }
        }
      });
      let scope;
      scope = this;
      $(this.document).mouseup(function(e) {

            // check that your clicked
            // element has no id=info
            // and is not child of info
            if (e.target.id !== 'info' && !$('#info').find(e.target).length) {
              if (scope.dropDownCheck === true) {
                scope.dropDownCheck = false;
              }
            }
          });
    }


    private showfile(files ) {
      for (let  x = 0; x < files.length; x++) {
        this.files.push(files[x]);
        this.flag = true;
      }
    }
    private codeStyles() {
      if (this.code.length < 6) {
        $('#countryCode').css('width', '50px');
      } else if (this.code.length < 8 && this.code.length > 5) {
        $('#countryCode').css('width', '70px');
      } else if (this.code.length >= 8) {
        $('#countryCode').css('width', '90px');
      }
    }
    public Apicall() {
      this.disabled = true;
      this.errortext = $('.autofit').val();
      let object;
      if (this.logintype === 'Mobile' && $('#mobileNumber') && $('#mobileNumber').val() && $('#mobileNumber').val().length > 0 ) {
        object = {
          'user': {
            'mobile': (this.userData ? this.userData.mobile : ''),
            'alternamenumber': this.selected_country['phone-code'] ? this.selected_country['phone-code'] + $('#mobileNumber').val() : $('#mobileNumber').val(),
            'email': $('.inputEmailId').val(),
            'name': this.username,
            'message': this.errortext,
            'version': appVersion
          }
        };
      } else if (this.logintype === 'Mobile' && !($('#mobileNumber') && $('#mobileNumber').val() && $('#mobileNumber').val().length > 0) ) {
        object = {
          'user': {
            'mobile': (this.userData ? this.userData.mobile : ''),
            'email': $('.inputEmailId').val(),
            'name': this.username,
            'message': this.errortext,
            'version': appVersion
          }
        };
      } else {
        object = {
          'user': {
            'mobile': ($('#mobileNumber') && $('#mobileNumber').val() && $('#mobileNumber').val() > 0) ? (this.selected_country['phone-code'] ? this.selected_country['phone-code'] + $('#mobileNumber').val() : $('#mobileNumber').val()) : '',
            'email': $('.inputEmailId').val(),
            'name': this.username,
            'message': this.errortext,
            'version': appVersion
          }
        };
      }
      this.userActionApi.postConatctUsData( JSON.stringify(object)).subscribe(value => {
        $('#snackbar-profile').addClass('show');
        this.toast_message = 'TOAST_MESSAGES.RESPONSE_RECEIVED';
        setTimeout(function() {$('#snackbar-profile').removeClass('show'); }, 2000);
      // send contact us event to GA
      this.tokenValue = this.gtm.fetchToken();
      this.timestampTime = this.gtm.fetchCurrentTime();
      this.timestampDateTime = this.gtm.fetchCurrentDate();
      this.clientID = this.gtm.fetchClientId();
      this.marketingValue = this.gtm.fetchMarketing();
      this.sendContactUs = {
        'event': 'LeadSubmit',
        'G_ID': this.tokenValue,
        'Client_ID': this.clientID,
        'retargeting_remarketing' : this.marketingValue,
        'TimeHHMMSS': this.timestampTime,
        'DateTimeStamp': this.timestampDateTime
      };
      this.gtm.logEvent(this.sendContactUs);
      this.reset();
      this.disabled = false;
    }, err => {
      this.disabled = false;
      $('#snackbar-profile').addClass('show');
      this.toast_message = 'TOAST_MESSAGES.TRY_AGAIN';
      // $('#snackbar-profile').text('There was some error..please try again later');
      setTimeout(function() {$('#snackbar-profile').removeClass('show') ; } , 2000);
    });
    }

    public MobileRestrictNumbers(e) {
    // Allow: backspace, delete, tab, escape, enter.
    if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
           // Allow: Ctrl+A, Command+A
           (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
          // Allow: Ctrl+V, Command+V
          (e.keyCode === 86 && (e.ctrlKey === true || e.metaKey === true)) ||
           // Allow: home, end, left, right, down, up
           (e.keyCode >= 35 && e.keyCode <= 40)) {
               // let it happen, don't do anything
             return;
           }
    // Ensure that it is a number and stop the keypress
    if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
      e.preventDefault();
    }
    $('.inputMobileNumber').on('paste', function (event) {
      setTimeout(function () {
        $('.inputMobileNumber').val($('.inputMobileNumber').val().replace(/[^0-9]/g, ''));
      }, 0);
    });
  }

  public reset() {
    $('#autofit').css({'height': '36px'});
    this.files.length = null;
    this.flag = false;
    this.validation_keypress = false;
    $('.errorFacedInfo').css({'border-bottom': '1px solid'});
    $('#mobileValid').css({'border-bottom': '1px solid'});
    $('.errorMsgMobile').css({'display': 'none'});
    $('.emailId').css({'border-bottom': '1px solid'});
    $('.errorMsg').css({'display': 'none'});
    $('.InvalidMobile').css({'display': 'none'});
    $('.InvalidEmail').css({'display': 'none'});
    const logintype = this.localstorage.getItem('login');
    if (logintype === 'Email') {
      this.userMobileNumber = '';
      $('.inputEmailId').prop('readonly', true);
      $('#countryCode').prop('readonly', true);
      $('#mobileNumber').val('');
    } else if (logintype === 'Mobile') {
       if (this.userEmailId === '') {
      $('.inputEmailId').val('');

       } else {
      $('.inputEmailId').prop('readonly', true);

       // this.userEmailId = '';
    }
      // $('.inputMobileNumber').prop('readonly', true)
     // $('.inputEmailId').val('');
      $('#mobileNumber').val('');
    } else if (logintype === 'google' || logintype === 'facebook') {
      this.userMobileNumber = '';
      // this.userEmailId = '';
      // $('.inputMobileNumber').prop('readonly', true)
      $('.inputEmailId').prop('readonly', true);
      $('#countryCode').prop('readonly', true);
      $('#mobileNumber').val('');
    }  else if (logintype === 'twitter' )  {
       if ( this.userEmailId === '' ) {
         this.userMobileNumber = '';
          $('.inputEmailId').val('');
          $('#countryCode').prop('readonly', true);
          $('#mobileNumber').val('');
        } else {
            this.userMobileNumber = '';
            $('.inputEmailId').prop('readonly', true);
            $('#countryCode').prop('readonly', true);
            $('#mobileNumber').val('');
       }
}  else {
      this.userMobileNumber = '';
      // this.userEmailId = ''
      this.mobilenumbertext = 'LOGIN.MOBILE_NUM';
      $('#mobileNumber').val('');

      $('.inputEmailId').val('');
      this.email_return = false;
      this.mobile_return = false;
      this.error_return = false;
      this.error_return_keypress = false;
      this.email_return_keypress = false;
    }
    this.email_return = false;
    this.mobile_return = false;
    this.error_return = false;
    this.error_return_keypress = false;
    this.email_return_keypress = false;
    $('.autofit').val('');
  }
  private remove(index) {
    this.files.splice(index, 1);
  }
  public changeValue(event: any, selectedIndex: number) {
    let index;
    index = 'countryList' + selectedIndex;
    this.currentIndex = selectedIndex;
    document.getElementById(index).focus();
    this.selected_country = event;
    this.code = this.selected_country['phone-code'] ? '+' + this.selected_country['phone-code'] + '-' : undefined;
    this.zeeSupport = this.selected_country.mail;
    this.contacthrefURL = 'mailto:' + this.selected_country.mail + '?Subject=Feedback';
    let re;
    // re = /^([a-zA-Z0-9]+)(([^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    // re = /^([a-zA-Z0-9]+)(([^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
     // re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/; // to validate c.abcd@gags.co
        re = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?/; // to validate c.abcd@gags.co and caps 
    if (this.zeeSupport && this.zeeSupport !== null && this.zeeSupport.match(re)) {
      this.zeeSupport = this.selected_country.mail;
    } else {
      this.zeeSupport = this.configFile.default_values.support_email;
    }
    this.codeStyles();
    this.keyUpValidation();
    this.dropDownCheck = false;
  }
  public dropdown() {
    this.dropDownCheck = !this.dropDownCheck;
    if (this.dropDownCheck) {
      // $("#countryList"+this.currentIndex).focus()
      let scope;
      scope = this;
      setTimeout(() => {
        let index;
        index = 'countryList' + scope.currentIndex;
        document.getElementById(index).focus();

      }, 100);
      // $("#countryList"+this.currentIndex).focus()
    }
    // $(window).keydown(function(e) {
    //     console.log(e,"find me")
    // })
  }
  private increment() {
    this.previousIndex = this.currentIndex;
    this.currentIndex ++;
    let index;
    index = 'countryList' + this.currentIndex;
    document.getElementById(index).focus();
  }
  private decrement() {
    this.previousIndex = this.currentIndex;
    if ((this.currentIndex - 1) >= 0) {
      this.currentIndex --;
      let index;
      index = 'countryList' + this.currentIndex;
      document.getElementById(index).focus();
    }
  }
  @HostListener('window:keydown', ['$event'])
  private keyEvent(event: KeyboardEvent) {
    if ( this.dropDownCheck && event.keyCode === 40 ) {
      event.preventDefault();
      this.increment();
    }
    if (this.dropDownCheck && event.keyCode === 38 ) {
      event.preventDefault();
      this.decrement();
    }
    if (this.dropDownCheck && event.keyCode === 9 ) {
      this.dropdown();
    }
  }
  public hideError() {
    $('.errorMsg').css({'display': 'none'});
    $('.errorFacedInfo').css({'border-bottom': '1px solid'});
  }

  public hideErrorMobile() {
    $('.InvalidMobile').css({'display': 'none'});
    $('#mobileValid').css({'border-bottom': '1px solid'});
  }

  public hideErrorEmail() {
    $('.InvalidEmail').css({'display': 'none'});
    $('.emailId').css({'border-bottom': '1px solid'});
  }

  public emailValidCommon(change: any): any {
    let count1;
    count1 = $('#email').val().length;
    if (count1 > 0 ) {
      const scope = this;
      $(this.document).ready(function() {
        let email_text;
        email_text = $('#email').val();
        let re;
        // re = /^([a-zA-Z0-9]+)(([^-=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^-=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;         /* let re = /^([a-zA-Z0-9._+-]+)(@[a-zA-Z0-9-.]+)(.[a-zA-Z]{2,4}){2,}$/;*/
        // re = /^([a-zA-Z0-9._+-]+)(@[a-zA-Z0-9-.]+)(.[a-zA-Z]{2,4}){2,}$/;
        // re = /^([a-zA-Z0-9]+)(([^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+(\.[^=<>()\[\]\\.,;:\s@^}|{#!%$*&?`~/+'"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        // re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/; // to validate c.abcd@gags.co
        re = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?/; // to validate c.abcd@gags.co and caps 
        let emailTest;
        emailTest = re.test(email_text);
        if (email_text.length === 0 ) {
          // $('#loginEnterMsg').css({'display': 'block'});
          if (change) {
            $('#loginErrMsg').css({'display': 'none'});
            $('.emailId').css({'border-bottom': '1px solid'});
          }
          scope.email_return = true;
        } else {
          if (change) {
            $('#loginEnterMsg').css({'display': 'none'});
            $('#loginErrMsg').css({'display': 'block'});
            $('.emailId').css({'border-bottom': '1px solid'});
          }
          if (emailTest === false) {
            if (change) {
              $('.emailId').css({'border-bottom': '1px solid red'});
            }
            scope.email_return = false;
          } else {
            scope.email_return = true;
            if (change) {
              $('#loginErrMsg').css({'display': 'none'});
            }
          }
        }
      });
    } else {
      this.email_return = false;
    }
    return this.email_return;
  }
  public mobileValidCommon(change: any) {
    const scope = this;
    let mobile_number, minMobileLength, maxMobileLength, count1;
    mobile_number = $('#mobileNumber').val();
    minMobileLength = 4;
    maxMobileLength = this.maxLength;
    count1 = $('#mobileNumber').val().length;
    if (mobile_number !== undefined && mobile_number.length === 0 ) {
      if (change) {
        $('#loginMobileErrorMsg').css({'display': 'none'});
        $('#mobileValid').css({'border-bottom': '1px solid'});
      }
      scope.mobile_return = true;
      return this.mobile_return;
    } else {
      if (change) {
        $('#loginMobileEnterMsg').css({'display': 'none'});
        $('#loginMobileErrorMsg').css({'display': 'block'});
      }
      if (mobile_number !== undefined && ((mobile_number.length < minMobileLength) || (mobile_number.length > maxMobileLength)) && mobile_number[0] !== '0') {
        if (change) {
          $('#mobileValid').css({'border-bottom': '1px solid red'});
        }
        scope.mobile_return = false;
        return this.mobile_return;
      } else {
        if (scope.selected_country.code === 'IN' && this.code && mobile_number.length === 10  && mobile_number[0] !== '0') {
          scope.mobile_return = true;
          if (change) {
            $('#mobileValid').css({'border-bottom': '1px solid'});
            $('#loginMobileErrorMsg').css({'display': 'none'});
          }
          return this.mobile_return;
        } else if (scope.selected_country.code !== 'IN' && this.code && mobile_number[0] !== '0' ) {
          scope.mobile_return = true;
          if (change) {
            $('#mobileValid').css({'border-bottom': '1px solid'});
            $('#loginMobileErrorMsg').css({'display': 'none'});
          }
          return this.mobile_return;
        } else if (!this.code && ((mobile_number.length > minMobileLength) && (mobile_number.length < maxMobileLength)) && mobile_number[0] !== '0') {
          scope.mobile_return = true;
          if (change) {
            $('#mobileValid').css({'border-bottom': '1px solid'});
            $('#loginMobileErrorMsg').css({'display': 'none'});
          }
          return this.mobile_return;
        } else {
          if (change) {
            $('#mobileValid').css({'border-bottom': '1px solid red'});
          }
          scope.mobile_return = false;
          return this.mobile_return;

        }
      }
    }
  }
  public errorValidCommon(change: any) {
    let count1;
    count1 = $('#autofit').val().length;
   // if (count1 > 0) {
      const scope = this;
    //  $(this.document).ready(function() {
        let mobile_number;
        mobile_number = $('#autofit').val();
        if (mobile_number.length <= 0) {
          scope.error_return = false;
          if (change) {
            $('.errorMsg').css({'display': 'block'});
            $('.errorFacedInfo').css({'border-bottom': '1px solid red'});
          }
        } else {
          scope.error_return = true;
          if (change) {
            $('.errorMsg').css({'display': 'none'});
            $('.errorFacedInfo').css({'border-bottom': '1px solid'});
          }
        }
    //   });
    // } else {
    //   this.error_return = false;
    // }
    return this.error_return;
  }
  public keyUpValidation () {
    let scope;
    scope = this;
    setTimeout(() => {
      scope.functionCall();
    }, 1000);
  }
  private functionCall() {
    if (this.token && this.mobileValidCommon(false) && this.emailValidCommon(false) && this.errorValidCommon(false)) {
      this.validation_keypress = true;
    }    else if (!this.token && this.mobileValidCommon(false)  && this.emailValidCommon(false) && ($('#email').val().length > 0 && ($('#mobileNumber').val().length > 0)) && this.errorValidCommon(false) ) {
      this.validation_keypress = true;
    } else {
      this.validation_keypress = false;
    }
    return this.error_return;
  }
  private errorValidationKeypress() {
    let count1;
    count1 = $('#autofit').val().length;
    if (count1 >= 0) {
      const scope = this;
      $(this.document).ready(function() {
        let mobile_number;
        mobile_number = $('#autofit').val();
        if (mobile_number.length <= 0) {
          scope.error_return_keypress = false;
        } else {
          scope.error_return_keypress = true;
        }
        return scope.error_return_keypress;
      });
    }
  }

  public checkLengthkeypress() {


    if (this.disabled === true) {
      $('.submit').css({'background-color': '#50012f', 'color': '#703055'});
      return true;
    } else {
          if ((this.validation_keypress === false)) {
      $('.submit').css({'background-color': '#50012f', 'color': '#703055'});
      return true;
    } else {
      $('.submit').css({'background-color': '#bf006b', 'color': '#eeeeee'});
      return false;
    }
    }


  }
  public ngOnDestroy () {
    this.linkservice.removeCanonicalLink();
  }
}
