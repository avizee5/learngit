import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReminderSignupComponent } from './reminder-signup.component';

describe('ReminderSignupComponent', () => {
  let component: ReminderSignupComponent;
  let fixture: ComponentFixture<ReminderSignupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReminderSignupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReminderSignupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
