import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared.module';
import { ReminderSignupComponent } from './reminder-signup.component';

@NgModule({
  imports: [
    CommonModule,
    SharedModule
  ],
  declarations: [ReminderSignupComponent],
  exports: [ReminderSignupComponent]
})
export class ReminderSignupModule { }
