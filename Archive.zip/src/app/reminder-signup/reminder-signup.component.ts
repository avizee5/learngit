import { Component, OnInit, Input, Output, EventEmitter, OnDestroy, HostListener} from '@angular/core';
import { HeaderservicesService } from '../services/headerservices.service';
import * as $ from 'jquery';
import { Location } from '@angular/common';
import { PlatformLocation } from '@angular/common';
import { Router } from '@angular/router';
import { SubscriptionService } from '../services/subscription.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import {  NetworkService  } from '../services/network.service';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { environment } from '../../environments/environment';
import { TranslateService} from '@ngx-translate/core';
import { SettingsService } from '../services/settings.service';
import {CurrencyPipe} from '@angular/common';
import {CommonService} from '../services/common.service';
import { VideoService } from './../services/video.service';
// declare const adoric;
@Component({
  selector: 'app-reminder-signup',
  templateUrl: './reminder-signup.component.html',
  styleUrls: ['./reminder-signup.component.less']
})


  export class ReminderSignupComponent implements OnInit, OnDestroy {

  // @Input() remider_flag: boolean
  @Input() public dialogue_text: string;
  @Input() public type: string;
  @Input() public video: any = false;
  @Output() public changestatusreminder: EventEmitter<boolean> = new EventEmitter<boolean>();

  public headerMessage = [
    'REMINDER_POPUP.POINT1',
    'REMINDER_POPUP.POINT2',
    'REMINDER_POPUP.POINT3'
  ];
  public signInFlag = false;
  public butonText: string;
  public localstorage: any;
  public window: any;
  public document: any;
  public navigator: any;
  public basepath: any;
  public zee5logo: any;
  public close: any;
  public loginToken: any;
  public premium: any;
  // public existingUser: any;
  // public headerText: any;
  // public loggedInText: any;
  public skipText: any;
  public closeEvent: any;
  public displayEvent: any;
  public loginEvent: any;
  public subscribeEvent: any;
  public skipEvent: any;
  public registerLaterEvent: any;
  public registerNowEvent: any;
  public loginPremiumEvent: any;
  public planStartString: any;
  public planStart: any;
  public startingPrice: any;
  public eventType: any;
  public displayCurrencyFlag: any;
  public displayCurrencyValue: any;
  public displayCurrency = false;
  public country: any;
  public isPlanActive: any; // free trial comm
  public isAnyPlanHistroy: any; // free trial comm
  public freeTrial: any; // free trial comm
  public countryValues: any;
  public freeTrialValue: any;
  private svodCheck = false;
  private freePackID: any = [];
  constructor(private commonService: CommonService, private cp: CurrencyPipe, @Inject(PLATFORM_ID) private platformId: Object, private settingsService: SettingsService, private translate: TranslateService, private gtm: GoogleAnalyticsService,  private networkService: NetworkService, private sub: SubscriptionService, private router: Router, private headerservicesService: HeaderservicesService, private location: Location , elocation: PlatformLocation, private videoService: VideoService) {
    if (isPlatformBrowser(this.platformId)) {
      this.localstorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
    this.headerservicesService.signinValue.subscribe(value => {
      this.signInFlag = value;
    });
  }

  @HostListener('window:resize', ['$event'])
  public fontReScale(event) {
    this.checkHeight();
  }

  public ngOnInit() {
    // if (this.video) {
    //   $('.headerInit').css('z-index', '0');
    // }

    if (this.router.url.indexOf('tvguide') >= 0) {
      $('.margin').css('top', '54%');
    }
    this.gtm.storeWindowError();
    this.networkService.lockScroll();
    this.basepath = environment.assetsBasePath;
    this.zee5logo = this.basepath + 'assets/common/zee5_logo_popup.png';
    this.close = this.basepath + 'assets/common/close_ic1.png';
    $('#body').addClass('scrolldisbaleOverriden');
    $(this.document).keydown(function(e) {
      if (e.keyCode === 9) {
        e.preventDefault();
      }
    });
    this.stopBodyScrolling(true);
    this.country = this.settingsService.getCountry();
    this.loginToken = this.localstorage.getItem('token') ? true : false;
    this.premium = this.headerservicesService.premium;
    this.checkHeight();
   this.countryValues = this.settingsService.getCountryValueNew();
   this.svodCheck = (this.countryValues && this.countryValues[0] && this.countryValues[0].menu_options && this.countryValues[0].menu_options.premium_tag && this.countryValues[0].menu_options.premium_tag.toLowerCase() === 'yes') ? true : (false);
    if (this.countryValues && this.countryValues.length >= 1) {
      this.freeTrialValue  = this.countryValues[0].free_trial;
    }
    if (this.premium) {
      // this.headerText = 'SUSCRIPTION.SUBSCRIBE_INFO_DES';
      // this.loggedInText = 'COMMON.UPGRADE_PREMIUM';
      // free trial comm --starts
      if (this.freeTrialValue && this.freeTrialValue.toLowerCase() === 'true' && this.loginToken) {
        this.isPlanActive = this.sub.getPlanActiveAll();
        this.isAnyPlanHistroy = this.sub.getAllHistoryPlan();
        if (this.isPlanActive.length === 0 && this.isAnyPlanHistroy.length === 0) {
          this.butonText =  'SUSCRIPTION.FREETRIAL';
        } else {
          this.butonText =  'SUSCRIPTION.SUBSCRIBE_NOW';
        }
      } else if (this.freeTrialValue && this.freeTrialValue.toLowerCase() === 'true' && (!this.loginToken)) {
           this.butonText =  'SUSCRIPTION.FREETRIAL';
      } else {
           this.butonText =  'SUSCRIPTION.SUBSCRIBE_NOW';
      }
      // free trial comm --ends
      // this.butonText =  'SUSCRIPTION.SUBSCRIBE_NOW';
      // this.existingUser = 'LOGIN.EXISTING_PREMIUM_USERS';
      this.skipText = 'COMMON.SKIP';
    } else if (this.settingsService.pageViewCounter === this.settingsService.pageViewBuffer) { // This link issue cannot be fixed, its not a type check
    // } else if (this.settingsService.pageViewCounter == 7) { // This link issue cannot be fixed, its not a type check
      // this.headerText = 'LOGIN.LOGIN_INFO_DES';
      // this.loggedInText = 'LOGIN.LOGIN_NEW';
      // this.existingUser = 'LOGIN.EXISTING_USERS';
      this.skipText = 'LOGIN.REGISTER_LATER';
      // this.butonText = 'SUSCRIPTION.FREETRIAL';
      if (this.freeTrialValue && this.freeTrialValue.toLowerCase() === 'true') {
        this.butonText =  'SUSCRIPTION.FREETRIAL';
      } else {
        this.butonText = this.svodCheck
         ? 'SUSCRIPTION.SUBSCRIBE_NOW' : 'LOGIN.REGISTER_NOW';
      }
    } else {
      // this.headerText = 'LOGIN.LOGIN_INFO_DES';
      // this.loggedInText = 'LOGIN.LOGIN_NEW';
      // this.existingUser = 'LOGIN.EXISTING_USERS';
      this.skipText = 'LOGIN.REGISTER_LATER';
      this.butonText = this.svodCheck ? 'SUSCRIPTION.SUBSCRIBE_NOW' : 'LOGIN.REGISTER_NOW';
    }
    // send pop up display event to GA
    this.eventType = this.checkUserType();
    // if(adoric) {
    //   adoric.trigger("PopupDisplayed");
    // }
    this.displayEvent = {
      'event': 'PopupDisplayed',
      'PopupType': this.eventType
    };
    this.gtm.logEvent(this.displayEvent);
  }

  public checkHeight(): any {
    $(this.document).ready(function() {
      let height, innerHeigth;
      innerHeigth = window.innerHeight;
      height =  parseInt($('.alertBox_block').height(), 10);
      if (height > innerHeight) {
        $('.alertBox_block').css('height', (innerHeight - 20) + 'px');
      } else {
        $('.alertBox_block').css('height', '');
      }
    });
  }

  @HostListener('window:popstate', ['$event'])
  public onPopState(event) {
        this.closeDialogue(false);
  }

  public skipDialogue() {
    this.eventType = this.checkUserType();
    let eventValue;
    if (this.skipText === 'COMMON.SKIP') {
      eventValue = 'skip';
    } else if (this.skipText === 'LOGIN.REGISTER_LATER') {
      eventValue = 'register later';
    }
    // if(adoric) {
    //   adoric.trigger("PopupClick");
    // }
    this.registerLaterEvent = {
      'event': 'PopupClick',
      'PopupType': this.eventType,
      'cta':  eventValue
    };
    this.gtm.logEvent(this.registerLaterEvent);
    this.skipChange(false);
  }

  public closeDialogue(flag: any) {
    this.networkService.unLockScroll();
    $('#body').removeClass('scrolldisbaleOverriden');
    this.stopBodyScrolling(false);
    $('#body').css('overflow', '');
    // this.remider_flag = false
    if ( this.type === 'reminder') {
      this.headerservicesService.signReminderChange(false);
    } else if ( this.type === 'subs') {
      this.headerservicesService.subscribeReminderChange(false);
    }
    this.changestatusreminder.emit(false);
    // send close event to GA
    this.eventType = this.checkUserType();
    if (flag) {
      // if(adoric) {
      //   adoric.trigger("PopupClick");
      // }
      this.closeEvent = {
        'event': 'PopupClick',
        'PopupType': this.eventType,
         'cta': 'close button'

      };
      this.gtm.logEvent(this.closeEvent);
    }
  }

  public skipChange(flag: boolean) {
    let postRoute, postRouteLoc;
      postRoute = this.sub.getParentId();
      if(postRoute){
        postRouteLoc = JSON.parse(postRoute);
        if (this.localstorage.getItem('country_code') === 'IN') {
          this.commonService.getPostSubscriptionRoute(postRoute, 'popup');
        } else if (postRouteLoc.extra == null || postRouteLoc.extra === postRouteLoc.id) {
          this.commonService.getPostSubscriptionRoute(postRoute, 'popup');
        }
        // else if(!this.loginToken){
        //   this.videoService.showLoginOnSkip.next(true);
        // }
        // else{
        //   this.videoService.showSubOnSkip.next(true);
        // }
      }


    this.closeDialogue(flag);
  }
  public openDialogue() {
    // if() {
    //   .trigger("PopupClick");
    // }
    this.subscribeEvent = {
      'event': 'PopupClick',
      'PopupType': this.checkUserType(),
      'cta': 'subscribe now'
    };
    this.gtm.logEvent(this.subscribeEvent);
    this.subscribeOpen();
  }

  public subscribeOpen() {
    let id, locId;
    id = this.sub.getParentId();
    if(id){
      locId = JSON.parse(id);
      if ((this.localstorage.getItem('country_code') === 'IN') || (locId.extra == null || locId.extra === locId.id)) {
        this.localstorage.setItem('postSubscriptionRoute', id);
      }
      if((this.localstorage.getItem('country_code') !== 'IN') && (locId.extra != null && locId.extra !== locId.id) ){
        this.localstorage.setItem("trailLogin", true)
      }

    }
/*  this.router.navigate(['/myaccount/subscription']);
    this.sub.storeRedirectSubscribe(true);
    this.closeDialogue(false);*/
    if (this.butonText === 'SUSCRIPTION.SUBSCRIBE_NOW') {
      // naviagte to subscription plan page
      // this.router.navigate(['/myaccount/subscription']);
    this.headerservicesService.MygpSubscriptionroute();
      this.sub.storeRedirectSubscribe(true);
      this.closeDialogue(false);
    } else if (this.butonText === 'LOGIN.REGISTER_NOW') {
      // navigate to register screen
      this.registerOpen();
    } else if (this.butonText ===  'SUSCRIPTION.FREETRIAL') {
      // if free pack id exists, navigate to billing information screen
      this.checkFreePack();
    }

  }
  public signInOpen() {
    // send login  event to GA
    this.eventType = this.checkUserType();
    // if() {
    //   adoric.trigger("PopupClick");
    // }
    this.loginEvent = {
        'event': 'PopupClick',
        'PopupType': this.eventType,
        'cta': 'click here to login'
      };
    this.gtm.logEvent(this.loginEvent);

    this.closeDialogue(false);
    let id, locId;
    id = this.sub.getParentId();
    if(id){
      locId = JSON.parse(id);
      if ((this.localstorage.getItem('country_code') === 'IN') || (locId.extra == null || locId.extra === locId.id)) {
        this.localstorage.setItem('postSubscriptionRoute', id);
      }
      if((this.localstorage.getItem('country_code') !== 'IN') && (locId.extra != null && locId.extra !== locId.id) ){
        this.localstorage.setItem("trailLogin", true)
      }

    }
    this.router.navigate(['signin/mobile']);
  }

  public registerOpen() {
    this.closeDialogue(false);
    this.router.navigate(['register/mobile']);
  }

  public stopBodyScrolling (bool) {
    if (bool === true) {
      this.document.body.addEventListener('touchmove', this.freezeVp, false);
    } else {
      this.document.body.removeEventListener('touchmove', this.freezeVp, false);
    }
  }

  public freezeVp = function(e) {
    e.preventDefault();
  };

  public checkUserType(): any {
    let userType;
    userType =  this.loginToken ? 'existing user popup' : 'premium user popup';
    return userType;
  }

  public ngOnDestroy() {
    this.sub.setParentId(null, null);
    // if (this.video) {
    //   $('.headerInit').css('z-index', '');
    // }
    $(this.document).unbind('keydown');
    this.networkService.unLockScroll();
    this.freePackID = [];
    $('#body').css('overflow', '');
  }

  /* check if free trial pack and navigate to billinig information*/
  private checkFreePack(): any {
    let packId;
    packId = (this.countryValues[0] && this.countryValues[0].freetrial_screen && this.countryValues[0].freetrial_screen.web_app && this.countryValues[0].freetrial_screen.web_app.free_trial_auto && this.countryValues[0].freetrial_screen.web_app.free_trial_auto.length > 0) ? (this.countryValues[0].freetrial_screen.web_app.free_trial_auto) : '';
    this.freePackID.push(packId);

    if (this.freePackID && this.freePackID.length > 0 && this.freePackID !== '') {
      // navigate to billing info
      this.sub.storeFreePack(true);
      this.sub.storeFreePackDetails(this.freePackID);
      // this.router.navigate(['/myaccount/subscription']);
    this.headerservicesService.MygpSubscriptionroute();
      this.sub.storeRedirectSubscribe(true);
      this.closeDialogue(false);
    } else {
      // navigate to susbcription
      this.sub.storeFreePack(false);
      // this.router.navigate(['/myaccount/subscription']);
      this.headerservicesService.MygpSubscriptionroute();
      this.sub.storeRedirectSubscribe(true);
      this.closeDialogue(false);
    }
  }
}
