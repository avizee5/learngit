import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from '../shared.module';
import { DeviceCheckComponent } from './device-check.component';


@NgModule({
  imports: [
    CommonModule,
    SharedModule
  ],
  declarations: [DeviceCheckComponent],
  exports: [DeviceCheckComponent]

})
export class DeviceCheckModule {}
