// import { Component, OnInit } from '@angular/core';
import { Component, OnInit, Input, Output, EventEmitter, HostListener, OnDestroy } from '@angular/core';
import { DeviceApiService } from '../services/device-api.service';
import {environment} from '../../environments/environment';
import 'rxjs/add/operator/timeout';
import 'rxjs/add/operator/takeUntil';
import { Subscription } from 'rxjs/Subscription';
import { Subject } from 'rxjs/Subject';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import {  NetworkService  } from '../services/network.service';
import * as $ from 'jquery';

const deviceLimit = 'DEVICE_MANAGMENT.DEVICE_REMOVE'; // "Your device limit is reached. Do you want to add this device and remove one of your other devices ?
const addError = 'DEVICE_MANAGMENT.DEVICE_ADD';  // "Device Cannot be Added!"
const timeLimit = 'DEVICE_MANAGMENT.DEVICE_TIME'; // "Sorry! Any device can be added only once in 24 hours"
const sorryError = 'MESSAGES.TIMEOUT_ERROR'; // "Sorry, something went wrong, please try again."
@Component({
  selector: 'app-device-check',
  templateUrl: './device-check.component.html',
  styleUrls: ['./device-check.component.less']
})

export class DeviceCheckComponent implements OnInit, OnDestroy {
	public token: any;
	public localStorage: any;
  public document: any;
  public basepath: any;
  public zee5logo: any;
  public closeButton: any;
  public headerText: any;
  public cancleButton: any;
  public navigator: any;
  private ngUnsubscribe = new Subject<any>();
  @Output() public resetDeviceStatus = new EventEmitter<any>();
  // @Input() buttonLength: any = false; // 2 - true, 1 - false
  public buttonLength: any = true; // 2 - true, 1 - false
  constructor(@Inject(PLATFORM_ID) private platformId: Object, private deviceApi: DeviceApiService,  private networkService: NetworkService, private gtm: GoogleAnalyticsService) { }
  public ngOnInit() {
  	if (isPlatformBrowser(this.platformId)) {
      this.localStorage = localStorage;
      this.document = document;
      this.navigator = navigator;
    }
    if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i) || window.innerWidth <= 480) {
      this.document.getElementById('body').classList.add('modalOpen');
    } else {
      this.document.getElementById('body').classList.add('modal-open');
    }
    // $('#body').addClass('scrolldisbaleOverriden');
    $(this.document).keydown(function(e) {
      if (e.keyCode === 9) {
        e.preventDefault();
      }
    });
    this.stopBodyScrolling(true);
    this.gtm.storeWindowError();
    this.networkService.lockScroll();
    this.basepath = environment.assetsBasePath;
    this.zee5logo = this.basepath + 'assets/common/zee5_logo_popup.png';
    this.closeButton = this.basepath + 'assets/common/close_ic1.png';
  	this.token = this.localStorage.getItem('token');
    if (this.buttonLength) {
      this.headerText = deviceLimit;
      this.cancleButton = 'COMMON.CANCEL_CAPS';
    } else {
      this.headerText = addError;
      this.cancleButton = 'COMMON.OK_BTN';
    }
  }
  public reset(): any {
    this.deviceApi.deleteDevice(this.token).takeUntil(this.ngUnsubscribe).timeout(environment.timeOut).subscribe(value => {
      this.resetDeviceStatus.emit('success');
    }, error => {
      this.buttonLength = false;
      this.cancleButton = 'COMMON.OK_BTN';
      if (error.name === 'TimeoutError') {
        this.headerText = sorryError;
      } else {
        let body;
        body = JSON.parse(error._body);
        if (body.code === 3607) { // device can be reset only once in 24hrs
          this.headerText = timeLimit;
        } else {
        	this.headerText = sorryError;
        }
      }
      this.gtm.sendErrorEvent('api', error);
    });
  }
  public close(): any {
    if (this.headerText === timeLimit) {
      this.resetDeviceStatus.emit(timeLimit);
    } else if (this.headerText === deviceLimit) {
      this.resetDeviceStatus.emit(deviceLimit);
    } else {
      this.resetDeviceStatus.emit(sorryError);
    }
  }

  public stopBodyScrolling (bool) {
    if (bool === true) {
      this.document.body.addEventListener('touchmove', this.freezeVp, false);
    } else {
      this.document.body.removeEventListener('touchmove', this.freezeVp, false);
    }
  }

  public freezeVp = function(e) {
    e.preventDefault();
  };

  public ngOnDestroy(): void {
    this.networkService.unLockScroll();
    // $('#body').removeClass('scrolldisbaleOverriden');
    this.stopBodyScrolling(false);
    $(this.document).unbind('keydown');
    this.networkService.unLockScroll();
    if (this.navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i) || window.innerWidth <= 480) {
      this.document.getElementById('body').classList.remove('modalOpen');
    } else {
      this.document.getElementById('body').classList.remove('modal-open');
    }
  }
}
