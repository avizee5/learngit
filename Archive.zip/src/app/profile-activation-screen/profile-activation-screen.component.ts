import { Component, OnInit, Input, Output, HostListener, EventEmitter } from '@angular/core';
import { HeaderservicesService } from '../services/headerservices.service';
import * as $ from 'jquery';
import { PlatformLocation } from '@angular/common';
import { Router } from '@angular/router';
import { ActivatedRoute , Params } from '@angular/router';
import { Location } from '@angular/common';
import { RouteService } from '../services/route.service';
import * as userApi from '../../data/user/api/api';
import { Http } from '@angular/http';
import {  NetworkService  } from '../services/network.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import {environment} from '../../environments/environment';
import 'rxjs/add/operator/timeout';
import { isPlatformBrowser } from '@angular/common';
import {  Inject, PLATFORM_ID } from '@angular/core';
declare const qg;
import { SettingsService } from '../services/settings.service';
import {CommonService} from '../services/common.service';

@Component({
  selector: 'app-profile-activation-screen',
  templateUrl: './profile-activation-screen.component.html',
  styleUrls: ['./profile-activation-screen.component.less']
})
export class ProfileActivationScreenComponent implements OnInit {

@Input() private profileCompFlag: any;  // send it to sigin screen
@Input() private signinHide: any;      // to hide sigin screen
@Input() private signinleft: any;
@Input() private signin: any;
@Input() private registermobileON: any;  // not used
@Input() private registerEmailON: any;   // not used
private timestampTime: any;
private timestampDateTime: any;
public buttonChangeCheck: boolean;
private routerCheck = false;
private code: any = '';
private userapi: any;
private error_message: any;
public confirmed_email = false;
private errors: any;
public responseAvailable = false;          // outer div show at a time
public error_check = false;
public loggedIn = false;
private retry: any;
private registercheck = false;
private pageName: any;
private profileActive: any;
public assetbasepath: any;
private tokenValue: any;
private personalizeClick = false;
  private heading1 = 'Hurray! Your profile has been activated.';
  private heading2 = 'Now you can either start personalizing your account or start browsing Zee5.';
  private button_personalise = 'PERSONALISE';
  private button_browse = 'BROWSE';
  private profileShow1: any;
  private signinleftchange: any;
  private signinchange: any;
  private localstorage: any;
  private window: any;
  private document: any;
  private navigator: any;
  private twitterTime: any;
  private twitterType: any;
  private pageName1: any;
  private countrycode: any;
  private clientID: any;
private marketingValue: any;
 private qgraph: any;
@Output() public update = new EventEmitter<boolean>();
  constructor(private commonService: CommonService, private settingsService: SettingsService, @Inject(PLATFORM_ID) private platformId: Object, private gtm: GoogleAnalyticsService, private networkService: NetworkService, private routeservice: RouteService, private headerservicesService: HeaderservicesService, private http: Http, private to: Location, location: PlatformLocation, private activatedRoute: ActivatedRoute,  private router: Router) {
    if (isPlatformBrowser(this.platformId)) {
      this.localstorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
  location.onPopState(() => {
        this.closeProfile();
        this.pass();
  });
  this.responseAvailable = false;
  this.loggedIn = this.routeservice.getloggedInstate(); // if true logout from website already login
  this.assetbasepath = environment.assetsBasePath;
  this.headerservicesService.PersonalizeReloadChange(false);  // to relad language screen after personalize
  this.headerservicesService.blockeventsValue.subscribe(value => {
     this.qgraph = this.headerservicesService.getRemarketing();
    });
}

  public ngOnInit() {
    this.gtm.storeWindowError();
    let network;
    network = this.networkService.getScreenStatus();
    this.qgraph = this.headerservicesService.getRemarketing();
    if (network === true) {
     this.countrycode = this.settingsService.getCountry();
     this.pageName = 'profile activated';
     this.gtm.sendPageName(this.pageName);
     this.gtm.sendEvent();
     this.twitterTime = this.localstorage.getItem('twitterTime');
     this.twitterType = this.localstorage.getItem('twitterType');
    $('#loaderPage').css('display:', 'block');
    this.responseAvailable = false;
    this.buttonChangeCheck = this.headerservicesService.getButtonChange();  // for mobile to show personlize screen
    this.code = this.routeservice.getcode(); // verfiy code
    this.registercheck = this.headerservicesService.getRegisterSuccess();   // from registration r login
    if (this.registercheck === true) {
      this.buttonChangeCheck = false;
    }
    if (this.buttonChangeCheck === true || this.buttonChangeCheck === undefined) {
        this.button_personalise = 'LOGIN.LOGIN_CAPS';
        this.responseAvailable = true;
    } else if (this.buttonChangeCheck === false || this.registercheck === true) {
      this.button_personalise = 'LOGIN.PERSONALIZE_CAPS';
      this.routerCheck = true;
      this.responseAvailable = true;
    }
    if (this.loggedIn) {
      this.retry = 'MENU.LOGOUT';  // if its login
    } else {
      this.retry = 'COMMON.RETRY';  // if code error
    }
    if (this.registercheck) {
      this.responseAvailable = true;
      this.error_check = false;
    } else if ((this.buttonChangeCheck === undefined && (this.loggedIn === false || this.loggedIn === undefined)) === true) {
       this.responseAvailable = false;
       this.userapi = new userApi.UserApi(this.http, null, null);
   this.userapi.v1UserConfirmemailPut(this.code).timeout(environment.timeOut).subscribe(res => {
    this.error_message = res.message;
    this.responseAvailable = true;
    this.confirmed_email = true;
    this.error_check = false;
    this.tokenValue = this.gtm.fetchToken();
    this.timestampTime = this.gtm.fetchCurrentTime();
    this.timestampDateTime = this.gtm.fetchCurrentDate();
    if (this.confirmed_email === true) {
    $('.now').text('Now you can either login to your account or start browsing on Zee5.');
    this.tokenValue = this.gtm.fetchToken();
    this.timestampTime = this.gtm.fetchCurrentTime();
    this.timestampDateTime = this.gtm.fetchCurrentDate();
    this.clientID = this.gtm.fetchClientId();
    this.marketingValue = this.gtm.fetchMarketing();
    this.gtm.logEvent({
                     'event' : 'RegisterSuccess',
                     'LoginMethod' : 'email',
                     'G_ID': this.tokenValue,
                     'Client_ID': this.clientID,
                     'retargeting_remarketing' : this.marketingValue,
                     'TimeHHMMSS': this.timestampTime,
                     'DateTimeStamp': this.timestampDateTime
              });
    this.pageName1 = 'register/Success';
    this.gtm.sendPageName(this.pageName1);
    this.gtm.sendEvent();
    this.qgraphevent('signup_success', {'verified': true, 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
    }
    $('#loaderPage').css('display', 'none');

  }, err => {
      this.responseAvailable = true;
      this.error_check = true;
      this.errors = err.json();
      this.confirmed_email = false;
      if (err.status === 400) {
      this.error_message = this.errors.message;
    }
    this.qgraphevent('signup_success', {'verified': false, 'country' : this.countrycode, 'state': localStorage.getItem('state_code')});
    this.gtm.sendErrorEvent('api', err);
    $('#loaderPage').css('display', 'none');
  });
   }
}
}
public closeProfile(): any {
    this.signin = true;
    this.signinleft = true;
    this.profileCompFlag = false;
    this.headerservicesService.ProfileActivationChange(false);  // added newly
    this.headerservicesService.modelChange(false);
    this.headerservicesService.registerMobilechange(false);
    this.headerservicesService.signinChange(false);
    this.headerservicesService.signinDetailsChange(true);
    this.headerservicesService.signinLeftChange(true);
    this.headerservicesService.signinRightTopChange(true);
    this.headerservicesService.bgImageValueChange(true);
    this.headerservicesService.loginHeadingChange(false);
    this.headerservicesService.registerHeadingChange(true);
    this.routeservice.Signal(null);                    // route value sending as a null to remove verfiy route
    let postRoute;
    postRoute = this.localstorage.getItem('postSubscriptionRoute');
    if (this.twitterType === 'register') {
       this.localstorage.removeItem('twitterType');
      if (postRoute) {
        this.localstorage.removeItem('postSubscriptionRoute');
        this.commonService.getPostSubscriptionRoute(postRoute, 'register');
      } else {
        this.window.location.href = environment.twitterLogout + this.localstorage.getItem('previousRoute') + '&ver=' + this.twitterTime;
        // this.window.location.href = environment.twitterLogout + '/' + '&ver=' + this.twitterTime;
      }
      // this.window.location.href = environment.twitterLogout + '/' + '&ver=' + this.twitterTime;
    } else {
      // this.to.go(this.routeservice.previousRoute());
      this.localstorage.setItem('googletag', 'false');
      // this.window.location.reload(true);
        if (postRoute) {
          this.localstorage.removeItem('postSubscriptionRoute');
          this.commonService.getPostSubscriptionRoute(postRoute, 'register');
        } else {
          // this.to.go(this.routeservice.previousRoute());
          // this.window.location.reload(true);
          this.window.location.href = this.window.location.origin + this.localstorage.getItem('previousRoute');
        }
        if (this.signinHide) {                      // to hide signin hide
           this.signinHide.classList.remove('signinCalldisplay');
           this.signinHide.classList.add('signinCall');
        }
      this.document.getElementById('body').classList.remove('modal-open');
       $('#body').removeClass('scrolldisbale');
       if (this.buttonChangeCheck === false) {
          this.headerservicesService.addChanges(false);
       }
    }
}
public pass(): any {
        this.signinleftchange = {p3: this.signinleft};
        this.update.emit(this.signinleftchange);
        this.profileShow1 = {p1: this.profileCompFlag};
        this.update.emit(this.profileShow1);
      }
public ChooseFunction() {   // personlize and login route
        let network;
        network = this.networkService.getPopupStatus();
    if (network === true) {
        if (((this.buttonChangeCheck === true || this.buttonChangeCheck === undefined) && (this.loggedIn === false || this.loggedIn === undefined)) === true) {  // login
             this.router.navigate(['/signin']);
             this.localstorage.setItem('googletag', 'false');
             // this.window.location.reload(true);
             this.headerservicesService.signinLeftChange(true);
             this.headerservicesService.ProfileActivationChange(false);
             this.headerservicesService.signinDetailsChange(true);
             this.headerservicesService.signinLeftChange(true);
             this.headerservicesService.signinRightTopChange(true);
             this.headerservicesService.bgImageValueChange(true);
             this.headerservicesService.loginHeadingChange(false);
             this.headerservicesService.registerHeadingChange(true);
	          // this.window.location.reload(true);
		        setTimeout(() => {
				     this.window.location.reload(true);
            }, 100);
      } else if (((this.buttonChangeCheck === false) && (this.loggedIn === false || this.loggedIn === undefined)) === true) {  // personlize
            this.signin = true;
            this.signinleft = true;
            this.profileCompFlag = false;
            this.personalizeClick = true;
             this.headerservicesService.ProfileActivationChange(false); // added newly
            this.headerservicesService.PersonalizeReloadChange(true);
            this.headerservicesService.modelChange(false);
            this.headerservicesService.registerMobilechange(false);
            this.headerservicesService.signinChange(false);
            this.headerservicesService.signinDetailsChange(true);
            this.headerservicesService.signinLeftChange(true);
            this.headerservicesService.signinRightTopChange(true);
            this.headerservicesService.bgImageValueChange(true);
            this.headerservicesService.loginHeadingChange(false);
            this.headerservicesService.registerHeadingChange(true);
            this.routeservice.Signal(null);
            this.headerservicesService.addChanges(false);
            this.pass();
           if (this.twitterType === 'register') {
              this.localstorage.removeItem('twitterType');
            this.window.location.href = environment.twitterLogout + '/language' + '&ver=' + this.twitterTime;
          } else {
            this.router.navigate(['/language']);
            if (this.signinHide) {
             this.signinHide.classList.remove('signinCalldisplay');
             this.signinHide.classList.add('signinCall');
              }
            this.document.getElementById('body').classList.remove('modal-open');
             $('#body').removeClass('scrolldisbale');
          if (this.buttonChangeCheck === false) {
            this.headerservicesService.addChanges(false);
             }
           }
        } else if (this.buttonChangeCheck === undefined && this.loggedIn === true) {  // logout
            this.closeProfile();
            this.localstorage.removeItem('token');
            this.localstorage.removeItem('login');
            this.localstorage.removeItem('twitterToken');
            this.router.navigate(['/']);
            this.localstorage.setItem('googletag', 'false');
            this.window.location.reload(true);
            this.headerservicesService.addChanges(false);
        }
      }
    }
  private qgraphevent(eventname, object) {
    if (this.window.qg) {
      // if (this.qgraph) {
      //   delete object.country;
      //   delete object.state;
      //   qg('event', eventname, object);
      // } else {
        qg('event', eventname, object);
      // }
    }
  }
}

