import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfileActivationScreenComponent } from './profile-activation-screen.component';

describe('ProfileActivationScreenComponent', () => {
  let component: ProfileActivationScreenComponent;
  let fixture: ComponentFixture<ProfileActivationScreenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfileActivationScreenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfileActivationScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
