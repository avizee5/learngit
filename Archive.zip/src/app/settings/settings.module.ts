import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared.module';
import { SettingsComponent } from './settings.component';
import { CheckBoxModule } from '../checkbox/checkbox.module';
import { ToggleswitchComponent } from '../settings/toggleswitch/toggleswitch.component';

const routes: Routes = [
    { path: '', component: SettingsComponent},

];
@NgModule({
 exports: [RouterModule],
  imports: [RouterModule.forChild(routes), CommonModule, SharedModule, CheckBoxModule],
  declarations: [SettingsComponent, ToggleswitchComponent]
})
export class SettingsModule {}
