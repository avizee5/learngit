import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-toggleswitch',
  templateUrl: './toggleswitch.component.html',
  styleUrls: ['./toggleswitch.component.less']
})
export class ToggleswitchComponent implements OnInit {

  @Input() public enabled: any;
  constructor() {
  	// todo
  }

  public ngOnInit() {
  	// todo
  }

}
