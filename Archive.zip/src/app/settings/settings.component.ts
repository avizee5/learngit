import { Component, OnInit, HostListener, OnDestroy  } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { Router } from '@angular/router';
import { HeaderservicesService } from '../services/headerservices.service';
import { UserApiService } from '../services/user-api.service';
import { VideoService } from '../services/video.service';
import { GoogleAnalyticsService } from '../services/google-analytics.service';
import { NetworkService } from '../services/network.service';
import { SettingsService } from '../services/settings.service';
import { RouteService } from '../services/route.service';
import * as $ from 'jquery';
import * as SettingsApi from '../../data/user/api/api';
import { Http } from '@angular/http';
import {environment} from '../../environments/environment';
import { LinkService } from '../services/link.service';

/* Angular Universal */
import { isPlatformBrowser } from '@angular/common';
import { Inject , PLATFORM_ID } from '@angular/core';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.less']
})

export class SettingsComponent implements OnInit, OnDestroy  {
  public router: any;
  public router2: any;
  public pageName: any;

  public qualityTypes: any;
  public option: any;
  public streamingValue: any;
  public selectedQuality: Array<any> = [];

  public autoPlay: any; /*Handling Autoplay button */
  public autoplayDigital: any;
  public controlRipple: any; /*For ripple effect */

  public open: any;
  public closed: any;
  public currentPhone: string;
  public currentEmail: string;
  public currentSMS: string;
  public selectionTrack: any;

  public settings: any;   /*JSON handling */
  public errorMessage: any;
  public userSettings: any;
  public updated_settings: any;
  public userToken: any;
  public key: any;
  public delete_settings: any;
  public configValue: any;

  public localStorage: any;
  public window: any;
  public document: any;
  public navigator: any;

  public autoPlayBool: any;
  public streamingQualityBool: any;
  public default_settings: any;
  public settingsBreadCrump: any;

  // Asset basepath variable
  public assetbasepath = environment.assetsBasePath;
  public oneTrust: any = false;
  
  constructor(private linkservice: LinkService, @Inject(PLATFORM_ID) private platformId: Object, private networkService: NetworkService, private routeservice: RouteService, private settingsService: SettingsService, private gtm: GoogleAnalyticsService, private videoService: VideoService, private userapiService: UserApiService, private headerservicesService: HeaderservicesService,  private routerLink: Router,  private http: Http) {
    if (isPlatformBrowser(this.platformId)) {
      this.localStorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }
    this.routeservice.setLoginRoute(this.window.location.pathname);  /*Return back to this page on login relaod */
    this.router = routerLink;
    this.router2 = this.window.location.pathname;
    this.headerservicesService.viewChange(this.router2);
  }

  public ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.localStorage = localStorage;
      this.window = window;
      this.document = document;
      this.navigator = navigator;
    }

       this.settingsBreadCrump = [
        {
          'label': 'BREADCRUMB.HOME',
          'url': '/',
          'enable': true
        },
        {
          'label': 'BREADCRUMB.SETTINGS',
          'url': '/settings',
          'enable': false
        }
      ];


      this.headerservicesService.breadCrump(this.settingsBreadCrump);


    this.linkservice.addTag({ rel: 'canonical', href: this.window.location.origin + '/' + this.routeservice.getBaseLocation()  +  'settings'  } );    this.configValue = environment.configFile;
    this.open = this.assetbasepath + 'assets/common/minus.png';
    this.closed = this.assetbasepath + 'assets/common/plus.png';

    let network;
    network = this.networkService.getScreenStatus();
    this.gtm.storeWindowError();
    $('#loaderPage').css('display', 'none');
    this.window.scrollTo(0, 0);
    this.pageName = 'settings';  /* Google Analytics */
    this.gtm.sendPageName(this.pageName);
    this.gtm.sendEvent();

    /* Streaming Quality */
    this.configValue = this.settingsService.getCompleteConfig();
    this.qualityTypes = this.configValue.streaming_quality;

    /* One Trust */
    let country;
    country = this.settingsService.getCountry();
    this.oneTrust = window['OnetrustActiveGroups'] && this.configValue && this.configValue.google_consent_allowed_countries && this.configValue.google_consent_allowed_countries.indexOf(country) !== -1;

    /*General settings */
    let p;
    p = this.localStorage.getItem('autoPlay');
    let q;
    q = this.localStorage.getItem('streamingQuality');
    this.userToken = this.localStorage.getItem('token');
    if (this.userToken) {   /*LOGGED IN USER*/
      let userBearer;
      userBearer = 'bearer ' + this.userToken;
      let config;
      config = {
      apiKey: userBearer,
      username: ' ',
      password: ' ',
      accessToken: ' ',
      withCredentials: false
      };

     this.userSettings = new SettingsApi.SettingsApi(this.http, null, config);

     this.userSettings.v1SettingsGet().subscribe(response => {
      if ( response.length > 0) {
        for (let i = 0; i < response.length; i++) {
          if ( response[i].key === 'auto_play') {
            this.autoPlayBool = true;
            if ( response[i].value === 'true') {
              this.autoPlay = true;
              this.autoplayDigital = true; // changed for undefined
            } else {
              this.autoPlay = false;
              this.autoplayDigital = false; // changed for undefined
            }
            this.videoService.autoPlay = this.autoPlay;
          }

          if ( response[i].key === 'streaming_quality') {
            this.streamingQualityBool = true;
            this.selectedQuality = [];
            this.selectedQuality.push(response[i].value);
            this.isChecked(response[i].value);
            this.videoService.bitRate = this.selectedQuality[0];
            this.streamingValue = this.selectedQuality[0]; // changed for undefined
          }
        }

           if (!this.autoPlayBool || !this.streamingQualityBool) {
            if (!this.autoPlayBool) {
              this.default_settings =
              [
               {key: 'auto_play', value: 'true' }
              ];

              this.autoPlay = true;
              this.videoService.autoPlay = this.autoPlay;
            }

            if (!this.streamingQualityBool) {
              this.default_settings =
              [
               {key: 'streaming_quality', value: 'Auto' }
              ];

              this.selectedQuality = [];
              this.selectedQuality.push('Auto');
              this.isChecked('Auto');
              this.videoService.bitRate = this.selectedQuality[0];
            }

            if (!this.autoPlayBool && !this.streamingQualityBool) {
              this.default_settings =
              [
               {key: 'auto_play', value: 'true' },
               {key: 'streaming_quality', value: 'Auto' }
              ];

              this.autoPlay = true;
              this.videoService.autoPlay = this.autoPlay;
              this.selectedQuality = [];
              this.selectedQuality.push('Auto');
              this.isChecked('Auto');
              this.videoService.bitRate = this.selectedQuality[0];
            }

            for (let i = 0; i < this.default_settings.length ; i++) {

            const defaultsettings = {
              'key': this.default_settings[i].key,
              'value': this.default_settings[i].value
            };

            this.userSettings.v1SettingsPost(defaultsettings).subscribe(responsePost => {
                // todo
            },
            err => {
              // todo
            });
          }
        }
      } else {
        this.autoPlay = true;
        this.videoService.autoPlay = this.autoPlay;
        this.selectedQuality.push('Auto');
        this.isChecked('Auto');
        this.videoService.bitRate = this.selectedQuality[0];
      }
    }, err => {
        this.autoPlay = true; // update when API arrives
        this.autoplayDigital = 'true';
        this.videoService.autoPlay = this.autoPlay;
        this.selectedQuality = [];
        this.selectedQuality.push('Auto');
        this.streamingValue = this.selectedQuality[0];
        this.isChecked('Auto');
        this.videoService.bitRate = this.streamingValue;
        this.gtm.sendErrorEvent('api', err);
      });
    } else {        /*GUEST USER*/
      if ( p === null && q === null) {   /* AutoPlay */
        this.localStorage.setItem('autoPlay', 'true');
        this.localStorage.setItem('streamingQuality' , 'Auto');
        this.autoPlay = true;
        this.autoplayDigital = 'true';
        this.videoService.autoPlay = this.autoPlay;
        this.selectedQuality = [];
        this.selectedQuality.push('Auto');
        this.streamingValue = 'Auto';
        this.isChecked('Auto');
      } else {
        if (p) {
          if ( this.localStorage.getItem('autoPlay') === 'true') {
            this.autoPlay = true;
            this.autoplayDigital = 'true';
          } else if ( this.localStorage.getItem('autoPlay') === 'false') {
            this.autoPlay = false;
            this.autoplayDigital = 'false';
          }
          this.videoService.autoPlay = this.autoPlay;
        }
        if (q) {
          let z1;
          z1 = this.localStorage.getItem('streamingQuality');
          this.selectedQuality = [];
          this.selectedQuality.push(z1);
          this.streamingValue = this.selectedQuality[0];
          this.isChecked(z1);
          this.videoService.bitRate = this.streamingValue;
        }
      }
    }

    /*Notifications */
    this.settings = [ { 'id': '1', 'name': 'MENU.REMINDERS' },
                      { 'id': '2', 'name': 'SETTINGS.NEW_CONTENT' },
                      { 'id': '3', 'name': 'SETTINGS.OFFLINE_SEARCH' },
                      { 'id': '4', 'name': 'SETTINGS.CONTINUE_WATCH' },
                      { 'id': '5', 'name': 'SETTINGS.NEW_EPISODE' },
                      { 'id': '6', 'name': 'SETTINGS.SUBS_RENEWAL' },
                      { 'id': '7', 'name': 'SETTINGS.REMINDER_RENEW' },
                      { 'id': '8', 'name': 'SETTINGS.CONFIRM_RENEW' }];

    this.currentPhone = this.closed;
    this.currentEmail = this.closed;
    this.currentSMS = this.closed;

    let x;
    x = this.document.getElementById('PhonenotificationOptions');
    let y;
    y = this.document.getElementById('EmailnotificationOptions');
    let z;
    z = this.document.getElementById('SMSnotificationOptions');

    x.style.display = 'none';
    y.style.display = 'none';
    z.style.display = 'none';

    /*setting array for selection category types*/
    this.selectionTrack = {'phone': [], 'email': [], 'sms': []};

    /*update the length-after the Api docs are received*/
    for (let i = 0; i <= this.settings.length; i++) {
       this.selectionTrack.phone[i] = true;
       this.selectionTrack.email[i] = true;
       this.selectionTrack.sms[i] = true;
    }
  }

 /* Streaming Qualities */
  public onClicked(value, i) {
   $('#rippleRadio' + i).removeClass('animate');
   clearTimeout(this.controlRipple);
   $('#rippleRadio' + i).addClass('animate');
   this.controlRipple = setTimeout(() => {
   $('#rippleRadio' + i).removeClass('animate');
    }, 300);
   this.selectedQuality = [];
   this.selectedQuality.push(value);
   this.streamingValue = this.selectedQuality[0];
  }

  public isChecked(value): boolean {
    return this.selectedQuality.indexOf(value) > -1;
  }

  public overlayBottom(id, event) {
    let a, b, c, x, y, z;
    a = this.document.getElementById('PhonenotificationHeadingtitle');
    b = this.document.getElementById('EmailnotificationHeadingtitle');
    c = this.document.getElementById('SMSnotificationHeadingtitle');
    x = this.document.getElementById('PhonenotificationOptions');
    y = this.document.getElementById('EmailnotificationOptions');
    z = this.document.getElementById('SMSnotificationOptions');

    if ( event === 1 && x.style.display === 'none') {
        this.currentPhone = this.open;
        this.currentEmail = this.closed;
        this.currentSMS = this.closed;

        a.style.color = 'white';
        b.style.color = '#6e6e6e';
        c.style.color = '#6e6e6e';
        if (this.navigator.userAgent.match(/iPad/i)) {
          x.style.display = 'inline-block';
        } else {
          x.style.display = 'inline-flex';
          y.style.display = 'none';
          z.style.display = 'none';
        }
    } else if ( event === 2 && y.style.display === 'none') {
        this.currentEmail = this.open;
        this.currentPhone = this.closed;
        this.currentSMS = this.closed;

        b.style.color = 'white';
        a.style.color = '#6e6e6e';
        c.style.color = '#6e6e6e';
        if (this.navigator.userAgent.match(/iPad/i)) {
          y.style.display = 'inline-block';
        } else {
          y.style.display = 'inline-flex';
          x.style.display = 'none';
          z.style.display = 'none';
        }
      } else if (event === 3 && z.style.display === 'none') {
        this.currentSMS = this.open;
        this.currentPhone = this.closed;
        this.currentEmail = this.closed;

        c.style.color = 'white';
        b.style.color = '#6e6e6e';
        a.style.color = '#6e6e6e';
        if (this.navigator.userAgent.match(/iPad/i)) {
          z.style.display = 'inline-block';
        } else {
          z.style.display = 'inline-flex';
          y.style.display = 'none';
          x.style.display = 'none';
        }
      } else {
        this.currentPhone = this.closed;
        this.currentEmail = this.closed;
        this.currentSMS = this.closed;

        a.style.color = '#6e6e6e';
        b.style.color = '#6e6e6e';
        c.style.color = '#6e6e6e';
        x.style.display = 'none';
        y.style.display = 'none';
        z.style.display = 'none';
      }
  }

  public toggleAutoplay() {                   /*Handling video autoplay & settings autoplay */
    this.autoPlay = !this.autoPlay;     // TO be updated once API arrives
    if (this.autoPlay === true) {
      this.autoplayDigital = 'true';
    } else {
      this.autoplayDigital = 'false';
    }
    // this.videoService.autoPlay = this.autoPlay;
  }

  public callToast() {                        /*Calling Toast on saving changes */
    let p;
    p = this.document.getElementById('snackbar');
    p.className = 'show';
    setTimeout(function() { p.className = p.className.replace('show', ''); }, 3000);
  }

  public toggleCheckboxes(checkBoxIndex, selectionCategory): any {  /* Handling individual checkboxes */
    this.selectionTrack[selectionCategory][checkBoxIndex] = !this.selectionTrack[selectionCategory][checkBoxIndex];
  }

  public clearHistory() {
    let network;
    network = this.networkService.getPopupStatus();
    if (network === true) {
      if ( this.userToken) {
        this.setContent('recent_search', '-');
      } else {
        this.localStorage.removeItem('Recent Searches');
      }

      this.callToastClearHistory();
    }
  }

  public callToastClearHistory() {
    let p;
    p = this.document.getElementById('snackbarClear');
    p.className = 'show';
    setTimeout(function() { p.className = p.className.replace('show', ''); }, 3000);
  }

  public callErrorToast() {
    let p;
    p = this.document.getElementById('snackbarError');
    p.className = 'show';
    setTimeout(function() { p.className = p.className.replace('show', ''); }, 3000);
  }

  public setContent(key, n): any { /*Setting in Service file*/
    this.userapiService.getParameter('put', key, n);
  }

  public saveChanges() {
    let network;
    network = this.networkService.getPopupStatus();
    if ( network === true) {
      this.userToken = this.localStorage.getItem('token');
      if (this.userToken) {    /*LOGGED IN USER*/
        this.updated_settings = [
        {key: 'auto_play', value: this.autoplayDigital },
        {key: 'streaming_quality', value: this.streamingValue },
        ];

        let userBearer;
        userBearer = 'bearer ' + this.userToken;
        let config;
        config = {
          apiKey: userBearer,
          username: ' ',
          password: ' ',
          accessToken: ' ',
          withCredentials: true
        };

        let userDetails;
        userDetails = new SettingsApi.SettingsApi(this.http, null, config);

        for (let i = 0 ; i < 2; i++) {
          let updatedsettings;
          updatedsettings = {
            'key': this.updated_settings[i].key,
            'value': this.updated_settings[i].value
          };

          userDetails.v1SettingsPut(updatedsettings).subscribe(value => {
            // todo
             this.callToast();
          },
          error => {
            this.callErrorToast();
            this.gtm.sendErrorEvent('api', error);
          });
        }
      } else {            /*GUEST USER*/
        this.localStorage.setItem('autoPlay', this.autoplayDigital );
        this.localStorage.setItem('streamingQuality', this.streamingValue );
         this.callToast();
      }
      this.videoService.bitRate = this.streamingValue;
      this.videoService.autoPlay = this.autoPlay;

    }
  }

  public openOTpreference(): any {
    this.document.getElementById('ot-sdk-btn').click();
  }

  public ngOnDestroy () {
    this.linkservice.removeCanonicalLink();
  }
}
