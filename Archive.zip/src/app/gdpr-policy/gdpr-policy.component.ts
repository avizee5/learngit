import { Component, OnInit, Input, Output, EventEmitter, Inject, HostListener, OnDestroy, ViewEncapsulation} from '@angular/core';
import * as $ from 'jquery';
import { SettingsService } from '../services/settings.service';
import {environment} from '../../environments/environment';
import { isPlatformBrowser } from '@angular/common';
import { PLATFORM_ID } from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { Subscription } from 'rxjs/Subscription';
import {Observable} from 'rxjs/Rx';
import { Subject } from 'rxjs/Subject';
import { RouteService } from '../services/route.service';



@Component({
  selector: 'app-gdpr-policy',
  templateUrl: './gdpr-policy.component.html',
  styleUrls: ['./gdpr-policy.component.less'],
  encapsulation: ViewEncapsulation.None,
})
export class GdprPolicyComponent implements OnInit, OnDestroy {
	public radioArray: any;
	public consentArray: any;
	public selectionTrack: Array<any> = [];
	private selectedButtonId: Array<any> = [];
	private controlRipple: any;
  public policyValues = [];
  private localstorage: any;
  private gdprValue: any;
  private policyMan: any;
  private profilingMan: any;
  private ageMan: any;
  private subscriptionMan: any;
  private policyStatus: any;
  private profilingStatus: any;
  private ageStatus: any;
  private subscriptionStatus: any;
  private configdata: any;
  public thirdstring: any;
  private line1: any;
  private window: any;
  private translation: any;
  @Input() private valueChange: any;                   // value binding sending to other component
  @Input() public classCheck: any;                     // for less from twitter
  @Input() public countryCheck: any;                  // for less from country gdpr popup
  @Input() public fontchange: any;                   // for font from country gdpr popup
  @Input() private countryListCCode: any;
  @Output() public update = new EventEmitter<boolean>();
  private ngUnsubscribe = new Subject<any>();
  constructor(private routeservice: RouteService,private translate: TranslateService, @Inject(PLATFORM_ID) private platformId: Object, private settingsService: SettingsService) {
    if (isPlatformBrowser(this.platformId)) {
      this.localstorage = localStorage;
      this.window = window;
    }
    for ( let i = 0; i <= 20; i++) {  // to remove old values
      this.selectionTrack[i] = false;
    }
    $('.loaderImage').css('display', 'block');
    this.configdata = this.settingsService.getCompleteConfig();
    let disp;
    disp = this.localstorage.getItem('display_language');
    setTimeout(() => {
      let value;
      value = this.countryListCCode;
      this.translate.get('GDPR.GDPR_LINE3').subscribe(valueage => {
        if (value && value[0] && value[0].age_validation.age) {
          this.thirdstring = valueage.replace(/18/g, value[0].age_validation.age);
        } else if (this.configdata.default_values) {
          this.thirdstring = valueage.replace(/18/g, this.configdata.default_values.age_validation.age);
         } else {
           this.thirdstring = valueage;
         }
        });
    if (value === undefined || value.length === 0) {
      let value1;
      value1 = this.settingsService.getCountryValueNew();
        if (value1 && value1.length >= 1 ) {
       this.gdprValue  = value1[0].gdpr_fields;
       this.translate.get('GDPR.GDPR_LINE3').subscribe(value2 => {
          if (value1[0].age_validation.age) {
          this.thirdstring = value2.replace(/18/g, value1[0].age_validation.age);
          } else {
            this.thirdstring = value2.replace(/18/g, this.configdata.default_values.age_validation.age);
          }
        });
     // policy
     if (this.gdprValue === undefined) {
      this.gdpr_config();
     } else {
     if (this.gdprValue.policy.default === 'checked') {
      this.selectionTrack[0] = true;
      } else {
      this.selectionTrack[0] = false;
    }
    if (this.gdprValue.policy.mendatory === 'yes') {
      this.policyMan = true;
      } else {
      this.policyMan = false;
    }
    if (this.gdprValue.policy.status === 'display') {
      this.policyStatus = true;
      } else {
      this.policyStatus = false;
    }
    // profiling
    if (this.gdprValue.profiling.default === 'checked') {
      this.selectionTrack[1] = true;
      } else {
      this.selectionTrack[1] = false;
    }
    if (this.gdprValue.profiling.mendatory === 'yes') {
      this.profilingMan = true;
      } else {
      this.profilingMan = false;
    }
    if (this.gdprValue.profiling.status === 'display') {
      this.profilingStatus = true;
      } else {
      this.profilingStatus = false;
    }
    // age
    if (this.gdprValue.age.default === 'checked') {
      this.selectionTrack[2] = true;
      } else {
      this.selectionTrack[2] = false;
    }
    if (this.gdprValue.age.mendatory === 'yes') {
      this.ageMan = true;
      } else {
      this.ageMan = false;
    }
    if (this.gdprValue.age.status === 'display') {
      this.ageStatus = true;
      } else {
      this.ageStatus = false;
    }
    // subscription
    if (this.gdprValue.subscription.default === 'yes') {
      this.onClicked('Yes', 0);
      this.selectionTrack[3] = true;
      this.selectedButtonId = [];
      this.selectedButtonId.push('Yes');
      this.isChecked('Yes');
      } else {
      this.onClicked('No', 1);
      this.selectionTrack[3] = false;
      this.selectedButtonId = [];
      this.selectedButtonId.push('No');
      this.isChecked('No');
    }
      if (this.gdprValue.subscription.mendatory === 'yes') {
      this.subscriptionMan = true;
      } else {
      this.subscriptionMan = false;
    }
    if (this.gdprValue.subscription.status === 'display') {
      this.subscriptionStatus = true;
      } else {
      this.subscriptionStatus = false;
    }
        // policy,profilling,age,subscription
      this.policyValues = [
          {'userValue': this.selectionTrack[0], 'userMandatory': this.policyMan, 'status': this.policyStatus},
          {'userValue': this.selectionTrack[1], 'userMandatory': this.profilingMan, 'status': this.profilingStatus},
          {'userValue': this.selectionTrack[2], 'userMandatory': this.ageMan, 'status': this.ageStatus},
          {'userValue': this.selectionTrack[3], 'userMandatory': this.subscriptionMan, 'status': this.subscriptionStatus}
        ];
        $('.auto-loader').css('display', 'none');
      }
     }
    } else {
    this.gdprValue = value[0].gdpr_fields;
     // policy
     if (this.gdprValue === undefined) {
       this.gdpr_config();
     } else {
    if (this.gdprValue.policy.default === 'checked') {
      this.selectionTrack[0] = true;
      } else {
      this.selectionTrack[0] = false;
    }
    if (this.gdprValue.policy.mendatory === 'yes') {
      this.policyMan = true;
      } else {
      this.policyMan = false;
    }
    if (this.gdprValue.policy.status === 'display') {
      this.policyStatus = true;
      } else {
      this.policyStatus = false;
    }
    // profiling
    if (this.gdprValue.profiling.default === 'checked') {
      this.selectionTrack[1] = true;
      } else {
      this.selectionTrack[1] = false;
    }
    if (this.gdprValue.profiling.mendatory === 'yes') {
      this.profilingMan = true;
      } else {
      this.profilingMan = false;
      }
    if (this.gdprValue.profiling.status === 'display') {
      this.profilingStatus = true;
      } else {
      this.profilingStatus = false;
      }
    // age
    if (this.gdprValue.age.default === 'checked') {
      this.selectionTrack[2] = true;
      } else {
      this.selectionTrack[2] = false;
      }
    if (this.gdprValue.age.mendatory === 'yes') {
      this.ageMan = true;
      } else {
      this.ageMan = false;
      }
    if (this.gdprValue.age.status === 'display') {
      this.ageStatus = true;
      } else {
      this.ageStatus = false;
      }
    // subscription
    if (this.gdprValue.subscription.default === 'yes') {
      this.onClicked('Yes', 0);
      this.selectionTrack[3] = true;
      this.selectedButtonId = [];
      this.selectedButtonId.push('Yes');
      this.isChecked('Yes');
      } else {
      this.onClicked('No', 1);
      this.selectionTrack[3] = false;
      this.selectedButtonId = [];
      this.selectedButtonId.push('No');
      this.isChecked('No');
    }
      if (this.gdprValue.subscription.mendatory === 'yes') {
      this.subscriptionMan = true;
      } else {
      this.subscriptionMan = false;
    }
    if (this.gdprValue.subscription.status === 'display') {
      this.subscriptionStatus = true;
      } else {
      this.subscriptionStatus = false;
    }
    this.policyValues = [
        {'userValue': this.selectionTrack[0], 'userMandatory': this.policyMan, 'status': this.policyStatus},
        {'userValue': this.selectionTrack[1], 'userMandatory': this.profilingMan, 'status': this.profilingStatus},
        {'userValue': this.selectionTrack[2], 'userMandatory': this.ageMan, 'status': this.ageStatus},
        {'userValue': this.selectionTrack[3], 'userMandatory': this.subscriptionMan, 'status': this.subscriptionStatus}
      ];
      $('.auto-loader').css('display', 'none');
    }
  }
  // }, error => {
  //   this.gdpr_config();
  // });
  }, 500);
  $('#loaderPage').css('display', 'none');
  }

  public ngOnInit() {
    this.sendData(this.valueChange);

  	this.radioArray = [{ id: '0', value: 'MENU.YES', original_value: 'Yes'},
                       { id: '1', value: 'MENU.NO', original_value: 'No'}];
    this.consentArray = [{id: '0', title: 'GDPR.GDPR_LINE1'},
                         {id: '1', title: 'GDPR.GDPR_LINE2'},
                         {id: '2', title: 'GDPR.GDPR_LINE3'}];
    $('.loaderImage').css('display', 'none');
    this.setString();
  }
@HostListener('window:resize', ['$event'])           // display scrollable header only in mobile browser
  public FontChange() {
    this.ResizeString();
  }
  public toggleCheckBox(index) {
  this.selectionTrack[index] = !this.selectionTrack[index];
  this.policyValues = [
          {'userValue': this.selectionTrack[0], 'userMandatory': this.policyMan, 'status': this.policyStatus},
          {'userValue': this.selectionTrack[1], 'userMandatory': this.profilingMan, 'status': this.profilingStatus},
          {'userValue': this.selectionTrack[2], 'userMandatory': this.ageMan, 'status': this.ageStatus},
          {'userValue': this.selectionTrack[3], 'userMandatory': this.subscriptionMan, 'status': this.subscriptionStatus}
        ];
        this.sendData(this.policyValues);
  }
  public onClicked(id, i) {
    $('#rippleRadio' + i).removeClass('animate');
   clearTimeout(this.controlRipple);
   $('#rippleRadio' + i).addClass('animate');
   this.controlRipple = setTimeout(() => {
   $('#rippleRadio' + i).removeClass('animate');
    }, 300);
   this.selectedButtonId = [];
   this.selectedButtonId.push(id);
   if (this.selectedButtonId[0] === 'Yes') {
     this.selectionTrack[3] = true;
   } else if (this.selectedButtonId[0] === 'No') {
     this.selectionTrack[3] = false;
   }
    this.policyValues = [
        {'userValue': this.selectionTrack[0], 'userMandatory': this.policyMan, 'status': this.policyStatus},
        {'userValue': this.selectionTrack[1], 'userMandatory': this.profilingMan, 'status': this.profilingStatus},
        {'userValue': this.selectionTrack[2], 'userMandatory': this.ageMan, 'status': this.ageStatus},
        {'userValue': this.selectionTrack[3], 'userMandatory': this.subscriptionMan, 'status': this.subscriptionStatus}
      ];
      this.sendData(this.policyValues);
  }

  private isChecked(id): boolean {
    return this.selectedButtonId.indexOf(id) > -1;
  }

  private gdpr_config() {
    this.configdata = this.settingsService.getCompleteConfig();
    this.gdprValue = this.configdata.default_values.gdpr_fields;
    this.translate.get('GDPR.GDPR_LINE3').subscribe(value2 => {
           this.thirdstring = value2.replace(/18/g, this.configdata.default_values.age_validation.age);
      });
     // policy
    if (this.gdprValue.policy.default === 'checked') {
      this.selectionTrack[0] = true;
      } else {
      this.selectionTrack[0] = false;
    }
    if (this.gdprValue.policy.mendatory === 'yes') {
      this.policyMan = true;
      } else {
      this.policyMan = false;
    }
    if (this.gdprValue.policy.status === 'display') {
      this.policyStatus = true;
      } else {
      this.policyStatus = false;
    }
    // profiling
    if (this.gdprValue.profiling.default === 'checked') {
      this.selectionTrack[1] = true;
      } else {
      this.selectionTrack[1] = false;
    }
    if (this.gdprValue.profiling.mendatory === 'yes') {
      this.profilingMan = true;
      } else {
      this.profilingMan = false;
    }
    if (this.gdprValue.profiling.status === 'display') {
      this.profilingStatus = true;
      } else {
      this.profilingStatus = false;
    }
    // age
    if (this.gdprValue.age.default === 'checked') {
      this.selectionTrack[2] = true;
      } else {
      this.selectionTrack[2] = false;
    }
    if (this.gdprValue.age.mendatory === 'yes') {
      this.ageMan = true;
      } else {
      this.ageMan = false;
    }
    if (this.gdprValue.age.status === 'display') {
      this.ageStatus = true;
      } else {
      this.ageStatus = false;
    }
    // subscription
    if (this.gdprValue.subscription.default === 'yes') {
      this.onClicked('Yes', 0);
      this.selectionTrack[3] = true;
      this.selectedButtonId = [];
      this.selectedButtonId.push('Yes');
      this.isChecked('Yes');
      } else {
      this.onClicked('No', 1);
      this.selectionTrack[3] = false;
      this.selectedButtonId = [];
      this.selectedButtonId.push('No');
      this.isChecked('No');
    }
    if (this.gdprValue.subscription.mendatory === 'yes') {
      this.subscriptionMan = true;
    } else {
      this.subscriptionMan = false;
    }
    if (this.gdprValue.subscription.status === 'display') {
      this.subscriptionStatus = true;
    } else {
      this.subscriptionStatus = false;
    }
      this.policyValues = [
        {'userValue': this.selectionTrack[0], 'userMandatory': this.policyMan, 'status': this.policyStatus},
        {'userValue': this.selectionTrack[1], 'userMandatory': this.profilingMan, 'status': this.profilingStatus},
        {'userValue': this.selectionTrack[2], 'userMandatory': this.ageMan, 'status': this.ageStatus},
        {'userValue': this.selectionTrack[3], 'userMandatory': this.subscriptionMan, 'status': this.subscriptionStatus}
      ];
      $('.auto-loader').css('display', 'none');
  }
    private sendData(value) {
      this.valueChange = value ;
      let data, sendFlag, count, sendCount, sendValue;
      sendFlag = true;
      count = 0;
      data = this.valueChange;
      if (data) {
        for (let i = 0; i < 3; i++) {                  // only for three points
          if (data[i]) {
            if (data[i].userMandatory === true) {      // if mandantory
              count++;
              if (data[i].userValue === false) {
                 sendFlag = false;                       // for accept button to unable r not
               }
            }
          }
        }
      }
      if (count > 0) {
        sendCount = true ;                             // if it is false accept unable it in register component
      }
      sendValue = {
        'sendCount' : sendCount,
        'sendFlag' : sendFlag,
        'sendValues' : this.policyValues
      };
      this.update.emit(sendValue);
    }
  private ResizeString() {
  if (this.window.innerWidth < 801) {
    $('.line1').html('<div style="font-size:12px;display:inherit">' + this.line1 + '</div>');
    } else {
      $('.line1').html('<div style="font-size:0.9375vw;display:inherit">' + this.line1 + '</div>');
    }
  }
  private setString(): void {
  this.translation = this.routeservice.getcurrentLanguage();
    if (this.window.innerWidth < 801) {
      this.translate.get(['GDPR.GDPR_LINE1']).takeUntil(this.ngUnsubscribe).subscribe(value => {
        this.line1 = value['GDPR.GDPR_LINE1'];
        this.line1 = this.line1.replace('<a>', '<a class="textclick" href="' + environment.shareUrl + this.translation + '/termsofuse" target="_blank">');
        this.line1 = this.line1.replace('<p>', '<a class="textclick" href="' + environment.shareUrl + this.translation + '/privacypolicy" target="_blank">');
    });
    } else {
      this.translate.get(['GDPR.GDPR_LINE1']).takeUntil(this.ngUnsubscribe).subscribe(value => {
        this.line1 = value['GDPR.GDPR_LINE1'];
        this.line1 = this.line1.replace('<a>', '<a class="textclick" href="' + environment.shareUrl + this.translation + '/termsofuse" target="_blank">');
        this.line1 = this.line1.replace('<p>', '<a class="textclick" href="' + environment.shareUrl + this.translation + '/privacypolicy" target="_blank">');
    });
   }
  }
  public ngOnDestroy() {
    this.ngUnsubscribe.complete();
    this.ngUnsubscribe.next();
  }
}
