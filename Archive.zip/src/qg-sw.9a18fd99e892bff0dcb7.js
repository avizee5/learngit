var appId = "9a18fd99e892bff0dcb7";
importScripts("https://cdn.qgraph.io/v3/r/qg-sw.js");