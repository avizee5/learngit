var appId = "ee4a1f660a8f1cfccc7c";
importScripts("https://cdn.qgraph.io/v3/r/qg-sw.js");