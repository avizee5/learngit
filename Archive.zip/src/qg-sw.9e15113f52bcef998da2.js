var appId = "9e15113f52bcef998da2";
importScripts("https://cdn.qgraph.io/v3/r/qg-sw.js");