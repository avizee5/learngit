var appId = "a1f8a604216c1d7877d2";
importScripts("https://cdn.qgraph.io/v3/r/qg-sw.js");
