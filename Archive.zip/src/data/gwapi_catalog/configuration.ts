export class Configuration {
  public apiKey: string;
  public username: string;
  public password: string;
  public accessToken: string | (() => string);
  public withCredentials: boolean;
}
