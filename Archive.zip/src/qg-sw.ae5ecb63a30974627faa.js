var appId = "ae5ecb63a30974627faa";
importScripts("https://cdn.qgraph.io/v3/r/qg-sw.js");